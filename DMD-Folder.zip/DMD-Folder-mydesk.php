<?php

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

require_once __DIR__ . '/DMD-Folder-lib.php';

if (!dmdfolder_has_permission('module.view')) {
    echo '<section class="dmd-folder-denied">⛔ Accès à DMD-Folder refusé.</section>';
    return;
}

$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-Folder';

$normalizedModule = str_replace('\\', '/', $moduleRealDir);
$normalizedDocumentRoot = rtrim(str_replace('\\', '/', $documentRoot), '/');

if ($normalizedDocumentRoot !== '' && strpos($normalizedModule, $normalizedDocumentRoot . '/') === 0) {
    $moduleWebPath = '/' . ltrim(substr($normalizedModule, strlen($normalizedDocumentRoot)), '/');
}

$domydeskRoot = dmdfolder_domydesk_root();
$email = dmdfolder_current_email();
$safeUser = function_exists('dmd_safe_user_key') ? dmd_safe_user_key($email) : basename($email);

$theme = 'default';
$themeFile = $domydeskRoot . '/users/profiles/' . $safeUser . '/theme.json';

if (is_file($themeFile)) {
    $themeData = json_decode((string)@file_get_contents($themeFile), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidate = basename((string)$themeData['theme']);
        if (is_file($domydeskRoot . '/theme/' . $candidate . '/style.css')) {
            $theme = $candidate;
        }
    }
}

$webRoot = preg_replace('~/modules/DMD-Folder/?$~', '', rtrim($moduleWebPath, '/'));
$themeUrl = ($webRoot !== '' ? $webRoot : '') . '/theme/' . rawurlencode($theme) . '/style.css';

$build = '126';
$mydeskCssVersion = is_file(__DIR__ . '/DMD-Folder-mydesk.css')
    ? (string)filemtime(__DIR__ . '/DMD-Folder-mydesk.css')
    : $build;
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>/DMD-Folder.css?v=<?= $build ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>/DMD-Folder-mydesk.css?v=<?= rawurlencode($mydeskCssVersion) ?>">

<section class="dmd-folder-inline dmd-folder-explorer dmd-folder-mydesk"
         data-dmd-folder
         data-folder-inline="1"
         data-module-url="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>"
         data-dmd-module-id="DMD-Folder"
         data-dmd-module-name="DMD-Folder"
         aria-label="DMD-Folder">
    <div class="dmd-folder-inline-loading">Chargement de DMD-Folder…</div>
</section>

<script>
(function () {
    document.documentElement.classList.add('dmd-folder-mydesk-host');
    if (document.body) document.body.classList.add('dmd-folder-mydesk-host');

    function sourceWindow() {
        var candidates = [];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}

        for (var i = 0; i < candidates.length; i++) {
            try {
                if (candidates[i].document && candidates[i].location.origin === window.location.origin) {
                    return candidates[i];
                }
            } catch (_) {}
        }
        return null;
    }

    function syncTheme() {
        var source = sourceWindow();
        if (!source) return;

        var names = [
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg',
            '--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft',
            '--border-color','--danger-color','--success-color','--warning-color','--shadow-color',
            '--radius-sm','--radius','--radius-lg','--font-family',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow',
            '--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color',
            '--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg',
            '--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];

        var targets = [document.documentElement];
        if (document.body) targets.push(document.body);

        [source.document.documentElement, source.document.body].filter(Boolean).forEach(function (sourceRoot) {
            var computed = source.getComputedStyle(sourceRoot);
            names.forEach(function (name) {
                var value = computed.getPropertyValue(name);
                if (!value || !value.trim()) return;
                targets.forEach(function (target) {
                    target.style.setProperty(name, value.trim());
                });
            });
        });

        try {
            var bodyStyle = source.getComputedStyle(source.document.body);
            targets.forEach(function (target) {
                if (bodyStyle.fontFamily) target.style.fontFamily = bodyStyle.fontFamily;
            });
        } catch (_) {}
    }

    syncTheme();
    window.addEventListener('focus', syncTheme);
    setTimeout(syncTheme, 120);
})();
</script>

<script src="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>/DMD-Folder.js?v=<?= $build ?>"></script>
