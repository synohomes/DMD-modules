<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

const DMDFOLDER_MODULE_ID = 'DMD-Folder';
const DMDFOLDER_MODULE_NAME = 'DMD-Folder';
const DMDFOLDER_VERSION = '1.2.6';

function dmdfolder_domydesk_root(): string
{
    $root = realpath(dirname(__DIR__, 2));
    if ($root === false || !is_dir($root)) {
        throw new RuntimeException('Racine DoMyDesk introuvable.');
    }
    return rtrim(str_replace('\\', '/', $root), '/');
}
function dmdfolder_current_email(): string
{
    $email = trim((string)($_SESSION['user']['email'] ?? ''));
    if ($email === '' || $email !== basename($email) || strpos($email, "\0") !== false || preg_match('~[\\/]~', $email)) {
        throw new RuntimeException('Utilisateur non connecté.');
    }
    return $email;
}

function dmdfolder_is_admin(): bool
{
    $roles = [
        strtolower((string)($_SESSION['user']['role_system'] ?? '')),
        strtolower((string)($_SESSION['role_system'] ?? '')),
        strtolower((string)($_SESSION['user']['role'] ?? '')),
        strtolower((string)($_SESSION['role'] ?? '')),
    ];
    foreach ($roles as $role) {
        if (in_array($role, ['admin', 'administrator', 'superadmin'], true)) {
            return true;
        }
    }
    return false;
}

function dmdfolder_access_root(): array
{
    $domydesk = dmdfolder_domydesk_root();
    $isAdmin = dmdfolder_is_admin() && dmdfolder_has_permission('folder.admin_root');

    if ($isAdmin) {
        return [
            'root' => $domydesk,
            'label' => 'DoMyDesk',
            'is_admin' => true,
            'email' => dmdfolder_current_email(),
        ];
    }

    $email = dmdfolder_current_email();
    $userDir = $domydesk . '/users/profiles/' . $email;
    if (!is_dir($userDir)) {
        throw new RuntimeException('Dossier utilisateur inaccessible.');
    }

    $real = realpath($userDir);
    if ($real === false) {
        throw new RuntimeException('Dossier utilisateur inaccessible.');
    }

    return [
        'root' => rtrim(str_replace('\\', '/', $real), '/'),
        'label' => 'Mes fichiers',
        'is_admin' => false,
        'email' => $email,
    ];
}

function dmdfolder_user_protected_files(): array
{
    return [
        'profile.json',
        'modules.json',
        'account.json',
        'auth.json',
        'roles.json',
        'permissions.json',
        'security.json',
    ];
}

function dmdfolder_is_protected_path(string $relative, ?array $access = null): bool
{
    if ($access === null) $access = dmdfolder_access_root();
    if (!empty($access['is_admin'])) {
        return false;
    }

    $relative = dmdfolder_normalize_relative($relative, true);
    if ($relative === '') {
        return false;
    }

    $parts = explode('/', strtolower($relative));

    // Le dossier /profile est réservé au Core (future migration profile.json + modules.json).
    if (($parts[0] ?? '') === 'profile') {
        return true;
    }

    return count($parts) === 1
        && in_array($parts[0], dmdfolder_user_protected_files(), true);
}
function dmdfolder_is_forbidden_user_file(string $relative, ?array $access = null): bool
{
    if ($access === null) $access = dmdfolder_access_root();
    if (!empty($access['is_admin'])) {
        return false;
    }

    $relative = dmdfolder_normalize_relative($relative, false);
    $name = strtolower(basename($relative));
    if (in_array($name, ['.htaccess', '.user.ini', 'web.config'], true)) {
        return true;
    }

    $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    return in_array($extension, [
        'php', 'php3', 'php4', 'php5', 'php7', 'php8',
        'phtml', 'pht', 'phar', 'cgi', 'shtml'
    ], true);
}

function dmdfolder_protection_reason(string $relative, bool $isFile, ?array $access = null): string
{
    if ($access === null) $access = dmdfolder_access_root();
    if (dmdfolder_is_protected_path($relative, $access)) {
        return 'Fichier système protégé : modification réservée à l’administrateur.';
    }
    if ($isFile && dmdfolder_is_forbidden_user_file($relative, $access)) {
        return 'Type de fichier exécutable interdit dans un dossier utilisateur.';
    }
    return '';
}

function dmdfolder_assert_mutation_allowed(string $relative, bool $isFile, ?array $access = null): void
{
    $reason = dmdfolder_protection_reason($relative, $isFile, $access);
    if ($reason !== '') {
        throw new RuntimeException($reason);
    }
}

function dmdfolder_normalize_relative(string $relative, bool $allowEmpty = true): string
{
    $relative = str_replace('\\', '/', trim($relative));
    $relative = trim($relative, '/');

    if ($relative === '') {
        if ($allowEmpty) {
            return '';
        }
        throw new InvalidArgumentException('Chemin vide.');
    }

    if (strpos($relative, "\0") !== false) {
        throw new InvalidArgumentException('Chemin invalide.');
    }

    $parts = explode('/', $relative);
    $clean = [];
    foreach ($parts as $part) {
        if ($part === '' || $part === '.' || $part === '..') {
            throw new InvalidArgumentException('Chemin interdit.');
        }
        $clean[] = $part;
    }
    return implode('/', $clean);
}

function dmdfolder_is_inside(string $path, string $root): bool
{
    $path = rtrim(str_replace('\\', '/', $path), '/');
    $root = rtrim(str_replace('\\', '/', $root), '/');
    return $path === $root || strpos($path . '/', $root . '/') === 0;
}

function dmdfolder_reject_symlink_chain(string $root, string $relative): void
{
    if ($relative === '') {
        return;
    }
    $cursor = rtrim($root, '/');
    foreach (explode('/', $relative) as $part) {
        $cursor .= '/' . $part;
        if (is_link($cursor)) {
            throw new RuntimeException('Les liens symboliques sont refusés.');
        }
    }
}

function dmdfolder_existing_path(string $relative, ?string $requiredType = null): array
{
    $access = dmdfolder_access_root();
    $relative = dmdfolder_normalize_relative($relative, true);

    if (dmdfolder_is_protected_path($relative, $access)) {
        throw new RuntimeException('Accès à une zone système protégée refusé.');
    }

    dmdfolder_reject_symlink_chain($access['root'], $relative);

    $candidate = $access['root'] . ($relative !== '' ? '/' . $relative : '');
    $real = realpath($candidate);
    if ($real === false) {
        throw new RuntimeException('Fichier ou dossier introuvable.');
    }
    $real = str_replace('\\', '/', $real);
    if (!dmdfolder_is_inside($real, $access['root'])) {
        throw new RuntimeException('Accès hors du dossier autorisé refusé.');
    }
    if ($requiredType === 'file' && !is_file($real)) {
        throw new RuntimeException('Ce chemin n’est pas un fichier.');
    }
    if ($requiredType === 'dir' && !is_dir($real)) {
        throw new RuntimeException('Ce chemin n’est pas un dossier.');
    }

    return [$real, $relative, $access];
}

function dmdfolder_validate_name(string $name): string
{
    $name = trim($name);
    if ($name === '' || $name === '.' || $name === '..' || $name !== basename($name)) {
        throw new InvalidArgumentException('Nom invalide.');
    }
    if (strpos($name, "\0") !== false || preg_match('~[\\/]~', $name)) {
        throw new InvalidArgumentException('Nom invalide.');
    }
    return $name;
}

function dmdfolder_new_path(string $parentRelative, string $name): array
{
    [$parent, $parentRelative, $access] = dmdfolder_existing_path($parentRelative, 'dir');
    $name = dmdfolder_validate_name($name);
    $target = $parent . '/' . $name;
    if (file_exists($target) || is_link($target)) {
        throw new RuntimeException('Un élément porte déjà ce nom.');
    }
    if (!dmdfolder_is_inside($target, $access['root'])) {
        throw new RuntimeException('Chemin de destination refusé.');
    }
    $relative = $parentRelative === '' ? $name : $parentRelative . '/' . $name;
    return [$target, $relative, $access];
}

function dmdfolder_csrf_token(): string
{
    if (empty($_SESSION['dmdfolder_csrf']) || !is_string($_SESSION['dmdfolder_csrf'])) {
        $_SESSION['dmdfolder_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['dmdfolder_csrf'];
}

function dmdfolder_check_csrf(): void
{
    $token = (string)($_POST['csrf'] ?? $_SERVER['HTTP_X_DMD_FOLDER_CSRF'] ?? '');
    if ($token === '' || !hash_equals(dmdfolder_csrf_token(), $token)) {
        throw new RuntimeException('Jeton de sécurité invalide. Recharge le module.');
    }
}

function dmdfolder_mime(string $path): string
{
    if (class_exists('finfo')) {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($path);
        if (is_string($mime) && $mime !== '') {
            return $mime;
        }
    }
    return 'application/octet-stream';
}

function dmdfolder_is_text_file(string $path, ?string $mime = null): bool
{
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $textExt = [
        'txt','md','markdown','log','json','xml','yaml','yml','ini','conf','cfg','csv','tsv',
        'php','phtml','html','htm','css','scss','less','js','mjs','cjs','ts','tsx','jsx',
        'sql','sh','bash','zsh','cmd','bat','ps1','py','rb','go','java','c','h','cpp','hpp',
        'vue','svelte','twig','env','htaccess','gitignore','dockerfile','makefile'
    ];
    if (in_array($ext, $textExt, true)) {
        return true;
    }
    if ($mime === null) $mime = dmdfolder_mime($path);
    return strpos($mime, 'text/') === 0 || in_array($mime, [
        'application/json','application/javascript','application/xml','application/x-httpd-php',
        'application/sql','application/x-sh','application/x-shellscript'
    ], true);
}

function dmdfolder_preview_type(string $path, string $mime): string
{
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    if (dmdfolder_is_text_file($path, $mime)) return 'text';
    if (strpos($mime, 'image/') === 0 && $ext !== 'svg') return 'image';
    if ($mime === 'application/pdf' || $ext === 'pdf') return 'pdf';
    if (strpos($mime, 'audio/') === 0) return 'audio';
    if (strpos($mime, 'video/') === 0) return 'video';
    return 'binary';
}

function dmdfolder_format_size(int $bytes): string
{
    if ($bytes < 1024) return $bytes . ' o';
    $units = ['Ko','Mo','Go','To'];
    $value = $bytes / 1024;
    foreach ($units as $unit) {
        if ($value < 1024 || $unit === 'To') {
            return number_format($value, $value >= 10 ? 1 : 2, ',', ' ') . ' ' . $unit;
        }
        $value /= 1024;
    }
    return $bytes . ' o';
}

function dmdfolder_relative_from_absolute(string $absolute, string $root): string
{
    $absolute = str_replace('\\', '/', $absolute);
    $root = rtrim(str_replace('\\', '/', $root), '/');
    if ($absolute === $root) return '';
    return ltrim(substr($absolute, strlen($root)), '/');
}

function dmdfolder_load_core_services(): void
{
    static $loaded = false;
    if ($loaded) return;
    $loaded = true;
    $root = dmdfolder_domydesk_root();
    foreach ([
        $root . '/core/dmd_permissions.php',
        $root . '/core/dmd_system_services.php',
        $root . '/core/dmd_module_events.php',
        $root . '/core/dmd_mfa.php',
    ] as $file) {
        if (is_file($file)) {
            try { require_once $file; } catch (Throwable $e) { /* intégration optionnelle */ }
        }
    }
}

function dmdfolder_has_permission(string $permission): bool
{
    try { dmdfolder_current_email(); } catch (Throwable $e) { return false; }
    dmdfolder_load_core_services();
    if (function_exists('dmd_current_user_has_module_permission')) {
        try {
            return (bool)dmd_current_user_has_module_permission(DMDFOLDER_MODULE_ID, $permission);
        } catch (Throwable $e) {
            return false;
        }
    }
    return dmdfolder_is_admin();
}

function dmdfolder_require_permission(string $permission): void
{
    if (!dmdfolder_has_permission($permission)) {
        throw new RuntimeException('Droit DMD-Folder refusé : ' . $permission . '.');
    }
}

function dmdfolder_permissions_snapshot(): array
{
    $permissions = [
        'module.view', 'folder.list', 'folder.read', 'folder.download', 'folder.search',
        'folder.create', 'folder.upload', 'folder.edit', 'folder.rename', 'folder.move',
        'folder.delete', 'folder.admin_root', 'logs.view', 'logs.export', 'logs.delete',
    ];
    $out = [];
    foreach ($permissions as $permission) {
        $out[$permission] = dmdfolder_has_permission($permission);
    }
    return $out;
}

function dmdfolder_runtime_root(): string
{
    $root = dmdfolder_domydesk_root() . '/data/modules/' . DMDFOLDER_MODULE_ID;
    if (!is_dir($root) && !@mkdir($root, 0770, true) && !is_dir($root)) {
        throw new RuntimeException('Stockage persistant DMD-Folder inaccessible.');
    }
    $htaccess = $root . '/.htaccess';
    if (!is_file($htaccess)) {
        @file_put_contents($htaccess, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\nOptions -Indexes\n", LOCK_EX);
    }
    foreach (['backups', 'logs', 'indexes'] as $dir) {
        $path = $root . '/' . $dir;
        if (!is_dir($path)) @mkdir($path, 0770, true);
    }
    dmdfolder_migrate_legacy_backups($root);
    return $root;
}

function dmdfolder_runtime_dir(string $name): string
{
    if (!in_array($name, ['backups', 'logs', 'indexes'], true)) {
        throw new InvalidArgumentException('Répertoire persistant invalide.');
    }
    $dir = dmdfolder_runtime_root() . '/' . $name;
    if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) {
        throw new RuntimeException('Répertoire persistant DMD-Folder inaccessible.');
    }
    return $dir;
}


function dmdfolder_config_default(): array
{
    return [
        'version' => 2,
        'mfa_enabled' => false,
        'mfa_timeout_minutes' => 15,
    ];
}

function dmdfolder_config_path(): string
{
    return dmdfolder_runtime_root() . '/config.json';
}

function dmdfolder_config_read(): array
{
    $default = dmdfolder_config_default();
    $file = dmdfolder_config_path();
    if (!is_file($file)) return $default;

    $raw = @file_get_contents($file);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($data)) return $default;

    $timeout = isset($data['mfa_timeout_minutes']) ? (int)$data['mfa_timeout_minutes'] : (int)$default['mfa_timeout_minutes'];
    $timeout = max(1, min(1440, $timeout));

    return [
        'version' => 2,
        'mfa_enabled' => !empty($data['mfa_enabled']),
        'mfa_timeout_minutes' => $timeout,
        'updated_at' => isset($data['updated_at']) ? (string)$data['updated_at'] : '',
        'updated_by' => isset($data['updated_by']) ? (string)$data['updated_by'] : '',
    ];
}

function dmdfolder_config_write(array $config, string $updatedBy = ''): bool
{

    $current = dmdfolder_config_read();
    $clean = dmdfolder_config_default();
    $clean['mfa_enabled'] = array_key_exists('mfa_enabled', $config)
        ? !empty($config['mfa_enabled'])
        : !empty($current['mfa_enabled']);
    $timeout = array_key_exists('mfa_timeout_minutes', $config)
        ? (int)$config['mfa_timeout_minutes']
        : (int)($current['mfa_timeout_minutes'] ?? $clean['mfa_timeout_minutes']);
    $clean['mfa_timeout_minutes'] = max(1, min(1440, $timeout));
    $clean['updated_at'] = date(DATE_ATOM);
    $clean['updated_by'] = $updatedBy;

    $json = json_encode($clean, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;

    $file = dmdfolder_config_path();
    $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000, 9999);
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        return false;
    }
    @chmod($file, 0640);
    return true;
}

function dmdfolder_mfa_service_available(): bool
{
    dmdfolder_load_core_services();
    return function_exists('dmd_mfa_enabled') && function_exists('dmd_mfa_verify_user_code');
}

function dmdfolder_mfa_session_key(): string
{
    return 'dmdfolder_mfa_verified';
}

function dmdfolder_mfa_timeout_minutes(): int
{
    $config = dmdfolder_config_read();
    return max(1, min(1440, (int)($config['mfa_timeout_minutes'] ?? 15)));
}

function dmdfolder_mfa_forget_verification(string $email): void
{
    $key = dmdfolder_mfa_session_key();
    if (isset($_SESSION[$key]) && is_array($_SESSION[$key])) {
        unset($_SESSION[$key][$email]);
        if (!$_SESSION[$key]) unset($_SESSION[$key]);
    }
}

function dmdfolder_mfa_verified_at(string $email): int
{
    $bucket = $_SESSION[dmdfolder_mfa_session_key()] ?? [];
    if (!is_array($bucket)) return 0;
    return max(0, (int)($bucket[$email] ?? 0));
}

function dmdfolder_mfa_is_verified(string $email): bool
{
    $verifiedAt = dmdfolder_mfa_verified_at($email);
    if ($verifiedAt <= 0) return false;

    $ttl = dmdfolder_mfa_timeout_minutes() * 60;
    if (($verifiedAt + $ttl) <= time()) {
        dmdfolder_mfa_forget_verification($email);
        return false;
    }
    return true;
}

function dmdfolder_mfa_mark_verified(string $email): void
{
    $key = dmdfolder_mfa_session_key();
    if (!isset($_SESSION[$key]) || !is_array($_SESSION[$key])) $_SESSION[$key] = [];
    $_SESSION[$key][$email] = time();
    unset($_SESSION['dmdfolder_mfa_failures'][$email]);
}

function dmdfolder_mfa_state(): array
{
    $config = dmdfolder_config_read();
    $moduleEnabled = !empty($config['mfa_enabled']);
    $email = dmdfolder_current_email();
    $available = dmdfolder_mfa_service_available();

    if (!$moduleEnabled) {
        return [
            'enabled' => false,
            'available' => $available,
            'account_enabled' => false,
            'required' => false,
            'verified' => true,
            'timeout_minutes' => dmdfolder_mfa_timeout_minutes(),
            'verified_at' => 0,
            'expires_at' => 0,
            'remaining_seconds' => 0,
        ];
    }

    if (!$available) {
        return [
            'enabled' => true,
            'available' => false,
            'account_enabled' => null,
            'required' => true,
            'verified' => false,
            'timeout_minutes' => dmdfolder_mfa_timeout_minutes(),
            'verified_at' => 0,
            'expires_at' => 0,
            'remaining_seconds' => 0,
        ];
    }

    $accountEnabled = (bool)dmd_mfa_enabled($email);
    $required = $accountEnabled;
    $verified = !$required || dmdfolder_mfa_is_verified($email);
    $verifiedAt = ($required && $verified) ? dmdfolder_mfa_verified_at($email) : 0;
    $timeoutMinutes = dmdfolder_mfa_timeout_minutes();
    $expiresAt = $verifiedAt > 0 ? ($verifiedAt + ($timeoutMinutes * 60)) : 0;

    return [
        'enabled' => true,
        'available' => true,
        'account_enabled' => $accountEnabled,
        'required' => $required,
        'verified' => $verified,
        'timeout_minutes' => $timeoutMinutes,
        'verified_at' => $verifiedAt,
        'expires_at' => $expiresAt,
        'remaining_seconds' => $expiresAt > 0 ? max(0, $expiresAt - time()) : 0,
    ];
}

function dmdfolder_mfa_verify_code(string $code): bool
{
    $state = dmdfolder_mfa_state();
    if (empty($state['enabled']) || empty($state['required'])) return true;
    if (empty($state['available'])) throw new RuntimeException('Le service MFA central DoMyDesk est indisponible.');

    $email = dmdfolder_current_email();
    $failures = $_SESSION['dmdfolder_mfa_failures'][$email] ?? ['count' => 0, 'locked_until' => 0];
    if (!is_array($failures)) $failures = ['count' => 0, 'locked_until' => 0];
    $lockedUntil = (int)($failures['locked_until'] ?? 0);
    if ($lockedUntil > time()) {
        throw new RuntimeException('Trop de tentatives MFA. Réessaie dans ' . max(1, $lockedUntil - time()) . ' seconde(s).');
    }

    $usedRecovery = false;
    if (dmd_mfa_verify_user_code($email, trim($code), $usedRecovery)) {
        dmdfolder_mfa_mark_verified($email);
        return true;
    }

    $count = (int)($failures['count'] ?? 0) + 1;
    if ($count >= 5) {
        $_SESSION['dmdfolder_mfa_failures'][$email] = ['count' => 0, 'locked_until' => time() + 60];
        throw new RuntimeException('Code MFA incorrect. Trop de tentatives : accès bloqué pendant 60 secondes.');
    }
    $_SESSION['dmdfolder_mfa_failures'][$email] = ['count' => $count, 'locked_until' => 0];
    throw new RuntimeException('Code MFA incorrect. Tentatives restantes : ' . (5 - $count) . '.');
}

function dmdfolder_migrate_legacy_backups(string $runtimeRoot): void
{
    static $running = false;
    if ($running) return;
    $running = true;
    try {
        $marker = $runtimeRoot . '/indexes/legacy-backups-migrated.json';
        if (is_file($marker)) return;
        $domydesk = dmdfolder_domydesk_root();
        $candidates = [
            $domydesk . '/modules/dmd-folder/backups',
            $domydesk . '/modules/dmd_folder/backups',
        ];
        $copied = 0;
        foreach ($candidates as $legacy) {
            if (!is_dir($legacy)) continue;
            $destination = $runtimeRoot . '/backups/legacy-' . date('Ymd-His');
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($legacy, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );
            foreach ($iterator as $item) {
                if ($item->isLink()) continue;
                $relative = ltrim(str_replace('\\', '/', substr($item->getPathname(), strlen($legacy))), '/');
                if ($relative === '') continue;
                $target = $destination . '/' . $relative;
                if ($item->isDir()) {
                    if (!is_dir($target)) @mkdir($target, 0770, true);
                } elseif ($item->isFile()) {
                    if (!is_dir(dirname($target))) @mkdir(dirname($target), 0770, true);
                    if (@copy($item->getPathname(), $target)) $copied++;
                }
            }
        }
        @file_put_contents($marker, json_encode([
            'schema' => 1,
            'migrated_at' => date(DATE_ATOM),
            'copied_files' => $copied,
            'source_deleted' => false,
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    } finally {
        $running = false;
    }
}

function dmdfolder_resource(string $relative, string $type, ?string $name = null, ?array $access = null): array
{
    if ($access === null) $access = dmdfolder_access_root();
    $relative = dmdfolder_normalize_relative($relative, true);
    $type = $type === 'dir' || $type === 'folder' ? 'folder' : 'file';
    $resourceName = $name !== null && trim($name) !== ''
        ? trim($name)
        : ($relative === '' ? (string)$access['label'] : basename($relative));

    $scope = 'system';
    $identityPath = $relative;
    if (empty($access['is_admin'])) {
        $scope = 'user:' . strtolower((string)$access['email']);
    } else {
        $parts = $relative === '' ? [] : explode('/', $relative);
        if (($parts[0] ?? '') === 'users' && ($parts[1] ?? '') === 'profiles' && !empty($parts[2])) {
            $scope = 'user:' . strtolower((string)$parts[2]);
            $identityPath = implode('/', array_slice($parts, 3));
        }
    }
    $identity = $scope . '|' . $type . '|' . $identityPath;
    return [
        'type' => $type,
        'id' => DMDFOLDER_MODULE_ID . ':' . $type . ':' . substr(hash('sha256', $identity), 0, 24),
        'name' => $resourceName,
        'path' => $relative,
        'scope' => $scope,
    ];
}

function dmdfolder_affected_emails(string $relative, ?array $access = null): array
{
    if ($access === null) $access = dmdfolder_access_root();
    $relative = dmdfolder_normalize_relative($relative, true);
    $emails = [];
    if (empty($access['is_admin'])) {
        if (!empty($access['email'])) $emails[] = strtolower((string)$access['email']);
    } else {
        $parts = $relative === '' ? [] : explode('/', $relative);
        if (($parts[0] ?? '') === 'users' && ($parts[1] ?? '') === 'profiles' && !empty($parts[2])) {
            $candidate = trim((string)$parts[2]);
            if ($candidate === basename($candidate) && !preg_match('~[\\/]~', $candidate)) {
                $emails[] = strtolower($candidate);
            }
        }
    }
    return array_values(array_unique(array_filter($emails)));
}

function dmdfolder_sanitize_log_value($value, int $depth = 0)
{
    if ($depth > 4) return '[depth-limit]';
    if (is_array($value)) {
        $out = [];
        foreach ($value as $key => $item) {
            $lower = strtolower((string)$key);
            if (preg_match('/content|password|passwd|token|secret|csrf|cookie|authorization|session/', $lower)) {
                $out[$key] = '[redacted]';
            } else {
                $out[$key] = dmdfolder_sanitize_log_value($item, $depth + 1);
            }
        }
        return $out;
    }
    if (is_string($value)) {
        if (strlen($value) > 800) return substr($value, 0, 800) . '…';
        return $value;
    }
    if (is_scalar($value) || $value === null) return $value;
    return is_object($value) ? get_class($value) : gettype($value);
}

function dmdfolder_log_event(string $action, string $target, string $result = 'success', array $details = [], ?array $resource = null, array $affectedUsers = []): void
{
    try {
        $entry = [
            'id' => bin2hex(random_bytes(12)),
            'timestamp' => date(DATE_ATOM),
            'user' => dmdfolder_current_email(),
            'module' => DMDFOLDER_MODULE_ID,
            'action' => $action,
            'target' => $target,
            'result' => $result,
            'details' => dmdfolder_sanitize_log_value($details),
            'resource' => $resource,
            'affected_users' => array_values(array_unique($affectedUsers)),
        ];
        $file = dmdfolder_runtime_dir('logs') . '/' . date('Y-m') . '.jsonl';
        $json = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json !== false) @file_put_contents($file, $json . PHP_EOL, FILE_APPEND | LOCK_EX);
    } catch (Throwable $e) { /* le journal ne doit jamais casser l'action métier */ }
}

function dmdfolder_log_months(): array
{
    $months = [];
    try {
        foreach (glob(dmdfolder_runtime_dir('logs') . '/*.jsonl') ?: [] as $file) {
            $month = basename($file, '.jsonl');
            if (preg_match('/^\\d{4}-\\d{2}$/', $month)) $months[] = $month;
        }
    } catch (Throwable $e) {}
    rsort($months, SORT_STRING);
    $current = date('Y-m');
    if (!in_array($current, $months, true)) array_unshift($months, $current);
    return array_values(array_unique($months));
}

function dmdfolder_logs_read(string $month, int $limit = 300): array
{
    if (!preg_match('/^\\d{4}-\\d{2}$/', $month)) throw new InvalidArgumentException('Mois de journal invalide.');
    $limit = max(1, min(500, $limit));
    $file = dmdfolder_runtime_dir('logs') . '/' . $month . '.jsonl';
    if (!is_file($file)) return [];
    $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    $slice = array_slice($lines, -$limit);
    $entries = [];
    foreach (array_reverse($slice) as $line) {
        $entry = json_decode($line, true);
        if (is_array($entry)) $entries[] = $entry;
    }
    return $entries;
}

function dmdfolder_logs_clear(string $month): bool
{
    if (!preg_match('/^\\d{4}-\\d{2}$/', $month)) throw new InvalidArgumentException('Mois de journal invalide.');
    $file = dmdfolder_runtime_dir('logs') . '/' . $month . '.jsonl';
    return !is_file($file) || @unlink($file);
}

function dmdfolder_action_label(string $action): string
{
    $labels = [
        'read' => 'Fichier consulté',
        'download' => 'Fichier téléchargé',
        'save' => 'Fichier modifié',
        'create_file' => 'Fichier créé',
        'mkdir' => 'Dossier créé',
        'rename' => 'Élément renommé',
        'move' => 'Élément déplacé',
        'delete' => 'Élément supprimé',
        'upload' => 'Fichier importé',
        'open' => 'Élément ouvert',
        'assert_exists' => 'Chemin vérifié',
    ];
    return $labels[$action] ?? ('DMD-Folder · ' . $action);
}

function dmdfolder_quick_session_event(string $action, string $target, array $resource, array $details = []): void
{
    dmdfolder_load_core_services();
    if (!function_exists('dmd_module_event')) return;
    try {
        $actor = dmdfolder_current_email();
        dmd_module_event(DMDFOLDER_MODULE_ID, $action, $resource, [
            'email' => $actor,
            'label' => dmdfolder_action_label($action),
            'target' => $target !== '' ? $target : (string)($resource['name'] ?? ''),
            'status' => 'success',
            'details' => (string)($details['message'] ?? ''),
            'meta' => [
                'source' => DMDFOLDER_MODULE_ID,
                'details' => dmdfolder_sanitize_log_value($details),
            ],
        ]);
    } catch (Throwable $e) {  }
}

function dmdfolder_notify_affected(string $action, string $target, array $resource, array $affectedUsers, array $details = []): void
{
    if ($affectedUsers === []) return;
    dmdfolder_load_core_services();
    if (!function_exists('dmd_notify_user')) return;
    $actor = '';
    try { $actor = strtolower(dmdfolder_current_email()); } catch (Throwable $e) { return; }
    $labels = [
        'save' => 'modifié', 'create_file' => 'créé', 'mkdir' => 'créé', 'upload' => 'importé',
        'rename' => 'renommé', 'move' => 'déplacé', 'delete' => 'supprimé',
    ];
    $verb = $labels[$action] ?? 'modifié';
    foreach (array_unique($affectedUsers) as $email) {
        $email = strtolower(trim((string)$email));
        if ($email === '' || $email === $actor) continue;
        try {
            dmd_notify_user(
                $email,
                'dmdfolder_change',
                'DMD-Folder : élément ' . $verb,
                $actor . ' a ' . $verb . ' « ' . ($resource['name'] ?? basename($target)) . ' » dans un espace qui vous concerne.',
                [
                    'level' => $action === 'delete' ? 'warning' : 'info',
                    'action_url' => 'dashboard.php',
                    'action_label' => 'Ouvrir DMD-Folder',
                    'meta' => [
                        'module' => DMDFOLDER_MODULE_ID,
                        'action' => $action,
                        'resource' => $resource,
                        'target' => $target,
                        'details' => dmdfolder_sanitize_log_value($details),
                    ],
                ]
            );
        } catch (Throwable $e) {  }
    }
}

function dmdfolder_audit(string $action, string $target, array $resource, array $details = [], array $affectedUsers = [], bool $notify = false, bool $quickSession = false): void
{
    dmdfolder_log_event($action, $target, 'success', $details, $resource, $affectedUsers);
    if ($quickSession) dmdfolder_quick_session_event($action, $target, $resource, $details);
    if ($notify) dmdfolder_notify_affected($action, $target, $resource, $affectedUsers, $details);
}

function dmdfolder_backup_file(string $absolute, string $relative, string $reason): ?string
{
    if (!is_file($absolute) || is_link($absolute)) return null;
    $size = filesize($absolute);
    if ($size === false || $size > 20 * 1024 * 1024) return null;

    $backupRoot = dmdfolder_runtime_dir('backups');
    if (dmdfolder_is_inside($absolute, $backupRoot)) return null;

    if (!is_dir($backupRoot) && !@mkdir($backupRoot, 0770, true) && !is_dir($backupRoot)) {
        return null;
    }
    $htaccess = $backupRoot . '/.htaccess';
    if (!is_file($htaccess)) {
        @file_put_contents($htaccess, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\nOptions -Indexes\n");
    }

    $safeReason = preg_replace('/[^a-z0-9_-]/i', '_', $reason) ?: 'change';
    $emailHash = substr(hash('sha256', dmdfolder_current_email()), 0, 12);
    $stamp = date('Ymd_His') . '_' . bin2hex(random_bytes(3));
    $relativeSafe = str_replace(['..', '\\'], ['_', '/'], $relative);
    $target = $backupRoot . '/' . date('Ymd') . '/' . $emailHash . '/' . $relativeSafe . '.' . $stamp . '.' . $safeReason . '.bak';
    $targetDir = dirname($target);
    if (!is_dir($targetDir) && !@mkdir($targetDir, 0770, true) && !is_dir($targetDir)) {
        return null;
    }
    return @copy($absolute, $target) ? $target : null;
}

function dmdfolder_delete_tree(string $path): void
{
    if (is_link($path) || is_file($path)) {
        if (!@unlink($path)) throw new RuntimeException('Suppression impossible.');
        return;
    }
    if (!is_dir($path)) throw new RuntimeException('Élément introuvable.');

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($iterator as $item) {
        $itemPath = $item->getPathname();
        if ($item->isLink() || $item->isFile()) {
            if (!@unlink($itemPath)) throw new RuntimeException('Suppression incomplète : ' . $item->getFilename());
        } elseif ($item->isDir() && !@rmdir($itemPath)) {
            throw new RuntimeException('Suppression incomplète : ' . $item->getFilename());
        }
    }
    if (!@rmdir($path)) throw new RuntimeException('Impossible de supprimer le dossier.');
}

function dmdfolder_json(array $payload, int $status = 200)
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
