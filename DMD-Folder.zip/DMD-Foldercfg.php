<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
require_once __DIR__ . '/DMD-Folder-lib.php';

if (!dmdfolder_has_permission('module.view')) {
    echo '<section class="dmd-folder-denied">⛔ Accès à la configuration DMD-Folder refusé.</section>';
    return;
}

$email = '';
try { $email = dmdfolder_current_email(); } catch (Throwable $e) {}
$permissions = dmdfolder_permissions_snapshot();
$access = null;
try { $access = dmdfolder_access_root(); } catch (Throwable $e) {}

$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-Folder';
$normalizedModule = str_replace('\\', '/', $moduleRealDir);
$normalizedDocumentRoot = rtrim(str_replace('\\', '/', $documentRoot), '/');
if ($normalizedDocumentRoot !== '' && strpos($normalizedModule, $normalizedDocumentRoot . '/') === 0) {
    $moduleWebPath = '/' . ltrim(substr($normalizedModule, strlen($normalizedDocumentRoot)), '/');
}
?>
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>/DMD-Folder.css?v=121">
<section class="dmd-folder-cfg" data-dmd-module-id="DMD-Folder">
    <header class="dmd-folder-cfg-header">
        <div>
            <span class="dmd-folder-cfg-kicker">DoMyDesk 1.2.0</span>
            <h3>📁 DMD-Folder</h3>
        </div>
        <span class="dmd-folder-cfg-version">v1.2.0</span>
    </header>
    <p>Le module n’a pas de paramètre utilisateur à saisir. Les accès sont pilotés par les droits fins DoMyDesk 1.2.0.</p>

    <div class="dmd-folder-cfg-grid">
        <article class="dmd-folder-cfg-card">
            <strong>Racine effective</strong>
            <code><?= !empty($access['is_admin']) ? 'DoMyDesk/' : 'users/profiles/' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . '/' ?></code>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Données persistantes du module</strong>
            <code>data/modules/DMD-Folder/</code>
            <span>Backups, journaux et index d’activité sont conservés hors du dossier du module.</span>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Intégrations Core</strong>
            <span>Action Hub · Quick-Session · Notifications · Permissions 1.2.0</span>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Droits actifs</strong>
            <span><?= count(array_filter($permissions)) ?> / <?= count($permissions) ?> permissions accordées à cette session.</span>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Sécurité</strong>
            <span>Contrôle backend des droits et chemins, CSRF, refus des traversées, symlinks et fichiers exécutables interdits pour les utilisateurs.</span>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Sauvegarde avant modification</strong>
            <span>Copie persistante avant édition, renommage, déplacement ou suppression d’un fichier jusqu’à 20 Mo.</span>
        </article>
    </div>
</section>
