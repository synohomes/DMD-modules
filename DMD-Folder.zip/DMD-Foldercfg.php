<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
require_once __DIR__ . '/DMD-Folder-lib.php';

if (!dmdfolder_has_permission('module.view')) {
    echo '<section class="dmd-folder-denied">⛔ Accès à la configuration DMD-Folder refusé.</section>';
    return;
}

$email = '';
try { $email = dmdfolder_current_email(); } catch (Throwable $e) {}
$permissions = dmdfolder_permissions_snapshot();
$access = null;
try { $access = dmdfolder_access_root(); } catch (Throwable $e) {}
$config = dmdfolder_config_read();
$canConfigure = dmdfolder_is_admin();
$mfaAvailable = dmdfolder_mfa_service_available();
$accountMfaEnabled = false;
if ($mfaAvailable && $email !== '' && function_exists('dmd_mfa_enabled')) {
    try { $accountMfaEnabled = (bool)dmd_mfa_enabled($email); } catch (Throwable $e) {}
}
$csrf = dmdfolder_csrf_token();

$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-Folder';
$normalizedModule = str_replace('\\', '/', $moduleRealDir);
$normalizedDocumentRoot = rtrim(str_replace('\\', '/', $documentRoot), '/');
if ($normalizedDocumentRoot !== '' && strpos($normalizedModule, $normalizedDocumentRoot . '/') === 0) {
    $moduleWebPath = '/' . ltrim(substr($normalizedModule, strlen($normalizedDocumentRoot)), '/');
}
?>
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>/DMD-Folder.css?v=125">
<section class="dmd-folder-cfg" data-dmd-module-id="DMD-Folder" data-dmd-folder-cfg data-api="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>/DMD-Folder-api.php" data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
    <header class="dmd-folder-cfg-header">
        <div>
            <span class="dmd-folder-cfg-kicker">DoMyDesk 1.2.0</span>
            <h3>📁 DMD-Folder</h3>
        </div>
        <span class="dmd-folder-cfg-version">v<?= htmlspecialchars(DMDFOLDER_VERSION, ENT_QUOTES, 'UTF-8') ?></span>
    </header>
    <p>Les accès restent pilotés par les droits fins DoMyDesk. Le MFA du module utilise uniquement le moteur MFA central de DoMyDesk.</p>

    <div class="dmd-folder-cfg-grid">
        <article class="dmd-folder-cfg-card dmd-folder-cfg-card-wide">
            <div class="dmd-folder-cfg-card-head">
                <div>
                    <strong>🔐 MFA à l’ouverture de DMD-Folder</strong>
                    <span>Quand il est activé, un utilisateur qui possède déjà le MFA sur son compte doit saisir un code Authenticator à la première ouverture du module pendant sa session.</span>
                </div>
                <label class="dmd-folder-switch" title="Activer ou désactiver le MFA du module">
                    <input type="checkbox" data-mfa-toggle <?= !empty($config['mfa_enabled']) ? 'checked' : '' ?> <?= ($canConfigure && ($mfaAvailable || !empty($config['mfa_enabled']))) ? '' : 'disabled' ?>>
                    <span aria-hidden="true"></span>
                </label>
            </div>
            <div class="dmd-folder-cfg-mfa-state">
                <span>Module : <strong data-mfa-module-state><?= !empty($config['mfa_enabled']) ? 'Activé' : 'Désactivé' ?></strong></span>
                <span>MFA central : <strong><?= $mfaAvailable ? 'Disponible' : 'Indisponible' ?></strong></span>
                <span>Ton compte : <strong><?= $accountMfaEnabled ? 'MFA activé' : 'MFA non activé' ?></strong></span>
            </div>
            <label class="dmd-folder-cfg-timeout">
                <span>
                    <strong>⏱️ Reverrouillage automatique</strong>
                    <small>Après cette durée, DMD-Folder se verrouille et redemande le MFA à la prochaine utilisation.</small>
                </span>
                <span class="dmd-folder-cfg-timeout-control">
                    <input type="number" min="1" max="1440" step="1" value="<?= (int)($config['mfa_timeout_minutes'] ?? 15) ?>" data-mfa-timeout <?= $canConfigure ? '' : 'disabled' ?>>
                    <em>minute(s)</em>
                </span>
            </label>
            <small>Si un compte n’a pas activé le MFA DoMyDesk, DMD-Folder ne le bloque pas. Aucun secret MFA n’est stocké dans le module.</small>
            <?php if (!$canConfigure): ?>
                <small class="dmd-folder-cfg-warning">Modification réservée à un administrateur DoMyDesk.</small>
            <?php endif; ?>
            <?php if ($canConfigure && !$mfaAvailable && empty($config['mfa_enabled'])): ?>
                <small class="dmd-folder-cfg-warning">Le MFA ne peut pas être activé tant que le service MFA central DoMyDesk n’est pas disponible.</small>
            <?php endif; ?>
            <div class="dmd-folder-cfg-feedback" data-cfg-feedback></div>
        </article>

        <article class="dmd-folder-cfg-card">
            <strong>Racine effective</strong>
            <code><?= !empty($access['is_admin']) ? 'DoMyDesk/' : 'users/profiles/' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . '/' ?></code>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Données persistantes du module</strong>
            <code>data/modules/DMD-Folder/</code>
            <span>Configuration, backups, journaux et index d’activité sont conservés hors du dossier du module.</span>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Intégrations Core</strong>
            <span>Quick-Session · Notifications · Permissions 1.2.0 · MFA central</span>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Droits actifs</strong>
            <span><?= count(array_filter($permissions)) ?> / <?= count($permissions) ?> permissions accordées à cette session.</span>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Sécurité</strong>
            <span>Contrôle backend des droits et chemins, CSRF, refus des traversées, symlinks et fichiers exécutables interdits pour les utilisateurs.</span>
        </article>
        <article class="dmd-folder-cfg-card">
            <strong>Sauvegarde avant modification</strong>
            <span>Copie persistante avant édition, renommage, déplacement ou suppression d’un fichier jusqu’à 20 Mo.</span>
        </article>
    </div>
</section>
<script>
(function(){
    const root = document.querySelector('[data-dmd-folder-cfg]');
    if (!root || root.dataset.bound === '1') return;
    root.dataset.bound = '1';
    const toggle = root.querySelector('[data-mfa-toggle]');
    const feedback = root.querySelector('[data-cfg-feedback]');
    const state = root.querySelector('[data-mfa-module-state]');
    const timeout = root.querySelector('[data-mfa-timeout]');
    if (!toggle || toggle.disabled) return;

    async function saveConfig(previousToggle, previousTimeout){
        toggle.disabled = true;
        if (timeout) timeout.disabled = true;
        if (feedback) {
            feedback.textContent = 'Enregistrement…';
            feedback.dataset.kind = 'info';
        }
        const timeoutValue = Math.max(1, Math.min(1440, parseInt(timeout && timeout.value ? timeout.value : '15', 10) || 15));
        if (timeout) timeout.value = String(timeoutValue);
        const form = new FormData();
        form.append('action', 'config_save');
        form.append('csrf', root.dataset.csrf || '');
        form.append('mfa_enabled', toggle.checked ? '1' : '0');
        form.append('mfa_timeout_minutes', String(timeoutValue));
        try {
            const response = await fetch(root.dataset.api, {method:'POST', body:form, credentials:'same-origin'});
            const text = await response.text();
            let data = null;
            try { data = JSON.parse(text); } catch (e) {}
            if (!response.ok || !data || !data.ok) throw new Error(data && data.message ? data.message : 'Enregistrement impossible.');
            if (state) state.textContent = toggle.checked ? 'Activé' : 'Désactivé';
            if (feedback) {
                feedback.textContent = data.message + ' Le déverrouillage MFA courant a été réinitialisé.';
                feedback.dataset.kind = 'ok';
            }
        } catch (error) {
            toggle.checked = previousToggle;
            if (timeout) timeout.value = String(previousTimeout);
            if (feedback) {
                feedback.textContent = error.message || String(error);
                feedback.dataset.kind = 'error';
            }
        } finally {
            toggle.disabled = false;
            if (timeout) timeout.disabled = false;
        }
    }

    toggle.addEventListener('change', function(){
        const previousToggle = !toggle.checked;
        const previousTimeout = timeout ? (parseInt(timeout.value || '15', 10) || 15) : 15;
        saveConfig(previousToggle, previousTimeout);
    });

    if (timeout) timeout.addEventListener('change', function(){
        const previousTimeout = parseInt(timeout.dataset.savedValue || timeout.defaultValue || '15', 10) || 15;
        const previousToggle = toggle.checked;
        saveConfig(previousToggle, previousTimeout).then(function(){
            timeout.dataset.savedValue = timeout.value;
        });
    });
    if (timeout) timeout.dataset.savedValue = timeout.value;
})();
</script>
