<?php
declare(strict_types=1);

require_once __DIR__ . '/DMD-Folder-lib.php';

$action = strtolower(trim((string)($_GET['action'] ?? $_POST['action'] ?? 'info')));
$rawTarget = trim((string)($_GET['path'] ?? $_POST['path'] ?? $_GET['month'] ?? $_POST['month'] ?? ''));

try {
    dmdfolder_require_permission('module.view');

    if ($action === 'info') {
        $access = dmdfolder_access_root();
        $rootResource = dmdfolder_resource('', 'folder', $access['label'], $access);
        dmdfolder_log_event('info', '', 'success', [], $rootResource);
        dmdfolder_json([
            'ok' => true,
            'module_id' => DMDFOLDER_MODULE_ID,
            'module_name' => DMDFOLDER_MODULE_NAME,
            'version' => DMDFOLDER_VERSION,
            'is_admin' => $access['is_admin'],
            'root_label' => $access['label'],
            'root_resource' => $rootResource,
            'permissions' => dmdfolder_permissions_snapshot(),
            'csrf' => dmdfolder_csrf_token(),
            'max_edit_bytes' => 2 * 1024 * 1024,
            'max_upload_bytes' => (int)min(
                dmdfolder_parse_ini_bytes((string)ini_get('upload_max_filesize')),
                dmdfolder_parse_ini_bytes((string)ini_get('post_max_size'))
            ),
        ]);
    }

    if ($action === 'list') {
        dmdfolder_require_permission('folder.list');
        [$dir, $relative, $access] = dmdfolder_existing_path((string)($_GET['path'] ?? ''), 'dir');
        $items = [];
        $scan = @scandir($dir);
        if ($scan === false) throw new RuntimeException('Lecture du dossier impossible.');

        foreach ($scan as $name) {
            if ($name === '.' || $name === '..') continue;
            $absolute = $dir . '/' . $name;
            $itemRelative = $relative === '' ? $name : $relative . '/' . $name;

            if (is_link($absolute)) {
                $items[] = [
                    'name' => $name,
                    'path' => $itemRelative,
                    'type' => 'link',
                    'size' => 0,
                    'size_label' => 'Lien refusé',
                    'modified' => @filemtime($absolute) ?: 0,
                    'modified_label' => date('d/m/Y H:i', @filemtime($absolute) ?: time()),
                    'extension' => strtolower(pathinfo($name, PATHINFO_EXTENSION)),
                    'editable' => false,
                    'preview' => 'binary',
                    'writable' => false,
                    'protected' => true,
                    'protection_reason' => 'Lien symbolique refusé.',
                    'resource' => null,
                ];
                continue;
            }

            $isDir = is_dir($absolute);
            $size = $isDir ? 0 : (int)(@filesize($absolute) ?: 0);
            $mime = $isDir ? 'inode/directory' : dmdfolder_mime($absolute);
            $protectionReason = dmdfolder_protection_reason($itemRelative, !$isDir, $access);
            $protected = $protectionReason !== '';

            if ($protected && empty($access['is_admin'])) continue;

            $items[] = [
                'name' => $name,
                'path' => $itemRelative,
                'type' => $isDir ? 'dir' : 'file',
                'size' => $size,
                'size_label' => $isDir ? 'Dossier' : dmdfolder_format_size($size),
                'modified' => (int)(@filemtime($absolute) ?: 0),
                'modified_label' => date('d/m/Y H:i', @filemtime($absolute) ?: time()),
                'extension' => strtolower(pathinfo($name, PATHINFO_EXTENSION)),
                'mime' => $mime,
                'editable' => !$protected && !$isDir && dmdfolder_is_text_file($absolute, $mime) && $size <= 2 * 1024 * 1024,
                'preview' => $isDir ? 'dir' : dmdfolder_preview_type($absolute, $mime),
                'writable' => !$protected && is_writable($absolute),
                'protected' => $protected,
                'protection_reason' => $protectionReason,
                'resource' => dmdfolder_resource($itemRelative, $isDir ? 'folder' : 'file', $name, $access),
            ];
        }

        usort($items, static function (array $a, array $b): int {
            $order = ['dir' => 0, 'file' => 1, 'link' => 2];
            $cmp = ($order[$a['type']] ?? 9) <=> ($order[$b['type']] ?? 9);
            return $cmp !== 0 ? $cmp : strnatcasecmp($a['name'], $b['name']);
        });

        $parent = '';
        if ($relative !== '') {
            $parts = explode('/', $relative);
            array_pop($parts);
            $parent = implode('/', $parts);
        }
        $resource = dmdfolder_resource($relative, 'folder', $relative === '' ? $access['label'] : basename($relative), $access);
        dmdfolder_log_event('list', $relative, 'success', ['items' => count($items)], $resource);
        dmdfolder_json([
            'ok' => true,
            'path' => $relative,
            'parent' => $parent,
            'root_label' => $access['label'],
            'is_admin' => $access['is_admin'],
            'writable' => is_writable($dir),
            'resource' => $resource,
            'items' => $items,
        ]);
    }

    if ($action === 'read') {
        dmdfolder_require_permission('folder.read');
        [$file, $relative, $access] = dmdfolder_existing_path((string)($_GET['path'] ?? ''), 'file');
        $size = (int)(@filesize($file) ?: 0);
        $mime = dmdfolder_mime($file);
        if (!dmdfolder_is_text_file($file, $mime)) throw new RuntimeException('Ce fichier n’est pas éditable comme texte.');
        if ($size > 2 * 1024 * 1024) throw new RuntimeException('Fichier trop volumineux pour l’éditeur intégré (2 Mo maximum).');
        $content = @file_get_contents($file);
        if ($content === false) throw new RuntimeException('Lecture du fichier impossible.');
        $protectionReason = dmdfolder_protection_reason($relative, true, $access);
        $resource = dmdfolder_resource($relative, 'file', basename($file), $access);
        dmdfolder_audit('read', $relative, $resource, ['size' => $size, 'mime' => $mime], [], false, true);
        dmdfolder_json([
            'ok' => true,
            'path' => $relative,
            'name' => basename($file),
            'mime' => $mime,
            'size' => $size,
            'content' => $content,
            'writable' => $protectionReason === '' && is_writable($file) && dmdfolder_has_permission('folder.edit'),
            'protected' => $protectionReason !== '',
            'protection_reason' => $protectionReason,
            'resource' => $resource,
        ]);
    }

    if ($action === 'stream' || $action === 'download') {
        dmdfolder_require_permission($action === 'download' ? 'folder.download' : 'folder.read');
        [$file, $relative, $access] = dmdfolder_existing_path((string)($_GET['path'] ?? ''), 'file');
        $name = basename($file);
        $mime = dmdfolder_mime($file);
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        $resource = dmdfolder_resource($relative, 'file', $name, $access);
        dmdfolder_audit($action, $relative, $resource, ['size' => (int)(@filesize($file) ?: 0), 'mime' => $mime], [], false, $action === 'download');

        if ($ext === 'svg' || $mime === 'image/svg+xml' || dmdfolder_is_text_file($file, $mime)) {
            $mime = 'text/plain; charset=utf-8';
            header("Content-Security-Policy: default-src 'none'");
        }
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . (string)filesize($file));
        $disposition = $action === 'download' ? 'attachment' : 'inline';
        header("Content-Disposition: {$disposition}; filename*=UTF-8''" . rawurlencode($name));
        readfile($file);
        exit;
    }

    if ($action === 'search') {
        dmdfolder_require_permission('folder.search');
        $query = trim((string)($_GET['q'] ?? ''));
        if ($query === '' || (function_exists('mb_strlen') ? mb_strlen($query) : strlen($query)) < 2) throw new RuntimeException('Saisis au moins 2 caractères.');
        [$dir, $relative, $access] = dmdfolder_existing_path((string)($_GET['path'] ?? ''), 'dir');
        $results = [];
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            if (count($results) >= 200) break;
            if ($item->isLink()) continue;
            if (stripos($item->getFilename(), $query) === false) continue;
            $absolute = str_replace('\\', '/', $item->getPathname());
            if (!dmdfolder_is_inside($absolute, $access['root'])) continue;
            $itemRelative = dmdfolder_relative_from_absolute($absolute, $access['root']);
            $isDir = $item->isDir();
            $protectionReason = dmdfolder_protection_reason($itemRelative, !$isDir, $access);
            $protected = $protectionReason !== '';
            if ($protected && empty($access['is_admin'])) continue;

            $results[] = [
                'name' => $item->getFilename(),
                'path' => $itemRelative,
                'type' => $isDir ? 'dir' : 'file',
                'size_label' => $isDir ? 'Dossier' : dmdfolder_format_size((int)$item->getSize()),
                'modified_label' => date('d/m/Y H:i', $item->getMTime()),
                'preview' => $isDir ? 'dir' : dmdfolder_preview_type($absolute, dmdfolder_mime($absolute)),
                'editable' => !$protected && !$isDir && dmdfolder_is_text_file($absolute) && $item->getSize() <= 2 * 1024 * 1024,
                'writable' => !$protected && is_writable($absolute),
                'protected' => $protected,
                'protection_reason' => $protectionReason,
                'resource' => dmdfolder_resource($itemRelative, $isDir ? 'folder' : 'file', $item->getFilename(), $access),
            ];
        }
        $resource = dmdfolder_resource($relative, 'folder', $relative === '' ? $access['label'] : basename($relative), $access);
        dmdfolder_log_event('search', $relative, 'success', ['query' => $query, 'results' => count($results)], $resource);
        dmdfolder_json(['ok' => true, 'items' => $results, 'query' => $query, 'path' => $relative]);
    }

    if ($action === 'logs_list') {
        dmdfolder_require_permission('logs.view');
        $month = trim((string)($_GET['month'] ?? date('Y-m')));
        $limit = (int)($_GET['limit'] ?? 300);
        $entries = dmdfolder_logs_read($month, $limit);
        dmdfolder_json(['ok' => true, 'month' => $month, 'months' => dmdfolder_log_months(), 'entries' => $entries]);
    }

    if ($action === 'logs_export') {
        dmdfolder_require_permission('logs.export');
        $month = trim((string)($_GET['month'] ?? date('Y-m')));
        if (!preg_match('/^\d{4}-\d{2}$/', $month)) throw new InvalidArgumentException('Mois de journal invalide.');
        dmdfolder_log_event('logs.export', $month, 'success');
        $file = dmdfolder_runtime_dir('logs') . '/' . $month . '.jsonl';
        header('Content-Type: text/csv; charset=utf-8');
        header('Cache-Control: private, no-store');
        header('Content-Disposition: attachment; filename="DMD-Folder-logs-' . $month . '.csv"');
        $out = fopen('php://output', 'wb');
        fputcsv($out, ['timestamp', 'user', 'action', 'target', 'result', 'resource_type', 'resource_id', 'resource_name', 'affected_users', 'details'], ';');
        if (is_file($file)) {
            $fh = fopen($file, 'rb');
            if ($fh) {
                while (($line = fgets($fh)) !== false) {
                    $entry = json_decode(trim($line), true);
                    if (!is_array($entry)) continue;
                    $resource = is_array($entry['resource'] ?? null) ? $entry['resource'] : [];
                    fputcsv($out, [
                        $entry['timestamp'] ?? '', $entry['user'] ?? '', $entry['action'] ?? '', $entry['target'] ?? '', $entry['result'] ?? '',
                        $resource['type'] ?? '', $resource['id'] ?? '', $resource['name'] ?? '',
                        implode(',', (array)($entry['affected_users'] ?? [])),
                        json_encode($entry['details'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    ], ';');
                }
                fclose($fh);
            }
        }
        fclose($out);
        exit;
    }

    dmdfolder_check_csrf();

    if ($action === 'logs_clear') {
        dmdfolder_require_permission('logs.delete');
        $month = trim((string)($_POST['month'] ?? date('Y-m')));
        if (!dmdfolder_logs_clear($month)) throw new RuntimeException('Impossible de vider ce journal.');
        dmdfolder_log_event('logs.clear', $month, 'success');
        dmdfolder_json(['ok' => true, 'message' => 'Journal ' . $month . ' vidé.']);
    }

    if ($action === 'save') {
        dmdfolder_require_permission('folder.edit');
        [$file, $relative, $access] = dmdfolder_existing_path((string)($_POST['path'] ?? ''), 'file');
        dmdfolder_assert_mutation_allowed($relative, true, $access);
        $mime = dmdfolder_mime($file);
        if (!dmdfolder_is_text_file($file, $mime)) throw new RuntimeException('Ce type de fichier n’est pas éditable.');
        $content = (string)($_POST['content'] ?? '');
        if (strlen($content) > 2 * 1024 * 1024) throw new RuntimeException('Le contenu dépasse 2 Mo.');
        if (!is_writable($file)) throw new RuntimeException('Le fichier n’est pas modifiable par le serveur web.');
        $backup = dmdfolder_backup_file($file, $relative, 'save');
        $bytes = @file_put_contents($file, $content, LOCK_EX);
        if ($bytes === false) throw new RuntimeException('Enregistrement impossible.');
        $resource = dmdfolder_resource($relative, 'file', basename($file), $access);
        $affected = dmdfolder_affected_emails($relative, $access);
        dmdfolder_audit('save', $relative, $resource, ['bytes' => $bytes, 'backup_created' => $backup !== null], $affected, true, true);
        dmdfolder_json(['ok' => true, 'message' => 'Fichier enregistré.', 'bytes' => $bytes, 'resource' => $resource]);
    }

    if ($action === 'create_file') {
        dmdfolder_require_permission('folder.create');
        [$target, $relative, $access] = dmdfolder_new_path((string)($_POST['path'] ?? ''), (string)($_POST['name'] ?? ''));
        dmdfolder_assert_mutation_allowed($relative, true, $access);
        $content = (string)($_POST['content'] ?? '');
        if (strlen($content) > 2 * 1024 * 1024) throw new RuntimeException('Le contenu dépasse 2 Mo.');
        if (@file_put_contents($target, $content, LOCK_EX) === false) throw new RuntimeException('Création du fichier impossible.');
        @chmod($target, 0664);
        $resource = dmdfolder_resource($relative, 'file', basename($target), $access);
        $affected = dmdfolder_affected_emails($relative, $access);
        dmdfolder_audit('create_file', $relative, $resource, ['bytes' => strlen($content)], $affected, true, true);
        dmdfolder_json(['ok' => true, 'message' => 'Fichier créé.', 'path' => $relative, 'resource' => $resource]);
    }

    if ($action === 'mkdir') {
        dmdfolder_require_permission('folder.create');
        [$target, $relative, $access] = dmdfolder_new_path((string)($_POST['path'] ?? ''), (string)($_POST['name'] ?? ''));
        dmdfolder_assert_mutation_allowed($relative, false, $access);
        if (!@mkdir($target, 0775, false)) throw new RuntimeException('Création du dossier impossible.');
        $resource = dmdfolder_resource($relative, 'folder', basename($target), $access);
        $affected = dmdfolder_affected_emails($relative, $access);
        dmdfolder_audit('mkdir', $relative, $resource, [], $affected, true, true);
        dmdfolder_json(['ok' => true, 'message' => 'Dossier créé.', 'path' => $relative, 'resource' => $resource]);
    }

    if ($action === 'rename') {
        dmdfolder_require_permission('folder.rename');
        [$source, $relative, $access] = dmdfolder_existing_path((string)($_POST['path'] ?? ''));
        if ($relative === '') throw new RuntimeException('La racine ne peut pas être renommée.');
        $isFile = is_file($source);
        dmdfolder_assert_mutation_allowed($relative, $isFile, $access);
        $newName = dmdfolder_validate_name((string)($_POST['name'] ?? ''));
        $target = dirname($source) . '/' . $newName;
        if (file_exists($target) || is_link($target)) throw new RuntimeException('Un élément porte déjà ce nom.');
        $newRelative = dmdfolder_relative_from_absolute(str_replace('\\', '/', $target), $access['root']);
        dmdfolder_assert_mutation_allowed($newRelative, $isFile, $access);
        $backup = $isFile ? dmdfolder_backup_file($source, $relative, 'rename') : null;
        if (!@rename($source, $target)) throw new RuntimeException('Renommage impossible.');
        $resource = dmdfolder_resource($newRelative, $isFile ? 'file' : 'folder', $newName, $access);
        $affected = array_values(array_unique(array_merge(dmdfolder_affected_emails($relative, $access), dmdfolder_affected_emails($newRelative, $access))));
        dmdfolder_audit('rename', $newRelative, $resource, ['from' => $relative, 'backup_created' => $backup !== null], $affected, true, true);
        dmdfolder_json(['ok' => true, 'message' => 'Élément renommé.', 'path' => $newRelative, 'resource' => $resource]);
    }

    if ($action === 'move') {
        dmdfolder_require_permission('folder.move');
        [$source, $relative, $access] = dmdfolder_existing_path((string)($_POST['path'] ?? ''));
        if ($relative === '') throw new RuntimeException('La racine ne peut pas être déplacée.');
        $isFile = is_file($source);
        dmdfolder_assert_mutation_allowed($relative, $isFile, $access);
        [$destination] = dmdfolder_existing_path((string)($_POST['destination'] ?? ''), 'dir');
        $target = $destination . '/' . basename($source);
        if (file_exists($target) || is_link($target)) throw new RuntimeException('Un élément du même nom existe déjà dans la destination.');
        if (is_dir($source) && dmdfolder_is_inside($destination, $source)) throw new RuntimeException('Impossible de déplacer un dossier dans lui-même.');
        if (!dmdfolder_is_inside($target, $access['root'])) throw new RuntimeException('Destination refusée.');
        $targetRelative = dmdfolder_relative_from_absolute(str_replace('\\', '/', $target), $access['root']);
        dmdfolder_assert_mutation_allowed($targetRelative, $isFile, $access);
        $backup = $isFile ? dmdfolder_backup_file($source, $relative, 'move') : null;
        if (!@rename($source, $target)) throw new RuntimeException('Déplacement impossible.');
        $resource = dmdfolder_resource($targetRelative, $isFile ? 'file' : 'folder', basename($target), $access);
        $affected = array_values(array_unique(array_merge(dmdfolder_affected_emails($relative, $access), dmdfolder_affected_emails($targetRelative, $access))));
        dmdfolder_audit('move', $targetRelative, $resource, ['from' => $relative, 'backup_created' => $backup !== null], $affected, true, true);
        dmdfolder_json(['ok' => true, 'message' => 'Élément déplacé.', 'path' => $targetRelative, 'resource' => $resource]);
    }

    if ($action === 'delete') {
        dmdfolder_require_permission('folder.delete');
        [$target, $relative, $access] = dmdfolder_existing_path((string)($_POST['path'] ?? ''));
        if ($relative === '') throw new RuntimeException('La racine ne peut pas être supprimée.');
        $isFile = is_file($target);
        dmdfolder_assert_mutation_allowed($relative, $isFile, $access);
        $resource = dmdfolder_resource($relative, $isFile ? 'file' : 'folder', basename($target), $access);
        $affected = dmdfolder_affected_emails($relative, $access);
        $backup = $isFile ? dmdfolder_backup_file($target, $relative, 'delete') : null;
        dmdfolder_delete_tree($target);
        dmdfolder_audit('delete', $relative, $resource, ['backup_created' => $backup !== null], $affected, true, true);
        dmdfolder_json(['ok' => true, 'message' => 'Élément supprimé.']);
    }

    if ($action === 'upload') {
        dmdfolder_require_permission('folder.upload');
        [$dir, $relative, $access] = dmdfolder_existing_path((string)($_POST['path'] ?? ''), 'dir');
        if (!is_writable($dir)) throw new RuntimeException('Le dossier n’est pas accessible en écriture.');
        if (empty($_FILES['files'])) throw new RuntimeException('Aucun fichier reçu.');
        $files = dmdfolder_normalize_uploads($_FILES['files']);
        $saved = [];
        $resources = [];
        $affected = [];
        foreach ($files as $upload) {
            if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                throw new RuntimeException('Échec de l’envoi : ' . dmdfolder_upload_error((int)$upload['error']));
            }
            if (!is_uploaded_file((string)$upload['tmp_name'])) throw new RuntimeException('Fichier envoyé invalide.');
            $name = dmdfolder_validate_name((string)$upload['name']);
            $target = dmdfolder_unique_target($dir, $name);
            $targetRelative = dmdfolder_relative_from_absolute(str_replace('\\', '/', $target), $access['root']);
            dmdfolder_assert_mutation_allowed($targetRelative, true, $access);
            if (!@move_uploaded_file((string)$upload['tmp_name'], $target)) throw new RuntimeException('Impossible d’enregistrer ' . $name . '.');
            @chmod($target, 0664);
            $saved[] = $targetRelative;
            $resource = dmdfolder_resource($targetRelative, 'file', basename($target), $access);
            $resources[] = $resource;
            $affected = array_merge($affected, dmdfolder_affected_emails($targetRelative, $access));
            dmdfolder_audit('upload', $targetRelative, $resource, ['bytes' => (int)($upload['size'] ?? 0)], dmdfolder_affected_emails($targetRelative, $access), true, true);
        }
        dmdfolder_json(['ok' => true, 'message' => count($saved) . ' fichier(s) importé(s).', 'paths' => $saved, 'resources' => $resources]);
    }

    throw new RuntimeException('Action inconnue.');
} catch (Throwable $e) {
    dmdfolder_log_event($action !== '' ? $action : 'unknown', $rawTarget, 'error', ['message' => $e->getMessage()]);
    $status = strpos($e->getMessage(), 'Droit DMD-Folder refusé') === 0 ? 403 : 400;
    dmdfolder_json(['ok' => false, 'message' => $e->getMessage()], $status);
}

function dmdfolder_parse_ini_bytes(string $value): int
{
    $value = trim($value);
    if ($value === '') return PHP_INT_MAX;
    $last = strtolower($value[strlen($value) - 1]);
    $number = (float)$value;
    if ($last === 'g') return (int)($number * 1024 * 1024 * 1024);
    if ($last === 'm') return (int)($number * 1024 * 1024);
    if ($last === 'k') return (int)($number * 1024);
    return (int)$number;
}

function dmdfolder_normalize_uploads(array $files): array
{
    if (!is_array($files['name'] ?? null)) return [$files];
    $out = [];
    foreach ($files['name'] as $i => $name) {
        $out[] = [
            'name' => $name,
            'type' => $files['type'][$i] ?? '',
            'tmp_name' => $files['tmp_name'][$i] ?? '',
            'error' => $files['error'][$i] ?? UPLOAD_ERR_NO_FILE,
            'size' => $files['size'][$i] ?? 0,
        ];
    }
    return $out;
}

function dmdfolder_unique_target(string $dir, string $name): string
{
    $target = $dir . '/' . $name;
    if (!file_exists($target) && !is_link($target)) return $target;
    $base = pathinfo($name, PATHINFO_FILENAME);
    $ext = pathinfo($name, PATHINFO_EXTENSION);
    for ($i = 2; $i < 10000; $i++) {
        $candidate = $dir . '/' . $base . ' (' . $i . ')' . ($ext !== '' ? '.' . $ext : '');
        if (!file_exists($candidate) && !is_link($candidate)) return $candidate;
    }
    throw new RuntimeException('Impossible de trouver un nom disponible.');
}

function dmdfolder_upload_error(int $code): string
{
    switch ($code) {
        case UPLOAD_ERR_INI_SIZE:
        case UPLOAD_ERR_FORM_SIZE:
            return 'fichier trop volumineux';
        case UPLOAD_ERR_PARTIAL:
            return 'envoi incomplet';
        case UPLOAD_ERR_NO_FILE:
            return 'aucun fichier';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'dossier temporaire absent';
        case UPLOAD_ERR_CANT_WRITE:
            return 'écriture disque impossible';
        case UPLOAD_ERR_EXTENSION:
            return 'envoi bloqué par PHP';
        default:
            return 'erreur inconnue';
    }
}
