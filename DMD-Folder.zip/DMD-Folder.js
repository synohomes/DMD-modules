(function () {
    'use strict';

    if (window.DMDFolder && typeof window.DMDFolder.initAll === 'function') {
        window.DMDFolder.initAll();
        return;
    }

    let zIndex = 12000;
    let windowOffset = 0;

    function esc(value) {
        return String(value ?? '').replace(/[&<>'"]/g, function (char) {
            return {'&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#039;', '"':'&quot;'}[char];
        });
    }

    function can(state, permission) {
        return !!(state && state.info && state.info.permissions && state.info.permissions[permission] === true);
    }

    function decorateActionHub(scope) {
        try {
            if (window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') {
                window.DMDActionHub.decorate(scope || document);
            }
        } catch (error) {}
    }

    function resourceAttrs(resource) {
        if (!resource || !resource.id || !resource.type) return '';
        return ' data-dmd-module-id="DMD-Folder"' +
            ' data-dmd-context-type="' + esc(resource.type) + '"' +
            ' data-dmd-context-id="' + esc(resource.id) + '"' +
            ' data-dmd-context-name="' + esc(resource.name || '') + '"' +
            ' data-dmd-action-hub="1"';
    }

    function viewport() {
        return {
            width: Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0),
            height: Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0),
            scrollX: window.scrollX || document.documentElement.scrollLeft || 0,
            scrollY: window.scrollY || document.documentElement.scrollTop || 0
        };
    }

    function bringToFront(win) {
        zIndex += 1;
        win.style.zIndex = String(zIndex);
    }

    function workspace() {
        return document.getElementById('dashboard') || document.querySelector('[data-dashboard]') || document.querySelector('main') || document.body;
    }

    function workspacePageOrigin(host) {
        const rect = host.getBoundingClientRect();
        return {
            left: rect.left + (window.scrollX || document.documentElement.scrollLeft || 0),
            top: rect.top + (window.scrollY || document.documentElement.scrollTop || 0)
        };
    }

    function expandDoMyDeskCanvas() {
        const ws = document.getElementById('dashboard');
        if (!ws) return;

        let maxRight = Math.max(document.documentElement.clientWidth || 0, ws.parentElement ? ws.parentElement.clientWidth : 0);
        let maxBottom = Math.max(document.documentElement.clientHeight || 0, ws.parentElement ? ws.parentElement.clientHeight : 0);

        ws.querySelectorAll('.module, .dmd-folder-window').forEach(function (element) {
            if (element.offsetParent === null) return;
            const right = element.offsetLeft + element.offsetWidth;
            const bottom = element.offsetTop + element.offsetHeight;
            if (right > maxRight) maxRight = right;
            if (bottom > maxBottom) maxBottom = bottom;
        });

        const width = Math.max(maxRight + 96, document.documentElement.clientWidth || 0);
        const height = Math.max(maxBottom + 96, document.documentElement.clientHeight || 0);
        ws.style.minWidth = width + 'px';
        ws.style.minHeight = height + 'px';

        const main = ws.closest('main') || document.querySelector('main');
        if (main) {
            main.style.minWidth = width + 'px';
            main.style.minHeight = height + 'px';
        }
    }

    function edgeAutoScroll(clientX, clientY) {
        const margin = 42;
        const step = 32;
        let dx = 0;
        let dy = 0;
        if (clientX >= window.innerWidth - margin) dx = step;
        else if (clientX <= margin) dx = -step;
        if (clientY >= window.innerHeight - margin) dy = step;
        else if (clientY <= margin) dy = -step;
        if (dx || dy) window.scrollBy(dx, dy);
    }

    function makeDraggable(win) {
        const handle = win.querySelector('.dmd-folder-window-header');
        if (!handle) return;
        let dragging = false;
        let startX = 0;
        let startY = 0;
        let startLeft = 0;
        let startTop = 0;

        handle.addEventListener('pointerdown', function (event) {
            if (event.target.closest('button, input, select, textarea, a')) return;
            dragging = true;
            startX = event.pageX;
            startY = event.pageY;
            startLeft = parseInt(win.style.left || String(win.offsetLeft), 10);
            startTop = parseInt(win.style.top || String(win.offsetTop), 10);
            bringToFront(win);
            handle.setPointerCapture(event.pointerId);
            document.body.classList.add('dmd-folder-moving');
            event.preventDefault();
        });

        handle.addEventListener('pointermove', function (event) {
            if (!dragging) return;
            win.style.left = Math.max(8, startLeft + event.pageX - startX) + 'px';
            win.style.top = Math.max(8, startTop + event.pageY - startY) + 'px';
            expandDoMyDeskCanvas();
            edgeAutoScroll(event.clientX, event.clientY);
        });

        function stop(event) {
            if (!dragging) return;
            dragging = false;
            try { handle.releasePointerCapture(event.pointerId); } catch (e) {}
            document.body.classList.remove('dmd-folder-moving');
            expandDoMyDeskCanvas();
        }

        handle.addEventListener('pointerup', stop);
        handle.addEventListener('pointercancel', stop);
    }

    function makeResizable(win) {
        const handle = win.querySelector('.dmd-folder-window-resizer');
        if (!handle) return;
        let resizing = false;
        let startX = 0;
        let startY = 0;
        let startWidth = 0;
        let startHeight = 0;

        handle.addEventListener('pointerdown', function (event) {
            resizing = true;
            startX = event.pageX;
            startY = event.pageY;
            startWidth = win.offsetWidth;
            startHeight = win.offsetHeight;
            bringToFront(win);
            handle.setPointerCapture(event.pointerId);
            document.body.classList.add('dmd-folder-resizing');
            event.preventDefault();
            event.stopPropagation();
        });

        handle.addEventListener('pointermove', function (event) {
            if (!resizing) return;
            win.style.width = Math.max(340, startWidth + event.pageX - startX) + 'px';
            win.style.height = Math.max(280, startHeight + event.pageY - startY) + 'px';
            expandDoMyDeskCanvas();
            edgeAutoScroll(event.clientX, event.clientY);
        });

        function stop(event) {
            if (!resizing) return;
            resizing = false;
            try { handle.releasePointerCapture(event.pointerId); } catch (e) {}
            document.body.classList.remove('dmd-folder-resizing');
            expandDoMyDeskCanvas();
        }

        handle.addEventListener('pointerup', stop);
        handle.addEventListener('pointercancel', stop);
    }

    function createWindow(options) {
        const vp = viewport();
        const width = Math.min(options.width || 1080, Math.max(340, vp.width - 32));
        const height = Math.min(options.height || 700, Math.max(280, vp.height - 32));
        windowOffset = (windowOffset + 24) % 144;

        const win = document.createElement('section');
        win.className = 'dmd-folder-window ' + (options.className || '');
        win.style.width = width + 'px';
        win.style.height = height + 'px';
        win.style.zIndex = String(++zIndex);
        win.innerHTML = `
            <header class="dmd-folder-window-header">
                <div class="dmd-folder-window-title"><span>${esc(options.icon || '📁')}</span><strong>${esc(options.title || 'DMD-Folder')}</strong></div>
                <div class="dmd-folder-window-actions">
                    <button type="button" data-window-maximize title="Agrandir / restaurer">▣</button>
                    <button type="button" data-window-close title="Fermer">×</button>
                </div>
            </header>
            <div class="dmd-folder-window-body"></div>
            <div class="dmd-folder-window-resizer" title="Redimensionner"></div>
        `;

        const host = workspace();
        const origin = workspacePageOrigin(host);
        const desiredPageLeft = vp.scrollX + Math.floor((vp.width - width) / 2) + windowOffset;
        const desiredPageTop = vp.scrollY + Math.floor((vp.height - height) / 2) + windowOffset;
        win.style.left = Math.max(8, desiredPageLeft - origin.left) + 'px';
        win.style.top = Math.max(8, desiredPageTop - origin.top) + 'px';
        host.appendChild(win);
        win.addEventListener('pointerdown', function () { bringToFront(win); });
        win.querySelector('[data-window-close]').addEventListener('click', function () {
            win.remove();
            expandDoMyDeskCanvas();
        });
        win.querySelector('[data-window-maximize]').addEventListener('click', function () {
            const isMax = win.dataset.maximized === '1';
            if (!isMax) {
                win.dataset.restore = JSON.stringify({
                    left: win.style.left,
                    top: win.style.top,
                    width: win.style.width,
                    height: win.style.height
                });
                const now = viewport();
                const host = win.offsetParent || workspace();
                const origin = workspacePageOrigin(host);
                win.style.left = Math.max(8, now.scrollX + 8 - origin.left) + 'px';
                win.style.top = Math.max(8, now.scrollY + 8 - origin.top) + 'px';
                win.style.width = Math.max(340, now.width - 16) + 'px';
                win.style.height = Math.max(280, now.height - 16) + 'px';
                win.dataset.maximized = '1';
            } else {
                try {
                    const restore = JSON.parse(win.dataset.restore || '{}');
                    Object.assign(win.style, restore);
                } catch (e) {}
                win.dataset.maximized = '0';
            }
            expandDoMyDeskCanvas();
        });

        makeDraggable(win);
        makeResizable(win);
        expandDoMyDeskCanvas();
        return win;
    }

    function setWindowTitle(win, title, icon) {
        if (!win) return;
        const titleEl = win.querySelector('.dmd-folder-window-title');
        if (titleEl) {
            titleEl.innerHTML = '<span>' + esc(icon || '📁') + '</span><strong>' + esc(title) + '</strong>';
            return;
        }
        win.setAttribute('aria-label', title);
        win.dataset.currentTitle = title;
    }

    function iconFor(item) {
        if (item.type === 'dir') return '📁';
        if (item.type === 'link') return '⛔';
        if (item.preview === 'image') return '🖼️';
        if (item.preview === 'pdf') return '📕';
        if (item.preview === 'audio') return '🎵';
        if (item.preview === 'video') return '🎬';
        if (item.preview === 'text') return '📄';
        return '📦';
    }

    function parentPath(path) {
        const parts = String(path || '').split('/').filter(Boolean);
        parts.pop();
        return parts.join('/');
    }

    function basename(path) {
        const parts = String(path || '').split('/').filter(Boolean);
        return parts.length ? parts[parts.length - 1] : '';
    }

    async function jsonFetch(url, options) {
        const response = await fetch(url, Object.assign({credentials: 'same-origin'}, options || {}));
        const text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (error) {
            throw new Error('Réponse serveur invalide (HTTP ' + response.status + ') : ' + text.slice(0, 180));
        }
        if (!response.ok || !data.ok) {
            throw new Error(data.message || 'Erreur serveur.');
        }
        return data;
    }

    function createClient(root) {
        const base = root.dataset.moduleUrl.replace(/\/$/, '');
        const api = base + '/DMD-Folder-api.php';
        let info = null;

        async function ensureInfo() {
            if (!info) info = await jsonFetch(api + '?action=info');
            return info;
        }

        async function get(action, params) {
            const query = new URLSearchParams(Object.assign({action: action}, params || {}));
            return jsonFetch(api + '?' + query.toString());
        }

        async function post(action, fields, files) {
            const current = await ensureInfo();
            const form = new FormData();
            form.append('action', action);
            form.append('csrf', current.csrf);
            Object.keys(fields || {}).forEach(function (key) {
                form.append(key, fields[key] == null ? '' : String(fields[key]));
            });
            (files || []).forEach(function (file) { form.append('files[]', file, file.name); });
            return jsonFetch(api, {method: 'POST', body: form});
        }

        function streamUrl(path, download) {
            return api + '?action=' + (download ? 'download' : 'stream') + '&path=' + encodeURIComponent(path);
        }

        function logsExportUrl(month) {
            return api + '?action=logs_export&month=' + encodeURIComponent(month || '');
        }

        return {base, api, ensureInfo, get, post, streamUrl, logsExportUrl};
    }

    function setStatus(state, message, kind) {
        state.status.textContent = message || '';
        state.status.dataset.kind = kind || 'info';
    }

function buildBreadcrumb(state) {
    const parts = state.path.split('/').filter(Boolean);

    if (!parts.length) {
        state.breadcrumb.innerHTML = '';
        return;
    }

    let current = '';
    let html = '';

    parts.forEach(function (part, index) {
        current = current ? current + '/' + part : part;

        if (index > 0) {
            html += '<span>›</span>';
        }

        html += '<button type="button" data-breadcrumb="' + esc(current) + '">' + esc(part) + '</button>';
    });

    state.breadcrumb.innerHTML = html;
}

    function renderSidebar(state, items) {
        if (!state.sidebar) return;
        const dirs = items.filter(function (item) { return item.type === 'dir'; });
        let html = '<button type="button" class="dmd-folder-side-root" data-side-path=""><span>🗂️</span><strong>' + esc(state.info.root_label) + '</strong></button>';
        if (state.path !== '') {
            html += '<button type="button" data-side-path="' + esc(parentPath(state.path)) + '"><span>↩️</span><span>Dossier parent</span></button>';
        }
        html += '<div class="dmd-folder-side-title">Sous-dossiers</div>';
        if (!dirs.length) {
            html += '<p class="dmd-folder-empty-small">Aucun sous-dossier</p>';
        } else {
            html += dirs.map(function (item) {
                return '<button type="button" data-side-path="' + esc(item.path) + '"><span>📁</span><span>' + esc(item.name) + '</span></button>';
            }).join('');
        }
        state.sidebar.innerHTML = html;
    }

    function renderItems(state, items, searchMode) {
        state.items = items;
        if (!items.length) {
            state.list.innerHTML = '<div class="dmd-folder-empty"><span>📭</span><strong>' + (searchMode ? 'Aucun résultat' : 'Dossier vide') + '</strong><small>' + (searchMode ? 'Essaie un autre nom.' : 'Aucun élément disponible dans ce dossier.') + '</small></div>';
            return;
        }

        state.list.innerHTML = `
            <div class="dmd-folder-table-head">
                <span>Nom</span><span>Actions</span>
            </div>
            <div class="dmd-folder-table-body">
                ${items.map(function (item) {
                    const disabled = item.type === 'link' ? ' disabled' : '';
                    const locked = item.protected === true;
                    const canOpen = item.type === 'dir' ? can(state, 'folder.list') : can(state, 'folder.read');
                    const canDownload = item.type !== 'dir' && can(state, 'folder.download');
                    const canRename = !locked && can(state, 'folder.rename');
                    const canMove = !locked && can(state, 'folder.move');
                    const canDelete = !locked && can(state, 'folder.delete');
                    const hasMenu = canDownload || canRename || canMove || canDelete;
                    const meta = item.type === 'dir'
                        ? ('Dossier' + (item.modified_label ? ' · ' + item.modified_label : ''))
                        : ([item.size_label, item.modified_label].filter(Boolean).join(' · ') || item.extension || item.mime || 'Fichier');
                    return `
                        <div class="dmd-folder-row" data-item-path="${esc(item.path)}" data-item-type="${esc(item.type)}"${resourceAttrs(item.resource)}>
                            <button type="button" class="dmd-folder-name" data-open-item${disabled}${canOpen ? '' : ' disabled'} title="${esc(locked ? (item.protection_reason || item.path) : item.path)}">
                                <span class="dmd-folder-file-icon">${locked ? '🔒' : iconFor(item)}</span>
                                <span><strong>${esc(item.name)}</strong><small>${esc(meta)}</small></span>
                            </button>
                            <span class="dmd-folder-row-actions">
                                ${locked && !hasMenu
                                    ? '<span class="dmd-folder-lock" title="' + esc(item.protection_reason || 'Élément protégé') + '">🔒</span>'
                                    : (item.type !== 'link' && hasMenu ? `
                                        <button type="button" class="dmd-folder-more" data-more-item aria-expanded="false" title="Actions">⋮</button>
                                        <span class="dmd-folder-action-menu" hidden>
                                            ${canDownload ? '<button type="button" data-download-item>⬇️ Télécharger</button>' : ''}
                                            ${canRename ? '<button type="button" data-rename-item>✏️ Renommer</button>' : ''}
                                            ${canMove ? '<button type="button" data-move-item>↪️ Déplacer</button>' : ''}
                                            ${canDelete ? '<button type="button" class="dmd-folder-danger" data-delete-item>🗑️ Supprimer</button>' : ''}
                                        </span>
                                    ` : '')}
                            </span>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
        decorateActionHub(state.list);
    }

    async function loadDirectory(state, path) {
        setStatus(state, 'Chargement…', 'info');
        try {
            const data = await state.client.get('list', {path: path || ''});
            state.path = data.path || '';
            if (state.search) state.search.value = '';
            buildBreadcrumb(state);
            renderSidebar(state, data.items || []);
            renderItems(state, data.items || [], false);
            if (data.resource && state.win) {
                state.win.setAttribute('data-dmd-module-id', 'DMD-Folder');
                state.win.setAttribute('data-dmd-context-type', data.resource.type || 'folder');
                state.win.setAttribute('data-dmd-context-id', data.resource.id || '');
                state.win.setAttribute('data-dmd-context-name', data.resource.name || data.root_label || 'DMD-Folder');
                state.win.setAttribute('data-dmd-action-hub', '1');
                decorateActionHub(state.win);
            }
            state.up.disabled = state.path === '';
            setWindowTitle(state.win, 'DMD-Folder — ' + (state.path || data.root_label), state.info.is_admin ? '🛠️' : '📁');
            setStatus(state, (data.items || []).length + ' élément(s) · ' + (data.writable ? 'écriture autorisée' : 'lecture seule'), data.writable ? 'ok' : 'warn');
        } catch (error) {
            setStatus(state, error.message, 'error');
            state.list.innerHTML = '<div class="dmd-folder-empty"><span>⚠️</span><strong>Accès impossible</strong><small>' + esc(error.message) + '</small></div>';
        }
    }

    function itemFromButton(button, state) {
        const row = button.closest('[data-item-path]');
        if (!row) return null;
        return state.items.find(function (item) { return item.path === row.dataset.itemPath; }) || null;
    }

    function download(client, path) {
        const link = document.createElement('a');
        link.href = client.streamUrl(path, true);
        link.download = basename(path);
        document.body.appendChild(link);
        link.click();
        link.remove();
    }

    function showMessage(title, message, icon) {
        const win = createWindow({title: title, icon: icon || 'ℹ️', width: 500, height: 260, className: 'dmd-folder-dialog'});
        const body = win.querySelector('.dmd-folder-window-body');
        body.innerHTML = '<div class="dmd-folder-dialog-content"><p>' + esc(message) + '</p><div class="dmd-folder-dialog-actions"><button type="button" data-ok>OK</button></div></div>';
        body.querySelector('[data-ok]').addEventListener('click', function () { win.remove(); expandDoMyDeskCanvas(); });
        return win;
    }

    function askText(title, label, value, options) {
        options = options || {};
        return new Promise(function (resolve) {
            const win = createWindow({title: title, icon: options.icon || '✏️', width: 520, height: options.multiline ? 390 : 285, className: 'dmd-folder-dialog'});
            const body = win.querySelector('.dmd-folder-window-body');
            body.innerHTML = `
                <form class="dmd-folder-dialog-content">
                    <label><span>${esc(label)}</span>${options.multiline ? '<textarea rows="8"></textarea>' : '<input type="text">'}</label>
                    <div class="dmd-folder-dialog-actions"><button type="button" data-cancel>Annuler</button><button type="submit">Valider</button></div>
                </form>
            `;
            const field = body.querySelector('input, textarea');
            field.value = value || '';
            setTimeout(function () { field.focus(); field.select(); }, 20);
            function close(result) { win.remove(); expandDoMyDeskCanvas(); resolve(result); }
            body.querySelector('[data-cancel]').addEventListener('click', function () { close(null); });
            body.querySelector('form').addEventListener('submit', function (event) {
                event.preventDefault();
                const result = field.value.trim();
                if (!result && !options.allowEmpty) return;
                close(result);
            });
        });
    }

    function askConfirm(title, message, danger) {
        return new Promise(function (resolve) {
            const win = createWindow({title: title, icon: danger ? '⚠️' : '❓', width: 520, height: 285, className: 'dmd-folder-dialog'});
            const body = win.querySelector('.dmd-folder-window-body');
            body.innerHTML = `
                <div class="dmd-folder-dialog-content">
                    <p>${esc(message)}</p>
                    <div class="dmd-folder-dialog-actions"><button type="button" data-no>Annuler</button><button type="button" data-yes class="${danger ? 'dmd-folder-danger' : ''}">Confirmer</button></div>
                </div>
            `;
            function close(result) { win.remove(); expandDoMyDeskCanvas(); resolve(result); }
            body.querySelector('[data-no]').addEventListener('click', function () { close(false); });
            body.querySelector('[data-yes]').addEventListener('click', function () { close(true); });
        });
    }

    async function renameItem(state, item, refreshCallback) {
        const name = await askText('Renommer', 'Nouveau nom', item.name, {icon: '✏️'});
        if (name === null || name === item.name) return;
        try {
            const result = await state.client.post('rename', {path: item.path, name: name});
            setStatus(state, result.message, 'ok');
            if (refreshCallback) refreshCallback(result.path, result.resource || null);
            else loadDirectory(state, state.path);
        } catch (error) {
            showMessage('Renommage impossible', error.message, '⚠️');
        }
    }

    async function moveItem(state, item, refreshCallback) {
        const destination = await askText('Déplacer', 'Dossier de destination depuis la racine', parentPath(item.path), {icon: '↪️'});
        if (destination === null) return;
        try {
            const result = await state.client.post('move', {path: item.path, destination: destination});
            setStatus(state, result.message, 'ok');
            if (refreshCallback) refreshCallback(result.path, result.resource || null);
            else loadDirectory(state, state.path);
        } catch (error) {
            showMessage('Déplacement impossible', error.message, '⚠️');
        }
    }

    async function deleteItem(state, item, refreshCallback) {
        const extra = item.type === 'dir' ? ' Tout son contenu sera supprimé.' : ' Une sauvegarde sera créée si le fichier fait 20 Mo maximum.';
        const ok = await askConfirm('Supprimer ' + item.name, 'Supprimer définitivement « ' + item.path + ' » ?' + extra, true);
        if (!ok) return;
        try {
            const result = await state.client.post('delete', {path: item.path});
            setStatus(state, result.message, 'ok');
            if (refreshCallback) refreshCallback();
            else loadDirectory(state, state.path);
        } catch (error) {
            showMessage('Suppression impossible', error.message, '⚠️');
        }
    }

    async function openFile(state, item) {
        if (item.type === 'dir') {
            if (!can(state, 'folder.list')) return;
            loadDirectory(state, item.path);
            return;
        }
        if (item.type === 'link' || !can(state, 'folder.read')) return;

        const win = createWindow({title: item.name, icon: iconFor(item), width: 920, height: 680, className: 'dmd-folder-viewer'});
        if (item.resource) {
            win.setAttribute('data-dmd-module-id', 'DMD-Folder');
            win.setAttribute('data-dmd-context-type', item.resource.type || 'file');
            win.setAttribute('data-dmd-context-id', item.resource.id || '');
            win.setAttribute('data-dmd-context-name', item.resource.name || item.name);
            win.setAttribute('data-dmd-action-hub', '1');
            decorateActionHub(win);
        }
        const body = win.querySelector('.dmd-folder-window-body');
        body.innerHTML = `
            <div class="dmd-folder-viewer-toolbar">
                <span title="${esc(item.path)}">${esc(item.path)}</span>
                <div>
                    ${can(state, 'folder.download') ? '<button type="button" data-view-download>⬇️ Télécharger</button>' : ''}
                    ${item.protected ? '<span title="' + esc(item.protection_reason || 'Fichier protégé') + '">🔒 Protégé</span>' : (can(state, 'folder.rename') ? '<button type="button" data-view-rename>✏️ Renommer</button>' : '') + (can(state, 'folder.delete') ? '<button type="button" data-view-delete>🗑️ Supprimer</button>' : '')}
                </div>
            </div>
            <div class="dmd-folder-viewer-content"><div class="dmd-folder-loading">Chargement…</div></div>
            <div class="dmd-folder-viewer-status"></div>
        `;
        const content = body.querySelector('.dmd-folder-viewer-content');
        const status = body.querySelector('.dmd-folder-viewer-status');
        let currentItem = Object.assign({}, item);
        let dirty = false;

        const viewDownload = body.querySelector('[data-view-download]');
        if (viewDownload) viewDownload.addEventListener('click', function () { download(state.client, currentItem.path); });
        const viewRename = body.querySelector('[data-view-rename]');
        if (viewRename) viewRename.addEventListener('click', function () {
            renameItem(state, currentItem, function (newPath, newResource) {
                if (!newPath) return;
                currentItem.path = newPath;
                currentItem.name = basename(newPath);
                if (newResource) currentItem.resource = newResource;
                setWindowTitle(win, currentItem.name, iconFor(currentItem));
                body.querySelector('.dmd-folder-viewer-toolbar > span').textContent = newPath;
                if (currentItem.resource) {
                    win.setAttribute('data-dmd-context-type', currentItem.resource.type || 'file');
                    win.setAttribute('data-dmd-context-id', currentItem.resource.id || '');
                    win.setAttribute('data-dmd-context-name', currentItem.resource.name || currentItem.name);
                    decorateActionHub(win);
                }
                loadDirectory(state, state.path);
            });
        });
        const viewDelete = body.querySelector('[data-view-delete]');
        if (viewDelete) viewDelete.addEventListener('click', function () {
            deleteItem(state, currentItem, function () {
                win.remove();
                expandDoMyDeskCanvas();
                loadDirectory(state, state.path);
            });
        });

        if (item.preview === 'text') {
            try {
                const data = await state.client.get('read', {path: item.path});
                content.innerHTML = `
                    <textarea class="dmd-folder-editor" spellcheck="false" aria-label="Contenu du fichier"></textarea>
                    <div class="dmd-folder-editor-actions"><button type="button" data-save-file ${(data.writable && can(state, 'folder.edit')) ? '' : 'disabled'}>💾 Enregistrer</button></div>
                `;
                const editor = content.querySelector('textarea');
                const save = content.querySelector('[data-save-file]');
                editor.value = data.content;
                editor.readOnly = !data.writable || !can(state, 'folder.edit');
                status.textContent = (data.writable && can(state, 'folder.edit')) ? 'Édition autorisée · sauvegarde persistante avant écrasement' : (data.protection_reason || 'Fichier en lecture seule');
                editor.addEventListener('input', function () {
                    dirty = true;
                    status.textContent = 'Modifications non enregistrées';
                    status.dataset.kind = 'warn';
                });
                editor.addEventListener('keydown', function (event) {
                    if (event.key === 'Tab') {
                        event.preventDefault();
                        const start = editor.selectionStart;
                        const end = editor.selectionEnd;
                        editor.value = editor.value.slice(0, start) + '    ' + editor.value.slice(end);
                        editor.selectionStart = editor.selectionEnd = start + 4;
                        editor.dispatchEvent(new Event('input'));
                    }
                    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
                        event.preventDefault();
                        save.click();
                    }
                });
                save.addEventListener('click', async function () {
                    save.disabled = true;
                    status.textContent = 'Enregistrement…';
                    status.dataset.kind = 'info';
                    try {
                        const result = await state.client.post('save', {path: currentItem.path, content: editor.value});
                        dirty = false;
                        status.textContent = result.message;
                        status.dataset.kind = 'ok';
                        loadDirectory(state, state.path);
                    } catch (error) {
                        status.textContent = error.message;
                        status.dataset.kind = 'error';
                    } finally {
                        save.disabled = !data.writable || !can(state, 'folder.edit');
                    }
                });
                win.querySelector('[data-window-close]').addEventListener('click', function (event) {
                    if (dirty && !window.confirm('Fermer sans enregistrer les modifications ?')) {
                        event.stopImmediatePropagation();
                    }
                }, true);
            } catch (error) {
                content.innerHTML = '<div class="dmd-folder-empty"><span>⚠️</span><strong>Lecture impossible</strong><small>' + esc(error.message) + '</small></div>';
            }
            return;
        }

        const url = state.client.streamUrl(item.path, false);
        if (item.preview === 'image') {
            content.innerHTML = '<div class="dmd-folder-image-wrap"><img src="' + esc(url) + '" alt="' + esc(item.name) + '"></div>';
        } else if (item.preview === 'pdf') {
            content.innerHTML = '<iframe class="dmd-folder-preview-frame" src="' + esc(url) + '" title="' + esc(item.name) + '"></iframe>';
        } else if (item.preview === 'audio') {
            content.innerHTML = '<div class="dmd-folder-media-wrap"><audio controls src="' + esc(url) + '"></audio></div>';
        } else if (item.preview === 'video') {
            content.innerHTML = '<div class="dmd-folder-media-wrap"><video controls src="' + esc(url) + '"></video></div>';
        } else {
            content.innerHTML = '<div class="dmd-folder-empty"><span>📦</span><strong>Aperçu indisponible</strong><small>' + (can(state, 'folder.download') ? 'Télécharge le fichier pour l’ouvrir avec l’application adaptée.' : 'Aucun aperçu disponible avec tes droits actuels.') + '</small>' + (can(state, 'folder.download') ? '<button type="button" data-binary-download>⬇️ Télécharger</button>' : '') + '</div>';
            const binaryDownload = content.querySelector('[data-binary-download]');
            if (binaryDownload) binaryDownload.addEventListener('click', function () { download(state.client, item.path); });
        }
        status.textContent = item.size_label + ' · ' + (item.mime || 'type inconnu');
    }

    function formatLogWhen(value) {
        if (!value) return '';
        const date = new Date(value);
        return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString();
    }

    function renderLogRows(container, entries) {
        if (!entries.length) {
            container.innerHTML = '<div class="dmd-folder-empty"><span>📋</span><strong>Journal vide</strong><small>Aucune entrée pour cette période.</small></div>';
            return;
        }
        container.innerHTML = entries.map(function (entry) {
            const resource = entry.resource || {};
            const details = entry.details && Object.keys(entry.details).length ? JSON.stringify(entry.details) : '';
            return `<article class="dmd-folder-log-row">
                <div class="dmd-folder-log-main"><strong>${esc(entry.action || 'action')}</strong><span>${esc(entry.target || resource.name || '')}</span></div>
                <div class="dmd-folder-log-meta"><span>${esc(formatLogWhen(entry.timestamp))}</span><span>${esc(entry.user || '')}</span><span data-result="${esc(entry.result || '')}">${esc(entry.result || '')}</span></div>
                ${details ? '<code>' + esc(details) + '</code>' : ''}
            </article>`;
        }).join('');
    }

    function printLogs(entries, month) {
        const frame = document.createElement('iframe');
        frame.className = 'dmd-folder-print-frame';
        frame.setAttribute('aria-hidden', 'true');
        document.body.appendChild(frame);
        const doc = frame.contentDocument;
        if (!doc) { frame.remove(); return; }
        doc.open();
        doc.write('<!doctype html><html><head><meta charset="utf-8"><title>DMD-Folder - Journal ' + esc(month) + '</title></head><body>');
        doc.write('<h1>DMD-Folder - Journal ' + esc(month) + '</h1>');
        doc.write('<table border="1" cellspacing="0" cellpadding="6"><thead><tr><th>Date</th><th>Utilisateur</th><th>Action</th><th>Cible</th><th>Résultat</th></tr></thead><tbody>');
        entries.forEach(function (entry) {
            doc.write('<tr><td>' + esc(formatLogWhen(entry.timestamp)) + '</td><td>' + esc(entry.user || '') + '</td><td>' + esc(entry.action || '') + '</td><td>' + esc(entry.target || '') + '</td><td>' + esc(entry.result || '') + '</td></tr>');
        });
        doc.write('</tbody></table></body></html>');
        doc.close();
        setTimeout(function () {
            try { frame.contentWindow.focus(); frame.contentWindow.print(); } catch (error) {}
            setTimeout(function () { frame.remove(); }, 500);
        }, 50);
    }

    async function openJournal(state) {
        const win = createWindow({title: 'DMD-Folder — Journal', icon: '📋', width: 980, height: 650, className: 'dmd-folder-journal'});
        const body = win.querySelector('.dmd-folder-window-body');
        body.innerHTML = `
            <div class="dmd-folder-journal-toolbar">
                <label><span>Mois</span><select data-log-month></select></label>
                <button type="button" data-log-refresh>🔄 Actualiser</button>
                ${can(state, 'logs.export') ? '<button type="button" data-log-export>⬇️ CSV</button>' : ''}
                <button type="button" data-log-print>🖨️ Imprimer / PDF</button>
                ${can(state, 'logs.delete') ? '<button type="button" class="dmd-folder-danger" data-log-clear>🗑️ Vider</button>' : ''}
            </div>
            <div class="dmd-folder-log-list"><div class="dmd-folder-loading">Chargement…</div></div>
            <footer class="dmd-folder-viewer-status" data-log-status></footer>`;
        const select = body.querySelector('[data-log-month]');
        const list = body.querySelector('.dmd-folder-log-list');
        const status = body.querySelector('[data-log-status]');
        let entries = [];

        async function load(month) {
            status.textContent = 'Chargement du journal…';
            try {
                const result = await state.client.get('logs_list', {month: month || select.value || ''});
                entries = result.entries || [];
                const current = result.month || month || '';
                select.innerHTML = (result.months || [current]).map(function (item) {
                    return '<option value="' + esc(item) + '"' + (item === current ? ' selected' : '') + '>' + esc(item) + '</option>';
                }).join('');
                renderLogRows(list, entries);
                status.textContent = entries.length + ' entrée(s) affichée(s).';
            } catch (error) {
                status.textContent = error.message;
                status.dataset.kind = 'error';
            }
        }

        select.addEventListener('change', function () { load(select.value); });
        body.querySelector('[data-log-refresh]').addEventListener('click', function () { load(select.value); });
        const exportButton = body.querySelector('[data-log-export]');
        if (exportButton) exportButton.addEventListener('click', function () {
            const link = document.createElement('a');
            link.href = state.client.logsExportUrl(select.value);
            link.download = 'DMD-Folder-logs-' + select.value + '.csv';
            document.body.appendChild(link); link.click(); link.remove();
        });
        body.querySelector('[data-log-print]').addEventListener('click', function () { printLogs(entries, select.value); });
        const clearButton = body.querySelector('[data-log-clear]');
        if (clearButton) clearButton.addEventListener('click', async function () {
            const ok = await askConfirm('Vider le journal', 'Supprimer les entrées du mois ' + select.value + ' ? Cette action sera elle-même journalisée.', true);
            if (!ok) return;
            try {
                const result = await state.client.post('logs_clear', {month: select.value});
                status.textContent = result.message;
                await load(select.value);
            } catch (error) { showMessage('Journal', error.message, '⚠️'); }
        });
        await load('');
    }

    async function openExplorer(root) {
        const client = createClient(root);
        const info = await client.ensureInfo();
        const inline = root.dataset.folderInline === '1';
        const win = inline ? root : createWindow({
            title: info.is_admin ? 'DMD-Folder — Administration' : 'DMD-Folder — Mes fichiers',
            icon: info.is_admin ? '🛠️' : '📁',
            width: 1180,
            height: 740,
            className: 'dmd-folder-explorer'
        });
        const body = inline ? root : win.querySelector('.dmd-folder-window-body');
        if (inline) {
            root.classList.add('dmd-folder-inline', 'dmd-folder-explorer');
        }
        body.innerHTML = `
            <div class="dmd-folder-toolbar">
                <button type="button" data-up title="Dossier parent">⬆️</button>
                <button type="button" data-refresh title="Actualiser">🔄</button>
                <div class="dmd-folder-breadcrumb"></div>
                ${can({info: info}, 'folder.search') ? '<label class="dmd-folder-search"><span>🔎</span><input type="search" placeholder="Rechercher un fichier"></label>' : '<span class="dmd-folder-search dmd-folder-search-disabled">Recherche non autorisée</span>'}
            </div>
            <div class="dmd-folder-commandbar">
                ${can({info: info}, 'folder.create') ? '<button type="button" data-new-file>📄 Nouveau fichier</button><button type="button" data-new-folder>📁 Nouveau dossier</button>' : ''}
                ${can({info: info}, 'folder.upload') ? '<button type="button" data-upload>⬆️ Importer</button><input type="file" data-upload-input multiple hidden>' : ''}
                ${can({info: info}, 'logs.view') ? '<button type="button" data-open-logs>📋 Journal</button>' : ''}
                <span class="dmd-folder-mode">${info.is_admin ? '🛡️ Racine complète DoMyDesk' : '🔒 Dossier utilisateur'}</span>
            </div>
            <div class="dmd-folder-layout">
                <main class="dmd-folder-list"></main>
            </div>
            <footer class="dmd-folder-status"></footer>
        `;

        const state = {
            root, client, info, win, path: '', items: [],
            up: body.querySelector('[data-up]'),
            breadcrumb: body.querySelector('.dmd-folder-breadcrumb'),
            sidebar: body.querySelector('.dmd-folder-sidebar'),
            list: body.querySelector('.dmd-folder-list'),
            status: body.querySelector('.dmd-folder-status'),
            search: body.querySelector('.dmd-folder-search input')
        };
        if (info.root_resource && win) {
            win.setAttribute('data-dmd-module-id', 'DMD-Folder');
            win.setAttribute('data-dmd-context-type', info.root_resource.type || 'folder');
            win.setAttribute('data-dmd-context-id', info.root_resource.id || '');
            win.setAttribute('data-dmd-context-name', info.root_resource.name || info.root_label || 'DMD-Folder');
            win.setAttribute('data-dmd-action-hub', '1');
            decorateActionHub(win);
        }

        state.up.addEventListener('click', function () { loadDirectory(state, parentPath(state.path)); });
        body.querySelector('[data-refresh]').addEventListener('click', function () { loadDirectory(state, state.path); });
        state.breadcrumb.addEventListener('click', function (event) {
            const button = event.target.closest('[data-breadcrumb]');
            if (button) loadDirectory(state, button.dataset.breadcrumb || '');
        });
        if (state.sidebar) {
            state.sidebar.addEventListener('click', function (event) {
                const button = event.target.closest('[data-side-path]');
                if (button) loadDirectory(state, button.dataset.sidePath || '');
            });
        }

        let searchTimer = null;
        if (state.search) state.search.addEventListener('input', function () {
            clearTimeout(searchTimer);
            const query = state.search.value.trim();
            if (query.length < 2) {
                if (query.length === 0) loadDirectory(state, state.path);
                return;
            }
            searchTimer = setTimeout(async function () {
                setStatus(state, 'Recherche…', 'info');
                try {
                    const result = await client.get('search', {path: state.path, q: query});
                    renderItems(state, result.items || [], true);
                    setStatus(state, (result.items || []).length + ' résultat(s) pour « ' + query + ' »', 'ok');
                } catch (error) {
                    setStatus(state, error.message, 'error');
                }
            }, 350);
        });

        const newFileButton = body.querySelector('[data-new-file]');
        if (newFileButton) newFileButton.addEventListener('click', async function () {
            const name = await askText('Nouveau fichier', 'Nom du fichier', 'nouveau-fichier.txt', {icon: '📄'});
            if (name === null) return;
            try {
                const result = await client.post('create_file', {path: state.path, name: name, content: ''});
                setStatus(state, result.message, 'ok');
                await loadDirectory(state, state.path);
                const created = state.items.find(function (item) { return item.path === result.path; });
                if (created && can(state, 'folder.read')) openFile(state, created);
            } catch (error) { showMessage('Création impossible', error.message, '⚠️'); }
        });

        const newFolderButton = body.querySelector('[data-new-folder]');
        if (newFolderButton) newFolderButton.addEventListener('click', async function () {
            const name = await askText('Nouveau dossier', 'Nom du dossier', 'Nouveau dossier', {icon: '📁'});
            if (name === null) return;
            try {
                const result = await client.post('mkdir', {path: state.path, name: name});
                setStatus(state, result.message, 'ok');
                loadDirectory(state, state.path);
            } catch (error) { showMessage('Création impossible', error.message, '⚠️'); }
        });

        const uploadInput = body.querySelector('[data-upload-input]');
        const uploadButton = body.querySelector('[data-upload]');
        if (uploadButton && uploadInput) uploadButton.addEventListener('click', function () { uploadInput.click(); });
        if (uploadInput) uploadInput.addEventListener('change', async function () {
            const files = Array.from(uploadInput.files || []);
            if (!files.length) return;
            setStatus(state, 'Import de ' + files.length + ' fichier(s)…', 'info');
            try {
                const result = await client.post('upload', {path: state.path}, files);
                setStatus(state, result.message, 'ok');
                loadDirectory(state, state.path);
            } catch (error) {
                setStatus(state, error.message, 'error');
                showMessage('Import impossible', error.message, '⚠️');
            } finally {
                uploadInput.value = '';
            }
        });

        const logsButton = body.querySelector('[data-open-logs]');
        if (logsButton) logsButton.addEventListener('click', function () { openJournal(state); });

        state.list.addEventListener('dblclick', function (event) {
            const row = event.target.closest('[data-item-path]');
            if (!row) return;
            const item = state.items.find(function (entry) { return entry.path === row.dataset.itemPath; });
            if (item && ((item.type === 'dir' && can(state, 'folder.list')) || (item.type !== 'dir' && can(state, 'folder.read')))) openFile(state, item);
        });

        state.list.addEventListener('click', function (event) {
            const moreButton = event.target.closest('[data-more-item]');
            if (moreButton) {
                event.stopPropagation();
                const menu = moreButton.parentElement.querySelector('.dmd-folder-action-menu');
                state.list.querySelectorAll('.dmd-folder-action-menu').forEach(function (other) {
                    if (other !== menu) other.hidden = true;
                });
                state.list.querySelectorAll('[data-more-item]').forEach(function (other) {
                    if (other !== moreButton) other.setAttribute('aria-expanded', 'false');
                });
                const willOpen = menu ? menu.hidden : false;
                if (menu) menu.hidden = !willOpen;
                moreButton.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
                return;
            }

            const openButton = event.target.closest('[data-open-item]');
            const downloadButton = event.target.closest('[data-download-item]');
            const renameButton = event.target.closest('[data-rename-item]');
            const moveButton = event.target.closest('[data-move-item]');
            const deleteButton = event.target.closest('[data-delete-item]');
            const actionButton = openButton || downloadButton || renameButton || moveButton || deleteButton;
            if (!actionButton) return;
            const item = itemFromButton(actionButton, state);
            if (!item) return;
            const menu = actionButton.closest('.dmd-folder-action-menu');
            if (menu) menu.hidden = true;
            if (openButton) openFile(state, item);
            else if (downloadButton) download(client, item.path);
            else if (renameButton) renameItem(state, item);
            else if (moveButton) moveItem(state, item);
            else if (deleteButton) deleteItem(state, item);
        });

        document.addEventListener('click', function (event) {
            if (event.target.closest('.dmd-folder-row-actions')) return;
            state.list.querySelectorAll('.dmd-folder-action-menu').forEach(function (menu) { menu.hidden = true; });
            state.list.querySelectorAll('[data-more-item]').forEach(function (button) { button.setAttribute('aria-expanded', 'false'); });
        });

        await loadDirectory(state, '');
    }

    function initRoot(root) {
        if (!root || root.dataset.folderReady === '1') return;
        root.dataset.folderReady = '1';

        if (root.dataset.folderInline === '1') {
            openExplorer(root).catch(function (error) {
                root.innerHTML = '<div class="dmd-folder-inline-error"><strong>⚠️ DMD-Folder indisponible</strong><span>' + esc(error.message) + '</span></div>';
            });
            return;
        }

        const button = root.querySelector('[data-folder-launch]');
        if (!button) return;
        button.addEventListener('click', function () {
            openExplorer(root).catch(function (error) {
                showMessage('DMD-Folder', error.message, '⚠️');
            });
        });
    }

    function initAll() {
        document.querySelectorAll('[data-dmd-folder]').forEach(initRoot);
    }

    window.DMDFolder = {initAll: initAll, openExplorer: openExplorer};
    initAll();
})();
