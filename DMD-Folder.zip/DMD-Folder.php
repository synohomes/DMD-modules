<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
require_once __DIR__ . '/DMD-Folder-lib.php';

if (!dmdfolder_has_permission('module.view')) {
    echo '<section class="dmd-folder-denied">⛔ Accès à DMD-Folder refusé.</section>';
    return;
}

$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-Folder';
$normalizedModule = str_replace('\\', '/', $moduleRealDir);
$normalizedDocumentRoot = rtrim(str_replace('\\', '/', $documentRoot), '/');
if ($normalizedDocumentRoot !== '' && strpos($normalizedModule, $normalizedDocumentRoot . '/') === 0) {
    $moduleWebPath = '/' . ltrim(substr($normalizedModule, strlen($normalizedDocumentRoot)), '/');
}
$build = '121';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>/DMD-Folder.css?v=<?= $build ?>">
<section class="dmd-folder-inline dmd-folder-explorer"
         data-dmd-folder
         data-folder-inline="1"
         data-module-url="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>"
         data-dmd-module-id="DMD-Folder"
         data-dmd-module-name="DMD-Folder"
         aria-label="DMD-Folder">
    <div class="dmd-folder-inline-loading">Chargement de DMD-Folder…</div>
</section>
<script src="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>/DMD-Folder.js?v=<?= $build ?>"></script>
