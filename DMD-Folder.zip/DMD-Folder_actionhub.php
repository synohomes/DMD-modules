<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */


declare(strict_types=1);

require_once __DIR__ . '/DMD-Folder-lib.php';

if (!function_exists('dmdfolder_actionhub_result')) {
    function dmdfolder_actionhub_result(bool $ok, string $message, array $data = [], string $error = ''): array
    {
        $result = [
            'ok' => $ok,
            'message' => $message,
            'data' => array_merge(['module' => DMDFOLDER_MODULE_ID], $data),
        ];
        if (!$ok && $error !== '') $result['error'] = $error;
        return $result;
    }
}

if (!function_exists('dmdfolder_actionhub_require_actor')) {
    function dmdfolder_actionhub_require_actor(string $email): void
    {
        $email = strtolower(trim($email));
        $current = strtolower(dmdfolder_current_email());
        if ($email === '' || !hash_equals($current, $email)) {
            throw new RuntimeException('Contexte ActionHub invalide.');
        }
        dmdfolder_require_permission('module.view');
    }
}

if (!function_exists('dmdfolder_actionhub_permission_for')) {
    function dmdfolder_actionhub_permission_for(string $actionId): ?string
    {
        $map = [
            'file.download' => 'folder.download',
            'resource.rename' => 'folder.rename',
            'resource.move' => 'folder.move',
            'resource.delete' => 'folder.delete',
            'folder.create' => 'folder.create',
            'file.create_text' => 'folder.create',
            'file.write_text' => 'folder.edit',
            'resource.assert_exists' => 'folder.list',
            'resource.rename_path' => 'folder.rename',
            'resource.move_path' => 'folder.move',
            'resource.delete_path' => 'folder.delete',
        ];
        return $map[$actionId] ?? null;
    }
}

if (!function_exists('dmdfolder_actionhub_resolve_context_resource')) {
    function dmdfolder_actionhub_resolve_context_resource(array $resource): array
    {
        $resourceId = trim((string)($resource['id'] ?? ''));
        if ($resourceId === '') throw new RuntimeException('Ressource ActionHub manquante.');
        return dmdfolder_resolve_resource($resourceId);
    }
}

if (!function_exists('dmdfolder_actionhub_create_folder')) {
    function dmdfolder_actionhub_create_folder(array $payload): array
    {
        [$target, $relative, $access] = dmdfolder_new_path(dmdfolder_actionhub_payload_path((string)($payload['parent_path'] ?? '')), (string)($payload['name'] ?? ''));
        dmdfolder_assert_mutation_allowed($relative, false, $access);
        if (!@mkdir($target, 0775, false)) throw new RuntimeException('Création du dossier impossible.');
        $resource = dmdfolder_resource($relative, 'folder', basename($target), $access);
        $affected = dmdfolder_affected_emails($relative, $access);
        dmdfolder_audit('mkdir', $relative, $resource, ['source' => 'actionhub_scenario'], $affected, true, true);
        return dmdfolder_actionhub_result(true, 'Dossier « ' . basename($target) . ' » créé.', [
            'reload' => true,
            'path' => $relative,
            'resource' => $resource,
        ]);
    }
}

if (!function_exists('dmdfolder_actionhub_create_text_file')) {
    function dmdfolder_actionhub_create_text_file(array $payload): array
    {
        [$target, $relative, $access] = dmdfolder_new_path(dmdfolder_actionhub_payload_path((string)($payload['parent_path'] ?? '')), (string)($payload['name'] ?? ''));
        dmdfolder_assert_mutation_allowed($relative, true, $access);
        $content = (string)($payload['content'] ?? '');
        if (strlen($content) > 2 * 1024 * 1024) throw new RuntimeException('Le contenu dépasse 2 Mo.');
        if (@file_put_contents($target, $content, LOCK_EX) === false) throw new RuntimeException('Création du fichier impossible.');
        @chmod($target, 0664);
        $resource = dmdfolder_resource($relative, 'file', basename($target), $access);
        $affected = dmdfolder_affected_emails($relative, $access);
        dmdfolder_audit('create_file', $relative, $resource, [
            'bytes' => strlen($content),
            'source' => 'actionhub_scenario',
        ], $affected, true, true);
        return dmdfolder_actionhub_result(true, 'Fichier « ' . basename($target) . ' » créé.', [
            'reload' => true,
            'path' => $relative,
            'resource' => $resource,
        ]);
    }
}

if (!function_exists('dmdfolder_actionhub_write_text')) {
    function dmdfolder_actionhub_write_text(array $payload): array
    {
        [$file, $relative, $access] = dmdfolder_existing_path(dmdfolder_actionhub_payload_path((string)($payload['path'] ?? '')), 'file');
        dmdfolder_assert_mutation_allowed($relative, true, $access);
        $mime = dmdfolder_mime($file);
        if (!dmdfolder_is_text_file($file, $mime)) throw new RuntimeException('Ce fichier n’est pas éditable comme texte.');
        $content = (string)($payload['content'] ?? '');
        if (strlen($content) > 2 * 1024 * 1024) throw new RuntimeException('Le contenu dépasse 2 Mo.');
        $backup = dmdfolder_backup_file($file, $relative, 'actionhub-save');
        if (@file_put_contents($file, $content, LOCK_EX) === false) throw new RuntimeException('Enregistrement impossible.');
        $resource = dmdfolder_resource($relative, 'file', basename($file), $access);
        $affected = dmdfolder_affected_emails($relative, $access);
        dmdfolder_audit('save', $relative, $resource, [
            'bytes' => strlen($content),
            'backup_created' => $backup !== null,
            'source' => 'actionhub_scenario',
        ], $affected, true, true);
        return dmdfolder_actionhub_result(true, 'Fichier « ' . basename($file) . ' » enregistré.', [
            'reload' => true,
            'path' => $relative,
            'resource' => $resource,
        ]);
    }
}

if (!function_exists('dmdfolder_actionhub_rename')) {
    function dmdfolder_actionhub_rename(string $path, string $newName, string $source): array
    {
        $path = dmdfolder_actionhub_payload_path($path);
        [$absolute, $relative, $access] = dmdfolder_existing_path($path);
        if ($relative === '') throw new RuntimeException('La racine ne peut pas être renommée.');
        $isFile = is_file($absolute);
        dmdfolder_assert_mutation_allowed($relative, $isFile, $access);
        $newName = dmdfolder_validate_name($newName);
        $target = dirname($absolute) . '/' . $newName;
        if (file_exists($target) || is_link($target)) throw new RuntimeException('Un élément porte déjà ce nom.');
        $newRelative = dmdfolder_relative_from_absolute(str_replace('\\', '/', $target), $access['root']);
        dmdfolder_assert_mutation_allowed($newRelative, $isFile, $access);
        $backup = $isFile ? dmdfolder_backup_file($absolute, $relative, 'actionhub-rename') : null;
        if (!@rename($absolute, $target)) throw new RuntimeException('Renommage impossible.');
        $resource = dmdfolder_resource($newRelative, $isFile ? 'file' : 'folder', $newName, $access);
        $affected = array_values(array_unique(array_merge(
            dmdfolder_affected_emails($relative, $access),
            dmdfolder_affected_emails($newRelative, $access)
        )));
        dmdfolder_audit('rename', $newRelative, $resource, [
            'from' => $relative,
            'backup_created' => $backup !== null,
            'source' => $source,
        ], $affected, true, true);
        return dmdfolder_actionhub_result(true, 'Élément renommé en « ' . $newName . ' ».', [
            'reload' => true,
            'path' => $newRelative,
            'resource' => $resource,
        ]);
    }
}

if (!function_exists('dmdfolder_actionhub_move')) {
    function dmdfolder_actionhub_move(string $path, string $destination, string $source): array
    {
        $path = dmdfolder_actionhub_payload_path($path);
        $destination = dmdfolder_actionhub_payload_path($destination);
        [$absolute, $relative, $access] = dmdfolder_existing_path($path);
        if ($relative === '') throw new RuntimeException('La racine ne peut pas être déplacée.');
        $isFile = is_file($absolute);
        dmdfolder_assert_mutation_allowed($relative, $isFile, $access);
        [$destinationDir] = dmdfolder_existing_path($destination, 'dir');
        $target = $destinationDir . '/' . basename($absolute);
        if (file_exists($target) || is_link($target)) throw new RuntimeException('Un élément du même nom existe déjà dans la destination.');
        if (!$isFile && dmdfolder_is_inside($destinationDir, $absolute)) throw new RuntimeException('Impossible de déplacer un dossier dans lui-même.');
        if (!dmdfolder_is_inside($target, $access['root'])) throw new RuntimeException('Destination refusée.');
        $targetRelative = dmdfolder_relative_from_absolute(str_replace('\\', '/', $target), $access['root']);
        dmdfolder_assert_mutation_allowed($targetRelative, $isFile, $access);
        $backup = $isFile ? dmdfolder_backup_file($absolute, $relative, 'actionhub-move') : null;
        if (!@rename($absolute, $target)) throw new RuntimeException('Déplacement impossible.');
        $resource = dmdfolder_resource($targetRelative, $isFile ? 'file' : 'folder', basename($target), $access);
        $affected = array_values(array_unique(array_merge(
            dmdfolder_affected_emails($relative, $access),
            dmdfolder_affected_emails($targetRelative, $access)
        )));
        dmdfolder_audit('move', $targetRelative, $resource, [
            'from' => $relative,
            'backup_created' => $backup !== null,
            'source' => $source,
        ], $affected, true, true);
        return dmdfolder_actionhub_result(true, 'Élément déplacé.', [
            'reload' => true,
            'path' => $targetRelative,
            'resource' => $resource,
        ]);
    }
}

if (!function_exists('dmdfolder_actionhub_delete')) {
    function dmdfolder_actionhub_delete(string $path, string $source): array
    {
        $path = dmdfolder_actionhub_payload_path($path);
        [$absolute, $relative, $access] = dmdfolder_existing_path($path);
        if ($relative === '') throw new RuntimeException('La racine ne peut pas être supprimée.');
        $isFile = is_file($absolute);
        dmdfolder_assert_mutation_allowed($relative, $isFile, $access);
        $resource = dmdfolder_resource($relative, $isFile ? 'file' : 'folder', basename($absolute), $access);
        $affected = dmdfolder_affected_emails($relative, $access);
        $backup = $isFile ? dmdfolder_backup_file($absolute, $relative, 'actionhub-delete') : null;
        dmdfolder_delete_tree($absolute);
        dmdfolder_audit('delete', $relative, $resource, [
            'backup_created' => $backup !== null,
            'source' => $source,
        ], $affected, true, true);
        return dmdfolder_actionhub_result(true, 'Élément supprimé.', [
            'reload' => true,
            'deleted' => true,
            'path' => $relative,
            'resource' => $resource,
        ]);
    }
}

if (!defined('DMDFOLDER_ACTIONHUB_ROOT_VALUE')) {
    define('DMDFOLDER_ACTIONHUB_ROOT_VALUE', '@root');
}

if (!function_exists('dmdfolder_actionhub_payload_path')) {
    function dmdfolder_actionhub_payload_path(string $value): string
    {
        $value = trim($value);
        if ($value === DMDFOLDER_ACTIONHUB_ROOT_VALUE) return '';
        return dmdfolder_normalize_relative($value, true);
    }
}

if (!function_exists('dmdfolder_actionhub_path_option')) {
    function dmdfolder_actionhub_path_option(string $relative, string $type, array $access): array
    {
        $relative = dmdfolder_normalize_relative($relative, true);
        if ($relative === '') {
            return [
                'value' => DMDFOLDER_ACTIONHUB_ROOT_VALUE,
                'label' => '📁 Racine — ' . (string)($access['label'] ?? 'DMD-Folder'),
            ];
        }
        return [
            'value' => $relative,
            'label' => ($type === 'folder' ? '📁 ' : '📄 ') . $relative,
        ];
    }
}

if (!function_exists('dmdfolder_actionhub_sort_options')) {
    function dmdfolder_actionhub_sort_options(array $options, bool $keepRootFirst = false): array
    {
        $root = null;
        $items = [];
        $seen = [];
        foreach ($options as $option) {
            if (!is_array($option)) continue;
            $value = (string)($option['value'] ?? '');
            if ($value === '' || isset($seen[$value])) continue;
            $seen[$value] = true;
            if ($keepRootFirst && $value === DMDFOLDER_ACTIONHUB_ROOT_VALUE) {
                $root = $option;
                continue;
            }
            $items[] = $option;
        }
        usort($items, static function (array $a, array $b): int {
            return strnatcasecmp((string)($a['label'] ?? ''), (string)($b['label'] ?? ''));
        });
        if (count($items) > 299) $items = array_slice($items, 0, 299);
        if ($root !== null) array_unshift($items, $root);
        return $items;
    }
}

if (!function_exists('dmdfolder_actionhub_text_path_hint')) {
    function dmdfolder_actionhub_text_path_hint(string $relative): bool
    {
        $name = strtolower(basename($relative));
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if ($ext === '' && in_array($name, ['dockerfile', 'makefile', '.env', '.gitignore', '.htaccess'], true)) return true;
        return in_array($ext, [
            'txt','md','markdown','log','json','xml','yaml','yml','ini','conf','cfg','csv','tsv',
            'php','phtml','html','htm','css','scss','less','js','mjs','cjs','ts','tsx','jsx',
            'sql','sh','bash','zsh','cmd','bat','ps1','py','rb','go','java','c','h','cpp','hpp',
            'vue','svelte','twig','env'
        ], true);
    }
}

if (!function_exists('dmdfolder_actionhub_catalog_add')) {
    function dmdfolder_actionhub_catalog_add(array &$bucket, string $relative, string $type, array $access): void
    {
        if (count($bucket) >= 300) return;
        try {
            $relative = dmdfolder_normalize_relative($relative, true);
            if ($relative !== '' && strlen($relative) > 120) return; // limite du contrat ActionHub 1.2.0
            if ($relative !== '' && dmdfolder_is_protected_path($relative, $access) && empty($access['is_admin'])) return;
            if ($type === 'file' && dmdfolder_is_forbidden_user_file($relative, $access) && empty($access['is_admin'])) return;
            $option = dmdfolder_actionhub_path_option($relative, $type, $access);
            $value = (string)$option['value'];
            foreach ($bucket as $existing) {
                if (is_array($existing) && (string)($existing['value'] ?? '') === $value) return;
            }
            $bucket[] = $option;
        } catch (Throwable $ignored) {}
    }
}

if (!function_exists('dmdfolder_actionhub_catalog_add_parents')) {
    function dmdfolder_actionhub_catalog_add_parents(array &$folders, array &$writableFolders, string $relative, array $access): void
    {
        try {
            $relative = dmdfolder_normalize_relative($relative, true);
            if ($relative === '') return;
            $parts = explode('/', $relative);
            array_pop($parts);
            $cursor = '';
            foreach ($parts as $part) {
                $cursor = $cursor === '' ? $part : $cursor . '/' . $part;
                dmdfolder_actionhub_catalog_add($folders, $cursor, 'folder', $access);
                dmdfolder_actionhub_catalog_add($writableFolders, $cursor, 'folder', $access);
            }
        } catch (Throwable $ignored) {}
    }
}

if (!function_exists('dmdfolder_actionhub_path_catalog_data')) {
    function dmdfolder_actionhub_path_catalog_data(): array
    {
        $access = dmdfolder_access_root();
        $root = (string)$access['root'];

        $all = [];
        $folders = [];
        $writableFolders = [];
        $mutable = [];
        $textFiles = [];

        dmdfolder_actionhub_catalog_add($all, '', 'folder', $access);
        dmdfolder_actionhub_catalog_add($folders, '', 'folder', $access);
        dmdfolder_actionhub_catalog_add($writableFolders, '', 'folder', $access);
        try {
            $count = 0;
            $iterator = new FilesystemIterator($root, FilesystemIterator::SKIP_DOTS | FilesystemIterator::CURRENT_AS_FILEINFO);
            foreach ($iterator as $item) {
                if (++$count > 200) break;
                if (!$item instanceof SplFileInfo || $item->isLink()) continue;
                $name = $item->getFilename();
                if ($name === '' || $name === '.' || $name === '..') continue;
                $relative = dmdfolder_normalize_relative($name, false);
                $isDir = $item->isDir();
                $type = $isDir ? 'folder' : 'file';
                $reason = dmdfolder_protection_reason($relative, !$isDir, $access);
                if ($reason !== '' && empty($access['is_admin'])) continue;

                dmdfolder_actionhub_catalog_add($all, $relative, $type, $access);
                dmdfolder_actionhub_catalog_add($mutable, $relative, $type, $access);
                if ($isDir) {
                    dmdfolder_actionhub_catalog_add($folders, $relative, 'folder', $access);
                    dmdfolder_actionhub_catalog_add($writableFolders, $relative, 'folder', $access);
                } elseif (dmdfolder_actionhub_text_path_hint($relative)) {
                    dmdfolder_actionhub_catalog_add($textFiles, $relative, 'file', $access);
                }
            }
        } catch (Throwable $ignored) {
            
        }
        try {
            $viewerKey = dmdfolder_resource_viewer_key();
            $indexFile = dmdfolder_domydesk_root() . '/data/modules/' . DMDFOLDER_MODULE_ID . '/indexes/resources.json';
            if ($viewerKey !== '' && is_file($indexFile)) {
                $size = @filesize($indexFile);
                if ($size !== false && $size <= 4 * 1024 * 1024) {
                    $raw = @file_get_contents($indexFile);
                    $data = is_string($raw) ? json_decode($raw, true) : null;
                    $resources = is_array($data['resources'] ?? null) ? $data['resources'] : [];
                    $seenCount = 0;
                    foreach ($resources as $entry) {
                        if (++$seenCount > 1200) break;
                        if (!is_array($entry)) continue;
                        $view = is_array($entry['paths'][$viewerKey] ?? null) ? $entry['paths'][$viewerKey] : null;
                        if (!$view || !array_key_exists('path', $view)) continue;
                        $relative = dmdfolder_normalize_relative((string)$view['path'], true);
                        if ($relative !== '' && strlen($relative) > 120) continue;

                        $resource = is_array($entry['resource'] ?? null) ? $entry['resource'] : [];
                        $type = strtolower((string)($resource['type'] ?? '')) === 'folder' ? 'folder' : 'file';
                        $reason = dmdfolder_protection_reason($relative, $type === 'file', $access);
                        if ($reason !== '' && empty($access['is_admin'])) continue;

                        dmdfolder_actionhub_catalog_add_parents($folders, $writableFolders, $relative, $access);
                        dmdfolder_actionhub_catalog_add($all, $relative, $type, $access);
                        if ($relative !== '') dmdfolder_actionhub_catalog_add($mutable, $relative, $type, $access);
                        if ($type === 'folder') {
                            dmdfolder_actionhub_catalog_add($folders, $relative, 'folder', $access);
                            dmdfolder_actionhub_catalog_add($writableFolders, $relative, 'folder', $access);
                        } elseif (dmdfolder_actionhub_text_path_hint($relative)) {
                            dmdfolder_actionhub_catalog_add($textFiles, $relative, 'file', $access);
                        }
                    }
                }
            }
        } catch (Throwable $ignored) {
        }

        return [
            'all' => dmdfolder_actionhub_sort_options($all, true),
            'folders' => dmdfolder_actionhub_sort_options($folders, true),
            'writable_folders' => dmdfolder_actionhub_sort_options($writableFolders, true),
            'mutable' => dmdfolder_actionhub_sort_options($mutable, false),
            'text_files' => dmdfolder_actionhub_sort_options($textFiles, false),
        ];
    }
}

if (!function_exists('dmdfolder_actionhub_destination_options')) {
    function dmdfolder_actionhub_destination_options(array $folders, string $sourceRelative = '', bool $sourceIsFolder = false): array
    {
        $sourceRelative = dmdfolder_normalize_relative($sourceRelative, true);
        $sourceParent = '';
        if ($sourceRelative !== '') {
            $parts = explode('/', $sourceRelative);
            array_pop($parts);
            $sourceParent = implode('/', $parts);
        }

        $out = [];
        foreach ($folders as $option) {
            if (!is_array($option)) continue;
            $destination = dmdfolder_actionhub_payload_path((string)($option['value'] ?? ''));
            if ($sourceRelative !== '' && $destination === $sourceParent) continue;
            if ($sourceIsFolder && $sourceRelative !== '') {
                if ($destination === $sourceRelative || strpos($destination . '/', $sourceRelative . '/') === 0) continue;
            }
            $out[] = $option;
        }
        return $out;
    }
}

if (!function_exists('dmdfolder_actionhub_input_select')) {
    function dmdfolder_actionhub_input_select(string $id, string $label, array $options, bool $required = true, string $help = ''): array
    {
        $input = [
            'id' => $id,
            'label' => $label,
            'type' => 'select',
            'required' => $required,
            'options' => $options,
        ];
        if ($help !== '') $input['help'] = $help;
        return $input;
    }
}

if (!function_exists('dmdfolder_actionhub_action')) {
    function dmdfolder_actionhub_action(
        string $id,
        string $label,
        string $group,
        string $permission,
        string $scope,
        array $resourceTypes = [],
        array $inputs = [],
        bool $scenario = false,
        bool $dangerous = false,
        string $confirm = '',
        string $icon = '⚡',
        string $description = ''
    ): array {
        $action = [
            'id' => $id,
            'label' => $label,
            'group' => $group,
            'permission' => $permission,
            'scope' => $scope,
            'scenario' => $scenario,
            'icon' => $icon,
            'description' => $description,
        ];
        if ($resourceTypes) $action['resource_types'] = $resourceTypes;
        if ($inputs) $action['inputs'] = $inputs;
        if ($dangerous) $action['dangerous'] = true;
        if ($confirm !== '') $action['confirm'] = $confirm;
        return $action;
    }
}

if (!function_exists('dmdfolder_actionhub_catalog')) {
    function dmdfolder_actionhub_catalog(array $context): array
    {
        try {
            $email = trim((string)($context['email'] ?? ''));
            dmdfolder_actionhub_require_actor($email);
            $paths = dmdfolder_actionhub_path_catalog_data();
            $resourceContext = is_array($context['resource'] ?? null) ? $context['resource'] : null;
            $actions = [];

            if ($resourceContext !== null) {
                [$absolute, $relative, $access, $resource] = dmdfolder_actionhub_resolve_context_resource($resourceContext);
                $isFolder = is_dir($absolute);
                $type = $isFolder ? 'folder' : 'file';

                if (dmdfolder_has_permission($isFolder ? 'folder.list' : 'folder.read')) {
                    $actions[] = dmdfolder_actionhub_action(
                        'resource.open', 'Ouvrir', 'Fichiers et dossiers', 'module.view', 'resource', [$type], [], false, false, '', '👁️',
                        'Ouvre l’élément sélectionné dans DMD-Folder.'
                    );
                }
                if (!$isFolder && dmdfolder_has_permission('folder.download')) {
                    $actions[] = dmdfolder_actionhub_action(
                        'file.download', 'Télécharger', 'Fichiers', 'folder.download', 'resource', ['file'], [], false, false, '', '⬇️',
                        'Télécharge le fichier sélectionné.'
                    );
                }
                if ($relative !== '' && dmdfolder_has_permission('folder.rename')) {
                    $actions[] = dmdfolder_actionhub_action(
                        'resource.rename', 'Renommer', 'Gestion', 'folder.rename', 'resource', [$type], [
                            ['id' => 'new_name', 'label' => 'Nouveau nom', 'type' => 'text', 'required' => true],
                        ], false, false, '', '✏️', 'Renomme l’élément sélectionné.'
                    );
                }
                if ($relative !== '' && dmdfolder_has_permission('folder.move')) {
                    $destinations = dmdfolder_actionhub_destination_options($paths['writable_folders'], $relative, $isFolder);
                    if ($destinations) {
                        $actions[] = dmdfolder_actionhub_action(
                            'resource.move', 'Déplacer', 'Gestion', 'folder.move', 'resource', [$type], [
                                dmdfolder_actionhub_input_select('destination', 'Dossier de destination', $destinations, false, 'Choisis directement le dossier de destination.'),
                            ], false, false, '', '📦', 'Déplace l’élément sélectionné vers un dossier accessible.'
                        );
                    }
                }
                if ($relative !== '' && dmdfolder_has_permission('folder.delete')) {
                    $actions[] = dmdfolder_actionhub_action(
                        'resource.delete', 'Supprimer', 'Gestion', 'folder.delete', 'resource', [$type], [], false, true,
                        'Supprimer définitivement cet élément ?', '🗑️', 'Supprime l’élément sélectionné.'
                    );
                }
                return ['replace' => true, 'actions' => $actions];
            }

            if (dmdfolder_has_permission('folder.create') && $paths['writable_folders']) {
                $actions[] = dmdfolder_actionhub_action(
                    'folder.create', 'Créer un dossier', 'Dossiers', 'folder.create', 'module', [], [
                        dmdfolder_actionhub_input_select('parent_path', 'Dossier parent', $paths['writable_folders'], false, 'Choisis le dossier dans lequel créer le nouveau dossier.'),
                        ['id' => 'name', 'label' => 'Nom du dossier', 'type' => 'text', 'required' => true],
                    ], true, false, '', '📁', 'Crée un dossier dans un emplacement choisi directement dans DMD-Folder.'
                );
                $actions[] = dmdfolder_actionhub_action(
                    'file.create_text', 'Créer un fichier texte', 'Fichiers texte', 'folder.create', 'module', [], [
                        dmdfolder_actionhub_input_select('parent_path', 'Dossier parent', $paths['writable_folders'], false, 'Choisis le dossier dans lequel créer le fichier.'),
                        ['id' => 'name', 'label' => 'Nom du fichier', 'type' => 'text', 'required' => true, 'placeholder' => 'exemple.txt'],
                        ['id' => 'content', 'label' => 'Contenu initial', 'type' => 'textarea', 'required' => false],
                    ], true, false, '', '📄', 'Crée un fichier texte dans un emplacement choisi directement dans DMD-Folder.'
                );
            }

            if (dmdfolder_has_permission('folder.edit') && $paths['text_files']) {
                $actions[] = dmdfolder_actionhub_action(
                    'file.write_text', 'Écrire dans un fichier texte', 'Fichiers texte', 'folder.edit', 'module', [], [
                        dmdfolder_actionhub_input_select('path', 'Fichier à modifier', $paths['text_files'], true, 'Choisis le fichier texte existant à modifier.'),
                        ['id' => 'content', 'label' => 'Nouveau contenu', 'type' => 'textarea', 'required' => false],
                    ], true, false, '', '💾', 'Remplace le contenu d’un fichier texte sélectionné. Une sauvegarde est créée avant modification lorsque possible.'
                );
            }

            if (dmdfolder_has_permission('folder.list') && $paths['all']) {
                $actions[] = dmdfolder_actionhub_action(
                    'resource.assert_exists', 'Vérifier qu’un chemin existe', 'Contrôle', 'folder.list', 'module', [], [
                        dmdfolder_actionhub_input_select('path', 'Fichier ou dossier', $paths['all'], false, 'Choisis directement l’élément dont le scénario doit vérifier l’existence.'),
                        [
                            'id' => 'expected_type', 'label' => 'Type attendu', 'type' => 'select', 'required' => false, 'default' => 'any',
                            'options' => [
                                ['value' => 'any', 'label' => 'Fichier ou dossier'],
                                ['value' => 'file', 'label' => 'Fichier'],
                                ['value' => 'folder', 'label' => 'Dossier'],
                            ],
                        ],
                    ], true, false, '', '✅', 'Vérifie qu’un élément sélectionné existe toujours lors de l’exécution du scénario.'
                );
            }

            if (dmdfolder_has_permission('folder.rename') && $paths['mutable']) {
                $actions[] = dmdfolder_actionhub_action(
                    'resource.rename_path', 'Renommer un fichier ou dossier', 'Gestion', 'folder.rename', 'module', [], [
                        dmdfolder_actionhub_input_select('path', 'Élément à renommer', $paths['mutable'], true, 'Choisis directement le fichier ou dossier.'),
                        ['id' => 'new_name', 'label' => 'Nouveau nom', 'type' => 'text', 'required' => true],
                    ], true, false, '', '✏️', 'Renomme un fichier ou dossier choisi dans DMD-Folder.'
                );
            }

            if (dmdfolder_has_permission('folder.move') && $paths['mutable'] && $paths['writable_folders']) {
                $actions[] = dmdfolder_actionhub_action(
                    'resource.move_path', 'Déplacer un fichier ou dossier', 'Gestion', 'folder.move', 'module', [], [
                        dmdfolder_actionhub_input_select('path', 'Élément à déplacer', $paths['mutable'], true, 'Choisis directement le fichier ou dossier à déplacer.'),
                        dmdfolder_actionhub_input_select('destination', 'Dossier de destination', $paths['writable_folders'], false, 'Choisis directement le dossier de destination.'),
                    ], true, false, '', '📦', 'Déplace un fichier ou dossier sélectionné vers un dossier accessible.'
                );
            }

            if (dmdfolder_has_permission('folder.delete') && $paths['mutable']) {
                $actions[] = dmdfolder_actionhub_action(
                    'resource.delete_path', 'Supprimer un fichier ou dossier', 'Gestion', 'folder.delete', 'module', [], [
                        dmdfolder_actionhub_input_select('path', 'Élément à supprimer', $paths['mutable'], true, 'Choisis directement le fichier ou dossier à supprimer.'),
                    ], true, true, 'Supprimer définitivement l’élément sélectionné ?', '🗑️', 'Supprime un fichier ou dossier choisi dans DMD-Folder.'
                );
            }

            return ['replace' => true, 'actions' => $actions];
        } catch (Throwable $e) {
            return ['replace' => true, 'actions' => []];
        }
    }
}

if (!function_exists('dmdfolder_actionhub_handle')) {
    function dmdfolder_actionhub_handle(array $context): array
    {
        try {
            $email = trim((string)($context['email'] ?? ''));
            $action = is_array($context['action'] ?? null) ? $context['action'] : [];
            $actionId = trim((string)($action['id'] ?? ''));
            $payload = is_array($context['payload'] ?? null) ? $context['payload'] : [];
            $resourceContext = is_array($context['resource'] ?? null) ? $context['resource'] : [];

            if ($actionId === '') throw new RuntimeException('Action ActionHub manquante.');
            dmdfolder_actionhub_require_actor($email);
            $permission = dmdfolder_actionhub_permission_for($actionId);
            if ($permission !== null) dmdfolder_require_permission($permission);

            if ($actionId === 'folder.create') return dmdfolder_actionhub_create_folder($payload);
            if ($actionId === 'file.create_text') return dmdfolder_actionhub_create_text_file($payload);
            if ($actionId === 'file.write_text') return dmdfolder_actionhub_write_text($payload);

            if ($actionId === 'resource.assert_exists') {
                $expectedType = strtolower(trim((string)($payload['expected_type'] ?? 'any')));
                $requiredType = $expectedType === 'file' ? 'file' : ($expectedType === 'folder' ? 'dir' : null);
                [$absolute, $relative, $access] = dmdfolder_existing_path(dmdfolder_actionhub_payload_path((string)($payload['path'] ?? '')), $requiredType);
                $type = is_dir($absolute) ? 'folder' : 'file';
                $resource = dmdfolder_resource($relative, $type, $relative === '' ? $access['label'] : basename($absolute), $access);
                dmdfolder_audit('assert_exists', $relative, $resource, ['source' => 'actionhub_scenario'], [], false, true);
                return dmdfolder_actionhub_result(true, 'Chemin disponible : ' . ($relative === '' ? $access['label'] : $relative) . '.', [
                    'path' => $relative,
                    'type' => $type,
                    'resource' => $resource,
                ]);
            }

            if ($actionId === 'resource.rename_path') {
                return dmdfolder_actionhub_rename((string)($payload['path'] ?? ''), (string)($payload['new_name'] ?? ''), 'actionhub_scenario');
            }
            if ($actionId === 'resource.move_path') {
                return dmdfolder_actionhub_move((string)($payload['path'] ?? ''), (string)($payload['destination'] ?? ''), 'actionhub_scenario');
            }
            if ($actionId === 'resource.delete_path') {
                return dmdfolder_actionhub_delete((string)($payload['path'] ?? ''), 'actionhub_scenario');
            }

            [$absolute, $relative, $access, $resource] = dmdfolder_actionhub_resolve_context_resource($resourceContext);
            $type = is_dir($absolute) ? 'folder' : 'file';

            if ($actionId === 'resource.open') {
                dmdfolder_require_permission($type === 'folder' ? 'folder.list' : 'folder.read');
                dmdfolder_audit('open', $relative, $resource, ['source' => 'actionhub_resource'], [], false, true);
                return dmdfolder_actionhub_result(true, 'Ouverture de « ' . ($resource['name'] ?? basename($absolute)) . ' ».', [
                    'ui_action' => 'open',
                    'path' => $relative,
                    'type' => $type,
                    'resource' => $resource,
                ]);
            }
            if ($actionId === 'file.download') {
                if ($type !== 'file') throw new RuntimeException('Cette action nécessite un fichier.');
                return dmdfolder_actionhub_result(true, 'Téléchargement de « ' . basename($absolute) . ' ».', [
                    'ui_action' => 'download',
                    'path' => $relative,
                    'type' => 'file',
                    'resource' => $resource,
                ]);
            }
            if ($actionId === 'resource.rename') {
                return dmdfolder_actionhub_rename($relative, (string)($payload['new_name'] ?? ''), 'actionhub_resource');
            }
            if ($actionId === 'resource.move') {
                return dmdfolder_actionhub_move($relative, (string)($payload['destination'] ?? ''), 'actionhub_resource');
            }
            if ($actionId === 'resource.delete') {
                return dmdfolder_actionhub_delete($relative, 'actionhub_resource');
            }

            return dmdfolder_actionhub_result(false, 'Action ActionHub DMD-Folder inconnue.', [], 'unsupported_action');
        } catch (Throwable $e) {
            try {
                dmdfolder_log_event('actionhub', '', 'error', ['message' => $e->getMessage()]);
            } catch (Throwable $ignored) {}
            $permissionDenied = strpos($e->getMessage(), 'Droit DMD-Folder refusé') === 0;
            return dmdfolder_actionhub_result(false, $e->getMessage(), [], $permissionDenied ? 'permission_denied' : 'action_failed');
        }
    }
}
