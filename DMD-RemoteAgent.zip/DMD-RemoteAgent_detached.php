<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$email = dmd_remoteagent_email();
if ($email === '') { http_response_code(401); echo 'Non connecté.'; exit; }
dmd_require_module_access(DMD_REMOTEAGENT_MODULE_ID, 'module.view');
$security = dmd_remoteagent_security_state($email);
if (empty($security['unlocked'])) { http_response_code(403); echo 'DMD-RemoteAgent est verrouillé par le MFA.'; exit; }
$agentId = dmd_agent_safe_agent_id(isset($_GET['agent_id']) ? $_GET['agent_id'] : '');
if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId) || !dmd_remoteagent_has_permission($email, $agentId, 'remote.screen')) {
    http_response_code(403); echo 'Accès Remote refusé.'; exit;
}
$device = dmd_remoteagent_get_device($agentId);
if (!$device) { http_response_code(404); echo 'PC introuvable.'; exit; }
$controlRequested = !empty($_GET['control']);
$canControl = dmd_remoteagent_has_permission($email, $agentId, 'remote.control');
$canClipboard = dmd_remoteagent_has_permission($email, $agentId, 'remote.clipboard');
$control = $controlRequested && $canControl;
$csrf = dmd_csrf_token('dmd_remoteagent');
$hostname = trim((string)($device['hostname'] ?? 'PC')); if ($hostname === '') $hostname = 'PC';

// Affichage UI : IPv4 de l'interface active en priorité.
// last_ip peut être une IPv6 link-local selon la connexion HTTP de l'Agent.
$ipv4 = '';
$inventory = isset($device['last_inventory']) && is_array($device['last_inventory']) ? $device['last_inventory'] : array();
$activeInterface = isset($inventory['active_interface']) && is_array($inventory['active_interface']) ? $inventory['active_interface'] : array();
$candidate = trim((string)($activeInterface['ipv4'] ?? ''));
if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
    $ipv4 = $candidate;
}
if ($ipv4 === '' && isset($inventory['network']) && is_array($inventory['network'])) {
    foreach ($inventory['network'] as $nic) {
        if (!is_array($nic) || !isset($nic['ips']) || !is_array($nic['ips'])) continue;
        foreach ($nic['ips'] as $rawIp) {
            $candidate = trim((string)$rawIp);
            if (strpos($candidate, '/') !== false) $candidate = explode('/', $candidate, 2)[0];
            if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && strpos($candidate, '127.') !== 0) {
                $ipv4 = $candidate;
                break 2;
            }
        }
    }
}
if ($ipv4 === '') {
    $candidate = trim((string)($device['last_ip'] ?? ''));
    if ($candidate !== '' && filter_var($candidate, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) $ipv4 = $candidate;
}
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DMD-Remote — <?= dmd_remoteagent_h($hostname) ?></title>
<?php $dmdDetachedCssRev = (string)(@filemtime(__DIR__ . '/DMD-RemoteAgent_detached.css') ?: '1.0.35'); ?>
<link rel="stylesheet" href="DMD-RemoteAgent_detached.css?v=<?= rawurlencode($dmdDetachedCssRev) ?>">
</head>
<body>
<div class="dmd-detached" id="dmdDetachedRemote">
  <header class="dmd-detached-head">
    <div class="identity">
      <span class="live" aria-hidden="true"></span>
      <strong><?= dmd_remoteagent_h($hostname) ?></strong>
      <?php if ($ipv4 !== ''): ?><small class="ipv4"><?= dmd_remoteagent_h($ipv4) ?></small><?php endif; ?>
      <span class="mode"><?= $control ? 'CTRL' : 'VUE' ?></span>
      <span class="status" id="dmdDetachedStatus">Connexion…</span>
    </div>
    <div class="actions" aria-label="Commandes Remote">
      <div class="picker-wrap">
        <button id="dmdOpenScreen" class="tool-btn icon-only" type="button" title="Choisir l’écran" aria-label="Choisir l’écran">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Zm1 2v8h14V7H5Zm5 12h4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <select id="dmdRemoteScreen" class="picker-select sr-picker" title="Écran distant" aria-label="Écran distant"><option value="">Écran…</option></select>
      </div>
      <div class="picker-wrap">
        <button id="dmdOpenProfile" class="tool-btn icon-only" type="button" title="Profil vidéo" aria-label="Profil vidéo">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M7 4v16M12 4v16M17 4v16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
        </button>
        <select id="dmdStreamProfile" class="picker-select sr-picker" title="Profil vidéo H.264" aria-label="Profil vidéo"><option value="balanced">1366 max</option><option value="low">1024 max</option><option value="quality">1920 max</option><option value="native">Natif</option></select>
      </div>
      <div class="picker-wrap">
        <button id="dmdOpenDisplay" class="tool-btn icon-only" type="button" title="Mode d’affichage" aria-label="Mode d’affichage">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h16M8 8l-4 4 4 4M16 8l4 4-4 4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <select id="dmdDisplayMode" class="picker-select sr-picker" title="Mode d’affichage" aria-label="Mode d’affichage"><option value="fit">Adapter</option><option value="1to1">1:1</option></select>
      </div>
      <?php if ($control): ?>
      <div class="picker-wrap">
        <button id="dmdOpenCombo" class="tool-btn icon-only" type="button" title="Combinaison de touches" aria-label="Combinaison de touches">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8h16M4 12h16M4 16h10" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="18" cy="16" r="2" fill="currentColor"/></svg>
        </button>
        <select id="dmdKeyCombo" class="picker-select sr-picker" title="Combinaison de touches" aria-label="Combinaison de touches"><option value="">Touches…</option><option value="ctrl_alt_end">Ctrl+Alt+Fin</option><option value="ctrl_alt_del">Ctrl+Alt+Suppr</option><option value="ctrl_shift_esc">Ctrl+Maj+Échap</option><option value="alt_tab">Alt+Tab</option><option value="alt_f4">Alt+F4</option><option value="win_r">Win+R</option><option value="win_l">Win+L</option><option value="ctrl_c">Ctrl+C</option><option value="ctrl_v">Ctrl+V</option><option value="ctrl_x">Ctrl+X</option><option value="ctrl_a">Ctrl+A</option></select>
      </div>
      <button id="dmdSendCombo" class="tool-btn icon-only" type="button" title="Envoyer la combinaison" aria-label="Envoyer la combinaison">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h10M11 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <?php endif; ?>
      <?php if ($canClipboard): ?><button id="dmdClipboardToggle" class="tool-btn icon-only" type="button" title="Presse-papiers manuel" aria-label="Presse-papiers manuel"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5h6M9 3h6a1 1 0 0 1 1 1v2H8V4a1 1 0 0 1 1-1Zm-2 4h10a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></button><?php endif; ?>
      <button id="dmdFullscreen" class="tool-btn icon-only" type="button" title="Plein écran" aria-label="Plein écran"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 4H4v4M16 4h4v4M8 20H4v-4M20 16v4h-4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
      <button id="dmdStop" class="tool-btn icon-only danger" type="button" title="Arrêter la session Remote" aria-label="Arrêter la session Remote"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="7" width="10" height="10" rx="1.5" fill="currentColor"/></svg></button>
    </div>
  </header>
  <?php if ($canClipboard): ?>
  <section class="clipboard-drawer" id="dmdClipboardDrawer" hidden>
    <span>Manuel uniquement :</span>
    <textarea id="dmdClipboardText" rows="2" placeholder="Clic droit → Coller ici depuis ton PC, ou charge le presse-papiers Remote."></textarea>
    <button id="dmdClipReadRemote" type="button">Remote → zone</button>
    <button id="dmdClipSendRemote" type="button">Zone → Remote</button>
    <small>Aucune synchronisation automatique. Pour récupérer vers ton PC : Remote → zone puis clic droit → Copier dans la zone.</small>
  </section>
  <?php endif; ?>
  <main class="dmd-detached-stage <?= $control ? 'control' : '' ?>" id="dmdDetachedStage" tabindex="0">
    <canvas id="dmdDetachedImage" aria-label="Écran distant <?= dmd_remoteagent_h($hostname) ?>"></canvas>
    <div class="waiting" id="dmdDetachedWaiting">Connexion à la session Remote existante…</div>
  </main>
  <footer><span>DoMyDesk · DMD-Remote</span><span id="dmdDetachedHint"><?= $control ? 'Clavier / souris actifs · presse-papiers uniquement sur action volontaire' : 'Mode visualisation' ?></span></footer>
</div>
<script>
window.DMD_DETACHED_REMOTE = <?= json_encode(array(
 'agentId'=>$agentId,'hostname'=>$hostname,'control'=>$control,'canClipboard'=>$canClipboard,
 'csrf'=>$csrf,'api'=>'DMD-RemoteAgent_api.php'
), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
</script>
<?php $dmdRemoteCoreRev = (string)(@filemtime(__DIR__ . '/DMDRemote.js') ?: '1.0.35'); ?>
<script src="DMDRemote.js?v=<?= rawurlencode($dmdRemoteCoreRev) ?>"></script>
<?php $dmdDetachedJsRev = (string)(@filemtime(__DIR__ . '/DMD-RemoteAgent_detached.js') ?: '1.0.35'); ?>
<script src="DMD-RemoteAgent_detached.js?v=<?= rawurlencode($dmdDetachedJsRev) ?>"></script>
</body>
</html>
