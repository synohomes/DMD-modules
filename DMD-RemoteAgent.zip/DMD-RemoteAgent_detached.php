<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$email = dmd_remoteagent_email();
if ($email === '') { http_response_code(401); echo 'Non connecté.'; exit; }
dmd_require_module_access(DMD_REMOTEAGENT_MODULE_ID, 'use');
$security = dmd_remoteagent_security_state($email);
if (empty($security['unlocked'])) { http_response_code(403); echo 'DMD-RemoteAgent est verrouillé par le MFA.'; exit; }
$agentId = dmd_agent_safe_agent_id(isset($_GET['agent_id']) ? $_GET['agent_id'] : '');
if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId) || !dmd_remoteagent_has_permission($email, $agentId, 'remote.screen')) {
    http_response_code(403); echo 'Accès Remote refusé.'; exit;
}
$device = dmd_remoteagent_get_device($agentId);
if (!$device) { http_response_code(404); echo 'PC introuvable.'; exit; }
$controlRequested = !empty($_GET['control']);
$canControl = dmd_remoteagent_has_permission($email, $agentId, 'remote.control');
$canClipboard = dmd_remoteagent_has_permission($email, $agentId, 'remote.clipboard');
$control = $controlRequested && $canControl;
$csrf = dmd_csrf_token('dmd_remoteagent');
$hostname = trim((string)($device['hostname'] ?? 'PC')); if ($hostname === '') $hostname = 'PC';
$lastIp = trim((string)($device['last_ip'] ?? ''));
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DMD-Remote — <?= dmd_remoteagent_h($hostname) ?></title>
<link rel="stylesheet" href="DMD-RemoteAgent_detached.css?v=1.0.35">
</head>
<body>
<div class="dmd-detached" id="dmdDetachedRemote">
  <header class="dmd-detached-head">
    <div class="identity"><span class="live"></span><strong><?= dmd_remoteagent_h($hostname) ?></strong><?php if ($lastIp !== ''): ?><small><?= dmd_remoteagent_h($lastIp) ?></small><?php endif; ?><span class="mode"><?= $control ? 'CONTRÔLE' : 'VUE' ?></span></div>
    <div class="status" id="dmdDetachedStatus">Connexion au flux…</div>
    <div class="actions">
      <select id="dmdResolution" title="Résolution réelle du PC distant" aria-label="Résolution Remote"><option value="">Résolution…</option></select>
      <select id="dmdDisplayMode" title="Mode d’affichage dans la fenêtre" aria-label="Mode d’affichage"><option value="fit">Adapter</option><option value="1to1">1:1</option></select>
      <?php if ($canClipboard): ?><button id="dmdClipboardToggle" type="button" title="Ouvrir le presse-papiers manuel">📋 Presse-papiers</button><?php endif; ?>
      <button id="dmdFullscreen" type="button" title="Plein écran">⛶ Plein écran</button>
      <button id="dmdStop" class="danger" type="button" title="Arrêter la session Remote">■ Stop</button>
    </div>
  </header>
  <?php if ($canClipboard): ?>
  <section class="clipboard-drawer" id="dmdClipboardDrawer" hidden>
    <span>Manuel uniquement :</span>
    <textarea id="dmdClipboardText" rows="2" placeholder="Clic droit → Coller ici depuis ton PC, ou charge le presse-papiers Remote."></textarea>
    <button id="dmdClipReadRemote" type="button">Remote → zone</button>
    <button id="dmdClipSendRemote" type="button">Zone → Remote</button>
    <small>Aucune synchronisation automatique. Pour récupérer vers ton PC : Remote → zone puis clic droit → Copier dans la zone.</small>
  </section>
  <?php endif; ?>
  <main class="dmd-detached-stage <?= $control ? 'control' : '' ?>" id="dmdDetachedStage" tabindex="0">
    <img id="dmdDetachedImage" alt="Écran distant <?= dmd_remoteagent_h($hostname) ?>" draggable="false">
    <div class="waiting" id="dmdDetachedWaiting">Connexion à la session Remote existante…</div>
  </main>
  <footer><span>DoMyDesk · DMD-Remote</span><span id="dmdDetachedHint"><?= $control ? 'Clavier / souris actifs · presse-papiers uniquement sur action volontaire' : 'Mode visualisation' ?></span></footer>
</div>
<script>
window.DMD_DETACHED_REMOTE = <?= json_encode(array(
 'agentId'=>$agentId,'hostname'=>$hostname,'control'=>$control,'canClipboard'=>$canClipboard,
 'csrf'=>$csrf,'api'=>'DMD-RemoteAgent_api.php'
), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
</script>
<script src="DMD-RemoteAgent_detached.js?v=1.0.35"></script>
</body>
</html>
