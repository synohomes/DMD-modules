#!/usr/bin/env php
<?php
/* DoMyDesk - DMD-Remote WebSocket interne. PHP CLI, aucun binaire/gateway externe. */
if (PHP_SAPI !== 'cli') { fwrite(STDERR, "CLI only\n"); exit(2); }

function argValue(array $argv, string $name): string {
    $n=count($argv); for($i=1;$i<$n;$i++){ if($argv[$i]===$name && isset($argv[$i+1])) return (string)$argv[$i+1]; }
    return '';
}
function readGuardedJson(string $path): array {
    $raw=@file_get_contents($path); if(!is_string($raw)||$raw==='') return [];
    $p=strpos($raw,"\n"); if(strncmp($raw,'<?php ',6)===0 && $p!==false) $raw=substr($raw,$p+1);
    $j=json_decode($raw,true); return is_array($j)?$j:[];
}
function b64urlDecode(string $s) {
    $s=strtr($s,'-_','+/'); $pad=strlen($s)%4; if($pad)$s.=str_repeat('=',4-$pad); return base64_decode($s,true);
}
function verifyTicket(string $ticket,array $cfg,string $kind,string $channel) {
    $parts=explode('.',$ticket,2); if(count($parts)!==2)return false;
    $payload=b64urlDecode($parts[0]); $sig=b64urlDecode($parts[1]);
    if(!is_string($payload)||!is_string($sig))return false;

    $verified=false;
    $ticketSecret=base64_decode(trim((string)($cfg['ticket_secret']??'')),true);
    if(is_string($ticketSecret)&&strlen($ticketSecret)===32&&strlen($sig)===32){
        $want=hash_hmac('sha256',$payload,$ticketSecret,true);
        $verified=hash_equals($want,$sig);
    }

    // Compatibilité très courte avec les tickets Ed25519 déjà émis avant
    // remplacement des fichiers. Aucun besoin de sodium pour les nouveaux tickets.
    if(!$verified&&strlen($sig)===64&&function_exists('sodium_crypto_sign_verify_detached')&&defined('SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES')){
        $pk=base64_decode(trim((string)($cfg['instance_public_key']??'')),true);
        if(is_string($pk)&&strlen($pk)===SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES){
            $verified=@sodium_crypto_sign_verify_detached($sig,$payload,$pk);
        }
    }
    if(!$verified)return false;

    $c=json_decode($payload,true); if(!is_array($c))return false;
    if((int)($c['v']??0)!==1 || (string)($c['instance_id']??'')!==(string)($cfg['instance_id']??''))return false;
    if((string)($c['kind']??'')!==$kind || (int)($c['exp']??0)<time())return false;
    $aid=preg_replace('/[^A-Za-z0-9._-]/','',(string)($c['agent_id']??'')); if($aid==='')return false;
    $perms=is_array($c['permissions']??null)?$c['permissions']:[]; if(!in_array($channel,$perms,true))return false;
    return ['agent_id'=>$aid,'permissions'=>$perms,'exp'=>(int)$c['exp']];
}
function wsAccept(string $key): string { return base64_encode(sha1(trim($key).'258EAFA5-E914-47DA-95CA-C5AB0DC85B11',true)); }
function frameOut(int $opcode,string $payload=''): string {
    $len=strlen($payload); $h=chr(0x80|($opcode&0x0f));
    if($len<126)$h.=chr($len); elseif($len<=0xffff)$h.=chr(126).pack('n',$len); else $h.=chr(127).pack('NN',intdiv($len,4294967296),$len%4294967296);
    return $h.$payload;
}
function parseFrames(string &$buf): array {
    $out=[];
    while(strlen($buf)>=2){
        $b1=ord($buf[0]);$b2=ord($buf[1]);$fin=($b1&0x80)!==0;$op=$b1&0x0f;$masked=($b2&0x80)!==0;$len=$b2&0x7f;$pos=2;
        if($len===126){if(strlen($buf)<4)break;$len=unpack('n',substr($buf,2,2))[1];$pos=4;}
        elseif($len===127){if(strlen($buf)<10)break;$u=unpack('Nhi/Nlo',substr($buf,2,8)); if($u['hi']!==0||$u['lo']>16777216){$buf='';break;} $len=$u['lo'];$pos=10;}
        $mask=''; if($masked){if(strlen($buf)<$pos+4)break;$mask=substr($buf,$pos,4);$pos+=4;}
        if(strlen($buf)<$pos+$len)break;
        $payload=$len?substr($buf,$pos,$len):''; $buf=substr($buf,$pos+$len);
        if($masked&&$len){for($i=0;$i<$len;$i++)$payload[$i]=$payload[$i]^$mask[$i&3];}
        if(!$fin && $op!==0x0){ /* fragmentation not used by our clients */ }
        $out[]=['op'=>$op,'payload'=>$payload];
    }
    return $out;
}
function jsonText(array $a): string { return json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)?:'{}'; }
function sendTo(array &$clients,int $id,int $opcode,string $payload): void { if(isset($clients[$id]))$clients[$id]['out'].=frameOut($opcode,$payload); }
function agentStatusPayload(array $s): string {
    return jsonText([
        'type'=>'agent_status',
        'control'=>!empty($s['agent_control']),
        'video'=>!empty($s['agent_video']),
    ]);
}
function sendAgentStatusToViewer(array &$clients,array &$s,int $viewerId): void {
    sendTo($clients,$viewerId,0x1,agentStatusPayload($s));
}
function broadcastAgentStatus(array &$clients,array &$s): void {
    $payload=agentStatusPayload($s);
    foreach(array_keys($s['view_control']??[]) as $vid) sendTo($clients,(int)$vid,0x1,$payload);
}
function closeClient(array &$clients,int $id,array &$sessions): void {
    if(!isset($clients[$id]))return; $c=$clients[$id]; $aid=(string)($c['agent_id']??'');$role=(string)($c['role']??'');$channel=(string)($c['channel']??'');
    @fclose($c['sock']); unset($clients[$id]);
    if($aid!==''&&isset($sessions[$aid])){
        $s=&$sessions[$aid];
        $agentChanged=false;
        if($role==='agent' && ($s['agent_'.$channel]??0)===$id){$s['agent_'.$channel]=0;$agentChanged=true;}
        if($role==='viewer')unset($s['view_'.$channel][$id]);
        if($agentChanged)broadcastAgentStatus($clients,$s);
        if($role==='viewer'&&$channel==='video'&&empty($s['view_video'])&&!empty($s['agent_control'])){
            sendTo($clients,(int)$s['agent_control'],0x1,jsonText(['type'=>'bridge','op'=>'stream.stop','request_id'=>'bridge-stop']));
        }
        foreach(($s['pending']??[]) as $rid=>$vid)if($vid===$id)unset($s['pending'][$rid]);
        if(empty($s['agent_video'])&&empty($s['agent_control'])&&empty($s['view_video'])&&empty($s['view_control']))unset($sessions[$aid]);
    }
}
function validControlMessage(string $payload,array $permissions,bool $viewer) {
    if(strlen($payload)>1048576)return false; $j=json_decode($payload,true); if(!is_array($j))return false;
    $type=(string)($j['type']??''); $op=(string)($j['op']??'');
    if($viewer){
        if(!in_array($type,['control','input'],true)||$op==='')return false;
        $inputOps=['input.ping','mouse.move','mouse.button','mouse.wheel','key.event','key.text','key.combo'];
        $clipOps=['clipboard.read','clipboard.write'];
        $safeOps=['display.list','display.select','stream.profile','stream.keyframe'];
        if(in_array($op,$inputOps,true) && !in_array('input',$permissions,true))return false;
        if(in_array($op,$clipOps,true) && !in_array('clipboard',$permissions,true))return false;
        if(!in_array($op,array_merge($inputOps,$clipOps,$safeOps),true))return false;
        if($type==='control' && trim((string)($j['request_id']??''))==='')return false;
    }
    return $j;
}

$configPath=argValue($argv,'--config'); if($configPath===''){fwrite(STDERR,"--config required\n");exit(2);} $cfg=readGuardedJson($configPath);
$listen=(string)($cfg['listen']??'127.0.0.1:49380'); if(!preg_match('/^([^:]+|\[[^\]]+\]):([0-9]{2,5})$/',$listen,$m)){fwrite(STDERR,"listen invalid\n");exit(3);} $port=(int)$m[2]; if($port<1||$port>65535)exit(3);
$context=null;$scheme='tcp';
$cert=trim((string)($cfg['tls_cert']??''));$key=trim((string)($cfg['tls_key']??''));
if($cert!==''&&$key!==''&&is_file($cert)&&is_file($key)){$scheme='tls';$context=stream_context_create(['ssl'=>['local_cert'=>$cert,'local_pk'=>$key,'verify_peer'=>false,'allow_self_signed'=>true,'disable_compression'=>true]]);} else {$context=stream_context_create();}
$errno=0;$errstr='';$server=@stream_socket_server($scheme.'://'.$listen,$errno,$errstr,STREAM_SERVER_BIND|STREAM_SERVER_LISTEN,$context); if(!$server){fwrite(STDERR,"listen failed: $errstr\n");exit(4);} stream_set_blocking($server,false);
$clients=[];$sessions=[];$lastGc=time(); fwrite(STDOUT,"DMD-Remote WS listening on $listen\n");
while(true){
    $read=[$server];$write=[]; foreach($clients as $c){$read[]=$c['sock'];if($c['out']!=='')$write[]=$c['sock'];}
    $except=null;$n=@stream_select($read,$write,$except,0,200000); if($n===false){usleep(50000);continue;}
    if(in_array($server,$read,true)){
        while(($sock=@stream_socket_accept($server,0))!==false){stream_set_blocking($sock,false);$id=(int)$sock;$clients[$id]=['sock'=>$sock,'state'=>'http','in'=>'','out'=>'','role'=>'','channel'=>'','agent_id'=>'','permissions'=>[],'last'=>time(),'need_keyframe'=>false,'pending_jpeg'=>'','flow_enabled'=>false,'awaiting_ack'=>false];}
    }
    foreach($read as $sock){if($sock===$server)continue;$id=(int)$sock;if(!isset($clients[$id]))continue;$chunk=@fread($sock,262144);if($chunk===false||($chunk===''&&feof($sock))){closeClient($clients,$id,$sessions);continue;}if($chunk==='')continue;$clients[$id]['last']=time();$clients[$id]['in'].=$chunk;
        if($clients[$id]['state']==='http'){
            $p=strpos($clients[$id]['in'],"\r\n\r\n"); if($p===false){if(strlen($clients[$id]['in'])>16384)closeClient($clients,$id,$sessions);continue;}
            $raw=substr($clients[$id]['in'],0,$p+4);$clients[$id]['in']=substr($clients[$id]['in'],$p+4);$lines=explode("\r\n",trim($raw));$req=array_shift($lines);$headers=[];foreach($lines as $line){$q=strpos($line,':');if($q!==false)$headers[strtolower(trim(substr($line,0,$q)))]=trim(substr($line,$q+1));}
            if(!preg_match('#^GET\s+([^\s]+)\s+HTTP/1\.[01]$#',$req,$rm)){closeClient($clients,$id,$sessions);continue;}$target=$rm[1];$u=parse_url($target);$path=(string)($u['path']??'/');parse_str((string)($u['query']??''),$query);
            if($path==='/health'){$body='DMDREMOTE-WS-R8-AGENTSTATUS-V2';$clients[$id]['out'].="HTTP/1.1 200 OK\r\nContent-Length: ".strlen($body)."\r\nConnection: close\r\n\r\n".$body;$clients[$id]['state']='http-close';continue;}
            if(strtolower((string)($headers['upgrade']??''))!=='websocket'||empty($headers['sec-websocket-key'])){closeClient($clients,$id,$sessions);continue;}
            if(!preg_match('#^/(agent|view)/(video|control)$#',$path,$pm)){closeClient($clients,$id,$sessions);continue;}$role=$pm[1]==='view'?'viewer':'agent';$channel=$pm[2];$claims=verifyTicket((string)($query['ticket']??''),$cfg,$role,$channel);if($claims===false){$clients[$id]['out'].="HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";$clients[$id]['state']='http-close';continue;}
            $clients[$id]['out'].="HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ".wsAccept($headers['sec-websocket-key'])."\r\n\r\n";$clients[$id]['state']='ws';$clients[$id]['role']=$role;$clients[$id]['channel']=$channel;$clients[$id]['agent_id']=$claims['agent_id'];$clients[$id]['permissions']=$claims['permissions'];$aid=$claims['agent_id'];if(!isset($sessions[$aid]))$sessions[$aid]=['agent_video'=>0,'agent_control'=>0,'view_video'=>[],'view_control'=>[],'keyframe'=>'','pending'=>[]];$s=&$sessions[$aid];
            if($role==='agent'){$old=(int)($s['agent_'.$channel]??0);if($old&&$old!==$id)closeClient($clients,$old,$sessions);$s['agent_'.$channel]=$id;broadcastAgentStatus($clients,$s);if($channel==='control'&&!empty($s['view_video'])){sendTo($clients,$id,0x1,jsonText(['type'=>'bridge','op'=>'stream.start','request_id'=>'bridge-start']));sendTo($clients,$id,0x1,jsonText(['type'=>'bridge','op'=>'stream.keyframe','request_id'=>'bridge-keyframe']));}}
            else {
                $s['view_'.$channel][$id]=true;
                if($channel==='control')sendAgentStatusToViewer($clients,$s,$id);
                if($channel==='video'){
                    // Une fenêtre qui rejoint une session peut afficher immédiatement
                    // la dernière IDR en cache, mais ne doit jamais consommer des
                    // P-frames dont elle a manqué les références intermédiaires.
                    if($s['keyframe']!=='') sendTo($clients,$id,0x2,$s['keyframe']);
                    $clients[$id]['need_keyframe']=true;
                    if(!empty($s['agent_control'])){
                        sendTo($clients,(int)$s['agent_control'],0x1,jsonText(['type'=>'bridge','op'=>'stream.start','request_id'=>'bridge-start']));
                        sendTo($clients,(int)$s['agent_control'],0x1,jsonText(['type'=>'bridge','op'=>'stream.keyframe','request_id'=>'bridge-keyframe']));
                    }
                }
            }
        }
        if(!isset($clients[$id])||$clients[$id]['state']!=='ws')continue;
        foreach(parseFrames($clients[$id]['in']) as $f){$op=$f['op'];$payload=$f['payload'];$c=$clients[$id];$aid=$c['agent_id'];if(!isset($sessions[$aid]))continue;$s=&$sessions[$aid];if($op===0x8){sendTo($clients,$id,0x8,'');closeClient($clients,$id,$sessions);break;}if($op===0x9){sendTo($clients,$id,0xA,$payload);continue;}if($op===0xA)continue;
            // Backpressure feedback on the VIDEO websocket; no input rights required.
            // Only the viewer's own stream is affected. Other viewers/agents
            // retain the old behavior unless their viewer opts in.
            if($c['role']==='viewer'&&$c['channel']==='video'&&$op===0x1){
                if(strlen($payload)>256)continue;
                $flow=json_decode($payload,true);
                if(!is_array($flow)||($flow['type']??'')!=='flow')continue;
                if(($flow['op']??'')==='enable'){
                    $clients[$id]['flow_enabled']=true;
                    $clients[$id]['awaiting_ack']=false;
                }elseif(($flow['op']??'')==='ack' && !empty($clients[$id]['flow_enabled'])){
                    $clients[$id]['awaiting_ack']=false;
                    if($clients[$id]['out']==='' && $clients[$id]['pending_jpeg']!==''){
                        $latest=$clients[$id]['pending_jpeg'];
                        $clients[$id]['pending_jpeg']='';
                        sendTo($clients,$id,0x2,$latest);
                        $clients[$id]['awaiting_ack']=true;
                    }
                }
                continue;
            }
            if($c['role']==='agent'&&$c['channel']==='video'&&$op===0x2){
                if(strlen($payload)<26||substr($payload,0,4)!=='DMDR')continue;
                $isKey=(ord($payload[5])&1)!==0;
                if($isKey)$s['keyframe']=$payload;
                foreach(array_keys($s['view_video']) as $vid){
                    $vid=(int)$vid;
                    if(!isset($clients[$vid]))continue;

                    // Le Remote doit rester proche du temps réel. Ne jamais vider
                    // brutalement "out" : fwrite() peut avoir déjà envoyé le début
                    // d'une frame WebSocket et supprimer sa fin corromprait le flux.
                    // Si un viewer accumule trop de données, on ferme uniquement sa
                    // socket. Le navigateur reconnecte immédiatement et repart sur
                    // une nouvelle IDR, sans conserver plusieurs secondes de retard.
                    if(!empty($clients[$vid]['need_keyframe'])){
                        if(!$isKey)continue;
                        $clients[$vid]['need_keyframe']=false;
                    }
                    // Une JPEG v2 est autonome : s'il reste une trame en cours
                    // d'envoi, conserver uniquement la dernière suivante.
                    // Ne jamais tronquer une trame WebSocket déjà commencée.
                    if(ord($payload[4])===2 && $isKey){
                        if($clients[$vid]['out']!=='' ||
                                (!empty($clients[$vid]['flow_enabled']) && !empty($clients[$vid]['awaiting_ack']))){
                            // Latest complete frame only. Never queue stale JPEGs.
                            $clients[$vid]['pending_jpeg']=$payload;
                        }else{
                            sendTo($clients,$vid,0x2,$payload);
                            if(!empty($clients[$vid]['flow_enabled']))$clients[$vid]['awaiting_ack']=true;
                        }
                        continue;
                    }
                    // Pour H264, conserver toutes les références entre IDR.
                    if(strlen($clients[$vid]['out'])>786432){
                        closeClient($clients,$vid,$sessions);
                        continue;
                    }
                    sendTo($clients,$vid,0x2,$payload);
                }
                continue;
            }
            if($c['role']==='viewer'&&$c['channel']==='control'&&$op===0x1){$j=validControlMessage($payload,$c['permissions'],true);if($j===false){sendTo($clients,$id,0x1,jsonText(['type'=>'error','message'=>'Commande Remote refusée par le relais.']));continue;}if(empty($s['agent_control'])){sendTo($clients,$id,0x1,jsonText(['type'=>'error','message'=>'Canal contrôle Agent hors ligne.']));continue;}if(($j['type']??'')==='control')$s['pending'][(string)$j['request_id']]=$id;sendTo($clients,(int)$s['agent_control'],0x1,$payload);continue;}
            if($c['role']==='agent'&&$c['channel']==='control'&&$op===0x1){$j=json_decode($payload,true);if(!is_array($j))continue;if(($j['type']??'')==='result'&&!empty($j['request_id'])){$rid=(string)$j['request_id'];$vid=(int)($s['pending'][$rid]??0);if($vid)sendTo($clients,$vid,0x1,$payload);unset($s['pending'][$rid]);}else{foreach(array_keys($s['view_control']) as $vid)sendTo($clients,(int)$vid,0x1,$payload);}continue;}
        }
    }
    foreach($write as $sock){$id=(int)$sock;if(!isset($clients[$id]))continue;$buf=$clients[$id]['out'];if($buf==='')continue;$w=@fwrite($sock,$buf);if($w===false){closeClient($clients,$id,$sessions);continue;}if($w>0){
        $clients[$id]['out']=substr($buf,$w);
        if($clients[$id]['out']==='' && $clients[$id]['pending_jpeg']!=='' &&
                (empty($clients[$id]['flow_enabled']) || empty($clients[$id]['awaiting_ack']))){
            $latest=$clients[$id]['pending_jpeg'];
            $clients[$id]['pending_jpeg']='';
            sendTo($clients,$id,0x2,$latest);
            if(!empty($clients[$id]['flow_enabled']))$clients[$id]['awaiting_ack']=true;
        }
    }
    if(isset($clients[$id])&&$clients[$id]['state']==='http-close'&&$clients[$id]['out']==='')closeClient($clients,$id,$sessions);}
    if(time()-$lastGc>=10){$lastGc=time();foreach(array_keys($clients) as $id){if(!isset($clients[$id]))continue;if(time()-(int)$clients[$id]['last']>90){closeClient($clients,$id,$sessions);continue;}if($clients[$id]['state']==='ws')sendTo($clients,$id,0x9,'dmd');}}
}
