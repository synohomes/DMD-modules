(function (global) {
    'use strict';

    const HEADER_BYTES = 26;
    const MAGIC = [0x44, 0x4d, 0x56, 0x32];
    const SESSION_TICKET = 'DMD-RemoteV2_ticket.php';

    function uid() {
        const bytes = new Uint8Array(12);
        crypto.getRandomValues(bytes);
        return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    }

    function websocketURL(base, path, ticket) {
        const u = new URL(base, global.location.href);
        u.protocol = u.protocol === 'https:' ? 'wss:' : 'ws:';
        u.pathname = u.pathname.replace(/\/$/, '') + path;
        u.search = '';
        u.hash = '';
        u.searchParams.set('ticket', ticket);
        return u.toString();
    }

    function packetFrom(raw) {
        if (!(raw instanceof ArrayBuffer) || raw.byteLength <= HEADER_BYTES) return null;
        const v = new DataView(raw);
        for (let i = 0; i < MAGIC.length; i++) if (v.getUint8(i) !== MAGIC[i]) return null;
        if (v.getUint8(4) !== 2) return null;
        return {
            key: (v.getUint8(5) & 1) !== 0,
            width: v.getUint16(6, false),
            height: v.getUint16(8, false),
            sequence: Number(v.getBigUint64(10, false)),
            timestamp: Number(v.getBigUint64(18, false)),
            h264: new Uint8Array(raw, HEADER_BYTES)
        };
    }

    function keyCode(event) {
        const fixed = {
            Backspace: 8, Tab: 9, Enter: 13, Shift: 16, Control: 17, Alt: 18, Pause: 19,
            CapsLock: 20, Escape: 27, ' ': 32, PageUp: 33, PageDown: 34, End: 35, Home: 36,
            ArrowLeft: 37, ArrowUp: 38, ArrowRight: 39, ArrowDown: 40, Insert: 45, Delete: 46,
            Meta: 91, ContextMenu: 93
        };
        if (fixed[event.key] !== undefined) return fixed[event.key];
        if (/^F([1-9]|1[0-9]|2[0-4])$/.test(event.key)) return 111 + Number(event.key.slice(1));
        const code = Number(event.keyCode || event.which || 0);
        return code > 0 ? code : 0;
    }

    class RemoteV2 {
        constructor(root, options) {
            this.root = root;
            this.options = Object.assign({ control: false, ticketURL: SESSION_TICKET, detachURL: 'DMD-RemoteAgent_detached.php', detached: false }, options || {});
            this.agentId = String(this.options.agentId || '');
            this.wantControl = Boolean(this.options.control);
            this.videoSocket = null;
            this.controlSocket = null;
            this.decoder = null;
            this.ticketExpiry = 0;
            this.ticketRefresh = null;
            this.reconnectTimer = null;
            this.stopping = false;
            this.decoderWidth = 0;
            this.decoderHeight = 0;
            this.firstFrame = false;
            this.lastSequence = 0;
            this.pending = new Map();
            this.pressed = new Set();
            this.moveFrame = 0;
            this.pendingMove = null;
            this.frameCounter = 0;
            this.frameWindowStart = performance.now();
            this.fps = 0;
            this.bindElements();
        }

        bindElements() {
            const q = s => this.root.querySelector(s);
            this.canvas = q('[data-rv2-canvas]');
            this.stage = q('[data-rv2-stage]');
            this.status = q('[data-rv2-status]');
            this.spinner = q('[data-rv2-wait]');
            this.display = q('[data-rv2-display]');
            this.profile = q('[data-rv2-profile]');
            this.fitMode = q('[data-rv2-fit]');
            this.combo = q('[data-rv2-combo]');
            this.comboSend = q('[data-rv2-combo-send]');
            this.clipOpen = q('[data-rv2-clipboard-open]');
            this.clipPanel = q('[data-rv2-clipboard]');
            this.clipText = q('[data-rv2-clipboard-text]');
            this.clipRead = q('[data-rv2-clipboard-read]');
            this.clipWrite = q('[data-rv2-clipboard-write]');
            this.fullscreen = q('[data-rv2-fullscreen]');
            this.detach = q('[data-rv2-detach]');
            this.close = q('[data-rv2-close]');
            this.stats = q('[data-rv2-stats]');
            if (!(this.canvas instanceof HTMLCanvasElement) || !this.stage) throw new Error('Remote v2: viewer DOM incomplet');
            this.context = this.canvas.getContext('2d', { alpha: false, desynchronized: true });
        }

        async start() {
            if (!this.agentId) throw new Error('Remote v2: agent_id absent');
            if (typeof VideoDecoder !== 'function' || typeof EncodedVideoChunk !== 'function') {
                throw new Error('Ce navigateur ne fournit pas WebCodecs/VideoDecoder.');
            }
            this.installUI();
            await this.connect();
        }

        installUI() {
            if (this.fitMode) this.fitMode.addEventListener('change', () => this.resizeCanvas());
            if (this.profile) this.profile.addEventListener('change', () => {
                this.command('stream.profile', { profile: this.profile.value }).catch(e => this.show(e.message, true));
            });
            if (this.display) this.display.addEventListener('change', () => {
                const index = Number(this.display.value);
                if (Number.isInteger(index) && index >= 0) this.command('display.select', { index }).then(() => this.requestKeyframe()).catch(e => this.show(e.message, true));
            });
            if (this.comboSend) this.comboSend.addEventListener('click', () => {
                const name = String(this.combo && this.combo.value || '');
                if (name) this.command('key.combo', { name }).catch(e => this.show(e.message, true));
            });
            if (this.clipOpen) this.clipOpen.addEventListener('click', () => {
                if (this.clipPanel) this.clipPanel.hidden = !this.clipPanel.hidden;
            });
            if (this.clipRead) this.clipRead.addEventListener('click', async () => {
                try {
                    const data = await this.command('clipboard.read', {});
                    if (this.clipText) this.clipText.value = String(data && data.text || '');
                } catch (e) { this.show(e.message, true); }
            });
            if (this.clipWrite) this.clipWrite.addEventListener('click', () => {
                this.command('clipboard.write', { text: String(this.clipText && this.clipText.value || '') }).catch(e => this.show(e.message, true));
            });
            if (this.fullscreen) this.fullscreen.addEventListener('click', async () => {
                try {
                    if (document.fullscreenElement) await document.exitFullscreen();
                    else await this.root.requestFullscreen();
                } catch (e) { this.show(e.message, true); }
            });
            if (this.detach) this.detach.addEventListener('click', () => {
                const u = new URL(this.options.detachURL || 'DMD-RemoteAgent_detached.php', global.location.href);
                u.searchParams.set('agent_id', this.agentId);
                if (this.wantControl) u.searchParams.set('control', '1');
                global.open(u.toString(), `DMDRemote_${this.agentId}`, 'popup=yes,width=1280,height=820,resizable=yes,scrollbars=no');
            });
            if (this.close) this.close.addEventListener('click', () => {
                this.stop();
                if (this.options.detached) global.close();
            });
            global.addEventListener('resize', () => this.resizeCanvas());
            document.addEventListener('fullscreenchange', () => this.resizeCanvas());
            global.addEventListener('beforeunload', () => this.stop());
            this.installInput();
        }

        installInput() {
            if (!this.wantControl) return;
            const normalize = ev => {
                const r = this.canvas.getBoundingClientRect();
                if (!r.width || !r.height) return null;
                const x = Math.round(Math.max(0, Math.min(1, (ev.clientX - r.left) / r.width)) * 65535);
                const y = Math.round(Math.max(0, Math.min(1, (ev.clientY - r.top) / r.height)) * 65535);
                return { x, y };
            };
            this.canvas.addEventListener('contextmenu', ev => ev.preventDefault());
            this.canvas.addEventListener('pointermove', ev => {
                const point = normalize(ev);
                if (!point) return;
                this.pendingMove = point;
                if (!this.moveFrame) this.moveFrame = requestAnimationFrame(() => {
                    this.moveFrame = 0;
                    const value = this.pendingMove;
                    this.pendingMove = null;
                    if (value) this.sendControl('mouse.move', value);
                });
            });
            this.canvas.addEventListener('pointerdown', ev => {
                ev.preventDefault();
                this.stage.focus({ preventScroll: true });
                this.sendControl('mouse.button', { button: Number(ev.button), down: true });
            });
            this.canvas.addEventListener('pointerup', ev => {
                ev.preventDefault();
                this.sendControl('mouse.button', { button: Number(ev.button), down: false });
            });
            this.canvas.addEventListener('wheel', ev => {
                ev.preventDefault();
                this.sendControl('mouse.wheel', { delta: ev.deltaY < 0 ? 120 : -120 });
            }, { passive: false });
            this.stage.addEventListener('keydown', ev => {
                const altGraph = ev.getModifierState && ev.getModifierState('AltGraph');
                if (ev.key && ev.key.length === 1 && !ev.metaKey && (!ev.ctrlKey || altGraph) && (!ev.altKey || altGraph)) {
                    ev.preventDefault();
                    this.sendControl('key.text', { text: ev.key });
                    return;
                }
                const vk = keyCode(ev);
                if (!vk || this.pressed.has(vk)) return;
                this.pressed.add(vk);
                ev.preventDefault();
                this.sendControl('key.event', { vk, down: true });
            });
            this.stage.addEventListener('keyup', ev => {
                const vk = keyCode(ev);
                if (!vk) return;
                this.pressed.delete(vk);
                ev.preventDefault();
                this.sendControl('key.event', { vk, down: false });
            });
            global.addEventListener('blur', () => this.releasePressed());
        }

        releasePressed() {
            for (const vk of this.pressed) this.sendControl('key.event', { vk, down: false });
            this.pressed.clear();
        }

        async obtainTicket() {
            const u = new URL(this.options.ticketURL, global.location.href);
            u.searchParams.set('agent_id', this.agentId);
            const response = await fetch(u.toString(), { credentials: 'same-origin', cache: 'no-store' });
            const body = await response.json().catch(() => null);
            if (!response.ok || !body || !body.ok) throw new Error(body && body.error ? body.error : `Ticket Remote HTTP ${response.status}`);
            this.ticketExpiry = Number(body.expires_at || 0);
            return body;
        }

        async connect() {
            if (this.stopping) return;
            clearTimeout(this.reconnectTimer);
            clearTimeout(this.ticketRefresh);
            this.show('Connexion WebSocket…');
            const token = await this.obtainTicket();
            const videoURL = websocketURL(token.gateway_url, '/v2/view/video', token.ticket);
            const controlURL = websocketURL(token.gateway_url, '/v2/view/control', token.ticket);
            await Promise.all([this.openVideo(videoURL), this.openControl(controlURL)]);
            this.show('Canaux vidéo et contrôle connectés. Attente de la première IDR…');
            await this.refreshDisplays().catch(() => {});
            this.requestKeyframe();
            const renewIn = Math.max(30000, (this.ticketExpiry * 1000) - Date.now() - 30000);
            this.ticketRefresh = setTimeout(() => this.rotateConnections(), renewIn);
        }

        openVideo(url) {
            return new Promise((resolve, reject) => {
                const socket = new WebSocket(url);
                socket.binaryType = 'arraybuffer';
                const timer = setTimeout(() => { socket.close(); reject(new Error('Connexion vidéo WebSocket expirée')); }, 8000);
                socket.onopen = () => { clearTimeout(timer); this.videoSocket = socket; resolve(); };
                socket.onerror = () => { clearTimeout(timer); reject(new Error('Connexion vidéo WebSocket impossible')); };
                socket.onmessage = event => this.acceptVideo(event.data);
                socket.onclose = () => {
                    if (this.videoSocket === socket) this.videoSocket = null;
                    if (!this.stopping) this.scheduleReconnect();
                };
            });
        }

        openControl(url) {
            return new Promise((resolve, reject) => {
                const socket = new WebSocket(url);
                const timer = setTimeout(() => { socket.close(); reject(new Error('Connexion contrôle WebSocket expirée')); }, 8000);
                socket.onopen = () => { clearTimeout(timer); this.controlSocket = socket; resolve(); };
                socket.onerror = () => { clearTimeout(timer); reject(new Error('Connexion contrôle WebSocket impossible')); };
                socket.onmessage = event => this.acceptControl(event.data);
                socket.onclose = () => {
                    if (this.controlSocket === socket) this.controlSocket = null;
                    if (!this.stopping) this.scheduleReconnect();
                };
            });
        }

        scheduleReconnect() {
            if (this.reconnectTimer || this.stopping) return;
            this.show('Canal Remote interrompu, reconnexion…', true);
            this.reconnectTimer = setTimeout(() => {
                this.reconnectTimer = null;
                this.shutdownSockets();
                this.connect().catch(() => this.scheduleReconnect());
            }, 600);
        }

        rotateConnections() {
            if (this.stopping) return;
            this.shutdownSockets();
            this.connect().catch(() => this.scheduleReconnect());
        }

        shutdownSockets() {
            for (const socket of [this.videoSocket, this.controlSocket]) {
                try { if (socket) socket.close(1000, 'rotate'); } catch (_) {}
            }
            this.videoSocket = null;
            this.controlSocket = null;
            for (const [id, item] of this.pending) {
                clearTimeout(item.timer);
                item.reject(new Error('Canal contrôle fermé'));
                this.pending.delete(id);
            }
        }

        ensureDecoder(width, height) {
            if (this.decoder && this.decoderWidth === width && this.decoderHeight === height && this.decoder.state !== 'closed') return;
            if (this.decoder) {
                try { this.decoder.close(); } catch (_) {}
            }
            this.decoderWidth = width;
            this.decoderHeight = height;
            this.decoder = new VideoDecoder({
                output: frame => this.renderFrame(frame),
                error: error => {
                    this.show(`Décodage H.264 : ${error.message || error}`, true);
                    this.requestKeyframe();
                }
            });
            this.decoder.configure({ codec: 'avc1.42001f', codedWidth: width, codedHeight: height, optimizeForLatency: true, hardwareAcceleration: 'prefer-hardware' });
        }

        acceptVideo(raw) {
            const packet = packetFrom(raw);
            if (!packet || !packet.width || !packet.height) return;
            if (packet.sequence <= this.lastSequence && !packet.key) return;
            this.ensureDecoder(packet.width, packet.height);
            if (packet.key && this.decoder.decodeQueueSize > 2) {
                try { this.decoder.reset(); } catch (_) {}
                this.decoder.configure({ codec: 'avc1.42001f', codedWidth: packet.width, codedHeight: packet.height, optimizeForLatency: true, hardwareAcceleration: 'prefer-hardware' });
            }
            if (!packet.key && !this.firstFrame && this.decoder.decodeQueueSize > 4) return;
            try {
                this.decoder.decode(new EncodedVideoChunk({
                    type: packet.key ? 'key' : 'delta',
                    timestamp: packet.timestamp,
                    data: packet.h264
                }));
                this.lastSequence = packet.sequence;
            } catch (e) {
                this.show(`Paquet H.264 refusé : ${e.message || e}`, true);
                this.requestKeyframe();
            }
        }

        renderFrame(frame) {
            try {
                if (this.canvas.width !== frame.displayWidth || this.canvas.height !== frame.displayHeight) {
                    this.canvas.width = frame.displayWidth;
                    this.canvas.height = frame.displayHeight;
                    this.resizeCanvas();
                }
                this.context.drawImage(frame, 0, 0, this.canvas.width, this.canvas.height);
                if (!this.firstFrame) {
                    this.firstFrame = true;
                    if (this.spinner) this.spinner.hidden = true;
                    this.show('Remote H.264 actif.');
                }
                this.frameCounter++;
                const now = performance.now();
                if (now - this.frameWindowStart >= 1000) {
                    this.fps = Math.round(this.frameCounter * 1000 / (now - this.frameWindowStart));
                    this.frameCounter = 0;
                    this.frameWindowStart = now;
                    if (this.stats) this.stats.textContent = `${this.canvas.width}×${this.canvas.height} · ${this.fps} fps · H.264/WSS`;
                }
            } finally {
                frame.close();
            }
        }

        resizeCanvas() {
            if (!this.canvas.width || !this.canvas.height) return;
            const mode = this.fitMode ? this.fitMode.value : 'fit';
            if (mode === 'native') {
                this.canvas.style.width = `${this.canvas.width}px`;
                this.canvas.style.height = `${this.canvas.height}px`;
                return;
            }
            const box = this.stage.getBoundingClientRect();
            const ratio = Math.min(box.width / this.canvas.width, box.height / this.canvas.height);
            this.canvas.style.width = `${Math.max(1, Math.floor(this.canvas.width * ratio))}px`;
            this.canvas.style.height = `${Math.max(1, Math.floor(this.canvas.height * ratio))}px`;
        }

        acceptControl(raw) {
            let message;
            try { message = JSON.parse(String(raw)); } catch (_) { return; }
            if (message.type === 'error') {
                this.show(String(message.message || 'Commande Remote refusée'), true);
                return;
            }
            if (message.type !== 'result' || !message.request_id) return;
            const item = this.pending.get(message.request_id);
            if (!item) return;
            clearTimeout(item.timer);
            this.pending.delete(message.request_id);
            if (message.ok) item.resolve(message.data || {});
            else item.reject(new Error(String(message.error || 'Commande Remote refusée')));
        }

        sendControl(op, data) {
            const socket = this.controlSocket;
            if (!socket || socket.readyState !== WebSocket.OPEN) return false;
            socket.send(JSON.stringify({ type: 'control', op, request_id: uid(), data: data || {} }));
            return true;
        }

        command(op, data, timeout) {
            return new Promise((resolve, reject) => {
                const socket = this.controlSocket;
                if (!socket || socket.readyState !== WebSocket.OPEN) { reject(new Error('Canal contrôle non connecté')); return; }
                const id = uid();
                const timer = setTimeout(() => {
                    this.pending.delete(id);
                    reject(new Error(`Commande ${op} expirée`));
                }, timeout || 4000);
                this.pending.set(id, { resolve, reject, timer });
                socket.send(JSON.stringify({ type: 'control', op, request_id: id, data: data || {} }));
            });
        }

        requestKeyframe() {
            if (!this.sendControl('stream.keyframe', {})) return;
        }

        async refreshDisplays() {
            if (!this.display) return;
            const data = await this.command('display.list', {});
            const rows = Array.isArray(data) ? data : (Array.isArray(data.displays) ? data.displays : []);
            this.display.innerHTML = '';
            for (const item of rows) {
                const option = document.createElement('option');
                option.value = String(Number(item.index || 0));
                option.textContent = `Écran ${Number(item.index || 0) + 1} · ${Number(item.width || 0)}×${Number(item.height || 0)}${item.primary ? ' · principal' : ''}`;
                this.display.appendChild(option);
            }
            if (!rows.length) {
                const option = document.createElement('option');
                option.value = '';
                option.textContent = 'Aucun écran';
                this.display.appendChild(option);
            }
        }

        show(text, error) {
            if (!this.status) return;
            this.status.textContent = String(text || '');
            this.status.classList.toggle('error', Boolean(error));
        }

        stop() {
            if (this.stopping) return;
            this.stopping = true;
            clearTimeout(this.reconnectTimer);
            clearTimeout(this.ticketRefresh);
            if (this.moveFrame) cancelAnimationFrame(this.moveFrame);
            this.releasePressed();
            this.shutdownSockets();
            if (this.decoder) {
                try { this.decoder.close(); } catch (_) {}
                this.decoder = null;
            }
        }
    }

    async function mount(root, options) {
        const app = new RemoteV2(root, options);
        try {
            await app.start();
        } catch (error) {
            app.show(error.message || String(error), true);
            const wait = root.querySelector('[data-rv2-wait]');
            if (wait) { wait.hidden = false; wait.textContent = error.message || String(error); }
        }
        return app;
    }

    global.DMDRemoteV2 = { mount };
})(window);
