<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$email = dmd_remoteagent_email();
if ($email === '') {
    echo '<section class="dram-denied">Non connecté.</section>';
    return;
}
dmd_require_module_access(DMD_REMOTEAGENT_MODULE_ID, 'use');

$documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? '')) ?: '';
$moduleDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-RemoteAgent';
if ($documentRoot !== '' && strpos(str_replace('\\', '/', $moduleDir), str_replace('\\', '/', $documentRoot)) === 0) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleDir, strlen($documentRoot))), '/');
}
$moduleWebPath = rtrim($moduleWebPath, '/');
$baseWeb = preg_replace('~/modules/DMD-RemoteAgent$~i', '', $moduleWebPath) ?: '';

$safeUser = function_exists('dmd_safe_user_key') ? dmd_safe_user_key($email) : basename($email);
$theme = 'default';
$themeFile = rtrim($documentRoot, DIRECTORY_SEPARATOR) . '/users/profiles/' . $safeUser . '/theme.json';
if ($safeUser !== '' && is_file($themeFile)) {
    $themeData = json_decode((string)@file_get_contents($themeFile), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidate = basename((string)$themeData['theme']);
        if (is_file(rtrim($documentRoot, DIRECTORY_SEPARATOR) . '/theme/' . $candidate . '/style.css')) {
            $theme = $candidate;
        }
    }
}

$themeUrl = rtrim($baseWeb, '/') . '/theme/' . rawurlencode($theme) . '/style.css';
$csrf = dmd_csrf_token('dmd_remoteagent');
$security = dmd_remoteagent_security_state($email);
$cssVer = (string)@filemtime(__DIR__ . '/DMD-RemoteAgent-mydesk.css');
$jsVer = (string)@filemtime(__DIR__ . '/DMD-RemoteAgent-mydesk.js');
$uid = 'dram_' . bin2hex(random_bytes(5));
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWebPath . '/DMD-RemoteAgent-mydesk.css?v=' . rawurlencode($cssVer), ENT_QUOTES, 'UTF-8') ?>">

<section
    id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
    class="dram-app"
    data-dram-root
    data-api="<?= htmlspecialchars($moduleWebPath . '/DMD-RemoteAgent_api.php', ENT_QUOTES, 'UTF-8') ?>"
    data-detached="<?= htmlspecialchars($moduleWebPath . '/DMD-RemoteAgent_detached.php', ENT_QUOTES, 'UTF-8') ?>"
    data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"
>
    <header class="dram-head">
        <div class="dram-brand">
            <img src="<?= htmlspecialchars($moduleWebPath . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt="">
            <div>
                <strong>DMD-RemoteAgent</strong>
                <small data-dram-head-state>Choisissez un PC</small>
            </div>
        </div>
        <button type="button" class="dram-icon-btn" data-dram-refresh aria-label="Actualiser">↻</button>
    </header>

    <section class="dram-security" data-dram-security <?= !empty($security['unlocked']) ? 'hidden' : '' ?>>
        <div class="dram-security-card">
            <span class="dram-security-icon">🔐</span>
            <strong>DMD-RemoteAgent verrouillé</strong>
            <p data-dram-security-message>Une validation MFA est requise pour utiliser le module.</p>
            <form data-dram-mfa-form>
                <input type="text" inputmode="numeric" autocomplete="one-time-code" data-dram-mfa-code placeholder="Code MFA ou code de secours" required>
                <button type="submit" class="dram-btn dram-primary">Déverrouiller</button>
            </form>
            <small data-dram-mfa-error></small>
        </div>
    </section>

    <section class="dram-main" data-dram-main <?= empty($security['unlocked']) ? 'hidden' : '' ?>>
        <div class="dram-picker">
            <label>
                <span>PC à administrer</span>
                <select data-dram-device>
                    <option value="">Choisir un PC…</option>
                </select>
            </label>
        </div>

        <section class="dram-welcome" data-dram-welcome>
            <div class="dram-welcome-icon">🖥️</div>
            <strong>Bienvenue dans DMD-RemoteAgent</strong>
            <p>Sélectionnez un PC dans le menu ci-dessus. MyDesk affichera uniquement les informations et les actions utiles pour ce poste.</p>
            <div class="dram-welcome-steps">
                <div><span>1</span><p>Choisissez un PC autorisé.</p></div>
                <div><span>2</span><p>Consultez son état, son IP, son système et l’agent installé.</p></div>
                <div><span>3</span><p>Lancez ensuite Remote, une commande terminal ou une action système selon vos droits.</p></div>
            </div>
        </section>

        <section class="dram-device" data-dram-device-view hidden>
            <div class="dram-device-head">
                <div class="dram-device-icon">🖥️</div>
                <div class="dram-device-title">
                    <strong data-dram-hostname>PC</strong>
                    <span data-dram-status>—</span>
                </div>
                <button type="button" class="dram-btn" data-dram-report>Actualiser le rapport</button>
            </div>

            <div class="dram-machine-line">
                <span data-dram-os-line>—</span>
                <span data-dram-ip-line>—</span>
                <span data-dram-agent-line>—</span>
                <span data-dram-contact-line>—</span>
            </div>

            <div class="dram-metrics">
                <article>
                    <span>CPU</span>
                    <strong data-dram-cpu-usage>—</strong>
                    <small data-dram-cpu-short>—</small>
                </article>
                <article>
                    <span>RAM</span>
                    <strong data-dram-ram-usage>—</strong>
                    <small data-dram-ram-short>—</small>
                </article>
                <article>
                    <span>Uptime</span>
                    <strong data-dram-uptime>—</strong>
                    <small data-dram-last-boot>Dernier démarrage —</small>
                </article>
                <article>
                    <span>Commandes</span>
                    <strong data-dram-pending>0</strong>
                    <small>en attente</small>
                </article>
            </div>

            <nav class="dram-tabs">
                <button type="button" class="is-active" data-dram-tab="overview">Aperçu</button>
                <button type="button" data-dram-tab="remote">Remote</button>
                <button type="button" data-dram-tab="terminal">Terminal</button>
                <button type="button" data-dram-tab="system">Système</button>
            </nav>

            <div class="dram-pane" data-dram-pane="overview">
                <section class="dram-panel">
                    <header><strong>Session et accès</strong></header>
                    <div class="dram-session">
                        <article>
                            <span>Session active</span>
                            <strong data-dram-session>—</strong>
                        </article>
                        <article>
                            <span>Domaine / Workgroup</span>
                            <strong data-dram-domain>—</strong>
                        </article>
                        <article>
                            <span>Groupes</span>
                            <div class="dram-tags" data-dram-groups></div>
                        </article>
                    </div>
                </section>

                <details class="dram-tech">
                    <summary>Détails techniques</summary>
                    <div class="dram-tech-body">
                        <div class="dram-info" data-dram-info></div>
                    </div>
                </details>
            </div>

            <div class="dram-pane" data-dram-pane="remote" hidden>
                <section class="dram-panel">
                    <header>
                        <div>
                            <strong>Remote</strong>
                            <small>Ouvre l’écran du PC dans une fenêtre indépendante.</small>
                        </div>
                    </header>
                    <div class="dram-action-grid">
                        <button type="button" class="dram-action" data-dram-operation="remote.screen">
                            <span>👁️</span>
                            <strong>Voir l’écran</strong>
                            <small>Visualisation uniquement</small>
                        </button>
                        <button type="button" class="dram-action" data-dram-operation="remote.control">
                            <span>🖱️</span>
                            <strong>Prendre le contrôle</strong>
                            <small>Clavier et souris</small>
                        </button>
                    </div>
                    <div class="dram-result" data-dram-remote-result>Choisissez une action Remote.</div>
                </section>
            </div>

            <div class="dram-pane" data-dram-pane="terminal" hidden>
                <section class="dram-panel">
                    <header>
                        <div>
                            <strong>Terminal</strong>
                            <small>Commande distante exécutée par DMD-Agent.</small>
                        </div>
                    </header>
                    <textarea data-dram-command rows="4" placeholder="Ex. hostname"></textarea>
                    <button type="button" class="dram-btn dram-primary dram-full" data-dram-terminal-run>Exécuter</button>
                    <pre class="dram-terminal-output" data-dram-terminal-output>Aucune commande exécutée.</pre>
                </section>
            </div>

            <div class="dram-pane" data-dram-pane="system" hidden>
                <section class="dram-panel">
                    <header><strong>Actions système</strong></header>
                    <div class="dram-action-grid">
                        <button type="button" class="dram-action" data-dram-operation="system.restart" data-confirm="Redémarrer ce PC ?">
                            <span>↻</span>
                            <strong>Redémarrer</strong>
                            <small>Redémarrage distant</small>
                        </button>
                        <button type="button" class="dram-action" data-dram-operation="system.shutdown" data-confirm="Éteindre ce PC ?">
                            <span>⏻</span>
                            <strong>Éteindre</strong>
                            <small>Arrêt distant</small>
                        </button>
                        <button type="button" class="dram-action" data-dram-operation="agent.update">
                            <span>⇧</span>
                            <strong>Mettre à jour</strong>
                            <small>DMD-Agent stable</small>
                        </button>
                    </div>
                    <div class="dram-result" data-dram-system-result>Prêt.</div>
                </section>
            </div>
        </section>
    </section>

    <div class="dram-toast" data-dram-toast hidden></div>
</section>

<script>
window.DMD_REMOTEAGENT_MYDESK_BOOT = <?= json_encode(array(
    'security' => $security,
    'csrf' => $csrf
), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
</script>
<script src="<?= htmlspecialchars($moduleWebPath . '/DMD-RemoteAgent-mydesk.js?v=' . rawurlencode($jsVer), ENT_QUOTES, 'UTF-8') ?>"></script>
