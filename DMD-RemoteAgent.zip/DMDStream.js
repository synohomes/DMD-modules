/* DMDStream / H.264 viewer — Remote H264 v2
 * WebCodecs primary decoder + MediaSource/fMP4 fallback for HTTP/non-secure DoMyDesk.
 */
(function(){
'use strict';

const te = new TextEncoder();
function u8(...v){return new Uint8Array(v);}
function u16(v){return u8((v>>>8)&255,v&255);}
function u24(v){return u8((v>>>16)&255,(v>>>8)&255,v&255);}
function u32(v){return u8((v>>>24)&255,(v>>>16)&255,(v>>>8)&255,v&255);}
function str4(s){return te.encode(s);}
function cat(...parts){
  const list=parts.filter(Boolean), n=list.reduce((a,p)=>a+p.length,0), out=new Uint8Array(n);
  let o=0; for(const p of list){out.set(p,o);o+=p.length;} return out;
}
function box(type,...payload){const body=cat(...payload);return cat(u32(body.length+8),str4(type),body);}
function fullBox(type,version,flags,...payload){return box(type,u8(version),u24(flags),...payload);}
function zeros(n){return new Uint8Array(n);}
function matrix(){return cat(u32(0x00010000),u32(0),u32(0),u32(0),u32(0x00010000),u32(0),u32(0),u32(0),u32(0x40000000));}

function splitAnnexB(data){
  const out=[]; let i=0, start=-1;
  const is3=p=>p+2<data.length&&data[p]===0&&data[p+1]===0&&data[p+2]===1;
  const is4=p=>p+3<data.length&&data[p]===0&&data[p+1]===0&&data[p+2]===0&&data[p+3]===1;
  while(i<data.length){
    let sc=0;if(is4(i))sc=4;else if(is3(i))sc=3;
    if(sc){
      if(start>=0&&i>start)out.push(data.slice(start,i));
      start=i+sc;i+=sc;continue;
    }
    i++;
  }
  if(start>=0&&start<data.length)out.push(data.slice(start));
  if(!out.length&&data.length)out.push(data);
  return out.filter(n=>n.length>0);
}
function h264Params(nals){
  let sps=null,pps=null;
  for(const n of nals){const t=n[0]&31;if(t===7&&!sps)sps=n;else if(t===8&&!pps)pps=n;}
  return {sps,pps};
}
function avcCodecFromSPS(sps){
  if(!sps||sps.length<4)return 'avc1.42E01E';
  return 'avc1.'+[sps[1],sps[2],sps[3]].map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();
}
function avcc(sps,pps){
  if(!sps||!pps||sps.length<4)throw new Error('SPS/PPS H.264 absents');
  return box('avcC',cat(
    u8(1,sps[1],sps[2],sps[3],0xff,0xe1),u16(sps.length),sps,u8(1),u16(pps.length),pps
  ));
}
function avccSample(nals){
  const parts=[];
  for(const n of nals){
    const t=n[0]&31;
    if(t===7||t===8)continue; // déjà dans avcC
    parts.push(u32(n.length),n);
  }
  return cat(...parts);
}
function mp4Init(width,height,sps,pps,timescale=90000,frameDuration=3000){
  const codecBox=avcc(sps,pps);
  const compressor=new Uint8Array(32); const name='DMD-Remote H264'; compressor[0]=Math.min(31,name.length); compressor.set(te.encode(name.slice(0,31)),1);
  const avc1=box('avc1',cat(
    zeros(6),u16(1),u16(0),u16(0),u32(0),u32(0),u32(0),
    u16(width),u16(height),u32(0x00480000),u32(0x00480000),u32(0),u16(1),compressor,u16(0x0018),u16(0xffff),codecBox
  ));
  const stsd=fullBox('stsd',0,0,u32(1),avc1);
  const stbl=box('stbl',stsd,fullBox('stts',0,0,u32(0)),fullBox('stsc',0,0,u32(0)),fullBox('stsz',0,0,u32(0),u32(0)),fullBox('stco',0,0,u32(0)));
  const dref=fullBox('dref',0,0,u32(1),fullBox('url ',0,1));
  const dinf=box('dinf',dref);
  const vmhd=fullBox('vmhd',0,1,u16(0),u16(0),u16(0),u16(0));
  const minf=box('minf',vmhd,dinf,stbl);
  const mdhd=fullBox('mdhd',0,0,u32(0),u32(0),u32(timescale),u32(0),u16(0x55c4),u16(0));
  const hdlr=fullBox('hdlr',0,0,u32(0),str4('vide'),zeros(12),te.encode('VideoHandler\0'));
  const mdia=box('mdia',mdhd,hdlr,minf);
  const tkhd=fullBox('tkhd',0,7,u32(0),u32(0),u32(1),u32(0),u32(0),zeros(8),u16(0),u16(0),u16(0),u16(0),matrix(),u32(width<<16),u32(height<<16));
  const trak=box('trak',tkhd,mdia);
  const mvhd=fullBox('mvhd',0,0,u32(0),u32(0),u32(1000),u32(0),u32(0x00010000),u16(0x0100),u16(0),zeros(8),matrix(),zeros(24),u32(2));
  const trex=fullBox('trex',0,0,u32(1),u32(1),u32(frameDuration),u32(0),u32(0));
  const moov=box('moov',mvhd,trak,box('mvex',trex));
  const ftyp=box('ftyp',str4('isom'),u32(0x200),str4('isom'),str4('iso6'),str4('avc1'),str4('mp41'));
  return cat(ftyp,moov);
}
function mp4Fragment(trackSeq,baseTime,duration,sample,key){
  const sampleFlags=key?0x02000000:0x01010000;
  const mfhd=fullBox('mfhd',0,0,u32(trackSeq));
  const tfhd=fullBox('tfhd',0,0x020000,u32(1));
  const tfdt=fullBox('tfdt',0,0,u32(baseTime>>>0));
  let trun=fullBox('trun',0,0x000701,u32(1),u32(0),u32(duration),u32(sample.length),u32(sampleFlags));
  let moof=box('moof',mfhd,box('traf',tfhd,tfdt,trun));
  const dataOffset=moof.length+8;
  trun=fullBox('trun',0,0x000701,u32(1),u32(dataOffset),u32(duration),u32(sample.length),u32(sampleFlags));
  moof=box('moof',mfhd,box('traf',tfhd,tfdt,trun));
  return cat(moof,box('mdat',sample));
}

class DMDStreamViewer {
  constructor(canvas){
    if(!canvas) throw new Error('Canvas Remote absent');
    this.canvas=canvas;
    this.ctx=canvas.getContext('2d',{alpha:false,desynchronized:true});
    this.sequence=0;this.baseSequence=0;this.width=0;this.height=0;this.waitingKeyframe=true;this.lastError='';
    this.mode='';this.decoder=null;this.decoderReady=false;this.decoderCodec='avc1.42E028';
    this.outputCount=0;this.queuedCount=0;this.lastOutputAt=0;this.pendingOutput=null;this.pendingOutputResolve=null;
    this.video=null;this.mediaSource=null;this.sourceBuffer=null;this.mseURL='';this.mseQueue=[];this.mseAppending=false;
    this.mseInit=false;this.mseSPS=null;this.msePPS=null;this.mseCodec='';this.mseFragSeq=1;this.mseTime=0;this.mseFrameDuration=3000;this.mseResetNeeded=false;this.drawStarted=false;this.mseStarted=false;
  }

  fail(message){this.lastError=String(message||'Paquet refusé');return null;}
  base64Bytes(value){const bin=atob(String(value||'')),out=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);return out;}

  noteOutput(w,h){
    if(w>0&&h>0){
      if(this.canvas.width!==w)this.canvas.width=w;
      if(this.canvas.height!==h)this.canvas.height=h;
      this.width=w;this.height=h;this.outputCount++;this.lastOutputAt=performance.now();
    }
    if(this.pendingOutputResolve){const r=this.pendingOutputResolve;this.pendingOutputResolve=null;this.pendingOutput=null;r(true);}
  }

  async ensureH264Decoder(){
    if(this.mode==='mse')return false;
    if(this.decoderReady&&this.decoder&&this.decoder.state!=='closed')return true;
    if(typeof VideoDecoder!=='function'){
      this.mode='mse';
      return false;
    }
    this.mode='webcodecs';
    this.canvas.style.opacity='1';
    const config={codec:this.decoderCodec,optimizeForLatency:true,hardwareAcceleration:'prefer-hardware'};
    if(typeof VideoDecoder.isConfigSupported==='function'){
      const support=await VideoDecoder.isConfigSupported(config);
      if(!support||!support.supported){this.mode='mse';return false;}
    }
    if(this.decoder&&this.decoder.state!=='closed'){try{this.decoder.close();}catch(_){}}
    this.decoder=new VideoDecoder({
      output:(frame)=>{
        try{
          const w=Number(frame.displayWidth||frame.codedWidth||0)|0,h=Number(frame.displayHeight||frame.codedHeight||0)|0;
          if(w>0&&h>0){this.ctx.drawImage(frame,0,0,w,h);this.noteOutput(w,h);}
        }catch(e){this.lastError=`rendu H264: ${e&&e.message?e.message:e}`;}
        finally{try{frame.close();}catch(_){}}
      },
      error:(e)=>{this.lastError=`décodeur H264: ${e&&e.message?e.message:e}`;this.waitingKeyframe=true;this.decoderReady=false;if(this.pendingOutputResolve){const r=this.pendingOutputResolve;this.pendingOutputResolve=null;this.pendingOutput=null;r(false);}}
    });
    this.decoder.configure(config);this.decoderReady=true;return true;
  }

  async setupMSE(width,height,nals){
    const {sps,pps}=h264Params(nals);
    if(!sps||!pps)throw new Error('H264 MSE: IDR sans SPS/PPS');
    const codec=avcCodecFromSPS(sps), mime=`video/mp4; codecs="${codec}"`;
    if(typeof MediaSource!=='function'||typeof MediaSource.isTypeSupported!=='function'||!MediaSource.isTypeSupported(mime)){
      throw new Error(`H264 navigateur indisponible (WebCodecs et MSE ${codec})`);
    }
    this.closeMSE(true);
    this.mode='mse';this.mseSPS=sps;this.msePPS=pps;this.mseCodec=codec;this.mseFragSeq=1;this.mseTime=0;this.mseQueue=[];this.mseAppending=false;this.mseInit=false;
    const video=document.createElement('video');
    video.muted=true;video.autoplay=true;video.playsInline=true;video.preload='auto';
    video.className='dmd-h264-mse-video';
    video.style.cssText='position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000;pointer-events:none;z-index:1';
    const parent=this.canvas.parentElement||document.body;
    try{if(getComputedStyle(parent).position==='static')parent.style.position='relative';}catch(_){ }
    parent.insertBefore(video,this.canvas);this.video=video;
    this.canvas.style.position='relative';this.canvas.style.zIndex='2';this.canvas.style.opacity='0';this.canvas.style.background='transparent';
    const ms=new MediaSource();this.mediaSource=ms;this.mseURL=URL.createObjectURL(ms);video.src=this.mseURL;
    await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(new Error('H264 MSE: sourceopen timeout')),3000);
      ms.addEventListener('sourceopen',()=>{clearTimeout(timer);resolve();},{once:true});
    });
    const sb=ms.addSourceBuffer(mime);sb.mode='segments';this.sourceBuffer=sb;
    sb.addEventListener('updateend',()=>this.pumpMSE());
    sb.addEventListener('error',()=>{this.lastError='H264 MSE: SourceBuffer error';});
    this.enqueueMSE(mp4Init(width,height,sps,pps,90000,this.mseFrameDuration));
    this.mseInit=true;this.startMSEDraw();
    try{await video.play();}catch(_){ }
  }

  startMSEDraw(){
    if(this.drawStarted||!this.video)return;this.drawStarted=true;
    const tick=()=>{
      if(!this.video||this.mode!=='mse'){this.drawStarted=false;return;}
      try{
        if(this.video.videoWidth>0&&this.video.videoHeight>0)this.noteOutput(this.video.videoWidth,this.video.videoHeight);
        const b=this.video.buffered;
        if(b&&b.length){
          const start=b.start(0),end=b.end(b.length-1),lag=Math.max(0,end-this.video.currentTime);
          if(!this.mseStarted&&end>start){this.video.currentTime=Math.max(start,end-0.03);this.mseStarted=true;}
          else if(lag>0.55)this.video.currentTime=Math.max(start,end-0.06);
          this.video.playbackRate=lag>0.18?1.08:1.0;
        }
        if(this.video.paused)this.video.play().catch(()=>{});
      }catch(e){this.lastError=`rendu MSE: ${e&&e.message?e.message:e}`;}
      setTimeout(tick,50);
    };
    this.video.addEventListener('loadeddata',()=>{if(this.video&&this.video.videoWidth>0)this.noteOutput(this.video.videoWidth,this.video.videoHeight);},{passive:true});
    this.video.addEventListener('playing',()=>{if(this.video&&this.video.videoWidth>0)this.noteOutput(this.video.videoWidth,this.video.videoHeight);},{passive:true});
    tick();
  }

  enqueueMSE(bytes){this.mseQueue.push(bytes);this.pumpMSE();}
  pumpMSE(){
    const sb=this.sourceBuffer;if(!sb||sb.updating||this.mseAppending)return;
    if(!this.mseQueue.length){
      if(this.video&&this.video.paused){this.video.play().catch(()=>{});}return;
    }
    const next=this.mseQueue.shift();
    try{this.mseAppending=true;sb.appendBuffer(next);}catch(e){this.mseAppending=false;this.lastError=`H264 MSE append: ${e&&e.message?e.message:e}`;return;}
    const done=()=>{this.mseAppending=false;sb.removeEventListener('updateend',done);this.pumpMSE();};
    sb.addEventListener('updateend',done,{once:true});
  }

  closeMSE(remove=true){
    if(this.video){try{this.video.pause();this.video.removeAttribute('src');this.video.load();}catch(_){ }if(remove)try{this.video.remove();}catch(_){ }}
    if(this.mseURL){try{URL.revokeObjectURL(this.mseURL);}catch(_){ }}
    this.video=null;this.mediaSource=null;this.sourceBuffer=null;this.mseURL='';this.mseQueue=[];this.mseAppending=false;this.mseInit=false;this.drawStarted=false;this.mseStarted=false;
    if(this.canvas){this.canvas.style.opacity='1';this.canvas.style.background='#000';}
  }

  async pushH264WebCodecs(packet,raw,key,seq){
    if(key&&this.decoder&&this.decoder.state==='configured'&&this.sequence>0){try{this.decoder.reset();this.decoder.configure({codec:this.decoderCodec,optimizeForLatency:true,hardwareAcceleration:'prefer-hardware'});}catch(_){}}
    const timestamp=seq*33333;
    try{this.decoder.decode(new EncodedVideoChunk({type:key?'key':'delta',timestamp,data:raw}));}
    catch(e){this.lastError=`decode H264 seq ${seq}: ${e&&e.message?e.message:e}`;this.waitingKeyframe=true;return false;}
    return true;
  }

  async pushH264MSE(packet,raw,key,seq){
    const nals=splitAnnexB(raw);
    if((!this.mseInit||this.mseResetNeeded)&&!key){this.lastError=`H264 MSE delta ${seq} avant IDR`;return false;}
    if(!this.mseInit||this.mseResetNeeded){
      await this.setupMSE(Number(packet.width)||this.width||1366,Number(packet.height)||this.height||768,nals);
      this.mseResetNeeded=false;
    }
    const sample=avccSample(nals);if(!sample.length){this.lastError=`H264 MSE paquet ${seq} sans slice`;return false;}
    this.enqueueMSE(mp4Fragment(this.mseFragSeq++,this.mseTime,this.mseFrameDuration,sample,key));
    this.mseTime=(this.mseTime+this.mseFrameDuration)>>>0;
    if(this.video&&this.video.paused)this.video.play().catch(()=>{});
    return true;
  }

  async pushH264(packet){
    const seq=Number(packet&&packet.sequence)||0;if(seq<=0||seq<=this.sequence)return false;
    const key=!!packet.keyframe;
    if(this.sequence>0&&seq!==this.sequence+1&&!key){this.waitingKeyframe=true;this.lastError=`H264 séquence ${this.sequence} -> ${seq}, IDR attendue`;return false;}
    if(this.sequence>0&&seq!==this.sequence+1&&key&&this.mode==='mse')this.mseResetNeeded=true;
    if(this.waitingKeyframe&&!key){this.lastError=`H264 delta ${seq} reçu avant IDR`;return false;}
    const raw=this.base64Bytes(packet.stream_base64);if(raw.length<5){this.lastError=`H264 paquet ${seq} vide`;return false;}
    const web=await this.ensureH264Decoder();
    let ok=false;
    if(web)ok=await this.pushH264WebCodecs(packet,raw,key,seq);
    else ok=await this.pushH264MSE(packet,raw,key,seq);
    if(!ok)return false;
    this.sequence=seq;if(key){this.baseSequence=seq;this.waitingKeyframe=false;}
    this.width=Number(packet.width)||this.width;this.height=Number(packet.height)||this.height;this.queuedCount++;this.lastError='';return true;
  }

  async waitForOutput(timeoutMs=160){
    const before=this.outputCount;if(before>0&&performance.now()-this.lastOutputAt<45)return true;
    if(this.pendingOutput)return this.pendingOutput;
    this.pendingOutput=new Promise(resolve=>{this.pendingOutputResolve=resolve;setTimeout(()=>{if(this.pendingOutputResolve===resolve){this.pendingOutputResolve=null;this.pendingOutput=null;resolve(this.outputCount>before);}},timeoutMs);});
    return this.pendingOutput;
  }

  softResync(){
    this.sequence=0;this.baseSequence=0;this.waitingKeyframe=true;this.lastError='';
    if(this.mode==='webcodecs'&&this.decoder&&this.decoder.state==='configured'){try{this.decoder.reset();this.decoder.configure({codec:this.decoderCodec,optimizeForLatency:true,hardwareAcceleration:'prefer-hardware'});}catch(_){}}
    if(this.mode==='mse')this.mseResetNeeded=true;
  }
  reset(){
    this.softResync();if(this.decoder){try{this.decoder.close();}catch(_){ }this.decoder=null;this.decoderReady=false;}this.closeMSE(true);this.mode='';
    if(this.ctx&&this.canvas){this.canvas.width=1;this.canvas.height=1;this.ctx.clearRect(0,0,1,1);}
  }
  async push(packet){const codec=String(packet&&packet.stream_codec||'').toLowerCase();if(codec!=='dmd-h264-annexb-v1')return !!this.fail(`codec Remote non H264: ${codec||'absent'}`);return this.pushH264(packet);}
  async pushBatch(packets){
    const list=Array.isArray(packets)?packets:[];let queued=0;
    for(const packet of list){const codec=String(packet&&packet.stream_codec||'').toLowerCase();if(codec!=='dmd-h264-annexb-v1'){this.lastError=`codec inattendu ${codec||'absent'} — H.264 requis`;continue;}try{if(await this.pushH264(packet))queued++;}catch(e){this.lastError=String(e&&e.message?e.message:e);this.waitingKeyframe=true;break;}}
    if(queued>0&&this.outputCount===0)await this.waitForOutput(this.mode==='mse'?90:70);
    return {rendered:queued>0,sequence:this.sequence,base_sequence:this.baseSequence,width:this.width,height:this.height,waiting_keyframe:this.waitingKeyframe,error:this.lastError,codec:dmdH264CodecName(),decoder:this.mode||'initialisation'};
  }
}
function dmdH264CodecName(){return 'dmd-h264-annexb-v1';}
window.DMDStreamViewer=DMDStreamViewer;
})();
