(function(){
'use strict';
const boot = window.DMD_REMOTEAGENT_BOOT || {};
const app = document.getElementById('dmdRemoteAgentApp');
if (!app || app.dataset.dmdRaReady === '1') return;
app.dataset.dmdRaReady = '1';
let devices = Array.isArray(boot.devices) ? boot.devices : [];
let current = null;
let currentTab = 'overview';
let touchStamp = Object.create(null);
let touchTimer = null;
const list = document.getElementById('dmdRaList');
const empty = document.getElementById('dmdRaEmpty');
const modal = document.getElementById('dmdRaModal');
const modalWindow = modal ? modal.querySelector('.dmd-ra-window') : null;
let security = boot.security && typeof boot.security === 'object' ? boot.security : {enabled:false,required:false,unlocked:true,session_minutes:15,account_mfa:false,expires_at:0,blocked_reason:''};
let securityTimer = null;
let floatingRemotes = new Map();

function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
function formatBytes(bytes){const n=Number(bytes||0);if(!Number.isFinite(n)||n<=0)return '—';const u=['o','Ko','Mo','Go','To'];let i=0,v=n;while(v>=1024&&i<u.length-1){v/=1024;i++;}return `${v>=10||i===0?v.toFixed(0):v.toFixed(1)} ${u[i]}`;}
function formatDate(v){if(!v)return '—';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('fr-FR');}
const FILE_CHUNK=28672,FILE_BATCH=8,FILE_MAX=64*1024*1024;
let remoteTimer=null,remoteSeq=0,remoteControl=false,remoteWidth=0,remoteHeight=0,remoteLastMove=0,remoteMovePending=null,remoteInputQueue=[],remoteInputTimer=null,remoteInputBusy=false,remoteImageUrl='';
function base64ToBytes(value){const bin=atob(String(value||''));const out=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);return out;}
function bytesToBase64(bytes){let out='';const step=8192;for(let i=0;i<bytes.length;i+=step){const part=bytes.subarray(i,Math.min(i+step,bytes.length));out+=String.fromCharCode.apply(null,part);}return btoa(out);}
function winJoin(base,name){base=String(base||'').replace(/[\\/]+$/,'');return base+'\\'+String(name||'');}
function fileTransferStatus(text,done,total){const el=document.getElementById('dmdRaFileTransfer');if(!el)return;el.hidden=false;const pct=total>0?Math.min(100,Math.round((done/total)*100)):100;el.innerHTML=`<strong>${esc(text)}</strong><span>${esc(formatBytes(done))} / ${esc(formatBytes(total))} · ${pct}%</span>`;}
function clearFileTransfer(){const el=document.getElementById('dmdRaFileTransfer');if(el){el.hidden=true;el.textContent='';}}
function hasPerm(permission){if(!current)return false;if(boot.isSuperadmin)return true;return Array.isArray(current.permissions)&&current.permissions.includes(permission);}
function hasAny(csv){if(!csv)return true;return csv.split(',').map(x=>x.trim()).filter(Boolean).some(hasPerm);}
function deviceById(id){return devices.find(d=>String(d.agent_id||'')===String(id||''))||null;}

function securityBlockedMessage(state){
 const reason=String(state&&state.blocked_reason||'');
 if(reason==='mfa_not_configured')return 'Active le MFA dans ton profil avant d’utiliser DMD-RemoteAgent.';
 if(reason==='mfa_disabled_by_policy')return 'Le MFA est désactivé pour ce compte par la politique DoMyDesk.';
 if(reason==='mfa_unavailable')return 'Le moteur MFA central DoMyDesk est indisponible.';
 return 'Saisis ton code Microsoft Authenticator pour déverrouiller le module.';
}
function securityCloseRemoteUi(){
 stopRemoteBrowser();
 for(const agentId of Array.from(floatingRemotes.keys())){try{closeFloatingRemote(agentId,false);}catch(_){}}
 if(modal){modal.hidden=true;modal.classList.remove('open');}
 current=null;
}
function applySecurityState(next,closeOnLock=true){
 if(next&&typeof next==='object')security=Object.assign({},security,next);
 const locked=!!security.enabled&&!security.unlocked;
 app.classList.toggle('dmd-ra-is-locked',locked);
 const gate=document.getElementById('dmdRaSecurityGate');if(gate)gate.hidden=!locked;
 const msg=document.getElementById('dmdRaSecurityMessage');if(msg)msg.textContent=securityBlockedMessage(security);
 const form=document.getElementById('dmdRaMfaForm');if(form)form.hidden=!locked||!security.account_mfa;
 const setup=document.getElementById('dmdRaMfaSetupLink');if(setup)setup.hidden=String(security.blocked_reason||'')!=='mfa_not_configured';
 const countdown=document.getElementById('dmdRaSecurityCountdown');
 if(countdown){countdown.hidden=!security.enabled||locked;if(!countdown.hidden)updateSecurityCountdown();}
 if(locked&&closeOnLock){securityCloseRemoteUi();devices=[];renderCards();}
 if(securityTimer){clearInterval(securityTimer);securityTimer=null;}
 if(security.enabled&&security.unlocked&&Number(security.expires_at||0)>0)securityTimer=setInterval(updateSecurityCountdown,1000);
}
function updateSecurityCountdown(){
 if(!security.enabled||!security.unlocked)return;
 const remain=Math.max(0,Number(security.expires_at||0)-Math.floor(Date.now()/1000));
 const el=document.getElementById('dmdRaSecurityCountdown');
 if(el){const m=Math.floor(remain/60),sec=remain%60;el.textContent=`🔐 ${m}:${String(sec).padStart(2,'0')}`;el.title=`Verrouillage MFA dans ${m} min ${sec} s`;}
 if(remain<=0){
   apiPost('security_lock',{}).catch(()=>{});
   applySecurityState({unlocked:false,verified_at:0,expires_at:0,remaining_seconds:0,blocked_reason:''},true);
 }
}
function handleSecurityDenied(data){
 if(data&&data.security)applySecurityState(data.security,true);
 else applySecurityState({enabled:true,required:true,unlocked:false,expires_at:0,blocked_reason:''},true);
}
async function unlockSecurity(code){
 const errorEl=document.getElementById('dmdRaSecurityError');if(errorEl)errorEl.textContent='';
 const input=document.getElementById('dmdRaMfaCode');const form=document.getElementById('dmdRaMfaForm');const button=form?form.querySelector('button'):null;
 if(button)button.disabled=true;
 try{
   const d=await apiPost('security_unlock',{code:String(code||'')});
   applySecurityState(d.security||{enabled:true,unlocked:true},false);
   if(input)input.value='';
   const state=await apiGet('state');devices=Array.isArray(state.devices)?state.devices:[];renderCards();toast(d.message||'DMD-RemoteAgent déverrouillé.');
 }catch(e){if(errorEl)errorEl.textContent=e.message||'Code MFA incorrect.';if(input){input.select();input.focus();}}
 finally{if(button)button.disabled=false;}
}

async function apiGet(action, params){const q=new URLSearchParams(params||{});q.set('action',action);q.set('_',Date.now());const r=await fetch(`${boot.api}?${q}`,{credentials:'same-origin',cache:'no-store'});const d=await r.json().catch(()=>({}));if((d&&d.error)==='module_mfa_required')handleSecurityDenied(d);if(!r.ok||!d.ok){const e=new Error(d.message||d.error||'Erreur API');e.data=d;throw e;}return d;}
async function apiPost(action,payload){const r=await fetch(`${boot.api}?action=${encodeURIComponent(action)}`,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-DMD-CSRF':String(boot.csrf||'')},body:JSON.stringify(payload||{})});const d=await r.json().catch(()=>({}));if((d&&d.error)==='module_mfa_required')handleSecurityDenied(d);if(!r.ok||!d.ok){const e=new Error(d.message||d.error||'Erreur API');e.data=d;throw e;}return d;}
function setStatus(text,busy){const el=document.getElementById('dmdRaCommandStatus');if(el){el.textContent=text||'';el.classList.toggle('busy',!!busy);}}
function toast(text){if(window.DMDWorkspace&&typeof window.DMDWorkspace.toast==='function')window.DMDWorkspace.toast(text);else setStatus(text,false);}

function renderCards(){
 const q=String(document.getElementById('dmdRaSearch').value||'').trim().toLowerCase();
 const f=String(document.getElementById('dmdRaStatusFilter').value||'all');
 const filtered=devices.filter(d=>{
   const text=[d.hostname,d.last_ip,d.platform,d.arch,d.agent_version,(d.groups||[]).map(g=>g.name).join(' ')].join(' ').toLowerCase();
   const okSearch=!q||text.includes(q);
   const okStatus=f==='all'||(f==='online'&&d.online)||(f==='offline'&&!d.online);
   return okSearch&&okStatus;
 });

 const groups=new Map();
 filtered.forEach(d=>{
   const memberships=Array.isArray(d.groups)&&d.groups.length?d.groups:[{group_id:'__ungrouped__',name:'Sans groupe'}];
   memberships.forEach(g=>{
     const name=String(g&&g.name||'').trim()||'Sans groupe';
     const key=String(g&&g.group_id||'').trim()||`name:${name.toLowerCase()}`;
     if(!groups.has(key))groups.set(key,{name,devices:[]});
     groups.get(key).devices.push(d);
   });
 });

 const sortedGroups=Array.from(groups.values()).sort((a,b)=>{
   if(a.name==='Sans groupe'&&b.name!=='Sans groupe')return 1;
   if(b.name==='Sans groupe'&&a.name!=='Sans groupe')return -1;
   return a.name.localeCompare(b.name,'fr',{sensitivity:'base'});
 });

 const cardHtml=d=>`<button type="button" class="dmd-ra-card ${d.online?'online':'offline'}" data-agent-id="${esc(d.agent_id)}" data-dmd-context data-dmd-context-type="remoteagent_pc" data-dmd-context-id="${esc(d.resource&&d.resource.id||'')}" data-dmd-context-name="${esc(d.hostname||'PC')}" data-dmd-context-source="DMD-RemoteAgent" title="${esc((d.hostname||'PC')+' — '+(d.last_ip||'IP inconnue'))}">
   <span class="dmd-ra-live ${d.online?'online':''}"></span>
   <span class="dmd-ra-card-ident"><strong>${esc(d.hostname||'PC')}</strong><small>${esc(d.last_ip||'IP inconnue')}</small></span>
 </button>`;

 list.innerHTML=sortedGroups.map(group=>{
   group.devices.sort((a,b)=>{
     if(!!a.online!==!!b.online)return a.online?-1:1;
     return String(a.hostname||'').localeCompare(String(b.hostname||''),'fr',{sensitivity:'base'});
   });
   return `<section class="dmd-ra-group"><div class="dmd-ra-group-title"><strong>${esc(group.name)}</strong><span>${group.devices.length}</span></div><div class="dmd-ra-group-grid">${group.devices.map(cardHtml).join('')}</div></section>`;
 }).join('');

 empty.hidden=filtered.length!==0;
 document.getElementById('dmdRaOnlineCount').textContent=String(devices.filter(d=>d.online).length);
 document.getElementById('dmdRaTotalCount').textContent=String(devices.length);
 if(window.DMDActionHub&&typeof window.DMDActionHub.decorate==='function')window.DMDActionHub.decorate(list);
}

function kv(label,value){return `<div class="dmd-ra-kv"><span>${esc(label)}</span><strong>${esc(value==null||value===''?'—':value)}</strong></div>`;}
function renderOverview(){
 if(!current)return;
 const inv=current.inventory||{},hw=current.hardware||{},os=(inv.os&&typeof inv.os==='object')?inv.os:{},cpu=inv.cpu||{},ram=inv.ram||{},up=inv.uptime||{};
 const net=Array.isArray(inv.network)?inv.network:[];const groups=Array.isArray(current.groups)?current.groups:[];
 const active=inv.active_interface&&typeof inv.active_interface==='object'?inv.active_interface:{};
 const vols=Array.isArray(inv.volumes)?inv.volumes:[];const ports=Array.isArray(inv.open_ports)?inv.open_ports:[];const sessions=Array.isArray(inv.sessions)?inv.sessions:[];
 const gpus=Array.isArray(inv.gpu)?inv.gpu:[];
 const pct=v=>{const n=Number(v);return Number.isFinite(n)?`${Math.round(n*10)/10}%`:'—';};
 const ramTotal=ram.total_bytes?formatBytes(ram.total_bytes):(ram.total_gb!=null?ram.total_gb+' Go':'—');
 const ramUsed=ram.used_bytes?formatBytes(ram.used_bytes):(ram.used_gb!=null?ram.used_gb+' Go':'—');
 const osLabel=[inv.os_name||os.name||current.platform,inv.os_version||os.version,inv.os_build?`build ${inv.os_build}`:''].filter(Boolean).join(' ');
 const gpuLabel=gpus.length?gpus.map(g=>typeof g==='string'?g:(g.name||g.model||'')).filter(Boolean).join(' · '):'—';
 const activeIPs=[active.ipv4,active.ipv6].filter(Boolean).join(' · ');
 document.getElementById('dmdRaOverview').innerHTML=`
 <div class="dmd-ra-overview-grid">
  <section class="dmd-ra-panel"><h3>Machine</h3>${kv('Nom',current.hostname)}${kv('IP vue par DoMyDesk',current.last_ip)}${kv('Système',osLabel||'—')}${kv('Architecture',current.arch)}${kv('Utilisateur actif',inv.active_session||inv.logged_on_user||'—')}${kv('Domaine / Workgroup',inv.domain||inv.workgroup||'—')}${kv('DMD-Agent',current.agent_version)}${kv('Dernier contact',formatDate(current.last_seen_at))}</section>
  <section class="dmd-ra-panel"><h3>Matériel</h3>${kv('Constructeur',inv.manufacturer||hw.system_vendor)}${kv('Modèle',inv.model||hw.system_product)}${kv('UUID',inv.system_uuid||hw.system_uuid)}${kv('N° série BIOS',inv.serial_number||hw.bios_serial)}${kv('Carte mère',(inv.baseboard&&inv.baseboard.product)||hw.baseboard_product)}${kv('TPM',inv.tpm||hw.tpm)}${kv('Secure Boot',inv.secure_boot)}${kv('GPU',gpuLabel)}</section>
  <section class="dmd-ra-panel"><h3>CPU / mémoire</h3>${kv('CPU',cpu.model)}${kv('Cœurs / threads',[cpu.cores?cpu.cores+' cœurs':'',cpu.threads?cpu.threads+' threads':''].filter(Boolean).join(' / '))}${kv('Charge CPU',pct(cpu.usage_percent!=null?cpu.usage_percent:inv.cpu_usage_percent))}${kv('RAM installée',ramTotal)}${kv('RAM utilisée',ramUsed)}${kv('Charge RAM',pct(ram.usage_percent))}${kv('Uptime',up.human||'—')}${kv('Dernier démarrage',formatDate(inv.last_boot_at))}</section>
  <section class="dmd-ra-panel"><h3>Réseau actif</h3>${kv('Interface',active.name)}${kv('IP',activeIPs)}${kv('MAC',active.mac)}${kv('Passerelle',active.gateway||inv.gateway)}${kv('DNS',Array.isArray(active.dns)?active.dns.join(' · '):(Array.isArray(inv.dns)?inv.dns.join(' · '):'—'))}${kv('Vitesse',active.speed_mbps?active.speed_mbps+' Mbps':'—')}${kv('Ports TCP en écoute',ports.length)}</section>
  <section class="dmd-ra-panel full"><h3>Stockage</h3><div class="dmd-ra-network">${vols.length?vols.map(v=>`<div><strong>${esc(v.letter||v.name||'Volume')}</strong><span>${esc(v.total_bytes?`${formatBytes(v.used_bytes)} / ${formatBytes(v.total_bytes)} · ${pct(v.usage_percent)}`:'—')}</span><small>${esc(v.filesystem||'')}</small></div>`).join(''):'<span>Aucune donnée disque.</span>'}</div></section>
  <section class="dmd-ra-panel full"><h3>Interfaces réseau</h3><div class="dmd-ra-network">${net.length?net.map(n=>`<div><strong>${esc(n.name||'Interface')}</strong><span>${esc((n.ips||[]).join(' · ')||'—')}</span><small>${esc(n.mac||'')}</small></div>`).join(''):'<span>Aucune donnée réseau.</span>'}</div></section>
  <section class="dmd-ra-panel full"><h3>Sessions et ports</h3>${kv('Session active',inv.active_session||inv.logged_on_user||'—')}${kv('Sessions détectées',sessions.length)}${kv('Ports TCP en écoute',ports.length)}${ports.length?`<div class="dmd-ra-chips">${ports.slice(0,24).map(p=>`<span>${esc((p.port||'')+'/'+(p.protocol||'TCP')+(p.process?' · '+p.process:''))}</span>`).join('')}${ports.length>24?`<span>+${ports.length-24}</span>`:''}</div>`:''}</section>
  <section class="dmd-ra-panel full"><h3>Groupes et droits</h3><div class="dmd-ra-chips">${groups.length?groups.map(g=>`<span>${esc(g.name)}</span>`).join(''):'<span>Sans groupe</span>'}</div><div class="dmd-ra-chips rights">${(current.permissions||[]).length?(current.permissions||[]).map(p=>`<span>${esc(p)}</span>`).join(''):'<span>Aucun droit opérationnel</span>'}</div></section>
 </div>`;
}
function applyPermissions(){if(!current)return;modal.querySelectorAll('[data-perm]').forEach(el=>{el.hidden=!hasPerm(el.dataset.perm);});modal.querySelectorAll('[data-perm-any]').forEach(el=>{el.hidden=!hasAny(el.dataset.permAny);});}
function switchTab(name){currentTab=name;document.querySelectorAll('#dmdRaTabs [data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));modal.querySelectorAll('[data-pane]').forEach(p=>{const on=p.dataset.pane===name;p.hidden=!on;p.classList.toggle('active',on);});modal.querySelectorAll('[data-actions-pane]').forEach(g=>{g.hidden=g.dataset.actionsPane!==name;});const cp=document.getElementById('dmdRaClipboardPanel');if(cp&&name!=='remote')cp.hidden=true;if(name==='history')loadHistory();if(name==='software'&&hasPerm('software.view'))loadSoftware(0).catch(e=>toast(e.message||'Inventaire logiciels impossible.'));}
function openDevice(id){current=deviceById(id);if(!current)return;document.getElementById('dmdRaTitle').textContent=current.hostname||'PC';document.getElementById('dmdRaSub').textContent=[current.last_ip,current.platform,current.agent_version].filter(Boolean).join(' · ');document.getElementById('dmdRaStateLine').textContent=current.online?'● En ligne':'○ Hors ligne';document.getElementById('dmdRaStateLine').classList.toggle('online',!!current.online);renderOverview();applyPermissions();switchTab('overview');modal.hidden=false;modal.classList.add('open');if(modal.parentElement!==document.body)document.body.appendChild(modal);if(touchTimer){clearInterval(touchTimer);touchTimer=null;}const agentId=current.agent_id;touchStamp[agentId]=Date.now();apiPost('touch',{agent_id:agentId}).catch(()=>{});const keepInteractive=()=>{if(!current||current.agent_id!==agentId)return;apiPost('interactive_touch',{agent_id:agentId}).catch(()=>{});};touchTimer=setInterval(keepInteractive,15000);setStatus('Prêt.',false);}
function closeModal(){if(touchTimer){clearInterval(touchTimer);touchTimer=null;}stopRemoteBrowser();modal.classList.remove('open');modal.hidden=true;current=null;}

async function refreshState(silent){try{if(!silent)setStatus('Actualisation…',true);const d=await apiGet('state');devices=Array.isArray(d.devices)?d.devices:[];renderCards();if(current){const updated=deviceById(current.agent_id);if(updated){current=updated;document.getElementById('dmdRaSub').textContent=[current.last_ip,current.platform,current.agent_version].filter(Boolean).join(' · ');renderOverview();applyPermissions();}}if(!silent)setStatus('État actualisé.',false);}catch(e){if(!silent)setStatus(e.message,false);}}
async function waitCommand(agentId,commandId,timeoutMs,silent){const started=Date.now();while(Date.now()-started<timeoutMs){await new Promise(r=>setTimeout(r,150));const d=await apiGet('command_status',{agent_id:agentId,command_id:commandId});const c=d.command||{};if(!silent)setStatus(`Commande ${c.status||'…'}`,c.status==='queued'||c.status==='delivered');if(['completed','failed','cancelled','expired'].includes(String(c.status||'')))return c;}throw new Error('Délai de réponse de l’agent dépassé.');}
async function execute(operation,params,opts){if(!current)return null;opts=opts||{};const agentId=current.agent_id;try{if(!opts.silent)setStatus('Envoi de la commande…',true);const d=await apiPost('command',{agent_id:agentId,operation,params:params||{}});const c=d.command||{};if(!opts.silent)toast(d.message||'Commande envoyée.');if(opts.noWait)return c;const done=await waitCommand(agentId,c.command_id,opts.timeout||120000,!!opts.silent);if(done.status==='failed'||done.status==='expired'||done.status==='cancelled')throw new Error(done.error||`Commande ${done.status}.`);if(!opts.silent)setStatus('Commande terminée.',false);if(!opts.noRefresh)await refreshState(true);return done;}catch(e){if(!opts.silent)setStatus(e.message||'Commande impossible.',false);throw e;}}
function commandResult(c){if(!c)return null;if(c.result!==undefined)return c.result;return null;}
function renderGenericResult(el,result){if(!el)return;if(result==null){el.innerHTML='<span>Aucune donnée retournée.</span>';return;}if(typeof result==='string'||typeof result==='number'||typeof result==='boolean'){el.innerHTML=`<pre>${esc(result)}</pre>`;return;}el.innerHTML=`<pre>${esc(JSON.stringify(result,null,2))}</pre>`;}

function renderFiles(result){
 const el=document.getElementById('dmdRaFilesResult');if(!el)return;
 const roots=Array.isArray(result&&result.roots)?result.roots:null;
 const entries=Array.isArray(result&&result.entries)?result.entries:(Array.isArray(result)?result:null);
 if(roots){el.innerHTML=`<div class="dmd-ra-table">${roots.length?roots.map(r=>`<button type="button" class="dmd-ra-file-row root" data-path="${esc(typeof r==='string'?r:(r.path||r.name||''))}"><strong>${esc(typeof r==='string'?r:(r.label||r.path||r.name||''))}</strong></button>`).join(''):'<span>Aucun volume local détecté.</span>'}</div>`;return;}
 if(entries){
   const path=String(result&&result.path||'');if(path)document.getElementById('dmdRaPath').value=path;
   const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||80),total=Number(result&&result.total||entries.length),hasMore=!!(result&&result.has_more),prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+entries.length);
   const parent=result&&result.parent?`<button type="button" data-path="${esc(result.parent)}">↑ Dossier parent</button>`:'';
   const nav=`<div class="dmd-ra-result-meta"><span>${esc(path||'Dossier')} · ${total} élément(s)</span><span class="dmd-ra-inline-actions">${parent}${offset>0?`<button type="button" data-file-offset="${prev}">‹ Précédent</button>`:''}${hasMore?`<button type="button" data-file-offset="${next}">Suivant ›</button>`:''}</span></div>`;
   el.innerHTML=nav+`<div class="dmd-ra-table">${entries.length?entries.map(e=>{const isDir=!!e.is_dir;const ep=e.path||'';const actions=[];if(!isDir&&hasPerm('files.download'))actions.push(`<button type="button" class="small" data-download-path="${esc(ep)}" data-download-name="${esc(e.name||'fichier')}" data-download-size="${esc(e.size||0)}">Télécharger</button>`);if(hasPerm('files.rename'))actions.push(`<button type="button" class="small" data-rename-path="${esc(ep)}" data-rename-name="${esc(e.name||'')}">Renommer</button>`);if(hasPerm('files.delete'))actions.push(`<button type="button" class="danger small" data-delete-path="${esc(ep)}" data-delete-dir="${isDir?'1':'0'}">Supprimer</button>`);return `<div class="dmd-ra-file-row"><button type="button" ${isDir?`data-path="${esc(ep)}"`:''}><strong>${isDir?'▸ ':'▹ '}${esc(e.name||ep)}</strong><span>${isDir?'Dossier':formatBytes(e.size)}${e.modified_at?' · '+esc(formatDate(e.modified_at)):''}</span></button><span class="dmd-ra-inline-actions">${actions.join('')}</span></div>`;}).join(''):'<span>Dossier vide.</span>'}</div>`;
   return;
 }
 renderGenericResult(el,result);
}

async function browseFiles(path,offset=0){path=String(path||'').trim();if(!path){const c=await execute('files.roots',{}, {timeout:60000});renderFiles(commandResult(c));return;}const c=await execute('files.list',{path,offset:Number(offset)||0,limit:80},{timeout:60000});renderFiles(commandResult(c));}

async function downloadRemoteFile(path,name,size){
 size=Number(size||0);if(size<0||size>FILE_MAX)throw new Error('Fichier trop volumineux pour le transfert DMD-Agent (64 Mio maximum).');
 clearFileTransfer();fileTransferStatus(`Téléchargement ${name}`,0,size);
 if(size===0){const url=URL.createObjectURL(new Blob([]));const a=document.createElement('a');a.href=url;a.download=name||'fichier';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);clearFileTransfer();return;}
 const offsets=[];for(let o=0;o<size;o+=FILE_CHUNK)offsets.push(o);const chunks=[];let done=0;
 for(let i=0;i<offsets.length;i+=FILE_BATCH){const batch=offsets.slice(i,i+FILE_BATCH);const results=await Promise.all(batch.map(async o=>{const c=await execute('files.read',{path,offset:o,length:Math.min(FILE_CHUNK,size-o),transfer_final:(o+Math.min(FILE_CHUNK,size-o)>=size)},{timeout:180000,silent:true,noRefresh:true});const r=commandResult(c)||{};if(r.truncated||typeof r.data_base64!=='string')throw new Error('Bloc de téléchargement invalide.');return r;}));results.sort((a,b)=>Number(a.offset||0)-Number(b.offset||0));for(const r of results){const b=base64ToBytes(r.data_base64);chunks.push(b);done+=b.byteLength;fileTransferStatus(`Téléchargement ${name}`,done,size);}}
 const blob=new Blob(chunks);const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name||'fichier';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);fileTransferStatus(`Téléchargement terminé : ${name}`,size,size);setTimeout(clearFileTransfer,1800);
}

async function uploadRemoteFile(file){
 if(!file)return;const base=document.getElementById('dmdRaPath').value.trim();if(!base)throw new Error('Ouvre d’abord un dossier de destination.');if(file.size>FILE_MAX)throw new Error('Fichier trop volumineux : maximum 64 Mio pour cette version.');const path=winJoin(base,file.name);fileTransferStatus(`Envoi ${file.name}`,0,file.size);
 if(file.size===0){await execute('files.write',{path,offset:0,truncate:true,data_base64:'',transfer_final:true},{timeout:180000,silent:true,noRefresh:true});fileTransferStatus(`Envoi terminé : ${file.name}`,0,0);await browseFiles(base,0);return;}
 const firstBytes=new Uint8Array(await file.slice(0,Math.min(FILE_CHUNK,file.size)).arrayBuffer());await execute('files.write',{path,offset:0,truncate:true,data_base64:bytesToBase64(firstBytes),transfer_final:(firstBytes.byteLength>=file.size)},{timeout:180000,silent:true,noRefresh:true});let done=firstBytes.byteLength;fileTransferStatus(`Envoi ${file.name}`,done,file.size);
 const offsets=[];for(let o=FILE_CHUNK;o<file.size;o+=FILE_CHUNK)offsets.push(o);for(let i=0;i<offsets.length;i+=FILE_BATCH){const batch=offsets.slice(i,i+FILE_BATCH);await Promise.all(batch.map(async o=>{const bytes=new Uint8Array(await file.slice(o,Math.min(o+FILE_CHUNK,file.size)).arrayBuffer());await execute('files.write',{path,offset:o,truncate:false,data_base64:bytesToBase64(bytes),transfer_final:(o+bytes.byteLength>=file.size)},{timeout:180000,silent:true,noRefresh:true});return bytes.byteLength;})).then(lengths=>{done+=lengths.reduce((a,b)=>a+b,0);fileTransferStatus(`Envoi ${file.name}`,done,file.size);});}
 fileTransferStatus(`Envoi terminé : ${file.name}`,file.size,file.size);await browseFiles(base,0);setTimeout(clearFileTransfer,1800);
}


function stopRemoteBrowser(){
 if(remoteTimer){clearTimeout(remoteTimer);remoteTimer=null;}
 if(remoteInputTimer){clearTimeout(remoteInputTimer);remoteInputTimer=null;}
 if(remoteImageUrl){try{URL.revokeObjectURL(remoteImageUrl);}catch(_){}remoteImageUrl='';}
 remoteSeq=0;remoteControl=false;remoteWidth=0;remoteHeight=0;remoteMovePending=null;remoteInputQueue=[];remoteInputBusy=false;
 const stage=remoteStage();if(stage){stage.onkeydown=null;stage.onkeyup=null;}
}
function remoteStage(){return document.getElementById('dmdRaRemoteStage');}
function renderRemoteShell(control){
 let stage=remoteStage();if(!stage)return;
 // cloneNode(false) supprime tous les anciens handlers : aucune frappe ne peut
 // être doublée après Voir l’écran -> Prendre le contrôle -> Voir l’écran.
 const clean=stage.cloneNode(false);stage.replaceWith(clean);stage=clean;
 remoteControl=!!control;
 stage.innerHTML=`<div class="dmd-ra-remote-wrap"><div class="dmd-ra-remote-status"><span class="dmd-ra-live online"></span><strong>${control?'Contrôle distant':'Écran distant'}</strong><small id="dmdRaRemoteMeta">Connexion au flux…</small></div><img id="dmdRaRemoteImage" alt="Écran distant ${esc(current&&current.hostname||'PC')}" draggable="false"></div>`;
 stage.classList.toggle('dmd-ra-control-active',remoteControl);
 stage.tabIndex=0;
 bindRemoteInput();
 if(remoteControl){try{stage.focus({preventScroll:true});}catch(_){stage.focus();}}
}
async function fetchRemoteFrameBinary(){
 const q=new URLSearchParams({action:'remote_frame_binary',agent_id:String(current.agent_id||''),after:String(remoteSeq),_:String(Date.now())});
 const r=await fetch(`${boot.api}?${q}`,{credentials:'same-origin',cache:'no-store'});
 if(r.status===204){return{active:r.headers.get('X-DMD-Remote-Active')==='1',no_change:true,sequence:Number(r.headers.get('X-DMD-Remote-Sequence')||remoteSeq),width:Number(r.headers.get('X-DMD-Remote-Width')||remoteWidth),height:Number(r.headers.get('X-DMD-Remote-Height')||remoteHeight)};}
 if(!r.ok){if(r.status===403){const d=await r.json().catch(()=>({}));if(d&&d.error==='module_mfa_required')handleSecurityDenied(d);}throw new Error(`Flux Remote HTTP ${r.status}`);}
 const blob=await r.blob();
 return{active:true,no_change:false,sequence:Number(r.headers.get('X-DMD-Remote-Sequence')||0),width:Number(r.headers.get('X-DMD-Remote-Width')||0),height:Number(r.headers.get('X-DMD-Remote-Height')||0),blob};
}
async function pollRemoteFrame(){
 if(!current||!remoteStage()||modal.hidden){stopRemoteBrowser();return;}
 try{
   const d=await fetchRemoteFrameBinary();
   if(!d.active){const meta=document.getElementById('dmdRaRemoteMeta');if(meta)meta.textContent='En attente du premier écran…';remoteTimer=setTimeout(pollRemoteFrame,120);return;}
   if(!d.no_change&&d.blob){
     remoteSeq=Number(d.sequence||remoteSeq);remoteWidth=Number(d.width||0);remoteHeight=Number(d.height||0);
     const img=document.getElementById('dmdRaRemoteImage');
     if(img){const old=remoteImageUrl;const url=URL.createObjectURL(d.blob);remoteImageUrl=url;img.onload=()=>{if(old&&old!==url){try{URL.revokeObjectURL(old);}catch(_){}}};img.src=url;}
     const meta=document.getElementById('dmdRaRemoteMeta');if(meta)meta.textContent=`${remoteWidth}×${remoteHeight} · image ${remoteSeq}${remoteControl?' · clavier/souris actifs':''}`;
   }
   remoteTimer=setTimeout(pollRemoteFrame,70);
 }catch(e){const meta=document.getElementById('dmdRaRemoteMeta');if(meta)meta.textContent='Flux interrompu, nouvelle tentative…';remoteTimer=setTimeout(pollRemoteFrame,450);}
}
function startRemoteBrowser(control){stopRemoteBrowser();renderRemoteShell(control);pollRemoteFrame();}
function queueRemoteInput(event){
 if(!current||!remoteControl)return;
 // Les déplacements deviennent obsolètes très vite : on remplace seulement le dernier move consécutif.
 if(event&&event.type==='move'&&remoteInputQueue.length&&remoteInputQueue[remoteInputQueue.length-1].type==='move')remoteInputQueue[remoteInputQueue.length-1]=event;
 else if(event&&event.type==='text'&&remoteInputQueue.length&&remoteInputQueue[remoteInputQueue.length-1].type==='text'&&String(remoteInputQueue[remoteInputQueue.length-1].text||'').length<56){
   remoteInputQueue[remoteInputQueue.length-1].text=String(remoteInputQueue[remoteInputQueue.length-1].text||'')+String(event.text||'');
 } else remoteInputQueue.push(event);
 if(remoteInputQueue.length>80)remoteInputQueue=remoteInputQueue.slice(-60);
 scheduleRemoteInputFlush(event&&event.type==='move'?45:0);
}
function scheduleRemoteInputFlush(delay){
 if(remoteInputTimer||remoteInputBusy)return;
 remoteInputTimer=setTimeout(()=>{remoteInputTimer=null;flushRemoteInputs();},Math.max(0,Number(delay||0)));
}
async function flushRemoteInputs(){
 if(remoteInputBusy||!current||!remoteControl||!remoteInputQueue.length)return;
 remoteInputBusy=true;
 const agentId=current.agent_id;
 const batch=remoteInputQueue.splice(0,32);
 try{await apiPost('remote_input',{agent_id:agentId,events:batch});}catch(_){}
 finally{remoteInputBusy=false;if(remoteInputQueue.length)scheduleRemoteInputFlush(0);}
}
function sendRemoteInput(event){queueRemoteInput(event);return Promise.resolve();}
function remoteCoords(ev,img){const r=img.getBoundingClientRect();if(!r.width||!r.height)return null;return{nx:Math.max(0,Math.min(100000,Math.round((ev.clientX-r.left)/r.width*100000))),ny:Math.max(0,Math.min(100000,Math.round((ev.clientY-r.top)/r.height*100000)))};}
function remoteVK(e){
 const direct=Number(e.keyCode||e.which||0);if(direct>0)return direct;
 const map={Backspace:8,Tab:9,Enter:13,Shift:16,Control:17,Alt:18,Pause:19,CapsLock:20,Escape:27,' ':32,PageUp:33,PageDown:34,End:35,Home:36,ArrowLeft:37,ArrowUp:38,ArrowRight:39,ArrowDown:40,Insert:45,Delete:46,Meta:91,ContextMenu:93};
 if(map[e.key]!=null)return map[e.key];
 const fm=/^F(\d{1,2})$/.exec(String(e.key||''));if(fm){const n=Number(fm[1]);if(n>=1&&n<=24)return 111+n;}
 return 0;
}
function bindRemoteInput(){
 const stage=remoteStage(),img=document.getElementById('dmdRaRemoteImage');
 if(!stage||!img)return;
 const focusStage=()=>{if(!remoteControl)return;try{stage.focus({preventScroll:true});}catch(_){stage.focus();}};
 img.oncontextmenu=e=>{if(remoteControl)e.preventDefault();};
 img.onmousemove=e=>{if(!remoteControl)return;const c=remoteCoords(e,img);if(!c)return;const now=Date.now();remoteMovePending=c;if(now-remoteLastMove<20)return;remoteLastMove=now;const p=remoteMovePending;remoteMovePending=null;sendRemoteInput({type:'move',nx:p.nx,ny:p.ny});};
 img.onmousedown=e=>{if(!remoteControl)return;e.preventDefault();e.stopPropagation();focusStage();const c=remoteCoords(e,img);if(c)sendRemoteInput({type:'move',nx:c.nx,ny:c.ny});sendRemoteInput({type:'button',button:e.button,down:true});};
 img.onmouseup=e=>{if(!remoteControl)return;e.preventDefault();e.stopPropagation();sendRemoteInput({type:'button',button:e.button,down:false});};
 img.onwheel=e=>{if(!remoteControl)return;e.preventDefault();e.stopPropagation();sendRemoteInput({type:'wheel',delta:e.deltaY<0?120:-120});};
 stage.onmousedown=e=>{if(remoteControl)focusStage();};

 // b4 : retour à la méthode qui fonctionnait réellement sur SERV3DPRINT.
 // e.key contient déjà le caractère résolu par Brave/Windows (AZERTY compris),
 // donc aucun mapping QWERTY n’est effectué pour le texte imprimable.
 stage.onkeydown=e=>{
   if(!remoteControl)return;
   const altGraph=typeof e.getModifierState==='function'&&e.getModifierState('AltGraph');
   const printable=!!(e.key&&e.key.length===1);
   if(printable&&!e.metaKey&&(!e.ctrlKey||altGraph)&&(!e.altKey||altGraph)){
     e.preventDefault();e.stopPropagation();sendRemoteInput({type:'text',text:e.key});return;
   }
   const vk=remoteVK(e);
   if(vk>0){e.preventDefault();e.stopPropagation();sendRemoteInput({type:'key',vk,down:true});}
 };
 stage.onkeyup=e=>{
   if(!remoteControl)return;
   const altGraph=typeof e.getModifierState==='function'&&e.getModifierState('AltGraph');
   const printable=!!(e.key&&e.key.length===1);
   if(printable&&!e.metaKey&&(!e.ctrlKey||altGraph)&&(!e.altKey||altGraph)){e.preventDefault();e.stopPropagation();return;}
   const vk=remoteVK(e);
   if(vk>0){e.preventDefault();e.stopPropagation();sendRemoteInput({type:'key',vk,down:false});}
 };
}

/* 1.0.21 — fenêtres Remote persistantes et multiples sur le dashboard. */
/* floatingRemotes est initialisée avec l’état global du module. */

async function executeForAgent(agentId,operation,params,opts){
 opts=opts||{};
 const d=await apiPost('command',{agent_id:agentId,operation,params:params||{}});
 const c=d.command||{};
 if(opts.noWait)return c;
 const done=await waitCommand(agentId,c.command_id,opts.timeout||120000,true);
 if(done.status==='failed'||done.status==='expired'||done.status==='cancelled')throw new Error(done.error||`Commande ${done.status}.`);
 return done;
}
function remoteResolutionUnwrap(v){let r=v;for(let i=0;i<4;i++){if(r&&typeof r==='object'&&r.result&&typeof r.result==='object'){r=r.result;continue;}break;}return r&&typeof r==='object'?r:{};}
function remoteResolutionName(w,h){w=Number(w||0);h=Number(h||0);return w>0&&h>0?`${w}x${h}`:'';}
function remoteResolutionLabel(v){return String(v||'').replace('x','×');}
function floatingResolutionEnsure(ctx,v,label){const sel=ctx&&ctx.resolutionSelect;if(!sel||!/^\d+x\d+$/.test(String(v||'')))return null;let o=Array.from(sel.options).find(x=>x.value===v);if(!o){o=document.createElement('option');o.value=v;sel.appendChild(o);}o.textContent=label||remoteResolutionLabel(v);if(ctx.rejectedResolutions&&ctx.rejectedResolutions.has(v)){o.disabled=true;o.textContent=`${remoteResolutionLabel(v)} (refusé)`;}return o;}
function floatingResolutionRender(ctx,info){const sel=ctx&&ctx.resolutionSelect;if(!sel)return;const actual=remoteResolutionName(info&&info.width,info&&info.height);const supported=Array.isArray(info&&info.supported)?info.supported.map(String).filter(v=>/^\d+x\d+$/.test(v)):[];const values=[];if(actual)values.push(actual);for(const v of supported)if(!values.includes(v))values.push(v);sel.innerHTML='<option value="auto">Auto</option>';for(const v of values)floatingResolutionEnsure(ctx,v);if(actual)sel.value=actual;}
function floatingResolutionSync(ctx,w,h){const sel=ctx&&ctx.resolutionSelect;if(!sel)return;const actual=remoteResolutionName(w,h);if(!actual)return;floatingResolutionEnsure(ctx,actual);sel.value=actual;sel.title=`Résolution réelle : ${remoteResolutionLabel(actual)}`;}
async function floatingResolutionLoad(ctx){if(!ctx||ctx.closed||!ctx.resolutionSelect)return;try{const done=await executeForAgent(ctx.agentId,'remote.resolution',{mode:'info'},{timeout:20000});const r=remoteResolutionUnwrap(done);floatingResolutionRender(ctx,r);floatingResolutionSync(ctx,r.width,r.height);}catch(_){floatingResolutionSync(ctx,ctx.width,ctx.height);}}
function floatingDisplayApply(ctx,v){if(!ctx||!ctx.stage)return;v=v==='1to1'?'1to1':'fit';ctx.stage.classList.toggle('pixel-1to1',v==='1to1');if(ctx.displaySelect)ctx.displaySelect.value=v;try{localStorage.setItem(`DMD-RemoteAgent:display:${ctx.agentId}`,v);}catch(_){}}
function floatingRemoteKey(agentId){return String(agentId||'').replace(/[^a-zA-Z0-9._-]+/g,'_');}
function floatingRemoteCoords(ev,ctx){
 const img=ctx&&ctx.img;if(!img)return null;
 const r=img.getBoundingClientRect();if(!r.width||!r.height)return null;
 const sourceW=Number(ctx.width||img.naturalWidth||0),sourceH=Number(ctx.height||img.naturalHeight||0);
 if(!(sourceW>0)||!(sourceH>0))return null;
 // object-fit:contain peut créer des bandes noires : on mappe sur le bitmap réellement visible.
 const scale=Math.min(r.width/sourceW,r.height/sourceH);
 const shownW=sourceW*scale,shownH=sourceH*scale;
 const left=r.left+(r.width-shownW)/2,top=r.top+(r.height-shownH)/2;
 const x=ev.clientX-left,y=ev.clientY-top;
 if(x<0||y<0||x>shownW||y>shownH)return null;
 return{
  nx:Math.max(0,Math.min(100000,Math.round(x/shownW*100000))),
  ny:Math.max(0,Math.min(100000,Math.round(y/shownH*100000)))
 };
}
function floatingRemoteVK(e){
 const direct=Number(e.keyCode||e.which||0);if(direct>0)return direct;
 const map={Backspace:8,Tab:9,Enter:13,Shift:16,Control:17,Alt:18,Pause:19,CapsLock:20,Escape:27,' ':32,PageUp:33,PageDown:34,End:35,Home:36,ArrowLeft:37,ArrowUp:38,ArrowRight:39,ArrowDown:40,Insert:45,Delete:46,Meta:91,ContextMenu:93};
 if(map[e.key]!=null)return map[e.key];
 const fm=/^F(\d{1,2})$/.exec(String(e.key||''));if(fm){const n=Number(fm[1]);if(n>=1&&n<=24)return 111+n;}
 return 0;
}
function floatingRemoteQueue(ctx,event){
 if(!ctx||ctx.closed||!ctx.control||!event)return;
 if(event.type==='move'&&ctx.inputQueue.length&&ctx.inputQueue[ctx.inputQueue.length-1].type==='move')ctx.inputQueue[ctx.inputQueue.length-1]=event;
 else if(event.type==='text'&&ctx.inputQueue.length&&ctx.inputQueue[ctx.inputQueue.length-1].type==='text'&&String(ctx.inputQueue[ctx.inputQueue.length-1].text||'').length<56)ctx.inputQueue[ctx.inputQueue.length-1].text=String(ctx.inputQueue[ctx.inputQueue.length-1].text||'')+String(event.text||'');
 else ctx.inputQueue.push(event);
 if(ctx.inputQueue.length>80)ctx.inputQueue=ctx.inputQueue.slice(-60);
 floatingRemoteScheduleInput(ctx,event.type==='move'?35:0);
}
function floatingRemoteScheduleInput(ctx,delay){
 if(!ctx||ctx.closed||ctx.inputTimer||ctx.inputBusy)return;
 ctx.inputTimer=setTimeout(()=>{ctx.inputTimer=null;floatingRemoteFlush(ctx);},Math.max(0,Number(delay||0)));
}
async function floatingRemoteFlush(ctx){
 if(!ctx||ctx.closed||ctx.inputBusy||!ctx.control||!ctx.inputQueue.length)return;
 ctx.inputBusy=true;
 const batch=ctx.inputQueue.splice(0,32);
 try{await apiPost('remote_input',{agent_id:ctx.agentId,events:batch});}catch(_){ }
 finally{ctx.inputBusy=false;if(ctx.inputQueue.length)floatingRemoteScheduleInput(ctx,0);}
}
function bindFloatingRemoteInput(ctx){
 const stage=ctx.stage,img=ctx.img;if(!stage||!img)return;
 const focusStage=()=>{if(!ctx.control)return;try{stage.focus({preventScroll:true});}catch(_){stage.focus();}};
 img.oncontextmenu=e=>{if(ctx.control)e.preventDefault();};
 img.onmousemove=e=>{if(!ctx.control)return;const c=floatingRemoteCoords(e,ctx);if(!c)return;const now=Date.now();ctx.movePending=c;if(now-ctx.lastMove<18)return;ctx.lastMove=now;const m=ctx.movePending;ctx.movePending=null;floatingRemoteQueue(ctx,{type:'move',nx:m.nx,ny:m.ny});};
 img.onmousedown=e=>{if(!ctx.control)return;e.preventDefault();e.stopPropagation();focusStage();const c=floatingRemoteCoords(e,ctx);if(c)floatingRemoteQueue(ctx,{type:'move',nx:c.nx,ny:c.ny});floatingRemoteQueue(ctx,{type:'button',button:e.button,down:true});};
 img.onmouseup=e=>{if(!ctx.control)return;e.preventDefault();e.stopPropagation();floatingRemoteQueue(ctx,{type:'button',button:e.button,down:false});};
 img.onwheel=e=>{if(!ctx.control)return;e.preventDefault();e.stopPropagation();floatingRemoteQueue(ctx,{type:'wheel',delta:e.deltaY<0?120:-120});};
 stage.onmousedown=()=>focusStage();
 stage.onkeydown=e=>{
   if(!ctx.control)return;
   const altGraph=typeof e.getModifierState==='function'&&e.getModifierState('AltGraph');
   const printable=!!(e.key&&e.key.length===1);
   if(printable&&!e.metaKey&&(!e.ctrlKey||altGraph)&&(!e.altKey||altGraph)){e.preventDefault();e.stopPropagation();floatingRemoteQueue(ctx,{type:'text',text:e.key});return;}
   const vk=floatingRemoteVK(e);if(vk>0){e.preventDefault();e.stopPropagation();floatingRemoteQueue(ctx,{type:'key',vk,down:true});}
 };
 stage.onkeyup=e=>{
   if(!ctx.control)return;
   const altGraph=typeof e.getModifierState==='function'&&e.getModifierState('AltGraph');
   const printable=!!(e.key&&e.key.length===1);
   if(printable&&!e.metaKey&&(!e.ctrlKey||altGraph)&&(!e.altKey||altGraph)){e.preventDefault();e.stopPropagation();return;}
   const vk=floatingRemoteVK(e);if(vk>0){e.preventDefault();e.stopPropagation();floatingRemoteQueue(ctx,{type:'key',vk,down:false});}
 };
}
async function fetchFloatingRemoteFrame(ctx){
 const q=new URLSearchParams({action:'remote_frame_binary',agent_id:ctx.agentId,after:String(ctx.seq),_:String(Date.now())});
 const r=await fetch(`${boot.api}?${q}`,{credentials:'same-origin',cache:'no-store'});
 if(r.status===204)return{active:r.headers.get('X-DMD-Remote-Active')==='1',no_change:true,sequence:Number(r.headers.get('X-DMD-Remote-Sequence')||ctx.seq),width:Number(r.headers.get('X-DMD-Remote-Width')||ctx.width),height:Number(r.headers.get('X-DMD-Remote-Height')||ctx.height)};
 if(!r.ok){if(r.status===403){const d=await r.json().catch(()=>({}));if(d&&d.error==='module_mfa_required')handleSecurityDenied(d);}throw new Error(`Flux Remote HTTP ${r.status}`);}
 return{active:true,no_change:false,sequence:Number(r.headers.get('X-DMD-Remote-Sequence')||0),width:Number(r.headers.get('X-DMD-Remote-Width')||0),height:Number(r.headers.get('X-DMD-Remote-Height')||0),blob:await r.blob()};
}
async function pollFloatingRemote(ctx){
 if(!ctx||ctx.closed||!ctx.root.isConnected)return;
 try{
   const d=await fetchFloatingRemoteFrame(ctx);
   if(!d.active){ctx.meta.textContent='Connexion…';ctx.frameTimer=setTimeout(()=>pollFloatingRemote(ctx),120);return;}
   if(!d.no_change&&d.blob){
     ctx.seq=Number(d.sequence||ctx.seq);ctx.width=Number(d.width||0);ctx.height=Number(d.height||0);floatingResolutionSync(ctx,ctx.width,ctx.height);
     const old=ctx.imageUrl,url=URL.createObjectURL(d.blob);ctx.imageUrl=url;
     ctx.img.onload=()=>{if(old&&old!==url){try{URL.revokeObjectURL(old);}catch(_){}}};ctx.img.src=url;
   }
   ctx.meta.textContent=`${ctx.control?'Contrôle':'Vue'} · ${ctx.width||'—'}×${ctx.height||'—'}`;
   ctx.frameTimer=setTimeout(()=>pollFloatingRemote(ctx),70);
 }catch(_){ctx.meta.textContent='Reconnexion…';ctx.frameTimer=setTimeout(()=>pollFloatingRemote(ctx),450);}
}
let floatingRemoteZ=10120;
function floatingRemoteStorageKey(agentId){return `DMD-RemoteAgent:floating:${String(agentId||'')}`;}
function floatingRemoteBringToFront(root){
 if(!root)return;
 floatingRemoteZ=Math.max(floatingRemoteZ+1,10121);
 root.style.zIndex=String(floatingRemoteZ);
}
function floatingRemoteSaveGeometry(ctx){
 if(!ctx||!ctx.root||!ctx.root.isConnected)return;
 const r=ctx.root.getBoundingClientRect();
 try{localStorage.setItem(floatingRemoteStorageKey(ctx.agentId),JSON.stringify({left:r.left,top:r.top,width:r.width,height:r.height}));}catch(_){}
}
function floatingRemoteRestoreGeometry(ctx){
 if(!ctx||!ctx.root)return;
 const root=ctx.root;
 let saved=null;
 try{saved=JSON.parse(localStorage.getItem(floatingRemoteStorageKey(ctx.agentId))||'null');}catch(_){}
 const r=root.getBoundingClientRect();
 const width=Math.max(420,Math.min(window.innerWidth-10,Number(saved&&saved.width)||r.width||980));
 const height=Math.max(260,Math.min(window.innerHeight-10,Number(saved&&saved.height)||r.height||610));
 const cascade=Math.min(180,floatingRemotes.size*24);
 let left=Number(saved&&saved.left);
 let top=Number(saved&&saved.top);
 if(!Number.isFinite(left))left=Math.max(8,Math.round((window.innerWidth-width)/2)+cascade);
 if(!Number.isFinite(top))top=Math.max(8,80+cascade);
 left=Math.max(0,Math.min(Math.max(0,window.innerWidth-60),left));
 top=Math.max(0,Math.min(Math.max(0,window.innerHeight-24),top));
 root.style.position='fixed';root.style.left=left+'px';root.style.top=top+'px';root.style.right='auto';root.style.bottom='auto';
 root.style.width=width+'px';root.style.height=height+'px';
}
function bindFloatingRemoteWindow(ctx){
 if(!ctx||!ctx.root)return;
 const root=ctx.root,handle=root.querySelector('.dmd-ra-floating-drag');
 floatingRemoteBringToFront(root);
 floatingRemoteRestoreGeometry(ctx);
 root.addEventListener('pointerdown',()=>floatingRemoteBringToFront(root),true);
 if(handle){
  let drag=null;
  handle.addEventListener('pointerdown',e=>{
   if(e.button!==0)return;
   const r=root.getBoundingClientRect();
   drag={id:e.pointerId,dx:e.clientX-r.left,dy:e.clientY-r.top};
   floatingRemoteBringToFront(root);
   try{handle.setPointerCapture(e.pointerId);}catch(_){}
   e.preventDefault();e.stopPropagation();
  });
  handle.addEventListener('pointermove',e=>{
   if(!drag||e.pointerId!==drag.id)return;
   const r=root.getBoundingClientRect();
   const minVisible=60,headVisible=24;
   const minX=Math.min(0,window.innerWidth-minVisible-r.width);
   const maxX=Math.max(0,window.innerWidth-minVisible);
   const maxY=Math.max(0,window.innerHeight-headVisible);
   const x=Math.max(minX,Math.min(maxX,e.clientX-drag.dx));
   const y=Math.max(0,Math.min(maxY,e.clientY-drag.dy));
   root.style.left=x+'px';root.style.top=y+'px';
   e.preventDefault();e.stopPropagation();
  });
  const end=e=>{
   if(!drag||e.pointerId!==drag.id)return;
   try{handle.releasePointerCapture(e.pointerId);}catch(_){}
   drag=null;floatingRemoteSaveGeometry(ctx);e.preventDefault();e.stopPropagation();
  };
  handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end);
 }
 // Le redimensionnement reste entièrement local au module (CSS resize:both).
 if(typeof ResizeObserver==='function'){
  let resizeTimer=null;
  ctx.resizeObserver=new ResizeObserver(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>floatingRemoteSaveGeometry(ctx),180);});
  ctx.resizeObserver.observe(root);
 }
}
function closeFloatingRemote(agentId,sendStop){
 const ctx=floatingRemotes.get(String(agentId||''));if(!ctx)return;
 ctx.closed=true;
 floatingRemoteSaveGeometry(ctx);
 if(ctx.resizeObserver){try{ctx.resizeObserver.disconnect();}catch(_){}}
 if(ctx.frameTimer)clearTimeout(ctx.frameTimer);if(ctx.inputTimer)clearTimeout(ctx.inputTimer);
 if(ctx.imageUrl){try{URL.revokeObjectURL(ctx.imageUrl);}catch(_){}}
 floatingRemotes.delete(ctx.agentId);
 if(ctx.root&&ctx.root.remove)ctx.root.remove();
 if(sendStop!==false)apiPost('command',{agent_id:ctx.agentId,operation:'remote.stop',params:{}}).catch(()=>{});
}
function openFloatingRemote(device,control){
 if(!device||!device.agent_id)return null;
 const agentId=String(device.agent_id);
 let ctx=floatingRemotes.get(agentId);
 if(ctx&&ctx.root&&ctx.root.isConnected){
   floatingRemoteBringToFront(ctx.root);
   ctx.control=!!control;ctx.root.classList.toggle('dmd-ra-control-active',ctx.control);ctx.mode.textContent=ctx.control?'CTRL':'VUE';ctx.meta.textContent=`${ctx.control?'Contrôle':'Vue'} · ${ctx.width||'—'}×${ctx.height||'—'}`;bindFloatingRemoteInput(ctx);if(ctx.control){try{ctx.stage.focus({preventScroll:true});}catch(_){ctx.stage.focus();}}return ctx;
 }
 const key=floatingRemoteKey(agentId);
 const root=document.createElement('section');
 root.className='dmd-ra-floating-remote';root.dataset.dmdRaFloatingAgent=agentId;root.setAttribute('role','dialog');root.setAttribute('aria-label',`Remote ${device.hostname||'PC'}`);
 root.innerHTML=`<header class="dmd-ra-floating-head"><span class="dmd-ra-floating-drag" title="Déplacer" aria-label="Déplacer" role="button" tabindex="0">⠿</span><span class="dmd-ra-live online"></span><strong>${esc(device.hostname||'PC')}</strong><small>${esc(device.last_ip||'')}</small><span class="dmd-ra-floating-mode">${control?'CTRL':'VUE'}</span><span class="dmd-ra-floating-meta">Connexion…</span><select class="dmd-ra-floating-resolution" title="Résolution réelle" aria-label="Résolution Remote"><option value="">Résolution…</option></select><select class="dmd-ra-floating-display" title="Mode d’affichage" aria-label="Mode d’affichage"><option value="fit">Adapter</option><option value="1to1">1:1</option></select><button type="button" class="dmd-ra-floating-detach" title="Détacher dans une fenêtre indépendante" aria-label="Détacher">↗</button><button type="button" class="dmd-ra-floating-close" title="Fermer le Remote" aria-label="Fermer">×</button></header><div class="dmd-ra-floating-stage" tabindex="0"><img alt="Écran distant ${esc(device.hostname||'PC')}" draggable="false"></div>`;
 document.body.appendChild(root);
 ctx={agentId,device,root,stage:root.querySelector('.dmd-ra-floating-stage'),img:root.querySelector('img'),meta:root.querySelector('.dmd-ra-floating-meta'),mode:root.querySelector('.dmd-ra-floating-mode'),resolutionSelect:root.querySelector('.dmd-ra-floating-resolution'),displaySelect:root.querySelector('.dmd-ra-floating-display'),rejectedResolutions:new Set(),seq:0,width:0,height:0,control:!!control,frameTimer:null,inputTimer:null,inputBusy:false,inputQueue:[],movePending:null,lastMove:0,imageUrl:'',closed:false,resizeObserver:null};
 floatingRemotes.set(agentId,ctx);
 root.classList.toggle('dmd-ra-control-active',ctx.control);
 root.querySelector('.dmd-ra-floating-close').addEventListener('click',e=>{e.preventDefault();e.stopPropagation();closeFloatingRemote(agentId,true);});
 const detachBtn=root.querySelector('.dmd-ra-floating-detach');
 if(detachBtn)detachBtn.addEventListener('click',e=>{
   e.preventDefault();e.stopPropagation();
   const base=String(boot.detached||'modules/DMD-RemoteAgent/DMD-RemoteAgent_detached.php');
   const url=`${base}?agent_id=${encodeURIComponent(agentId)}&control=${ctx.control?'1':'0'}`;
   const win=window.open(url,`DMDRemote_${key}`,'popup=yes,width=1280,height=820,resizable=yes,scrollbars=no');
   if(!win){toast('Le navigateur a bloqué la fenêtre Remote. Autorise les popups pour DoMyDesk.');return;}
   closeFloatingRemote(agentId,false);
   setStatus(`Remote ${device.hostname||'PC'} détaché dans une fenêtre indépendante.`,false);
 });
 const resolutionSelect=ctx.resolutionSelect;
 if(resolutionSelect)resolutionSelect.addEventListener('change',async e=>{
   e.stopPropagation();const mode=String(resolutionSelect.value||'');if(!mode)return;resolutionSelect.disabled=true;ctx.meta.textContent=mode==='auto'?'Détection résolution…':`Demande ${remoteResolutionLabel(mode)}…`;
   try{
     const done=await executeForAgent(agentId,'remote.resolution',{mode},{timeout:20000});
     const r=remoteResolutionUnwrap(done),actual=remoteResolutionName(r.width,r.height);
     if(r.applied===false&&mode!=='auto')ctx.rejectedResolutions.add(mode);
     floatingResolutionRender(ctx,r);if(actual)floatingResolutionSync(ctx,r.width,r.height);ctx.seq=0;
     if(r.applied===false){ctx.meta.textContent=`${remoteResolutionLabel(mode)} refusé · ${remoteResolutionLabel(actual)||'inchangée'}`;toast(String(r.message||`Résolution ${mode} non disponible sur ce PC.`));}
     else ctx.meta.textContent=String(r.message||`Résolution réelle ${remoteResolutionLabel(actual||mode)}`);
   }catch(err){ctx.meta.textContent='Résolution inchangée';toast(err.message||'Changement de résolution impossible.');floatingResolutionSync(ctx,ctx.width,ctx.height);}
   finally{resolutionSelect.disabled=false;}
 });
 const displaySelect=ctx.displaySelect;
 if(displaySelect){let initial='fit';try{initial=localStorage.getItem(`DMD-RemoteAgent:display:${agentId}`)||'fit';}catch(_){}floatingDisplayApply(ctx,initial);displaySelect.addEventListener('change',e=>{e.stopPropagation();floatingDisplayApply(ctx,displaySelect.value);});}
 floatingResolutionLoad(ctx);
 bindFloatingRemoteInput(ctx);
 bindFloatingRemoteWindow(ctx);
 pollFloatingRemote(ctx);
 if(ctx.control)setTimeout(()=>{try{ctx.stage.focus({preventScroll:true});}catch(_){ctx.stage.focus();}},0);
 return ctx;
}
function showDetachedRemoteMessage(control){
 const stage=remoteStage();
 if(stage){stopRemoteBrowser();stage.innerHTML='<span>Aucune session Remote intégrée active.</span>';}
 // La fenêtre PC reste sur le dashboard, mais on évite l'immense panneau noir derrière le Remote flottant.
 switchTab('overview');
 setStatus(`Remote ${control?'en contrôle':'en vue'} ouvert sur le dashboard.`,false);
}

function renderProcesses(result){
 const el=document.getElementById('dmdRaProcessesResult');if(result&&result.truncated){el.innerHTML=`<span>${esc(result.message||'Résultat processus trop volumineux.')}</span>`;return;}const rows=Array.isArray(result&&result.processes)?result.processes:(Array.isArray(result)?result:[]);if(!rows.length){renderGenericResult(el,result);return;}
 const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||25),total=Number(result&&result.total||rows.length),hasMore=!!(result&&result.has_more),prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
 const nav=`<div class="dmd-ra-result-meta"><span>${offset+1}-${offset+rows.length} / ${total} processus</span><span class="dmd-ra-inline-actions">${offset>0?`<button type="button" data-process-offset="${prev}">‹ Précédent</button>`:''}${hasMore?`<button type="button" data-process-offset="${next}">Suivant ›</button>`:''}</span></div>`;
 el.innerHTML=nav+`<div class="dmd-ra-table">${rows.map(p=>`<div class="dmd-ra-data-row process"><span><strong>${esc(p.name||p.process||'Processus')}</strong><small>PID ${esc(p.pid||'—')}${p.user?' · '+esc(p.user):''}</small><small title="${esc(p.path||'')}">${esc(p.path||'')}</small></span><span>${esc(p.cpu!=null?p.cpu+' %':'—')}</span><span>${esc(p.memory_bytes!=null?formatBytes(p.memory_bytes):(p.memory||p.ram||'—'))}</span>${hasPerm('processes.kill')&&!p.protected?`<button type="button" class="danger small" data-kill-pid="${esc(p.pid||'')}">Arrêter</button>`:`<span class="dmd-ra-protected">Protégé</span>`}</div>`).join('')}</div>`;
}
function serviceStatusLabel(v){const m={running:'En cours',stopped:'Arrêté',start_pending:'Démarrage…',stop_pending:'Arrêt…',continue_pending:'Reprise…',pause_pending:'Mise en pause…',paused:'En pause'};return m[String(v||'').toLowerCase()]||String(v||'—');}
function renderServices(result){
 const el=document.getElementById('dmdRaServicesResult');if(result&&result.truncated){el.innerHTML=`<span>${esc(result.message||'Résultat services trop volumineux.')}</span>`;return;}const rows=Array.isArray(result&&result.services)?result.services:(Array.isArray(result)?result:[]);if(!rows.length){renderGenericResult(el,result);return;}
 const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||40),total=Number(result&&result.total||rows.length),hasMore=!!(result&&result.has_more),prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
 const nav=`<div class="dmd-ra-result-meta"><span>${offset+1}-${offset+rows.length} / ${total} services</span><span class="dmd-ra-inline-actions">${offset>0?`<button type="button" data-service-offset="${prev}">‹ Précédent</button>`:''}${hasMore?`<button type="button" data-service-offset="${next}">Suivant ›</button>`:''}</span></div>`;
 el.innerHTML=nav+`<div class="dmd-ra-table">${rows.map(s=>{let actions='<span class="dmd-ra-protected">Aucune action</span>';if(s.protected){actions='<span class="dmd-ra-protected">Protégé</span>';}else if(hasPerm('services.control')){const a=[];if(s.can_start)a.push(`<button type="button" data-service="${esc(s.name||'')}" data-service-op="start">Démarrer</button>`);if(s.can_stop)a.push(`<button type="button" data-service="${esc(s.name||'')}" data-service-op="stop">Arrêter</button>`);if(s.can_restart)a.push(`<button type="button" data-service="${esc(s.name||'')}" data-service-op="restart">Redémarrer</button>`);if(a.length)actions=`<span class="dmd-ra-inline-actions">${a.join('')}</span>`;}return `<div class="dmd-ra-data-row service"><span><strong>${esc(s.display_name||s.name||'Service')}</strong><small>${esc(s.name||'')}${s.start_mode?' · '+esc(s.start_mode):''}${s.pid?' · PID '+esc(s.pid):''}</small></span><span>${esc(serviceStatusLabel(s.status))}</span>${actions}</div>`;}).join('')}</div>`;
}
function renderSoftware(result){const el=document.getElementById('dmdRaSoftwareResult');const rows=Array.isArray(result&&result.software)?result.software:(Array.isArray(result)?result:[]);const total=Number(result&&result.total||rows.length);const offset=Number(result&&result.offset||0);const limit=Number(result&&result.limit||40);if(!rows.length){el.innerHTML=`<div class="dmd-ra-empty-result">${total?'Aucun logiciel sur cette page.':'Aucun logiciel correspondant.'}</div>`;return;}const nav=`<div class="dmd-ra-pager"><button type="button" data-software-offset="${Math.max(0,Number(result.prev_offset||0))}" ${offset<=0?'disabled':''}>Précédent</button><span>${offset+1}–${offset+rows.length} / ${total}</span><button type="button" data-software-offset="${Number(result.next_offset||offset+limit)}" ${result&&result.has_more?'':'disabled'}>Suivant</button></div>`;el.innerHTML=`${nav}<div class="dmd-ra-table">${rows.map(s=>{const meta=[s.publisher||'',s.scope==='user'?'Utilisateur':'Machine',s.install_date||''].filter(Boolean).join(' · ');let action='';if(hasPerm('software.uninstall')){if(s.protected)action='<span class="dmd-ra-protected">Protégé</span>';else if(s.can_uninstall)action=`<button type="button" class="danger small" data-uninstall-id="${esc(s.id||'')}" data-uninstall-name="${esc(s.name||'Logiciel')}">Désinstaller</button>`;else action='<span>Non désinstallable</span>';}return `<div class="dmd-ra-data-row software"><span><strong>${esc(s.name||'Logiciel')}</strong><small>${esc(meta)}</small></span><span>${esc(s.version||'—')}</span>${action}</div>`;}).join('')}</div>${nav}`;}
async function loadSoftware(offset){const input=document.getElementById('dmdRaSoftwareSearch');const query=input?input.value.trim():'';const c=await execute('software.list',{offset:Math.max(0,Number(offset||0)),limit:40,query},{timeout:60000,silent:true,noRefresh:true});renderSoftware(commandResult(c)||{});return c;}
async function loadHistory(){if(!current)return;const el=document.getElementById('dmdRaHistoryResult');el.textContent='Chargement…';try{const d=await apiGet('history',{agent_id:current.agent_id,limit:50});const rows=Array.isArray(d.commands)?d.commands:[];el.innerHTML=rows.length?`<div class="dmd-ra-history">${rows.map(c=>`<div><span class="status ${esc(c.status||'')}"></span><strong>${esc(c.type||'commande')}</strong><small>${esc(formatDate(c.created_at))} · ${esc(c.created_by||'')}</small><b>${esc(c.status||'')}</b></div>`).join('')}</div>`:'Aucune commande enregistrée pour ce PC.';}catch(e){el.textContent=e.message;}}

list.addEventListener('click',e=>{const card=e.target.closest('[data-agent-id]');if(!card)return;e.preventDefault();openDevice(card.dataset.agentId);});
document.getElementById('dmdRaSearch').addEventListener('input',renderCards);document.getElementById('dmdRaStatusFilter').addEventListener('change',renderCards);
const dmdRaDragHandle=document.getElementById('dmdRaDragHandle');
if(dmdRaDragHandle){
 let dmdRaDrag=null;
 dmdRaDragHandle.addEventListener('pointerdown',e=>{
  if(e.button!==0)return;
  const win=modal.querySelector('.dmd-ra-window');if(!win)return;
  const r=win.getBoundingClientRect();
  dmdRaDrag={id:e.pointerId,dx:e.clientX-r.left,dy:e.clientY-r.top,w:r.width,h:r.height};
  win.style.position='fixed';win.style.left=r.left+'px';win.style.top=r.top+'px';win.style.margin='0';
  try{dmdRaDragHandle.setPointerCapture(e.pointerId);}catch(_){ }
  e.preventDefault();e.stopPropagation();
 });
 dmdRaDragHandle.addEventListener('pointermove',e=>{
  if(!dmdRaDrag||e.pointerId!==dmdRaDrag.id)return;
  const win=modal.querySelector('.dmd-ra-window');if(!win)return;
  const maxX=Math.max(0,window.innerWidth-dmdRaDrag.w),maxY=Math.max(0,window.innerHeight-dmdRaDrag.h);
  const x=Math.max(0,Math.min(maxX,e.clientX-dmdRaDrag.dx));
  const y=Math.max(0,Math.min(maxY,e.clientY-dmdRaDrag.dy));
  win.style.left=x+'px';win.style.top=y+'px';
  e.preventDefault();
 });
 const dmdRaEndDrag=e=>{if(!dmdRaDrag||e.pointerId!==dmdRaDrag.id)return;try{dmdRaDragHandle.releasePointerCapture(e.pointerId);}catch(_){ }dmdRaDrag=null;};
 dmdRaDragHandle.addEventListener('pointerup',dmdRaEndDrag);
 dmdRaDragHandle.addEventListener('pointercancel',dmdRaEndDrag);
}
document.getElementById('dmdRaClose').addEventListener('click',closeModal);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal&&!modal.hidden)closeModal();});
document.getElementById('dmdRaTabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b&&!b.hidden)switchTab(b.dataset.tab);});
document.getElementById('dmdRaRefreshState').addEventListener('click',()=>refreshState(false));
const clipboardToggle=document.getElementById('dmdRaClipboardToggle');if(clipboardToggle)clipboardToggle.addEventListener('click',()=>{const p=document.getElementById('dmdRaClipboardPanel');if(p)p.hidden=!p.hidden;});
const historyRefresh=document.getElementById('dmdRaHistoryRefresh');if(historyRefresh)historyRefresh.addEventListener('click',()=>loadHistory());

modal.addEventListener('click',async e=>{
 const fp=e.target.closest('[data-file-offset]');if(fp){try{await browseFiles(document.getElementById('dmdRaPath').value,Number(fp.dataset.fileOffset||0));}catch(err){toast(err.message||'Chargement impossible.');}return;}
 const dl=e.target.closest('[data-download-path]');if(dl){dl.disabled=true;try{await downloadRemoteFile(dl.dataset.downloadPath,dl.dataset.downloadName||'fichier',Number(dl.dataset.downloadSize||0));}catch(err){toast(err.message||'Téléchargement impossible.');clearFileTransfer();}finally{dl.disabled=false;}return;}
 const ren=e.target.closest('[data-rename-path]');if(ren){const name=prompt('Nouveau nom :',ren.dataset.renameName||'');if(!name||name===ren.dataset.renameName)return;try{await execute('files.rename',{path:ren.dataset.renamePath,name},{timeout:60000});await browseFiles(document.getElementById('dmdRaPath').value,0);}catch(err){toast(err.message||'Renommage impossible.');}return;}
 const pp=e.target.closest('[data-process-offset]');if(pp){const offset=Number(pp.dataset.processOffset||0);pp.disabled=true;pp.textContent='Chargement…';setStatus('Chargement de la page processus…',true);try{const c=await execute('processes.list',{offset,limit:25},{timeout:30000});renderProcesses(commandResult(c));}catch(e){toast(e.message||'Chargement impossible.');}return;}
 const sp=e.target.closest('[data-service-offset]');if(sp){const offset=Number(sp.dataset.serviceOffset||0);sp.disabled=true;sp.textContent='Chargement…';setStatus('Chargement de la page services…',true);try{const c=await execute('services.list',{offset,limit:40},{timeout:30000});renderServices(commandResult(c));}catch(e){toast(e.message||'Chargement impossible.');}return;}
 const swp=e.target.closest('[data-software-offset]');if(swp){swp.disabled=true;try{await loadSoftware(Number(swp.dataset.softwareOffset||0));}catch(err){toast(err.message||'Chargement logiciels impossible.');}return;}
 const opBtn=e.target.closest('[data-operation]');
 if(opBtn){const op=opBtn.dataset.operation;const opDevice=current;if(opBtn.dataset.confirm&&!confirm(opBtn.dataset.confirm))return;let params={};if(op==='processes.list')params={offset:0,limit:25};else if(op==='services.list')params={offset:0,limit:40};try{const c=await execute(op,params,{timeout:op==='agent.update'?300000:120000});const r=commandResult(c);if(op==='software.list')renderSoftware(r);else if(op==='processes.list')renderProcesses(r);else if(op==='services.list')renderServices(r);else if(op==='remote.clipboard.get'){document.getElementById('dmdRaClipboard').value=typeof r==='string'?r:String(r&&r.text||'');}else if(op==='remote.screen'){openFloatingRemote(opDevice,false);showDetachedRemoteMessage(false);}else if(op==='remote.control'){openFloatingRemote(opDevice,true);showDetachedRemoteMessage(true);}else if(op==='remote.stop'){if(opDevice)closeFloatingRemote(opDevice.agent_id,false);stopRemoteBrowser();remoteStage().innerHTML='<span>Aucune session Remote active.</span>';}else if(op.indexOf('remote.')===0){renderGenericResult(document.getElementById('dmdRaRemoteStage'),r);}else if(op.indexOf('system.')===0||op==='agent.update'||op==='pc.refresh')renderGenericResult(document.getElementById('dmdRaSystemResult'),r);}catch(_){}return;}
 const pathBtn=e.target.closest('[data-path]');if(pathBtn){const path=pathBtn.dataset.path||'';document.getElementById('dmdRaPath').value=path;try{await browseFiles(path,0);}catch(err){toast(err.message||'Ouverture impossible.');}return;}
 const del=e.target.closest('[data-delete-path]');if(del){const isDir=del.dataset.deleteDir==='1';const msg=isDir?`Supprimer le dossier ${del.dataset.deletePath} et tout son contenu ?`:`Supprimer ${del.dataset.deletePath} ?`;if(!confirm(msg))return;try{await execute('files.delete',{path:del.dataset.deletePath,recursive:isDir},{timeout:120000});await browseFiles(document.getElementById('dmdRaPath').value,0);}catch(err){toast(err.message||'Suppression impossible.');}return;}
 const kill=e.target.closest('[data-kill-pid]');if(kill){if(!confirm(`Arrêter le PID ${kill.dataset.killPid} ?`))return;try{await execute('processes.kill',{pid:Number(kill.dataset.killPid)});const c=await execute('processes.list',{offset:0,limit:25});renderProcesses(commandResult(c));}catch(_){}return;}
 const svc=e.target.closest('[data-service]');if(svc){const op=svc.dataset.serviceOp||'restart';svc.disabled=true;try{const done=await execute('services.control',{name:svc.dataset.service,operation:op},{timeout:90000});toast(`Service ${svc.dataset.service} : ${op} OK`);const c=await execute('services.list',{offset:0,limit:40},{timeout:30000});renderServices(commandResult(c));}catch(err){toast(err.message||'Action service impossible.');}return;}
 const uns=e.target.closest('[data-uninstall-id]');if(uns){const name=uns.dataset.uninstallName||uns.dataset.uninstallId;if(!confirm(`Désinstaller ${name} ?\n\nLa désinstallation est définitive et s'exécute sur le PC distant.`))return;uns.disabled=true;try{const done=await execute('software.uninstall',{id:uns.dataset.uninstallId},{timeout:720000});const r=commandResult(done)||{};toast(r.reboot_required?`${name} désinstallé. Un redémarrage Windows est requis.`:`${name} : désinstallation terminée.`);await new Promise(resolve=>setTimeout(resolve,1500));await loadSoftware(0);}catch(err){toast(err.message||'Désinstallation impossible.');}finally{uns.disabled=false;}return;}
});

document.getElementById('dmdRaSoftwareRefresh').addEventListener('click',()=>loadSoftware(0).catch(e=>toast(e.message||'Inventaire logiciels impossible.')));
document.getElementById('dmdRaSoftwareSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();loadSoftware(0).catch(err=>toast(err.message||'Recherche impossible.'));}});
document.getElementById('dmdRaRoots').addEventListener('click',async()=>{try{await browseFiles('',0);}catch(err){toast(err.message||'Lecture des racines impossible.');}});
document.getElementById('dmdRaBrowse').addEventListener('click',async()=>{const path=document.getElementById('dmdRaPath').value.trim();try{await browseFiles(path,0);}catch(err){toast(err.message||'Ouverture impossible.');}});
document.getElementById('dmdRaMkdir').addEventListener('click',async()=>{const base=document.getElementById('dmdRaPath').value.trim();const name=prompt('Nom du nouveau dossier :');if(!name)return;try{await execute('files.mkdir',{path:base,name},{timeout:60000});await browseFiles(base,0);}catch(err){toast(err.message||'Création impossible.');}});
document.getElementById('dmdRaUpload').addEventListener('click',()=>document.getElementById('dmdRaUploadInput').click());
document.getElementById('dmdRaUploadInput').addEventListener('change',async e=>{const file=e.target.files&&e.target.files[0];if(!file)return;try{await uploadRemoteFile(file);}catch(err){toast(err.message||'Envoi impossible.');clearFileTransfer();}finally{e.target.value='';}});
document.getElementById('dmdRaClipboardSend').addEventListener('click',async()=>{try{await execute('remote.clipboard.set',{text:document.getElementById('dmdRaClipboard').value});}catch(_){}});
document.getElementById('dmdRaTerminalRun').addEventListener('click',async()=>{const input=document.getElementById('dmdRaTerminalInput');const shell=document.getElementById('dmdRaTerminalShell').value||'powershell';const cmd=input.value.trim();if(!cmd)return;const out=document.getElementById('dmdRaTerminalOutput');out.textContent+=`\n[${shell}] > ${cmd}\n`;input.value='';try{const c=await execute('system.terminal',{command:cmd,shell,timeout_seconds:45},{timeout:180000,silent:true,noRefresh:true});const r=commandResult(c)||{};if(r.stdout)out.textContent+=r.stdout;if(r.stderr)out.textContent+=`\n[stderr]\n${r.stderr}`;out.textContent+=`\n[exit ${r.exit_code??'—'} · ${r.duration_ms??0} ms${r.timed_out?' · timeout':''}${r.truncated?' · sortie tronquée':''}]\n`;}catch(e){out.textContent+=`ERREUR: ${e.message}\n`;}out.scrollTop=out.scrollHeight;});
document.getElementById('dmdRaTerminalInput').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();document.getElementById('dmdRaTerminalRun').click();}});

const dmdRaMfaForm=document.getElementById('dmdRaMfaForm');if(dmdRaMfaForm)dmdRaMfaForm.addEventListener('submit',e=>{e.preventDefault();const input=document.getElementById('dmdRaMfaCode');unlockSecurity(input?input.value:'');});
applySecurityState(security,false);

(function registerProvider(){const provider={id:'DMD-RemoteAgent',getResources(){return devices.map(d=>d.resource).filter(Boolean);}};let tries=0;const install=()=>{tries++;if(window.DMDActionHub&&typeof window.DMDActionHub.registerProvider==='function'){window.DMDActionHub.registerProvider(provider);return;}if(tries<30)setTimeout(install,250);};install();})();
if(modalWindow&&window.DMDWorkspace&&typeof window.DMDWorkspace.registerPopup==='function'){window.DMDWorkspace.registerPopup(modalWindow,{key:'DMD-RemoteAgent:pc',handle:'.dmd-ra-window-head'});}
renderCards();
setInterval(()=>refreshState(true),30000);
})();
