(function(){
'use strict';
const boot = window.DMD_REMOTEAGENT_BOOT || {};
const app = document.getElementById('dmdRemoteAgentApp');
if (!app || app.dataset.dmdRaReady === '1') return;
app.dataset.dmdRaReady = '1';
let devices = Array.isArray(boot.devices) ? boot.devices : [];
let current = null;
let currentTab = 'overview';
let touchStamp = Object.create(null);
let touchTimer = null;
const list = document.getElementById('dmdRaList');
const empty = document.getElementById('dmdRaEmpty');
const modal = document.getElementById('dmdRaModal');
const modalWindow = modal ? modal.querySelector('.dmd-ra-window') : null;
if(modal)modal.dataset.dmdWindowIgnore='1';
if(modalWindow)modalWindow.dataset.dmdWindowIgnore='1';
let security = boot.security && typeof boot.security === 'object' ? boot.security : {enabled:false,required:false,unlocked:true,session_minutes:15,account_mfa:false,expires_at:0,blocked_reason:''};
let securityTimer = null;
let floatingRemotes = new Map();
const selectedAgents = new Set();
const expandedGroups = new Set();

function workspaceHost(){
 const ws=document.getElementById('dashboard');
 if(!ws)return null;
 if(window.DMDWorkspace&&typeof window.DMDWorkspace.isMobileView==='function'&&window.DMDWorkspace.isMobileView())return null;
 return ws;
}
function requestWorkspaceExpansion(){
 if(typeof window.DMDExpandDashboardCanvas==='function')requestAnimationFrame(()=>window.DMDExpandDashboardCanvas());
}
function workspacePointFromViewport(x,y){
 const ws=workspaceHost();if(!ws)return{x:Number(x)||0,y:Number(y)||0};
 const r=ws.getBoundingClientRect();
 return{x:(Number(x)||0)-r.left+(ws.scrollLeft||0),y:(Number(y)||0)-r.top+(ws.scrollTop||0)};
}
function mountWorkspaceWindow(windowEl,key){
 const ws=workspaceHost();if(!ws||!windowEl)return false;
 const overlay=windowEl.closest('.dmd-ra-modal');
 if(overlay){
   overlay.dataset.dmdWindowIgnore='1';
   overlay.classList.add('dmd-workspace-overlay');
   if(overlay.parentElement!==ws)ws.appendChild(overlay);
 }else if(windowEl.parentElement!==ws){
   ws.appendChild(windowEl);
 }
 windowEl.dataset.dmdWindowIgnore='1';
 windowEl.dataset.dmdRaWorkspace='1';
 windowEl.dataset.dmdRaGeometryKey=String(key||'');
 windowEl.classList.add('dmd-managed-window','dmd-workspace-window','dmd-workspace-positioned','dmd-ra-own-window-manager');
 Object.assign(windowEl.style,{position:'absolute',right:'auto',bottom:'auto',margin:'0',transform:'none',maxWidth:'none',maxHeight:'none'});
 requestWorkspaceExpansion();
 return true;
}
function workspaceWindowPosition(windowEl){
 if(!windowEl)return{left:0,top:0};
 if(windowEl.dataset.dmdRaWorkspace==='1'){
   return{left:Number.parseFloat(windowEl.style.left)||0,top:Number.parseFloat(windowEl.style.top)||0};
 }
 const r=windowEl.getBoundingClientRect();return{left:r.left,top:r.top};
}
function bindOwnWindowDrag(root,handle,onEnd){
 if(!root||!handle||handle.dataset.dmdRaOwnDrag==='1')return;
 handle.dataset.dmdRaOwnDrag='1';
 let drag=null;
 handle.addEventListener('pointerdown',e=>{
   if(e.button!==0)return;
   const interactive=e.target.closest('button,select,input,textarea,a');
   if(interactive&&!e.target.closest('.dmd-ra-drag-handle,.dmd-ra-floating-drag'))return;
   const pos=workspaceWindowPosition(root),r=root.getBoundingClientRect();
   drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,left:pos.left,top:pos.top,width:r.width,height:r.height,workspace:root.dataset.dmdRaWorkspace==='1'};
   try{handle.setPointerCapture(e.pointerId);}catch(_){}
   floatingRemoteZ=Math.max(floatingRemoteZ+1,10121);root.style.zIndex=String(floatingRemoteZ);
   e.preventDefault();e.stopPropagation();
 });
 handle.addEventListener('pointermove',e=>{
   if(!drag||drag.id!==e.pointerId)return;
   let left=drag.left+(e.clientX-drag.startX),top=drag.top+(e.clientY-drag.startY);
   if(drag.workspace){
     left=Math.max(0,left);top=Math.max(0,top);
   }else{
     left=Math.min(Math.max(4,left),Math.max(4,window.innerWidth-drag.width-4));
     top=Math.min(Math.max(4,top),Math.max(4,window.innerHeight-drag.height-4));
   }
   root.style.left=Math.round(left)+'px';root.style.top=Math.round(top)+'px';
   if(drag.workspace)requestWorkspaceExpansion();
   e.preventDefault();
 });
 const end=e=>{
   if(!drag||drag.id!==e.pointerId)return;
   drag=null;try{handle.releasePointerCapture(e.pointerId);}catch(_){}
   if(typeof onEnd==='function')onEnd();
   requestWorkspaceExpansion();e.preventDefault();
 };
 handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end);
}

function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
function formatBytes(bytes){const n=Number(bytes||0);if(!Number.isFinite(n)||n<=0)return '—';const u=['o','Ko','Mo','Go','To'];let i=0,v=n;while(v>=1024&&i<u.length-1){v/=1024;i++;}return `${v>=10||i===0?v.toFixed(0):v.toFixed(1)} ${u[i]}`;}
function formatDate(v){if(!v)return '—';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('fr-FR');}
const FILE_CHUNK=28672,FILE_BATCH=8,FILE_MAX=2*1024*1024*1024;
let remoteTimer=null,remoteSeq=0,remoteControl=false,remoteWidth=0,remoteHeight=0,remoteLastMove=0,remoteMovePending=null,remoteInputQueue=[],remoteInputTimer=null,remoteInputBusy=false,remoteViewer=null;
function base64ToBytes(value){const bin=atob(String(value||''));const out=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);return out;}
function bytesToBase64(bytes){let out='';const step=8192;for(let i=0;i<bytes.length;i+=step){const part=bytes.subarray(i,Math.min(i+step,bytes.length));out+=String.fromCharCode.apply(null,part);}return btoa(out);}
function winJoin(base,name){base=String(base||'').replace(/[\\/]+$/,'');return base+'\\'+String(name||'');}
function fileTransferStatus(text,done,total){const el=document.getElementById('dmdRaFileTransfer');if(!el)return;el.hidden=false;const pct=total>0?Math.min(100,Math.round((done/total)*100)):100;el.innerHTML=`<strong>${esc(text)}</strong><span>${esc(formatBytes(done))} / ${esc(formatBytes(total))} · ${pct}%</span>`;}
function clearFileTransfer(){const el=document.getElementById('dmdRaFileTransfer');if(el){el.hidden=true;el.textContent='';}}
function hasPerm(permission){if(!current)return false;if(boot.isSuperadmin)return true;return Array.isArray(current.permissions)&&current.permissions.includes(permission);}
function hasAny(csv){if(!csv)return true;return csv.split(',').map(x=>x.trim()).filter(Boolean).some(hasPerm);}
function deviceById(id){return devices.find(d=>String(d.agent_id||'')===String(id||''))||null;}
function isIPv4(value){
 const v=String(value||'').trim();
 if(!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(v))return false;
 return v.split('.').every(part=>{const n=Number(part);return Number.isInteger(n)&&n>=0&&n<=255;});
}
function deviceIPv4(d){
 d=d&&typeof d==='object'?d:{};
 const inv=(d.inventory&&typeof d.inventory==='object')?d.inventory:((d.last_inventory&&typeof d.last_inventory==='object')?d.last_inventory:{});
 const active=inv.active_interface&&typeof inv.active_interface==='object'?inv.active_interface:{};
 if(isIPv4(active.ipv4))return String(active.ipv4).trim();
 const nets=Array.isArray(inv.network)?inv.network:[];
 for(const nic of nets){
   const ips=nic&&Array.isArray(nic.ips)?nic.ips:[];
   for(const raw of ips){
     const ip=String(raw||'').split('/')[0].trim();
     if(isIPv4(ip)&&!ip.startsWith('127.'))return ip;
   }
 }
 if(isIPv4(d.last_ip))return String(d.last_ip).trim();
 return 'IPv4 inconnue';
}

function securityBlockedMessage(state){
 const reason=String(state&&state.blocked_reason||'');
 if(reason==='mfa_not_configured')return 'Active le MFA dans ton profil avant d’utiliser DMD-RemoteAgent.';
 if(reason==='mfa_disabled_by_policy')return 'Le MFA est désactivé pour ce compte par la politique DoMyDesk.';
 if(reason==='mfa_unavailable')return 'Le moteur MFA central DoMyDesk est indisponible.';
 return 'Saisis ton code Microsoft Authenticator pour déverrouiller le module.';
}
function securityCloseRemoteUi(){
 stopRemoteBrowser();
 for(const agentId of Array.from(floatingRemotes.keys())){try{closeFloatingRemote(agentId,false);}catch(_){}}
 if(modal){modal.hidden=true;modal.classList.remove('open');}
 current=null;
}
function applySecurityState(next,closeOnLock=true){
 if(next&&typeof next==='object')security=Object.assign({},security,next);
 const locked=!!security.enabled&&!security.unlocked;
 app.classList.toggle('dmd-ra-is-locked',locked);
 const gate=document.getElementById('dmdRaSecurityGate');if(gate)gate.hidden=!locked;
 const msg=document.getElementById('dmdRaSecurityMessage');if(msg)msg.textContent=securityBlockedMessage(security);
 const form=document.getElementById('dmdRaMfaForm');if(form)form.hidden=!locked||!security.account_mfa;
 const setup=document.getElementById('dmdRaMfaSetupLink');if(setup)setup.hidden=String(security.blocked_reason||'')!=='mfa_not_configured';
 const countdown=document.getElementById('dmdRaSecurityCountdown');
 if(countdown){countdown.hidden=!security.enabled||locked;if(!countdown.hidden)updateSecurityCountdown();}
 if(locked&&closeOnLock){securityCloseRemoteUi();devices=[];renderCards();}
 if(securityTimer){clearInterval(securityTimer);securityTimer=null;}
 if(security.enabled&&security.unlocked&&Number(security.expires_at||0)>0)securityTimer=setInterval(updateSecurityCountdown,1000);
}
function updateSecurityCountdown(){
 if(!security.enabled||!security.unlocked)return;
 const remain=Math.max(0,Number(security.expires_at||0)-Math.floor(Date.now()/1000));
 const el=document.getElementById('dmdRaSecurityCountdown');
 if(el){const m=Math.floor(remain/60),sec=remain%60;el.textContent=`🔐 ${m}:${String(sec).padStart(2,'0')}`;el.title=`Verrouillage MFA dans ${m} min ${sec} s`;}
 if(remain<=0){
   apiPost('security_lock',{}).catch(()=>{});
   applySecurityState({unlocked:false,verified_at:0,expires_at:0,remaining_seconds:0,blocked_reason:''},true);
 }
}
function handleSecurityDenied(data){
 if(data&&data.security)applySecurityState(data.security,true);
 else applySecurityState({enabled:true,required:true,unlocked:false,expires_at:0,blocked_reason:''},true);
}
async function unlockSecurity(code){
 const errorEl=document.getElementById('dmdRaSecurityError');if(errorEl)errorEl.textContent='';
 const input=document.getElementById('dmdRaMfaCode');const form=document.getElementById('dmdRaMfaForm');const button=form?form.querySelector('button'):null;
 if(button)button.disabled=true;
 try{
   const d=await apiPost('security_unlock',{code:String(code||'')});
   applySecurityState(d.security||{enabled:true,unlocked:true},false);
   if(input)input.value='';
   const state=await apiGet('state');devices=Array.isArray(state.devices)?state.devices:[];renderCards();toast(d.message||'DMD-RemoteAgent déverrouillé.');
 }catch(e){if(errorEl)errorEl.textContent=e.message||'Code MFA incorrect.';if(input){input.select();input.focus();}}
 finally{if(button)button.disabled=false;}
}

async function apiGet(action, params){const q=new URLSearchParams(params||{});q.set('action',action);q.set('_',Date.now());const r=await fetch(`${boot.api}?${q}`,{credentials:'same-origin',cache:'no-store'});const d=await r.json().catch(()=>({}));if((d&&d.error)==='module_mfa_required')handleSecurityDenied(d);if(!r.ok||!d.ok){const e=new Error(d.message||d.error||'Erreur API');e.data=d;throw e;}return d;}
async function apiPost(action,payload){const r=await fetch(`${boot.api}?action=${encodeURIComponent(action)}`,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-DMD-CSRF':String(boot.csrf||'')},body:JSON.stringify(payload||{})});const d=await r.json().catch(()=>({}));if((d&&d.error)==='module_mfa_required')handleSecurityDenied(d);if(!r.ok||!d.ok){const e=new Error(d.message||d.error||'Erreur API');e.data=d;throw e;}return d;}
function setStatus(text,busy){const el=document.getElementById('dmdRaCommandStatus');if(el){el.textContent=text||'';el.classList.toggle('busy',!!busy);}}
function toast(text){if(window.DMDWorkspace&&typeof window.DMDWorkspace.toast==='function')window.DMDWorkspace.toast(text);else setStatus(text,false);}

function deviceHasPerm(device,perm){if(boot.isSuperadmin)return true;return !!device&&Array.isArray(device.permissions)&&device.permissions.includes(perm);}
function selectedDevices(){return devices.filter(d=>selectedAgents.has(String(d.agent_id||'')));}
function updateSelectionToolbar(){
 const el=document.getElementById('dmdRaSelectionBar');if(!el)return;
 const rows=selectedDevices();const count=rows.length;
 el.hidden=count===0;
 const counter=el.querySelector('[data-selection-count]');if(counter)counter.textContent=String(count);
 const view=el.querySelector('[data-selection-remote="screen"]');if(view)view.disabled=!rows.some(d=>d.online&&deviceHasPerm(d,'remote.screen'));
 const ctrl=el.querySelector('[data-selection-remote="control"]');if(ctrl)ctrl.disabled=!rows.some(d=>d.online&&deviceHasPerm(d,'remote.control'));
}
function ensureSelectionToolbar(){
 let el=document.getElementById('dmdRaSelectionBar');if(el)return el;
 el=document.createElement('div');el.id='dmdRaSelectionBar';el.className='dmd-ra-selection-bar';el.hidden=true;
 el.innerHTML='<strong><span data-selection-count>0</span> PC sélectionné(s)</strong><span></span><button type="button" data-selection-remote="screen">Voir</button><button type="button" data-selection-remote="control">Contrôle</button><button type="button" data-selection-clear>Effacer</button>';
 const top=document.querySelector('.dmd-ra-topbar');if(top&&top.parentNode)top.parentNode.insertBefore(el,top.nextSibling);
 el.addEventListener('click',e=>{
   const clear=e.target.closest('[data-selection-clear]');if(clear){selectedAgents.clear();renderCards();return;}
   const action=e.target.closest('[data-selection-remote]');if(!action)return;
   const perm=action.dataset.selectionRemote==='control'?'remote.control':'remote.screen';const control=perm==='remote.control';
   let opened=0;selectedDevices().forEach(d=>{if(!d.online||!deviceHasPerm(d,perm))return;try{openFloatingRemote(d,control);opened++;}catch(err){toast(err.message||'Remote impossible.');}});
   if(!opened)toast('Aucun PC sélectionné disponible pour cette action.');
 });
 return el;
}
function renderCards(){
 const q=String(document.getElementById('dmdRaSearch').value||'').trim().toLowerCase();
 const f=String(document.getElementById('dmdRaStatusFilter').value||'all');
 const filtered=devices.filter(d=>{
   const text=[d.hostname,deviceIPv4(d),d.platform,d.arch,d.agent_version,(d.groups||[]).map(g=>g.name).join(' ')].join(' ').toLowerCase();
   return (!q||text.includes(q))&&(f==='all'||(f==='online'&&d.online)||(f==='offline'&&!d.online));
 });
 const validIds=new Set(devices.map(d=>String(d.agent_id||'')));for(const id of Array.from(selectedAgents)){if(!validIds.has(id))selectedAgents.delete(id);}
 const groups=new Map();
 filtered.forEach(d=>{
   const memberships=Array.isArray(d.groups)&&d.groups.length?d.groups:[{group_id:'__ungrouped__',name:'Sans groupe'}];
   memberships.forEach(g=>{
     const name=String(g&&g.name||'').trim()||'Sans groupe';const key=String(g&&g.group_id||'').trim()||`name:${name.toLowerCase()}`;
     if(!groups.has(key))groups.set(key,{key,name,devices:[]});groups.get(key).devices.push(d);
   });
 });
 const sortedGroups=Array.from(groups.values()).sort((a,b)=>{if(a.name==='Sans groupe'&&b.name!=='Sans groupe')return 1;if(b.name==='Sans groupe'&&a.name!=='Sans groupe')return -1;return a.name.localeCompare(b.name,'fr',{sensitivity:'base'});});
 if(q){sortedGroups.forEach(g=>expandedGroups.add(g.key));}
 const cardHtml=d=>{const id=String(d.agent_id||''),selected=selectedAgents.has(id);return `<div class="dmd-ra-card ${d.online?'online':'offline'}${selected?' selected':''}" data-agent-row="${esc(id)}" data-dmd-context data-dmd-context-type="remoteagent_pc" data-dmd-context-id="${esc(d.resource&&d.resource.id||'')}" data-dmd-context-name="${esc(d.hostname||'PC')}" data-dmd-context-source="DMD-RemoteAgent"><label class="dmd-ra-card-select" title="Sélectionner ${esc(d.hostname||'PC')}"><input type="checkbox" data-select-agent="${esc(id)}" ${selected?'checked':''}><span></span></label><button type="button" class="dmd-ra-card-open" data-agent-id="${esc(id)}" title="${esc((d.hostname||'PC')+' — '+deviceIPv4(d))}"><span class="dmd-ra-live ${d.online?'online':''}"></span><span class="dmd-ra-card-ident"><strong>${esc(d.hostname||'PC')}</strong><small>${esc(deviceIPv4(d))}</small></span></button></div>`;};
 list.innerHTML=sortedGroups.map(group=>{
   group.devices.sort((a,b)=>{if(!!a.online!==!!b.online)return a.online?-1:1;return String(a.hostname||'').localeCompare(String(b.hostname||''),'fr',{sensitivity:'base'});});
   const open=expandedGroups.has(group.key);const online=group.devices.filter(d=>d.online).length;const allSelected=group.devices.length>0&&group.devices.every(d=>selectedAgents.has(String(d.agent_id||'')));
   return `<section class="dmd-ra-group${open?' open':''}" data-group-key="${esc(group.key)}"><div class="dmd-ra-group-card"><label class="dmd-ra-group-select" title="Sélectionner tous les PC du groupe"><input type="checkbox" data-select-group="${esc(group.key)}" ${allSelected?'checked':''}><span></span></label><button type="button" class="dmd-ra-group-toggle" data-toggle-group="${esc(group.key)}" aria-expanded="${open?'true':'false'}"><span class="dmd-ra-group-chevron">›</span><span class="dmd-ra-group-name"><strong>${esc(group.name)}</strong><small>${online} en ligne · ${group.devices.length} PC</small></span></button></div><div class="dmd-ra-group-grid" ${open?'':'hidden'}>${group.devices.map(cardHtml).join('')}</div></section>`;
 }).join('');
 empty.hidden=filtered.length!==0;document.getElementById('dmdRaOnlineCount').textContent=String(devices.filter(d=>d.online).length);document.getElementById('dmdRaTotalCount').textContent=String(devices.length);ensureSelectionToolbar();updateSelectionToolbar();if(window.DMDActionHub&&typeof window.DMDActionHub.decorate==='function')window.DMDActionHub.decorate(list);
}
function kv(label,value){return `<div class="dmd-ra-kv"><span>${esc(label)}</span><strong>${esc(value==null||value===''?'—':value)}</strong></div>`;}
function renderOverview(){
 if(!current)return;
 const inv=current.inventory||{},hw=current.hardware||{},os=(inv.os&&typeof inv.os==='object')?inv.os:{},cpu=inv.cpu||{},ram=inv.ram||{},up=inv.uptime||{};
 const net=Array.isArray(inv.network)?inv.network:[];const groups=Array.isArray(current.groups)?current.groups:[];
 const active=inv.active_interface&&typeof inv.active_interface==='object'?inv.active_interface:{};
 const vols=Array.isArray(inv.volumes)?inv.volumes:[];const ports=Array.isArray(inv.open_ports)?inv.open_ports:[];const sessions=Array.isArray(inv.sessions)?inv.sessions:[];
 const gpus=Array.isArray(inv.gpu)?inv.gpu:[];
 const pct=v=>{const n=Number(v);return Number.isFinite(n)?`${Math.round(n*10)/10}%`:'—';};
 const ramTotal=ram.total_bytes?formatBytes(ram.total_bytes):(ram.total_gb!=null?ram.total_gb+' Go':'—');
 const ramUsed=ram.used_bytes?formatBytes(ram.used_bytes):(ram.used_gb!=null?ram.used_gb+' Go':'—');
 const osLabel=[inv.os_name||os.name||current.platform,inv.os_version||os.version,inv.os_build?`build ${inv.os_build}`:''].filter(Boolean).join(' ');
 const gpuLabel=gpus.length?gpus.map(g=>typeof g==='string'?g:(g.name||g.model||'')).filter(Boolean).join(' · '):'—';
 const activeIPs=[active.ipv4,active.ipv6].filter(Boolean).join(' · ');
 document.getElementById('dmdRaOverview').innerHTML=`
 <div class="dmd-ra-overview-grid">
  <section class="dmd-ra-panel"><h3>Machine</h3>${kv('Nom',current.hostname)}${kv('IPv4 active',deviceIPv4(current))}${kv('Système',osLabel||'—')}${kv('Architecture',current.arch)}${kv('Utilisateur actif',inv.active_session||inv.logged_on_user||'—')}${kv('Domaine / Workgroup',inv.domain||inv.workgroup||'—')}${kv('DMD-Agent',current.agent_version)}${kv('Dernier contact',formatDate(current.last_seen_at))}</section>
  <section class="dmd-ra-panel"><h3>Matériel</h3>${kv('Constructeur',inv.manufacturer||hw.system_vendor)}${kv('Modèle',inv.model||hw.system_product)}${kv('UUID',inv.system_uuid||hw.system_uuid)}${kv('N° série BIOS',inv.serial_number||hw.bios_serial)}${kv('Carte mère',(inv.baseboard&&inv.baseboard.product)||hw.baseboard_product)}${kv('TPM',inv.tpm||hw.tpm)}${kv('Secure Boot',inv.secure_boot)}${kv('GPU',gpuLabel)}</section>
  <section class="dmd-ra-panel"><h3>CPU / mémoire</h3>${kv('CPU',cpu.model)}${kv('Cœurs / threads',[cpu.cores?cpu.cores+' cœurs':'',cpu.threads?cpu.threads+' threads':''].filter(Boolean).join(' / '))}${kv('Charge CPU',pct(cpu.usage_percent!=null?cpu.usage_percent:inv.cpu_usage_percent))}${kv('RAM installée',ramTotal)}${kv('RAM utilisée',ramUsed)}${kv('Charge RAM',pct(ram.usage_percent))}${kv('Uptime',up.human||'—')}${kv('Dernier démarrage',formatDate(inv.last_boot_at))}</section>
  <section class="dmd-ra-panel"><h3>Réseau actif</h3>${kv('Interface',active.name)}${kv('IP',activeIPs)}${kv('MAC',active.mac)}${kv('Passerelle',active.gateway||inv.gateway)}${kv('DNS',Array.isArray(active.dns)?active.dns.join(' · '):(Array.isArray(inv.dns)?inv.dns.join(' · '):'—'))}${kv('Vitesse',active.speed_mbps?active.speed_mbps+' Mbps':'—')}${kv('Ports TCP en écoute',ports.length)}</section>
  <section class="dmd-ra-panel full"><h3>Stockage</h3><div class="dmd-ra-network">${vols.length?vols.map(v=>`<div><strong>${esc(v.letter||v.name||'Volume')}</strong><span>${esc(v.total_bytes?`${formatBytes(v.used_bytes)} / ${formatBytes(v.total_bytes)} · ${pct(v.usage_percent)}`:'—')}</span><small>${esc(v.filesystem||'')}</small></div>`).join(''):'<span>Aucune donnée disque.</span>'}</div></section>
  <section class="dmd-ra-panel full"><h3>Interfaces réseau</h3><div class="dmd-ra-network">${net.length?net.map(n=>`<div><strong>${esc(n.name||'Interface')}</strong><span>${esc((n.ips||[]).join(' · ')||'—')}</span><small>${esc(n.mac||'')}</small></div>`).join(''):'<span>Aucune donnée réseau.</span>'}</div></section>
  <section class="dmd-ra-panel full"><h3>Sessions et ports</h3>${kv('Session active',inv.active_session||inv.logged_on_user||'—')}${kv('Sessions détectées',sessions.length)}${kv('Ports TCP en écoute',ports.length)}${ports.length?`<div class="dmd-ra-chips">${ports.slice(0,24).map(p=>`<span>${esc((p.port||'')+'/'+(p.protocol||'TCP')+(p.process?' · '+p.process:''))}</span>`).join('')}${ports.length>24?`<span>+${ports.length-24}</span>`:''}</div>`:''}</section>
  <section class="dmd-ra-panel full"><h3>Groupes et droits</h3><div class="dmd-ra-chips">${groups.length?groups.map(g=>`<span>${esc(g.name)}</span>`).join(''):'<span>Sans groupe</span>'}</div><div class="dmd-ra-chips rights">${(current.permissions||[]).length?(current.permissions||[]).map(p=>`<span>${esc(p)}</span>`).join(''):'<span>Aucun droit opérationnel</span>'}</div></section>
 </div>`;
}
function applyPermissions(){if(!current)return;modal.querySelectorAll('[data-perm]').forEach(el=>{el.hidden=!hasPerm(el.dataset.perm);});modal.querySelectorAll('[data-perm-any]').forEach(el=>{el.hidden=!hasAny(el.dataset.permAny);});}
function switchTab(name){currentTab=name;document.querySelectorAll('#dmdRaTabs [data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));modal.querySelectorAll('[data-pane]').forEach(p=>{const on=p.dataset.pane===name;p.hidden=!on;p.classList.toggle('active',on);});modal.querySelectorAll('[data-actions-pane]').forEach(g=>{g.hidden=g.dataset.actionsPane!==name;});const cp=document.getElementById('dmdRaClipboardPanel');if(cp&&name!=='remote')cp.hidden=true;if(name==='files'&&hasPerm('files.browse')){const out=document.getElementById('dmdRaFilesResult');const path=document.getElementById('dmdRaPath');if(path)path.value='';if(out)out.innerHTML='<div class="dmd-ra-loading-line">Détection des lecteurs du poste…</div>';browseFiles('',0).catch(e=>{if(out)out.innerHTML=`<div class="dmd-ra-empty-state">${esc(e&&e.message?e.message:'Lecture des lecteurs impossible.')}</div>`;toast(e&&e.message?e.message:'Lecture des lecteurs impossible.');});}if(name==='history')loadHistory();if(name==='software'&&hasPerm('software.view'))loadSoftware(0).catch(e=>toast(e.message||'Inventaire logiciels impossible.'));if(name==='registry'&&hasPerm('registry.read'))loadRegistry().catch(e=>toast(e.message||'Lecture registre impossible.'));if(name==='devices'&&hasAny('devices.manage,network.manage'))loadDevicesAndNetwork().catch(e=>toast(e.message||'Lecture périphériques impossible.'));}
function openDevice(id){current=deviceById(id);if(!current)return;document.getElementById('dmdRaTitle').textContent=current.hostname||'PC';document.getElementById('dmdRaSub').textContent=[deviceIPv4(current),current.platform,current.agent_version].filter(Boolean).join(' · ');document.getElementById('dmdRaStateLine').textContent=current.online?'● En ligne':'○ Hors ligne';document.getElementById('dmdRaStateLine').classList.toggle('online',!!current.online);renderOverview();applyPermissions();switchTab('overview');modal.hidden=false;modal.classList.add('open');if(modalWindow&&mountWorkspaceWindow(modalWindow,'DMD-RemoteAgent:pc-window')){modal.style.pointerEvents='none';restoreMainWindowGeometry();}else{if(modal.parentElement!==document.body)document.body.appendChild(modal);restoreMainWindowGeometry();}if(touchTimer){clearInterval(touchTimer);touchTimer=null;}const agentId=current.agent_id;touchStamp[agentId]=Date.now();apiPost('touch',{agent_id:agentId}).catch(()=>{});const keepInteractive=()=>{if(!current||current.agent_id!==agentId)return;apiPost('interactive_touch',{agent_id:agentId}).catch(()=>{});};touchTimer=setInterval(keepInteractive,15000);setStatus('Prêt.',false);}
function closeModal(){if(touchTimer){clearInterval(touchTimer);touchTimer=null;}saveMainWindowGeometry();stopRemoteBrowser();modal.classList.remove('open');modal.hidden=true;current=null;}

async function refreshState(silent){try{if(!silent)setStatus('Actualisation…',true);const d=await apiGet('state');devices=Array.isArray(d.devices)?d.devices:[];renderCards();if(current){const updated=deviceById(current.agent_id);if(updated){current=updated;document.getElementById('dmdRaSub').textContent=[deviceIPv4(current),current.platform,current.agent_version].filter(Boolean).join(' · ');renderOverview();applyPermissions();}}if(!silent)setStatus('État actualisé.',false);}catch(e){if(!silent)setStatus(e.message,false);}}
async function waitCommand(agentId,commandId,timeoutMs,silent){const started=Date.now();while(Date.now()-started<timeoutMs){await new Promise(r=>setTimeout(r,150));const d=await apiGet('command_status',{agent_id:agentId,command_id:commandId});const c=d.command||{};if(!silent)setStatus(`Commande ${c.status||'…'}`,c.status==='queued'||c.status==='delivered');if(['completed','failed','cancelled','expired'].includes(String(c.status||'')))return c;}throw new Error('Délai de réponse de l’agent dépassé.');}
async function execute(operation,params,opts){if(!current)return null;opts=opts||{};const agentId=current.agent_id;try{if(!opts.silent)setStatus('Envoi de la commande…',true);const d=await apiPost('command',{agent_id:agentId,operation,params:params||{}});const c=d.command||{};if(!opts.silent)toast(d.message||'Commande envoyée.');if(opts.noWait)return c;const done=await waitCommand(agentId,c.command_id,opts.timeout||120000,!!opts.silent);if(done.status==='failed'||done.status==='expired'||done.status==='cancelled')throw new Error(done.error||`Commande ${done.status}.`);if(!opts.silent)setStatus('Commande terminée.',false);if(!opts.noRefresh)await refreshState(true);return done;}catch(e){if(!opts.silent)setStatus(e.message||'Commande impossible.',false);throw e;}}
function commandResult(c){if(!c)return null;if(c.result!==undefined)return c.result;return null;}
function renderGenericResult(el,result){if(!el)return;if(result==null){el.innerHTML='<span>Aucune donnée retournée.</span>';return;}if(typeof result==='string'||typeof result==='number'||typeof result==='boolean'){el.innerHTML=`<pre>${esc(result)}</pre>`;return;}el.innerHTML=`<pre>${esc(JSON.stringify(result,null,2))}</pre>`;}

function renderFiles(result){
 const el=document.getElementById('dmdRaFilesResult');if(!el)return;
 const roots=Array.isArray(result&&result.roots)?result.roots:null;
 const entries=Array.isArray(result&&result.entries)?result.entries:(Array.isArray(result)?result:null);
 if(roots){el.innerHTML=`<div class="dmd-ra-table dmd-ra-roots">${roots.length?roots.map(r=>{const obj=typeof r==='string'?{path:r,label:r}:r;const path=String(obj.path||obj.name||'');const label=String(obj.label||obj.volume_name||path||'Lecteur');const meta=[];if(obj.filesystem)meta.push(String(obj.filesystem));if(obj.drive_type_name)meta.push(String(obj.drive_type_name));if(Number(obj.total_bytes)>0){const total=Number(obj.total_bytes),free=Number(obj.free_bytes||0);meta.push(`${formatBytes(Math.max(0,total-free))} / ${formatBytes(total)}`);}return `<button type="button" class="dmd-ra-file-row root" data-path="${esc(path)}"><strong>${esc(path)}${label&&label!==path?` · ${esc(label)}`:''}</strong>${meta.length?`<span>${esc(meta.join(' · '))}</span>`:''}</button>`;}).join(''):'<span>Aucun volume local détecté.</span>'}</div>`;return;}
 if(entries){
   const path=String(result&&result.path||'');if(path)document.getElementById('dmdRaPath').value=path;
   const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||80),total=Number(result&&result.total||entries.length),hasMore=!!(result&&result.has_more),prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+entries.length);
   const parent=result&&result.parent?`<button type="button" data-path="${esc(result.parent)}">↑ Dossier parent</button>`:'';
   const nav=`<div class="dmd-ra-result-meta"><span>${esc(path||'Dossier')} · ${total} élément(s)</span><span class="dmd-ra-inline-actions">${parent}${offset>0?`<button type="button" data-file-offset="${prev}">‹ Précédent</button>`:''}${hasMore?`<button type="button" data-file-offset="${next}">Suivant ›</button>`:''}</span></div>`;
   el.innerHTML=nav+`<div class="dmd-ra-table">${entries.length?entries.map(e=>{const isDir=!!e.is_dir;const ep=e.path||'';const actions=[];if(!isDir&&hasPerm('files.download'))actions.push(`<button type="button" class="small" data-download-path="${esc(ep)}" data-download-name="${esc(e.name||'fichier')}" data-download-size="${esc(e.size||0)}">Télécharger</button>`);if(isDir&&hasPerm('files.download'))actions.push(`<button type="button" class="small" data-download-folder="${esc(ep)}" data-download-folder-name="${esc(e.name||'dossier')}">Télécharger dossier</button>`);if(hasPerm('files.rename'))actions.push(`<button type="button" class="small" data-rename-path="${esc(ep)}" data-rename-name="${esc(e.name||'')}">Renommer</button>`);if(hasPerm('files.delete'))actions.push(`<button type="button" class="danger small" data-delete-path="${esc(ep)}" data-delete-dir="${isDir?'1':'0'}">Supprimer</button>`);return `<div class="dmd-ra-file-row"><button type="button" ${isDir?`data-path="${esc(ep)}"`:''}><strong>${isDir?'▸ ':'▹ '}${esc(e.name||ep)}</strong><span>${isDir?'Dossier':formatBytes(e.size)}${e.modified_at?' · '+esc(formatDate(e.modified_at)):''}</span></button><span class="dmd-ra-inline-actions">${actions.join('')}</span></div>`;}).join(''):'<span>Dossier vide.</span>'}</div>`;
   return;
 }
 renderGenericResult(el,result);
}

async function browseFiles(path,offset=0){path=String(path||'').trim();if(!path){const c=await execute('files.roots',{}, {timeout:60000});renderFiles(commandResult(c));return;}const c=await execute('files.list',{path,offset:Number(offset)||0,limit:80},{timeout:60000});renderFiles(commandResult(c));}

async function downloadRemoteFile(path,name,size){
 size=Number(size||0);if(size<0||size>FILE_MAX)throw new Error('Fichier trop volumineux pour le transfert DMD-Agent (2 Gio maximum).');
 clearFileTransfer();fileTransferStatus(`Téléchargement ${name}`,0,size);
 if(size===0){const url=URL.createObjectURL(new Blob([]));const a=document.createElement('a');a.href=url;a.download=name||'fichier';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);clearFileTransfer();return;}
 const offsets=[];for(let o=0;o<size;o+=FILE_CHUNK)offsets.push(o);const chunks=[];let done=0;
 for(let i=0;i<offsets.length;i+=FILE_BATCH){const batch=offsets.slice(i,i+FILE_BATCH);const results=await Promise.all(batch.map(async o=>{const c=await execute('files.read',{path,offset:o,length:Math.min(FILE_CHUNK,size-o),transfer_final:(o+Math.min(FILE_CHUNK,size-o)>=size)},{timeout:180000,silent:true,noRefresh:true});const r=commandResult(c)||{};if(r.truncated||typeof r.data_base64!=='string')throw new Error('Bloc de téléchargement invalide.');return r;}));results.sort((a,b)=>Number(a.offset||0)-Number(b.offset||0));for(const r of results){const b=base64ToBytes(r.data_base64);chunks.push(b);done+=b.byteLength;fileTransferStatus(`Téléchargement ${name}`,done,size);}}
 const blob=new Blob(chunks);const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name||'fichier';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);fileTransferStatus(`Téléchargement terminé : ${name}`,size,size);setTimeout(clearFileTransfer,1800);
}

async function uploadRemoteFile(file){const base=document.getElementById('dmdRaPath').value.trim();if(!base)throw new Error('Ouvre d’abord un dossier de destination.');const path=winJoin(base,file.name);await uploadRemoteFileToPath(file,path,base);fileTransferStatus(`Envoi terminé : ${file.name}`,file.size,file.size);setTimeout(clearFileTransfer,1800);}


function registryValueText(v){
 if(v===null||v===undefined)return '';
 if(Array.isArray(v))return v.join('\n');
 if(typeof v==='object')return JSON.stringify(v);
 return String(v);
}
function renderRegistry(result){
 const el=document.getElementById('dmdRaRegistryResult');if(!el)return;
 const keys=Array.isArray(result&&result.keys)?result.keys:[];
 const values=Array.isArray(result&&result.values)?result.values:[];
 const hive=String(result&&result.hive||document.getElementById('dmdRaRegistryHive')?.value||'HKLM');
 const path=String(result&&result.path||'');
 const pi=document.getElementById('dmdRaRegistryPath');if(pi)pi.value=path;
 const up=path.includes('\\')?path.split('\\').slice(0,-1).join('\\'):'';
 const nav=`<div class="dmd-ra-result-meta"><span>${esc(hive+'\\'+path)}</span><span>${path?`<button type="button" data-reg-path="${esc(up)}">↑ Parent</button>`:''}</span></div>`;
 const keyRows=keys.map(k=>`<div class="dmd-ra-file-row"><button type="button" data-reg-path="${esc(k.path||k.name||'')}"><strong>▸ ${esc(k.name||'Clé')}</strong></button>${hasPerm('registry.write')?`<span class="dmd-ra-inline-actions"><button type="button" class="danger small" data-reg-delete-key="${esc(k.path||'')}">Supprimer</button></span>`:''}</div>`).join('');
 const valRows=values.map(v=>`<div class="dmd-ra-file-row"><button type="button" data-reg-value="${esc(v.raw_name??v.name??'')}" data-reg-type="${esc(String(v.type||'String').toLowerCase())}" data-reg-data="${esc(registryValueText(v.value))}"><strong>${esc(v.name||'(Par défaut)')}</strong><span>${esc(v.type||'')} · ${esc(registryValueText(v.value).slice(0,160))}</span></button>${hasPerm('registry.write')?`<span class="dmd-ra-inline-actions"><button type="button" class="danger small" data-reg-delete-value="${esc(v.raw_name??'')}">Supprimer</button></span>`:''}</div>`).join('');
 el.innerHTML=nav+`<div class="dmd-ra-table">${keyRows||'<span>Aucune sous-clé.</span>'}</div><div class="dmd-ra-table">${valRows||'<span>Aucune valeur.</span>'}</div>`;
}
async function loadRegistry(path){
 const hive=document.getElementById('dmdRaRegistryHive')?.value||'HKLM';
 const p=path!==undefined?String(path):String(document.getElementById('dmdRaRegistryPath')?.value||'');
 const c=await execute('registry.list',{hive,path:p},{timeout:60000,silent:true,noRefresh:true});
 renderRegistry(commandResult(c)||{});
}
async function saveRegistryValue(){
 const hive=document.getElementById('dmdRaRegistryHive')?.value||'HKLM',path=document.getElementById('dmdRaRegistryPath')?.value||'',name=document.getElementById('dmdRaRegistryName')?.value||'',value_type=document.getElementById('dmdRaRegistryType')?.value||'string',value=document.getElementById('dmdRaRegistryValue')?.value||'';
 await execute('registry.set',{hive,path,name,value_type,value},{timeout:90000});await loadRegistry(path);
}
async function deleteRegistryValue(name){
 const hive=document.getElementById('dmdRaRegistryHive')?.value||'HKLM',path=document.getElementById('dmdRaRegistryPath')?.value||'';
 if(!confirm(`Supprimer la valeur ${name||'(Par défaut)'} ?`))return;
 await execute('registry.delete',{hive,path,name,scope:'value'},{timeout:90000});await loadRegistry(path);
}
async function deleteRegistryKey(path){
 const hive=document.getElementById('dmdRaRegistryHive')?.value||'HKLM';if(!confirm(`Supprimer la clé ${hive}\\${path} et son contenu ?`))return;
 await execute('registry.delete',{hive,path,scope:'key',recursive:true},{timeout:90000});await loadRegistry(document.getElementById('dmdRaRegistryPath')?.value||'');
}
function renderRemovable(result){
 const el=document.getElementById('dmdRaRemovableResult');if(!el)return;const vols=Array.isArray(result&&result.volumes)?result.volumes:[],usb=Array.isArray(result&&result.usb_devices)?result.usb_devices:[];
 el.innerHTML=`<div class="dmd-ra-table">${vols.length?vols.map(v=>`<div class="dmd-ra-file-row"><div><strong>${esc(v.letter||'Lecteur')}</strong><span>${esc(v.label||v.kind||'')} · ${esc(v.filesystem||'')} · ${esc(formatBytes(v.size))}</span></div>${hasPerm('devices.manage')?`<span class="dmd-ra-inline-actions"><button type="button" class="danger small" data-eject-letter="${esc(v.letter||'')}">Éjecter</button></span>`:''}</div>`).join(''):'<span>Aucun support amovible monté.</span>'}</div>${usb.length?`<div class="dmd-ra-table">${usb.map(u=>`<div class="dmd-ra-file-row"><div><strong>${esc(u.model||'Périphérique USB')}</strong><span>${esc(u.serial||'')} · ${esc(formatBytes(u.size))}</span></div></div>`).join('')}</div>`:''}`;
}
function renderNetworkPaths(result){
 const el=document.getElementById('dmdRaNetworkResult');if(!el)return;let rows=result&&result.paths;if(!Array.isArray(rows))rows=rows?[rows]:[];
 el.innerHTML=`<div class="dmd-ra-table">${rows.length?rows.map(v=>`<div class="dmd-ra-file-row"><div><strong>${esc(v.local_path||'')}</strong><span>${esc(v.remote_path||'')} · ${esc(v.scope||'')} · ${esc(v.status||'')}</span></div>${hasPerm('network.manage')?`<span class="dmd-ra-inline-actions"><button type="button" class="danger small" data-network-remove="${esc(v.local_path||'')}">Retirer</button></span>`:''}</div>`).join(''):'<span>Aucun chemin réseau mappé.</span>'}</div>`;
}
async function loadDevicesAndNetwork(){
 const jobs=[];if(hasPerm('devices.manage'))jobs.push(execute('devices.removable.list',{}, {timeout:60000,silent:true,noRefresh:true}).then(c=>renderRemovable(commandResult(c)||{})));if(hasPerm('network.manage'))jobs.push(execute('network.paths.list',{}, {timeout:60000,silent:true,noRefresh:true}).then(c=>renderNetworkPaths(commandResult(c)||{})));await Promise.all(jobs);
}
async function addNetworkPath(){
 const local_path=(document.getElementById('dmdRaNetworkLetter')?.value||'').trim(),remote_path=(document.getElementById('dmdRaNetworkPath')?.value||'').trim();if(!local_path||!remote_path)throw new Error('Lettre et chemin réseau requis.');await execute('network.paths.add',{local_path,remote_path},{timeout:90000});await loadDevicesAndNetwork();
}
async function uploadRemoteFileToPath(file,path,refreshBase){
 if(!file)return;if(file.size>FILE_MAX)throw new Error('Fichier trop volumineux : maximum 2 Gio.');fileTransferStatus(`Envoi ${file.name}`,0,file.size);
 if(file.size===0){await execute('files.write',{path,offset:0,truncate:true,data_base64:'',transfer_final:true},{timeout:180000,silent:true,noRefresh:true});if(refreshBase)await browseFiles(refreshBase,0);return;}
 const firstBytes=new Uint8Array(await file.slice(0,Math.min(FILE_CHUNK,file.size)).arrayBuffer());await execute('files.write',{path,offset:0,truncate:true,data_base64:bytesToBase64(firstBytes),transfer_final:(firstBytes.byteLength>=file.size)},{timeout:180000,silent:true,noRefresh:true});let done=firstBytes.byteLength;fileTransferStatus(`Envoi ${file.name}`,done,file.size);
 const offsets=[];for(let o=FILE_CHUNK;o<file.size;o+=FILE_CHUNK)offsets.push(o);for(let i=0;i<offsets.length;i+=FILE_BATCH){const batch=offsets.slice(i,i+FILE_BATCH);await Promise.all(batch.map(async o=>{const bytes=new Uint8Array(await file.slice(o,Math.min(o+FILE_CHUNK,file.size)).arrayBuffer());await execute('files.write',{path,offset:o,truncate:false,data_base64:bytesToBase64(bytes),transfer_final:(o+bytes.byteLength>=file.size)},{timeout:180000,silent:true,noRefresh:true});return bytes.byteLength;})).then(lengths=>{done+=lengths.reduce((a,b)=>a+b,0);fileTransferStatus(`Envoi ${file.name}`,done,file.size);});}
 if(refreshBase)await browseFiles(refreshBase,0);
}
async function uploadRemoteFolder(fileList){
 const base=document.getElementById('dmdRaPath').value.trim();if(!base)throw new Error('Ouvre d’abord un dossier de destination.');const files=Array.from(fileList||[]);if(!files.length)return;
 const made=new Set();for(const file of files){const rel=String(file.webkitRelativePath||file.name).replace(/\//g,'\\');const parts=rel.split('\\').filter(Boolean);parts.pop();let cur=base;for(const part of parts){const parent=cur;cur=winJoin(cur,part);if(!made.has(cur)){try{await execute('files.mkdir',{path:parent,name:part},{timeout:60000,silent:true,noRefresh:true});}catch(_){}made.add(cur);}}await uploadRemoteFileToPath(file,winJoin(base,rel),'');}
 await browseFiles(base,0);const total=files.reduce((a,f)=>a+Number(f.size||0),0);fileTransferStatus(`Dossier envoyé · ${files.length} fichier(s)`,total,total);setTimeout(clearFileTransfer,1800);
}
async function downloadRemoteFolder(path,name){
 const stamp=Date.now(),safe=String(name||'dossier').replace(/[<>:"/\\|?*]+/g,'_').slice(0,80)||'dossier',archive=`C:\\Windows\\Temp\\DMD-Folder-${stamp}-${safe}.zip`;
 fileTransferStatus(`Préparation ${safe}.zip`,0,1);
 try{const packed=await execute('files.archive',{path,archive_path:archive},{timeout:20*60*1000,silent:true,noRefresh:true});const r=commandResult(packed)||{};await downloadRemoteFile(archive,`${safe}.zip`,Number(r.archive_bytes||0));}
 finally{try{await execute('files.delete',{path:archive,recursive:false},{timeout:60000,silent:true,noRefresh:true});}catch(_){}}
}

let integratedRemoteSession=null;
function remoteStage(){return document.getElementById('dmdRaRemoteStage');}
function stopRemoteBrowser(){
 if(integratedRemoteSession){try{integratedRemoteSession.close();}catch(_){}integratedRemoteSession=null;}
 remoteControl=false;remoteWidth=0;remoteHeight=0;
 const stage=remoteStage();if(stage){stage.onkeydown=null;stage.onkeyup=null;}
}
function fitIntegratedRemoteCanvas(){
 const stage=remoteStage(),canvas=document.getElementById('dmdRaRemoteImage');
 if(!stage||!canvas||!(remoteWidth>0)||!(remoteHeight>0))return;
 const r=stage.getBoundingClientRect();if(!(r.width>0)||!(r.height>0))return;
 const scale=Math.min(r.width/remoteWidth,r.height/remoteHeight);
 canvas.style.width=Math.max(1,Math.floor(remoteWidth*scale))+'px';
 canvas.style.height=Math.max(1,Math.floor(remoteHeight*scale))+'px';
}
function startRemoteBrowser(control){
 stopRemoteBrowser();
 let stage=remoteStage();if(!stage||!current)return;
 const clean=stage.cloneNode(false);stage.replaceWith(clean);stage=clean;
 remoteControl=!!control;remoteWidth=0;remoteHeight=0;
 stage.tabIndex=0;stage.classList.toggle('dmd-ra-control-active',remoteControl);
 stage.innerHTML=`<div class="dmd-ra-remote-wrap"><div class="dmd-ra-remote-status"><span class="dmd-ra-live online"></span><strong>${remoteControl?'Contrôle distant':'Écran distant'}</strong><small id="dmdRaRemoteMeta">Connexion Remote…</small></div><canvas id="dmdRaRemoteImage" aria-label="Écran distant ${esc(current.hostname||'PC')}"></canvas></div>`;
 const canvas=document.getElementById('dmdRaRemoteImage'),meta=document.getElementById('dmdRaRemoteMeta');
 if(!canvas||typeof window.DMDRemoteSession!=='function')throw new Error('Remote H.264 indisponible');
 integratedRemoteSession=new window.DMDRemoteSession({agentId:String(current.agent_id||''),api:String(boot.api||'DMD-RemoteAgent_api.php'),csrf:String(boot.csrf||''),control:remoteControl,canvas,
  onStatus:text=>{if(meta)meta.textContent=String(text||'');},
  onInfo:info=>{remoteWidth=Number(info&&info.width||remoteWidth);remoteHeight=Number(info&&info.height||remoteHeight);if(meta)meta.textContent=`${remoteWidth||'—'}×${remoteHeight||'—'} · H.264${remoteControl?' · clavier/souris actifs':''}`;fitIntegratedRemoteCanvas();}
 });
 integratedRemoteSession.bindInput(stage);integratedRemoteSession.connect();
 if(remoteControl){try{stage.focus({preventScroll:true});}catch(_){stage.focus();}}
}
function remoteSessionForAgent(agentId){
 const ctx=floatingRemotes.get(String(agentId||''));
 if(ctx&&ctx.session)return ctx.session;
 if(current&&String(current.agent_id||'')===String(agentId||'')&&integratedRemoteSession)return integratedRemoteSession;
 return null;
}

let floatingRemoteZ=10120;
function floatingRemoteKey(agentId){return String(agentId||'').replace(/[^a-zA-Z0-9._-]+/g,'_');}
function floatingRemoteStorageKey(agentId){return `DMD-RemoteAgent:floating:${String(agentId||'')}`;}
function floatingRemoteStateEndpoint(){return String((window.DMDWorkspace&&window.DMDWorkspace.windowStateUrl)||'users/workspace_state.php');}
function floatingRemotePostState(payload){
 return fetch(floatingRemoteStateEndpoint(),{method:'POST',headers:{'Content-Type':'application/json'},cache:'no-store',credentials:'same-origin',body:JSON.stringify(payload)}).catch(()=>null);
}
function floatingRemoteGeometry(ctx){
 if(!ctx||!ctx.root)return null;
 const root=ctx.root,r=root.getBoundingClientRect(),pos=workspaceWindowPosition(root);
 return {x:pos.left,top:pos.top,y:pos.top,width:r.width,height:r.height,space:root.dataset.dmdRaWorkspace==='1'?'workspace':'viewport'};
}
function floatingRemoteRememberOpen(ctx){
 if(!ctx)return;
 const g=floatingRemoteGeometry(ctx);
 if(!g)return;
 floatingRemotePostState({type:'remote',agent_id:ctx.agentId,control:!!ctx.control,open:true,geometry:{x:g.x,y:g.y,width:g.width,height:g.height}});
}
function floatingRemoteForget(agentId){
 floatingRemotePostState({type:'remote',agent_id:String(agentId||''),open:false});
}
async function restoreFloatingRemotes(){
 try{
   const r=await fetch(floatingRemoteStateEndpoint(),{method:'GET',cache:'no-store',credentials:'same-origin'});
   const data=await r.json();
   const remotes=data&&data.ok&&data.state&&data.state.remotes&&typeof data.state.remotes==='object'?data.state.remotes:{};
   Object.keys(remotes).forEach(agentId=>{
     const saved=remotes[agentId]||{};
     const device=deviceById(agentId);
     if(!device)return;
     const g=saved.geometry&&typeof saved.geometry==='object'?saved.geometry:null;
     if(g){
       try{localStorage.setItem(floatingRemoteStorageKey(agentId),JSON.stringify({left:Number(g.x)||0,top:Number(g.y)||0,width:Number(g.width)||760,height:Number(g.height)||480,space:'workspace'}));}catch(_){}
     }
     try{openFloatingRemote(device,!!saved.control,true);}catch(_){}
   });
 }catch(_){}
}
function floatingRemoteBringToFront(root){if(!root)return;floatingRemoteZ=Math.max(floatingRemoteZ+1,10121);root.style.zIndex=String(floatingRemoteZ);}
function floatingRemoteSaveGeometry(ctx){if(!ctx||!ctx.root)return;const root=ctx.root,r=root.getBoundingClientRect();const pos=workspaceWindowPosition(root);try{localStorage.setItem(floatingRemoteStorageKey(ctx.agentId),JSON.stringify({left:pos.left,top:pos.top,width:r.width,height:r.height,space:root.dataset.dmdRaWorkspace==='1'?'workspace':'viewport'}));}catch(_){}floatingRemoteRememberOpen(ctx);}
function floatingRemoteRestoreGeometry(ctx){
 const root=ctx.root;const inWorkspace=mountWorkspaceWindow(root,`DMD-RemoteAgent:remote:${ctx.agentId}`);
 let saved=null;try{saved=JSON.parse(localStorage.getItem(floatingRemoteStorageKey(ctx.agentId))||'null');}catch(_){}
 if(inWorkspace){
   const ws=workspaceHost(),vw=Math.max(320,ws.clientWidth||window.innerWidth||1200),vh=Math.max(240,ws.clientHeight||window.innerHeight||800);
   const minW=Math.min(360,Math.max(280,vw-16)),minH=Math.min(240,Math.max(200,vh-16));
   let width=Math.min(Math.max(minW,Number(saved&&saved.width||760)),Math.max(minW,vw-16));
   let height=Math.min(Math.max(minH,Number(saved&&saved.height||480)),Math.max(minH,vh-16));
   const cascade=Math.min(160,Math.max(0,floatingRemotes.size-1)*22);
   let left=Number(saved&&saved.left),top=Number(saved&&saved.top);
   if(saved&&saved.space!=='workspace'&&Number.isFinite(left)&&Number.isFinite(top)){const p=workspacePointFromViewport(left,top);left=p.x;top=p.y;}
   if(!Number.isFinite(left))left=(ws.scrollLeft||0)+Math.max(8,vw-width-18-cascade);
   if(!Number.isFinite(top))top=(ws.scrollTop||0)+46+cascade;
   Object.assign(root.style,{left:Math.max(0,left)+'px',top:Math.max(0,top)+'px',width:width+'px',height:height+'px'});
   requestWorkspaceExpansion();return;
 }
 const minW=Math.min(360,Math.max(280,window.innerWidth-16)),minH=Math.min(240,Math.max(200,window.innerHeight-16)),maxW=Math.max(minW,window.innerWidth-8),maxH=Math.max(minH,window.innerHeight-8);
 let width=Math.min(maxW,Math.max(minW,Number(saved&&saved.width||760))),height=Math.min(maxH,Math.max(minH,Number(saved&&saved.height||480)));
 const cascade=Math.min(180,floatingRemotes.size*24);let left=Number(saved&&saved.left);let top=Number(saved&&saved.top);
 if(saved&&saved.space==='workspace'&&Number.isFinite(left)&&Number.isFinite(top)){left=8;top=72+cascade;}
 if(!Number.isFinite(left))left=Math.max(8,window.innerWidth-width-24-cascade);if(!Number.isFinite(top))top=72+cascade;
 left=Math.min(Math.max(8,left),Math.max(8,window.innerWidth-width-8));top=Math.min(Math.max(8,top),Math.max(8,window.innerHeight-height-8));
 Object.assign(root.style,{position:'fixed',left:left+'px',top:top+'px',width:width+'px',height:height+'px'});
}
function floatingFitCanvas(ctx){
 if(!ctx||!ctx.stage||!ctx.img||!ctx.width||!ctx.height)return;
 const mode=ctx.displaySelect&&ctx.displaySelect.value==='1to1'?'1to1':'fit';
 if(mode==='1to1'){ctx.img.style.width=ctx.width+'px';ctx.img.style.height=ctx.height+'px';ctx.img.style.maxWidth='none';ctx.img.style.maxHeight='none';ctx.stage.style.overflow='auto';return;}
 ctx.stage.style.overflow='hidden';const r=ctx.stage.getBoundingClientRect();if(!r.width||!r.height)return;const scale=Math.min(r.width/ctx.width,r.height/ctx.height);ctx.img.style.width=Math.max(1,Math.floor(ctx.width*scale))+'px';ctx.img.style.height=Math.max(1,Math.floor(ctx.height*scale))+'px';ctx.img.style.maxWidth='100%';ctx.img.style.maxHeight='100%';
}
function bindFloatingRemoteWindow(ctx){
 const root=ctx.root,head=root.querySelector('.dmd-ra-floating-head');
 floatingRemoteBringToFront(root);floatingRemoteRestoreGeometry(ctx);
 root.addEventListener('pointerdown',()=>floatingRemoteBringToFront(root),true);
 bindOwnWindowDrag(root,head,()=>floatingRemoteSaveGeometry(ctx));
 let resizeTimer=null;if(typeof ResizeObserver==='function'){
   ctx.resizeObserver=new ResizeObserver(()=>{
     if(root.dataset.dmdRaWorkspace!=='1')clampFloatingWindow(root,4);
     floatingFitCanvas(ctx);requestWorkspaceExpansion();clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>floatingRemoteSaveGeometry(ctx),180);
   });ctx.resizeObserver.observe(root);
 }
}
async function floatingLoadDisplays(ctx){
 const sel=ctx&&ctx.resolutionSelect;if(!sel||!ctx.session)return;sel.disabled=true;
 let last=null;for(let i=0;i<20;i++){try{const rows=await ctx.session.call('display.list',{},4000);const list=Array.isArray(rows)?rows:(rows&&Array.isArray(rows.displays)?rows.displays:[]);sel.innerHTML='';if(!list.length){sel.innerHTML='<option value="">Écran</option>';return;}list.forEach((d,n)=>{const o=document.createElement('option');const idx=Number(d.index!=null?d.index:n);o.value=String(idx);o.textContent=`${Number(d.width||0)}×${Number(d.height||0)}${d.primary?' · principal':''}`;sel.appendChild(o);});sel.disabled=false;return;}catch(e){last=e;await new Promise(r=>setTimeout(r,150));}}
 sel.innerHTML='<option value="">Écran indisponible</option>';if(last&&ctx.meta)ctx.meta.textContent=last.message||String(last);
}
function closeFloatingRemote(agentId,sendStop,forgetState){
 const ctx=floatingRemotes.get(String(agentId||''));if(!ctx)return;
 ctx.closed=true;if(forgetState){floatingRemoteForget(ctx.agentId);try{localStorage.removeItem(floatingRemoteStorageKey(ctx.agentId));}catch(_){}}else{floatingRemoteSaveGeometry(ctx);}if(ctx.resizeObserver)try{ctx.resizeObserver.disconnect();}catch(_){}if(ctx.session)try{ctx.session.close();}catch(_){}if(ctx.root)ctx.root.remove();floatingRemotes.delete(ctx.agentId);
}
function openFloatingRemote(device,control,restoring){
 if(!device||!device.agent_id)throw new Error('PC Remote invalide.');if(typeof window.DMDRemoteSession!=='function')throw new Error('Remote H.264 indisponible');
 const agentId=String(device.agent_id),key=floatingRemoteKey(agentId);let ctx=floatingRemotes.get(agentId);
 if(ctx){if(!!control&&!ctx.control){closeFloatingRemote(agentId,false,false);ctx=null;}else{floatingRemoteBringToFront(ctx.root);return ctx;}}
 const root=document.createElement('section');root.className='dmd-ra-floating-remote';root.dataset.agentId=agentId;root.dataset.dmdWindowIgnore='1';root.innerHTML=`<header class="dmd-ra-floating-head"><span class="dmd-ra-floating-drag" title="Déplacer" aria-label="Déplacer" role="button" tabindex="0">⠿</span><span class="dmd-ra-live online"></span><strong>${esc(device.hostname||'PC')}</strong><small>${esc(deviceIPv4(device))}</small><span class="dmd-ra-floating-mode">${control?'CTRL':'VUE'}</span><span class="dmd-ra-floating-meta">Connexion…</span><select class="dmd-ra-floating-resolution" title="Écran distant" aria-label="Écran distant"><option value="">Écran…</option></select><select class="dmd-ra-floating-display" title="Mode d’affichage" aria-label="Mode d’affichage"><option value="fit">Adapter</option><option value="1to1">1:1</option></select><button type="button" class="dmd-ra-floating-detach" title="Détacher dans une fenêtre indépendante" aria-label="Détacher">↗</button><button type="button" class="dmd-ra-floating-close" title="Fermer le Remote" aria-label="Fermer">×</button></header><div class="dmd-ra-floating-stage" tabindex="0"><canvas aria-label="Écran distant ${esc(device.hostname||'PC')}"></canvas></div>`;
 const floatingHost=workspaceHost()||document.body;floatingHost.appendChild(root);const stage=root.querySelector('.dmd-ra-floating-stage'),canvas=stage.querySelector('canvas'),meta=root.querySelector('.dmd-ra-floating-meta');
 ctx={agentId,device,root,stage,img:canvas,meta,mode:root.querySelector('.dmd-ra-floating-mode'),resolutionSelect:root.querySelector('.dmd-ra-floating-resolution'),displaySelect:root.querySelector('.dmd-ra-floating-display'),control:!!control,width:0,height:0,closed:false,resizeObserver:null,session:null};floatingRemotes.set(agentId,ctx);
 ctx.session=new window.DMDRemoteSession({agentId,api:String(boot.api||'DMD-RemoteAgent_api.php'),csrf:String(boot.csrf||''),control:ctx.control,canvas,
   onStatus:text=>{if(ctx.meta&&!ctx.closed)ctx.meta.textContent=String(text||'');},
   onInfo:info=>{if(ctx.closed)return;ctx.width=Number(info&&info.width||ctx.width);ctx.height=Number(info&&info.height||ctx.height);if(ctx.meta)ctx.meta.textContent=`${ctx.width||'—'}×${ctx.height||'—'} · H.264${ctx.control?' · CTRL':''}`;floatingFitCanvas(ctx);}
 });
 ctx.session.bindInput(stage);ctx.session.connect();stage.classList.toggle('dmd-ra-control-active',ctx.control);
 root.querySelector('.dmd-ra-floating-close').addEventListener('click',e=>{e.preventDefault();e.stopPropagation();closeFloatingRemote(agentId,false,true);});
 const detachBtn=root.querySelector('.dmd-ra-floating-detach');detachBtn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const base=String(boot.detached||'modules/DMD-RemoteAgent/DMD-RemoteAgent_detached.php');const url=`${base}?agent_id=${encodeURIComponent(agentId)}&control=${ctx.control?'1':'0'}`;const win=window.open(url,`DMDRemote_${key}`,'popup=yes,width=1280,height=820,resizable=yes,scrollbars=no');if(!win){toast('Le navigateur a bloqué la fenêtre Remote. Autorise les popups pour DoMyDesk.');return;}closeFloatingRemote(agentId,false,true);setStatus(`Remote ${device.hostname||'PC'} détaché dans une fenêtre indépendante.`,false);});
 if(ctx.resolutionSelect)ctx.resolutionSelect.addEventListener('change',async e=>{e.stopPropagation();if(ctx.resolutionSelect.value==='')return;ctx.resolutionSelect.disabled=true;try{await ctx.session.call('display.select',{index:Number(ctx.resolutionSelect.value)},5000);await ctx.session.requestKeyframe();}catch(err){toast(err.message||'Changement d’écran impossible.');}finally{ctx.resolutionSelect.disabled=false;}});
 if(ctx.displaySelect){let initial='fit';try{initial=localStorage.getItem(`DMD-RemoteAgent:display:${agentId}`)||'fit';}catch(_){}ctx.displaySelect.value=initial==='1to1'?'1to1':'fit';ctx.displaySelect.addEventListener('change',e=>{e.stopPropagation();try{localStorage.setItem(`DMD-RemoteAgent:display:${agentId}`,ctx.displaySelect.value);}catch(_){}floatingFitCanvas(ctx);});}
 bindFloatingRemoteWindow(ctx);floatingRemoteRememberOpen(ctx);floatingLoadDisplays(ctx);if(ctx.control)setTimeout(()=>{try{stage.focus({preventScroll:true});}catch(_){stage.focus();}},0);return ctx;
}
function showDetachedRemoteMessage(control){
 const stage=remoteStage();if(stage){stopRemoteBrowser();stage.innerHTML='<span>Aucune session Remote intégrée active.</span>';}
 switchTab('overview');setStatus(`Remote ${control?'en contrôle':'en vue'} ouvert sur le dashboard.`,false);
}

function renderProcesses(result){
 const el=document.getElementById('dmdRaProcessesResult');if(result&&result.truncated){el.innerHTML=`<span>${esc(result.message||'Résultat processus trop volumineux.')}</span>`;return;}const rows=Array.isArray(result&&result.processes)?result.processes:(Array.isArray(result)?result:[]);if(!rows.length){renderGenericResult(el,result);return;}
 const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||25),total=Number(result&&result.total||rows.length),hasMore=!!(result&&result.has_more),prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
 const nav=`<div class="dmd-ra-result-meta"><span>${offset+1}-${offset+rows.length} / ${total} processus</span><span class="dmd-ra-inline-actions">${offset>0?`<button type="button" data-process-offset="${prev}">‹ Précédent</button>`:''}${hasMore?`<button type="button" data-process-offset="${next}">Suivant ›</button>`:''}</span></div>`;
 el.innerHTML=nav+`<div class="dmd-ra-table">${rows.map(p=>`<div class="dmd-ra-data-row process"><span><strong>${esc(p.name||p.process||'Processus')}</strong><small>PID ${esc(p.pid||'—')}${p.user?' · '+esc(p.user):''}</small><small title="${esc(p.path||'')}">${esc(p.path||'')}</small></span><span>${esc(p.cpu!=null?p.cpu+' %':'—')}</span><span>${esc(p.memory_bytes!=null?formatBytes(p.memory_bytes):(p.memory||p.ram||'—'))}</span>${hasPerm('processes.kill')&&!p.protected?`<button type="button" class="danger small" data-kill-pid="${esc(p.pid||'')}">Arrêter</button>`:`<span class="dmd-ra-protected">Protégé</span>`}</div>`).join('')}</div>`;
}
function serviceStatusLabel(v){const m={running:'En cours',stopped:'Arrêté',start_pending:'Démarrage…',stop_pending:'Arrêt…',continue_pending:'Reprise…',pause_pending:'Mise en pause…',paused:'En pause'};return m[String(v||'').toLowerCase()]||String(v||'—');}
function renderServices(result){
 const el=document.getElementById('dmdRaServicesResult');if(result&&result.truncated){el.innerHTML=`<span>${esc(result.message||'Résultat services trop volumineux.')}</span>`;return;}const rows=Array.isArray(result&&result.services)?result.services:(Array.isArray(result)?result:[]);if(!rows.length){renderGenericResult(el,result);return;}
 const offset=Number(result&&result.offset||0),limit=Number(result&&result.limit||40),total=Number(result&&result.total||rows.length),hasMore=!!(result&&result.has_more),prev=Number(result&&result.prev_offset!=null?result.prev_offset:Math.max(0,offset-limit)),next=Number(result&&result.next_offset!=null?result.next_offset:offset+rows.length);
 const nav=`<div class="dmd-ra-result-meta"><span>${offset+1}-${offset+rows.length} / ${total} services</span><span class="dmd-ra-inline-actions">${offset>0?`<button type="button" data-service-offset="${prev}">‹ Précédent</button>`:''}${hasMore?`<button type="button" data-service-offset="${next}">Suivant ›</button>`:''}</span></div>`;
 el.innerHTML=nav+`<div class="dmd-ra-table">${rows.map(s=>{let actions='<span class="dmd-ra-protected">Aucune action</span>';if(s.protected){actions='<span class="dmd-ra-protected">Protégé</span>';}else if(hasPerm('services.control')){const a=[];if(s.can_start)a.push(`<button type="button" data-service="${esc(s.name||'')}" data-service-op="start">Démarrer</button>`);if(s.can_stop)a.push(`<button type="button" data-service="${esc(s.name||'')}" data-service-op="stop">Arrêter</button>`);if(s.can_restart)a.push(`<button type="button" data-service="${esc(s.name||'')}" data-service-op="restart">Redémarrer</button>`);if(a.length)actions=`<span class="dmd-ra-inline-actions">${a.join('')}</span>`;}return `<div class="dmd-ra-data-row service"><span><strong>${esc(s.display_name||s.name||'Service')}</strong><small>${esc(s.name||'')}${s.start_mode?' · '+esc(s.start_mode):''}${s.pid?' · PID '+esc(s.pid):''}</small></span><span>${esc(serviceStatusLabel(s.status))}</span>${actions}</div>`;}).join('')}</div>`;
}
function renderSoftware(result){const el=document.getElementById('dmdRaSoftwareResult');const rows=Array.isArray(result&&result.software)?result.software:(Array.isArray(result)?result:[]);const total=Number(result&&result.total||rows.length);const offset=Number(result&&result.offset||0);const limit=Number(result&&result.limit||40);if(!rows.length){el.innerHTML=`<div class="dmd-ra-empty-result">${total?'Aucun logiciel sur cette page.':'Aucun logiciel correspondant.'}</div>`;return;}const nav=`<div class="dmd-ra-pager"><button type="button" data-software-offset="${Math.max(0,Number(result.prev_offset||0))}" ${offset<=0?'disabled':''}>Précédent</button><span>${offset+1}–${offset+rows.length} / ${total}</span><button type="button" data-software-offset="${Number(result.next_offset||offset+limit)}" ${result&&result.has_more?'':'disabled'}>Suivant</button></div>`;el.innerHTML=`${nav}<div class="dmd-ra-table">${rows.map(s=>{const meta=[s.publisher||'',s.scope==='user'?'Utilisateur':'Machine',s.install_date||''].filter(Boolean).join(' · ');let action='';if(hasPerm('software.uninstall')){if(s.protected)action='<span class="dmd-ra-protected">Protégé</span>';else if(s.can_uninstall)action=`<button type="button" class="danger small" data-uninstall-id="${esc(s.id||'')}" data-uninstall-name="${esc(s.name||'Logiciel')}">Désinstaller</button>`;else action='<span>Non désinstallable</span>';}return `<div class="dmd-ra-data-row software"><span><strong>${esc(s.name||'Logiciel')}</strong><small>${esc(meta)}</small></span><span>${esc(s.version||'—')}</span>${action}</div>`;}).join('')}</div>${nav}`;}
async function loadSoftware(offset){const input=document.getElementById('dmdRaSoftwareSearch');const query=input?input.value.trim():'';const c=await execute('software.list',{offset:Math.max(0,Number(offset||0)),limit:40,query},{timeout:60000,silent:true,noRefresh:true});renderSoftware(commandResult(c)||{});return c;}
async function loadHistory(){if(!current)return;const el=document.getElementById('dmdRaHistoryResult');el.textContent='Chargement…';try{const d=await apiGet('history',{agent_id:current.agent_id,limit:50});const rows=Array.isArray(d.commands)?d.commands:[];el.innerHTML=rows.length?`<div class="dmd-ra-history">${rows.map(c=>`<div><span class="status ${esc(c.status||'')}"></span><strong>${esc(c.type||'commande')}</strong><small>${esc(formatDate(c.created_at))} · ${esc(c.created_by||'')}</small><b>${esc(c.status||'')}</b></div>`).join('')}</div>`:'Aucune commande enregistrée pour ce PC.';}catch(e){el.textContent=e.message;}}

function clampFloatingWindow(root,margin){
 if(!root)return;const m=Number.isFinite(margin)?margin:4;const r=root.getBoundingClientRect();
 const maxLeft=Math.max(m,window.innerWidth-Math.min(r.width,window.innerWidth-m*2)-m);const maxTop=Math.max(m,window.innerHeight-Math.min(r.height,window.innerHeight-m*2)-m);
 const left=Math.min(Math.max(m,r.left),maxLeft),top=Math.min(Math.max(m,r.top),maxTop);
 root.style.left=left+'px';root.style.top=top+'px';
}
function mainWindowStorageKey(){return 'DMD-RemoteAgent:pc-window';}
function saveMainWindowGeometry(){if(!modalWindow)return;const r=modalWindow.getBoundingClientRect(),pos=workspaceWindowPosition(modalWindow);try{localStorage.setItem(mainWindowStorageKey(),JSON.stringify({left:pos.left,top:pos.top,width:r.width,height:r.height,space:modalWindow.dataset.dmdRaWorkspace==='1'?'workspace':'viewport'}));}catch(_){}}
function restoreMainWindowGeometry(){
 if(!modalWindow)return;let saved=null;try{saved=JSON.parse(localStorage.getItem(mainWindowStorageKey())||'null');}catch(_){}
 if(modalWindow.dataset.dmdRaWorkspace==='1'){
   const ws=workspaceHost();if(!ws)return;
   const vw=Math.max(360,ws.clientWidth||window.innerWidth||1200),vh=Math.max(260,ws.clientHeight||window.innerHeight||800);
   const width=Math.min(Math.max(520,Number(saved&&saved.width||Math.min(980,vw*.74))),Math.max(520,vw-16));
   const height=Math.min(Math.max(420,Number(saved&&saved.height||Math.min(760,vh*.82))),Math.max(420,vh-16));
   let left=Number(saved&&saved.left),top=Number(saved&&saved.top);
   if(saved&&saved.space!=='workspace'&&Number.isFinite(left)&&Number.isFinite(top)){const p=workspacePointFromViewport(left,top);left=p.x;top=p.y;}
   if(!Number.isFinite(left))left=(ws.scrollLeft||0)+Math.max(8,(vw-width)/2);
   if(!Number.isFinite(top))top=(ws.scrollTop||0)+Math.max(8,(vh-height)/2);
   Object.assign(modalWindow.style,{position:'absolute',left:Math.max(0,left)+'px',top:Math.max(0,top)+'px',width:width+'px',height:height+'px',margin:'0',transform:'none',maxWidth:'none',maxHeight:'none'});
   requestWorkspaceExpansion();return;
 }
 const maxW=Math.max(360,window.innerWidth-16),maxH=Math.max(260,window.innerHeight-16);const width=Math.min(maxW,Math.max(520,Number(saved&&saved.width||Math.min(980,window.innerWidth*.74))));const height=Math.min(maxH,Math.max(420,Number(saved&&saved.height||Math.min(760,window.innerHeight*.82))));
 let left=Number(saved&&saved.left),top=Number(saved&&saved.top);if(saved&&saved.space==='workspace'){left=NaN;top=NaN;}if(!Number.isFinite(left))left=Math.max(8,(window.innerWidth-width)/2);if(!Number.isFinite(top))top=Math.max(8,(window.innerHeight-height)/2);
 Object.assign(modalWindow.style,{position:'fixed',left:left+'px',top:top+'px',width:width+'px',height:height+'px',margin:'0',transform:'none'});clampFloatingWindow(modalWindow,4);
}
window.addEventListener('resize',()=>{fitIntegratedRemoteCanvas();if(modalWindow&&!modal.hidden&&modalWindow.dataset.dmdRaWorkspace!=='1')clampFloatingWindow(modalWindow,4);for(const ctx of floatingRemotes.values()){if(ctx.root&&ctx.root.dataset.dmdRaWorkspace!=='1')clampFloatingWindow(ctx.root,4);floatingFitCanvas(ctx);}requestWorkspaceExpansion();});
list.addEventListener('click',e=>{
 const groupToggle=e.target.closest('[data-toggle-group]');if(groupToggle){e.preventDefault();const key=String(groupToggle.dataset.toggleGroup||'');if(expandedGroups.has(key))expandedGroups.delete(key);else expandedGroups.add(key);renderCards();return;}
 const groupSelect=e.target.closest('[data-select-group]');if(groupSelect){const key=String(groupSelect.dataset.selectGroup||'');const groupEl=groupSelect.closest('[data-group-key]');const ids=groupEl?Array.from(groupEl.querySelectorAll('[data-agent-row]')).map(el=>String(el.dataset.agentRow||'')):[];if(groupSelect.checked)ids.forEach(id=>selectedAgents.add(id));else ids.forEach(id=>selectedAgents.delete(id));renderCards();return;}
 const select=e.target.closest('[data-select-agent]');if(select){const id=String(select.dataset.selectAgent||'');if(select.checked)selectedAgents.add(id);else selectedAgents.delete(id);renderCards();return;}
 const card=e.target.closest('[data-agent-id]');if(!card)return;e.preventDefault();openDevice(card.dataset.agentId);
});
document.getElementById('dmdRaSearch').addEventListener('input',renderCards);document.getElementById('dmdRaStatusFilter').addEventListener('change',renderCards);
const dmdRaDragHandle=document.getElementById('dmdRaDragHandle');
const dmdRaWindowHead=modalWindow?modalWindow.querySelector('.dmd-ra-window-head'):null;
if(modalWindow&&dmdRaWindowHead)bindOwnWindowDrag(modalWindow,dmdRaWindowHead,saveMainWindowGeometry);
if(modalWindow&&typeof ResizeObserver==='function'){
 let mainResizeTimer=null;const mainResizeObserver=new ResizeObserver(()=>{if(modal.hidden)return;if(modalWindow.dataset.dmdRaWorkspace!=='1')clampFloatingWindow(modalWindow,4);requestWorkspaceExpansion();clearTimeout(mainResizeTimer);mainResizeTimer=setTimeout(saveMainWindowGeometry,180);});mainResizeObserver.observe(modalWindow);
}
document.getElementById('dmdRaClose').addEventListener('click',closeModal);document.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal&&!modal.hidden)closeModal();});
document.getElementById('dmdRaTabs').addEventListener('click',e=>{const b=e.target.closest('[data-tab]');if(b&&!b.hidden)switchTab(b.dataset.tab);});
const remoteMenu=document.getElementById('dmdRaRemoteMenu');
const remoteMenuTrigger=document.getElementById('dmdRaRemoteMenuTrigger');
const remoteMenuPopup=document.getElementById('dmdRaRemoteMenuPopup');
function setRemoteMenuOpen(open){
 const on=!!open&&!!remoteMenu&&!!remoteMenuTrigger&&!!remoteMenuPopup;
 if(remoteMenu)remoteMenu.classList.toggle('open',on);
 if(remoteMenuTrigger)remoteMenuTrigger.setAttribute('aria-expanded',on?'true':'false');
 if(remoteMenuPopup)remoteMenuPopup.hidden=!on;
}
if(remoteMenuTrigger){
 remoteMenuTrigger.addEventListener('click',e=>{
  e.preventDefault();
  e.stopPropagation();
  setRemoteMenuOpen(!(remoteMenu&&remoteMenu.classList.contains('open')));
 });
}
if(remoteMenuPopup){
 remoteMenuPopup.addEventListener('click',e=>{
  const op=e.target.closest('[data-operation]');
  if(op)setRemoteMenuOpen(false);
 });
}
document.addEventListener('click',e=>{
 if(remoteMenu&&remoteMenu.classList.contains('open')&&!remoteMenu.contains(e.target))setRemoteMenuOpen(false);
});
document.addEventListener('keydown',e=>{
 if(e.key==='Escape'&&remoteMenu&&remoteMenu.classList.contains('open')){
  setRemoteMenuOpen(false);
  try{remoteMenuTrigger&&remoteMenuTrigger.focus({preventScroll:true});}catch(_){ }
 }
});
document.getElementById('dmdRaRefreshState').addEventListener('click',()=>refreshState(false));
const clipboardToggle=document.getElementById('dmdRaClipboardToggle');if(clipboardToggle)clipboardToggle.addEventListener('click',()=>{const p=document.getElementById('dmdRaClipboardPanel');if(p)p.hidden=!p.hidden;});
const historyRefresh=document.getElementById('dmdRaHistoryRefresh');if(historyRefresh)historyRefresh.addEventListener('click',()=>loadHistory());

modal.addEventListener('click',async e=>{
 const fp=e.target.closest('[data-file-offset]');if(fp){try{await browseFiles(document.getElementById('dmdRaPath').value,Number(fp.dataset.fileOffset||0));}catch(err){toast(err.message||'Chargement impossible.');}return;}
 const dl=e.target.closest('[data-download-path]');if(dl){dl.disabled=true;try{await downloadRemoteFile(dl.dataset.downloadPath,dl.dataset.downloadName||'fichier',Number(dl.dataset.downloadSize||0));}catch(err){toast(err.message||'Téléchargement impossible.');clearFileTransfer();}finally{dl.disabled=false;}return;}
 const dlf=e.target.closest('[data-download-folder]');if(dlf){dlf.disabled=true;try{await downloadRemoteFolder(dlf.dataset.downloadFolder,dlf.dataset.downloadFolderName||'dossier');}catch(err){toast(err.message||'Téléchargement dossier impossible.');clearFileTransfer();}finally{dlf.disabled=false;}return;}
 const ren=e.target.closest('[data-rename-path]');if(ren){const name=prompt('Nouveau nom :',ren.dataset.renameName||'');if(!name||name===ren.dataset.renameName)return;try{await execute('files.rename',{path:ren.dataset.renamePath,name},{timeout:60000});await browseFiles(document.getElementById('dmdRaPath').value,0);}catch(err){toast(err.message||'Renommage impossible.');}return;}
 const pp=e.target.closest('[data-process-offset]');if(pp){const offset=Number(pp.dataset.processOffset||0);pp.disabled=true;pp.textContent='Chargement…';setStatus('Chargement de la page processus…',true);try{const c=await execute('processes.list',{offset,limit:25},{timeout:30000});renderProcesses(commandResult(c));}catch(e){toast(e.message||'Chargement impossible.');}return;}
 const sp=e.target.closest('[data-service-offset]');if(sp){const offset=Number(sp.dataset.serviceOffset||0);sp.disabled=true;sp.textContent='Chargement…';setStatus('Chargement de la page services…',true);try{const c=await execute('services.list',{offset,limit:40},{timeout:30000});renderServices(commandResult(c));}catch(e){toast(e.message||'Chargement impossible.');}return;}
 const swp=e.target.closest('[data-software-offset]');if(swp){swp.disabled=true;try{await loadSoftware(Number(swp.dataset.softwareOffset||0));}catch(err){toast(err.message||'Chargement logiciels impossible.');}return;}
 const regPath=e.target.closest('[data-reg-path]');if(regPath){try{await loadRegistry(regPath.dataset.regPath||'');}catch(err){toast(err.message||'Lecture registre impossible.');}return;}
 const regVal=e.target.closest('[data-reg-value]');if(regVal){document.getElementById('dmdRaRegistryName').value=regVal.dataset.regValue||'';document.getElementById('dmdRaRegistryType').value=String(regVal.dataset.regType||'string').replace(/^reg_/,'').replace('sz','string').replace('expand_string','expandstring').replace('multi_string','multistring');document.getElementById('dmdRaRegistryValue').value=regVal.dataset.regData||'';return;}
 const regDelVal=e.target.closest('[data-reg-delete-value]');if(regDelVal){try{await deleteRegistryValue(regDelVal.dataset.regDeleteValue||'');}catch(err){toast(err.message||'Suppression registre impossible.');}return;}
 const regDelKey=e.target.closest('[data-reg-delete-key]');if(regDelKey){try{await deleteRegistryKey(regDelKey.dataset.regDeleteKey||'');}catch(err){toast(err.message||'Suppression registre impossible.');}return;}
 const eject=e.target.closest('[data-eject-letter]');if(eject){if(!confirm(`Éjecter ${eject.dataset.ejectLetter} ?`))return;try{await execute('devices.removable.eject',{letter:eject.dataset.ejectLetter},{timeout:60000});await loadDevicesAndNetwork();}catch(err){toast(err.message||'Éjection impossible.');}return;}
 const netRemove=e.target.closest('[data-network-remove]');if(netRemove){if(!confirm(`Retirer le chemin réseau ${netRemove.dataset.networkRemove} ?`))return;try{await execute('network.paths.remove',{local_path:netRemove.dataset.networkRemove},{timeout:60000});await loadDevicesAndNetwork();}catch(err){toast(err.message||'Retrait réseau impossible.');}return;}
 const opBtn=e.target.closest('[data-operation]');
 if(opBtn){const op=opBtn.dataset.operation;const opDevice=current;if(opBtn.dataset.confirm&&!confirm(opBtn.dataset.confirm))return;
 if(op==='remote.screen'){try{openFloatingRemote(opDevice,false);showDetachedRemoteMessage(false);}catch(err){toast(err.message||'Remote impossible.');}return;}
 if(op==='remote.control'){try{openFloatingRemote(opDevice,true);showDetachedRemoteMessage(true);}catch(err){toast(err.message||'Remote impossible.');}return;}
 if(op==='remote.stop'){if(opDevice)closeFloatingRemote(opDevice.agent_id,false);stopRemoteBrowser();const rs=remoteStage();if(rs)rs.innerHTML='<span>Aucune session Remote active.</span>';return;}
 if(op==='remote.clipboard.get'){const session=opDevice?remoteSessionForAgent(opDevice.agent_id):null;if(!session){toast('Ouvre d’abord le Remote de ce PC.');return;}try{const r=await session.call('clipboard.read',{},5000);document.getElementById('dmdRaClipboard').value=String(r&&r.text!=null?r.text:r||'');}catch(err){toast(err.message||'Presse-papiers inaccessible.');}return;}
 let params={};if(op==='processes.list')params={offset:0,limit:25};else if(op==='services.list')params={offset:0,limit:40};try{const c=await execute(op,params,{timeout:op==='agent.update'?300000:120000});const r=commandResult(c);if(op==='software.list')renderSoftware(r);else if(op==='processes.list')renderProcesses(r);else if(op==='services.list')renderServices(r);else if(op.indexOf('system.')===0||op==='agent.update'||op==='pc.refresh')renderGenericResult(document.getElementById('dmdRaSystemResult'),r);}catch(_){}return;}
 const pathBtn=e.target.closest('[data-path]');if(pathBtn){const path=pathBtn.dataset.path||'';document.getElementById('dmdRaPath').value=path;try{await browseFiles(path,0);}catch(err){toast(err.message||'Ouverture impossible.');}return;}
 const del=e.target.closest('[data-delete-path]');if(del){const isDir=del.dataset.deleteDir==='1';const msg=isDir?`Supprimer le dossier ${del.dataset.deletePath} et tout son contenu ?`:`Supprimer ${del.dataset.deletePath} ?`;if(!confirm(msg))return;try{await execute('files.delete',{path:del.dataset.deletePath,recursive:isDir},{timeout:120000});await browseFiles(document.getElementById('dmdRaPath').value,0);}catch(err){toast(err.message||'Suppression impossible.');}return;}
 const kill=e.target.closest('[data-kill-pid]');if(kill){if(!confirm(`Arrêter le PID ${kill.dataset.killPid} ?`))return;try{await execute('processes.kill',{pid:Number(kill.dataset.killPid)});const c=await execute('processes.list',{offset:0,limit:25});renderProcesses(commandResult(c));}catch(_){}return;}
 const svc=e.target.closest('[data-service]');if(svc){const op=svc.dataset.serviceOp||'restart';svc.disabled=true;try{const done=await execute('services.control',{name:svc.dataset.service,operation:op},{timeout:90000});toast(`Service ${svc.dataset.service} : ${op} OK`);const c=await execute('services.list',{offset:0,limit:40},{timeout:30000});renderServices(commandResult(c));}catch(err){toast(err.message||'Action service impossible.');}return;}
 const uns=e.target.closest('[data-uninstall-id]');if(uns){const name=uns.dataset.uninstallName||uns.dataset.uninstallId;if(!confirm(`Désinstaller ${name} ?\n\nLa désinstallation est définitive et s'exécute sur le PC distant.`))return;uns.disabled=true;try{const done=await execute('software.uninstall',{id:uns.dataset.uninstallId},{timeout:720000});const r=commandResult(done)||{};toast(r.reboot_required?`${name} désinstallé. Un redémarrage Windows est requis.`:`${name} : désinstallation terminée.`);await new Promise(resolve=>setTimeout(resolve,1500));await loadSoftware(0);}catch(err){toast(err.message||'Désinstallation impossible.');}finally{uns.disabled=false;}return;}
});

document.getElementById('dmdRaSoftwareRefresh').addEventListener('click',()=>loadSoftware(0).catch(e=>toast(e.message||'Inventaire logiciels impossible.')));
document.getElementById('dmdRaSoftwareUpdatesScan').addEventListener('click',async()=>{const o=document.getElementById('dmdRaSoftwareUpdatesResult');o.hidden=false;o.textContent='Recherche des mises à jour…';try{const c=await execute('software.updates.scan',{include_unknown:true},{timeout:240000});const r=commandResult(c)||{};o.textContent=[r.stdout,r.stderr].filter(Boolean).join('\n').trim()||'Aucune mise à jour retournée par Winget.';}catch(e){o.textContent=e.message||'Recherche impossible.';toast(o.textContent);}});
document.getElementById('dmdRaSoftwareUpdatesApply').addEventListener('click',async()=>{if(!confirm('Installer toutes les mises à jour logicielles disponibles sur ce PC ?'))return;const o=document.getElementById('dmdRaSoftwareUpdatesResult');o.hidden=false;o.textContent='Installation des mises à jour…';try{const c=await execute('software.updates.apply',{all:true},{timeout:1900000});const r=commandResult(c)||{};o.textContent=[r.stdout,r.stderr].filter(Boolean).join('\n').trim()||'Mises à jour terminées.';toast('Mises à jour logicielles terminées.');await loadSoftware(0);}catch(e){o.textContent=e.message||'Mise à jour impossible.';toast(o.textContent);}});
document.getElementById('dmdRaSoftwareSearch').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();loadSoftware(0).catch(err=>toast(err.message||'Recherche impossible.'));}});
document.getElementById('dmdRaRoots').addEventListener('click',async()=>{try{await browseFiles('',0);}catch(err){toast(err.message||'Lecture des racines impossible.');}});
document.getElementById('dmdRaBrowse').addEventListener('click',async()=>{const path=document.getElementById('dmdRaPath').value.trim();try{await browseFiles(path,0);}catch(err){toast(err.message||'Ouverture impossible.');}});
document.getElementById('dmdRaMkdir').addEventListener('click',async()=>{const base=document.getElementById('dmdRaPath').value.trim();const name=prompt('Nom du nouveau dossier :');if(!name)return;try{await execute('files.mkdir',{path:base,name},{timeout:60000});await browseFiles(base,0);}catch(err){toast(err.message||'Création impossible.');}});
document.getElementById('dmdRaUpload').addEventListener('click',()=>document.getElementById('dmdRaUploadInput').click());
document.getElementById('dmdRaUploadInput').addEventListener('change',async e=>{const file=e.target.files&&e.target.files[0];if(!file)return;try{await uploadRemoteFile(file);}catch(err){toast(err.message||'Envoi impossible.');clearFileTransfer();}finally{e.target.value='';}});
document.getElementById('dmdRaUploadFolder').addEventListener('click',()=>document.getElementById('dmdRaUploadFolderInput').click());
document.getElementById('dmdRaUploadFolderInput').addEventListener('change',async e=>{try{await uploadRemoteFolder(e.target.files);}catch(err){toast(err.message||'Envoi dossier impossible.');clearFileTransfer();}finally{e.target.value='';}});
document.getElementById('dmdRaRegistryOpen').addEventListener('click',()=>loadRegistry().catch(e=>toast(e.message||'Lecture registre impossible.')));
document.getElementById('dmdRaRegistryRefresh').addEventListener('click',()=>loadRegistry().catch(e=>toast(e.message||'Lecture registre impossible.')));
document.getElementById('dmdRaRegistryHive').addEventListener('change',()=>{document.getElementById('dmdRaRegistryPath').value='';loadRegistry('').catch(e=>toast(e.message||'Lecture registre impossible.'));});
document.getElementById('dmdRaRegistrySave').addEventListener('click',()=>saveRegistryValue().catch(e=>toast(e.message||'Écriture registre impossible.')));
document.getElementById('dmdRaRegistryDeleteValue').addEventListener('click',()=>deleteRegistryValue(document.getElementById('dmdRaRegistryName').value||'').catch(e=>toast(e.message||'Suppression registre impossible.')));
document.getElementById('dmdRaDevicesRefresh').addEventListener('click',()=>loadDevicesAndNetwork().catch(e=>toast(e.message||'Lecture périphériques impossible.')));
document.getElementById('dmdRaNetworkAdd').addEventListener('click',()=>addNetworkPath().catch(e=>toast(e.message||'Ajout réseau impossible.')));
document.getElementById('dmdRaClipboardSend').addEventListener('click',async()=>{if(!current)return;const session=remoteSessionForAgent(current.agent_id);if(!session){toast('Ouvre d’abord le Remote de ce PC.');return;}try{await session.call('clipboard.write',{text:document.getElementById('dmdRaClipboard').value},5000);}catch(err){toast(err.message||'Presse-papiers inaccessible.');}});
document.getElementById('dmdRaTerminalRun').addEventListener('click',async()=>{const input=document.getElementById('dmdRaTerminalInput');const shell=document.getElementById('dmdRaTerminalShell').value||'powershell';const cmd=input.value.trim();if(!cmd)return;const out=document.getElementById('dmdRaTerminalOutput');out.textContent+=`\n[${shell}] > ${cmd}\n`;input.value='';try{const c=await execute('system.terminal',{command:cmd,shell,timeout_seconds:45},{timeout:180000,silent:true,noRefresh:true});const r=commandResult(c)||{};if(r.stdout)out.textContent+=r.stdout;if(r.stderr)out.textContent+=`\n[stderr]\n${r.stderr}`;out.textContent+=`\n[exit ${r.exit_code??'—'} · ${r.duration_ms??0} ms${r.timed_out?' · timeout':''}${r.truncated?' · sortie tronquée':''}]\n`;}catch(e){out.textContent+=`ERREUR: ${e.message}\n`;}out.scrollTop=out.scrollHeight;});
document.getElementById('dmdRaTerminalInput').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();document.getElementById('dmdRaTerminalRun').click();}});

const dmdRaMfaForm=document.getElementById('dmdRaMfaForm');if(dmdRaMfaForm)dmdRaMfaForm.addEventListener('submit',e=>{e.preventDefault();const input=document.getElementById('dmdRaMfaCode');unlockSecurity(input?input.value:'');});
applySecurityState(security,false);

(function registerProvider(){const provider={id:'DMD-RemoteAgent',getResources(){return devices.map(d=>d.resource).filter(Boolean);}};let tries=0;const install=()=>{tries++;if(window.DMDActionHub&&typeof window.DMDActionHub.registerProvider==='function'){window.DMDActionHub.registerProvider(provider);return;}if(tries<30)setTimeout(install,250);};install();})();
renderCards();
setTimeout(()=>restoreFloatingRemotes(),0);
setInterval(()=>refreshState(true),30000);
})();
