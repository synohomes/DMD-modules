<?php
$DMD_REMOTE_V2_DETACHED = false;
require __DIR__ . '/DMD-RemoteV2_view.php';
?>
<link rel="stylesheet" href="DMD-RemoteV2.css?v=2">
<script src="DMD-RemoteV2.js?v=2"></script>
<script>
(function(){
  const boots=window.DMD_REMOTE_V2_BOOT||{};
  for(const id of Object.keys(boots)){
    const root=document.getElementById(id);
    if(root&&!root.dataset.rv2Mounted){root.dataset.rv2Mounted='1';window.DMDRemoteV2.mount(root,boots[id]);}
  }
})();
</script>
