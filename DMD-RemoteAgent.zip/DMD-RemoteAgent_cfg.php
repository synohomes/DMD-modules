<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$email = dmd_remoteagent_email();
if ($email === '' || !dmd_remoteagent_is_superadmin($email)) {
    http_response_code(403);
    echo '<div class="dmd-ra-cfg-error">Accès réservé au Superadmin.</div>';
    return;
}

$csrf = dmd_csrf_token('dmd_remoteagent_cfg');
$message = '';
$error = '';
if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST') {
    if (!dmd_csrf_validate((string)($_POST['csrf_token'] ?? ''), 'dmd_remoteagent_cfg')) {
        $error = 'Formulaire expiré. Recharge le CFG.';
    } else {
        $config = array(
            'mfa_enabled' => !empty($_POST['mfa_enabled']),
            'session_minutes' => max(1, min(720, (int)($_POST['session_minutes'] ?? 15))),
        );
        if (dmd_remoteagent_security_config_write($config, $email)) {
            dmd_remoteagent_security_session_clear($email);
            $message = 'Configuration de sécurité enregistrée.';
            if (function_exists('dmd_system_log')) dmd_system_log('remoteagent_security_config', $email, 'success', 'Configuration MFA DMD-RemoteAgent modifiée.');
        } else {
            $error = 'Impossible d’enregistrer la configuration.';
        }
    }
}
$config = dmd_remoteagent_security_config_read();
?>
<style>
.dmd-ra-cfg{font:inherit;color:inherit;max-width:760px;padding:10px}.dmd-ra-cfg *{box-sizing:border-box}.dmd-ra-cfg h3{margin:0 0 4px;font-size:15px}.dmd-ra-cfg p{margin:0 0 10px;font-size:12px;opacity:.78}.dmd-ra-cfg-card{border:1px solid var(--border-color,currentColor);border-radius:8px;padding:12px;background:var(--card-bg,var(--panel-bg,transparent))}.dmd-ra-cfg-row{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:9px 0;border-bottom:1px solid var(--border-color,currentColor)}.dmd-ra-cfg-row:last-child{border-bottom:0}.dmd-ra-cfg-label{display:grid;gap:2px;min-width:0}.dmd-ra-cfg-label strong{font-size:12px}.dmd-ra-cfg-label small{font-size:10px;opacity:.72}.dmd-ra-cfg input[type=number]{width:90px;min-height:28px;padding:3px 6px;border:1px solid var(--border-color,currentColor);border-radius:5px;background:var(--input-bg,var(--panel-bg,transparent));color:inherit}.dmd-ra-cfg-actions{display:flex;justify-content:flex-end;margin-top:10px}.dmd-ra-cfg button{min-height:28px;padding:4px 10px;border:1px solid var(--border-color,currentColor);border-radius:5px;background:var(--button-bg,var(--card-bg,transparent));color:inherit;cursor:pointer}.dmd-ra-cfg-msg{margin:0 0 8px;padding:7px 9px;border:1px solid var(--border-color,currentColor);border-radius:6px;font-size:11px}.dmd-ra-cfg-error{padding:12px;color:var(--danger-color,currentColor)}
</style>
<div class="dmd-ra-cfg">
  <h3>🔐 Sécurité DMD-RemoteAgent</h3>
  <p>Ce CFG ne modifie pas les droits Agent : ils restent exclusivement dans <code>/adm/agent/</code>.</p>
  <?php if ($message !== ''): ?><div class="dmd-ra-cfg-msg"><?= dmd_remoteagent_h($message) ?></div><?php endif; ?>
  <?php if ($error !== ''): ?><div class="dmd-ra-cfg-msg"><?= dmd_remoteagent_h($error) ?></div><?php endif; ?>
  <form method="post" autocomplete="off">
    <input type="hidden" name="csrf_token" value="<?= dmd_remoteagent_h($csrf) ?>">
    <div class="dmd-ra-cfg-card">
      <label class="dmd-ra-cfg-row">
        <span class="dmd-ra-cfg-label"><strong>Exiger le MFA pour DMD-RemoteAgent</strong><small>Utilise le MFA central DoMyDesk. Aucun secret MFA n’est stocké dans le module.</small></span>
        <input type="checkbox" name="mfa_enabled" value="1" <?= !empty($config['mfa_enabled']) ? 'checked' : '' ?>>
      </label>
      <label class="dmd-ra-cfg-row">
        <span class="dmd-ra-cfg-label"><strong>Verrouillage automatique</strong><small>Après ce délai, le module et les fenêtres Remote sont verrouillés et le code MFA est redemandé.</small></span>
        <span><input type="number" name="session_minutes" min="1" max="720" step="1" value="<?= (int)$config['session_minutes'] ?>"> min</span>
      </label>
    </div>
    <p style="margin-top:9px">Si le MFA est exigé mais qu’un utilisateur ne l’a pas configuré, DMD-RemoteAgent reste inaccessible jusqu’à l’activation du MFA dans son profil.</p>
    <div class="dmd-ra-cfg-actions"><button type="submit">Enregistrer</button></div>
  </form>
</div>
