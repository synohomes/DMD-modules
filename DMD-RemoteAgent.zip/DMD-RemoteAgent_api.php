<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$email = dmd_api_require_user();
if (!dmd_user_has_module_permission($email, DMD_REMOTEAGENT_MODULE_ID, 'module.view')) {
    dmd_json_response(array('ok'=>false,'error'=>'module_access_denied'), 403);
}

$action = isset($_GET['action']) ? trim((string)$_GET['action']) : '';
$method = strtoupper((string)(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET'));

if ($method === 'GET') {
    if ($action === 'security_status') {
        dmd_json_response(array('ok'=>true,'security'=>dmd_remoteagent_security_state($email),'server_time'=>time()));
    }
    if ($action !== 'security_status' && !dmd_remoteagent_security_state($email)['unlocked']) {
        dmd_remoteagent_security_json_denied($email);
    }
    if ($action === 'state') {
        $devices = array();
        foreach (dmd_remoteagent_accessible_devices($email) as $device) $devices[] = dmd_remoteagent_state_device($device);
        dmd_json_response(array(
            'ok'=>true,
            'devices'=>$devices,
            'is_superadmin'=>dmd_remoteagent_is_superadmin($email),
            'admin_url'=>'adm/agent/',
            'server_time'=>time(),
        ));
    }
    if ($action === 'command_status') {
        $agentId = dmd_agent_safe_agent_id(isset($_GET['agent_id']) ? $_GET['agent_id'] : '');
        $commandId = isset($_GET['command_id']) ? trim((string)$_GET['command_id']) : '';
        if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
        if (function_exists('dmd_agent_command_mark_interactive')) dmd_agent_command_mark_interactive($agentId, 20);
        $command = dmd_agent_command_status($agentId, $commandId);
        if (!$command) dmd_json_response(array('ok'=>false,'error'=>'command_not_found'), 404);
        dmd_json_response(array('ok'=>true,'command'=>$command));
    }
    if ($action === 'remote_stream') {
        // Ancien transport vidéo HTTP définitivement retiré : le Remote écran
        // utilise uniquement les WebSockets persistants DMD-Remote.
        dmd_json_response(array('ok'=>false,'error'=>'remote_stream_retired','transport'=>'websocket_h264'), 410);
    }
    if ($action === 'history') {
        $agentId = dmd_agent_safe_agent_id(isset($_GET['agent_id']) ? $_GET['agent_id'] : '');
        if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
        $limit = isset($_GET['limit']) ? max(1, min(100, (int)$_GET['limit'])) : 40;
        dmd_json_response(array('ok'=>true,'commands'=>dmd_agent_command_history($agentId, $limit)));
    }
    dmd_json_response(array('ok'=>false,'error'=>'action_invalid'), 400);
}

if ($method !== 'POST') dmd_json_response(array('ok'=>false,'error'=>'method_not_allowed'), 405);
$payload = dmd_json_body(array());
dmd_api_require_csrf('dmd_remoteagent', $payload);

if ($action === 'remote_diag_sample') {
    $agentId=dmd_agent_safe_agent_id(isset($payload['agent_id'])?$payload['agent_id']:'');
    if($agentId==='' || !dmd_remoteagent_has_permission($email,$agentId,'remote.screen')) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'),403);
    $diagDir=DMD_REMOTEAGENT_ROOT.'/var/agent/remote-diagnostic'; if(!is_dir($diagDir)) @mkdir($diagDir,0750,true);
    $sample=array(
      'ts_ms'=>(int)round(microtime(true)*1000),
      'sequence'=>max(0,(int)($payload['sequence']??0)),
      'fetch_ms'=>max(0,min(60000,(int)($payload['fetch_ms']??0))),
      'decode_ms'=>max(0,min(60000,(int)($payload['decode_ms']??0))),
      'display_ms'=>max(0,min(60000,(int)($payload['display_ms']??0))),
      'server_php_ms'=>max(0,min(60000,(int)($payload['server_php_ms']??0))),
      'state_age_ms'=>max(0,min(600000,(int)($payload['state_age_ms']??0))),
      'blob_bytes'=>max(0,min(5000000,(int)($payload['blob_bytes']??0))),
      'polls'=>max(0,(int)($payload['polls']??0)),'frames'=>max(0,(int)($payload['frames']??0)),'errors'=>max(0,(int)($payload['errors']??0)),
      'input_queue'=>max(0,min(1000,(int)($payload['input_queue']??0))),'input_busy'=>!empty($payload['input_busy'])
    );
    @file_put_contents($diagDir.'/'.$agentId.'.browser.json',json_encode($sample,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),LOCK_EX);
    dmd_json_response(array('ok'=>true));
}

if ($action === 'security_unlock') {
    $message = '';
    $ok = dmd_remoteagent_security_unlock($email, isset($payload['code']) ? $payload['code'] : '', $message);
    $state = dmd_remoteagent_security_state($email);
    dmd_json_response(array('ok'=>(bool)$ok,'error'=>$ok ? '' : 'mfa_invalid','message'=>$message,'security'=>$state,'server_time'=>time()), $ok ? 200 : 403);
}
if ($action === 'security_lock') {
    dmd_remoteagent_security_session_clear($email);
    dmd_json_response(array('ok'=>true,'security'=>dmd_remoteagent_security_state($email),'server_time'=>time()));
}
if (!dmd_remoteagent_security_state($email)['unlocked']) {
    dmd_remoteagent_security_json_denied($email);
}

if ($action === 'remote_ws_ticket') {
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
    if ($agentId === '' || !dmd_remoteagent_has_permission($email, $agentId, 'remote.screen')) {
        dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
    }
    require_once DMD_REMOTEAGENT_ROOT . '/adm/agent/includes/remote_ws.php';
    $permissions = array('video','control','screen');
    if (!empty($payload['control']) && dmd_remoteagent_has_permission($email, $agentId, 'remote.control')) $permissions[] = 'input';
    if (dmd_remoteagent_has_permission($email, $agentId, 'remote.clipboard')) $permissions[] = 'clipboard';
    $issued = dmd_remote_ws_issue_ticket('viewer', $agentId, $permissions, 180);
    if (empty($issued['ok'])) {
        dmd_json_response(array(
            'ok'=>false,
            'error'=>(string)($issued['error'] ?? 'remote_ws_unavailable'),
            'details'=>$issued,
        ), 503);
    }
    dmd_json_response(array(
        'ok'=>true,
        'ticket'=>$issued['ticket'],
        'remote_url'=>$issued['remote_url'],
        'expires_at'=>$issued['expires_at'],
        'permissions'=>$issued['permissions'],
    ));
}

if ($action === 'remote_input') {
    // Ancien canal de contrôle HTTP retiré : clavier/souris passent par le
    // WebSocket CONTROL indépendant du flux vidéo.
    dmd_json_response(array('ok'=>false,'error'=>'remote_input_retired','transport'=>'websocket_control'), 410);
}

if ($action === 'command') {
    $agentId = isset($payload['agent_id']) ? $payload['agent_id'] : '';
    $operation = isset($payload['operation']) ? trim((string)$payload['operation']) : '';
    $params = isset($payload['params']) && is_array($payload['params']) ? $payload['params'] : array();
    $result = dmd_remoteagent_queue_operation($email, $agentId, $operation, $params, 'module');
    dmd_json_response($result, !empty($result['ok']) ? 200 : (($result['error'] ?? '') === 'permission_denied' ? 403 : 400));
}

if ($action === 'interactive_touch') {
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
    if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
    $ok = function_exists('dmd_agent_command_mark_interactive') ? dmd_agent_command_mark_interactive($agentId, 45) : true;
    dmd_json_response(array('ok'=>(bool)$ok,'interactive_for'=>45), $ok ? 200 : 500);
}

if ($action === 'touch') {
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
    if ($agentId === '' || !dmd_remoteagent_touch($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
    dmd_json_response(array('ok'=>true));
}

if ($action === 'cancel') {
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
    $commandId = isset($payload['command_id']) ? trim((string)$payload['command_id']) : '';
    if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
    $result = dmd_agent_command_cancel($agentId, $commandId, $email);
    dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
}

dmd_json_response(array('ok'=>false,'error'=>'action_invalid'), 400);
