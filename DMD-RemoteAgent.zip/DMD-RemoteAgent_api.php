<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$email = dmd_api_require_user();
if (!dmd_user_can_use_module($email, DMD_REMOTEAGENT_MODULE_ID)) {
    dmd_json_response(array('ok'=>false,'error'=>'module_access_denied'), 403);
}

$action = isset($_GET['action']) ? trim((string)$_GET['action']) : '';
$method = strtoupper((string)(isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET'));

if ($method === 'GET') {
    if ($action === 'security_status') {
        dmd_json_response(array('ok'=>true,'security'=>dmd_remoteagent_security_state($email),'server_time'=>time()));
    }
    if ($action !== 'security_status' && !dmd_remoteagent_security_state($email)['unlocked']) {
        dmd_remoteagent_security_json_denied($email);
    }
    if ($action === 'state') {
        $devices = array();
        foreach (dmd_remoteagent_accessible_devices($email) as $device) $devices[] = dmd_remoteagent_state_device($device);
        dmd_json_response(array(
            'ok'=>true,
            'devices'=>$devices,
            'is_superadmin'=>dmd_remoteagent_is_superadmin($email),
            'admin_url'=>'adm/agent/',
            'server_time'=>time(),
        ));
    }
    if ($action === 'command_status') {
        $agentId = dmd_agent_safe_agent_id(isset($_GET['agent_id']) ? $_GET['agent_id'] : '');
        $commandId = isset($_GET['command_id']) ? trim((string)$_GET['command_id']) : '';
        if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
        if (function_exists('dmd_agent_command_mark_interactive')) dmd_agent_command_mark_interactive($agentId, 20);
        $command = dmd_agent_command_status($agentId, $commandId);
        if (!$command) dmd_json_response(array('ok'=>false,'error'=>'command_not_found'), 404);
        dmd_json_response(array('ok'=>true,'command'=>$command));
    }
    if ($action === 'remote_frame_binary') {
        $agentId = dmd_agent_safe_agent_id(isset($_GET['agent_id']) ? $_GET['agent_id'] : '');
        if ($agentId === '' || !dmd_remoteagent_has_permission($email, $agentId, 'remote.screen')) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
        // Le flux image ne doit pas monopoliser le verrou de session PHP :
        // les clics/clavier arrivent en parallèle dans la même session navigateur.
        if (session_status() === PHP_SESSION_ACTIVE) @session_write_close();
        $state = dmd_agent_remote_state($agentId);
        $after = isset($_GET['after']) ? max(0,(int)$_GET['after']) : 0;
        $seq = (int)($state['sequence'] ?? 0);
        $active = $state && !empty($state['active']);
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('X-DMD-Remote-Active: ' . ($active ? '1' : '0'));
        header('X-DMD-Remote-Sequence: ' . $seq);
        header('X-DMD-Remote-Width: ' . (int)($state['width'] ?? 0));
        header('X-DMD-Remote-Height: ' . (int)($state['height'] ?? 0));
        header('X-DMD-Remote-Control: ' . (!empty($state['control']) ? '1' : '0'));
        header('X-DMD-Remote-Frame-Mode: ' . (string)($state['frame_mode'] ?? 'full'));
        if (!$active || $seq <= $after) { http_response_code(204); exit; }
        $frame = dmd_agent_remote_frame($agentId);
        if ($frame === '') { http_response_code(204); exit; }
        header('Content-Type: image/jpeg');
        header('Content-Length: ' . strlen($frame));
        echo $frame;
        exit;
    }
    if ($action === 'remote_frame') {
        $agentId = dmd_agent_safe_agent_id(isset($_GET['agent_id']) ? $_GET['agent_id'] : '');
        if ($agentId === '' || !dmd_remoteagent_has_permission($email, $agentId, 'remote.screen')) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
        $state = dmd_agent_remote_state($agentId);
        if (!$state || empty($state['active'])) dmd_json_response(array('ok'=>true,'active'=>false,'sequence'=>(int)($state['sequence'] ?? 0)));
        $after = isset($_GET['after']) ? max(0,(int)$_GET['after']) : 0;
        $seq = (int)($state['sequence'] ?? 0);
        if ($seq <= $after) dmd_json_response(array('ok'=>true,'active'=>true,'no_change'=>true,'sequence'=>$seq,'width'=>(int)($state['width'] ?? 0),'height'=>(int)($state['height'] ?? 0),'control'=>!empty($state['control'])));
        $frame = dmd_agent_remote_frame($agentId);
        if ($frame === '') dmd_json_response(array('ok'=>true,'active'=>true,'no_change'=>true,'sequence'=>$seq));
        dmd_json_response(array('ok'=>true,'active'=>true,'sequence'=>$seq,'width'=>(int)($state['width'] ?? 0),'height'=>(int)($state['height'] ?? 0),'control'=>!empty($state['control']),'jpeg_base64'=>base64_encode($frame)));
    }
    if ($action === 'history') {
        $agentId = dmd_agent_safe_agent_id(isset($_GET['agent_id']) ? $_GET['agent_id'] : '');
        if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
        $limit = isset($_GET['limit']) ? max(1, min(100, (int)$_GET['limit'])) : 40;
        dmd_json_response(array('ok'=>true,'commands'=>dmd_agent_command_history($agentId, $limit)));
    }
    dmd_json_response(array('ok'=>false,'error'=>'action_invalid'), 400);
}

if ($method !== 'POST') dmd_json_response(array('ok'=>false,'error'=>'method_not_allowed'), 405);
$payload = dmd_json_body(array());
dmd_api_require_csrf('dmd_remoteagent', $payload);

if ($action === 'security_unlock') {
    $message = '';
    $ok = dmd_remoteagent_security_unlock($email, isset($payload['code']) ? $payload['code'] : '', $message);
    $state = dmd_remoteagent_security_state($email);
    dmd_json_response(array('ok'=>(bool)$ok,'error'=>$ok ? '' : 'mfa_invalid','message'=>$message,'security'=>$state,'server_time'=>time()), $ok ? 200 : 403);
}
if ($action === 'security_lock') {
    dmd_remoteagent_security_session_clear($email);
    dmd_json_response(array('ok'=>true,'security'=>dmd_remoteagent_security_state($email),'server_time'=>time()));
}
if (!dmd_remoteagent_security_state($email)['unlocked']) {
    dmd_remoteagent_security_json_denied($email);
}

if ($action === 'remote_input') {
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
    if ($agentId === '' || !dmd_remoteagent_has_permission($email, $agentId, 'remote.control')) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
    if (session_status() === PHP_SESSION_ACTIVE) @session_write_close();

    $rawEvents = array();
    if (isset($payload['events']) && is_array($payload['events'])) $rawEvents = array_slice($payload['events'], 0, 64);
    elseif (isset($payload['event']) && is_array($payload['event'])) $rawEvents = array($payload['event']);
    if (!$rawEvents) dmd_json_response(array('ok'=>false,'error'=>'remote_event_invalid'), 400);

    $cleanEvents = array();
    foreach ($rawEvents as $event) {
        if (!is_array($event)) continue;
        $type = strtolower(trim((string)($event['type'] ?? '')));
        $clean = array('type'=>$type);
        if ($type === 'move') {
            $clean['nx']=max(0,min(100000,(int)($event['nx'] ?? 0))); $clean['ny']=max(0,min(100000,(int)($event['ny'] ?? 0)));
        } elseif ($type === 'button') {
            $clean['button']=max(0,min(2,(int)($event['button'] ?? 0))); $clean['down']=!empty($event['down']);
        } elseif ($type === 'wheel') {
            $clean['delta']=max(-2400,min(2400,(int)($event['delta'] ?? 0)));
        } elseif ($type === 'key') {
            $vk=max(1,min(255,(int)($event['vk'] ?? 0))); $clean['vk']=$vk; $clean['down']=!empty($event['down']);
        } elseif ($type === 'text') {
            $text=(string)($event['text'] ?? ''); if(strlen($text)>64)$text=substr($text,0,64); if($text==='') continue; $clean['text']=$text;
        } else continue;
        $cleanEvents[] = $clean;
    }
    if (!$cleanEvents) dmd_json_response(array('ok'=>false,'error'=>'remote_event_invalid'), 400);
    if (function_exists('dmd_agent_remote_queue_inputs')) {
        if (!dmd_agent_remote_queue_inputs($agentId,$cleanEvents)) dmd_json_response(array('ok'=>false,'error'=>'remote_queue_failed'),500);
    } else {
        foreach ($cleanEvents as $clean) if (!dmd_agent_remote_queue_input($agentId,$clean)) dmd_json_response(array('ok'=>false,'error'=>'remote_queue_failed'),500);
    }
    dmd_json_response(array('ok'=>true,'queued'=>count($cleanEvents)));
}

if ($action === 'command') {
    $agentId = isset($payload['agent_id']) ? $payload['agent_id'] : '';
    $operation = isset($payload['operation']) ? trim((string)$payload['operation']) : '';
    $params = isset($payload['params']) && is_array($payload['params']) ? $payload['params'] : array();
    $result = dmd_remoteagent_queue_operation($email, $agentId, $operation, $params, 'module');
    dmd_json_response($result, !empty($result['ok']) ? 200 : (($result['error'] ?? '') === 'permission_denied' ? 403 : 400));
}

if ($action === 'interactive_touch') {
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
    if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
    $ok = function_exists('dmd_agent_command_mark_interactive') ? dmd_agent_command_mark_interactive($agentId, 45) : true;
    dmd_json_response(array('ok'=>(bool)$ok,'interactive_for'=>45), $ok ? 200 : 500);
}

if ($action === 'touch') {
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
    if ($agentId === '' || !dmd_remoteagent_touch($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
    dmd_json_response(array('ok'=>true));
}

if ($action === 'cancel') {
    $agentId = dmd_agent_safe_agent_id(isset($payload['agent_id']) ? $payload['agent_id'] : '');
    $commandId = isset($payload['command_id']) ? trim((string)$payload['command_id']) : '';
    if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) dmd_json_response(array('ok'=>false,'error'=>'permission_denied'), 403);
    $result = dmd_agent_command_cancel($agentId, $commandId, $email);
    dmd_json_response($result, !empty($result['ok']) ? 200 : 400);
}

dmd_json_response(array('ok'=>false,'error'=>'action_invalid'), 400);
