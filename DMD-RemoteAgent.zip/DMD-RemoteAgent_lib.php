<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();

if (!defined('DMD_REMOTEAGENT_ROOT')) define('DMD_REMOTEAGENT_ROOT', dirname(__DIR__, 2));
if (!defined('DMD_REMOTEAGENT_MODULE_ID')) define('DMD_REMOTEAGENT_MODULE_ID', 'DMD-RemoteAgent');

require_once DMD_REMOTEAGENT_ROOT . '/core/dmd_permissions.php';
require_once DMD_REMOTEAGENT_ROOT . '/core/dmd_security.php';
require_once DMD_REMOTEAGENT_ROOT . '/core/dmd_system_services.php';
require_once DMD_REMOTEAGENT_ROOT . '/core/dmd_module_logs.php';
require_once DMD_REMOTEAGENT_ROOT . '/core/dmd_activity.php';
require_once DMD_REMOTEAGENT_ROOT . '/core/dmd_module_events.php';
if (is_file(DMD_REMOTEAGENT_ROOT . '/core/dmd_mfa.php')) require_once DMD_REMOTEAGENT_ROOT . '/core/dmd_mfa.php';
require_once DMD_REMOTEAGENT_ROOT . '/adm/agent/includes/agent_core.php';

function dmd_remoteagent_h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_remoteagent_email() {
    return isset($_SESSION['user']['email']) ? trim((string)$_SESSION['user']['email']) : '';
}

function dmd_remoteagent_profile($email) {
    return function_exists('dmd_read_profile') ? dmd_read_profile($email) : array();
}

function dmd_remoteagent_is_superadmin($email) {
    $profile = dmd_remoteagent_profile($email);
    return strtolower(trim((string)(isset($profile['role_system']) ? $profile['role_system'] : ''))) === 'superadmin';
}

function dmd_remoteagent_operator_label($email) {
    $profile = dmd_remoteagent_profile($email);
    $first = trim((string)($profile['prenom'] ?? $profile['first_name'] ?? $profile['firstname'] ?? ''));
    $last = trim((string)($profile['nom'] ?? $profile['last_name'] ?? $profile['lastname'] ?? ''));
    $label = trim($first . ' ' . $last);
    if ($label === '') {
        foreach (array('display_name','pseudo','user_name','name','username') as $field) {
            $v = trim((string)($profile[$field] ?? ''));
            if ($v !== '') { $label = $v; break; }
        }
    }
    if ($label === '') $label = trim((string)$email);
    if (strlen($label) > 120) $label = substr($label, 0, 120);
    return $label;
}

function dmd_remoteagent_security_defaults() {
    return array(
        'version' => 1,
        'mfa_enabled' => false,
        'session_minutes' => 15,
    );
}

function dmd_remoteagent_security_config_path() {
    return DMD_REMOTEAGENT_ROOT . '/var/agent/remoteagent_module_security.json';
}

function dmd_remoteagent_security_config_read() {
    $out = dmd_remoteagent_security_defaults();
    $file = dmd_remoteagent_security_config_path();
    if (!is_file($file)) return $out;
    $raw = @file_get_contents($file);
    $data = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($data)) return $out;
    $out['mfa_enabled'] = !empty($data['mfa_enabled']);
    $minutes = isset($data['session_minutes']) ? (int)$data['session_minutes'] : 15;
    $out['session_minutes'] = max(1, min(720, $minutes));
    if (!empty($data['updated_at'])) $out['updated_at'] = (string)$data['updated_at'];
    if (!empty($data['updated_by'])) $out['updated_by'] = (string)$data['updated_by'];
    return $out;
}

function dmd_remoteagent_security_config_write($config, $updatedBy) {
    if (!is_array($config)) return false;
    $dir = dirname(dmd_remoteagent_security_config_path());
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    @chmod($dir, 0750);
    $clean = dmd_remoteagent_security_defaults();
    $clean['mfa_enabled'] = !empty($config['mfa_enabled']);
    $clean['session_minutes'] = max(1, min(720, (int)(isset($config['session_minutes']) ? $config['session_minutes'] : 15)));
    $clean['updated_at'] = date('c');
    $clean['updated_by'] = trim((string)$updatedBy);
    $json = json_encode($clean, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) return false;
    try { $suffix = bin2hex(random_bytes(5)); } catch (Exception $e) { return false; }
    $file = dmd_remoteagent_security_config_path();
    $tmp = $file . '.tmp.' . $suffix;
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
    @chmod($file, 0640);
    return true;
}

function dmd_remoteagent_security_stop_active_remotes($email = '') {
    $email = trim((string)$email);
    $active = isset($_SESSION['dmd_remoteagent_active_remote']) && is_array($_SESSION['dmd_remoteagent_active_remote'])
        ? $_SESSION['dmd_remoteagent_active_remote'] : array();
    if ($email !== '' && function_exists('dmd_agent_queue_command')) {
        foreach (array_keys($active) as $agentId) {
            $agentId = dmd_agent_safe_agent_id($agentId);
            if ($agentId === '') continue;
            @dmd_agent_queue_command($agentId, 'remote.stop', array(), $email, 'remote.screen', 120);
        }
    }
    unset($_SESSION['dmd_remoteagent_active_remote']);
}

function dmd_remoteagent_security_session_clear($email = '') {
    dmd_remoteagent_security_stop_active_remotes($email);
    unset($_SESSION['dmd_remoteagent_module_mfa']);
}

function dmd_remoteagent_security_state($email) {
    $email = trim((string)$email);
    $cfg = dmd_remoteagent_security_config_read();
    $base = array(
        'enabled' => !empty($cfg['mfa_enabled']),
        'required' => !empty($cfg['mfa_enabled']),
        'session_minutes' => (int)$cfg['session_minutes'],
        'account_mfa' => false,
        'unlocked' => true,
        'verified_at' => 0,
        'expires_at' => 0,
        'remaining_seconds' => 0,
        'blocked_reason' => '',
    );
    if (empty($cfg['mfa_enabled'])) return $base;
    $base['unlocked'] = false;
    if (!function_exists('dmd_mfa_enabled') || !function_exists('dmd_mfa_verify_user_code')) {
        $base['blocked_reason'] = 'mfa_unavailable';
        return $base;
    }
    $policy = function_exists('dmd_mfa_effective_policy') ? dmd_mfa_effective_policy($email, dmd_remoteagent_profile($email)) : 'optional';
    if ($policy === 'disabled') {
        $base['blocked_reason'] = 'mfa_disabled_by_policy';
        return $base;
    }
    $base['account_mfa'] = dmd_mfa_enabled($email);
    if (!$base['account_mfa']) {
        $base['blocked_reason'] = 'mfa_not_configured';
        return $base;
    }
    $session = isset($_SESSION['dmd_remoteagent_module_mfa']) && is_array($_SESSION['dmd_remoteagent_module_mfa'])
        ? $_SESSION['dmd_remoteagent_module_mfa'] : array();
    if ((string)(isset($session['email']) ? $session['email'] : '') !== $email) {
        dmd_remoteagent_security_session_clear($email);
        return $base;
    }
    $verifiedAt = (int)(isset($session['verified_at']) ? $session['verified_at'] : 0);
    $expiresAt = (int)(isset($session['expires_at']) ? $session['expires_at'] : 0);
    $sessionRevision = (string)(isset($session['config_revision']) ? $session['config_revision'] : '');
    $configRevision = (string)(isset($cfg['updated_at']) ? $cfg['updated_at'] : '');
    if (($configRevision !== '' && $sessionRevision !== $configRevision) || $verifiedAt <= 0 || $expiresAt <= time()) {
        dmd_remoteagent_security_session_clear($email);
        return $base;
    }
    $base['unlocked'] = true;
    $base['verified_at'] = $verifiedAt;
    $base['expires_at'] = $expiresAt;
    $base['remaining_seconds'] = max(0, $expiresAt - time());
    return $base;
}

function dmd_remoteagent_security_unlock($email, $code, &$message) {
    $message = '';
    $state = dmd_remoteagent_security_state($email);
    if (empty($state['enabled'])) { $message = 'Protection MFA désactivée.'; return true; }
    if (empty($state['account_mfa'])) { $message = 'MFA non disponible pour ce compte.'; return false; }
    $now = time();
    $attempts = isset($_SESSION['dmd_remoteagent_mfa_attempts']) && is_array($_SESSION['dmd_remoteagent_mfa_attempts'])
        ? $_SESSION['dmd_remoteagent_mfa_attempts'] : array('count'=>0,'window_start'=>$now,'locked_until'=>0);
    $lockedUntil = (int)(isset($attempts['locked_until']) ? $attempts['locked_until'] : 0);
    if ($lockedUntil > $now) {
        $message = 'Trop de tentatives. Réessayez dans ' . ($lockedUntil - $now) . ' seconde(s).';
        return false;
    }
    if ($now - (int)(isset($attempts['window_start']) ? $attempts['window_start'] : $now) > 600) {
        $attempts = array('count'=>0,'window_start'=>$now,'locked_until'=>0);
    }
    $usedRecovery = false;
    if (!dmd_mfa_verify_user_code($email, trim((string)$code), $usedRecovery)) {
        $attempts['count'] = (int)(isset($attempts['count']) ? $attempts['count'] : 0) + 1;
        if ($attempts['count'] >= 5) {
            $attempts['locked_until'] = $now + 60;
            $attempts['count'] = 0;
            $attempts['window_start'] = $now;
            $message = 'Code incorrect. Trop de tentatives : verrouillage pendant 60 secondes.';
        } else {
            $message = 'Code MFA incorrect. Tentatives restantes : ' . (5 - $attempts['count']) . '.';
        }
        $_SESSION['dmd_remoteagent_mfa_attempts'] = $attempts;
        return false;
    }
    unset($_SESSION['dmd_remoteagent_mfa_attempts']);
    $cfg = dmd_remoteagent_security_config_read();
    $expiresAt = $now + ((int)$cfg['session_minutes'] * 60);
    $_SESSION['dmd_remoteagent_module_mfa'] = array('email'=>$email,'verified_at'=>$now,'expires_at'=>$expiresAt,'config_revision'=>(string)(isset($cfg['updated_at']) ? $cfg['updated_at'] : ''));
    $_SESSION['dmd_mfa_authenticated_at'] = $now;
    $message = $usedRecovery ? 'DMD-RemoteAgent déverrouillé avec un code de secours.' : 'DMD-RemoteAgent déverrouillé.';
    if (function_exists('dmd_system_log')) dmd_system_log('remoteagent_mfa_unlock', $email, 'success', $message);
    return true;
}

function dmd_remoteagent_security_json_denied($email) {
    $state = dmd_remoteagent_security_state($email);
    dmd_json_response(array(
        'ok'=>false,
        'error'=>'module_mfa_required',
        'message'=>'DMD-RemoteAgent est verrouillé. Une nouvelle validation MFA est requise.',
        'security'=>$state,
    ), 403);
}


function dmd_remoteagent_device_capabilities($device) {
    $caps = array();
    foreach (array('capabilities', 'reported_capabilities') as $key) {
        foreach ((array)(isset($device[$key]) ? $device[$key] : array()) as $cap) {
            $cap = trim((string)$cap);
            if ($cap !== '' && !in_array($cap, $caps, true)) $caps[] = $cap;
        }
    }
    sort($caps, SORT_STRING);
    return $caps;
}

function dmd_remoteagent_is_online($device, $now = null) {
    if ($now === null) $now = time();
    $last = isset($device['last_seen_ts']) ? (int)$device['last_seen_ts'] : 0;
    return ((string)(isset($device['status']) ? $device['status'] : '') === 'active') && $last > 0 && (($now - $last) < 90);
}

function dmd_remoteagent_resource($device) {
    $agentId = (string)(isset($device['agent_id']) ? $device['agent_id'] : '');
    $hostname = trim((string)(isset($device['hostname']) ? $device['hostname'] : 'PC'));
    if ($hostname === '') $hostname = 'PC';
    $platform = strtolower(trim((string)(isset($device['platform']) ? $device['platform'] : '')));
    $tags = array('remoteagent');
    if ($platform !== '') $tags[] = 'os:' . $platform;
    foreach (dmd_agent_access_pc_groups_for_agent($agentId) as $group) {
        if (!empty($group['name'])) $tags[] = 'group:' . trim((string)$group['name']);
    }
    return array(
        'type' => 'remoteagent_pc',
        'id' => DMD_REMOTEAGENT_MODULE_ID . ':pc:' . $agentId,
        'name' => $hostname,
        'label' => $hostname,
        'source' => DMD_REMOTEAGENT_MODULE_ID,
        'tags' => array_values(array_unique($tags)),
    );
}

function dmd_remoteagent_parse_resource_id($resourceId) {
    $prefix = DMD_REMOTEAGENT_MODULE_ID . ':pc:';
    $resourceId = trim((string)$resourceId);
    if (strpos($resourceId, $prefix) !== 0) return '';
    return dmd_agent_safe_agent_id(substr($resourceId, strlen($prefix)));
}

function dmd_remoteagent_get_device($agentId) {
    $agentId = dmd_agent_safe_agent_id($agentId);
    if ($agentId === '') return array();
    $file = dmd_agent_device_file($agentId);
    if ($file === '' || !is_file($file)) return array();
    return dmd_agent_json_read($file, array());
}

function dmd_remoteagent_effective_permissions($email, $agentId) {
    return dmd_agent_access_effective_permissions(trim((string)$email), dmd_agent_safe_agent_id($agentId));
}

function dmd_remoteagent_user_can_see_device($email, $agentId) {
    if (dmd_remoteagent_is_superadmin($email)) return true;
    return count(dmd_remoteagent_effective_permissions($email, $agentId)) > 0;
}

function dmd_remoteagent_accessible_devices($email) {
    $email = trim((string)$email);
    $now = time();
    $out = array();
    foreach (dmd_agent_list_devices() as $device) {
        $agentId = dmd_agent_safe_agent_id(isset($device['agent_id']) ? $device['agent_id'] : '');
        if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId)) continue;
        $permissions = dmd_remoteagent_effective_permissions($email, $agentId);
        $groups = array();
        foreach (dmd_agent_access_pc_groups_for_agent($agentId) as $group) {
            $groups[] = array(
                'group_id' => (string)(isset($group['group_id']) ? $group['group_id'] : ''),
                'name' => (string)(isset($group['name']) ? $group['name'] : ''),
            );
        }
        $device['_online'] = dmd_remoteagent_is_online($device, $now);
        $device['_permissions'] = $permissions;
        $device['_groups'] = $groups;
        $device['_resource'] = dmd_remoteagent_resource($device);
        $device['_pending_commands'] = function_exists('dmd_agent_command_pending_count') ? dmd_agent_command_pending_count($agentId) : 0;
        $out[] = $device;
    }
    usort($out, function($a, $b) {
        $ao = !empty($a['_online']) ? 0 : 1;
        $bo = !empty($b['_online']) ? 0 : 1;
        if ($ao !== $bo) return $ao < $bo ? -1 : 1;
        return strcasecmp((string)(isset($a['hostname']) ? $a['hostname'] : ''), (string)(isset($b['hostname']) ? $b['hostname'] : ''));
    });
    return $out;
}

function dmd_remoteagent_has_permission($email, $agentId, $permission) {
    if (dmd_remoteagent_is_superadmin($email)) return true;
    return dmd_agent_access_check($email, $agentId, $permission);
}

function dmd_remoteagent_operation_catalog() {
    return array(
        'pc.refresh' => array('command'=>'inventory.refresh','permission'=>'__visible__','capability'=>'inventory.basic','ttl'=>180,'notify'=>false),
        'remote.screen' => array('command'=>'remote.start','permission'=>'remote.screen','capability'=>'remote.screen','ttl'=>120,'notify'=>false),
        'remote.control' => array('command'=>'remote.start_control','permission'=>'remote.control','capability'=>'remote.control','ttl'=>120,'notify'=>false),
        'remote.stop' => array('command'=>'remote.stop','permission'=>'remote.screen','capability'=>'remote.screen','ttl'=>120,'notify'=>false),
        'remote.resolution' => array('command'=>'remote.resolution.set','permission'=>'remote.screen','capability'=>'remote.screen','ttl'=>120,'notify'=>false),
        'remote.clipboard.get' => array('command'=>'remote.clipboard.get','permission'=>'remote.clipboard','capability'=>'remote.clipboard','ttl'=>120,'notify'=>false),
        'remote.clipboard.set' => array('command'=>'remote.clipboard.set','permission'=>'remote.clipboard','capability'=>'remote.clipboard','ttl'=>120,'notify'=>false),
        'files.roots' => array('command'=>'filesystem.roots','permission'=>'files.browse','capability'=>'filesystem.roots','ttl'=>180,'notify'=>false),
        'files.list' => array('command'=>'filesystem.list','permission'=>'files.browse','capability'=>'filesystem.list','ttl'=>180,'notify'=>false),
        'files.read' => array('command'=>'filesystem.read','permission'=>'files.download','capability'=>'filesystem.read','ttl'=>300,'notify'=>false),
        'files.write' => array('command'=>'filesystem.write','permission'=>'files.upload','capability'=>'filesystem.write','ttl'=>600,'notify'=>true),
        'files.mkdir' => array('command'=>'filesystem.mkdir','permission'=>'files.mkdir','capability'=>'filesystem.mkdir','ttl'=>300,'notify'=>true),
        'files.delete' => array('command'=>'filesystem.delete','permission'=>'files.delete','capability'=>'filesystem.write','ttl'=>300,'notify'=>true),
        'files.rename' => array('command'=>'filesystem.rename','permission'=>'files.rename','capability'=>'filesystem.write','ttl'=>300,'notify'=>true),
        'software.list' => array('command'=>'software.list','permission'=>'software.view','capability'=>'software.list','ttl'=>300,'notify'=>false),
        'software.uninstall' => array('command'=>'software.uninstall','permission'=>'software.uninstall','capability'=>'software.uninstall','ttl'=>1200,'notify'=>true),
        'processes.list' => array('command'=>'processes.list','permission'=>'processes.view','capability'=>'system.processes','ttl'=>180,'notify'=>false),
        'processes.kill' => array('command'=>'processes.kill','permission'=>'processes.kill','capability'=>'system.processes','ttl'=>180,'notify'=>true),
        'services.list' => array('command'=>'services.list','permission'=>'services.view','capability'=>'system.services','ttl'=>180,'notify'=>false),
        'services.control' => array('command'=>'services.control','permission'=>'services.control','capability'=>'system.services','ttl'=>300,'notify'=>true),
        'system.terminal' => array('command'=>'system.terminal','permission'=>'system.terminal','capability'=>'system.terminal','ttl'=>600,'notify'=>true),
        'system.restart' => array('command'=>'system.restart','permission'=>'system.restart','capability'=>'system.power','ttl'=>300,'notify'=>true),
        'system.shutdown' => array('command'=>'system.shutdown','permission'=>'system.shutdown','capability'=>'system.power','ttl'=>300,'notify'=>true),
        'agent.update' => array('command'=>'agent.update','permission'=>'agent.update','capability'=>'core.update','ttl'=>1800,'notify'=>true),
    );
}

function dmd_remoteagent_operation_meta($operation) {
    $catalog = dmd_remoteagent_operation_catalog();
    return isset($catalog[$operation]) ? $catalog[$operation] : null;
}

function dmd_remoteagent_operation_allowed($email, $device, $operation, &$reason) {
    $reason = '';
    $meta = dmd_remoteagent_operation_meta($operation);
    if (!is_array($meta)) { $reason = 'operation_unknown'; return false; }
    $agentId = dmd_agent_safe_agent_id(isset($device['agent_id']) ? $device['agent_id'] : '');
    if ($agentId === '') { $reason = 'agent_invalid'; return false; }
    if (!dmd_remoteagent_user_can_see_device($email, $agentId)) { $reason = 'permission_denied'; return false; }
    $permission = (string)$meta['permission'];
    if ($permission !== '__visible__' && !dmd_remoteagent_has_permission($email, $agentId, $permission)) {
        $reason = 'permission_denied'; return false;
    }
    $capability = trim((string)$meta['capability']);
    if ($capability !== '' && !in_array($capability, dmd_remoteagent_device_capabilities($device), true)) {
        $reason = 'capability_missing'; return false;
    }
    if ((string)(isset($device['status']) ? $device['status'] : '') !== 'active') { $reason = 'agent_inactive'; return false; }
    return true;
}

function dmd_remoteagent_clean_payload($payload, $depth = 0) {
    if ($depth > 5) return null;
    if (is_array($payload)) {
        $out = array();
        $count = 0;
        foreach ($payload as $key => $value) {
            if (++$count > 100) break;
            $safeKey = is_int($key) ? $key : preg_replace('/[^a-zA-Z0-9._-]+/', '_', substr((string)$key, 0, 80));
            $out[$safeKey] = dmd_remoteagent_clean_payload($value, $depth + 1);
        }
        return $out;
    }
    if (is_bool($payload) || is_int($payload) || is_float($payload) || $payload === null) return $payload;
    return substr((string)$payload, 0, 32768);
}

function dmd_remoteagent_normalize_operation_payload($operation, $payload) {
    $payload = is_array($payload) ? $payload : array();
    if ($operation === 'software.list') {
        $query=trim((string)($payload['query'] ?? '')); if(strlen($query)>120)$query=substr($query,0,120);
        return array('offset'=>max(0,(int)($payload['offset'] ?? 0)),'limit'=>max(10,min(60,(int)($payload['limit'] ?? 40))),'query'=>$query);
    }
    if ($operation === 'software.uninstall') {
        $id=strtoupper(trim((string)($payload['id'] ?? '')));
        return preg_match('/^SW-[A-F0-9]{24}$/',$id) ? array('id'=>$id) : array();
    }
    if ($operation === 'processes.list') {
        return array('offset'=>max(0,(int)($payload['offset'] ?? 0)),'limit'=>max(5,min(25,(int)($payload['limit'] ?? 25))));
    }
    if ($operation === 'services.list') {
        return array('offset'=>max(0,(int)($payload['offset'] ?? 0)),'limit'=>max(10,min(40,(int)($payload['limit'] ?? 40))));
    }
    if ($operation === 'processes.kill') {
        $pid=(int)($payload['pid'] ?? 0); return $pid>0 ? array('pid'=>$pid) : array();
    }
    if ($operation === 'services.control') {
        $name=trim((string)($payload['name'] ?? '')); $verb=strtolower(trim((string)($payload['operation'] ?? 'restart')));
        if (!preg_match('/^[A-Za-z0-9_.-]{1,256}$/',$name) || !in_array($verb,array('start','stop','restart'),true)) return array();
        return array('name'=>$name,'operation'=>$verb);
    }
    if ($operation === 'system.restart' || $operation === 'system.shutdown') {
        $delay=(int)($payload['delay_seconds'] ?? 60); return array('delay_seconds'=>max(45,min(120,$delay)));
    }
    if ($operation === 'remote.resolution') {
        $mode=strtolower(trim((string)($payload['mode'] ?? 'auto')));
        if (!in_array($mode,array('info','auto','1024x768','1280x720','1366x768','1600x900','1920x1080'),true)) $mode='auto';
        return array('mode'=>$mode);
    }
    if ($operation === 'system.terminal') {
        $command=trim((string)($payload['command'] ?? ''));
        $shell=strtolower(trim((string)($payload['shell'] ?? 'powershell')));
        if (!in_array($shell,array('powershell','cmd'),true)) $shell='powershell';
        $timeout=max(1,min(120,(int)($payload['timeout_seconds'] ?? 45)));
        if (strlen($command)>8192) $command=substr($command,0,8192);
        return array('command'=>$command,'shell'=>$shell,'timeout_seconds'=>$timeout);
    }
    if ($operation === 'files.roots') return array();
    if ($operation === 'files.list') {
        $path=trim((string)($payload['path'] ?? '')); if(strlen($path)>32000)$path=substr($path,0,32000);
        return array('path'=>$path,'offset'=>max(0,(int)($payload['offset'] ?? 0)),'limit'=>max(10,min(120,(int)($payload['limit'] ?? 80))));
    }
    if ($operation === 'files.read') {
        $path=trim((string)($payload['path'] ?? '')); if(strlen($path)>32000)$path=substr($path,0,32000);
        return array('path'=>$path,'offset'=>max(0,(int)($payload['offset'] ?? 0)),'length'=>max(1,min(28672,(int)($payload['length'] ?? 28672))),'transfer_final'=>!empty($payload['transfer_final']));
    }
    if ($operation === 'files.write') {
        $path=trim((string)($payload['path'] ?? '')); if(strlen($path)>32000)$path=substr($path,0,32000);
        $data=(string)($payload['data_base64'] ?? ''); if(strlen($data)>42000)$data=substr($data,0,42000);
        return array('path'=>$path,'offset'=>max(0,(int)($payload['offset'] ?? 0)),'truncate'=>!empty($payload['truncate']),'data_base64'=>$data,'transfer_final'=>!empty($payload['transfer_final']));
    }
    if ($operation === 'files.mkdir') {
        $path=trim((string)($payload['path'] ?? '')); $name=trim((string)($payload['name'] ?? ''));
        return array('path'=>substr($path,0,32000),'name'=>substr($name,0,240));
    }
    if ($operation === 'files.delete') {
        $path=trim((string)($payload['path'] ?? ''));
        return array('path'=>substr($path,0,32000),'recursive'=>!empty($payload['recursive']));
    }
    if ($operation === 'files.rename') {
        $path=trim((string)($payload['path'] ?? '')); $name=trim((string)($payload['name'] ?? ''));
        return array('path'=>substr($path,0,32000),'name'=>substr($name,0,240));
    }
    return dmd_remoteagent_clean_payload($payload);
}

function dmd_remoteagent_queue_operation($email, $agentId, $operation, $payload, $origin) {
    $email = trim((string)$email);
    $agentId = dmd_agent_safe_agent_id($agentId);
    $device = dmd_remoteagent_get_device($agentId);
    if (!$device) return array('ok'=>false,'error'=>'agent_not_found','message'=>'PC introuvable.');

    $reason = '';
    if (!dmd_remoteagent_operation_allowed($email, $device, $operation, $reason)) {
        $messages = array(
            'permission_denied'=>'Droit DMD-RemoteAgent refusé pour ce PC.',
            'capability_missing'=>'La capability requise n’est pas active sur cet agent.',
            'agent_inactive'=>'Cet agent n’est plus actif.',
            'operation_unknown'=>'Action inconnue.',
        );
        return array('ok'=>false,'error'=>$reason,'message'=>isset($messages[$reason])?$messages[$reason]:'Action refusée.');
    }

    $meta = dmd_remoteagent_operation_meta($operation);
    if (!function_exists('dmd_agent_queue_command')) {
        return array('ok'=>false,'error'=>'server_patch_required','message'=>'Le canal de commandes DMD-Agent n’est pas installé sur cette instance DoMyDesk.');
    }
    $payload = dmd_remoteagent_normalize_operation_payload($operation, $payload);
    if ($operation === 'remote.screen' || $operation === 'remote.control') {
        $noticeSettings = function_exists('dmd_agent_remote_notice_settings_read') ? dmd_agent_remote_notice_settings_read() : array('enabled'=>true,'show_on_view'=>false,'show_operator'=>true);
        $noticeEnabled = !array_key_exists('enabled', $noticeSettings) || !empty($noticeSettings['enabled']);
        if ($operation === 'remote.screen' && empty($noticeSettings['show_on_view'])) $noticeEnabled = false;
        $payload['notice'] = (bool)$noticeEnabled;
        if ($noticeEnabled) {
            $payload['operator_name'] = !array_key_exists('show_operator', $noticeSettings) || !empty($noticeSettings['show_operator']) ? dmd_remoteagent_operator_label($email) : '';
        }
    }
    if (($operation === 'processes.kill' || $operation === 'services.control') && !$payload) return array('ok'=>false,'error'=>'payload_invalid','message'=>'Paramètres de commande invalides.');
    if ($operation === 'software.uninstall' && trim((string)($payload['id'] ?? '')) === '') return array('ok'=>false,'error'=>'payload_invalid','message'=>'Identifiant logiciel invalide.');
    if (in_array($operation,array('files.list','files.read','files.write','files.delete','files.rename'),true) && trim((string)($payload['path'] ?? '')) === '') return array('ok'=>false,'error'=>'payload_invalid','message'=>'Chemin fichier requis.');
    if ($operation === 'files.mkdir' && (trim((string)($payload['path'] ?? '')) === '' || trim((string)($payload['name'] ?? '')) === '')) return array('ok'=>false,'error'=>'payload_invalid','message'=>'Chemin et nom de dossier requis.');
    if ($operation === 'files.rename' && trim((string)($payload['name'] ?? '')) === '') return array('ok'=>false,'error'=>'payload_invalid','message'=>'Nouveau nom requis.');
    if ($operation === 'system.terminal' && trim((string)($payload['command'] ?? '')) === '') return array('ok'=>false,'error'=>'payload_invalid','message'=>'Commande terminal requise.');
    $queued = dmd_agent_queue_command(
        $agentId,
        (string)$meta['command'],
        $payload,
        $email,
        (string)$meta['capability'],
        isset($meta['ttl']) ? (int)$meta['ttl'] : 300
    );
    if (empty($queued['ok'])) {
        return array('ok'=>false,'error'=>isset($queued['error'])?$queued['error']:'queue_failed','message'=>'Impossible de mettre la commande en file.');
    }

    if ($operation === 'remote.screen' || $operation === 'remote.control') {
        if (!isset($_SESSION['dmd_remoteagent_active_remote']) || !is_array($_SESSION['dmd_remoteagent_active_remote'])) $_SESSION['dmd_remoteagent_active_remote'] = array();
        $_SESSION['dmd_remoteagent_active_remote'][$agentId] = time();
    } elseif ($operation === 'remote.stop' && isset($_SESSION['dmd_remoteagent_active_remote'][$agentId])) {
        unset($_SESSION['dmd_remoteagent_active_remote'][$agentId]);
    }

    $resource = dmd_remoteagent_resource($device);
    $isTransferChunk = in_array($operation, array('files.read','files.write'), true);
    $emitEvent = !$isTransferChunk || !empty($payload['transfer_final']);
    $notify = !empty($meta['notify']) && $emitEvent;
    $event = null;
    if ($emitEvent) {
        $event = dmd_module_event(DMD_REMOTEAGENT_MODULE_ID, $operation, $resource, array(
            'email'=>$email,
            'label'=>$operation,
            'target'=>$resource['name'],
            'status'=>'success',
            'details'=>'Commande envoyée à DMD-Agent.',
            'meta'=>array('origin'=>(string)$origin,'command_id'=>$queued['command']['command_id']),
            'notify'=>$notify,
        ));
    }

    return array(
        'ok'=>true,
        'message'=>'Commande envoyée à ' . $resource['name'] . '.',
        'command'=>$queued['command'],
        'resource'=>$resource,
        'event'=>$event,
    );
}

function dmd_remoteagent_state_device($device) {
    $inventory = isset($device['last_inventory']) && is_array($device['last_inventory']) ? $device['last_inventory'] : array();
    return array(
        'agent_id'=>(string)(isset($device['agent_id'])?$device['agent_id']:''),
        'hostname'=>(string)(isset($device['hostname'])?$device['hostname']:'PC'),
        'status'=>(string)(isset($device['status'])?$device['status']:''),
        'online'=>!empty($device['_online']),
        'last_seen_at'=>(string)(isset($device['last_seen_at'])?$device['last_seen_at']:''),
        'last_seen_ts'=>(int)(isset($device['last_seen_ts'])?$device['last_seen_ts']:0),
        'last_ip'=>(string)(isset($device['last_ip'])?$device['last_ip']:''),
        'platform'=>(string)(isset($device['platform'])?$device['platform']:''),
        'arch'=>(string)(isset($device['arch'])?$device['arch']:''),
        'agent_version'=>(string)(isset($device['agent_version'])?$device['agent_version']:''),
        'hardware'=>isset($device['hardware'])&&is_array($device['hardware'])?$device['hardware']:array(),
        'inventory'=>$inventory,
        'capabilities'=>dmd_remoteagent_device_capabilities($device),
        'permissions'=>isset($device['_permissions'])&&is_array($device['_permissions'])?$device['_permissions']:array(),
        'groups'=>isset($device['_groups'])&&is_array($device['_groups'])?$device['_groups']:array(),
        'pending_commands'=>(int)(isset($device['_pending_commands'])?$device['_pending_commands']:0),
        'resource'=>isset($device['_resource'])&&is_array($device['_resource'])?$device['_resource']:dmd_remoteagent_resource($device),
    );
}

function dmd_remoteagent_touch($email, $agentId) {
    $device = dmd_remoteagent_get_device($agentId);
    if (!$device || !dmd_remoteagent_user_can_see_device($email, $agentId)) return false;
    if (function_exists('dmd_agent_command_mark_interactive')) dmd_agent_command_mark_interactive($agentId, 45);
    $resource = dmd_remoteagent_resource($device);
    dmd_module_event(DMD_REMOTEAGENT_MODULE_ID, 'pc.open', $resource, array(
        'email'=>$email,
        'label'=>'Ouvrir le PC',
        'target'=>$resource['name'],
        'status'=>'success',
        'details'=>'Fiche DMD-RemoteAgent ouverte.',
        'notify'=>false,
    ));
    return true;
}
