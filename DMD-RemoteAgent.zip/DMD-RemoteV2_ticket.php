<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';
require_once dirname(__DIR__, 2) . '/adm/agent/includes/remote_v2.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$email = dmd_remoteagent_email();
if ($email === '') { http_response_code(401); echo json_encode(['ok'=>false,'error'=>'not_authenticated']); exit; }
dmd_require_module_access(DMD_REMOTEAGENT_MODULE_ID, 'module.view');
$security = dmd_remoteagent_security_state($email);
if (empty($security['unlocked'])) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'mfa_locked']); exit; }
$agentId = dmd_agent_safe_agent_id((string)($_GET['agent_id'] ?? ''));
if ($agentId === '' || !dmd_remoteagent_user_can_see_device($email, $agentId) || !dmd_remoteagent_has_permission($email, $agentId, 'remote.screen')) {
    http_response_code(403); echo json_encode(['ok'=>false,'error'=>'remote_screen_denied']); exit;
}
$device = dmd_remoteagent_get_device($agentId);
if (!$device) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'agent_not_found']); exit; }
$caps = is_array($device['capabilities'] ?? null) ? $device['capabilities'] : [];
if (!in_array('remote.screen', $caps, true)) { http_response_code(403); echo json_encode(['ok'=>false,'error'=>'remote_not_enrolled']); exit; }
$permissions = ['screen'];
if (dmd_remoteagent_has_permission($email, $agentId, 'remote.control')) $permissions[] = 'control';
if (dmd_remoteagent_has_permission($email, $agentId, 'remote.clipboard')) $permissions[] = 'clipboard';
$issued = dmd_remote_v2_issue_ticket('viewer', $agentId, $permissions, 180);
if (empty($issued['ok'])) { http_response_code(503); echo json_encode($issued, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); exit; }
echo json_encode($issued, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
