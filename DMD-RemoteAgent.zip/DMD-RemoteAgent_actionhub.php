<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

function dmd_remoteagent_actionhub_operation_map() {
    return array(
        'pc.refresh'=>'pc.refresh',
        'pc.restart'=>'system.restart',
        'pc.shutdown'=>'system.shutdown',
        'agent.update'=>'agent.update',
        'process.kill'=>'processes.kill',
        'service.restart'=>'services.control',
        'terminal.run'=>'system.terminal',
    );
}

function dmd_remoteagent_actionhub_permission_for_action($actionId) {
    $map = array(
        'pc.refresh'=>'__visible__',
        'pc.restart'=>'system.restart',
        'pc.shutdown'=>'system.shutdown',
        'agent.update'=>'agent.update',
        'process.kill'=>'processes.kill',
        'service.restart'=>'services.control',
        'terminal.run'=>'system.terminal',
    );
    return isset($map[$actionId]) ? $map[$actionId] : '';
}

function dmd_remoteagent_actionhub_target_options($email, $actionId) {
    $out = array();
    $permission = dmd_remoteagent_actionhub_permission_for_action($actionId);
    foreach (dmd_remoteagent_accessible_devices($email) as $device) {
        $agentId = (string)$device['agent_id'];
        if ($permission !== '__visible__' && !dmd_remoteagent_has_permission($email, $agentId, $permission)) continue;
        $operationMap = dmd_remoteagent_actionhub_operation_map();
        $operation = isset($operationMap[$actionId]) ? $operationMap[$actionId] : '';
        $reason = '';
        if ($operation === '' || !dmd_remoteagent_operation_allowed($email, $device, $operation, $reason)) continue;
        $resource = dmd_remoteagent_resource($device);
        $label = (string)$resource['name'];
        if (!empty($device['last_ip'])) $label .= ' · ' . $device['last_ip'];
        if (empty($device['_online'])) $label .= ' · hors ligne';
        $out[] = array('value'=>$resource['id'],'label'=>$label);
    }
    return $out;
}

function dmd_remoteagent_actionhub_catalog($context) {
    if (!is_array($context)) return array('replace'=>true,'actions'=>array());
    $email = trim((string)(isset($context['email']) ? $context['email'] : ''));
    if ($email === '' || empty(dmd_remoteagent_security_state($email)['unlocked'])) return array('replace'=>true,'actions'=>array());
    $resource = isset($context['resource']) && is_array($context['resource']) ? $context['resource'] : null;
    $actions = isset($context['actions']) && is_array($context['actions']) ? $context['actions'] : array();
    $out = array();

    if ($resource) {
        $agentId = dmd_remoteagent_parse_resource_id(isset($resource['id']) ? $resource['id'] : '');
        $device = dmd_remoteagent_get_device($agentId);
        if (!$device || !dmd_remoteagent_user_can_see_device($email, $agentId)) return array('replace'=>true,'actions'=>array());
        foreach ($actions as $action) {
            if (!is_array($action)) continue;
            $actionId = trim((string)(isset($action['id']) ? $action['id'] : ''));
            $map = dmd_remoteagent_actionhub_operation_map();
            if (!isset($map[$actionId])) continue;
            $reason = '';
            if (!dmd_remoteagent_operation_allowed($email, $device, $map[$actionId], $reason)) continue;
            $dynamic = $action;
            $dynamic['scope'] = 'resource';
            $dynamic['scenario'] = false;
            $dynamic['resource_types'] = array('remoteagent_pc');
            $dynamic['inputs'] = array_values(array_filter((array)(isset($action['inputs'])?$action['inputs']:array()), function($input) {
                return is_array($input) && (string)(isset($input['id'])?$input['id']:'') !== 'target';
            }));
            $out[] = $dynamic;
        }
        return array('replace'=>true,'actions'=>$out);
    }

    foreach ($actions as $action) {
        if (!is_array($action)) continue;
        $actionId = trim((string)(isset($action['id']) ? $action['id'] : ''));
        $map = dmd_remoteagent_actionhub_operation_map();
        if (!isset($map[$actionId])) continue;
        $dynamic = $action;
        $dynamic['scope'] = 'module';
        $dynamic['scenario'] = true;
        unset($dynamic['resource_types']);
        $inputs = array(array(
            'id'=>'target',
            'label'=>'PC',
            'type'=>'select',
            'required'=>true,
            'help'=>'Seuls les PC autorisés par /adm/agent/ sont proposés.',
            'options'=>dmd_remoteagent_actionhub_target_options($email, $actionId),
        ));
        foreach ((array)(isset($action['inputs'])?$action['inputs']:array()) as $input) {
            if (is_array($input) && (string)(isset($input['id'])?$input['id']:'') !== 'target') $inputs[] = $input;
        }
        $dynamic['inputs'] = $inputs;
        $out[] = $dynamic;
    }
    return array('replace'=>true,'actions'=>$out);
}

function dmd_remoteagent_actionhub_handle($context) {
    if (!is_array($context)) return array('ok'=>false,'error'=>'invalid_context','message'=>'Contexte ActionHub invalide.');
    $email = trim((string)(isset($context['email']) ? $context['email'] : ''));
    if ($email === '' || empty(dmd_remoteagent_security_state($email)['unlocked'])) return array('ok'=>false,'error'=>'module_mfa_required','message'=>'DMD-RemoteAgent est verrouillé : ouvre le module et valide ton MFA.');
    $action = isset($context['action']) && is_array($context['action']) ? $context['action'] : array();
    $resource = isset($context['resource']) && is_array($context['resource']) ? $context['resource'] : array();
    $payload = isset($context['payload']) && is_array($context['payload']) ? $context['payload'] : array();
    $actionId = trim((string)(isset($action['id']) ? $action['id'] : ''));
    $map = dmd_remoteagent_actionhub_operation_map();
    if (!isset($map[$actionId])) return array('ok'=>false,'error'=>'unknown_action','message'=>'Action DMD-RemoteAgent inconnue.');

    $scope = strtolower(trim((string)(isset($action['scope']) ? $action['scope'] : 'resource')));
    if ($scope === 'module') {
        $resourceId = trim((string)(isset($payload['target']) ? $payload['target'] : ''));
    } else {
        $resourceId = trim((string)(isset($resource['id']) ? $resource['id'] : ''));
    }
    $agentId = dmd_remoteagent_parse_resource_id($resourceId);
    if ($agentId === '') return array('ok'=>false,'error'=>'invalid_resource','message'=>'PC DMD-RemoteAgent invalide.');

    $params = array();
    if ($actionId === 'process.kill') $params['pid'] = isset($payload['pid']) ? (int)$payload['pid'] : 0;
    if ($actionId === 'service.restart') {
        $params['name'] = trim((string)(isset($payload['service']) ? $payload['service'] : ''));
        $params['operation'] = 'restart';
    }
    if ($actionId === 'terminal.run') $params['command'] = trim((string)(isset($payload['command']) ? $payload['command'] : ''));
    if ($actionId === 'agent.update') $params['channel'] = trim((string)(isset($payload['channel']) ? $payload['channel'] : 'stable'));

    if ($actionId === 'process.kill' && $params['pid'] <= 0) return array('ok'=>false,'error'=>'pid_required','message'=>'PID invalide.');
    if ($actionId === 'service.restart' && $params['name'] === '') return array('ok'=>false,'error'=>'service_required','message'=>'Nom du service requis.');
    if ($actionId === 'terminal.run' && $params['command'] === '') return array('ok'=>false,'error'=>'command_required','message'=>'Commande terminal requise.');

    $result = dmd_remoteagent_queue_operation($email, $agentId, $map[$actionId], $params, 'actionhub');
    if (empty($result['ok'])) return array('ok'=>false,'error'=>isset($result['error'])?$result['error']:'action_failed','message'=>isset($result['message'])?$result['message']:'Action impossible.');
    return array(
        'ok'=>true,
        'message'=>$result['message'],
        'data'=>array('command'=>isset($result['command'])?$result['command']:array()),
        'event_emitted'=>true,
    );
}
