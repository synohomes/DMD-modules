(function(){
'use strict';

const boot=window.DMD_DETACHED_REMOTE||{};
const agentId=String(boot.agentId||'');
const canvas=document.getElementById('dmdDetachedImage');
const stage=document.getElementById('dmdDetachedStage');
const waiting=document.getElementById('dmdDetachedWaiting');
const status=document.getElementById('dmdDetachedStatus');
const hint=document.getElementById('dmdDetachedHint');
const screenSel=document.getElementById('dmdRemoteScreen');
const profileSel=document.getElementById('dmdStreamProfile');
const displayMode=document.getElementById('dmdDisplayMode');
const comboSel=document.getElementById('dmdKeyCombo');
const openScreenBtn=document.getElementById('dmdOpenScreen');
const openProfileBtn=document.getElementById('dmdOpenProfile');
const openDisplayBtn=document.getElementById('dmdOpenDisplay');
const openComboBtn=document.getElementById('dmdOpenCombo');
const comboBtn=document.getElementById('dmdSendCombo');
const clipboardToggle=document.getElementById('dmdClipboardToggle');
const clipboardDrawer=document.getElementById('dmdClipboardDrawer');
const clipboardText=document.getElementById('dmdClipboardText');
const clipboardRead=document.getElementById('dmdClipReadRemote');
const clipboardSend=document.getElementById('dmdClipSendRemote');
const fullscreen=document.getElementById('dmdFullscreen');
const stop=document.getElementById('dmdStop');

if(!agentId||!canvas||!stage||typeof window.DMDRemoteSession!=='function'){
  if(hint)hint.textContent='Initialisation Remote impossible.';
  return;
}

let width=0;
let height=0;
let closed=false;
let screenLoaded=false;

function setStatus(text){
  if(status)status.textContent=String(text||'');
  if(waiting&&width<=0){
    waiting.hidden=false;
    waiting.textContent=String(text||'Connexion Remote…');
  }
}

function setHint(text,error){
  if(!hint)return;
  hint.textContent=String(text||'');
  hint.style.color=error?'#ff9c9f':'';
}

function focusStage(){
  try{stage.focus({preventScroll:true});}
  catch(_){try{stage.focus();}catch(__){}}
}

function fit(){
  if(!width||!height)return;
  const one=displayMode&&displayMode.value==='1to1';
  stage.classList.toggle('pixel-1to1',!!one);
  if(one){
    canvas.style.width=width+'px';
    canvas.style.height=height+'px';
    canvas.style.maxWidth='none';
    canvas.style.maxHeight='none';
    return;
  }
  const r=stage.getBoundingClientRect();
  if(!r.width||!r.height)return;
  const scale=Math.min(r.width/width,r.height/height);
  canvas.style.width=Math.max(1,Math.floor(width*scale))+'px';
  canvas.style.height=Math.max(1,Math.floor(height*scale))+'px';
  canvas.style.maxWidth='100%';
  canvas.style.maxHeight='100%';
}

const session=new window.DMDRemoteSession({
  agentId,
  api:String(boot.api||'DMD-RemoteAgent_api.php'),
  csrf:String(boot.csrf||''),
  control:!!boot.control,
  canvas,
  onStatus:setStatus,
  onInfo(info){
    width=Number(info&&info.width||width);
    height=Number(info&&info.height||height);
    if(width>0&&height>0){
      if(waiting)waiting.hidden=true;
      setStatus(`${width}×${height} · H.264`);
      fit();
      if(!screenLoaded)loadScreens();
    }
  }
});

window.DMDDetachedRemoteSession=session;
session.bindInput(stage);
session.connect();

async function callWhenReady(op,data,tries){
  let last;
  for(let i=0;i<(tries||20);i++){
    if(closed)throw new Error('Remote fermé');
    try{return await session.call(op,data||{},4000);}
    catch(e){last=e;await new Promise(r=>setTimeout(r,150));}
  }
  throw last||new Error('Canal contrôle indisponible');
}

async function loadScreens(){
  if(!screenSel||screenLoaded)return;
  screenLoaded=true;
  screenSel.disabled=true;
  try{
    const rows=await callWhenReady('display.list',{},20);
    const list=Array.isArray(rows)?rows:(rows&&Array.isArray(rows.displays)?rows.displays:[]);
    screenSel.innerHTML='';
    if(!list.length){
      screenSel.innerHTML='<option value="">Aucun écran</option>';
      return;
    }
    list.forEach((d,i)=>{
      const o=document.createElement('option');
      const idx=Number(d.index!=null?d.index:i);
      o.value=String(idx);
      o.textContent=`Écran ${idx+1} · ${Number(d.width||0)}×${Number(d.height||0)}${d.primary?' · principal':''}`;
      screenSel.appendChild(o);
    });
    screenSel.disabled=false;
  }catch(e){
    screenSel.innerHTML='<option value="">Écran indisponible</option>';
    setHint(e&&e.message?e.message:String(e),true);
  }
}

function stopTopbarEvent(event){
  if(!event)return;
  event.preventDefault();
  event.stopPropagation();
}

function openPicker(selectEl){
  if(!selectEl)return;
  try{ if(typeof selectEl.showPicker==='function'){ selectEl.showPicker(); return; } }catch(_){ }
  try{ selectEl.focus({preventScroll:true}); }catch(_){ try{ selectEl.focus(); }catch(__){} }
  try{ selectEl.click(); }catch(_){ }
}

function bindPickerButton(button, selectEl, emptyTitle){
  if(!button||!selectEl)return;
  button.onclick=event=>{ stopTopbarEvent(event); openPicker(selectEl); };
  const sync=()=>{
    const opt=selectEl.options && selectEl.selectedIndex>=0 ? selectEl.options[selectEl.selectedIndex] : null;
    const label=(opt&&opt.textContent?opt.textContent:'').trim() || emptyTitle || '';
    if(label){
      button.title=label;
      button.setAttribute('aria-label', label);
    }
  };
  selectEl.addEventListener('change', sync);
  sync();
}

bindPickerButton(openScreenBtn, screenSel, "Choisir l'écran");
bindPickerButton(openProfileBtn, profileSel, 'Profil vidéo');
bindPickerButton(openDisplayBtn, displayMode, "Mode d'affichage");
bindPickerButton(openComboBtn, comboSel, 'Combinaison de touches');

if(screenSel){
  screenSel.onchange=async event=>{
    event.stopPropagation();
    if(screenSel.value==='')return;
    screenSel.disabled=true;
    try{
      await callWhenReady('display.select',{index:Number(screenSel.value)},20);
      await session.requestKeyframe();
      setHint('Écran distant changé.');
    }catch(e){setHint(e&&e.message?e.message:String(e),true);}
    finally{screenSel.disabled=false;}
  };
}

if(profileSel){
  profileSel.onchange=async event=>{
    event.stopPropagation();
    profileSel.disabled=true;
    try{
      const r=await callWhenReady('stream.profile',{profile:String(profileSel.value||'balanced')},20);
      if(r&&r.profile)profileSel.value=String(r.profile);
      await session.requestKeyframe();
      setHint('Profil vidéo appliqué.');
    }catch(e){setHint(e&&e.message?e.message:String(e),true);}
    finally{profileSel.disabled=false;}
  };
}

if(displayMode){
  let initial='fit';
  try{initial=localStorage.getItem('DMD-Remote:displayMode')||'fit';}catch(_){}
  displayMode.value=initial==='1to1'?'1to1':'fit';
  displayMode.onchange=event=>{
    event.stopPropagation();
    try{localStorage.setItem('DMD-Remote:displayMode',displayMode.value);}catch(_){}
    fit();
    setHint(displayMode.value==='1to1'?'Affichage 1:1.':'Affichage adapté.');
  };
}

if(comboBtn){
  comboBtn.onclick=async event=>{
    stopTopbarEvent(event);
    const name=String(comboSel&&comboSel.value||'');
    if(!name){setHint('Choisir une combinaison de touches.');return;}
    comboBtn.disabled=true;
    try{
      await callWhenReady('key.combo',{name},20);
      setHint('Combinaison envoyée.');
      if(comboSel)comboSel.value='';
      focusStage();
    }catch(e){setHint(e&&e.message?e.message:String(e),true);}
    finally{comboBtn.disabled=false;}
  };
}

function setClipboardOpen(open){
  if(!clipboardDrawer)return;
  clipboardDrawer.hidden=!open;
  clipboardDrawer.style.setProperty('display',open?'flex':'none','important');
  if(clipboardToggle)clipboardToggle.setAttribute('aria-expanded',open?'true':'false');
  setHint(open?'Presse-papiers ouvert.':'Presse-papiers fermé.');
}

if(clipboardDrawer)setClipboardOpen(false);

if(clipboardToggle){
  clipboardToggle.onclick=event=>{
    stopTopbarEvent(event);
    const open=clipboardDrawer ? (clipboardDrawer.hidden || getComputedStyle(clipboardDrawer).display==='none') : false;
    setClipboardOpen(open);
  };
}

if(clipboardRead){
  clipboardRead.onclick=async event=>{
    stopTopbarEvent(event);
    clipboardRead.disabled=true;
    try{
      const r=await callWhenReady('clipboard.read',{},20);
      if(clipboardText)clipboardText.value=String(r&&r.text!=null?r.text:r||'');
      setHint('Presse-papiers distant chargé.');
    }catch(e){setHint(e&&e.message?e.message:String(e),true);}
    finally{clipboardRead.disabled=false;}
  };
}

if(clipboardSend){
  clipboardSend.onclick=async event=>{
    stopTopbarEvent(event);
    clipboardSend.disabled=true;
    try{
      await callWhenReady('clipboard.write',{text:String(clipboardText&&clipboardText.value||'')},20);
      setHint('Presse-papiers envoyé au PC distant.');
    }catch(e){setHint(e&&e.message?e.message:String(e),true);}
    finally{clipboardSend.disabled=false;}
  };
}

if(fullscreen){
  fullscreen.onclick=async event=>{
    stopTopbarEvent(event);
    try{
      if(document.fullscreenElement)await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    }catch(e){setHint(e&&e.message?e.message:String(e),true);}
  };
}

document.addEventListener('fullscreenchange',()=>{
  if(fullscreen){ fullscreen.title=document.fullscreenElement?'Quitter le plein écran':'Plein écran'; fullscreen.setAttribute('aria-label', fullscreen.title); }
  setTimeout(fit,0);
});

function shutdown(closeWindow){
  if(closed)return;
  closed=true;
  try{session.close();}catch(_){}
  if(waiting){waiting.hidden=false;waiting.textContent='Session Remote arrêtée.';}
  setHint('Session Remote arrêtée.');
  if(closeWindow)setTimeout(()=>{try{window.close();}catch(_){}},60);
}

if(stop){
  stop.onclick=event=>{
    stopTopbarEvent(event);
    shutdown(true);
  };
}

window.addEventListener('resize',fit);
window.addEventListener('pagehide',()=>shutdown(false),{once:true});
focusStage();
})();
