<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$email = dmd_remoteagent_email();
if ($email === '') { echo '<div class="dmd-ra-error">Non connecté.</div>'; return; }
dmd_require_module_access(DMD_REMOTEAGENT_MODULE_ID, 'module.view');
$csrf = dmd_csrf_token('dmd_remoteagent');
$securityState = dmd_remoteagent_security_state($email);
$devices = !empty($securityState['unlocked']) ? dmd_remoteagent_accessible_devices($email) : array();
$isSuperadmin = dmd_remoteagent_is_superadmin($email);

$state = array();
$onlineCount = 0;
foreach ($devices as $device) {
    $row = dmd_remoteagent_state_device($device);
    if (!empty($row['online'])) $onlineCount++;
    $state[] = $row;
}
$initialJson = json_encode($state, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
?>
<?php $dmdRemoteAgentCssRev = (string)(@filemtime(__DIR__ . '/DMD-RemoteAgent.css') ?: '1.0.35'); ?>
<link rel="stylesheet" href="modules/DMD-RemoteAgent/DMD-RemoteAgent.css?v=<?= rawurlencode($dmdRemoteAgentCssRev) ?>">
<div class="dmd-ra-app<?= empty($securityState['unlocked']) ? ' dmd-ra-is-locked' : '' ?>" id="dmdRemoteAgentApp" data-dmd-module="DMD-RemoteAgent">
    <div class="dmd-ra-security-gate" id="dmdRaSecurityGate" <?= !empty($securityState['unlocked']) ? 'hidden' : '' ?>>
        <div class="dmd-ra-security-card">
            <div class="dmd-ra-security-icon">🔐</div>
            <strong>DMD-RemoteAgent verrouillé</strong>
            <p id="dmdRaSecurityMessage">
                <?php if (($securityState['blocked_reason'] ?? '') === 'mfa_not_configured'): ?>Active le MFA dans ton profil avant d’utiliser ce module.
                <?php elseif (($securityState['blocked_reason'] ?? '') === 'mfa_disabled_by_policy'): ?>Le MFA est désactivé pour ce compte par la politique DoMyDesk.
                <?php elseif (($securityState['blocked_reason'] ?? '') === 'mfa_unavailable'): ?>Le moteur MFA central DoMyDesk est indisponible.
                <?php else: ?>Saisis ton code Microsoft Authenticator pour déverrouiller le module.<?php endif; ?>
            </p>
            <form id="dmdRaMfaForm" autocomplete="off" <?= empty($securityState['account_mfa']) ? 'hidden' : '' ?>>
                <input id="dmdRaMfaCode" inputmode="numeric" autocomplete="one-time-code" placeholder="Code MFA ou code de secours" required>
                <button type="submit">Déverrouiller</button>
            </form>
            <a id="dmdRaMfaSetupLink" href="profile_edit.php" target="_top" <?= (($securityState['blocked_reason'] ?? '') === 'mfa_not_configured') ? '' : 'hidden' ?>>Configurer le MFA dans mon profil</a>
            <small id="dmdRaSecurityError"></small>
        </div>
    </div>
    <div class="dmd-ra-topbar">
        <div class="dmd-ra-stats" aria-label="État DMD-RemoteAgent">
            <span><i class="dmd-ra-dot online"></i><strong id="dmdRaOnlineCount"><?= (int)$onlineCount ?></strong> en ligne</span>
            <span><i class="dmd-ra-dot"></i><strong id="dmdRaTotalCount"><?= count($state) ?></strong> autorisés</span>
        </div>
        <div class="dmd-ra-tools">
            <input id="dmdRaSearch" type="search" placeholder="Rechercher un PC…" autocomplete="off">
            <select id="dmdRaStatusFilter" aria-label="Filtrer les PC"><option value="all">Tous</option><option value="online">En ligne</option><option value="offline">Hors ligne</option></select>
            <span class="dmd-ra-security-countdown" id="dmdRaSecurityCountdown" <?= empty($securityState['enabled']) || empty($securityState['unlocked']) ? 'hidden' : '' ?>></span>
            <?php if ($isSuperadmin): ?><a class="dmd-ra-gear" href="adm/agent/" target="_top" title="Administration DMD-Agent" aria-label="Administration DMD-Agent">⚙</a><?php endif; ?>
        </div>
    </div>

    <div class="dmd-ra-list" id="dmdRaList"></div>
    <div class="dmd-ra-empty" id="dmdRaEmpty" hidden>
        <strong>Aucun PC disponible</strong>
        <span><?= $isSuperadmin ? 'Les enrôlements et droits se gèrent avec l’engrenage.' : 'Aucun PC ne t’est actuellement attribué dans l’administration DMD-Agent.' ?></span>
    </div>
</div>

<div class="dmd-ra-modal dmd-popup-overlay" id="dmdRaModal" hidden>
    <div class="dmd-ra-window" role="dialog" aria-modal="false" aria-labelledby="dmdRaTitle">
        <header class="dmd-ra-window-head">
            <button type="button" class="dmd-ra-drag-handle" id="dmdRaDragHandle" aria-label="Déplacer la fenêtre" title="Déplacer">⠿</button>
            <div class="dmd-ra-title-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24"><path d="M4 5.5h16v10H4zM8.5 19h7M12 15.5V19" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
            <div class="dmd-ra-title">
                <div class="dmd-ra-title-row">
                    <h2 id="dmdRaTitle">PC</h2>
                    <span id="dmdRaStateLine">—</span>
                </div>
                <small id="dmdRaSub">—</small>
            </div>
            <button type="button" class="dmd-ra-close" id="dmdRaClose" aria-label="Fermer" title="Fermer">×</button>
        </header>
        <div class="dmd-ra-navline">
            <nav class="dmd-ra-tabs" id="dmdRaTabs">
                <button type="button" data-tab="overview" class="active">Rapport</button>
                <div class="dmd-ra-tab-menu" id="dmdRaRemoteMenu" data-perm-any="remote.screen,remote.control">
                    <button type="button" class="dmd-ra-remote-trigger" id="dmdRaRemoteMenuTrigger" aria-haspopup="true" aria-expanded="false">Remote</button>
                    <div class="dmd-ra-remote-menu" id="dmdRaRemoteMenuPopup" hidden>
                        <button type="button" data-operation="remote.screen" data-perm="remote.screen"><span class="dmd-ra-menu-icon">◉</span><span><strong>Voir</strong><small>Ouvrir l’écran distant</small></span></button>
                        <button type="button" data-operation="remote.control" data-perm="remote.control"><span class="dmd-ra-menu-icon">⌁</span><span><strong>Contrôle</strong><small>Clavier et souris actifs</small></span></button>
                    </div>
                </div>
                <button type="button" data-tab="files" data-perm-any="files.browse,files.download,files.upload,files.mkdir,files.delete,files.rename">Fichiers</button>
                <button type="button" data-tab="registry" data-perm-any="registry.read,registry.write">Registre</button>
                <button type="button" data-tab="devices" data-perm-any="devices.manage,network.manage">USB / Réseau</button>
                <button type="button" data-tab="software" data-perm-any="software.view,software.uninstall,software.update">Logiciels</button>
                <button type="button" data-tab="processes" data-perm-any="processes.view,processes.kill">Processus</button>
                <button type="button" data-tab="services" data-perm-any="services.view,services.control">Services</button>
                <button type="button" data-tab="terminal" data-perm-any="system.terminal">Terminal</button>
                <button type="button" data-tab="power" data-perm-any="system.restart,system.shutdown,agent.update">Système</button>
                <button type="button" data-tab="history">Historique</button>
            </nav>
            <div class="dmd-ra-nav-sep" aria-hidden="true"></div>
            <div class="dmd-ra-context-actions" id="dmdRaContextActions">
                <div class="dmd-ra-context-group" data-actions-pane="overview">
                    <button type="button" data-operation="pc.refresh" title="Actualiser le rapport">↻</button>
                </div>


                <div class="dmd-ra-context-group" data-actions-pane="registry" hidden>
                    <button type="button" id="dmdRaRegistryRefresh" data-perm="registry.read">↻ Registre</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="devices" hidden>
                    <button type="button" id="dmdRaDevicesRefresh" data-perm-any="devices.manage,network.manage">↻ Périphériques</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="software" hidden>
                    <button type="button" id="dmdRaSoftwareRefresh" data-perm="software.view">↻</button>
                    <button type="button" id="dmdRaSoftwareUpdatesScan" data-perm="software.update">Mises à jour</button>
                    <button type="button" id="dmdRaSoftwareUpdatesApply" data-perm="software.update">Tout mettre à jour</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="processes" hidden>
                    <button type="button" data-operation="processes.list" data-perm="processes.view">↻ Processus</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="services" hidden>
                    <button type="button" data-operation="services.list" data-perm="services.view">↻ Services</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="terminal" hidden>
                    <button type="button" id="dmdRaTerminalClearNav" title="Effacer la console">Effacer</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="power" hidden>
                    <button type="button" data-operation="pc.refresh">↻ Rapport</button>
                    <button type="button" data-operation="agent.update" data-perm="agent.update">MAJ Agent</button>
                    <button type="button" class="warning" data-operation="system.restart" data-perm="system.restart" data-confirm="Redémarrer ce PC ?">Redémarrer</button>
                    <button type="button" class="danger" data-operation="system.shutdown" data-perm="system.shutdown" data-confirm="Éteindre ce PC ?">Éteindre</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="history" hidden>
                    <button type="button" id="dmdRaHistoryRefresh" title="Actualiser l’historique">↻</button>
                </div>
                <span class="dmd-ra-mini-status" id="dmdRaCommandStatus">Prêt.</span>
                <button type="button" class="dmd-ra-mini-refresh" id="dmdRaRefreshState" title="Actualiser l’état">↻</button>
            </div>
        </div>
        <div class="dmd-ra-window-body">
            <section class="dmd-ra-pane active" data-pane="overview"><div id="dmdRaOverview"></div></section>
            <section class="dmd-ra-pane dmd-ra-remote-pane" data-pane="remote" hidden>
                <div class="dmd-ra-remote-stage" id="dmdRaRemoteStage" tabindex="0"><span>Aucune session Remote active.</span></div>
                <div class="dmd-ra-clipboard-panel" id="dmdRaClipboardPanel" hidden data-perm="remote.clipboard">
                    <textarea id="dmdRaClipboard" rows="2" placeholder="Presse-papiers distant…"></textarea>
                    <button type="button" data-operation="remote.clipboard.get" title="Lire le presse-papiers distant">Lire</button>
                    <button type="button" id="dmdRaClipboardSend" title="Envoyer vers le PC">Envoyer</button>
                </div>
            </section>
            <section class="dmd-ra-pane dmd-ra-files-pane" data-pane="files" hidden>
                <div class="dmd-ra-files-toolbar">
                    <button type="button" id="dmdRaRoots" class="dmd-ra-icon-action" data-perm="files.browse" title="Afficher les lecteurs" aria-label="Afficher les lecteurs">⌂</button>
                    <input id="dmdRaPath" type="text" placeholder="Chemin distant…" autocomplete="off" spellcheck="false">
                    <button type="button" id="dmdRaBrowse" data-perm="files.browse">Ouvrir</button>
                    <span class="dmd-ra-files-sep" aria-hidden="true"></span>
                    <button type="button" id="dmdRaMkdir" data-perm="files.mkdir">Nouveau dossier</button>
                    <button type="button" id="dmdRaUpload" data-perm="files.upload">Envoyer fichier</button>
                    <button type="button" id="dmdRaUploadFolder" data-perm="files.upload">Envoyer dossier</button>
                    <input id="dmdRaUploadInput" type="file" hidden>
                    <input id="dmdRaUploadFolderInput" type="file" webkitdirectory multiple hidden>
                </div>
                <div class="dmd-ra-file-transfer" id="dmdRaFileTransfer" hidden></div>
                <div class="dmd-ra-result dmd-ra-file-browser" id="dmdRaFilesResult"><div class="dmd-ra-loading-line">Chargement des lecteurs…</div></div>
            </section>
            <section class="dmd-ra-pane" data-pane="registry" hidden>
                <div class="dmd-ra-adminbar">
                    <select id="dmdRaRegistryHive" aria-label="Ruche"><option>HKLM</option><option>HKCU</option><option>HKU</option><option>HKCR</option><option>HKCC</option></select>
                    <input id="dmdRaRegistryPath" type="text" placeholder="SOFTWARE\Microsoft\Windows" autocomplete="off">
                    <button type="button" id="dmdRaRegistryOpen">Ouvrir</button>
                </div>
                <div class="dmd-ra-result" id="dmdRaRegistryResult">Saisis une clé ou ouvre la racine.</div>
                <div class="dmd-ra-adminbar dmd-ra-regeditbar" data-perm="registry.write">
                    <input id="dmdRaRegistryName" type="text" placeholder="Nom de la valeur (vide = défaut)">
                    <select id="dmdRaRegistryType"><option value="string">REG_SZ</option><option value="expandstring">REG_EXPAND_SZ</option><option value="dword">REG_DWORD</option><option value="qword">REG_QWORD</option><option value="multistring">REG_MULTI_SZ</option><option value="binary">REG_BINARY (base64)</option></select>
                    <input id="dmdRaRegistryValue" type="text" placeholder="Valeur">
                    <button type="button" id="dmdRaRegistrySave">Enregistrer</button>
                    <button type="button" class="danger" id="dmdRaRegistryDeleteValue">Supprimer valeur</button>
                </div>
            </section>
            <section class="dmd-ra-pane" data-pane="devices" hidden>
                <div class="dmd-ra-section-title"><strong>Supports amovibles / USB / lecteurs</strong></div>
                <div class="dmd-ra-result" id="dmdRaRemovableResult">Aucune liste chargée.</div>
                <div class="dmd-ra-section-title"><strong>Chemins réseau SMB</strong></div>
                <div class="dmd-ra-adminbar" data-perm="network.manage"><input id="dmdRaNetworkLetter" type="text" maxlength="2" placeholder="Z:"><input id="dmdRaNetworkPath" type="text" placeholder="\\serveur\partage"><button type="button" id="dmdRaNetworkAdd">Ajouter</button></div>
                <div class="dmd-ra-result" id="dmdRaNetworkResult">Aucun chemin chargé.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="software" hidden>
                <div class="dmd-ra-softwarebar"><input id="dmdRaSoftwareSearch" type="search" placeholder="Rechercher un logiciel…" autocomplete="off"></div>
                <pre class="dmd-ra-result" id="dmdRaSoftwareUpdatesResult" hidden></pre>
                <div class="dmd-ra-result" id="dmdRaSoftwareResult">Aucune liste chargée.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="processes" hidden>
                <div class="dmd-ra-result" id="dmdRaProcessesResult">Aucun processus chargé.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="services" hidden>
                <div class="dmd-ra-result" id="dmdRaServicesResult">Aucun service chargé.</div>
            </section>
            <section class="dmd-ra-pane dmd-ra-terminal-pane" data-pane="terminal" hidden>
                <div class="dmd-ra-terminal-shell">
                    <div class="dmd-ra-terminal-toolbar">
                        <div class="dmd-ra-terminal-ident">
                            <span class="dmd-ra-terminal-dot" aria-hidden="true"></span>
                            <strong id="dmdRaTerminalTitle">PowerShell</strong>
                            <small>SYSTEM · <?= dmd_remoteagent_h($hostname) ?></small>
                        </div>
                        <div class="dmd-ra-terminal-tools">
                            <select id="dmdRaTerminalShell" aria-label="Shell" title="Shell distant">
                                <option value="powershell">PowerShell</option>
                                <option value="cmd">CMD</option>
                            </select>
                            <button type="button" id="dmdRaTerminalClear" title="Effacer la console" aria-label="Effacer la console">Effacer</button>
                        </div>
                    </div>
                    <pre id="dmdRaTerminalOutput" class="dmd-ra-terminal-output" tabindex="0" aria-live="polite"></pre>
                    <div class="dmd-ra-terminal-commandbar">
                        <span class="dmd-ra-terminal-prompt" id="dmdRaTerminalPrompt">PS&gt;</span>
                        <input id="dmdRaTerminalInput" type="text" placeholder="Saisir une commande…" autocomplete="off" autocapitalize="off" spellcheck="false">
                        <button type="button" id="dmdRaTerminalRun" title="Exécuter (Entrée)" aria-label="Exécuter">↵</button>
                    </div>
                </div>
            </section>
            <section class="dmd-ra-pane" data-pane="power" hidden>
                <div class="dmd-ra-result" id="dmdRaSystemResult">Les actions système respectent les droits définis dans /adm/agent/.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="history" hidden><div class="dmd-ra-result" id="dmdRaHistoryResult">Chargement…</div></section>
        </div>

    </div>
</div>

<script>
window.DMD_REMOTEAGENT_BOOT = {
  csrf: <?= json_encode($csrf) ?>,
  devices: <?= $initialJson ?: '[]' ?>,
  isSuperadmin: <?= $isSuperadmin ? 'true' : 'false' ?>,
  security: <?= json_encode($securityState, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>,
  api: 'modules/DMD-RemoteAgent/DMD-RemoteAgent_api.php',
  detached: 'modules/DMD-RemoteAgent/DMD-RemoteAgent_detached.php'
};
</script>
<?php $dmdRemoteCoreRev = (string)(@filemtime(__DIR__ . '/DMDRemote.js') ?: '1.0.35'); ?>
<script src="modules/DMD-RemoteAgent/DMDRemote.js?v=<?= rawurlencode($dmdRemoteCoreRev) ?>"></script>
<?php $dmdRemoteAgentUiRev = (string)(@filemtime(__DIR__ . '/DMD-RemoteAgent.js') ?: '1.0.35'); ?>
<script src="modules/DMD-RemoteAgent/DMD-RemoteAgent.js?v=<?= rawurlencode($dmdRemoteAgentUiRev) ?>"></script>
