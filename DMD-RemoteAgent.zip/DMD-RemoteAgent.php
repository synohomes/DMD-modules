<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$email = dmd_remoteagent_email();
if ($email === '') { echo '<div class="dmd-ra-error">Non connecté.</div>'; return; }
dmd_require_module_access(DMD_REMOTEAGENT_MODULE_ID, 'use');
$csrf = dmd_csrf_token('dmd_remoteagent');
$securityState = dmd_remoteagent_security_state($email);
$devices = !empty($securityState['unlocked']) ? dmd_remoteagent_accessible_devices($email) : array();
$isSuperadmin = dmd_remoteagent_is_superadmin($email);

$state = array();
$onlineCount = 0;
foreach ($devices as $device) {
    $row = dmd_remoteagent_state_device($device);
    if (!empty($row['online'])) $onlineCount++;
    $state[] = $row;
}
$initialJson = json_encode($state, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
?>
<link rel="stylesheet" href="modules/DMD-RemoteAgent/DMD-RemoteAgent.css?v=1.0.34">
<div class="dmd-ra-app<?= empty($securityState['unlocked']) ? ' dmd-ra-is-locked' : '' ?>" id="dmdRemoteAgentApp" data-dmd-module="DMD-RemoteAgent">
    <div class="dmd-ra-security-gate" id="dmdRaSecurityGate" <?= !empty($securityState['unlocked']) ? 'hidden' : '' ?>>
        <div class="dmd-ra-security-card">
            <div class="dmd-ra-security-icon">🔐</div>
            <strong>DMD-RemoteAgent verrouillé</strong>
            <p id="dmdRaSecurityMessage">
                <?php if (($securityState['blocked_reason'] ?? '') === 'mfa_not_configured'): ?>Active le MFA dans ton profil avant d’utiliser ce module.
                <?php elseif (($securityState['blocked_reason'] ?? '') === 'mfa_disabled_by_policy'): ?>Le MFA est désactivé pour ce compte par la politique DoMyDesk.
                <?php elseif (($securityState['blocked_reason'] ?? '') === 'mfa_unavailable'): ?>Le moteur MFA central DoMyDesk est indisponible.
                <?php else: ?>Saisis ton code Microsoft Authenticator pour déverrouiller le module.<?php endif; ?>
            </p>
            <form id="dmdRaMfaForm" autocomplete="off" <?= empty($securityState['account_mfa']) ? 'hidden' : '' ?>>
                <input id="dmdRaMfaCode" inputmode="numeric" autocomplete="one-time-code" placeholder="Code MFA ou code de secours" required>
                <button type="submit">Déverrouiller</button>
            </form>
            <a id="dmdRaMfaSetupLink" href="profile_edit.php" target="_top" <?= (($securityState['blocked_reason'] ?? '') === 'mfa_not_configured') ? '' : 'hidden' ?>>Configurer le MFA dans mon profil</a>
            <small id="dmdRaSecurityError"></small>
        </div>
    </div>
    <div class="dmd-ra-topbar">
        <div class="dmd-ra-stats" aria-label="État DMD-RemoteAgent">
            <span><i class="dmd-ra-dot online"></i><strong id="dmdRaOnlineCount"><?= (int)$onlineCount ?></strong> en ligne</span>
            <span><i class="dmd-ra-dot"></i><strong id="dmdRaTotalCount"><?= count($state) ?></strong> autorisés</span>
        </div>
        <div class="dmd-ra-tools">
            <input id="dmdRaSearch" type="search" placeholder="Rechercher un PC…" autocomplete="off">
            <select id="dmdRaStatusFilter" aria-label="Filtrer les PC"><option value="all">Tous</option><option value="online">En ligne</option><option value="offline">Hors ligne</option></select>
            <span class="dmd-ra-security-countdown" id="dmdRaSecurityCountdown" <?= empty($securityState['enabled']) || empty($securityState['unlocked']) ? 'hidden' : '' ?>></span>
            <?php if ($isSuperadmin): ?><a class="dmd-ra-gear" href="adm/agent/" target="_top" title="Administration DMD-Agent" aria-label="Administration DMD-Agent">⚙</a><?php endif; ?>
        </div>
    </div>

    <div class="dmd-ra-list" id="dmdRaList"></div>
    <div class="dmd-ra-empty" id="dmdRaEmpty" hidden>
        <strong>Aucun PC disponible</strong>
        <span><?= $isSuperadmin ? 'Les enrôlements et droits se gèrent avec l’engrenage.' : 'Aucun PC ne t’est actuellement attribué dans l’administration DMD-Agent.' ?></span>
    </div>
</div>

<div class="dmd-ra-modal dmd-popup-overlay" id="dmdRaModal" hidden>
    <div class="dmd-ra-window" role="dialog" aria-modal="true" aria-labelledby="dmdRaTitle">
        <header class="dmd-ra-window-head">
            <button type="button" class="dmd-ra-drag-handle" id="dmdRaDragHandle" aria-label="Déplacer la fenêtre" title="Déplacer">⠿</button>
            <div class="dmd-ra-title">
                <span id="dmdRaStateLine">—</span>
                <h2 id="dmdRaTitle">PC</h2>
                <small id="dmdRaSub">—</small>
            </div>
            <button type="button" class="dmd-ra-close" id="dmdRaClose" aria-label="Fermer" title="Fermer">×</button>
        </header>
        <div class="dmd-ra-navline">
            <nav class="dmd-ra-tabs" id="dmdRaTabs">
                <button type="button" data-tab="overview" class="active">Rapport</button>
                <button type="button" data-tab="remote" data-perm-any="remote.screen,remote.control,remote.clipboard">Remote</button>
                <button type="button" data-tab="files" data-perm-any="files.browse,files.download,files.upload,files.mkdir,files.delete,files.rename">Fichiers</button>
                <button type="button" data-tab="software" data-perm-any="software.view,software.uninstall">Logiciels</button>
                <button type="button" data-tab="processes" data-perm-any="processes.view,processes.kill">Processus</button>
                <button type="button" data-tab="services" data-perm-any="services.view,services.control">Services</button>
                <button type="button" data-tab="terminal" data-perm-any="system.terminal">Terminal</button>
                <button type="button" data-tab="power" data-perm-any="system.restart,system.shutdown,agent.update">Système</button>
                <button type="button" data-tab="history">Historique</button>
            </nav>
            <div class="dmd-ra-nav-sep" aria-hidden="true"></div>
            <div class="dmd-ra-context-actions" id="dmdRaContextActions">
                <div class="dmd-ra-context-group" data-actions-pane="overview">
                    <button type="button" data-operation="pc.refresh" title="Actualiser le rapport">↻</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="remote" hidden>
                    <button type="button" data-operation="remote.screen" data-perm="remote.screen">Voir</button>
                    <button type="button" data-operation="remote.control" data-perm="remote.control">Contrôle</button>
                    <button type="button" data-operation="remote.stop" data-perm="remote.screen">Stop</button>
                    <button type="button" id="dmdRaClipboardToggle" data-perm="remote.clipboard">Presse-papiers</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="files" hidden>
                    <button type="button" id="dmdRaRoots" data-perm="files.browse">Racines</button>
                    <button type="button" id="dmdRaBrowse" data-perm="files.browse">Ouvrir</button>
                    <button type="button" id="dmdRaMkdir" data-perm="files.mkdir">Nouveau dossier</button>
                    <button type="button" id="dmdRaUpload" data-perm="files.upload">Envoyer</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="software" hidden>
                    <button type="button" id="dmdRaSoftwareRefresh" data-perm="software.view">↻</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="processes" hidden>
                    <button type="button" data-operation="processes.list" data-perm="processes.view">↻ Processus</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="services" hidden>
                    <button type="button" data-operation="services.list" data-perm="services.view">↻ Services</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="terminal" hidden>
                    <button type="button" id="dmdRaTerminalRun">Exécuter</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="power" hidden>
                    <button type="button" data-operation="pc.refresh">↻ Rapport</button>
                    <button type="button" data-operation="agent.update" data-perm="agent.update">MAJ Agent</button>
                    <button type="button" class="warning" data-operation="system.restart" data-perm="system.restart" data-confirm="Redémarrer ce PC ?">Redémarrer</button>
                    <button type="button" class="danger" data-operation="system.shutdown" data-perm="system.shutdown" data-confirm="Éteindre ce PC ?">Éteindre</button>
                </div>
                <div class="dmd-ra-context-group" data-actions-pane="history" hidden>
                    <button type="button" id="dmdRaHistoryRefresh" title="Actualiser l’historique">↻</button>
                </div>
                <span class="dmd-ra-mini-status" id="dmdRaCommandStatus">Prêt.</span>
                <button type="button" class="dmd-ra-mini-refresh" id="dmdRaRefreshState" title="Actualiser l’état">↻</button>
            </div>
        </div>
        <div class="dmd-ra-window-body">
            <section class="dmd-ra-pane active" data-pane="overview"><div id="dmdRaOverview"></div></section>
            <section class="dmd-ra-pane dmd-ra-remote-pane" data-pane="remote" hidden>
                <div class="dmd-ra-remote-stage" id="dmdRaRemoteStage" tabindex="0"><span>Aucune session Remote active.</span></div>
                <div class="dmd-ra-clipboard-panel" id="dmdRaClipboardPanel" hidden data-perm="remote.clipboard">
                    <textarea id="dmdRaClipboard" rows="2" placeholder="Presse-papiers distant…"></textarea>
                    <button type="button" data-operation="remote.clipboard.get" title="Lire le presse-papiers distant">Lire</button>
                    <button type="button" id="dmdRaClipboardSend" title="Envoyer vers le PC">Envoyer</button>
                </div>
            </section>
            <section class="dmd-ra-pane" data-pane="files" hidden>
                <div class="dmd-ra-filebar"><input id="dmdRaPath" type="text" placeholder="C:\\"><input id="dmdRaUploadInput" type="file" hidden></div>
                <div class="dmd-ra-file-transfer" id="dmdRaFileTransfer" hidden></div>
                <div class="dmd-ra-result" id="dmdRaFilesResult">Sélectionne une racine ou saisis un chemin.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="software" hidden>
                <div class="dmd-ra-softwarebar"><input id="dmdRaSoftwareSearch" type="search" placeholder="Rechercher un logiciel…" autocomplete="off"></div>
                <div class="dmd-ra-result" id="dmdRaSoftwareResult">Aucune liste chargée.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="processes" hidden>
                <div class="dmd-ra-result" id="dmdRaProcessesResult">Aucun processus chargé.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="services" hidden>
                <div class="dmd-ra-result" id="dmdRaServicesResult">Aucun service chargé.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="terminal" hidden>
                <div class="dmd-ra-terminal"><pre id="dmdRaTerminalOutput">DMD-RemoteAgent — terminal distant
Les commandes sont exécutées par le service DMD-Agent avec les droits SYSTEM.</pre><div class="dmd-ra-terminal-commandbar"><input id="dmdRaTerminalInput" type="text" placeholder="Commande à exécuter"><select id="dmdRaTerminalShell" aria-label="Shell"><option value="powershell">PowerShell</option><option value="cmd">CMD</option></select></div></div>
            </section>
            <section class="dmd-ra-pane" data-pane="power" hidden>
                <div class="dmd-ra-result" id="dmdRaSystemResult">Les actions système respectent les droits définis dans /adm/agent/.</div>
            </section>
            <section class="dmd-ra-pane" data-pane="history" hidden><div class="dmd-ra-result" id="dmdRaHistoryResult">Chargement…</div></section>
        </div>

    </div>
</div>

<script>
window.DMD_REMOTEAGENT_BOOT = {
  csrf: <?= json_encode($csrf) ?>,
  devices: <?= $initialJson ?: '[]' ?>,
  isSuperadmin: <?= $isSuperadmin ? 'true' : 'false' ?>,
  security: <?= json_encode($securityState, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>,
  api: 'modules/DMD-RemoteAgent/DMD-RemoteAgent_api.php',
  detached: 'modules/DMD-RemoteAgent/DMD-RemoteAgent_detached.php'
};
</script>
<script src="modules/DMD-RemoteAgent/DMD-RemoteAgent.js?v=1.0.34"></script>
