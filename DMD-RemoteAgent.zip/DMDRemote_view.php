<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/DMD-RemoteAgent_lib.php';

$viewerEmail = dmd_remoteagent_email();
if ($viewerEmail === '') { http_response_code(401); exit('Session DoMyDesk requise.'); }
dmd_require_module_access(DMD_REMOTEAGENT_MODULE_ID, 'module.view');
$viewerSecurity = dmd_remoteagent_security_state($viewerEmail);
if (empty($viewerSecurity['unlocked'])) { http_response_code(403); exit('MFA DMD-RemoteAgent requis.'); }
$viewerAgentId = dmd_agent_safe_agent_id((string)($_GET['agent_id'] ?? ''));
if ($viewerAgentId === '' || !dmd_remoteagent_user_can_see_device($viewerEmail, $viewerAgentId) || !dmd_remoteagent_has_permission($viewerEmail, $viewerAgentId, 'remote.screen')) {
    http_response_code(403); exit('Accès écran distant refusé.');
}
$viewerDevice = dmd_remoteagent_get_device($viewerAgentId);
if (!$viewerDevice) { http_response_code(404); exit('PC introuvable.'); }
$viewerControl = !empty($_GET['control']) && dmd_remoteagent_has_permission($viewerEmail, $viewerAgentId, 'remote.control');
$viewerClipboard = dmd_remoteagent_has_permission($viewerEmail, $viewerAgentId, 'remote.clipboard');
$viewerDetached = !empty($DMD_REMOTE_DETACHED);
$viewerHost = trim((string)($viewerDevice['hostname'] ?? 'PC')) ?: 'PC';
$viewerIP = trim((string)($viewerDevice['last_ip'] ?? ''));
$viewerId = 'dmd-remote-' . bin2hex(random_bytes(5));
$viewerModuleWeb = '';
$viewerDocRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? ''));
$viewerModuleDir = realpath(__DIR__);
if (is_string($viewerDocRoot) && $viewerDocRoot !== '' && is_string($viewerModuleDir) && str_starts_with($viewerModuleDir, rtrim($viewerDocRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR)) {
    $viewerModuleWeb = '/' . str_replace(DIRECTORY_SEPARATOR, '/', ltrim(substr($viewerModuleDir, strlen(rtrim($viewerDocRoot, DIRECTORY_SEPARATOR))), DIRECTORY_SEPARATOR));
}
if ($viewerModuleWeb === '') $viewerModuleWeb = '/domydesk/modules/DMD-RemoteAgent';
$viewerTicketURL = rtrim($viewerModuleWeb, '/') . '/DMD-RemoteAgent_ticket.php';
$viewerDetachURL = rtrim($viewerModuleWeb, '/') . '/DMD-RemoteAgent_detached.php';
?>
<div class="dmd-remote" id="<?= htmlspecialchars($viewerId, ENT_QUOTES, 'UTF-8') ?>">
  <div class="dmd-remote-bar">
    <div class="dmd-remote-ident"><i class="dmd-remote-dot"></i><strong><?= htmlspecialchars($viewerHost, ENT_QUOTES, 'UTF-8') ?></strong><?php if ($viewerIP !== ''): ?><small><?= htmlspecialchars($viewerIP, ENT_QUOTES, 'UTF-8') ?></small><?php endif; ?></div>
    <div class="dmd-remote-actions">
      <select data-remote-display aria-label="Écran distant"><option value="">Écran…</option></select>
      <select data-remote-profile aria-label="Qualité vidéo"><option value="balanced">1366 max</option><option value="low">1024 max</option><option value="quality">1920 max</option><option value="native">Natif</option></select>
      <select data-remote-fit aria-label="Mode d'affichage"><option value="fit">Adapter</option><option value="native">1:1</option></select>
      <?php if ($viewerControl): ?><select data-remote-combo aria-label="Combinaison clavier"><option value="">Touches…</option><option value="ctrl_alt_end">Ctrl+Alt+Fin</option><option value="ctrl_shift_esc">Ctrl+Maj+Échap</option><option value="alt_tab">Alt+Tab</option><option value="alt_f4">Alt+F4</option><option value="win_r">Win+R</option><option value="win_l">Win+L</option><option value="ctrl_c">Ctrl+C</option><option value="ctrl_v">Ctrl+V</option><option value="ctrl_x">Ctrl+X</option><option value="ctrl_a">Ctrl+A</option></select><button type="button" data-remote-combo-send>Envoyer</button><?php endif; ?>
      <?php if ($viewerClipboard): ?><button type="button" data-remote-clipboard-open>Presse-papiers</button><?php endif; ?>
      <button type="button" data-remote-fullscreen>Plein écran</button>
      <?php if (!$viewerDetached): ?><button type="button" data-remote-detach title="Détacher dans une fenêtre indépendante" aria-label="Détacher">↗</button><?php endif; ?>
      <?php if ($viewerDetached): ?><button type="button" class="danger" data-remote-close>Fermer</button><?php endif; ?>
    </div>
  </div>
  <?php if ($viewerClipboard): ?><div class="dmd-remote-clipboard" data-remote-clipboard hidden><span>Presse-papiers manuel</span><textarea data-remote-clipboard-text></textarea><button type="button" data-remote-clipboard-read>Remote → zone</button><button type="button" data-remote-clipboard-write>Zone → Remote</button></div><?php endif; ?>
  <div class="dmd-remote-stage" data-remote-stage tabindex="0">
    <canvas data-remote-canvas></canvas>
    <div class="dmd-remote-wait" data-remote-wait>Connexion H.264 / WebSocket…</div>
  </div>
  <div class="dmd-remote-footer"><span data-remote-status>DMD-Remote</span><span data-remote-stats>H.264/WSS</span></div>
</div>
<script>
window.DMD_REMOTE_BOOT = window.DMD_REMOTE_BOOT || {};
window.DMD_REMOTE_BOOT[<?= json_encode($viewerId) ?>] = <?= json_encode([
    'agentId'=>$viewerAgentId,
    'control'=>$viewerControl,
    'detached'=>$viewerDetached,
    'ticketURL'=>$viewerTicketURL,
    'detachURL'=>$viewerDetachURL
], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
</script>
