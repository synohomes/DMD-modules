(function(){
"use strict";
const root=document.querySelector('[data-dram-root]');
if(!root||root.dataset.ready==='1')return;
root.dataset.ready='1';

const boot=window.DMD_REMOTEAGENT_MYDESK_BOOT||{};
const api=root.dataset.api;
const detached=root.dataset.detached;
const csrf=root.dataset.csrf||boot.csrf||'';
let security=boot.security||{enabled:false,unlocked:true};
let devices=[];
let current=null;
let isSuperadmin=false;
let refreshTimer=null;

const $=(s,c=root)=>c.querySelector(s);
const $$=(s,c=root)=>Array.from(c.querySelectorAll(s));
const esc=v=>String(v??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[m]));
const formatDate=v=>{if(!v)return'—';const d=new Date(v);return Number.isNaN(d.getTime())?String(v):d.toLocaleString('fr-FR');};

function toast(text){
    const el=$('[data-dram-toast]');
    el.textContent=text||'';
    el.hidden=false;
    clearTimeout(el._timer);
    el._timer=setTimeout(()=>el.hidden=true,2600);
}
function securityMessage(state){
    const reason=String(state?.blocked_reason||'');
    if(reason==='mfa_not_configured')return'Le MFA doit être configuré dans votre profil avant d’utiliser DMD-RemoteAgent.';
    if(reason==='mfa_disabled_by_policy')return'Le MFA est désactivé pour ce compte par la politique DoMyDesk.';
    if(reason==='mfa_unavailable')return'Le moteur MFA central DoMyDesk est indisponible.';
    return'Une validation MFA est requise pour utiliser DMD-RemoteAgent.';
}
function applySecurity(next){
    if(next&&typeof next==='object')security=Object.assign({},security,next);
    const locked=!!security.enabled&&!security.unlocked;
    $('[data-dram-security]').hidden=!locked;
    $('[data-dram-main]').hidden=locked;
    $('[data-dram-security-message]').textContent=securityMessage(security);
    if(locked){
        devices=[];
        current=null;
        renderPicker();
        showWelcome();
    }
}
async function apiGet(action,params){
    const q=new URLSearchParams(params||{});
    q.set('action',action);
    q.set('_',Date.now());
    const res=await fetch(`${api}?${q}`,{credentials:'same-origin',cache:'no-store'});
    const data=await res.json().catch(()=>({}));
    if(data?.error==='module_mfa_required'&&data.security)applySecurity(data.security);
    if(!res.ok||!data.ok)throw new Error(data.message||data.error||`HTTP ${res.status}`);
    return data;
}
async function apiPost(action,payload){
    const res=await fetch(`${api}?action=${encodeURIComponent(action)}`,{
        method:'POST',
        credentials:'same-origin',
        cache:'no-store',
        headers:{'Content-Type':'application/json','X-DMD-CSRF':csrf},
        body:JSON.stringify(payload||{})
    });
    const data=await res.json().catch(()=>({}));
    if(data?.error==='module_mfa_required'&&data.security)applySecurity(data.security);
    if(!res.ok||!data.ok)throw new Error(data.message||data.error||`HTTP ${res.status}`);
    return data;
}
function permission(name){
    if(!current)return false;
    if(isSuperadmin)return true;
    return Array.isArray(current.permissions)&&current.permissions.includes(name);
}
function capability(name){
    if(!current)return false;
    return Array.isArray(current.capabilities)&&current.capabilities.includes(name);
}
function deviceById(id){
    return devices.find(d=>String(d.agent_id||'')===String(id||''))||null;
}
function showWelcome(){
    $('[data-dram-welcome]').hidden=false;
    $('[data-dram-device-view]').hidden=true;
    $('[data-dram-head-state]').textContent='Choisissez un PC';
}
function renderPicker(){
    const select=$('[data-dram-device]');
    const selected=current?.agent_id||'';
    select.innerHTML='<option value="">Choisir un PC…</option>'+devices.map(d=>{
        const state=d.online?'●':'○';
        const label=`${state} ${d.hostname||'PC'}${d.last_ip?' · '+d.last_ip:''}`;
        return `<option value="${esc(d.agent_id)}">${esc(label)}</option>`;
    }).join('');
    if(selected&&deviceById(selected))select.value=selected;
}
function pct(value){
    const n=Number(value);
    return Number.isFinite(n)?`${Math.round(n*10)/10} %`:'—';
}
function formatBytes(value){
    const n=Number(value);
    if(!Number.isFinite(n)||n<=0)return'—';
    const units=['o','Ko','Mo','Go','To'];
    let v=n;
    let i=0;
    while(v>=1024&&i<units.length-1){v/=1024;i++;}
    return `${v>=10||i===0?v.toFixed(0):v.toFixed(1).replace('.',',')} ${units[i]}`;
}
function machineData(){
    const inv=current?.inventory&&typeof current.inventory==='object'?current.inventory:{};
    const hw=current?.hardware&&typeof current.hardware==='object'?current.hardware:{};
    const os=inv.os&&typeof inv.os==='object'?inv.os:{};
    const cpu=inv.cpu&&typeof inv.cpu==='object'?inv.cpu:{};
    const ram=inv.ram&&typeof inv.ram==='object'?inv.ram:{};
    const uptime=inv.uptime&&typeof inv.uptime==='object'?inv.uptime:{};
    const active=inv.active_interface&&typeof inv.active_interface==='object'?inv.active_interface:{};
    const gpu=Array.isArray(inv.gpu)?inv.gpu:[];
    const volumes=Array.isArray(inv.volumes)?inv.volumes:[];
    const sessions=Array.isArray(inv.sessions)?inv.sessions:[];
    const ports=Array.isArray(inv.open_ports)?inv.open_ports:[];
    const osLabel=[inv.os_name||os.name||current?.platform,inv.os_version||os.version,inv.os_build?`build ${inv.os_build}`:''].filter(Boolean).join(' ');
    const ramTotal=ram.total_bytes?formatBytes(ram.total_bytes):(ram.total_gb!=null?`${ram.total_gb} Go`:'—');
    const ramUsed=ram.used_bytes?formatBytes(ram.used_bytes):(ram.used_gb!=null?`${ram.used_gb} Go`:'—');
    const ramFree=ram.free_bytes?formatBytes(ram.free_bytes):(ram.free_gb!=null?`${ram.free_gb} Go`:'—');
    const activeIPs=[active.ipv4,active.ipv6].filter(Boolean).join(' · ');
    const gpuLabel=gpu.length?gpu.map(g=>typeof g==='string'?g:(g.name||g.model||'')).filter(Boolean).join(' · '):'—';
    return{inv,hw,os,cpu,ram,uptime,active,gpu,volumes,sessions,ports,osLabel,ramTotal,ramUsed,ramFree,activeIPs,gpuLabel};
}
function infoRows(){
    if(!current)return'';
    const d=machineData();
    const rows=[
        ['Identifiant agent',current.agent_id||'—'],
        ['Architecture',current.arch||'—'],
        ['État agent',current.status||'—'],
        ['Constructeur',d.inv.manufacturer||d.hw.system_vendor||'—'],
        ['Modèle',d.inv.model||d.hw.system_product||'—'],
        ['N° série BIOS',d.inv.serial_number||d.hw.bios_serial||'—'],
        ['CPU',d.cpu.model||'—'],
        ['Cœurs / threads',[d.cpu.cores?`${d.cpu.cores} cœurs`:'',d.cpu.threads?`${d.cpu.threads} threads`:''].filter(Boolean).join(' / ')||'—'],
        ['Charge CPU',pct(d.cpu.usage_percent!=null?d.cpu.usage_percent:d.inv.cpu_usage_percent)],
        ['RAM installée',d.ramTotal],
        ['RAM utilisée',d.ramUsed],
        ['RAM libre',d.ramFree],
        ['Charge RAM',pct(d.ram.usage_percent)],
        ['GPU',d.gpuLabel],
        ['Interface active',d.active.name||'—'],
        ['IP interface',d.activeIPs||'—'],
        ['MAC',d.active.mac||'—'],
        ['Passerelle',d.active.gateway||d.inv.gateway||'—'],
        ['Démarrage',formatDate(d.inv.last_boot_at)],
        ['Volumes détectés',String(d.volumes.length)],
        ['Sessions détectées',String(d.sessions.length)],
        ['Ports TCP en écoute',String(d.ports.length)]
    ];
    return rows.map(row=>`<div class="dram-info-row"><span>${esc(row[0])}</span><strong>${esc(row[1])}</strong></div>`).join('');
}
function renderGroups(){
    const host=$('[data-dram-groups]');
    const groups=Array.isArray(current?.groups)?current.groups:[];
    host.innerHTML=groups.length?groups.map(g=>`<span class="dram-tag">${esc(g.name||'Groupe')}</span>`).join(''):'<span class="dram-tag">Aucun groupe</span>';
}
function applyActions(){
    $$('[data-dram-operation]').forEach(btn=>{
        const op=btn.dataset.dramOperation;
        let visible=true;
        if(op==='remote.screen')visible=permission('remote.screen')&&capability('remote.screen');
        if(op==='remote.control')visible=permission('remote.control')&&capability('remote.control');
        if(op==='system.restart')visible=permission('system.restart')&&capability('system.power');
        if(op==='system.shutdown')visible=permission('system.shutdown')&&capability('system.power');
        if(op==='agent.update')visible=permission('agent.update')&&capability('core.update');
        btn.hidden=!visible;
    });
    const terminalTab=$('[data-dram-tab="terminal"]');
    terminalTab.hidden=!(permission('system.terminal')&&capability('system.terminal'));
}
function renderCurrent(){
    if(!current){showWelcome();return;}
    const d=machineData();
    $('[data-dram-welcome]').hidden=true;
    $('[data-dram-device-view]').hidden=false;
    $('[data-dram-head-state]').textContent=`${current.hostname||'PC'} · ${current.online?'En ligne':'Hors ligne'}`;
    $('[data-dram-hostname]').textContent=current.hostname||'PC';
    const status=$('[data-dram-status]');
    status.textContent=current.online?'● En ligne':'○ Hors ligne';
    status.classList.toggle('is-online',!!current.online);

    $('[data-dram-os-line]').textContent=d.osLabel||[current.platform,current.arch].filter(Boolean).join(' · ')||'Système inconnu';
    $('[data-dram-ip-line]').textContent=`IP ${current.last_ip||'—'}`;
    $('[data-dram-agent-line]').textContent=`Agent ${current.agent_version||'—'}`;
    $('[data-dram-contact-line]').textContent=`Contact ${formatDate(current.last_seen_at)}`;

    $('[data-dram-cpu-usage]').textContent=pct(d.cpu.usage_percent!=null?d.cpu.usage_percent:d.inv.cpu_usage_percent);
    $('[data-dram-cpu-short]').textContent=[d.cpu.cores?`${d.cpu.cores} cœurs`:'',d.cpu.threads?`${d.cpu.threads} threads`:''].filter(Boolean).join(' / ')||d.cpu.model||'—';

    $('[data-dram-ram-usage]').textContent=pct(d.ram.usage_percent);
    $('[data-dram-ram-short]').textContent=d.ramUsed!=='—'&&d.ramTotal!=='—'?`${d.ramUsed} / ${d.ramTotal}`:d.ramTotal;

    $('[data-dram-uptime]').textContent=d.uptime.human||'—';
    $('[data-dram-last-boot]').textContent=d.inv.last_boot_at?`Démarré ${formatDate(d.inv.last_boot_at)}`:'Dernier démarrage —';

    $('[data-dram-pending]').textContent=String(current.pending_commands||0);
    $('[data-dram-session]').textContent=d.inv.active_session||d.inv.logged_on_user||'—';
    $('[data-dram-domain]').textContent=d.inv.domain||d.inv.workgroup||'—';

    $('[data-dram-info]').innerHTML=infoRows();
    renderGroups();
    applyActions();
}
async function loadState(silent){
    try{
        const data=await apiGet('state');
        devices=Array.isArray(data.devices)?data.devices:[];
        isSuperadmin=!!data.is_superadmin;
        const selected=current?.agent_id||'';
        current=selected?deviceById(selected):null;
        renderPicker();
        renderCurrent();
        if(!silent)toast('État actualisé');
    }catch(error){
        if(!silent)toast(error.message);
    }
}
async function unlock(code,button){
    button.disabled=true;
    $('[data-dram-mfa-error]').textContent='';
    try{
        const data=await apiPost('security_unlock',{code:String(code||'')});
        applySecurity(data.security||{enabled:true,unlocked:true});
        $('[data-dram-mfa-code]').value='';
        await loadState(true);
    }catch(error){
        $('[data-dram-mfa-error]').textContent=error.message;
    }finally{
        button.disabled=false;
    }
}
async function waitCommand(agentId,commandId,timeoutMs){
    const until=Date.now()+(timeoutMs||120000);
    while(Date.now()<until){
        await new Promise(resolve=>setTimeout(resolve,220));
        const data=await apiGet('command_status',{agent_id:agentId,command_id:commandId});
        const command=data.command||{};
        const status=String(command.status||'');
        if(['done','completed','failed','expired','cancelled'].includes(status))return command;
    }
    throw new Error('Délai de réponse de DMD-Agent dépassé.');
}
function commandResult(command){
    let result=command?.result;
    for(let i=0;i<4;i++){
        if(result&&typeof result==='object'&&Object.prototype.hasOwnProperty.call(result,'result')){
            result=result.result;
            continue;
        }
        break;
    }
    return result;
}
async function execute(operation,params,timeoutMs){
    if(!current)throw new Error('Choisissez un PC.');
    const queued=await apiPost('command',{agent_id:current.agent_id,operation,params:params||{}});
    const id=queued.command?.command_id||queued.command_id||'';
    if(!id)return queued;
    const done=await waitCommand(current.agent_id,id,timeoutMs||120000);
    if(['failed','expired','cancelled'].includes(String(done.status||'')))throw new Error(done.error||`Commande ${done.status}`);
    return done;
}
async function startRemote(operation,button){
    if(!current)return;
    const control=operation==='remote.control';
    const popup=window.open('about:blank',`DMDRemote_${String(current.agent_id).replace(/[^A-Za-z0-9_-]/g,'_')}`,'popup=yes,width=1280,height=820,resizable=yes,scrollbars=no');
    if(popup){
        try{
            popup.document.write('<!doctype html><title>DMD-Remote</title><body style="font-family:Segoe UI,Arial,sans-serif;padding:20px">Connexion au PC…</body>');
            popup.document.close();
        }catch(_){}
    }
    button.disabled=true;
    $('[data-dram-remote-result]').textContent=control?'Démarrage du contrôle Remote…':'Démarrage de la visualisation Remote…';
    try{
        await execute(operation,{},120000);
        const url=`${detached}?agent_id=${encodeURIComponent(current.agent_id)}&control=${control?'1':'0'}`;
        if(popup&&!popup.closed)popup.location.href=url;
        else window.open(url,`DMDRemote_${String(current.agent_id).replace(/[^A-Za-z0-9_-]/g,'_')}`,'popup=yes,width=1280,height=820,resizable=yes,scrollbars=no');
        $('[data-dram-remote-result]').textContent='Session Remote ouverte.';
    }catch(error){
        if(popup&&!popup.closed)popup.close();
        $('[data-dram-remote-result]').textContent=error.message;
    }finally{
        button.disabled=false;
    }
}
async function runTerminal(button){
    if(!current)return;
    const input=$('[data-dram-command]');
    const output=$('[data-dram-terminal-output]');
    const command=String(input.value||'').trim();
    if(!command)return;
    button.disabled=true;
    output.textContent='Exécution…';
    try{
        const done=await execute('system.terminal',{command},120000);
        const result=commandResult(done);
        output.textContent=typeof result==='string'?result:JSON.stringify(result,null,2);
    }catch(error){
        output.textContent=error.message;
    }finally{
        button.disabled=false;
    }
}
async function systemAction(operation,button){
    if(!current)return;
    if(button.dataset.confirm&&!confirm(button.dataset.confirm))return;
    button.disabled=true;
    const host=$('[data-dram-system-result]');
    host.textContent='Commande en cours…';
    try{
        const params=operation==='agent.update'?{channel:'stable'}:{};
        await execute(operation,params,operation==='agent.update'?300000:120000);
        host.textContent='Commande exécutée.';
        setTimeout(()=>loadState(true),900);
    }catch(error){
        host.textContent=error.message;
    }finally{
        button.disabled=false;
    }
}
function switchTab(name){
    $$('[data-dram-tab]').forEach(btn=>btn.classList.toggle('is-active',btn.dataset.dramTab===name));
    $$('[data-dram-pane]').forEach(pane=>pane.hidden=pane.dataset.dramPane!==name);
}
$('[data-dram-mfa-form]').addEventListener('submit',event=>{
    event.preventDefault();
    unlock($('[data-dram-mfa-code]').value,event.submitter||event.currentTarget.querySelector('button'));
});
$('[data-dram-device]').addEventListener('change',event=>{
    current=deviceById(event.target.value);
    renderCurrent();
    switchTab('overview');
    if(current)apiPost('touch',{agent_id:current.agent_id}).catch(()=>{});
});
$('[data-dram-refresh]').addEventListener('click',()=>loadState(false));
$('[data-dram-report]').addEventListener('click',async event=>{
    if(!current)return;
    event.currentTarget.disabled=true;
    try{
        await execute('pc.refresh',{},120000);
        await loadState(true);
        toast('Rapport actualisé');
    }catch(error){
        toast(error.message);
    }finally{
        event.currentTarget.disabled=false;
    }
});
$$('[data-dram-tab]').forEach(btn=>btn.addEventListener('click',()=>switchTab(btn.dataset.dramTab)));
$$('[data-dram-operation]').forEach(btn=>btn.addEventListener('click',()=>{
    const op=btn.dataset.dramOperation;
    if(op==='remote.screen'||op==='remote.control')startRemote(op,btn);
    else systemAction(op,btn);
}));
$('[data-dram-terminal-run]').addEventListener('click',event=>runTerminal(event.currentTarget));

applySecurity(security);
if(security.unlocked)loadState(true);
refreshTimer=setInterval(()=>{
    if(!document.hidden&&security.unlocked)loadState(true);
},20000);
document.addEventListener('visibilitychange',()=>{
    if(!document.hidden&&security.unlocked)loadState(true);
});
})();