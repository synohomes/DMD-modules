(function () {
'use strict';
const DMD_REMOTE_VIEWER_BUILD = 'DMD-REMOTE-V8-AUTO-RECOVERY';

const U8 = Uint8Array;

function cat() {
    let total = 0;
    const parts = [];
    for (const value of arguments) {
        const part = value instanceof U8 ? value : new U8(value || 0);
        parts.push(part);
        total += part.length;
    }
    const out = new U8(total);
    let offset = 0;
    for (const part of parts) {
        out.set(part, offset);
        offset += part.length;
    }
    return out;
}
function ascii(text) {
    const out = new U8(text.length);
    for (let i = 0; i < text.length; i++) out[i] = text.charCodeAt(i) & 255;
    return out;
}
function u16(v) { return new U8([(v >>> 8) & 255, v & 255]); }
function u24(v) { return new U8([(v >>> 16) & 255, (v >>> 8) & 255, v & 255]); }
function u32(v) {
    v = Number(v) >>> 0;
    return new U8([(v >>> 24) & 255, (v >>> 16) & 255, (v >>> 8) & 255, v & 255]);
}
function u64(v) {
    v = Math.max(0, Number(v) || 0);
    const hi = Math.floor(v / 4294967296);
    const lo = v - hi * 4294967296;
    return cat(u32(hi), u32(lo));
}
function zeros(n) { return new U8(n); }
function box(type) {
    const body = cat.apply(null, Array.prototype.slice.call(arguments, 1));
    return cat(u32(body.length + 8), ascii(type), body);
}
function fullbox(type, version, flags) {
    const parts = Array.prototype.slice.call(arguments, 3);
    return box(type, cat(new U8([version & 255]), u24(flags)), ...parts);
}

function nalUnits(data) {
    const bytes = data instanceof U8 ? data : new U8(data || 0);
    const out = [];
    let pos = 0;
    let start = -1;
    function startCode(p) {
        if (p + 3 <= bytes.length && bytes[p] === 0 && bytes[p + 1] === 0 && bytes[p + 2] === 1) return 3;
        if (p + 4 <= bytes.length && bytes[p] === 0 && bytes[p + 1] === 0 && bytes[p + 2] === 0 && bytes[p + 3] === 1) return 4;
        return 0;
    }
    while (pos < bytes.length) {
        const size = startCode(pos);
        if (size) {
            if (start >= 0 && pos > start) out.push(bytes.subarray(start, pos));
            start = pos + size;
            pos += size;
            continue;
        }
        pos++;
    }
    if (start >= 0 && start < bytes.length) out.push(bytes.subarray(start));
    return out.filter(x => x.length > 0);
}
function parameterSets(data) {
    let sps = null;
    let pps = null;
    for (const unit of nalUnits(data)) {
        const type = unit[0] & 31;
        if (type === 7 && !sps) sps = unit.slice();
        if (type === 8 && !pps) pps = unit.slice();
    }
    return {sps, pps};
}
function codecFromSps(sps) {
    if (!sps || sps.length < 4) return 'avc1.42E01E';
    const hex = n => n.toString(16).padStart(2, '0').toUpperCase();
    return 'avc1.' + hex(sps[1]) + hex(sps[2]) + hex(sps[3]);
}
function avccSample(data) {
    const parts = [];
    for (const unit of nalUnits(data)) parts.push(u32(unit.length), unit);
    return cat.apply(null, parts);
}
function avcC(sps, pps) {
    return box('avcC', cat(new U8([1, sps[1] || 66, sps[2] || 0, sps[3] || 30, 0xff, 0xe1]), u16(sps.length), sps, new U8([1]), u16(pps.length), pps));
}
function initSegment(width, height, sps, pps) {
    const matrix = cat(u32(0x00010000), u32(0), u32(0), u32(0), u32(0x00010000), u32(0), u32(0), u32(0), u32(0x40000000));
    const mvhd = fullbox('mvhd', 0, 0, u32(0), u32(0), u32(90000), u32(0), u32(0x00010000), u16(0x0100), u16(0), zeros(8), matrix, zeros(24), u32(2));
    const tkhd = fullbox('tkhd', 0, 7, u32(0), u32(0), u32(1), u32(0), u32(0), zeros(8), u16(0), u16(0), u16(0), u16(0), matrix, u32(width << 16), u32(height << 16));
    const mdhd = fullbox('mdhd', 0, 0, u32(0), u32(0), u32(90000), u32(0), u16(0x55c4), u16(0));
    const hdlr = fullbox('hdlr', 0, 0, u32(0), ascii('vide'), zeros(12), ascii('VideoHandler\0'));
    const comp = ascii('DoMyDesk H264');
    const cname = new U8(32);
    cname[0] = Math.min(31, comp.length);
    cname.set(comp.subarray(0, 31), 1);
    const avc1 = box('avc1', zeros(6), u16(1), zeros(16), u16(width), u16(height), u32(0x00480000), u32(0x00480000), u32(0), u16(1), cname, u16(0x0018), u16(0xffff), avcC(sps, pps));
    const stsd = fullbox('stsd', 0, 0, u32(1), avc1);
    const stts = fullbox('stts', 0, 0, u32(0));
    const stsc = fullbox('stsc', 0, 0, u32(0));
    const stsz = fullbox('stsz', 0, 0, u32(0), u32(0));
    const stco = fullbox('stco', 0, 0, u32(0));
    const stbl = box('stbl', stsd, stts, stsc, stsz, stco);
    const dref = fullbox('dref', 0, 0, u32(1), fullbox('url ', 0, 1));
    const minf = box('minf', fullbox('vmhd', 0, 1, u16(0), u16(0), u16(0), u16(0)), box('dinf', dref), stbl);
    const mdia = box('mdia', mdhd, hdlr, minf);
    const trak = box('trak', tkhd, mdia);
    const trex = fullbox('trex', 0, 0, u32(1), u32(1), u32(3000), u32(0), u32(0));
    const moov = box('moov', mvhd, trak, box('mvex', trex));
    const ftyp = box('ftyp', ascii('isom'), u32(0x200), ascii('isom'), ascii('iso6'), ascii('avc1'), ascii('mp41'));
    return cat(ftyp, moov);
}
function fragment(seq, baseTime, duration, key, sample) {
    const mfhd = fullbox('mfhd', 0, 0, u32(seq));
    const tfhd = fullbox('tfhd', 0, 0x020000, u32(1));
    const tfdt = fullbox('tfdt', 1, 0, u64(baseTime));
    const sampleFlags = key ? 0x02000000 : 0x01010000;
    function makeTrun(offset) {
        return fullbox('trun', 0, 0x000701, u32(1), u32(offset), u32(duration), u32(sample.length), u32(sampleFlags));
    }
    let traf = box('traf', tfhd, tfdt, makeTrun(0));
    let moof = box('moof', mfhd, traf);
    traf = box('traf', tfhd, tfdt, makeTrun(moof.length + 8));
    moof = box('moof', mfhd, traf);
    return cat(moof, box('mdat', sample));
}
function sameBytes(a, b) {
    if (!a || !b || a.length !== b.length) return false;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
}
function parsePacket(ab) {
    const a = new U8(ab);
    if (a.length < 26 || String.fromCharCode(a[0], a[1], a[2], a[3]) !== 'DMDR') return null;
    const version = a[4];
    if (version !== 1 && version !== 2) return null;
    const dv = new DataView(a.buffer, a.byteOffset, a.byteLength);
    const seq = dv.getUint32(10) * 4294967296 + dv.getUint32(14);
    const timestamp = dv.getUint32(18) * 4294967296 + dv.getUint32(22);
    const payload = a.subarray(26);
    return {
        version,
        codec: version === 2 ? 'jpeg' : 'h264',
        key: (a[5] & 1) !== 0,
        width: dv.getUint16(6),
        height: dv.getUint16(8),
        seq,
        timestamp,
        h264: version === 1 ? payload : null,
        jpeg: version === 2 ? payload : null
    };
}
function wsBase(url) {
    let value = String(url || '').replace(/\/$/, '');
    if (value.startsWith('https://')) value = 'wss://' + value.slice(8);
    else if (value.startsWith('http://')) value = 'ws://' + value.slice(7);
    return value;
}

class MSEDecoder {
    constructor(canvas, status, onResync) {
        this.canvas = canvas;
        this.status = status;
        this.onResync = onResync;
        this.parent = canvas.parentElement;
        this.video = document.createElement('video');
        this.video.muted = true;
        this.video.defaultMuted = true;
        this.video.volume = 0;
        this.video.autoplay = true;
        this.video.playsInline = true;
        this.video.preload = 'auto';
        this.video.controls = false;
        this.video.disablePictureInPicture = true;
        this.video.setAttribute('muted', '');
        this.video.setAttribute('autoplay', '');
        this.video.setAttribute('playsinline', '');
        this.video.setAttribute('aria-hidden', 'true');
        this.video.style.cssText = 'position:absolute;z-index:20;pointer-events:none;background:#000;object-fit:fill;display:none;margin:0;padding:0;border:0;';
        if (this.parent) {
            const pos = getComputedStyle(this.parent).position;
            if (pos === 'static') this.parent.style.position = 'relative';
            this.parent.appendChild(this.video);
        }
        this.ms = null;
        this.sb = null;
        this.queue = [];
        this.seq = 1;
        this.base = 0;
        this.ready = false;
        this.waitingKey = true;
        this.lastResync = 0;
        this.objectURL = '';
        this.kickTimer = null;
        this.lastProgress = 0;
        this.resizeObserver = typeof ResizeObserver === 'function' ? new ResizeObserver(() => this.syncLayout()) : null;
        if (this.resizeObserver) {
            this.resizeObserver.observe(this.canvas);
            if (this.parent) this.resizeObserver.observe(this.parent);
        }
        this.scrollHandler = () => this.syncLayout();
        if (this.parent) this.parent.addEventListener('scroll', this.scrollHandler, {passive: true});
        this.visibleHandler = () => {
            if (!document.hidden) {
                this.catchUp();
                this.tryPlay();
            }
        };
        document.addEventListener('visibilitychange', this.visibleHandler);
        this.mediaWakeHandler = () => {
            this.catchUp();
            this.tryPlay();
        };
        for (const eventName of ['loadedmetadata', 'loadeddata', 'canplay', 'progress', 'waiting', 'stalled']) {
            this.video.addEventListener(eventName, this.mediaWakeHandler);
        }
        this.video.addEventListener('playing', () => { this.lastProgress = performance.now(); });
        this.video.addEventListener('timeupdate', () => { this.lastProgress = performance.now(); });
    }
    syncLayout() {
        if (!this.parent || !this.video) return;
        const pr = this.parent.getBoundingClientRect();
        const cr = this.canvas.getBoundingClientRect();
        const left = cr.left - pr.left + this.parent.scrollLeft;
        const top = cr.top - pr.top + this.parent.scrollTop;
        this.video.style.left = Math.round(left) + 'px';
        this.video.style.top = Math.round(top) + 'px';
        this.video.style.width = Math.max(1, Math.round(cr.width)) + 'px';
        this.video.style.height = Math.max(1, Math.round(cr.height)) + 'px';
    }
    tryPlay() {
        if (!this.video || !this.video.src) return;
        try {
            const p = this.video.play();
            if (p && typeof p.catch === 'function') p.catch(() => {});
        } catch (_) {}
    }
    startKick() {
        if (this.kickTimer) return;
        const started = performance.now();
        this.kickTimer = setInterval(() => {
            if (!this.video || !this.video.src || performance.now() - started > 8000) {
                this.stopKick();
                return;
            }
            this.catchUp();
            this.tryPlay();
            if (!this.video.paused && this.video.readyState >= 2 && performance.now() - this.lastProgress < 1200) {
                this.stopKick();
            }
        }, 120);
    }
    stopKick() {
        if (this.kickTimer) clearInterval(this.kickTimer);
        this.kickTimer = null;
    }
    configure(width, height, sps, pps) {
        this.closeMedia();
        this.canvas.width = width;
        this.canvas.height = height;
        this.ms = new MediaSource();
        this.objectURL = URL.createObjectURL(this.ms);
        this.video.src = this.objectURL;
        this.video.style.display = 'block';
        this.lastProgress = 0;
        this.startKick();
        this.syncLayout();
        const codec = codecFromSps(sps);
        this.ms.addEventListener('sourceopen', () => {
            try {
                if (!this.ms || this.ms.readyState !== 'open') return;
                this.sb = this.ms.addSourceBuffer(`video/mp4; codecs="${codec}"`);
                this.sb.mode = 'segments';
                this.sb.addEventListener('updateend', () => {
                    this.catchUp();
                    this.pump();
                });
                this.queue.unshift(initSegment(width, height, sps, pps));
                this.ready = true;
                this.waitingKey = false;
                this.pump();
                this.tryPlay();
            } catch (e) {
                if (this.status) this.status('Décodage H.264 MediaSource impossible');
                this.triggerResync();
            }
        }, {once: true});
    }
    triggerResync() {
        const now = Date.now();
        this.closeMedia();
        this.waitingKey = true;
        if (now - this.lastResync > 300) {
            this.lastResync = now;
            if (this.onResync) this.onResync();
        }
    }
    push(pkt) {
        const p = parameterSets(pkt.h264);
        if (this.waitingKey || !this.ready) {
            if (!pkt.key || !p.sps || !p.pps) return;
            this.configure(pkt.width, pkt.height, p.sps, p.pps);
        }
        if (!this.ready) return;

        if (this.queue.length > 4 || this.liveLag() > 0.40) {
            if (pkt.key && p.sps && p.pps) {
                this.configure(pkt.width, pkt.height, p.sps, p.pps);
            } else {
                this.triggerResync();
                return;
            }
        }

        const sample = avccSample(pkt.h264);
        if (!sample.length) return;
        this.queue.push(fragment(this.seq++, this.base, 3000, pkt.key, sample));
        this.base += 3000;
        this.pump();
        this.tryPlay();
    }
    liveLag() {
        try {
            if (!this.video.buffered || !this.video.buffered.length) return 0;
            const end = this.video.buffered.end(this.video.buffered.length - 1);
            return Math.max(0, end - this.video.currentTime);
        } catch (_) {
            return 0;
        }
    }
    catchUp() {
        try {
            if (!this.video.buffered || !this.video.buffered.length) return;
            const end = this.video.buffered.end(this.video.buffered.length - 1);
            const lag = end - this.video.currentTime;
            if (!Number.isFinite(this.video.currentTime) || this.video.currentTime < 0) this.video.currentTime = 0;
            if (lag > 0.14) this.video.currentTime = Math.max(0, end - 0.03);
            if (this.video.paused) this.tryPlay();
        } catch (_) {}
    }
    pump() {
        if (!this.sb || this.sb.updating || !this.queue.length) return;
        try {
            this.sb.appendBuffer(this.queue.shift());
        } catch (e) {
            if (e && e.name === 'QuotaExceededError') this.triggerResync();
        }
    }
    closeMedia() {
        this.stopKick();
        this.ready = false;
        this.queue = [];
        this.seq = 1;
        this.base = 0;
        if (this.sb) {
            try { if (this.sb.updating) this.sb.abort(); } catch (_) {}
            this.sb = null;
        }
        if (this.ms) {
            try { if (this.ms.readyState === 'open') this.ms.endOfStream(); } catch (_) {}
            this.ms = null;
        }
        if (this.video) {
            try { this.video.pause(); } catch (_) {}
            this.video.removeAttribute('src');
            try { this.video.load(); } catch (_) {}
            this.video.style.display = 'none';
        }
        if (this.objectURL) {
            try { URL.revokeObjectURL(this.objectURL); } catch (_) {}
            this.objectURL = '';
        }
    }
    close() {
        this.closeMedia();
        if (this.resizeObserver) this.resizeObserver.disconnect();
        if (this.parent) this.parent.removeEventListener('scroll', this.scrollHandler);
        document.removeEventListener('visibilitychange', this.visibleHandler);
        for (const eventName of ['loadedmetadata', 'loadeddata', 'canplay', 'progress', 'waiting', 'stalled']) {
            this.video.removeEventListener(eventName, this.mediaWakeHandler);
        }
        if (this.video && this.video.parentNode) this.video.parentNode.removeChild(this.video);
    }
}

class WCDecoder {
    constructor(canvas, status, onResync) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d', {alpha: false});
        this.status = status;
        this.onResync = onResync;
        this.dec = null;
        this.codec = '';
        this.waitingKey = true;
        this.lastResync = 0;
    }
    configure(codec) {
        if (this.dec) {
            try { this.dec.close(); } catch (_) {}
        }
        this.dec = new VideoDecoder({
            output: frame => {
                try {
                    if (this.canvas.width !== frame.displayWidth || this.canvas.height !== frame.displayHeight) {
                        this.canvas.width = frame.displayWidth;
                        this.canvas.height = frame.displayHeight;
                    }
                    this.ctx.drawImage(frame, 0, 0, this.canvas.width, this.canvas.height);
                } finally {
                    frame.close();
                }
            },
            error: () => this.resync()
        });
        const cfg = {codec, optimizeForLatency: true, hardwareAcceleration: 'prefer-hardware', avc: {format: 'annexb'}};
        try {
            this.dec.configure(cfg);
        } catch (_) {
            delete cfg.avc;
            this.dec.configure(cfg);
        }
        this.codec = codec;
        this.waitingKey = false;
    }
    resync() {
        if (this.dec) {
            try { this.dec.close(); } catch (_) {}
            this.dec = null;
        }
        this.waitingKey = true;
        const now = Date.now();
        if (now - this.lastResync > 300) {
            this.lastResync = now;
            if (this.onResync) this.onResync();
        }
    }
    push(pkt) {
        const p = parameterSets(pkt.h264);
        if (this.dec && this.dec.decodeQueueSize > 3) {
            this.resync();
            if (!pkt.key) return;
        }
        if (this.waitingKey || !this.dec || this.dec.state === 'closed') {
            if (!pkt.key || !p.sps) return;
            this.configure(codecFromSps(p.sps));
        }
        if (!this.dec || this.dec.state !== 'configured') return;
        try {
            this.dec.decode(new EncodedVideoChunk({
                type: pkt.key ? 'key' : 'delta',
                timestamp: pkt.timestamp,
                data: pkt.h264
            }));
        } catch (_) {
            this.resync();
        }
    }
    close() {
        if (this.dec) {
            try { this.dec.close(); } catch (_) {}
        }
        this.dec = null;
        this.waitingKey = true;
    }
}

class JPEGDecoder {
    constructor(canvas, status, onDraw) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d', {alpha: false});
        this.status = status;
        this.onDraw = onDraw;
        this.latestDrawn = 0;
        this.pending = null;
        this.busy = false;
        this.closed = false;
        this.activeURL = null;
    }
    // Un seul JPEG en cours de décodage, et au plus la dernière image en
    // attente. Évite l'accumulation asynchrone d'ImageBitmap/Blob en cas de lag.
    push(pkt) {
        if (this.closed || !pkt || !pkt.jpeg || !pkt.jpeg.length) return;
        this.pending = pkt;
        if (!this.busy) this.decodeNext();
    }
    async decodeNext() {
        if (this.closed || this.busy || !this.pending) return;
        const pkt = this.pending;
        this.pending = null;
        this.busy = true;
        const seq = Number(pkt.seq) || 0;
        const blob = new Blob([pkt.jpeg], {type: 'image/jpeg'});
        let bitmap = null;
        try {
            if (typeof createImageBitmap === 'function') {
                bitmap = await createImageBitmap(blob);
                if (!this.closed && seq > this.latestDrawn) {
                    const w = Number(pkt.width) || bitmap.width || 1;
                    const h = Number(pkt.height) || bitmap.height || 1;
                    this.draw(bitmap, w, h, seq);
                }
            } else {
                const url = URL.createObjectURL(blob);
                this.activeURL = url;
                try {
                    const img = new Image();
                    await new Promise((resolve, reject) => {
                        img.onload = resolve;
                        img.onerror = () => reject(new Error('Décodage JPEG impossible'));
                        img.src = url;
                    });
                    if (!this.closed && seq > this.latestDrawn) {
                        this.draw(img, Number(pkt.width) || img.naturalWidth || 1, Number(pkt.height) || img.naturalHeight || 1, seq);
                    }
                } finally {
                    URL.revokeObjectURL(url);
                    if (this.activeURL === url) this.activeURL = null;
                }
            }
        } catch (err) {
            if (!this.closed && this.status) this.status('Décodage JPEG Remote impossible : ' + String(err && err.message || err));
        } finally {
            if (bitmap) try { bitmap.close(); } catch (_) {}
            this.busy = false;
            if (!this.closed && this.pending) this.decodeNext();
        }
    }
    draw(image, w, h, seq) {
        if (w < 1 || h < 1 || w > 8192 || h > 8192) return;
        if (this.canvas.width !== w || this.canvas.height !== h) {
            this.canvas.width = w;
            this.canvas.height = h;
        }
        this.ctx.drawImage(image, 0, 0, w, h);
        this.latestDrawn = seq;
        if (this.onDraw) this.onDraw();
    }
    close() {
        this.closed = true;
        this.pending = null;
    }
}

class Sink {
    constructor(canvas, status, onResync, onDraw) {
        this.canvas = canvas;
        this.status = status;
        this.onResync = onResync;
        this.onDraw = onDraw;
        this.impl = null;
        this.kind = '';
        this.width = 0;
        this.height = 0;
        this.sps = null;
    }
    create(codec) {
        if (codec === 'jpeg') {
            this.kind = 'JPEG';
            this.impl = new JPEGDecoder(this.canvas, this.status, this.onDraw);
            if (this.status) this.status('Remote JPEG de secours');
            return;
        }
        if (typeof VideoDecoder === 'function' && typeof EncodedVideoChunk === 'function') {
            this.kind = 'WebCodecs';
            this.impl = new WCDecoder(this.canvas, this.status, this.onResync);
        } else if (typeof MediaSource === 'function') {
            this.kind = 'MediaSource';
            this.impl = new MSEDecoder(this.canvas, this.status, this.onResync);
        } else {
            throw new Error('Aucun décodeur H.264 navigateur disponible');
        }
        if (this.status) this.status('H.264 · ' + this.kind);
    }
    push(pkt) {
        const codec = pkt && pkt.codec === 'jpeg' ? 'jpeg' : 'h264';
        if (codec === 'jpeg') {
            if (!this.impl || this.kind !== 'JPEG') {
                if (this.impl) this.impl.close();
                this.impl = null;
                this.kind = '';
                this.sps = null;
                this.create('jpeg');
            }
            this.width = pkt.width;
            this.height = pkt.height;
            this.impl.push(pkt);
            return;
        }
        const p = parameterSets(pkt.h264);
        const nextSps = p.sps || null;
        const geometryChanged = this.impl && pkt.key && (pkt.width !== this.width || pkt.height !== this.height);
        const codecChanged = this.impl && this.kind === 'JPEG';
        const h264Changed = this.impl && pkt.key && nextSps && this.sps && !sameBytes(nextSps, this.sps);
        if (geometryChanged || codecChanged || h264Changed) {
            this.impl.close();
            this.impl = null;
            this.kind = '';
            this.sps = null;
        }
        if (!this.impl) this.create('h264');
        if (pkt.key) {
            this.width = pkt.width;
            this.height = pkt.height;
            if (nextSps) this.sps = nextSps.slice();
        }
        this.impl.push(pkt);
    }
    close() {
        if (this.impl) this.impl.close();
        this.impl = null;
        this.kind = '';
        this.width = 0;
        this.height = 0;
        this.sps = null;
    }
}

class Session {
    constructor(opts) {
        this.o = opts || {};
        this.agentId = String(this.o.agentId || '');
        this.api = String(this.o.api || 'DMD-RemoteAgent_api.php');
        this.csrf = String(this.o.csrf || '');
        this.control = !!this.o.control;
        this.canvas = this.o.canvas;
        this.onStatus = typeof this.o.onStatus === 'function' ? this.o.onStatus : () => {};
        this.onInfo = typeof this.o.onInfo === 'function' ? this.o.onInfo : () => {};
        this.video = null;
        this.ctrl = null;
        this.pending = new Map();
        this.closed = false;
        this.reconnectTimer = null;
        this.startupTimer = null;
        this.ticketExp = 0;
        this.info = {width: 0, height: 0, seq: 0};
        this.inputCleanup = [];
        this.pressedKeys = new Set();
        this.pressedButtons = new Set();
        this.sink = new Sink(this.canvas, text => this.onStatus(text), () => this.requestKeyframe(), () => {
            this.lastRenderedAt = performance.now(); this.firstJPEGAt = 0;
            // Admit the next JPEG only after this one has been decoded/drawn.
            // Prevents seconds of latency when the network or browser is slower.
            if (this.sink.kind === 'JPEG' && this.video && this.video.readyState === WebSocket.OPEN) {
                try { this.video.send('{"type":"flow","op":"ack"}'); } catch (_) {}
            }
        });
        this.inputProbeDone = false;
        this.agentStatus = {control: false, video: false, known: false};
        this.lastFrameAt = 0;
        this.lastRenderedAt = 0;
        this.firstJPEGAt = 0;
        this.lastAgentStatusAt = 0;
        this.lastProbeAt = 0;
        this.probeInFlight = false;
        this.connectionEpoch = 0;
        this.watchdogTimer = setInterval(() => this.watchdog(), 1500);
    }
    async post(action, payload) {
        const r = await fetch(`${this.api}?action=${encodeURIComponent(action)}`, {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: {'Content-Type': 'application/json', 'X-DMD-CSRF': this.csrf},
            body: JSON.stringify(payload || {})
        });
        const d = await r.json().catch(() => ({}));
        if (!r.ok || !d.ok) throw new Error(d.message || d.error || `HTTP ${r.status}`);
        return d;
    }
    async connect() {
        if (this.closed) return;
        const epoch = ++this.connectionEpoch;
        this.onStatus('Connexion Remote…');
        let ticketData;
        try {
            ticketData = await this.post('remote_ws_ticket', {agent_id: this.agentId, control: this.control});
        } catch (e) {
            if (this.closed || epoch !== this.connectionEpoch) return;
            this.onStatus(String(e.message || e));
            this.scheduleReconnect(1000);
            return;
        }
        if (this.closed || epoch !== this.connectionEpoch) return;
        const base = wsBase(ticketData.remote_url);
        const ticket = encodeURIComponent(ticketData.ticket);
        this.ticketExp = Number(ticketData.expires_at || 0);
        try {
            this.video = new WebSocket(`${base}/view/video?ticket=${ticket}`);
            this.video.binaryType = 'arraybuffer';
            this.video.onopen = () => {
                if (epoch !== this.connectionEpoch) return;
                // Opt-in per viewer: older viewers continue to use the legacy path.
                // The video socket itself carries acknowledgements; read-only
                // viewers work without keyboard/mouse permissions.
                try { this.video.send('{"type":"flow","op":"enable"}'); } catch (_) {}
                this.onStatus('Relais vidéo connecté · attente de DMD-Remote Agent');
            };
            this.video.onmessage = event => {
                if (epoch !== this.connectionEpoch || !(event.data instanceof ArrayBuffer)) return;
                const pkt = parsePacket(event.data);
                if (!pkt) return;
                this.lastFrameAt = performance.now();
                if (pkt.codec === 'jpeg' && !this.lastRenderedAt && !this.firstJPEGAt) this.firstJPEGAt = this.lastFrameAt;
                this.info = {width: pkt.width, height: pkt.height, seq: pkt.seq};
                if (this.startupTimer) {
                    clearInterval(this.startupTimer);
                    this.startupTimer = null;
                }
                try {
                    this.sink.push(pkt);
                    this.onInfo(this.info);
                    if (this.agentStatus.control && this.agentStatus.video) this.onStatus('Remote connecté');
                } catch (err) {
                    this.onStatus(String(err.message || err));
                }
            };
            this.video.onclose = () => { if (!this.closed && epoch === this.connectionEpoch) this.scheduleReconnect(250); };
            this.video.onerror = () => {};

            this.ctrl = new WebSocket(`${base}/view/control?ticket=${ticket}`);
            this.ctrl.onopen = () => {
                if (epoch !== this.connectionEpoch) return;
                this.onStatus('Relais Remote connecté · vérification de l’Agent…');
            };
            this.ctrl.onmessage = event => {
                if (epoch !== this.connectionEpoch || typeof event.data !== 'string') return;
                let msg;
                try { msg = JSON.parse(event.data); } catch (_) { return; }
                if (msg && msg.type === 'agent_status') {
                    const previous = this.agentStatus;
                    const next = {
                        control: !!msg.control,
                        video: !!msg.video,
                        known: true
                    };
                    const previousOnline = !!(previous.known && previous.control && previous.video);
                    const nextOnline = !!(next.control && next.video);
                    const transportChanged = !!(previous.known && (previous.control !== next.control || previous.video !== next.video));
                    this.agentStatus = next;
                    this.lastAgentStatusAt = performance.now();
                    if (transportChanged) {
                        this.inputProbeDone = false;
                        this.probeInFlight = false;
                        this.releaseInputs();
                        // Le relais reste joignable pendant un lock/unlock ou un reboot,
                        // donc les WebSockets du viewer ne se ferment pas forcément.
                        // Une nouvelle fenêtre fonctionnait car elle recréait ces deux
                        // sockets. On fait désormais exactement cette reprise tout seul
                        // quand les canaux Agent disparaissent ou reviennent.
                        if (previousOnline !== nextOnline) {
                            this.info = {width: 0, height: 0, seq: 0};
                            this.lastFrameAt = 0;
                            this.sink.close();
                            this.lastRenderedAt = 0;
                            this.firstJPEGAt = 0;
                            this.onStatus(nextOnline ? 'DMD-Remote Agent revenu · reprise automatique…' : 'DMD-Remote Agent en reconnexion…');
                            this.scheduleReconnect(nextOnline ? 120 : 450);
                            return;
                        }
                    }
                    if (!this.agentStatus.control) {
                        this.inputProbeDone = false;
                        this.onStatus('DMD-Remote Agent non connecté au relais');
                        return;
                    }
                    if (!this.agentStatus.video) {
                        this.onStatus('Canal contrôle Agent connecté · attente du flux vidéo');
                    } else if (!this.info.seq) {
                        this.onStatus('DMD-Remote Agent connecté · attente de l’écran');
                    } else {
                        this.onStatus('Remote connecté');
                    }
                    this.armStartupKeyframes();
                    this.requestKeyframe();
                    this.probeControl();
                    return;
                }
                if (msg && msg.type === 'result' && msg.request_id) {
                    const pending = this.pending.get(String(msg.request_id));
                    if (!pending) return;
                    this.pending.delete(String(msg.request_id));
                    clearTimeout(pending.timer);
                    if (msg.ok) pending.resolve(msg.data);
                    else pending.reject(new Error(msg.error || 'Commande Remote refusée'));
                } else if (msg && msg.type === 'error') {
                    const text = String(msg.message || 'Canal contrôle refusé');
                    if (text === 'Canal contrôle Agent hors ligne.') {
                        this.agentStatus.control = false;
                        this.agentStatus.known = true;
                        this.inputProbeDone = false;
                        this.onStatus('DMD-Remote Agent non connecté au relais');
                    } else {
                        this.onStatus(text);
                    }
                }
            };
            this.ctrl.onclose = () => {
                if (epoch !== this.connectionEpoch) return;
                for (const pending of this.pending.values()) {
                    clearTimeout(pending.timer);
                    pending.reject(new Error('Canal contrôle fermé'));
                }
                this.pending.clear();
                if (!this.closed) this.scheduleReconnect(250);
            };
            this.ctrl.onerror = () => {};
        } catch (e) {
            this.onStatus(String(e.message || e));
            this.scheduleReconnect();
        }
    }
    probeControl() {
        if (!this.control || this.inputProbeDone || !this.agentStatus.control || this.probeInFlight) return;
        if (!this.ctrl || this.ctrl.readyState !== WebSocket.OPEN) return;
        this.inputProbeDone = true;
        this.probeInFlight = true;
        this.lastProbeAt = performance.now();
        this.call('input.ping', {}, 2500).then(() => {
            this.probeInFlight = false;
            this.lastProbeAt = performance.now();
        }).catch(err => {
            this.probeInFlight = false;
            this.inputProbeDone = false;
            if (this.agentStatus.control) {
                this.onStatus('Contrôle Remote indisponible : ' + String(err && err.message || err));
                this.scheduleReconnect(150);
            }
        });
    }
    watchdog() {
        if (this.closed || this.reconnectTimer) return;
        const now = performance.now();
        if (!this.video || !this.ctrl) return;
        if (this.video.readyState === WebSocket.CLOSED || this.ctrl.readyState === WebSocket.CLOSED) {
            this.scheduleReconnect(100);
            return;
        }
        const online = !!(this.agentStatus.known && this.agentStatus.control && this.agentStatus.video);
        if (!online) return;

        // Un changement de desktop Windows peut laisser les sockets viewer
        // ouvertes alors que l'ancien helper a disparu. Une absence prolongée
        // d'images déclenche une resynchronisation puis une reconnexion complète.
        const frameAge = this.lastFrameAt ? now - this.lastFrameAt : (this.lastAgentStatusAt ? now - this.lastAgentStatusAt : 0);
        if (frameAge > 3000 && frameAge <= 6000) this.requestKeyframe();
        if (frameAge > 6000) {
            this.onStatus('Flux Remote interrompu · reprise automatique…');
            this.scheduleReconnect(100);
            return;
        }
        // Recevoir des JPEG ne prouve pas que le navigateur les affiche.
        // Relancer un lecteur dont le décodage est bloqué, même si les
        // WebSockets continuent à recevoir des images.
        if (this.sink.kind === 'JPEG' && this.lastFrameAt &&
                now - (this.lastRenderedAt || this.firstJPEGAt || now) > 8000 &&
                !document.hidden) {
            this.onStatus('Affichage Remote figé · reprise automatique…');
            this.scheduleReconnect(100);
            return;
        }

        // Le contrôle doit rester vivant après Winlogon/default et après reboot.
        // Une sonde périodique évite de conserver silencieusement un canal Agent
        // remplacé côté relais.
        if (this.control && !this.probeInFlight && now - this.lastProbeAt > 4000) {
            this.probeInFlight = true;
            this.lastProbeAt = now;
            this.call('input.ping', {}, 1800).then(() => {
                this.probeInFlight = false;
                this.inputProbeDone = true;
                this.lastProbeAt = performance.now();
            }).catch(() => {
                this.probeInFlight = false;
                this.inputProbeDone = false;
                this.onStatus('Canal contrôle remplacé · reprise automatique…');
                this.scheduleReconnect(100);
            });
        }
    }
    armStartupKeyframes() {
        if (this.closed || this.info.seq > 0) return;
        if (this.startupTimer) return;
        let attempts = 0;
        const poke = () => {
            if (this.closed || this.info.seq > 0 || attempts >= 10) {
                clearInterval(this.startupTimer);
                this.startupTimer = null;
                return;
            }
            attempts++;
            this.requestKeyframe();
        };
        poke();
        this.startupTimer = setInterval(poke, 350);
    }
    scheduleReconnect(delay) {
        if (this.closed || this.reconnectTimer) return;
        const wait = Number.isFinite(Number(delay)) ? Math.max(0, Number(delay)) : 250;
        this.reconnectTimer = setTimeout(() => {
            this.reconnectTimer = null;
            this.onStatus('Reconnexion Remote automatique…');
            this.closeSockets();
            this.sink.close();
            this.lastRenderedAt = 0;
            this.firstJPEGAt = 0;
            this.info = {width: 0, height: 0, seq: 0};
            this.lastFrameAt = 0;
            this.lastAgentStatusAt = 0;
            this.agentStatus = {control: false, video: false, known: false};
            this.inputProbeDone = false;
            this.probeInFlight = false;
            this.connect();
        }, wait);
    }
    closeSockets() {
        this.connectionEpoch++;
        if (this.startupTimer) {
            clearInterval(this.startupTimer);
            this.startupTimer = null;
        }
        for (const ws of [this.video, this.ctrl]) {
            if (!ws) continue;
            try {
                ws.onopen = ws.onmessage = ws.onerror = ws.onclose = null;
                ws.close();
            } catch (_) {}
        }
        this.video = null;
        this.ctrl = null;
    }
    sendInput(op, data) {
        if (!this.control || !this.ctrl || this.ctrl.readyState !== WebSocket.OPEN || !this.agentStatus.control) return;
        if (op === 'mouse.move' && this.ctrl.bufferedAmount > 32768) return;
        try {
            this.ctrl.send(JSON.stringify({type: 'input', op, data: data || {}}));
        } catch (_) {}
    }
    call(op, data, timeout) {
        return new Promise((resolve, reject) => {
            if (!this.ctrl || this.ctrl.readyState !== WebSocket.OPEN) {
                reject(new Error('Canal contrôle non connecté'));
                return;
            }
            if (!this.agentStatus.control) {
                reject(new Error('DMD-Remote Agent hors ligne'));
                return;
            }
            const id = 'R' + Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
            const timer = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error('Délai Remote dépassé'));
            }, timeout || 5000);
            this.pending.set(id, {resolve, reject, timer});
            try {
                this.ctrl.send(JSON.stringify({type: 'control', op, request_id: id, data: data || {}}));
            } catch (e) {
                clearTimeout(timer);
                this.pending.delete(id);
                reject(e);
            }
        });
    }
    requestKeyframe() {
        if (!this.ctrl || this.ctrl.readyState !== WebSocket.OPEN || !this.agentStatus.control) return Promise.resolve();
        return this.call('stream.keyframe', {}, 1500).catch(() => {});
    }
    releaseInputs() {
        if (!this.control) return;
        for (const button of Array.from(this.pressedButtons)) this.sendInput('mouse.button', {button: Number(button), down: false});
        this.pressedButtons.clear();
        for (const vk of Array.from(this.pressedKeys)) this.sendInput('key.event', {vk: Number(vk), down: false});
        this.pressedKeys.clear();
    }
    unbindInput() {
        this.releaseInputs();
        for (const fn of this.inputCleanup.splice(0)) {
            try { fn(); } catch (_) {}
        }
    }
    close() {
        if (this.closed) return;
        this.unbindInput();
        this.closed = true;
        if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
        if (this.watchdogTimer) { clearInterval(this.watchdogTimer); this.watchdogTimer = null; }
        this.closeSockets();
        for (const pending of this.pending.values()) {
            clearTimeout(pending.timer);
            pending.reject(new Error('Remote fermé'));
        }
        this.pending.clear();
        this.sink.close();
    }
    bindInput(stage) {
        const canvas = this.canvas;
        if (!stage || !canvas) return;
        this.unbindInput();
        const on = (target, type, handler, opts) => {
            target.addEventListener(type, handler, opts);
            this.inputCleanup.push(() => target.removeEventListener(type, handler, opts));
        };
        const focus = () => {
            if (!this.control) return;
            try { stage.focus({preventScroll: true}); } catch (_) { stage.focus(); }
        };
        const pos = event => {
            const rect = canvas.getBoundingClientRect();
            if (!rect.width || !rect.height) return null;
            return {
                x: Math.max(0, Math.min(65535, Math.round((event.clientX - rect.left) / rect.width * 65535))),
                y: Math.max(0, Math.min(65535, Math.round((event.clientY - rect.top) / rect.height * 65535)))
            };
        };
        const vk = event => {
            const direct = Number(event.keyCode || event.which || 0);
            if (direct > 0) return direct;
            const map = {Backspace:8, Tab:9, Enter:13, Shift:16, Control:17, Alt:18, Pause:19, CapsLock:20, Escape:27, ' ':32, PageUp:33, PageDown:34, End:35, Home:36, ArrowLeft:37, ArrowUp:38, ArrowRight:39, ArrowDown:40, Insert:45, Delete:46, Meta:91, ContextMenu:93};
            if (map[event.key] != null) return map[event.key];
            const f = /^F(\d{1,2})$/.exec(String(event.key || ''));
            if (!f) return 0;
            const n = Number(f[1]);
            return n >= 1 && n <= 24 ? 111 + n : 0;
        };
        let lastMove = 0;
        let pendingMove = null;
        let moveTimer = null;
        const flushMove = () => {
            moveTimer = null;
            if (!pendingMove) return;
            const p = pendingMove;
            pendingMove = null;
            lastMove = performance.now();
            this.sendInput('mouse.move', p);
        };
        const queueMove = event => {
            pendingMove = pos(event);
            if (!pendingMove) return;
            const elapsed = performance.now() - lastMove;
            if (elapsed >= 12) {
                if (moveTimer) { clearTimeout(moveTimer); moveTimer = null; }
                flushMove();
            } else if (!moveTimer) {
                moveTimer = setTimeout(flushMove, Math.max(1, 12 - elapsed));
            }
        };

        on(canvas, 'contextmenu', event => { if (this.control) event.preventDefault(); });
        on(canvas, 'pointermove', event => { if (this.control) queueMove(event); });
        on(canvas, 'pointerdown', event => {
            if (!this.control) return;
            event.preventDefault();
            focus();
            try { canvas.setPointerCapture(event.pointerId); } catch (_) {}
            const p = pos(event);
            if (p) this.sendInput('mouse.move', p);
            this.pressedButtons.add(Number(event.button));
            this.sendInput('mouse.button', {button: Number(event.button), down: true});
        });
        on(canvas, 'pointerup', event => {
            if (!this.control) return;
            event.preventDefault();
            try { canvas.releasePointerCapture(event.pointerId); } catch (_) {}
            this.pressedButtons.delete(Number(event.button));
            this.sendInput('mouse.button', {button: Number(event.button), down: false});
        });
        on(canvas, 'pointercancel', event => {
            if (!this.control) return;
            this.pressedButtons.delete(Number(event.button));
            this.sendInput('mouse.button', {button: Number(event.button), down: false});
        });
        on(canvas, 'wheel', event => {
            if (!this.control) return;
            event.preventDefault();
            this.sendInput('mouse.wheel', {delta: event.deltaY < 0 ? 120 : -120});
        }, {passive: false});
        on(stage, 'keydown', event => {
            if (!this.control) return;
            const altGraph = typeof event.getModifierState === 'function' && event.getModifierState('AltGraph');
            const printable = !!(event.key && event.key.length === 1);
            if (printable && !event.metaKey && (!event.ctrlKey || altGraph) && (!event.altKey || altGraph)) {
                event.preventDefault();
                event.stopPropagation();
                this.sendInput('key.text', {text: event.key});
                return;
            }
            const code = vk(event);
            if (code && !this.pressedKeys.has(code)) {
                this.pressedKeys.add(code);
                event.preventDefault();
                event.stopPropagation();
                this.sendInput('key.event', {vk: code, down: true});
            }
        });
        on(stage, 'keyup', event => {
            if (!this.control) return;
            const altGraph = typeof event.getModifierState === 'function' && event.getModifierState('AltGraph');
            const printable = !!(event.key && event.key.length === 1);
            if (printable && !event.metaKey && (!event.ctrlKey || altGraph) && (!event.altKey || altGraph)) {
                event.preventDefault();
                event.stopPropagation();
                return;
            }
            const code = vk(event);
            if (code) {
                this.pressedKeys.delete(code);
                event.preventDefault();
                event.stopPropagation();
                this.sendInput('key.event', {vk: code, down: false});
            }
        });
        on(stage, 'pointerdown', focus);
        on(window, 'blur', () => this.releaseInputs());
        on(document, 'visibilitychange', () => {
            if (document.hidden) this.releaseInputs();
            else this.requestKeyframe();
        });
        this.inputCleanup.push(() => { if (moveTimer) clearTimeout(moveTimer); });
    }
}

window.DMDRemoteSession = Session;
})();
