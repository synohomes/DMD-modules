<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/dmd-ha-v2_lib.php';

if (!dmdha_permission('use') || !dmdha_permission('entity.view')) {
    echo '<div class="dha-app dha-denied">Accès à DMD-Ha.V2 refusé.</div>';
    return;
}

$script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
$marker = '/modules/' . DMDHA_MODULE_ID . '/';
$pos = strpos($script, $marker);

if ($pos !== false) {
    $rootWeb = substr($script, 0, $pos);
} else {
    $rootWeb = '';
}

$moduleWeb = rtrim($rootWeb, '/') . '/modules/' . DMDHA_MODULE_ID;
$email = dmdha_current_email();
$safe = function_exists('dmd_safe_user_key') ? dmd_safe_user_key($email) : basename($email);
$theme = 'default';
$themeFile = DMDHA_DMD_ROOT . '/users/profiles/' . $safe . '/theme.json';

if (is_file($themeFile)) {
    $data = json_decode((string)@file_get_contents($themeFile), true);
    if (is_array($data) && !empty($data['theme'])) {
        $candidate = basename((string)$data['theme']);
        if (is_file(DMDHA_DMD_ROOT . '/theme/' . $candidate . '/style.css')) {
            $theme = $candidate;
        }
    }
}

$themeUrl = rtrim($rootWeb, '/') . '/theme/' . rawurlencode($theme) . '/style.css';
$cssVersion = is_file(__DIR__ . '/dmd-ha-v2-mydesk.css') ? (string)filemtime(__DIR__ . '/dmd-ha-v2-mydesk.css') : DMDHA_MODULE_VERSION;
$jsVersion = is_file(__DIR__ . '/dmd-ha-v2-mydesk.js') ? (string)filemtime(__DIR__ . '/dmd-ha-v2-mydesk.js') : DMDHA_MODULE_VERSION;
$uid = 'dha_' . bin2hex(random_bytes(5));

?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWeb . '/dmd-ha-v2-mydesk.css?v=' . rawurlencode($cssVersion), ENT_QUOTES, 'UTF-8') ?>">

<section
    id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
    class="dha-app"
    data-api="<?= htmlspecialchars($moduleWeb . '/dmd-ha-v2_api.php', ENT_QUOTES, 'UTF-8') ?>"
>
    <header class="dha-top">
        <div class="dha-brand">
            <img src="<?= htmlspecialchars($moduleWeb . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt="">
            <div>
                <strong>Home Assistant</strong>
                <small data-subtitle>Chargement…</small>
            </div>
        </div>
        <button type="button" class="dha-icon-btn" data-refresh aria-label="Actualiser">↻</button>
    </header>

    <div class="dha-instance-row">
        <select data-instance aria-label="Instance Home Assistant"></select>
    </div>

    <section class="dha-welcome" data-welcome>
        <div class="dha-welcome-icon">🏠</div>
        <strong>Bienvenue dans Home Assistant</strong>
        <p>Choisissez d’abord une instance dans le menu déroulant ci-dessus.</p>
        <div class="dha-welcome-steps">
            <div><span>1</span><p>Sélectionnez votre instance Home Assistant.</p></div>
            <div><span>2</span><p>Recherchez ou filtrez les périphériques à afficher.</p></div>
            <div><span>3</span><p>Cliquez sur un périphérique pour consulter son état et utiliser ses commandes.</p></div>
        </div>
    </section>

    <div class="dha-workspace" data-workspace hidden>
        <div class="dha-search">
            <span>⌕</span>
            <input type="search" data-search placeholder="Rechercher un appareil…" autocomplete="off">
        </div>

        <nav class="dha-tabs" data-tabs aria-label="Filtres">
            <button type="button" class="is-active" data-tab="all">Tous</button>
            <button type="button" data-tab="control">Contrôles</button>
            <button type="button" data-tab="camera">Caméras</button>
        </nav>

        <div class="dha-family-row"><select class="dha-family-select" data-family-select aria-label="Catégorie"><option value="">Toutes les catégories</option></select></div>
        <div class="dha-message" data-message hidden></div>
        <main class="dha-content" data-content></main>
    </div>

    <section class="dha-detail" data-detail hidden>
        <header class="dha-detail-head">
            <button type="button" class="dha-back" data-back aria-label="Retour">‹</button>
            <div>
                <strong data-detail-title>Périphérique</strong>
                <small data-detail-type></small>
            </div>
            <button type="button" class="dha-icon-btn" data-detail-refresh aria-label="Actualiser">↻</button>
        </header>
        <div class="dha-detail-scroll">
            <div class="dha-state-card">
                <span data-detail-icon>⌂</span>
                <div>
                    <small>État</small>
                    <strong data-detail-state>—</strong>
                </div>
            </div>
            <div class="dha-camera" data-camera hidden>
                <img data-camera-img alt="">
                <button type="button" data-camera-refresh>Actualiser l’image</button>
            </div>
            <div class="dha-controls" data-controls></div>
            <section class="dha-info">
                <h3>Informations</h3>
                <div data-info></div>
            </section>
        </div>
    </section>

    <div class="dha-toast" data-toast hidden></div>
</section>

<script>
(function(){
    function sourceWindow(){
        var list=[];
        try{if(window.opener&&!window.opener.closed)list.push(window.opener);}catch(e){}
        try{if(window.parent&&window.parent!==window)list.push(window.parent);}catch(e){}
        for(var i=0;i<list.length;i++){
            try{
                if(list[i].document&&list[i].location.origin===window.location.origin)return list[i];
            }catch(e){}
        }
        return null;
    }

    function syncTheme(){
        var source=sourceWindow();
        if(!source)return;
        var names=[
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg',
            '--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft',
            '--border-color','--danger-color','--success-color','--warning-color','--shadow-color',
            '--radius-sm','--radius','--radius-lg','--font-family',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow',
            '--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color',
            '--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg',
            '--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];
        var targets=[document.documentElement,document.body].filter(Boolean);
        [source.document.documentElement,source.document.body].filter(Boolean).forEach(function(root){
            var cs=source.getComputedStyle(root);
            names.forEach(function(name){
                var value=cs.getPropertyValue(name);
                if(value&&value.trim()){
                    targets.forEach(function(target){
                        target.style.setProperty(name,value.trim());
                    });
                }
            });
        });
        try{
            var bodyStyle=source.getComputedStyle(source.document.body);
            targets.forEach(function(target){
                target.style.fontFamily=bodyStyle.fontFamily||'';
            });
        }catch(e){}
    }

    syncTheme();
    window.addEventListener('focus',syncTheme);
    window.addEventListener('load',syncTheme,{once:true});
})();
</script>
<script src="<?= htmlspecialchars($moduleWeb . '/dmd-ha-v2-mydesk.js?v=' . rawurlencode($jsVersion), ENT_QUOTES, 'UTF-8') ?>"></script>
