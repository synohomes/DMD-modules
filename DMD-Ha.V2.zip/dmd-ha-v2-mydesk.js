(function(){
    var root=document.querySelector('.dha-app[data-api]');
    if(!root||root.dataset.ready==='1')return;
    root.dataset.ready='1';

    var api=root.dataset.api;
    var csrf='';
    var instances=[];
    var permissions={};
    var entities=[];
    var currentRef='';
    var currentEntity='';
    var activeTab='all';
    var activeFamily='';
    var timer=null;

    var q=function(s,c){return (c||root).querySelector(s);};
    var qa=function(s,c){return Array.prototype.slice.call((c||root).querySelectorAll(s));};
    var esc=function(v){return String(v==null?'':v).replace(/[&<>'"]/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m];});};

    function url(action,params){
        var u=new URL(api,location.href);
        u.searchParams.set('action',action);
        Object.keys(params||{}).forEach(function(k){u.searchParams.set(k,params[k]);});
        return u.toString();
    }

    async function get(action,params){
        var r=await fetch(url(action,params||{}),{credentials:'same-origin',cache:'no-store'});
        var t=await r.text();
        var j;
        try{j=JSON.parse(t);}catch(e){throw new Error('Réponse API invalide.');}
        if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));
        return j;
    }

    async function post(action,data){
        var body=Object.assign({},data||{},{action:action,csrf:csrf});
        var r=await fetch(api,{
            method:'POST',
            credentials:'same-origin',
            cache:'no-store',
            headers:{'Content-Type':'application/json','X-DMDHA-CSRF':csrf},
            body:JSON.stringify(body)
        });
        var t=await r.text();
        var j;
        try{j=JSON.parse(t);}catch(e){throw new Error('Réponse API invalide.');}
        if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));
        return j;
    }

    function showMessage(message){
        var el=q('[data-message]');
        if(!message){
            el.hidden=true;
            el.textContent='';
            return;
        }
        el.textContent=message;
        el.hidden=false;
    }

    function toast(message){
        var el=q('[data-toast]');
        el.textContent=message;
        el.hidden=false;
        clearTimeout(el._timer);
        el._timer=setTimeout(function(){el.hidden=true;},2400);
    }

    function instance(){
        for(var i=0;i<instances.length;i++){
            if(instances[i].ref===currentRef)return instances[i];
        }
        return null;
    }

    function hasRight(right){
        var i=instance();
        if(permissions[right]!==true&&!(right!=='entity.view'&&permissions['entity.control']===true))return false;
        if(!i||!i.shared)return true;
        var rights=Array.isArray(i.rights)?i.rights:[];
        return rights.indexOf(right)!==-1||(right!=='entity.view'&&rights.indexOf('entity.control')!==-1);
    }

    function domain(entity){
        var id=String(entity&&entity.entity_id||'');
        return id.indexOf('.')===-1?'':id.split('.')[0];
    }

    function meta(entity){
        var p=entity&&entity.preset||{};
        var d=entity&&entity.display||{};
        return {
            familyKey:d.family_key||p.family_key||'other',
            familyLabel:d.family_label||p.family_label||'Autres',
            familyIcon:d.family_icon||p.family_icon||'⌂',
            typeLabel:d.device_type_label||d.group_type_label||p.label||'Périphérique',
            icon:d.device_type_icon||d.group_type_icon||p.icon||'⌂'
        };
    }

    function stateText(entity){
        var raw=String(entity&&entity.state!=null?entity.state:'').trim();
        var low=raw.toLowerCase();
        var unit=String(entity&&entity.unit||'').trim();

        if(low==='unavailable')return 'Indisponible';
        if(low==='unknown'||raw==='')return 'Inconnu';
        if(low==='on')return 'Activé';
        if(low==='off')return 'Désactivé';
        if(low==='open')return 'Ouvert';
        if(low==='closed')return 'Fermé';
        if(low==='locked')return 'Verrouillé';
        if(low==='unlocked')return 'Déverrouillé';
        if(low==='home')return 'À la maison';
        if(low==='not_home')return 'Absent';
        if(low==='idle')return 'Au repos';
        if(low==='running')return 'En cours';
        if(low==='paused')return 'En pause';
        if(low==='standby')return 'En veille';

        var n=Number(raw);
        if(raw!==''&&Number.isFinite(n)){
            var value=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}).format(n);
            return value+(unit?' '+unit:'');
        }

        return raw.replace(/_/g,' ');
    }

    function isOn(entity){
        var s=String(entity&&entity.state||'').toLowerCase();
        return ['on','open','unlocked','home','playing','heating','cooling','running'].indexOf(s)!==-1;
    }

    function canControl(entity){
        var p=entity&&entity.preset||{};
        var right=p.required_control||'entity.control';
        var actions=Array.isArray(p.actions)?p.actions:[];
        return actions.length>0&&hasRight(right);
    }

    function isCamera(entity){
        return domain(entity)==='camera';
    }

    function familyList(){
        var map={};
        entities.forEach(function(entity){
            var m=meta(entity);
            if(!map[m.familyKey])map[m.familyKey]={key:m.familyKey,label:m.familyLabel,icon:m.familyIcon};
        });
        return Object.keys(map).map(function(k){return map[k];}).sort(function(a,b){
            return String(a.label).localeCompare(String(b.label),'fr');
        });
    }

    function renderFamilies(){
        var select=q('[data-family-select]');
        if(!select)return;
        var items=familyList();
        var value=activeFamily;
        select.innerHTML='<option value="">Toutes les catégories</option>'+items.map(function(item){
            return '<option value="'+esc(item.key)+'">'+esc(item.familyIcon||item.icon||'')+(item.familyIcon||item.icon?' ':'')+esc(item.label)+'</option>';
        }).join('');
        select.value=value;
    }

    function filtered(){
        var search=String(q('[data-search]').value||'').trim().toLowerCase();
        return entities.filter(function(entity){
            var m=meta(entity);
            if(activeFamily&&m.familyKey!==activeFamily)return false;
            if(activeTab==='control'&&!canControl(entity))return false;
            if(activeTab==='camera'&&!isCamera(entity))return false;
            if(search){
                var hay=[entity.friendly_name,entity.entity_id,m.familyLabel,m.typeLabel,stateText(entity)].join(' ').toLowerCase();
                if(hay.indexOf(search)===-1)return false;
            }
            return true;
        });
    }

    function render(){
        renderFamilies();
        var list=filtered();
        var subtitle=q('[data-subtitle]');
        var inst=instance();
        subtitle.textContent=(inst?inst.name:'Aucune instance')+' · '+entities.length+' périphérique'+(entities.length>1?'s':'');
        var host=q('[data-content]');

        if(!list.length){
            host.innerHTML='<div class="dha-empty">Aucun périphérique correspondant.</div>';
            return;
        }

        host.innerHTML='<div class="dha-grid">'+list.map(function(entity){
            var m=meta(entity);
            return '<button type="button" class="dha-device '+(isOn(entity)?'is-on':'')+'" data-entity="'+esc(entity.entity_id)+'">'+
                '<span class="dha-device-icon">'+esc(m.icon)+'</span>'+
                '<span class="dha-device-copy">'+
                    '<strong>'+esc(entity.friendly_name||entity.entity_id)+'</strong>'+
                    '<small>'+esc(m.typeLabel)+'</small>'+
                    '<span>'+esc(stateText(entity))+'</span>'+
                '</span>'+
            '</button>';
        }).join('')+'</div>';
    }

    function attributeRows(entity){
        var attrs=entity&&entity.attributes&&typeof entity.attributes==='object'?entity.attributes:{};
        var skip={
            friendly_name:1,icon:1,device_class:1,unit_of_measurement:1,supported_features:1,
            entity_picture:1,attribution:1,source_list:1,hvac_modes:1,options:1,available_modes:1,
            operation_list:1,min_temp:1,max_temp:1,min_humidity:1,max_humidity:1
        };
        var rows=[
            ['Entity ID',entity.entity_id],
            ['Type',meta(entity).typeLabel]
        ];

        Object.keys(attrs).forEach(function(key){
            if(skip[key])return;
            var value=attrs[key];
            if(value===null||value===''||typeof value==='object')return;
            rows.push([key.replace(/_/g,' '),String(value)]);
        });

        return rows.slice(0,18).map(function(row){
            return '<div class="dha-info-row"><span>'+esc(row[0])+'</span><strong>'+esc(row[1])+'</strong></div>';
        }).join('');
    }

    function controlHtml(entity){
        var p=entity&&entity.preset||{};
        var actions=Array.isArray(p.actions)?p.actions:[];
        var attrs=entity.attributes||{};
        var right=p.required_control||'entity.control';
        var allowed=hasRight(right);
        var seen={};
        var html='';

        if(isCamera(entity)&&hasRight('camera.view')){
            html+='<button type="button" data-camera-open>Afficher la caméra</button>';
        }

        if(!allowed&&actions.length){
            return html+'<div class="dha-empty">Consultation uniquement avec vos droits actuels.</div>';
        }

        actions.forEach(function(action){
            var service=String(action.service||'');
            var widget=String(action.widget||'power');
            if(!service||service.indexOf('camera.')===0)return;
            var key=service+'|'+widget;
            if(seen[key])return;
            seen[key]=1;
            var label=action.label||service;

            if(['brightness','volume','position','percentage','temperature','number','humidity'].indexOf(widget)!==-1){
                var min=0,max=100,step=1,value=0;
                if(widget==='temperature'){
                    min=Number(attrs.min_temp!=null?attrs.min_temp:5);
                    max=Number(attrs.max_temp!=null?attrs.max_temp:35);
                    step=.5;
                    value=Number(attrs.temperature!=null?attrs.temperature:(attrs.current_temperature!=null?attrs.current_temperature:20));
                }else if(widget==='humidity'){
                    min=Number(attrs.min_humidity!=null?attrs.min_humidity:0);
                    max=Number(attrs.max_humidity!=null?attrs.max_humidity:100);
                    value=Number(attrs.humidity!=null?attrs.humidity:(attrs.target_humidity!=null?attrs.target_humidity:50));
                }else if(widget==='brightness'){
                    value=Math.round((Number(attrs.brightness||0)/255)*100);
                }else if(widget==='volume'){
                    value=Math.round(Number(attrs.volume_level||0)*100);
                }else if(widget==='position'){
                    value=Number(attrs.current_position||0);
                }else if(widget==='percentage'){
                    value=Number(attrs.percentage||0);
                }else{
                    value=Number(entity.state||0);
                    step=.5;
                }

                html+='<label class="dha-control-line">'+
                    '<span>'+esc(label)+'</span>'+
                    '<input type="range" min="'+esc(min)+'" max="'+esc(max)+'" step="'+esc(step)+'" value="'+esc(value)+'" data-control-value="'+esc(key)+'">'+
                    '<output>'+esc(value)+'</output>'+
                    '<button type="button" data-service="'+esc(service)+'" data-widget="'+esc(widget)+'" data-read="'+esc(key)+'">Appliquer</button>'+
                '</label>';
                return;
            }

            if(['source','hvac_mode','option','humidifier_mode','water_heater_mode'].indexOf(widget)!==-1){
                var list=[];
                if(widget==='source')list=attrs.source_list||[];
                else if(widget==='hvac_mode')list=attrs.hvac_modes||[];
                else if(widget==='humidifier_mode')list=attrs.available_modes||attrs.modes||[];
                else if(widget==='water_heater_mode')list=attrs.operation_list||[];
                else list=attrs.options||[];

                html+='<label class="dha-control-line">'+
                    '<span>'+esc(label)+'</span>'+
                    '<select data-control-value="'+esc(key)+'">'+list.map(function(v){return '<option value="'+esc(v)+'">'+esc(v)+'</option>';}).join('')+'</select>'+
                    '<button type="button" data-service="'+esc(service)+'" data-widget="'+esc(widget)+'" data-read="'+esc(key)+'">Appliquer</button>'+
                '</label>';
                return;
            }

            if(widget==='command'){
                html+='<label class="dha-control-line">'+
                    '<span>'+esc(label)+'</span>'+
                    '<input type="text" data-control-value="'+esc(key)+'" placeholder="Commande">'+
                    '<button type="button" data-service="'+esc(service)+'" data-widget="command" data-read="'+esc(key)+'">Envoyer</button>'+
                '</label>';
                return;
            }

            html+='<button type="button" data-service="'+esc(service)+'" data-widget="'+esc(widget)+'">'+esc(label)+'</button>';
        });

        if(String(entity.entity_id||'').indexOf('alarm_control_panel.')===0&&html){
            html='<label class="dha-control-line"><span>Code alarme</span><input type="password" data-alarm-code autocomplete="off"></label>'+html;
        }

        return html||'<div class="dha-empty">Aucune commande disponible.</div>';
    }

    function entityById(id){
        for(var i=0;i<entities.length;i++){
            if(entities[i].entity_id===id)return entities[i];
        }
        return null;
    }

    function showDetail(id){
        var entity=entityById(id);
        if(!entity)return;
        currentEntity=id;
        var m=meta(entity);
        q('[data-detail-title]').textContent=entity.friendly_name||entity.entity_id;
        q('[data-detail-type]').textContent=m.familyLabel+' · '+m.typeLabel;
        q('[data-detail-icon]').textContent=m.icon;
        q('[data-detail-state]').textContent=stateText(entity);
        q('[data-controls]').innerHTML=controlHtml(entity);
        q('[data-info]').innerHTML=attributeRows(entity);
        q('[data-camera]').hidden=true;
        q('[data-camera-img]').removeAttribute('src');
        q('[data-detail]').hidden=false;

        qa('input[type="range"]',q('[data-controls]')).forEach(function(input){
            input.addEventListener('input',function(){
                var output=input.parentElement.querySelector('output');
                if(output)output.textContent=input.value;
            });
        });
    }

    function closeDetail(){
        q('[data-detail]').hidden=true;
        currentEntity='';
        q('[data-camera-img]').removeAttribute('src');
    }

    function showCamera(){
        var entity=entityById(currentEntity);
        if(!entity||!currentRef)return;
        var box=q('[data-camera]');
        var img=q('[data-camera-img]');
        box.hidden=false;
        img.alt=entity.friendly_name||entity.entity_id;
        img.src=url('camera_snapshot',{instance_ref:currentRef,entity_id:entity.entity_id,t:Date.now()});
    }

    async function sendControl(button){
        var entity=entityById(currentEntity);
        if(!entity)return;
        var service=button.dataset.service;
        if(!service)return;

        var widget=button.dataset.widget||'power';
        var value=null;
        if(button.dataset.read){
            var field=q('[data-control-value="'+CSS.escape(button.dataset.read)+'"]',q('[data-controls]'));
            if(field)value=field.value;
        }

        var extra={};
        var code=q('[data-alarm-code]',q('[data-controls]'));
        if(code&&code.value)extra.code=code.value;

        button.disabled=true;
        try{
            await post('service_call',{
                instance_ref:currentRef,
                entity_id:entity.entity_id,
                service:service,
                widget:widget,
                value:value,
                extra:extra
            });
            toast('Commande envoyée');
            setTimeout(loadStates,500);
        }catch(e){
            showMessage(e.message);
        }finally{
            button.disabled=false;
        }
    }

    function instanceOptions(){
        var select=q('[data-instance]');
        currentRef='';
        q('[data-workspace]').hidden=true;
        q('[data-welcome]').hidden=false;
        q('[data-subtitle]').textContent='Choisissez une instance';

        if(!instances.length){
            select.innerHTML='<option value="" selected>Aucune instance disponible</option>';
            select.disabled=true;
            return;
        }

        select.disabled=false;
        select.innerHTML='<option value="" selected>Choisir une instance…</option>'+instances.map(function(item){
            return '<option value="'+esc(item.ref)+'">'+esc(item.name)+(item.shared?' · partagé':'')+'</option>';
        }).join('');
        select.value='';
    }

    async function loadStates(){
        if(!currentRef){
            entities=[];
            render();
            return;
        }

        showMessage('');
        try{
            var j=await get('states',{instance_ref:currentRef});
            entities=Array.isArray(j.entities)?j.entities:[];
            render();

            if(currentEntity&&entityById(currentEntity)){
                showDetail(currentEntity);
            }
        }catch(e){
            entities=[];
            render();
            showMessage(e.message);
        }
    }

    async function bootstrap(){
        try{
            var j=await get('bootstrap');
            csrf=j.csrf||'';
            instances=Array.isArray(j.instances)?j.instances:[];
            permissions=j.permissions||{};
            instanceOptions();
        }catch(e){
            q('[data-content]').innerHTML='<div class="dha-empty">'+esc(e.message)+'</div>';
            showMessage(e.message);
        }
    }

    q('[data-refresh]').addEventListener('click',loadStates);
    q('[data-detail-refresh]').addEventListener('click',loadStates);
    q('[data-instance]').addEventListener('change',function(e){
        currentRef=e.target.value||'';
        activeFamily='';
        activeTab='all';
        currentEntity='';
        closeDetail();
        q('[data-search]').value='';
        qa('[data-tab]',q('[data-tabs]')).forEach(function(item){
            item.classList.toggle('is-active',item.dataset.tab==='all');
        });

        if(!currentRef){
            entities=[];
            q('[data-workspace]').hidden=true;
            q('[data-welcome]').hidden=false;
            q('[data-content]').innerHTML='';
            q('[data-subtitle]').textContent='Choisissez une instance';
            return;
        }

        q('[data-welcome]').hidden=true;
        q('[data-workspace]').hidden=false;
        q('[data-content]').innerHTML='<div class="dha-loading">Chargement…</div>';
        loadStates();
    });
    q('[data-search]').addEventListener('input',render);
    q('[data-tabs]').addEventListener('click',function(e){
        var button=e.target.closest('[data-tab]');
        if(!button)return;
        activeTab=button.dataset.tab||'all';
        qa('[data-tab]',q('[data-tabs]')).forEach(function(item){
            item.classList.toggle('is-active',item===button);
        });
        render();
    });
    q('[data-family-select]').addEventListener('change',function(e){
        activeFamily=e.target.value||'';
        render();
    });
    q('[data-content]').addEventListener('click',function(e){
        var button=e.target.closest('[data-entity]');
        if(button)showDetail(button.dataset.entity);
    });
    q('[data-back]').addEventListener('click',closeDetail);
    q('[data-camera-refresh]').addEventListener('click',showCamera);
    q('[data-controls]').addEventListener('click',function(e){
        var camera=e.target.closest('[data-camera-open]');
        if(camera){
            showCamera();
            return;
        }
        var button=e.target.closest('[data-service]');
        if(button)sendControl(button);
    });

    document.addEventListener('visibilitychange',function(){
        if(!document.hidden)loadStates();
    });

    bootstrap().then(function(){
        clearInterval(timer);
        timer=setInterval(function(){
            if(!document.hidden)loadStates();
        },20000);
    });
})();