<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */


if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/dmd-ha-v2_lib.php';
if (!dmdha_permission('use')) { echo '<section class="dmdha"><div class="dmdha-empty">Accès à DMD-Ha.V2 refusé.</div></section>'; return; }
$scriptPath = str_replace('\\','/',(string)(isset($_SERVER['SCRIPT_NAME'])?$_SERVER['SCRIPT_NAME']:''));
$marker = '/modules/' . DMDHA_MODULE_ID . '/'; $pos = strpos($scriptPath,$marker);
if ($pos !== false) $base = substr($scriptPath,0,$pos) . '/modules/' . DMDHA_MODULE_ID;
else { $dir=str_replace('\\','/',dirname($scriptPath)); if(substr($dir,-4)==='/adm')$dir=dirname($dir); $base=rtrim($dir,'/').'/modules/'.DMDHA_MODULE_ID; }
if($base==='')$base='/modules/'.DMDHA_MODULE_ID;
$uid='dmdha-'.bin2hex(random_bytes(4));
?>
<link rel="stylesheet" href="<?= htmlspecialchars($base . '/dmd-ha-v2.css?v=216', ENT_QUOTES, 'UTF-8') ?>">
<section id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>" class="dmdha" data-api="<?= htmlspecialchars($base . '/dmd-ha-v2_api.php', ENT_QUOTES, 'UTF-8') ?>" data-module="<?= htmlspecialchars(DMDHA_MODULE_ID, ENT_QUOTES, 'UTF-8') ?>"><br>
    <header class="dmdha-head">
<br>
        <div class="dmdha-head-actions"><select data-instance aria-label="Instance Home Assistant"></select><button type="button" data-integrations>Intégrations</button><button type="button" data-refresh>Actualiser</button></div>
    </header>
    <div class="dmdha-toolbar">
        <input type="search" data-search placeholder="Rechercher un périphérique…">
        <select data-family-filter><option value="">Toutes les familles</option></select>
        <span class="dmdha-count" data-count>0 périphérique</span>
    </div>
    <div class="dmdha-notice" data-notice hidden></div>
    <div class="dmdha-content" data-content><div class="dmdha-empty">Chargement…</div></div>
    <div class="dmdha-toast" data-toast hidden></div>
</section>
<script>
(function(){
    const root=document.getElementById(<?= json_encode($uid) ?>); if(!root||root.dataset.ready==='1')return; root.dataset.ready='1';
    const apiUrl=root.dataset.api, moduleId=root.dataset.module; let csrf='', instances=[], currentRef='', entities=[], resources=[], permissions={}, serviceCache={}, pollTimer=null, cameraThumbTimer=null, cameraThumbCache={}, z=9000;
    const CAMERA_THUMB_MS=300000;
    const q=(s,c=root)=>(c||root).querySelector(s), qa=(s,c=root)=>Array.from((c||root).querySelectorAll(s));
    const esc=v=>String(v==null?'':v).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
    const url=(action,params={})=>{const u=new URL(apiUrl,location.href);u.searchParams.set('action',action);Object.keys(params).forEach(k=>u.searchParams.set(k,params[k]));return u.toString();};
    async function get(action,params={}){const r=await fetch(url(action,params),{credentials:'same-origin',cache:'no-store'});const t=await r.text();let j;try{j=JSON.parse(t)}catch(e){throw new Error('Réponse API invalide : '+t.slice(0,180))}if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));return j;}
    async function post(action,data={}){const r=await fetch(apiUrl,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-DMDHA-CSRF':csrf},body:JSON.stringify(Object.assign({},data,{action,csrf}))});const t=await r.text();let j;try{j=JSON.parse(t)}catch(e){throw new Error('Réponse API invalide : '+t.slice(0,180))}if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));return j;}
    function toast(msg){const el=q('[data-toast]');el.textContent=msg;el.hidden=false;clearTimeout(el._t);el._t=setTimeout(()=>el.hidden=true,3200);}
    function notice(msg){const el=q('[data-notice]');if(!msg){el.hidden=true;el.textContent='';return;}el.textContent=msg;el.hidden=false;}
    function current(ref=currentRef){return instances.find(i=>i.ref===ref)||null;}
    function hasCoreRight(right){return permissions[right]===true || (right!=='entity.view' && permissions['entity.control']===true);}
    function hasInstanceRight(right,ref=currentRef){const i=current(ref);if(!i)return false;if(!i.shared)return true;const rights=Array.isArray(i.rights)?i.rights:[];return rights.includes(right) || (right!=='entity.view' && right!=='instance.view' && rights.includes('entity.control'));}
    function canPresetControl(p,ref=currentRef){const right=(p&&p.required_control)||'entity.control';return hasCoreRight(right)&&hasInstanceRight(right,ref);}
    function canCamera(ref=currentRef){return permissions['camera.view']===true&&hasInstanceRight('camera.view',ref);}
    function serviceAvailable(service,ref=currentRef){if(String(service||'').startsWith('camera.'))return true;const map=serviceCache[ref];return !map||Object.prototype.hasOwnProperty.call(map,service);}
    async function loadServices(){if(!currentRef||serviceCache[currentRef])return;try{const j=await get('services',{instance_ref:currentRef});serviceCache[currentRef]=j.services||{};}catch(_){serviceCache[currentRef]=null;}}
    function entityDomain(e){const id=String((e&&e.entity_id)||'');return id.includes('.')?id.split('.',1)[0]:'';}
    function fmtNumber(n,max=2,min=0){if(!Number.isFinite(n))return String(n);return new Intl.NumberFormat('fr-FR',{minimumFractionDigits:min,maximumFractionDigits:max}).format(n);}
    function normalizedUnit(unit){return String(unit||'').trim().replace('° C','°C').replace('° F','°F');}
    function numericPresentation(n,unit,attrs={}){
        let u=normalizedUnit(unit),v=n,abs=Math.abs(v),digits=2;
        const lower=u.toLowerCase();
        if((u==='kWh'||lower==='kwh')&&abs>0&&abs<1){v*=1000;u='Wh';}
        else if(u==='MWh'&&abs>0&&abs<1){v*=1000;u='kWh';}
        else if(u==='Wh'&&abs>=1000){v/=1000;u='kWh';}
        else if(u==='W'&&abs>=1000){v/=1000;u='kW';}
        else if((lower==='mbit/s'||lower==='mbps')&&abs>0&&abs<1){v*=1000;u='kbit/s';}
        else if((lower==='kbit/s'||lower==='kbps')&&abs>=1000){v/=1000;u='Mbit/s';}
        else if(u==='MB/s'&&abs>0&&abs<1){v*=1000;u='kB/s';}
        else if(u==='kB/s'&&abs>=1000){v/=1000;u='MB/s';}
        else if(u==='GB'&&abs>0&&abs<1){v*=1000;u='MB';}
        else if(u==='MB'&&abs>=1000){v/=1000;u='GB';}
        else if(u==='MB'&&abs>0&&abs<1){v*=1000;u='kB';}
        else if(u==='kB'&&abs>=1000){v/=1000;u='MB';}
        else if(u==='GiB'&&abs>0&&abs<1){v*=1024;u='MiB';}
        else if(u==='MiB'&&abs>=1024){v/=1024;u='GiB';}
        else if(u==='MiB'&&abs>0&&abs<1){v*=1024;u='KiB';}
        else if(u==='KiB'&&abs>=1024){v/=1024;u='MiB';}
        abs=Math.abs(v);
        if(u==='%'||u==='°C'||u==='°F'||u==='W'||u==='kW'||u==='V'||u==='A'||u==='Hz'||u==='ms')digits=1;
        else if(abs>=100)digits=1; else if(abs>=10)digits=1; else if(abs>=1)digits=2; else if(abs>=0.01)digits=3; else digits=4;
        if(Math.abs(v-Math.round(v))<1e-9)digits=0;
        return {text:fmtNumber(v,digits)+(u?' '+u:''),raw:n,unit:u};
    }
    function statePresentation(e){
        const raw=String(e&&e.state!=null?e.state:'').trim(), domain=entityDomain(e), attrs=(e&&e.attributes)||{}, dc=String(attrs.device_class||'').toLowerCase(), unit=normalizedUnit(e&&e.unit);
        const low=raw.toLowerCase();
        if(low==='unavailable')return {text:'Indisponible',raw};
        if(low==='unknown'||raw==='')return {text:domain==='button'?'Prêt':'Inconnu',raw};
        if(low==='idle')return {text:domain==='camera'?'Disponible':'Au repos',raw};
        if(low==='streaming'&&domain==='camera')return {text:'En direct',raw};
        if(low==='recording'&&domain==='camera')return {text:'Enregistrement',raw};
        if(low==='running')return {text:'En cours',raw};
        if(low==='paused')return {text:'En pause',raw};
        if(low==='standby')return {text:'En veille',raw};
        if(low==='above_horizon')return {text:'Au-dessus de l’horizon',raw};
        if(low==='below_horizon')return {text:'Sous l’horizon',raw};
        if(low==='home')return {text:'À la maison',raw};
        if(low==='not_home')return {text:'Absent',raw};
        if(low==='on'||low==='off'){
            const on=low==='on';
            if(domain==='switch'||domain==='light'||domain==='input_boolean')return {text:on?'Activé':'Désactivé',raw};
            if(domain==='binary_sensor'){
                const map={connectivity:['Connecté','Déconnecté'],problem:['Problème','OK'],safety:['Alerte','OK'],update:['Mise à jour disponible','À jour'],heat:['Chauffe','Inactif'],motion:['Mouvement','Calme'],occupancy:['Présence','Libre'],opening:['Ouvert','Fermé'],door:['Ouvert','Fermé'],window:['Ouvert','Fermé'],garage_door:['Ouvert','Fermé'],lock:['Déverrouillé','Verrouillé'],smoke:['Fumée détectée','OK'],gas:['Gaz détecté','OK'],moisture:['Humidité détectée','Sec'],battery:['Batterie faible','OK'],power:['Alimenté','Hors tension'],plug:['Branché','Débranché']};
                if(map[dc])return {text:on?map[dc][0]:map[dc][1],raw};
                return {text:on?'Actif':'Inactif',raw};
            }
            return {text:on?'Actif':'Inactif',raw};
        }
        if(dc==='timestamp'||/^\d{4}-\d{2}-\d{2}T/.test(raw)){
            const d=new Date(raw);if(!Number.isNaN(d.getTime()))return {text:new Intl.DateTimeFormat('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).format(d),raw};
        }
        if(/^-?\d+(?:\.\d+)?$/.test(raw))return numericPresentation(Number(raw),unit,attrs);
        const weather={clear_night:'Nuit claire',cloudy:'Nuageux',exceptional:'Exceptionnel',fog:'Brouillard',hail:'Grêle',lightning:'Orage',lightning_rainy:'Orage et pluie',partlycloudy:'Partiellement nuageux',pouring:'Pluie forte',rainy:'Pluie',snowy:'Neige',snowy_rainy:'Neige et pluie',sunny:'Ensoleillé',windy:'Venteux',windy_variant:'Venteux'};
        if(domain==='weather'&&weather[low])return {text:weather[low],raw};
        return {text:raw.replace(/_/g,' '),raw};
    }
    function stateText(e){return statePresentation(e).text;}
    function displayParts(e){
        const full=String((e&&e.friendly_name)||e.entity_id||'Périphérique').trim(), domain=entityDomain(e), object=String(e&&e.entity_id||'').split('.').slice(1).join('.'), firstSlug=object.split('_')[0].toLowerCase();
        let device=String((e&&e.display&&e.display.device_name)||(e&&e.device_name)||'').trim(), label=full;
        if(device&&full.toLowerCase().startsWith(device.toLowerCase())){label=full.slice(device.length).replace(/^\s*[-–—:]?\s*/,'').trim()||full;}
        if(!device&&['sensor','binary_sensor','switch','button','select','number','time','update'].includes(domain)){
            const first=full.split(/\s+/)[0]||'';const norm=first.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]/g,'');
            if(norm&&norm===firstSlug&&full.length>first.length){device=first;label=full.slice(first.length).trim();}
        }
        return {device,label:label||full,full};
    }
    function displayMeta(e){const p=(e&&e.preset)||{},d=(e&&e.display)||{};return {family_key:d.family_key||p.family_key||'other',family_label:d.family_label||p.family_label||'Autres',family_icon:d.family_icon||p.family_icon||'⌂',family_order:Number(d.family_order??p.family_order??999),type:d.group_type_key||p.type||'generic',type_label:d.group_type_label||p.label||'Périphérique',type_icon:d.group_type_icon||p.icon||'⌂',device_type_key:d.device_type_key||p.type||'generic',device_type_label:d.device_type_label||p.label||'Périphérique',device_type_icon:d.device_type_icon||p.icon||'⌂',device_name:d.device_name||e.device_name||'',device_group_key:d.device_group_key||'',device_group_label:d.device_group_label||'',device_group_icon:d.device_group_icon||'',device_group:d.device_group===true,metric_order:Number(d.metric_order??500),switch_vendor:d.switch_vendor||e.manufacturer||'',switch_model:d.switch_model||e.model||''};}
    function nasRootDeviceName(e){
        const raw=String(displayMeta(e).device_name||'').trim();if(!raw)return '';
        let name=raw.replace(/\s*\((?:drive|disk|disque|volume|storage|pool|bay|raid|ssd|hdd)\b[^)]*\)\s*$/i,'').trim();
        name=name.replace(/\s+(?:drive|disk|disque|volume|storage|pool|bay)\s*[-#:]?\s*\d+\s*$/i,'').trim();
        return name||raw;
    }
    function nasItemSort(a,b){
        const da=displayMeta(a),db=displayMeta(b),ra=String(da.device_name||'').trim(),rb=String(db.device_name||'').trim(),na=nasRootDeviceName(a),nb=nasRootDeviceName(b);
        const ca=(ra===na?'0 ':'1 ')+ra,cb=(rb===nb?'0 ':'1 ')+rb;
        return ca.localeCompare(cb,'fr',{numeric:true,sensitivity:'base'})||da.metric_order-db.metric_order||String(a.friendly_name||'').localeCompare(String(b.friendly_name||''),'fr',{numeric:true,sensitivity:'base'});
    }
    function validIpAddress(value){
        let v=String(value||'').trim().replace(/^\[|\]$/g,'');if(!v)return '';
        if(/^\d{1,3}(?:\.\d{1,3}){3}$/.test(v)){const parts=v.split('.').map(Number);return parts.every(n=>Number.isInteger(n)&&n>=0&&n<=255)?v:'';}
        if(v.includes(':')&&/^[0-9a-f:]+$/i.test(v))return v;
        return '';
    }
    function nasEntityIp(e){
        if(!e)return '';const a=e.attributes&&typeof e.attributes==='object'?e.attributes:{};
        const direct=['ip_address','ip','device_ip','host_address','ipv4_address'];
        for(const key of direct){const ip=validIpAddress(a[key]);if(ip)return ip;}
        const urls=[e.configuration_url,a.configuration_url,a.web_url,a.url];
        for(const raw of urls){if(!raw||typeof raw!=='string')continue;try{const u=new URL(raw,location.href),ip=validIpAddress(u.hostname);if(ip)return ip;}catch(_){} }
        return '';
    }
    function nasGroupIp(items){for(const e of items||[]){const ip=nasEntityIp(e);if(ip)return ip;}return '';}
    function resourceFor(e){return resources.find(r=>r.local_id===e.entity_id)||null;}
    function decorate(scope){try{if(window.DMDActionHub&&typeof window.DMDActionHub.decorate==='function')window.DMDActionHub.decorate(scope||root);}catch(e){}}
    function instanceOptions(){const sel=q('[data-instance]');sel.innerHTML=instances.length?instances.map(i=>`<option value="${esc(i.ref)}">${esc(i.name)}${i.shared?' · partagé':''}</option>`).join(''):'<option value="">Aucune instance</option>';if(!currentRef||!instances.some(i=>i.ref===currentRef))currentRef=instances[0]?instances[0].ref:'';sel.value=currentRef;}
    function familiesFromEntities(){const map=new Map();entities.forEach(e=>{const d=displayMeta(e);if(!map.has(d.family_key))map.set(d.family_key,{key:d.family_key,label:d.family_label,icon:d.family_icon,order:d.family_order});});return Array.from(map.values()).sort((a,b)=>(a.order||999)-(b.order||999)||String(a.label).localeCompare(String(b.label)));}
    function renderFamilyFilter(){const sel=q('[data-family-filter]'), old=sel.value;sel.innerHTML='<option value="">Toutes les familles</option>'+familiesFromEntities().map(f=>`<option value="${esc(f.key)}">${esc(f.icon)} ${esc(f.label)}</option>`).join('');if(Array.from(sel.options).some(o=>o.value===old))sel.value=old;}
    function cameraThumbKey(ref,entityId){return String(ref||'')+'|'+String(entityId||'');}
    function applyCameraThumb(key,objectUrl){
        qa('img[data-camera-thumb]',q('[data-content]')).forEach(img=>{if(img.dataset.cameraThumbKey===key){img.src=objectUrl;img.classList.add('is-ready');img.classList.remove('is-error');}});
    }
    async function ensureCameraThumb(img,force=false){
        if(!img||!document.body.contains(img))return;
        const ref=img.dataset.instanceRef||currentRef,entityId=img.dataset.cameraThumb||'';if(!ref||!entityId)return;
        const key=cameraThumbKey(ref,entityId),now=Date.now(),cached=cameraThumbCache[key];
        if(!force&&cached&&cached.url&&(now-cached.at)<CAMERA_THUMB_MS){img.src=cached.url;img.classList.add('is-ready');return;}
        if(cached&&cached.pending){try{await cached.pending;}catch(_){ }return;}
        const entry=cached||{};
        entry.pending=(async()=>{
            const r=await fetch(url('camera_snapshot',{instance_ref:ref,entity_id:entityId,t:Date.now()}),{credentials:'same-origin',cache:'no-store'});
            if(!r.ok)throw new Error('HTTP '+r.status);const blob=await r.blob();if(!blob||!String(blob.type||'').startsWith('image/'))throw new Error('Aperçu caméra invalide.');
            const objectUrl=URL.createObjectURL(blob),old=entry.url;entry.url=objectUrl;entry.at=Date.now();if(old&&old!==objectUrl)try{URL.revokeObjectURL(old)}catch(_){ }applyCameraThumb(key,objectUrl);
        })();
        cameraThumbCache[key]=entry;
        try{await entry.pending;}catch(_){img.classList.add('is-error');}finally{entry.pending=null;}
    }
    function refreshCameraThumbs(force=false){qa('img[data-camera-thumb]',q('[data-content]')).forEach(img=>ensureCameraThumb(img,force));}
    function normSwitchText(v){return String(v==null?'':v).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[_\/-]+/g,' ').replace(/\s+/g,' ').trim();}
    function switchAttr(attrs,names){attrs=attrs&&typeof attrs==='object'?attrs:{};for(const name of names){if(attrs[name]!==undefined&&attrs[name]!==null&&attrs[name]!==''&&typeof attrs[name]!=='object')return attrs[name];}return null;}
    function switchPortNumber(e){
        const a=e&&e.attributes||{}, direct=switchAttr(a,['port','port_number','port_id','index']);if(direct!==null&&/^\d+$/.test(String(direct)))return Number(direct);
        const text=normSwitchText((e?.friendly_name||'')+' '+(e?.entity_id||''));let m=text.match(/(?:^|\s)port\s*([0-9]{1,3})(?:\s|$)/i);if(m)return Number(m[1]);
        m=String(e?.entity_id||'').match(/(?:^|_)port_?([0-9]{1,3})(?:_|$)/i);return m?Number(m[1]):0;
    }
    function switchBool(v){const x=normSwitchText(v);if(['on','up','online','connected','connecte','active','true','1','link up'].includes(x))return true;if(['off','down','offline','disconnected','deconnecte','inactive','false','0','link down'].includes(x))return false;return null;}
    function switchCompactSpeed(v){let x=String(v==null?'':v).trim();if(!x)return '';x=x.replace(/\s*gbit\/s/i,'G').replace(/\s*gbps/i,'G').replace(/\s*mbit\/s/i,'M').replace(/\s*mbps/i,'M').replace(/\s*kbit\/s/i,'K').replace(/\s*kbps/i,'K');return x;}
    function switchPortMetric(e){
        const t=' '+normSwitchText((e?.friendly_name||'')+' '+(e?.entity_id||'')+' '+(e?.translation_key||''))+' ';
        if(/\b(etat administratif|administrative state|admin state|admin status)\b/.test(t))return 'admin';
        if(/\b(vitesse duplex configure|speed duplex configured|configured speed duplex)\b/.test(t))return 'configured';
        if(/\b(flow control configure|configured flow control)\b/.test(t))return 'flow_config';
        if(/\b(flow control reel|actual flow control|flow control actual)\b/.test(t))return 'flow_actual';
        if(/\b(tx bons paquets|tx good packets?|good tx)\b/.test(t))return 'tx_good';
        if(/\b(rx bons paquets|rx good packets?|good rx)\b/.test(t))return 'rx_good';
        if(/\b(tx erreurs?|tx errors?|tx bad)\b/.test(t))return 'tx_errors';
        if(/\b(rx erreurs?|rx errors?|rx bad)\b/.test(t))return 'rx_errors';
        if(/\b(mac apprises?|learned macs?|mac count|nombre de mac)\b/.test(t))return 'mac';
        if(/\b(vlan detectes?|detected vlans?)\b/.test(t))return 'vlan';
        if(/\bduplex\b/.test(t))return 'duplex';
        if(/\b(vitesse|speed|link speed|debit port)\b/.test(t))return 'speed';
        if(/\b(mac|clients?|appareils? connectes?)\b/.test(t))return 'mac';
        if(/\bpoe\b/.test(t))return 'poe';
        if(/\bvlan\b/.test(t))return 'vlan';
        if(/\b(entrant|receive|received|rx)\b/.test(t))return 'rx';
        if(/\b(sortant|transmit|transmitted|tx)\b/.test(t))return 'tx';
        if(entityDomain(e)==='binary_sensor'||/\b(lien|link|connectivite|connectivity|status|etat)\b/.test(t))return 'link';return 'other';
    }
    function switchUnique(values){return Array.from(new Set((values||[]).map(v=>String(v??'').trim()).filter(Boolean)));}
    function switchNormalizeMacDetail(row){
        if(typeof row==='string')return {mac:row.trim(),vlan:'',type:''};
        if(!row||typeof row!=='object')return null;
        const pick=(...keys)=>{for(const k of keys)if(row[k]!==undefined&&row[k]!==null&&row[k]!==''&&typeof row[k]!=='object')return String(row[k]);return '';};
        const mac=pick('mac','mac_address','address','macaddr'),vlan=pick('vlan','vlan_id','vid'),type=pick('type','entry_type','kind','status');
        return mac||vlan||type?{mac,vlan,type}:null;
    }
    function switchMergePortRecord(port,rec){
        if(!rec||typeof rec!=='object')return;const get=(...keys)=>{for(const k of keys)if(rec[k]!==undefined&&rec[k]!==null&&rec[k]!==''&&typeof rec[k]!=='object')return rec[k];return null;};
        let v=get('link','connected','up','online','status','state');if(v!==null&&port.link===null)port.link=switchBool(v);
        v=get('admin','admin_state','administrative_state','admin_status','enabled');if(v!==null&&!port.admin)port.admin=String(v);
        v=get('speed','link_speed','speed_mbps','rate');if(v!==null&&!port.speed)port.speed=switchCompactSpeed(v);
        v=get('duplex','actual_duplex');if(v!==null&&!port.duplex)port.duplex=String(v);
        v=get('configured','configured_speed_duplex','speed_duplex_configured','configured_speed');if(v!==null&&!port.configured)port.configured=String(v);
        v=get('flow_config','flow_control_configured','configured_flow_control');if(v!==null&&!port.flow_config)port.flow_config=String(v);
        v=get('flow_actual','flow_control_actual','actual_flow_control','flow_control');if(v!==null&&!port.flow_actual)port.flow_actual=String(v);
        v=get('tx_good','tx_good_packets','tx_packets_good');if(v!==null&&!port.tx_good)port.tx_good=String(v);
        v=get('rx_good','rx_good_packets','rx_packets_good');if(v!==null&&!port.rx_good)port.rx_good=String(v);
        v=get('tx_errors','tx_error','tx_bad','tx_bad_packets');if(v!==null&&!port.tx_errors)port.tx_errors=String(v);
        v=get('rx_errors','rx_error','rx_bad','rx_bad_packets');if(v!==null&&!port.rx_errors)port.rx_errors=String(v);
        v=get('mac_count','clients','client_count','learned_mac_count');if(v!==null&&!port.macs)port.macs=String(v);
        const macArray=Array.isArray(rec.mac_addresses)?rec.mac_addresses:(Array.isArray(rec.macs)?rec.macs:[]);if(macArray.length)port.mac_addresses=switchUnique([...(port.mac_addresses||[]),...macArray]);
        const vlanArray=Array.isArray(rec.vlans)?rec.vlans:(Array.isArray(rec.detected_vlans)?rec.detected_vlans:[]);if(vlanArray.length)port.vlans=switchUnique([...(port.vlans||[]),...vlanArray]);
        const details=Array.isArray(rec.mac_details)?rec.mac_details:(Array.isArray(rec.mac_table)?rec.mac_table:[]);if(details.length){for(const row of details){const d=switchNormalizeMacDetail(row);if(d&&!port.mac_details.some(x=>x.mac===d.mac&&x.vlan===d.vlan&&x.type===d.type))port.mac_details.push(d);}}
        if(!port.macs&&port.mac_addresses.length)port.macs=String(port.mac_addresses.length);
        if(!port.macs&&port.mac_details.length)port.macs=String(port.mac_details.length);
        if(!port.vlans.length&&port.mac_details.length)port.vlans=switchUnique(port.mac_details.map(x=>x.vlan));
        v=get('poe','poe_status','power');if(v!==null&&!port.poe)port.poe=String(v);v=get('vlan','vlan_id','pvid');if(v!==null&&!port.vlan)port.vlan=String(v);v=get('media','type','port_type','medium');if(v!==null&&!port.media)port.media=String(v);
    }
    function switchDeviceData(items){
        const visible=items.filter(e=>!e.supporting), first=items[0]||{}, dm=displayMeta(first), ports=new Map();let ip='',fw='',hw='',serial='',maxPort=0;
        const configUrl=String(first.configuration_url||'');if(configUrl){try{ip=(new URL(configUrl,location.href)).hostname||'';}catch(_){}}
        for(const e of items){const a=e.attributes||{};if(!ip){const v=switchAttr(a,['ip_address','ip','host','address','device_ip']);if(v)ip=String(v);}if(!fw)fw=String(e.sw_version||switchAttr(a,['firmware','firmware_version','sw_version','software_version','version'])||'');if(!hw)hw=String(e.hw_version||switchAttr(a,['hw_version','hardware_version'])||'');if(!serial)serial=String(e.serial_number||switchAttr(a,['serial_number','serial'])||'');
            const n=switchPortNumber(e);if(n>0){maxPort=Math.max(maxPort,n);if(!ports.has(n))ports.set(n,{n,link:null,admin:'',speed:'',duplex:'',configured:'',flow_config:'',flow_actual:'',tx_good:'',rx_good:'',tx_errors:'',rx_errors:'',macs:'',mac_addresses:[],mac_details:[],poe:'',vlan:'',vlans:[],media:'',rx:'',tx:'',entity_id:e.entity_id});const port=ports.get(n);if(!port.entity_id||!e.supporting)port.entity_id=e.entity_id;const metric=switchPortMetric(e), val=statePresentation(e).text, raw=e.state;
                if(metric==='link'){const b=switchBool(raw);if(b!==null)port.link=b;else if(port.link===null)port.link=switchBool(val);}else if(metric==='admin')port.admin=val;else if(metric==='speed')port.speed=switchCompactSpeed(val);else if(metric==='duplex')port.duplex=val;else if(metric==='configured')port.configured=val;else if(metric==='flow_config')port.flow_config=val;else if(metric==='flow_actual')port.flow_actual=val;else if(metric==='tx_good')port.tx_good=String(raw);else if(metric==='rx_good')port.rx_good=String(raw);else if(metric==='tx_errors')port.tx_errors=String(raw);else if(metric==='rx_errors')port.rx_errors=String(raw);else if(metric==='mac')port.macs=String(raw);else if(metric==='poe')port.poe=val;else if(metric==='vlan'){port.vlan=val;port.vlans=switchUnique([...(port.vlans||[]),...String(raw).split(/[,;\s]+/)]);}else if(metric==='rx')port.rx=val;else if(metric==='tx')port.tx=val;
                switchMergePortRecord(port,a);
            }
            const nested=a.ports||a.port_status||a.port_data;if(nested&&typeof nested==='object'){const rows=Array.isArray(nested)?nested:Object.values(nested);rows.forEach((rec,idx)=>{if(!rec||typeof rec!=='object')return;const no=Number(rec.port??rec.port_number??rec.id??rec.index??idx+1);if(!Number.isFinite(no)||no<=0)return;maxPort=Math.max(maxPort,no);if(!ports.has(no))ports.set(no,{n:no,link:null,admin:'',speed:'',duplex:'',configured:'',flow_config:'',flow_actual:'',tx_good:'',rx_good:'',tx_errors:'',rx_errors:'',macs:'',mac_addresses:[],mac_details:[],poe:'',vlan:'',vlans:[],media:'',rx:'',tx:'',entity_id:e.entity_id});switchMergePortRecord(ports.get(no),rec);});}
        }
        const totalAttr=items.map(e=>switchAttr(e.attributes||{},['port_count','ports_total','total_ports','num_ports'])).find(v=>Number(v)>0);const total=Math.max(Number(totalAttr)||0,maxPort,ports.size);for(let n=1;n<=total;n++)if(!ports.has(n))ports.set(n,{n,link:null,admin:'',speed:'',duplex:'',configured:'',flow_config:'',flow_actual:'',tx_good:'',rx_good:'',tx_errors:'',rx_errors:'',macs:'',mac_addresses:[],mac_details:[],poe:'',vlan:'',vlans:[],media:'',rx:'',tx:'',entity_id:visible[0]?.entity_id||first.entity_id||''});
        const list=Array.from(ports.values()).sort((a,b)=>a.n-b.n),active=list.filter(p=>p.link===true).length;
        const vendor=dm.switch_vendor||first.manufacturer||'',model=dm.switch_model||first.model||'',name=dm.device_group_label||dm.device_name||vendor||'Switch réseau';return {name,vendor,model,ip,fw,hw,serial,total,active,ports:list,visible,groupKey:dm.device_group_key||''};
    }
    function isNetworkSwitchGroup(items){return items.some(e=>{const d=displayMeta(e);return d.device_type_key==='network_switch'||d.type==='network_switch'||d.type==='network.switch';});}
    function networkSwitchVisual(items){
        const sw=switchDeviceData(items);if(!sw.ports.length)return '';
        const title=[sw.vendor,sw.model].filter(Boolean).join(' ').trim()||sw.name,sub=[sw.name!==title?sw.name:'',sw.ip?('IP '+sw.ip):'',sw.fw?('FW '+sw.fw):''].filter(Boolean).join(' · ');
        const ports=sw.ports.map(p=>{const cls=p.link===true?'is-up':p.link===false?'is-down':'is-unknown',status=p.link===true?(p.speed||'UP'):p.link===false?'DOWN':(p.speed||'?'),mac=p.macs!==''?(String(p.macs)+' MAC'):'';const vlanList=(p.vlans||[]).length?p.vlans.join(', '):p.vlan;const details=[p.media,p.duplex,p.poe?('PoE '+p.poe):'',vlanList?('VLAN '+vlanList):'',p.rx?('RX '+p.rx):'',p.tx?('TX '+p.tx):''].filter(Boolean).join(' · ');return `<button type="button" class="dmdha-switch-port ${cls}" data-switch-port="${p.n}" data-switch-group="${esc(sw.groupKey)}" data-switch-entity="${esc(p.entity_id)}" title="${esc('Port '+p.n+' · '+status+(mac?' · '+mac:'')+(details?' · '+details:''))}"><span class="dmdha-switch-led"></span><span class="dmdha-switch-jack"><i></i></span><strong>${p.n}</strong><b>${esc(status)}</b>${mac?`<small>${esc(mac)}</small>`:'<small>&nbsp;</small>'}</button>`}).join('');
        return `<section class="dmdha-switch-visual"><header><div><strong>${esc(title)}</strong>${sub?`<small>${esc(sub)}</small>`:''}</div><div class="dmdha-switch-total"><strong>${sw.active}/${sw.total}</strong><small>ports actifs</small></div></header><div class="dmdha-switch-ports">${ports}</div><footer><span><i class="is-up"></i> connecté</span><span><i class="is-down"></i> déconnecté</span><span><i class="is-unknown"></i> inconnu</span></footer></section>`;
    }
    function card(e){
        const r=resourceFor(e),p=e.preset||{},d=displayMeta(e),parts=displayParts(e),state=statePresentation(e),search=(e.friendly_name+' '+e.entity_id+' '+p.label+' '+p.family_label+' '+d.type_label+' '+d.family_label+' '+parts.device+' '+parts.label).toLowerCase();
        const device=parts.device?`<small class="dmdha-card-device">${esc(parts.device)}</small>`:'',isCamera=entityDomain(e)==='camera'&&canCamera(currentRef);
        const context=`data-open="${esc(e.entity_id)}" data-family="${esc(d.family_key)}" data-search="${esc(search)}" data-dmd-module-id="${esc(moduleId)}" data-dmd-context-type="ha_entity" data-dmd-context-id="${esc(r?r.id:(moduleId+':ha_entity:'+e.entity_id))}" data-dmd-context-name="${esc(e.friendly_name)}" data-dmd-action-hub="1"`;
        const thumb=isCamera?`<span class="dmdha-camera-thumb" data-camera-live="${esc(e.entity_id)}" title="Ouvrir le flux en direct"><img alt="Aperçu ${esc(parts.full)}" data-camera-thumb="${esc(e.entity_id)}" data-instance-ref="${esc(currentRef)}" data-camera-thumb-key="${esc(cameraThumbKey(currentRef,e.entity_id))}"><span>▶ Direct</span></span>`:'';
        const typeLabel=d.device_type_label&&d.device_type_label!==parts.device?d.device_type_label:p.label;
        return `<button type="button" class="dmdha-card${isCamera?' dmdha-camera-card':''}" title="${esc(parts.full+' · '+e.entity_id+' · '+state.text+' · '+typeLabel)}" ${context}><span class="dmdha-card-icon">${esc(d.type_icon||p.icon||'⌂')}</span><span class="dmdha-card-copy">${device}<strong>${esc(parts.label)}</strong></span><span class="dmdha-card-value"><strong>${esc(state.text)}</strong>${isCamera?'':`<small>${esc(typeLabel)}</small>`}</span>${thumb}</button>`;
    }
    function render(){
        renderFamilyFilter();const search=q('[data-search]').value.trim().toLowerCase(),family=q('[data-family-filter]').value,content=q('[data-content]');
        const openFamilies=new Set(qa('details.dmdha-main-family[open]',content).map(d=>d.dataset.familyKey));
        const openTypes=new Set(qa('details.dmdha-main-type[open]',content).map(d=>d.dataset.typeKey));
        const openDevices=new Set(qa('details.dmdha-main-device[open]',content).map(d=>d.dataset.deviceKey));
        const filtered=entities.filter(e=>{const d=displayMeta(e);return (!family||d.family_key===family)&&(!search||(e.friendly_name+' '+e.entity_id+' '+(e.preset?.label||'')+' '+(e.preset?.family_label||'')+' '+d.type_label+' '+d.family_label+' '+(d.device_name||'')+' '+(d.device_group_label||'')).toLowerCase().includes(search));});
        const selectedFiltered=filtered.filter(e=>!e.supporting);q('[data-count]').textContent=selectedFiltered.length+' périphérique'+(selectedFiltered.length>1?'s':'')+(search||family?' affiché'+(selectedFiltered.length>1?'s':''):'');
        if(!selectedFiltered.length){content.innerHTML='<div class="dmdha-empty">Aucun périphérique pour ce filtre.</div>';return;}
        const fams={};filtered.forEach(e=>{const d=displayMeta(e);if(!fams[d.family_key])fams[d.family_key]={label:d.family_label,icon:d.family_icon,order:d.family_order,types:{},count:0};if(!fams[d.family_key].types[d.type])fams[d.family_key].types[d.type]={label:d.type_label,icon:d.type_icon,items:[],devices:{},count:0};const g=fams[d.family_key].types[d.type];if(d.device_group&&d.device_group_key){if(!g.devices[d.device_group_key])g.devices[d.device_group_key]={label:d.device_group_label||d.device_name||d.type_label,icon:d.device_group_icon||d.type_icon,items:[]};g.devices[d.device_group_key].items.push(e);}else g.items.push(e);if(!e.supporting){fams[d.family_key].count++;g.count++;}});
        const forceOpen=!!search||!!family;
        const html=Object.keys(fams).filter(fk=>fams[fk].count>0).sort((a,b)=>(fams[a].order||999)-(fams[b].order||999)||String(fams[a].label).localeCompare(String(fams[b].label))).map(fk=>{const f=fams[fk],familyOpen=forceOpen||openFamilies.has(fk),types=Object.keys(f.types).filter(t=>f.types[t].count>0).sort((a,b)=>String(f.types[a].label).localeCompare(String(f.types[b].label)));return `<details class="dmdha-main-family" data-family-key="${esc(fk)}" ${familyOpen?'open':''}><summary><span class="dmdha-main-family-title"><span>${esc(f.icon)}</span><strong>${esc(f.label)}</strong></span><small>${f.count}</small></summary><div class="dmdha-main-family-body">${types.map(t=>{const g=f.types[t],typeKey=fk+'::'+t,typeOpen=forceOpen||openTypes.has(typeKey),deviceKeys=Object.keys(g.devices).filter(k=>g.devices[k].items.some(e=>!e.supporting)).sort((a,b)=>String(g.devices[a].label).localeCompare(String(g.devices[b].label)));
            const directItems=g.items.filter(e=>!e.supporting);
            let direct='';
            if(t==='network.nas'&&directItems.length){
                const nasGroups={};const leftovers=[];
                directItems.forEach(e=>{const name=nasRootDeviceName(e);if(name){const key=name.toLocaleLowerCase('fr');if(!nasGroups[key])nasGroups[key]={label:name,icon:'🗄️',items:[]};nasGroups[key].items.push(e);}else leftovers.push(e);});
                direct=Object.keys(nasGroups).sort((a,b)=>nasGroups[a].label.localeCompare(nasGroups[b].label,'fr',{numeric:true,sensitivity:'base'})).map(nk=>{const ng=nasGroups[nk],deviceKey=typeKey+'::nas::'+nk,deviceOpen=forceOpen||openDevices.has(deviceKey);ng.items.sort(nasItemSort);const nasIp=nasGroupIp(ng.items);return `<details class="dmdha-main-device is-nas-device" data-device-key="${esc(deviceKey)}" ${deviceOpen?'open':''}><summary><span>${esc(ng.icon)} <strong>${esc(ng.label)}</strong>${nasIp?` <small>· IP ${esc(nasIp)}</small>`:''}</span><small>${ng.items.length}</small></summary><div class="dmdha-grid">${ng.items.map(card).join('')}</div></details>`}).join('');
                if(leftovers.length)direct+=`<div class="dmdha-grid">${leftovers.map(card).join('')}</div>`;
            }else if(directItems.length)direct=`<div class="dmdha-grid">${directItems.map(card).join('')}</div>`;
            const devices=deviceKeys.map(dk=>{const dg=g.devices[dk],deviceKey=typeKey+'::'+dk,deviceOpen=forceOpen||openDevices.has(deviceKey);dg.items.sort((a,b)=>displayMeta(a).metric_order-displayMeta(b).metric_order||String(a.friendly_name).localeCompare(String(b.friendly_name)));const selectedItems=dg.items.filter(e=>!e.supporting),switchView=isNetworkSwitchGroup(dg.items),nasView=(t==='nas'||t==='network.nas'),nasIp=nasView?nasGroupIp(dg.items):'',body=switchView?`${networkSwitchVisual(dg.items)}<details class="dmdha-switch-entities"><summary>Entités détaillées <small>${selectedItems.length}</small></summary><div class="dmdha-grid">${selectedItems.map(card).join('')}</div></details>`:`<div class="dmdha-grid">${selectedItems.map(card).join('')}</div>`;return `<details class="dmdha-main-device${switchView?' is-network-switch':''}${nasView?' is-nas-device':''}" data-device-key="${esc(deviceKey)}" ${deviceOpen?'open':''}><summary><span>${esc(dg.icon)} <strong>${esc(dg.label)}</strong>${nasIp?` <small>· IP ${esc(nasIp)}</small>`:''}</span><small>${switchView?switchDeviceData(dg.items).active+'/'+switchDeviceData(dg.items).total:selectedItems.length}</small></summary>${body}</details>`}).join('');return `<details class="dmdha-main-type" data-type-key="${esc(typeKey)}" ${typeOpen?'open':''}><summary><span>${esc(g.icon)} <strong>${esc(g.label)}</strong></span><small>${g.count}</small></summary>${direct}${devices}</details>`}).join('')}</div></details>`}).join('');
        content.innerHTML=html;decorate(content);refreshCameraThumbs(false);
    }
    function attrValue(k,v){
        if(v==null)return '';
        if(k==='brightness'&&Number.isFinite(Number(v)))return fmtNumber(Number(v)/255*100,0)+' %';
        if(k==='volume_level'&&Number.isFinite(Number(v)))return fmtNumber(Number(v)*100,0)+' %';
        if(['battery_level','percentage','position'].includes(k)&&Number.isFinite(Number(v)))return fmtNumber(Number(v),1)+' %';
        if(['current_temperature','temperature'].includes(k)&&Number.isFinite(Number(v)))return fmtNumber(Number(v),1)+' °C';
        if(['latitude','longitude'].includes(k)&&Number.isFinite(Number(v)))return fmtNumber(Number(v),5);
        return String(v).replace(/_/g,' ');
    }
    function attrRows(attrs){
        const labels={device_class:'Classe HA',battery_level:'Batterie',brightness:'Luminosité',color_temp_kelvin:'Température couleur',current_temperature:'Température actuelle',temperature:'Consigne',hvac_action:'Action climat',hvac_mode:'Mode climat',percentage:'Pourcentage',position:'Position',volume_level:'Volume',media_title:'Titre',media_artist:'Artiste',source:'Source',ip_address:'Adresse IP',latitude:'Latitude',longitude:'Longitude'};
        const keep=Object.keys(labels);return keep.filter(k=>attrs&&attrs[k]!==undefined&&typeof attrs[k]!=='object').map(k=>`<div><span>${esc(labels[k])}</span><strong>${esc(attrValue(k,attrs[k]))}</strong></div>`).join('');
    }
    function controlHtml(e,ref){const p=e.preset||{}, all=Array.isArray(p.actions)?p.actions:[],attrs=e.attributes||{};const a=all.filter(x=>(String(x.service||'').startsWith('camera.')?canCamera(ref):canPresetControl(p,ref))&&serviceAvailable(x.service,ref));if(!a.length)return '<p class="dmdha-muted">Consultation uniquement avec vos droits actuels.</p>';let out='', seen={};a.forEach(x=>{const key=x.service+'|'+x.widget;if(seen[key])return;seen[key]=1;const w=x.widget||'power';if(x.service==='camera.snapshot_proxy')out+=`<button type="button" data-camera="snapshot">${esc(x.label)}</button>`;else if(x.service==='camera.stream_proxy')out+=`<button type="button" data-camera="stream">${esc(x.label)}</button>`;else if(['brightness','volume','position','percentage','temperature','number','humidity'].includes(w)){let min=w==='temperature'?(attrs.min_temp??5):w==='humidity'?(attrs.min_humidity??0):0,max=w==='temperature'?(attrs.max_temp??35):w==='humidity'?(attrs.max_humidity??100):100,step=(w==='temperature'||w==='number')?0.5:1;let value=w==='brightness'?Math.round((Number(attrs.brightness||0)/255)*100):w==='volume'?Math.round(Number(attrs.volume_level||0)*100):w==='position'?Number(attrs.current_position||0):w==='percentage'?Number(attrs.percentage||0):w==='temperature'?Number(attrs.temperature||attrs.current_temperature||20):w==='humidity'?Number(attrs.humidity||attrs.target_humidity||attrs.current_humidity||e.state||50):Number(e.state||0);out+=`<label class="dmdha-control-line"><span>${esc(x.label)}</span><input type="range" min="${esc(min)}" max="${esc(max)}" step="${esc(step)}" value="${esc(value)}" data-value-for="${esc(key)}"><output>${esc(value)}</output><button type="button" data-service="${esc(x.service)}" data-widget="${esc(w)}" data-read="${esc(key)}">Appliquer</button></label>`;}else if(['source','hvac_mode','option','humidifier_mode','water_heater_mode'].includes(w)){const list=w==='source'?(attrs.source_list||[]):w==='hvac_mode'?(attrs.hvac_modes||[]):w==='humidifier_mode'?(attrs.available_modes||attrs.modes||[]):w==='water_heater_mode'?(attrs.operation_list||[]):(attrs.options||[]);out+=`<label class="dmdha-control-line"><span>${esc(x.label)}</span><select data-value-for="${esc(key)}">${list.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('')}</select><button type="button" data-service="${esc(x.service)}" data-widget="${esc(w)}" data-read="${esc(key)}">Appliquer</button></label>`;}else if(w==='command'){out+=`<label class="dmdha-control-line"><span>${esc(x.label)}</span><input data-value-for="${esc(key)}" placeholder="Commande"><button type="button" data-service="${esc(x.service)}" data-widget="command" data-read="${esc(key)}">Envoyer</button></label>`;}else{out+=`<button type="button" data-service="${esc(x.service)}" data-widget="${esc(w)}">${esc(x.label)}</button>`;}});if(String(e.entity_id).startsWith('alarm_control_panel.'))out=`<label class="dmdha-control-line"><span>Code alarme</span><input type="password" data-alarm-code autocomplete="off" placeholder="si requis"></label>`+out;return out;}
    function geometryKey(e,ref){return 'DMD-Ha.V2.window.'+ref+'.'+e.entity_id;}
    function restoreGeometry(win,e,ref){try{const g=JSON.parse(localStorage.getItem(geometryKey(e,ref))||'null');if(g){if(g.left!=null)win.style.left=g.left+'px';if(g.top!=null)win.style.top=g.top+'px';if(g.width)win.style.width=g.width+'px';if(g.height)win.style.height=g.height+'px';}}catch(_){}}
    function saveGeometry(win,e,ref){try{const r=win.getBoundingClientRect();localStorage.setItem(geometryKey(e,ref),JSON.stringify({left:Math.round(r.left+window.scrollX),top:Math.round(r.top+window.scrollY),width:Math.round(r.width),height:Math.round(r.height)}));}catch(_){}}
    function makeDraggable(win,e,ref){const h=q('[data-drag]',win);let on=false,sx=0,sy=0,l=0,t=0;h.addEventListener('pointerdown',ev=>{if(ev.target.closest('button'))return;on=true;win.style.zIndex=String(++z);sx=ev.clientX;sy=ev.clientY;const r=win.getBoundingClientRect();l=r.left+window.scrollX;t=r.top+window.scrollY;h.setPointerCapture(ev.pointerId)});h.addEventListener('pointermove',ev=>{if(!on)return;win.style.left=Math.max(0,l+ev.clientX-sx)+'px';win.style.top=Math.max(0,t+ev.clientY-sy)+'px';});h.addEventListener('pointerup',ev=>{if(!on)return;on=false;try{h.releasePointerCapture(ev.pointerId)}catch(_){ }saveGeometry(win,e,ref)});win.addEventListener('pointerdown',()=>win.style.zIndex=String(++z));if(window.ResizeObserver)new ResizeObserver(()=>saveGeometry(win,e,ref)).observe(win);}
    function switchDetailValue(v,fallback='—'){const x=String(v??'').trim();return x===''?fallback:x;}
    function openSwitchPort(groupKey,portNo,entityId){
        const instanceRef=currentRef;if(!instanceRef)return;portNo=Number(portNo);const items=entities.filter(x=>displayMeta(x).device_group_key===groupKey);if(!items.length)return openEntity(entityId);
        const sw=switchDeviceData(items),port=sw.ports.find(x=>x.n===portNo);if(!port)return openEntity(entityId);
        const seed=entities.find(x=>x.entity_id===entityId)||items.find(x=>!x.supporting)||items[0],key='switchport|'+instanceRef+'|'+groupKey+'|'+portNo,existing=document.querySelector('.dmdha-window[data-key="'+CSS.escape(key)+'"]');if(existing){existing.style.zIndex=String(++z);return;}
        const win=document.createElement('section');win.className='dmdha-window dmdha-switch-port-window';win.dataset.key=key;win.style.zIndex=String(++z);win.style.left=(45+document.querySelectorAll('.dmdha-window').length*24+window.scrollX)+'px';win.style.top=(90+document.querySelectorAll('.dmdha-window').length*24+window.scrollY)+'px';
        const status=port.link===true?'Connecté':port.link===false?'Déconnecté':'Inconnu',vlans=(port.vlans||[]).length?port.vlans.join(', '):port.vlan,macCount=port.macs||((port.mac_details||[]).length?String(port.mac_details.length):((port.mac_addresses||[]).length?String(port.mac_addresses.length):''));
        let macDetails=(port.mac_details||[]).slice();if(!macDetails.length&&(port.mac_addresses||[]).length)macDetails=port.mac_addresses.map(mac=>({mac,vlan:'',type:''}));
        const row=(label,value)=>`<div><span>${esc(label)}</span><strong>${esc(switchDetailValue(value))}</strong></div>`;
        const table=macDetails.length?`<section class="dmdha-switch-mac-section"><h4>MAC détectées sur le port <small>${macDetails.length}</small></h4><div class="dmdha-switch-mac-list">${macDetails.map(x=>`<div><code>${esc(x.mac||'—')}</code><span>${x.vlan?('VLAN '+esc(x.vlan)):'—'}</span><small>${esc(x.type||'')}</small></div>`).join('')}</div></section>`:'<section class="dmdha-switch-mac-section is-empty"><h4>MAC détectées sur le port</h4><p>Aucun détail MAC exposé par Home Assistant pour ce port.</p></section>';
        const title=[sw.vendor,sw.model].filter(Boolean).join(' ').trim()||sw.name,meta=[sw.name!==title?sw.name:'',sw.ip?('IP '+sw.ip):'',sw.fw?('FW '+sw.fw):''].filter(Boolean).join(' · ');
        win.innerHTML=`<header data-drag><div><strong>🔀 ${esc(title)} · Port ${portNo}</strong><small>${esc(meta||sw.name)}</small></div><button type="button" data-close aria-label="Fermer">×</button></header><div class="dmdha-window-body"><div class="dmdha-switch-port-status ${port.link===true?'is-up':port.link===false?'is-down':'is-unknown'}"><strong>${esc(status)}</strong><small>${esc(port.speed||'')}</small></div><div class="dmdha-switch-port-facts">${row('État administratif',port.admin)}${row('Vitesse',port.speed)}${row('Duplex',port.duplex)}${row('Vitesse/Duplex configuré',port.configured)}${row('Flow Control configuré',port.flow_config)}${row('Flow Control réel',port.flow_actual)}${row('TX bons paquets',port.tx_good)}${row('RX bons paquets',port.rx_good)}${row('TX erreurs',port.tx_errors)}${row('RX erreurs',port.rx_errors)}${row('MAC apprises',macCount)}${row('VLAN détectés',vlans)}</div>${table}<details class="dmdha-switch-port-entities"><summary>Entités Home Assistant du port</summary><div>${items.filter(x=>switchPortNumber(x)===portNo).map(x=>`<button type="button" data-open-entity="${esc(x.entity_id)}"><strong>${esc(x.friendly_name)}</strong><small>${esc(x.entity_id)}</small><span>${esc(statePresentation(x).text)}</span></button>`).join('')}</div></details></div>`;
        document.body.appendChild(win);restoreGeometry(win,seed,instanceRef);makeDraggable(win,seed,instanceRef);q('[data-close]',win).addEventListener('click',()=>win.remove());q('.dmdha-window-body',win).addEventListener('click',ev=>{const b=ev.target.closest('[data-open-entity]');if(b)openEntity(b.dataset.openEntity);});
    }
    function openEntity(entityId,cameraMode=''){const instanceRef=currentRef,e=entities.find(x=>x.entity_id===entityId);if(!e||!instanceRef)return;const key=instanceRef+'|'+entityId,existing=document.querySelector('.dmdha-window[data-key="'+CSS.escape(key)+'"]');if(existing){existing.style.zIndex=String(++z);if(cameraMode){const cb=q('[data-camera="'+cameraMode+'"]',existing);if(cb)cb.click();}return;}const r=resourceFor(e),inst=current(instanceRef),win=document.createElement('section');win.className='dmdha-window';win.dataset.key=key;win.dataset.dmdModuleId=moduleId;win.dataset.dmdContextType='ha_entity';win.dataset.dmdContextId=r?r.id:(moduleId+':ha_entity:'+entityId);win.dataset.dmdContextName=e.friendly_name;win.dataset.dmdActionHub='1';win.style.zIndex=String(++z);win.style.left=(40+document.querySelectorAll('.dmdha-window').length*26+window.scrollX)+'px';win.style.top=(90+document.querySelectorAll('.dmdha-window').length*26+window.scrollY)+'px';const parts=displayParts(e),sp=statePresentation(e),dm=displayMeta(e);win.innerHTML=`<header data-drag><div><strong>${esc(dm.device_type_icon||e.preset.icon)} ${esc(parts.full)}</strong><small>${esc(inst?inst.name:'')} · ${esc(dm.device_type_label)}</small></div><button type="button" data-close aria-label="Fermer">×</button></header><div class="dmdha-window-body"><div class="dmdha-state-big">${esc(sp.text)}</div><div class="dmdha-info"><div><span>Périphérique</span><strong>${esc(parts.device||parts.full)}</strong></div><div><span>Mesure / fonction</span><strong>${esc(parts.device?parts.label:e.preset.label)}</strong></div><div><span>Type de périphérique</span><strong>${esc(dm.device_type_label)}</strong></div><div><span>Entity ID</span><strong>${esc(e.entity_id)}</strong></div>${attrRows(e.attributes)}</div><div class="dmdha-controls">${controlHtml(e,instanceRef)}</div><div class="dmdha-camera-box" data-camera-box hidden></div><div class="dmdha-window-msg" data-msg></div></div>`;document.body.appendChild(win);restoreGeometry(win,e,instanceRef);makeDraggable(win,e,instanceRef);decorate(win);q('[data-close]',win).addEventListener('click',()=>{if(win._dmdhaCameraTimer)clearInterval(win._dmdhaCameraTimer);win.remove();});qa('input[type="range"]',win).forEach(sl=>sl.addEventListener('input',()=>{const o=sl.parentElement.querySelector('output');if(o)o.textContent=sl.value;}));q('.dmdha-controls',win).addEventListener('click',async ev=>{const b=ev.target.closest('button');if(!b)return;const msg=q('[data-msg]',win);try{if(b.dataset.camera){const box=q('[data-camera-box]',win);box.hidden=false;if(win._dmdhaCameraTimer){clearInterval(win._dmdhaCameraTimer);win._dmdhaCameraTimer=null;}const img=document.createElement('img');img.alt=e.friendly_name;box.replaceChildren(img);if(b.dataset.camera==='snapshot'){img.src=url('camera_snapshot',{instance_ref:instanceRef,entity_id:e.entity_id,t:Date.now()});msg.textContent='Instantané.';return;}msg.textContent='Ouverture du flux…';let fallback=false;img.addEventListener('load',()=>{if(!fallback)msg.textContent='Flux caméra actif.';});img.addEventListener('error',()=>{if(fallback)return;fallback=true;msg.textContent='Flux natif indisponible : aperçu rafraîchi automatiquement.';const refresh=()=>{if(!document.body.contains(win)){if(win._dmdhaCameraTimer)clearInterval(win._dmdhaCameraTimer);return;}img.src=url('camera_snapshot',{instance_ref:instanceRef,entity_id:e.entity_id,t:Date.now()});};refresh();win._dmdhaCameraTimer=setInterval(refresh,1500);});img.src=url('camera_stream',{instance_ref:instanceRef,entity_id:e.entity_id,t:Date.now()});return;}const service=b.dataset.service;if(!service)return;let value=null;if(b.dataset.read){const field=win.querySelector('[data-value-for="'+CSS.escape(b.dataset.read)+'"]');value=field?field.value:null;}const extra={};const code=q('[data-alarm-code]',win);if(code&&code.value)extra.code=code.value;b.disabled=true;msg.textContent='Commande…';await post('service_call',{instance_ref:instanceRef,entity_id:e.entity_id,service,widget:b.dataset.widget||'power',value,extra});msg.textContent='Commande envoyée.';toast('Commande envoyée');if(currentRef===instanceRef)setTimeout(loadStates,700);}catch(err){msg.textContent=err.message;}finally{b.disabled=false;}});if(cameraMode){const cb=q('[data-camera="'+cameraMode+'"]',win);if(cb)setTimeout(()=>cb.click(),0);}}
    async function openIntegrations(){const instanceRef=currentRef,inst=current(instanceRef);if(!instanceRef||!inst)return;const fake={entity_id:'integrations'};const key='integrations|'+instanceRef,existing=document.querySelector('.dmdha-window[data-key="'+CSS.escape(key)+'"]');if(existing){existing.style.zIndex=String(++z);return;}try{toast('Chargement des intégrations…');const j=await get('integrations',{instance_ref:instanceRef});const win=document.createElement('section');win.className='dmdha-window dmdha-integration-window';win.dataset.key=key;win.style.zIndex=String(++z);win.style.left=(55+document.querySelectorAll('.dmdha-window').length*22+window.scrollX)+'px';win.style.top=(80+document.querySelectorAll('.dmdha-window').length*22+window.scrollY)+'px';const groups=j.integrations||[];win.innerHTML=`<header data-drag><div><strong>Intégrations · ${esc(inst.name)}</strong><small>${groups.length} intégration${groups.length>1?'s':''}</small></div><button type="button" data-close aria-label="Fermer">×</button></header><div class="dmdha-window-body dmdha-integrations">${groups.length?groups.map(g=>`<details><summary><strong>${esc(g.platform)}</strong><span>${g.count} entité${g.count>1?'s':''}</span></summary>${Object.values(g.types||{}).sort((a,b)=>String(a.label).localeCompare(String(b.label))).map(t=>`<section><h4>${esc(t.icon)} ${esc(t.label)} <small>${(t.entities||[]).length}</small></h4><div>${(t.entities||[]).map(x=>`<article><strong>${esc(x.friendly_name)}</strong><small>${esc(x.entity_id)}</small><span>${esc(statePresentation({entity_id:x.entity_id,state:x.state,unit:x.unit,attributes:{}}).text)}</span></article>`).join('')}</div></section>`).join('')}</details>`).join(''):'<div class="dmdha-empty">Aucune intégration détectée.</div>'}</div>`;document.body.appendChild(win);restoreGeometry(win,fake,instanceRef);makeDraggable(win,fake,instanceRef);q('[data-close]',win).addEventListener('click',()=>{if(win._dmdhaCameraTimer)clearInterval(win._dmdhaCameraTimer);win.remove();});}catch(err){notice(err.message);}}
    async function loadStates(){if(!currentRef){entities=[];resources=[];render();notice('Aucune instance Home Assistant accessible.');return;}notice('');try{await loadServices();const j=await get('states',{instance_ref:currentRef});entities=j.entities||[];resources=j.resources||[];render();}catch(err){entities=[];resources=[];render();notice(err.message);}}
    async function bootstrap(){try{const j=await get('bootstrap');csrf=j.csrf||'';instances=j.instances||[];permissions=j.permissions||{};instanceOptions();await loadStates();}catch(err){notice(err.message);q('[data-content]').innerHTML='<div class="dmdha-empty">'+esc(err.message)+'</div>';}}
    q('[data-instance]').addEventListener('change',e=>{currentRef=e.target.value;loadStates();});q('[data-integrations]').addEventListener('click',openIntegrations);q('[data-refresh]').addEventListener('click',loadStates);q('[data-search]').addEventListener('input',render);q('[data-family-filter]').addEventListener('change',render);q('[data-content]').addEventListener('click',e=>{const live=e.target.closest('[data-camera-live]');if(live){e.preventDefault();e.stopPropagation();openEntity(live.dataset.cameraLive,'stream');return;}const sp=e.target.closest('[data-switch-port]');if(sp){e.preventDefault();e.stopPropagation();openSwitchPort(sp.dataset.switchGroup,sp.dataset.switchPort,sp.dataset.switchEntity);return;}const b=e.target.closest('[data-open]');if(b)openEntity(b.dataset.open);});
    function schedule(){clearInterval(pollTimer);clearInterval(cameraThumbTimer);pollTimer=setInterval(()=>{if(!document.body.contains(root)){clearInterval(pollTimer);clearInterval(cameraThumbTimer);return;}if(!document.hidden)loadStates();},20000);cameraThumbTimer=setInterval(()=>{if(!document.body.contains(root)){clearInterval(pollTimer);clearInterval(cameraThumbTimer);return;}if(!document.hidden)refreshCameraThumbs(true);},CAMERA_THUMB_MS);}document.addEventListener('visibilitychange',()=>{if(!document.hidden&&document.body.contains(root)){loadStates();refreshCameraThumbs(false);}});bootstrap().then(schedule);
})();
</script>
