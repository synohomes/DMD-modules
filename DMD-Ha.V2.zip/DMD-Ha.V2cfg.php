<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/dmd-ha-v2_lib.php';
if (!dmdha_permission('instance.manage') && !(dmdha_is_superadmin() && dmdha_permission('share.manage')) && !dmdha_permission('preset.manage') && !dmdha_permission('logs.view')) { echo '<section class="dmdha dmdha-cfg"><div class="dmdha-empty">Configuration DMD-Ha.V2 refusée.</div></section>'; return; }
$scriptPath=str_replace('\\','/',(string)(isset($_SERVER['SCRIPT_NAME'])?$_SERVER['SCRIPT_NAME']:''));$marker='/modules/'.DMDHA_MODULE_ID.'/';$pos=strpos($scriptPath,$marker);
if($pos!==false)$base=substr($scriptPath,0,$pos).'/modules/'.DMDHA_MODULE_ID;else{$dir=str_replace('\\','/',dirname($scriptPath));if(substr($dir,-4)==='/adm')$dir=dirname($dir);$base=rtrim($dir,'/').'/modules/'.DMDHA_MODULE_ID;}if($base==='')$base='/modules/'.DMDHA_MODULE_ID;
$uid='dmdhacfg-'.bin2hex(random_bytes(4));
?>
<link rel="stylesheet" href="<?= htmlspecialchars($base . '/dmd-ha-v2.css?v=212', ENT_QUOTES, 'UTF-8') ?>">
<section id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>" class="dmdha dmdha-cfg" data-api="<?= htmlspecialchars($base . '/dmd-ha-v2_api.php', ENT_QUOTES, 'UTF-8') ?>">
    <header class="dmdha-head"><div class="dmdha-title"><img src="<?= htmlspecialchars($base . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt=""><div><strong>Configuration DMD-Ha.V2</strong><small>Instances · périphériques · partages · presets · notifications · logs</small></div></div><div class="dmdha-head-actions"><button type="button" data-reload>Recharger</button></div></header>
    <nav class="dmdha-tabs" aria-label="Configuration HA">
        <button type="button" data-tab-btn="instances" class="is-active">Instances</button>
        <button type="button" data-tab-btn="entities">Périphériques</button>
        <button type="button" data-tab-btn="shares">Partages & droits</button>
        <button type="button" data-tab-btn="presets">Presets</button>
        <button type="button" data-tab-btn="notifications">Notifications</button>
        <button type="button" data-tab-btn="logs">Logs</button>
    </nav>
    <div class="dmdha-notice" data-notice hidden></div>

    <section class="dmdha-tab is-active" data-tab="instances">
        <div class="dmdha-cfg-grid">
            <aside class="dmdha-side"><div class="dmdha-side-head"><strong>Instances HA</strong><button type="button" data-new-instance>+ Ajouter</button></div><div data-instance-list></div></aside>
            <form class="dmdha-panel dmdha-form" data-instance-form>
                <input type="hidden" name="id">
                <div class="dmdha-form-grid">
                    <label><span>Nom</span><input name="name" required placeholder="Maison"></label>
                    <label><span>URL Home Assistant</span><input name="base_url" required placeholder="https://homeassistant.local:8123"></label>
                    <label class="dmdha-span-2"><span>Token longue durée</span><input name="token" type="password" autocomplete="new-password" placeholder="Vide = conserver le token enregistré"></label>
                    <label><span>Instance active</span><select name="enabled"><option value="1">Oui</option><option value="0">Non</option></select></label>
                    <label><span>Vérifier le certificat SSL</span><select name="verify_ssl"><option value="1">Oui</option><option value="0">Non</option></select></label>
                </div>
                <div class="dmdha-actions"><button type="button" data-test-instance>Tester</button><button type="submit">Enregistrer</button><button type="button" data-delete-instance class="dmdha-danger">Supprimer</button></div>
                <p class="dmdha-muted">Le token n’est jamais partagé avec les autres utilisateurs et reste chiffré dans le profil du propriétaire.</p>
                <div class="dmdha-window-msg" data-instance-msg></div>
            </form>
        </div>
    </section>

    <section class="dmdha-tab" data-tab="entities">
        <div class="dmdha-entity-toolbar">
            <div class="dmdha-entity-toolbar-main">
                <label><span>Instance Home Assistant</span><select data-entity-instance></select></label>
                <div class="dmdha-actions dmdha-actions-inline"><button type="button" data-discover>Découvrir / actualiser</button><button type="button" data-save-entities>Enregistrer la sélection</button></div>
            </div>
            <div class="dmdha-entity-toolbar-filters">
                <label class="dmdha-search-field"><span>Recherche</span><input type="search" data-entity-search placeholder="Nom, ID, catégorie, intégration…"></label>
                <label><span>Nature</span><select data-entity-scope aria-label="Type d’entités"><option value="primary">Périphériques principaux</option><option value="technical">Entités techniques</option><option value="all">Toutes les entités</option></select></label>
                <label><span>Sélection</span><select data-entity-selection><option value="all">Tous</option><option value="selected">Sélectionnés uniquement</option><option value="unselected">Non sélectionnés uniquement</option></select></label>
            </div>
            <div class="dmdha-entity-toolbar-actions">
                <label class="dmdha-select-all"><input type="checkbox" data-select-all disabled><span>Tout sélectionner dans la vue</span></label>
                <button type="button" data-clean-technical>Retirer les techniques</button>
                <button type="button" data-expand-entities>Tout ouvrir</button>
                <button type="button" data-collapse-entities>Tout fermer</button>
            </div>
        </div>
        <div class="dmdha-summary dmdha-summary-5"><article><span>Détectés</span><strong data-discovered-count>0</strong></article><article><span>Sélectionnés</span><strong data-selected-count>0</strong></article><article><span>Visibles</span><strong data-visible-count>0</strong></article><article><span>Catégories</span><strong data-family-count>0</strong></article><article><span>Techniques</span><strong data-technical-count>0</strong></article></div>
        <p class="dmdha-muted dmdha-entity-hint">Les catégories sont repliées par défaut. Ouvre uniquement la famille puis le type dont tu as besoin.</p>
        <div class="dmdha-entity-catalog" data-entity-catalog><div class="dmdha-empty">Choisis une instance puis lance la découverte.</div></div>
    </section>

    <section class="dmdha-tab" data-tab="shares">
        <div class="dmdha-share-layout">
            <form class="dmdha-panel dmdha-form" data-share-form>
                <h3>Partager une instance</h3>
                <label><span>Instance</span><select name="instance_id" data-share-instance></select></label>
                <label><span>Utilisateur</span><select name="grantee" data-grantee><option value="*">Tous les utilisateurs</option></select></label>
                <div class="dmdha-rights" data-rights></div>
                <div class="dmdha-actions"><button type="submit">Enregistrer ce partage</button><button type="button" data-share-all>Appliquer à toutes mes instances</button></div>
                <div class="dmdha-window-msg" data-share-msg></div>
            </form>
            <div class="dmdha-panel"><h3>Partages existants</h3><div data-share-list></div></div>
        </div>
    </section>

    <section class="dmdha-tab" data-tab="presets">
        <div class="dmdha-summary"><article><span>Version active</span><strong data-preset-version>-</strong></article><article><span>Presets</span><strong data-preset-total>0</strong></article><article><span>Familles</span><strong data-preset-families>0</strong></article></div>
        <p class="dmdha-muted" data-preset-meta></p>
        <p class="dmdha-muted">Le catalogue contient les types que DMD-Ha.V2 sait reconnaître. Un preset présent ici ne signifie pas que ce périphérique existe dans ton Home Assistant : seuls les périphériques réellement découverts et sélectionnés apparaissent dans le module.</p>
        <div class="dmdha-panel dmdha-form">
            <h3>Mise à jour des presets</h3>
            <label><span>URL du catalog.json</span><input data-preset-source placeholder="https://.../catalog.json"></label>
            <div class="dmdha-actions"><button type="button" data-preset-save-source>Enregistrer l’URL</button><button type="button" data-preset-check>Vérifier</button><button type="button" data-preset-update>Installer la mise à jour</button><button type="button" data-preset-rollback>Version précédente</button><button type="button" data-preset-restore>Presets intégrés</button></div>
            <p class="dmdha-muted">Une mise à jour est téléchargée dans un dossier temporaire, validée intégralement (100 presets minimum, familles cohérentes, clés uniques), puis activée. Le catalogue intégré au module reste toujours disponible en secours.</p>
            <div class="dmdha-window-msg" data-preset-msg></div>
        </div>
        <div class="dmdha-panel"><h3>Classement du catalogue actif</h3><div class="dmdha-family-table" data-preset-family-list></div></div>
    </section>

    <section class="dmdha-tab" data-tab="notifications">
        <div class="dmdha-subbar"><select data-notif-instance></select></div>
        <form class="dmdha-panel dmdha-form" data-notif-form>
            <h3>Notifications de l’instance</h3>
            <div class="dmdha-check-grid">
                <label><input type="checkbox" name="instance_offline"> Instance inaccessible</label>
                <label><input type="checkbox" name="instance_restored"> Instance rétablie</label>
                <label><input type="checkbox" name="entity_unavailable"> Périphérique indisponible</label>
                <label><input type="checkbox" name="entity_restored"> Périphérique rétabli</label>
                <label><input type="checkbox" name="battery_low"> Batterie faible</label>
                <label><input type="checkbox" name="security_alert"> Fumée / CO / gaz / fuite / sécurité</label>
            </div>
            <div class="dmdha-actions"><button type="submit">Enregistrer les notifications</button></div><div class="dmdha-window-msg" data-notif-msg></div>
        </form>
    </section>

    <section class="dmdha-tab" data-tab="logs">
        <div class="dmdha-subbar"><button type="button" data-load-logs>Actualiser les logs</button></div><div class="dmdha-log-list" data-log-list><div class="dmdha-empty">Charge le journal pour afficher les dernières actions.</div></div>
    </section>
    <div class="dmdha-toast" data-toast hidden></div>
</section>
<script>
(function(){
const root=document.getElementById(<?= json_encode($uid) ?>);if(!root||root.dataset.ready==='1')return;root.dataset.ready='1';const apiUrl=root.dataset.api;let csrf='',instances=[],users=[],shares=[],rightCatalog={},presetStatus={},permissions={},isSuperadmin=false,discovered=[],selected=new Set();
const q=(s,c=root)=>(c||root).querySelector(s),qa=(s,c=root)=>Array.from((c||root).querySelectorAll(s));const esc=v=>String(v==null?'':v).replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
const url=(action,params={})=>{const u=new URL(apiUrl,location.href);u.searchParams.set('action',action);Object.keys(params).forEach(k=>u.searchParams.set(k,params[k]));return u.toString();};
async function get(action,params={}){const r=await fetch(url(action,params),{credentials:'same-origin',cache:'no-store'}),t=await r.text();let j;try{j=JSON.parse(t)}catch(e){throw new Error('Réponse API invalide : '+t.slice(0,180))}if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));return j;}
async function post(action,data={}){const r=await fetch(apiUrl,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-DMDHA-CSRF':csrf},body:JSON.stringify(Object.assign({},data,{action,csrf}))}),t=await r.text();let j;try{j=JSON.parse(t)}catch(e){throw new Error('Réponse API invalide : '+t.slice(0,180))}if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));return j;}
function toast(m){const e=q('[data-toast]');e.textContent=m;e.hidden=false;clearTimeout(e._t);e._t=setTimeout(()=>e.hidden=true,3000)}function notice(m){const e=q('[data-notice]');e.textContent=m||'';e.hidden=!m}
function applyPermissions(){const rules={instances:'instance.manage',entities:'instance.manage',shares:'share.manage',presets:'preset.manage',notifications:'instance.manage',logs:'logs.view'};Object.keys(rules).forEach(tab=>{const allowed=permissions[rules[tab]]===true&&(tab!=='shares'||isSuperadmin);const b=q('[data-tab-btn="'+tab+'"]'),s=q('[data-tab="'+tab+'"]');if(b)b.hidden=!allowed;if(s)s.hidden=!allowed;});const active=q('[data-tab-btn].is-active:not([hidden])');if(!active){const first=qa('[data-tab-btn]').find(b=>!b.hidden);if(first){qa('[data-tab-btn]').forEach(b=>b.classList.toggle('is-active',b===first));qa('[data-tab]').forEach(s=>s.classList.toggle('is-active',s.dataset.tab===first.dataset.tab));}}}function owned(id){return instances.find(i=>i.id===id)||null}function currentFormId(){return q('[data-instance-form] [name="id"]').value}
function activateTab(name){qa('[data-tab-btn]').forEach(b=>b.classList.toggle('is-active',b.dataset.tabBtn===name));qa('[data-tab]').forEach(p=>p.classList.toggle('is-active',p.dataset.tab===name));if(name==='logs')loadLogs();}
qa('[data-tab-btn]').forEach(b=>b.addEventListener('click',()=>activateTab(b.dataset.tabBtn)));
function fillInstanceSelects(){const opts=instances.length?instances.map(i=>`<option value="${esc(i.id)}">${esc(i.name)}</option>`).join(''):'<option value="">Aucune instance</option>';['[data-entity-instance]','[data-share-instance]','[data-notif-instance]'].forEach(sel=>{const e=q(sel),old=e.value;e.innerHTML=opts;if(instances.some(i=>i.id===old))e.value=old;});renderNotifForm();}
function renderInstanceList(){const box=q('[data-instance-list]');box.innerHTML=instances.length?instances.map(i=>`<button type="button" class="dmdha-side-item ${currentFormId()===i.id?'is-active':''}" data-edit-instance="${esc(i.id)}"><strong>${esc(i.name)}</strong><small>${esc(i.base_url)}</small><span>${i.enabled?'Actif':'Inactif'} · ${i.entities.length} périphérique(s)</span></button>`).join(''):'<div class="dmdha-empty">Aucune instance.</div>';}
function editInstance(id){const i=owned(id),f=q('[data-instance-form]');if(!i)return;f.elements.id.value=i.id;f.elements.name.value=i.name;f.elements.base_url.value=i.base_url;f.elements.token.value='';f.elements.enabled.value=i.enabled?'1':'0';f.elements.verify_ssl.value=i.verify_ssl?'1':'0';q('[data-delete-instance]').disabled=false;renderInstanceList();}
function newInstance(){const f=q('[data-instance-form]');f.reset();f.elements.id.value='';f.elements.enabled.value='1';f.elements.verify_ssl.value='1';q('[data-delete-instance]').disabled=true;renderInstanceList();}
q('[data-instance-list]').addEventListener('click',e=>{const b=e.target.closest('[data-edit-instance]');if(b)editInstance(b.dataset.editInstance)});q('[data-new-instance]').addEventListener('click',newInstance);
q('[data-instance-form]').addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget,m=q('[data-instance-msg]');try{const data={id:f.elements.id.value,name:f.elements.name.value,base_url:f.elements.base_url.value,token:f.elements.token.value,enabled:f.elements.enabled.value==='1',verify_ssl:f.elements.verify_ssl.value==='1'};m.textContent='Enregistrement…';const j=await post('instance_save',data);await bootstrap(false);editInstance(j.instance.id);m.textContent='Instance enregistrée.';toast('Instance enregistrée');}catch(err){m.textContent=err.message}});
q('[data-test-instance]').addEventListener('click',async()=>{const f=q('[data-instance-form]'),m=q('[data-instance-msg]');try{m.textContent='Test en cours…';const j=await post('instance_test',{id:f.elements.id.value,base_url:f.elements.base_url.value,token:f.elements.token.value,verify_ssl:f.elements.verify_ssl.value==='1'});m.textContent='OK · '+(j.info.location_name||'Home Assistant')+(j.info.version?' · '+j.info.version:'');}catch(err){m.textContent=err.message}});
q('[data-delete-instance]').addEventListener('click',async()=>{const id=currentFormId();if(!id||!confirm('Supprimer cette instance Home Assistant et ses partages ?'))return;const m=q('[data-instance-msg]');try{await post('instance_delete',{id});await bootstrap(false);newInstance();m.textContent='Instance supprimée.';}catch(err){m.textContent=err.message}});
function displayMeta(e){const p=(e&&e.preset)||{},d=(e&&e.display)||{};return {family_key:d.family_key||p.family_key||'other',family_label:d.family_label||p.family_label||'Autres',family_icon:d.family_icon||p.family_icon||'⌂',family_order:Number(d.family_order??p.family_order??999),type:d.group_type_key||p.type||'generic',type_label:d.group_type_label||p.label||'Périphérique',type_icon:d.group_type_icon||p.icon||'⌂',device_type_key:d.device_type_key||p.type||'generic',device_type_label:d.device_type_label||p.label||'Périphérique',device_type_icon:d.device_type_icon||p.icon||'⌂',device_name:d.device_name||e.device_name||'',device_group_key:d.device_group_key||'',device_group_label:d.device_group_label||'',device_group_icon:d.device_group_icon||'',device_group:d.device_group===true,metric_order:Number(d.metric_order??500)};}
function entityScopeMatch(e){const scope=q('[data-entity-scope]').value;if(scope==='all')return true;if(scope==='technical')return e.technical===true;return e.technical!==true;}
function entitySelectionMatch(e){const mode=q('[data-entity-selection]').value;if(mode==='selected')return selected.has(e.entity_id);if(mode==='unselected')return !selected.has(e.entity_id);return true;}
function entitySearchMatch(e){const filter=q('[data-entity-search]').value.trim().toLowerCase();if(!filter)return true;const d=displayMeta(e);return (e.friendly_name+' '+e.entity_id+' '+e.preset.label+' '+e.preset.family_label+' '+d.type_label+' '+d.family_label+' '+(e.integration||'')+' '+(d.device_name||'')+' '+(e.manufacturer||'')+' '+(e.model||'')).toLowerCase().includes(filter);}
function visibleEntities(){return discovered.filter(e=>entityScopeMatch(e)&&entitySelectionMatch(e)&&entitySearchMatch(e));}
function updateSelectAll(){const c=q('[data-select-all]');if(!c)return;const items=visibleEntities(),ids=items.map(e=>e.entity_id),count=ids.filter(id=>selected.has(id)).length;c.disabled=ids.length===0;c.checked=ids.length>0&&count===ids.length;c.indeterminate=count>0&&count<ids.length;c.title=ids.length?(count+' / '+ids.length+' entités visibles sélectionnées'):'Aucune entité dans ce filtre';}
function entityPickHtml(e){const d=displayMeta(e),details=[e.entity_id,e.integration||'Home Assistant',e.state+(e.unit?' '+e.unit:'')];if(d.device_name)details.push(d.device_name);if(e.manufacturer||e.model)details.push([e.manufacturer,e.model].filter(Boolean).join(' '));if(e.technical)details.push('technique');return '<label class="'+(e.technical?'is-technical':'')+'"><input type="checkbox" data-entity-check="'+esc(e.entity_id)+'" '+(selected.has(e.entity_id)?'checked':'')+'><span><strong>'+esc(e.friendly_name)+'</strong><small>'+esc(details.join(' · '))+'</small><em class="dmdha-device-type-badge">'+esc(d.device_type_icon)+' '+esc(d.device_type_label)+'</em></span></label>';}
function renderEntities(){
    const catalog=q('[data-entity-catalog]'),openFamilies=new Set(qa('details.dmdha-family[open]',catalog).map(d=>d.dataset.familyKey)),openTypes=new Set(qa('details.dmdha-type[open]',catalog).map(d=>d.dataset.typeKey)),openDevices=new Set(qa('details.dmdha-device[open]',catalog).map(d=>d.dataset.deviceKey));
    const list=visibleEntities(),technicalCount=discovered.filter(e=>e.technical===true).length;
    const familyKeys=new Set(list.map(e=>displayMeta(e).family_key));
    q('[data-discovered-count]').textContent=discovered.length;q('[data-selected-count]').textContent=selected.size;q('[data-visible-count]').textContent=list.length;q('[data-family-count]').textContent=familyKeys.size;q('[data-technical-count]').textContent=technicalCount;updateSelectAll();
    if(!list.length){catalog.innerHTML='<div class="dmdha-empty">Aucun périphérique pour ce filtre.</div>';return;}
    const fam={};list.forEach(e=>{const d=displayMeta(e);if(!fam[d.family_key])fam[d.family_key]={label:d.family_label,icon:d.family_icon,order:d.family_order,types:{},items:[]};fam[d.family_key].items.push(e);if(!fam[d.family_key].types[d.type])fam[d.family_key].types[d.type]={label:d.type_label,icon:d.type_icon,items:[],devices:{}};const g=fam[d.family_key].types[d.type];if(d.device_group&&d.device_group_key){if(!g.devices[d.device_group_key])g.devices[d.device_group_key]={label:d.device_group_label||d.device_name||d.type_label,icon:d.device_group_icon||d.type_icon,items:[]};g.devices[d.device_group_key].items.push(e);}else g.items.push(e)});
    const searching=q('[data-entity-search]').value.trim()!=='';let html='';
    Object.keys(fam).sort((a,b)=>(fam[a].order||999)-(fam[b].order||999)||fam[a].label.localeCompare(fam[b].label)).forEach(k=>{const f=fam[k],fSel=f.items.filter(e=>selected.has(e.entity_id)).length,fOpen=searching||openFamilies.has(k);html+='<details class="dmdha-family" data-family-key="'+esc(k)+'" '+(fOpen?'open':'')+'><summary><span class="dmdha-family-title"><span>'+esc(f.icon)+'</span><strong>'+esc(f.label)+'</strong></span><span class="dmdha-family-count"><b>'+fSel+'</b> / '+f.items.length+' sélectionnés</span></summary><div class="dmdha-family-body">';
        Object.keys(f.types).sort((a,b)=>f.types[a].label.localeCompare(f.types[b].label)).forEach(t=>{const g=f.types[t],allItems=g.items.concat(...Object.values(g.devices).map(d=>d.items)),typeKey=k+'::'+t,gSel=allItems.filter(e=>selected.has(e.entity_id)).length,gOpen=searching||openTypes.has(typeKey);g.items.sort((a,b)=>(selected.has(b.entity_id)?1:0)-(selected.has(a.entity_id)?1:0)||a.friendly_name.localeCompare(b.friendly_name));html+='<details class="dmdha-type" data-type-key="'+esc(typeKey)+'" '+(gOpen?'open':'')+'><summary><span><strong>'+esc(g.icon)+' '+esc(g.label)+'</strong></span><small>'+gSel+' / '+allItems.length+'</small></summary>';
            if(g.items.length)html+='<div class="dmdha-entity-picks">'+g.items.map(entityPickHtml).join('')+'</div>';
            Object.keys(g.devices).sort((a,b)=>String(g.devices[a].label).localeCompare(String(g.devices[b].label))).forEach(dk=>{const dg=g.devices[dk],deviceKey=typeKey+'::'+dk,dSel=dg.items.filter(e=>selected.has(e.entity_id)).length,dOpen=searching||openDevices.has(deviceKey);dg.items.sort((a,b)=>(selected.has(b.entity_id)?1:0)-(selected.has(a.entity_id)?1:0)||displayMeta(a).metric_order-displayMeta(b).metric_order||a.friendly_name.localeCompare(b.friendly_name));html+='<details class="dmdha-device" data-device-key="'+esc(deviceKey)+'" '+(dOpen?'open':'')+'><summary><span><strong>'+esc(dg.icon)+' '+esc(dg.label)+'</strong></span><small>'+dSel+' / '+dg.items.length+'</small></summary><div class="dmdha-entity-picks">'+dg.items.map(entityPickHtml).join('')+'</div></details>';});
            html+='</details>';});html+='</div></details>';});catalog.innerHTML=html;
}
q('[data-discover]').addEventListener('click',async()=>{const id=q('[data-entity-instance]').value;if(!id)return;notice('Découverte Home Assistant…');try{const j=await get('discover',{instance_ref:(owned(id)||{}).ref||''});discovered=j.entities||[];selected=new Set((owned(id)||{entities:[]}).entities||[]);renderEntities();notice('');}catch(err){notice(err.message)}});
q('[data-entity-search]').addEventListener('input',renderEntities);q('[data-entity-scope]').addEventListener('change',renderEntities);q('[data-entity-selection]').addEventListener('change',renderEntities);
q('[data-expand-entities]').addEventListener('click',()=>qa('details',q('[data-entity-catalog]')).forEach(d=>d.open=true));q('[data-collapse-entities]').addEventListener('click',()=>qa('details',q('[data-entity-catalog]')).forEach(d=>d.open=false));
q('[data-select-all]').addEventListener('change',e=>{const checked=e.currentTarget.checked;visibleEntities().forEach(item=>{if(checked)selected.add(item.entity_id);else selected.delete(item.entity_id)});renderEntities();});
q('[data-clean-technical]').addEventListener('click',()=>{discovered.filter(e=>e.technical===true).forEach(e=>selected.delete(e.entity_id));renderEntities();toast('Entités techniques retirées de la sélection');});
q('[data-entity-catalog]').addEventListener('change',e=>{const c=e.target.closest('[data-entity-check]');if(!c)return;c.checked?selected.add(c.dataset.entityCheck):selected.delete(c.dataset.entityCheck);if(q('[data-entity-selection]').value!=='all')renderEntities();else{q('[data-selected-count]').textContent=selected.size;updateSelectAll();const family=c.closest('details.dmdha-family'),type=c.closest('details.dmdha-type');if(family){const badge=q('.dmdha-family-count',family),checks=qa('[data-entity-check]',family),n=checks.filter(x=>x.checked).length;if(badge)badge.innerHTML='<b>'+n+'</b> / '+checks.length+' sélectionnés';}if(type){const badge=type.querySelector('summary small'),checks=qa('[data-entity-check]',type),n=checks.filter(x=>x.checked).length;if(badge)badge.textContent=n+' / '+checks.length;}}});
q('[data-entity-instance]').addEventListener('change',()=>{discovered=[];selected=new Set((owned(q('[data-entity-instance]').value)||{entities:[]}).entities||[]);renderEntities()});
q('[data-save-entities]').addEventListener('click',async()=>{const id=q('[data-entity-instance]').value;if(!id)return;try{await post('entities_save',{id,entities:Array.from(selected)});await bootstrap(false);toast('Sélection enregistrée');}catch(err){notice(err.message)}});
function renderRights(){q('[data-rights]').innerHTML=Object.keys(rightCatalog).map(k=>`<label><input type="checkbox" value="${esc(k)}" data-right ${['instance.view','entity.view'].includes(k)?'checked disabled':''}><span>${esc(rightCatalog[k])}</span></label>`).join('')}function chosenRights(){const s=new Set(['instance.view','entity.view']);qa('[data-right]').forEach(c=>{if(c.checked)s.add(c.value)});return Array.from(s)}
function renderUsers(){q('[data-grantee]').innerHTML='<option value="*">Tous les utilisateurs</option>'+users.map(u=>`<option value="${esc(u.email)}">${esc(u.label)} · ${esc(u.email)} · ${esc(u.role||'user')}</option>`).join('')}
function renderShares(){const box=q('[data-share-list]');box.innerHTML=shares.length?shares.map(g=>{const inst=owned(g.instance_id);return `<div class="dmdha-share-row"><div><strong>${esc(inst?inst.name:g.instance_id)}</strong><small>${esc(g.grantee==='*'?'Tous les utilisateurs':g.grantee)}</small><span>${(g.rights||[]).map(r=>esc(rightCatalog[r]||r)).join(' · ')}</span></div><button type="button" data-remove-share="${esc(g.instance_id)}" data-grantee="${esc(g.grantee)}">Retirer</button></div>`}).join(''):'<div class="dmdha-empty">Aucun partage.</div>'}
q('[data-share-form]').addEventListener('submit',async e=>{e.preventDefault();const m=q('[data-share-msg]');try{await post('share_save',{instance_id:q('[data-share-instance]').value,grantee:q('[data-grantee]').value,rights:chosenRights()});await bootstrap(false);m.textContent='Partage enregistré.';toast('Partage enregistré');}catch(err){m.textContent=err.message}});q('[data-share-all]').addEventListener('click',async()=>{const m=q('[data-share-msg]');try{await post('share_apply_all',{grantee:q('[data-grantee]').value,rights:chosenRights()});await bootstrap(false);m.textContent='Partage appliqué à toutes les instances.';}catch(err){m.textContent=err.message}});q('[data-share-list]').addEventListener('click',async e=>{const b=e.target.closest('[data-remove-share]');if(!b)return;try{await post('share_delete',{instance_id:b.dataset.removeShare,grantee:b.dataset.grantee});await bootstrap(false);toast('Partage retiré');}catch(err){notice(err.message)}});
function renderPresets(){q('[data-preset-version]').textContent=presetStatus.active_version||'-';q('[data-preset-total]').textContent=presetStatus.active_total||0;q('[data-preset-families]').textContent=(presetStatus.families||[]).length;q('[data-preset-source]').value=presetStatus.source_url||'';q('[data-preset-meta]').textContent='Intégrés : '+(presetStatus.bundled_version||'-')+' · précédent : '+(presetStatus.backup_version||'aucun')+(presetStatus.using_update?' · catalogue mis à jour actif':' · catalogue intégré actif');q('[data-preset-family-list]').innerHTML=(presetStatus.families||[]).map(f=>`<div><span>${esc(f.label||f.key)}</span><strong>${esc(f.count||0)}</strong><small>${esc(f.file||'')}</small></div>`).join('')||'<div class="dmdha-empty">Catalogue indisponible.</div>'}
async function presetAction(action){const m=q('[data-preset-msg]'),source=q('[data-preset-source]').value.trim();try{m.textContent='Action en cours…';const j=await post(action,{source_url:source});if(j.preset_status)presetStatus=j.preset_status;if(j.remote)m.textContent='Disponible : '+(j.remote.catalog_version||'?')+' · '+(j.remote.total_presets||0)+' presets · '+(j.remote.families||0)+' familles';else m.textContent=j.message||'OK';renderPresets();}catch(err){m.textContent=err.message}}
q('[data-preset-save-source]').addEventListener('click',()=>presetAction('preset_source_save'));q('[data-preset-check]').addEventListener('click',()=>presetAction('preset_check'));q('[data-preset-update]').addEventListener('click',()=>{if(confirm('Installer ce catalogue de presets après validation complète ?'))presetAction('preset_update')});q('[data-preset-rollback]').addEventListener('click',()=>{if(confirm('Restaurer le catalogue de presets précédent ?'))presetAction('preset_rollback')});q('[data-preset-restore]').addEventListener('click',()=>{if(confirm('Revenir au catalogue intégré à DMD-Ha.V2 ?'))presetAction('preset_restore')});
function renderNotifForm(){const id=q('[data-notif-instance]').value,i=owned(id),f=q('[data-notif-form]');if(!i)return;const n=i.notifications||{};['instance_offline','instance_restored','entity_unavailable','entity_restored','battery_low','security_alert'].forEach(k=>{if(f.elements[k])f.elements[k].checked=n[k]!==false})}q('[data-notif-instance]').addEventListener('change',renderNotifForm);q('[data-notif-form]').addEventListener('submit',async e=>{e.preventDefault();const f=e.currentTarget,id=q('[data-notif-instance]').value,n={};['instance_offline','instance_restored','entity_unavailable','entity_restored','battery_low','security_alert'].forEach(k=>n[k]=!!f.elements[k].checked);try{await post('notifications_save',{id,notifications:n});await bootstrap(false);q('[data-notif-msg]').textContent='Notifications enregistrées.';}catch(err){q('[data-notif-msg]').textContent=err.message}});
async function loadLogs(){const box=q('[data-log-list]');box.innerHTML='<div class="dmdha-empty">Chargement…</div>';try{const j=await get('logs',{all:1});box.innerHTML=(j.logs||[]).map(l=>`<article><time>${esc(l.date_iso||'')}</time><strong>${esc(l.action||'')}</strong><span>${esc(l.user||'')}</span><small>${esc(l.target||'')} · ${esc(l.result||'')}</small><code>${esc(JSON.stringify(l.details||{}))}</code></article>`).join('')||'<div class="dmdha-empty">Aucun log.</div>'}catch(err){box.innerHTML='<div class="dmdha-empty">'+esc(err.message)+'</div>'}}q('[data-load-logs]').addEventListener('click',loadLogs);
async function bootstrap(first=true){notice('');try{const j=await get('cfg_bootstrap');csrf=j.csrf||csrf;instances=j.instances||[];users=j.users||[];shares=j.shares||[];rightCatalog=j.share_right_catalog||{};presetStatus=j.preset_status||{};permissions=j.permissions||{};isSuperadmin=j.is_superadmin===true;applyPermissions();fillInstanceSelects();renderInstanceList();renderUsers();renderRights();renderShares();renderPresets();if(first&&permissions['instance.manage']){instances[0]?editInstance(instances[0].id):newInstance();selected=new Set((instances[0]||{entities:[]}).entities||[]);}}catch(err){notice(err.message)}}
q('[data-reload]').addEventListener('click',()=>bootstrap(false));bootstrap(true);
})();
</script>
