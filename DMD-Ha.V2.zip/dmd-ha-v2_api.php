<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/dmd-ha-v2_lib.php';
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function dmdha_api_json($ok, $message, $extra, $status) {
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    if ($status) http_response_code((int)$status);
    $payload = array_merge(array('ok'=>(bool)$ok,'message'=>(string)$message), is_array($extra)?$extra:array());
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
}
function dmdha_api_owned_instance($id) {
    $owner=dmdha_current_email(); $item=dmdha_find_instance($owner,$id); if(!$item) throw new RuntimeException('Instance Home Assistant introuvable.'); return $item;
}
function dmdha_api_save_one_instance($data) {
    dmdha_require_permission('instance.manage'); $owner=dmdha_current_email(); $items=dmdha_load_instances($owner);
    $id=dmdha_clean_id(isset($data['id'])?$data['id']:''); $existing=null; $existingIndex=-1;
    if($id!=='') foreach($items as $idx=>$it) if($it['id']===$id){$existing=$it;$existingIndex=$idx;break;}
    $name=trim((string)(isset($data['name'])?$data['name']:'')); $base=dmdha_clean_url(isset($data['base_url'])?$data['base_url']:''); $enabled=!isset($data['enabled'])||!empty($data['enabled']); $verify=!isset($data['verify_ssl'])||!empty($data['verify_ssl']);
    if($name==='') throw new InvalidArgumentException('Nom de l’instance obligatoire.');
    if($id==='') $id='ha-'.substr(bin2hex(random_bytes(8)),0,12);
    $item=$existing?$existing:array('id'=>$id,'owner'=>$owner,'entities'=>array(),'notifications'=>array(),'created_at'=>dmdha_now_iso());
    $item['id']=$id; $item['owner']=$owner; $item['name']=$name; $item['base_url']=$base; $item['enabled']=$enabled; $item['verify_ssl']=$verify; $item['updated_at']=dmdha_now_iso();
    $token=trim((string)(isset($data['token'])?$data['token']:'')); if($token!=='') $item['token_enc']=dmdha_encrypt($owner,$token); elseif(!$existing) throw new InvalidArgumentException('Token Home Assistant obligatoire pour une nouvelle instance.');
    if(isset($data['notifications'])&&is_array($data['notifications'])) $item['notifications']=$data['notifications'];
    $item=dmdha_normalize_instance($item,$owner); if($existingIndex>=0)$items[$existingIndex]=$item; else $items[]=$item; if(!dmdha_save_instances($owner,$items)) throw new RuntimeException('Impossible d’enregistrer l’instance Home Assistant dans '.dmdha_instances_file($owner).'.');
    dmdha_log($existing?'instance.update':'instance.create',dmdha_instance_ref($owner,$id),'success',array('name'=>$name,'base_url'=>$base,'enabled'=>$enabled,'verify_ssl'=>$verify),$owner);
    return dmdha_public_instance($item,$owner,array_keys(dmdha_share_right_catalog()));
}
function dmdha_api_grants_for_owner_instance($owner,$instanceId) {
    $data=dmdha_load_shares(); $out=array(); foreach($data['grants'] as $g) if(is_array($g)&&strcasecmp((string)(isset($g['owner'])?$g['owner']:''),$owner)===0&&(string)(isset($g['instance_id'])?$g['instance_id']:'')===(string)$instanceId)$out[]=$g; return $out;
}

try {
    dmdha_require_login();
    $action=strtolower(trim((string)(isset($_GET['action'])?$_GET['action']:(isset($_POST['action'])?$_POST['action']:''))));
    $input=dmdha_input(); if($action===''&&isset($input['action']))$action=strtolower(trim((string)$input['action']));

    if($action==='camera_snapshot'||$action==='camera_stream') {
        dmdha_require_permission('camera.view'); $ref=isset($_GET['instance_ref'])?$_GET['instance_ref']:''; $entity=trim((string)(isset($_GET['entity_id'])?$_GET['entity_id']:'')); if($entity==='')throw new InvalidArgumentException('Caméra manquante.');
        if(!preg_match('/^camera\.[a-zA-Z0-9_]+$/',$entity))throw new InvalidArgumentException('Entité caméra invalide.');
        list($instance,$rights)=dmdha_instance_access($ref,'camera.view'); if(!in_array($entity,$instance['entities'],true))throw new RuntimeException('Caméra non sélectionnée dans cette instance.');
        if($action==='camera_stream'){dmdha_ha_stream_camera($instance,$entity);exit;}
        $bin=dmdha_ha_request($instance,'/api/camera_proxy/'.rawurlencode($entity),'GET',null,true);
        header('Content-Type: '.$bin['content_type']); header('Cache-Control: no-store'); echo $bin['body']; exit;
    }

    if($action==='bootstrap') {
        dmdha_require_permission('use'); $viewer=dmdha_current_email(); $preset=dmdha_preset_status();
        dmdha_api_json(true,'DMD-Ha.V2 prêt.',array('csrf'=>dmdha_csrf_token(),'instances'=>dmdha_effective_instances($viewer),'permissions'=>dmdha_permissions_snapshot(),'preset_status'=>$preset,'module'=>array('id'=>DMDHA_MODULE_ID,'version'=>DMDHA_MODULE_VERSION)),200);
    }
    if($action==='cfg_bootstrap') {
        $perms=dmdha_permissions_snapshot(); $canShareCfg=!empty($perms['share.manage'])&&dmdha_is_superadmin(); if(empty($perms['instance.manage'])&&!$canShareCfg&&empty($perms['preset.manage'])&&empty($perms['logs.view'])){http_response_code(403);throw new RuntimeException('Aucun droit de configuration DMD-Ha.V2.');}
        $viewer=dmdha_current_email(); $instances=array(); if(!empty($perms['instance.manage'])||(!empty($perms['share.manage'])&&dmdha_is_superadmin())) foreach(dmdha_load_instances($viewer) as $i)$instances[]=dmdha_public_instance($i,$viewer,array_keys(dmdha_share_right_catalog()));
        $users=array();$ownShares=array(); if(!empty($perms['share.manage'])&&dmdha_is_superadmin()){$users=dmdha_users();$shareData=dmdha_load_shares();foreach($shareData['grants'] as $g)if(is_array($g)&&strcasecmp((string)(isset($g['owner'])?$g['owner']:''),$viewer)===0)$ownShares[]=$g;}
        dmdha_api_json(true,'Configuration chargée.',array('csrf'=>dmdha_csrf_token(),'instances'=>$instances,'users'=>$users,'share_right_catalog'=>dmdha_share_right_catalog(),'shares'=>$ownShares,'permissions'=>$perms,'is_superadmin'=>dmdha_is_superadmin(),'preset_status'=>dmdha_preset_status()),200);
    }
    if($action==='states'||$action==='discover') {
        dmdha_require_permission($action==='discover'?'instance.manage':'entity.view'); $ref=isset($_GET['instance_ref'])?$_GET['instance_ref']:(isset($input['instance_ref'])?$input['instance_ref']:''); list($instance,$rights)=dmdha_instance_access($ref,'entity.view');
        if($action==='discover'&&strcasecmp($instance['owner'],dmdha_current_email())!==0)throw new RuntimeException('La découverte complète est réservée au propriétaire de l’instance.');
        try { $entities=$action==='discover'?dmdha_discover_for_instance($instance):dmdha_states_for_instance($instance,true); if($action==='states'){dmdha_track_instance_success($instance,$entities);$entities=dmdha_filter_entities_for_viewer($entities,$instance,$rights);} $resources=array(); foreach($entities as $e)$resources[]=dmdha_resource_for_entity($instance,$e); dmdha_api_json(true,count($entities).' périphérique(s).',array('instance'=>dmdha_public_instance($instance,dmdha_current_email(),$rights),'entities'=>$entities,'resources'=>$resources),200); }
        catch(Exception $e){ dmdha_track_instance_failure($instance,$e->getMessage()); dmdha_log('instance.read',dmdha_instance_ref($instance['owner'],$instance['id']),'error',array('error'=>$e->getMessage()),$instance['owner']); throw $e; }
    }
    if($action==='services') {
        dmdha_require_permission('entity.view'); $ref=isset($_GET['instance_ref'])?$_GET['instance_ref']:(isset($input['instance_ref'])?$input['instance_ref']:''); list($instance,$rights)=dmdha_instance_access($ref,'entity.view');
        $services=dmdha_services_for_instance($instance); dmdha_api_json(true,count($services).' service(s) Home Assistant.',array('services'=>$services),200);
    }
    if($action==='integrations') {
        dmdha_require_permission('entity.view'); $ref=isset($_GET['instance_ref'])?$_GET['instance_ref']:(isset($input['instance_ref'])?$input['instance_ref']:''); list($instance,$rights)=dmdha_instance_access($ref,'entity.view');
        $entities=dmdha_filter_entities_for_viewer(dmdha_discover_for_instance($instance),$instance,$rights); $groups=array(); foreach($entities as $e){$platform=trim((string)(isset($e['integration'])?$e['integration']:'home_assistant'));if($platform==='')$platform='home_assistant';if(!isset($groups[$platform]))$groups[$platform]=array('platform'=>$platform,'count'=>0,'types'=>array());$disp=isset($e['display'])&&is_array($e['display'])?$e['display']:array();$type=(string)(isset($disp['device_type_key'])?$disp['device_type_key']:$e['preset']['type']);$label=(string)(isset($disp['device_type_label'])?$disp['device_type_label']:$e['preset']['label']);$icon=(string)(isset($disp['device_type_icon'])?$disp['device_type_icon']:$e['preset']['icon']);$family=(string)(isset($disp['family_label'])?$disp['family_label']:$e['preset']['family_label']);if(!isset($groups[$platform]['types'][$type]))$groups[$platform]['types'][$type]=array('type'=>$type,'label'=>$label,'icon'=>$icon,'family'=>$family,'entities'=>array());$groups[$platform]['types'][$type]['entities'][]=array('entity_id'=>$e['entity_id'],'friendly_name'=>$e['friendly_name'],'state'=>$e['state'],'unit'=>$e['unit']);$groups[$platform]['count']++;}
        $out=array_values($groups); usort($out,function($a,$b){return strcasecmp($a['platform'],$b['platform']);}); dmdha_api_json(true,count($out).' intégration(s).',array('integrations'=>$out,'instance'=>dmdha_public_instance($instance,dmdha_current_email(),$rights)),200);
    }
    if($action==='instance_test') {
        dmdha_require_permission('instance.manage'); dmdha_require_csrf($input); $id=dmdha_clean_id(isset($input['id'])?$input['id']:''); $base=trim((string)(isset($input['base_url'])?$input['base_url']:'')); $token=trim((string)(isset($input['token'])?$input['token']:'')); $verify=!isset($input['verify_ssl'])||!empty($input['verify_ssl']);
        if($id!==''&&$token===''){ $ex=dmdha_api_owned_instance($id); $token=dmdha_instance_token($ex); if($base==='')$base=$ex['base_url']; }
        if($token==='')throw new InvalidArgumentException('Token obligatoire pour tester.'); $r=dmdha_test_connection_values($base,$token,$verify); dmdha_api_json(true,'Connexion Home Assistant réussie.',array('info'=>$r),200);
    }
    if($action==='instance_save') {
        dmdha_require_csrf($input); $saved=dmdha_api_save_one_instance($input); dmdha_api_json(true,'Instance enregistrée.',array('instance'=>$saved),200);
    }
    if($action==='instance_delete') {
        dmdha_require_permission('instance.manage'); dmdha_require_csrf($input); $id=dmdha_clean_id(isset($input['id'])?$input['id']:''); $owner=dmdha_current_email(); $instance=dmdha_api_owned_instance($id); $items=array(); foreach(dmdha_load_instances($owner) as $it)if($it['id']!==$id)$items[]=$it;
        $shares=dmdha_load_shares(); $keep=array(); $removedGrants=array(); foreach($shares['grants'] as $g){if(!is_array($g))continue;if(strcasecmp((string)$g['owner'],$owner)===0&&(string)$g['instance_id']===$id){$removedGrants[]=$g;continue;}$keep[]=$g;} $shares['grants']=$keep;
        if(!dmdha_save_instances($owner,$items)) throw new RuntimeException('Impossible de supprimer l’instance dans '.dmdha_instances_file($owner).'.');
        if(!dmdha_save_shares($shares)) throw new RuntimeException('Instance supprimée, mais impossible de mettre à jour le fichier des partages '.dmdha_shares_file().'.');
        foreach($removedGrants as $g)dmdha_notify_share_change($owner,(string)$g['grantee'],$instance,isset($g['rights'])?$g['rights']:array(),true);
        dmdha_log('instance.delete',dmdha_instance_ref($owner,$id),'success',array('name'=>$instance['name']),$owner); dmdha_api_json(true,'Instance supprimée.',array(),200);
    }
    if($action==='entities_save') {
        dmdha_require_permission('instance.manage'); dmdha_require_csrf($input); $id=dmdha_clean_id(isset($input['id'])?$input['id']:''); $entities=isset($input['entities'])&&is_array($input['entities'])?$input['entities']:array(); $owner=dmdha_current_email(); $items=dmdha_load_instances($owner); $found=false;
        foreach($items as $idx=>$it)if($it['id']===$id){$it['entities']=dmdha_selected_entities_from_legacy(array('entities'=>$entities));$it['updated_at']=dmdha_now_iso();$items[$idx]=$it;$found=true;break;} if(!$found)throw new RuntimeException('Instance introuvable.'); if(!dmdha_save_instances($owner,$items))throw new RuntimeException('Impossible d’enregistrer la sélection dans '.dmdha_instances_file($owner).'.'); dmdha_log('entities.selection',dmdha_instance_ref($owner,$id),'success',array('count'=>count($items[$idx]['entities'])),$owner); dmdha_api_json(true,'Périphériques sélectionnés enregistrés.',array('entities'=>$items[$idx]['entities']),200);
    }
    if($action==='notifications_save') {
        dmdha_require_permission('instance.manage'); dmdha_require_csrf($input); $id=dmdha_clean_id(isset($input['id'])?$input['id']:''); $settings=isset($input['notifications'])&&is_array($input['notifications'])?$input['notifications']:array(); $owner=dmdha_current_email(); $items=dmdha_load_instances($owner); $found=false;
        foreach($items as $idx=>$it)if($it['id']===$id){$it['notifications']=$settings;$it=dmdha_normalize_instance($it,$owner);$items[$idx]=$it;$found=true;break;} if(!$found)throw new RuntimeException('Instance introuvable.');if(!dmdha_save_instances($owner,$items))throw new RuntimeException('Impossible d’enregistrer les notifications dans '.dmdha_instances_file($owner).'.');dmdha_log('notifications.settings',dmdha_instance_ref($owner,$id),'success',array('settings'=>$items[$idx]['notifications']),$owner);dmdha_api_json(true,'Notifications mises à jour.',array('notifications'=>$items[$idx]['notifications']),200);
    }
    if($action==='share_save'||$action==='share_apply_all') {
        dmdha_require_permission('share.manage'); dmdha_require_superadmin(); dmdha_require_csrf($input); $owner=dmdha_current_email(); $grantee=trim((string)(isset($input['grantee'])?$input['grantee']:'')); if($grantee!=='*')$grantee=dmdha_safe_email($grantee); if($grantee===''||strcasecmp($grantee,$owner)===0)throw new InvalidArgumentException('Utilisateur de partage invalide.');
        if($grantee!=='*'){$known=false;foreach(dmdha_users() as $u)if(strcasecmp((string)$u['email'],$grantee)===0&&in_array((string)$u['role'],array('user','admin','superadmin'),true)){$known=true;break;}if(!$known)throw new InvalidArgumentException('Utilisateur DoMyDesk introuvable pour ce partage.');}
        $rights=dmdha_normalize_share_rights(isset($input['rights'])?$input['rights']:array()); $ids=array(); if($action==='share_apply_all'){foreach(dmdha_load_instances($owner) as $i)$ids[]=$i['id'];} else {$ids[]=dmdha_clean_id(isset($input['instance_id'])?$input['instance_id']:'');}
        $shares=dmdha_load_shares(); $changes=array(); foreach($ids as $id){$instance=dmdha_api_owned_instance($id);$updated=false;foreach($shares['grants'] as $k=>$g){if(is_array($g)&&strcasecmp((string)$g['owner'],$owner)===0&&(string)$g['instance_id']===$id&&strcasecmp((string)$g['grantee'],$grantee)===0){$shares['grants'][$k]['rights']=$rights;$shares['grants'][$k]['updated_at']=dmdha_now_iso();$updated=true;break;}}if(!$updated)$shares['grants'][]=array('owner'=>$owner,'instance_id'=>$id,'grantee'=>$grantee,'rights'=>$rights,'created_at'=>dmdha_now_iso(),'updated_at'=>dmdha_now_iso(),'created_by'=>$owner);$changes[]=array('instance'=>$instance,'updated'=>$updated);}
        if(!dmdha_save_shares($shares))throw new RuntimeException('Impossible d’enregistrer les partages dans '.dmdha_shares_file().'.');
        foreach($changes as $change){$instance=$change['instance'];dmdha_notify_share_change($owner,$grantee,$instance,$rights,false);dmdha_log('share.'.($change['updated']?'update':'create'),dmdha_instance_ref($owner,$instance['id']),'success',array('grantee'=>$grantee,'rights'=>$rights),$owner);}
        dmdha_api_json(true,$action==='share_apply_all'?'Partage appliqué à toutes les instances.':'Partage enregistré.',array('shares'=>$shares['grants']),200);
    }
    if($action==='share_delete') {
        dmdha_require_permission('share.manage'); dmdha_require_superadmin(); dmdha_require_csrf($input); $owner=dmdha_current_email(); $id=dmdha_clean_id(isset($input['instance_id'])?$input['instance_id']:''); $grantee=trim((string)(isset($input['grantee'])?$input['grantee']:'')); $instance=dmdha_api_owned_instance($id); $shares=dmdha_load_shares(); $keep=array(); $removed=false; $oldRights=array();
        foreach($shares['grants'] as $g){if(is_array($g)&&strcasecmp((string)$g['owner'],$owner)===0&&(string)$g['instance_id']===$id&&strcasecmp((string)$g['grantee'],$grantee)===0){$removed=true;$oldRights=isset($g['rights'])?$g['rights']:array();continue;}$keep[]=$g;} $shares['grants']=$keep;if(!dmdha_save_shares($shares))throw new RuntimeException('Impossible de mettre à jour les partages dans '.dmdha_shares_file().'.');if($removed)dmdha_notify_share_change($owner,$grantee,$instance,$oldRights,true);dmdha_log('share.delete',dmdha_instance_ref($owner,$id),'success',array('grantee'=>$grantee),$owner);dmdha_api_json(true,'Partage retiré.',array('shares'=>$shares['grants']),200);
    }
    if($action==='service_call') {
        dmdha_require_csrf($input); $ref=isset($input['instance_ref'])?$input['instance_ref']:''; $entityId=trim((string)(isset($input['entity_id'])?$input['entity_id']:'')); $service=trim((string)(isset($input['service'])?$input['service']:'')); $widget=trim((string)(isset($input['widget'])?$input['widget']:'power')); if(!preg_match('/^[a-z0-9_]+\.[a-z0-9_]+$/',$entityId)||!preg_match('/^[a-z0-9_]+\.[a-z0-9_]+$/',$service))throw new InvalidArgumentException('Commande invalide.');
        list($instance,$viewRights)=dmdha_instance_access($ref,'entity.view'); if(!in_array($entityId,$instance['entities'],true))throw new RuntimeException('Périphérique non sélectionné.'); $state=dmdha_find_entity_state($instance,$entityId); if(!$state)throw new RuntimeException('État du périphérique introuvable.'); $metaMap=dmdha_registry_metadata($instance,false); $meta=isset($metaMap[$entityId])&&is_array($metaMap[$entityId])?$metaMap[$entityId]:array(); $preset=dmdha_match_preset($state,$meta); $required=isset($preset['required_control'])?$preset['required_control']:'entity.control'; list($instance,$rights)=dmdha_instance_access($ref,$required);
        $allowed=null; foreach((array)(isset($preset['actions'])?$preset['actions']:array()) as $a){if(is_array($a)&&(string)(isset($a['service'])?$a['service']:'')===$service&&(string)(isset($a['widget'])?$a['widget']:'power')===$widget){$allowed=$a;break;}} if(!$allowed)throw new RuntimeException('Action non prévue par le preset '.$preset['label'].'.');
        $parts=explode('.',$service,2); $payload=dmdha_service_payload($entityId,$widget,isset($input['value'])?$input['value']:null,isset($input['extra'])&&is_array($input['extra'])?$input['extra']:array()); $resource=dmdha_resource_id($instance,$entityId); $friendly=trim((string)(isset($state['attributes']['friendly_name'])?$state['attributes']['friendly_name']:$entityId));
        try{$res=dmdha_ha_request($instance,'/api/services/'.$parts[0].'/'.$parts[1],'POST',$payload,false);dmdha_log('entity.control',$resource,'success',array('entity_id'=>$entityId,'name'=>$friendly,'instance_name'=>$instance['name'],'instance_ref'=>$ref,'preset'=>$preset['key'],'service'=>$service,'widget'=>$widget),$instance['owner']);}catch(Exception $e){dmdha_log('entity.control',$resource,'error',array('entity_id'=>$entityId,'name'=>$friendly,'instance_name'=>$instance['name'],'instance_ref'=>$ref,'preset'=>$preset['key'],'service'=>$service,'widget'=>$widget,'error'=>dmdha_substr($e->getMessage(),0,220)),$instance['owner']);throw $e;} dmdha_api_json(true,'Commande envoyée.',array('result'=>$res,'resource_id'=>$resource),200);
    }
    if($action==='logs') {
        dmdha_require_permission('logs.view'); $all=!empty($_GET['all']); $limit=$all?0:(isset($_GET['limit'])?(int)$_GET['limit']:150); dmdha_api_json(true,'Journal chargé.',array('logs'=>dmdha_read_logs($limit)),200);
    }
    if($action==='preset_status') { dmdha_require_permission('preset.manage'); dmdha_api_json(true,'État des presets.',array('preset_status'=>dmdha_preset_status()),200); }
    if($action==='preset_source_save') { dmdha_require_permission('preset.manage');dmdha_require_csrf($input);$cfg=dmdha_save_preset_source(isset($input['source_url'])?$input['source_url']:'');dmdha_log('presets.source','presets','success',array('source_url'=>$cfg['source_url']),dmdha_current_email());dmdha_api_json(true,'Source des presets enregistrée.',array('preset_status'=>dmdha_preset_status()),200); }
    if($action==='preset_check') { dmdha_require_permission('preset.manage');dmdha_require_csrf($input);$url=trim((string)(isset($input['source_url'])?$input['source_url']:dmdha_preset_status()['source_url']));if($url==='')throw new InvalidArgumentException('URL de catalogue requise.');$remote=dmdha_preset_check_remote($url);dmdha_api_json(true,'Catalogue distant accessible.',array('remote'=>$remote,'preset_status'=>dmdha_preset_status()),200); }
    if($action==='preset_update') { dmdha_require_permission('preset.manage');dmdha_require_csrf($input);$url=trim((string)(isset($input['source_url'])?$input['source_url']:dmdha_preset_status()['source_url']));if($url==='')throw new InvalidArgumentException('URL de catalogue requise.');$valid=dmdha_preset_install_remote($url);dmdha_log('presets.update','presets','success',array('catalog_version'=>isset($valid['catalog']['catalog_version'])?$valid['catalog']['catalog_version']:'','total'=>$valid['total']),dmdha_current_email());dmdha_api_json(true,'Presets mis à jour.',array('preset_status'=>dmdha_preset_status()),200); }
    if($action==='preset_rollback') { dmdha_require_permission('preset.manage');dmdha_require_csrf($input);$status=dmdha_preset_rollback();dmdha_log('presets.rollback','presets','success',$status,dmdha_current_email());dmdha_api_json(true,'Catalogue précédent restauré.',array('preset_status'=>$status),200); }
    if($action==='preset_restore') { dmdha_require_permission('preset.manage');dmdha_require_csrf($input);$status=dmdha_preset_restore_bundled();dmdha_log('presets.restore','presets','success',$status,dmdha_current_email());dmdha_api_json(true,'Presets intégrés restaurés.',array('preset_status'=>$status),200); }

    dmdha_api_json(false,'Action inconnue : '.$action,array(),404);
} catch (InvalidArgumentException $e) { dmdha_api_json(false,$e->getMessage(),array(),422); }
catch (RuntimeException $e) { dmdha_api_json(false,$e->getMessage(),array(),http_response_code()>=400?http_response_code():400); }
catch (Exception $e) { dmdha_api_json(false,'Erreur DMD-Ha.V2 : '.$e->getMessage(),array(),500); }
