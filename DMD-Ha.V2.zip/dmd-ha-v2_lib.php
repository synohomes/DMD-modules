<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!defined('DMDHA_MODULE_ID')) define('DMDHA_MODULE_ID', 'DMD-Ha.V2');
if (!defined('DMDHA_MODULE_VERSION')) define('DMDHA_MODULE_VERSION', '2.0.22');
if (!defined('DMDHA_MODULE_ROOT')) define('DMDHA_MODULE_ROOT', __DIR__);
if (!defined('DMDHA_DMD_ROOT')) {
    $r = realpath(__DIR__ . '/../..');
    define('DMDHA_DMD_ROOT', $r !== false ? $r : dirname(__DIR__, 2));
}
if (!defined('DMDHA_SYSTEM_ROOT')) define('DMDHA_SYSTEM_ROOT', DMDHA_DMD_ROOT . '/data/modules/' . DMDHA_MODULE_ID);
if (!defined('DMDHA_LOG_ROOT')) define('DMDHA_LOG_ROOT', DMDHA_DMD_ROOT . '/data/logs/' . DMDHA_MODULE_ID);
if (!defined('DMDHA_BUNDLED_PRESETS')) define('DMDHA_BUNDLED_PRESETS', DMDHA_MODULE_ROOT . '/presets');

$coreRuntime = DMDHA_DMD_ROOT . '/core/dmd_runtime.php';
if (is_file($coreRuntime)) {
    require_once $coreRuntime;
} else {
    foreach (array(
        DMDHA_DMD_ROOT . '/core/dmd_permissions.php',
        DMDHA_DMD_ROOT . '/core/dmd_system_services.php',
        DMDHA_DMD_ROOT . '/core/dmd_activity.php',
        DMDHA_DMD_ROOT . '/core/dmd_module_logs.php',
        DMDHA_DMD_ROOT . '/core/dmd_module_events.php'
    ) as $coreFile) {
        if (is_file($coreFile)) require_once $coreFile;
    }
}

function dmdha_now_iso() { return date('c'); }
function dmdha_substr($value,$start,$length) { $value=(string)$value; return function_exists('mb_substr') ? mb_substr($value,$start,$length,'UTF-8') : substr($value,$start,$length); }
function dmdha_lower($value) { $value=(string)$value; return function_exists('mb_strtolower') ? mb_strtolower($value,'UTF-8') : strtolower($value); }
function dmdha_current_email() {
    return trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : (isset($_SESSION['email']) ? $_SESSION['email'] : (isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''))));
}
function dmdha_current_role() {
    $r = isset($_SESSION['user']['role_system']) ? $_SESSION['user']['role_system'] : (isset($_SESSION['role_system']) ? $_SESSION['role_system'] : (isset($_SESSION['user']['role']) ? $_SESSION['user']['role'] : ''));
    return strtolower(trim((string)$r));
}
function dmdha_is_admin() { return in_array(dmdha_current_role(), array('admin','administrator','superadmin'), true); }
function dmdha_is_superadmin() { return dmdha_current_role() === 'superadmin'; }
function dmdha_require_superadmin() {
    dmdha_require_login();
    if (!dmdha_is_superadmin()) { http_response_code(403); throw new RuntimeException('Partage réservé aux superadmins.'); }
}
function dmdha_safe_email($email) {
    $email = trim((string)$email);
    if ($email === '' || strpos($email, '..') !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false || basename($email) !== $email) return '';
    return $email;
}
function dmdha_require_login() {
    if (dmdha_current_email() === '') { http_response_code(401); throw new RuntimeException('Connexion requise.'); }
}
function dmdha_permission($permission) {
    $permission = trim((string)$permission);
    if ($permission === '') return false;
    if (function_exists('dmd_current_user_has_module_permission')) {
        return (bool)dmd_current_user_has_module_permission(DMDHA_MODULE_ID, $permission);
    }
    if ($permission === 'use') return dmdha_current_email() !== '';
    return dmdha_is_admin();
}
function dmdha_user_permission($email, $permission) {
    $email = dmdha_safe_email($email);
    $permission = trim((string)$permission);
    if ($email === '' || $permission === '') return false;
    if (strcasecmp($email, dmdha_current_email()) === 0) return dmdha_permission($permission);
    if (function_exists('dmd_user_has_module_permission')) {
        try { return (bool)dmd_user_has_module_permission($email, DMDHA_MODULE_ID, $permission); }
        catch (Exception $e) { return false; }
    }
    if (function_exists('dmd_effective_module_access')) {
        try {
            $access = dmd_effective_module_access($email, DMDHA_MODULE_ID);
            if (empty($access['allowed'])) return false;
            if ($permission === 'use' || $permission === 'module.view' || $permission === 'view') return true;
            $perms = isset($access['permissions']) && is_array($access['permissions']) ? $access['permissions'] : array();
            return in_array('*', $perms, true) || in_array($permission, $perms, true);
        } catch (Exception $e) { return false; }
    }
    return false;
}
function dmdha_require_permission($permission) {
    dmdha_require_login();
    if (!dmdha_permission($permission)) { http_response_code(403); throw new RuntimeException('Droit insuffisant : ' . $permission . '.'); }
}
function dmdha_permissions_snapshot() {
    $keys = array('use','entity.view','entity.control','instance.manage','share.manage','preset.manage','logs.view','light.control','cover.control','climate.control','media.control','camera.view','security.control','lock.control','switch.control','fan.control','vacuum.control','automation.control','energy.view');
    $out = array();
    foreach ($keys as $k) $out[$k] = dmdha_permission($k);
    return $out;
}
function dmdha_csrf_token() {
    if (empty($_SESSION['dmdha_v2_csrf'])) $_SESSION['dmdha_v2_csrf'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['dmdha_v2_csrf'];
}
function dmdha_require_csrf($input) {
    $got = isset($input['csrf']) ? (string)$input['csrf'] : (isset($_SERVER['HTTP_X_DMDHA_CSRF']) ? (string)$_SERVER['HTTP_X_DMDHA_CSRF'] : '');
    if ($got === '' || !hash_equals(dmdha_csrf_token(), $got)) { http_response_code(403); throw new RuntimeException('Jeton de sécurité invalide.'); }
}
function dmdha_input() {
    $ct = isset($_SERVER['CONTENT_TYPE']) ? strtolower((string)$_SERVER['CONTENT_TYPE']) : '';
    if (strpos($ct, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $j = json_decode((string)$raw, true);
        return is_array($j) ? $j : array();
    }
    return $_POST;
}
function dmdha_json_read($file, $default) {
    if (!is_file($file)) return $default;
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') return $default;
    $j = json_decode($raw, true);
    return is_array($j) ? $j : $default;
}
function dmdha_json_write($file, $data) {
    $dir = dirname($file);
    dmdha_protect_dir($dir);
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    $tmp = $file . '.tmp-' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
    return true;
}
function dmdha_protect_dir($dir) {
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Impossible de créer le dossier de données.');
    @chmod($dir, 0750);
    $ht = rtrim($dir, '/\\') . '/.htaccess';
    if (!is_file($ht)) @file_put_contents($ht, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n", LOCK_EX);
}
function dmdha_system_root() { dmdha_protect_dir(DMDHA_SYSTEM_ROOT); return DMDHA_SYSTEM_ROOT; }
function dmdha_owner_root($email) {
    $email = dmdha_safe_email($email);
    if ($email === '') throw new RuntimeException('Utilisateur invalide.');
    $dir = DMDHA_DMD_ROOT . '/users/profiles/' . $email . '/ha';
    dmdha_protect_dir($dir);
    return $dir;
}
function dmdha_instances_file($email) { return dmdha_owner_root($email) . '/instances.json'; }
function dmdha_secret_file($email) { return dmdha_owner_root($email) . '/secret.key'; }
function dmdha_owner_secret($email) {
    $file = dmdha_secret_file($email);
    if (!is_file($file)) {
        $legacyGlobal=DMDHA_DMD_ROOT.'/users/keys/ha.secret';
        if(is_file($legacyGlobal)){@copy($legacyGlobal,$file);@chmod($file,0600);}
    }
    if (is_file($file)) {
        $raw = @file_get_contents($file);
        if ($raw !== false) {
            $trim=trim($raw);
            if (preg_match('/^[a-fA-F0-9]{64}$/',$trim)) return substr(hash('sha256',$trim,true),0,32);
            if (strlen($raw) >= 32) return substr($raw, 0, 32);
        }
    }
    $key = random_bytes(32);
    if (@file_put_contents($file, $key, LOCK_EX) === false) throw new RuntimeException('Impossible de créer la clé HA.');
    @chmod($file, 0600);
    return $key;
}
function dmdha_encrypt($email, $plain) {
    if (!function_exists('openssl_encrypt')) throw new RuntimeException('Extension PHP OpenSSL requise pour protéger le token Home Assistant.');
    $plain = (string)$plain;
    if ($plain === '') return '';
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($plain, 'AES-256-CBC', dmdha_owner_secret($email), OPENSSL_RAW_DATA, $iv);
    if ($cipher === false) throw new RuntimeException('Échec du chiffrement du token Home Assistant.');
    return base64_encode($iv . $cipher);
}
function dmdha_decrypt($email, $enc) {
    if (!function_exists('openssl_decrypt')) throw new RuntimeException('Extension PHP OpenSSL requise pour lire le token Home Assistant.');
    $enc = trim((string)$enc);
    if ($enc === '') return '';
    $raw = base64_decode($enc, true);
    if ($raw === false || strlen($raw) < 17) return '';
    $plain = openssl_decrypt(substr($raw, 16), 'AES-256-CBC', dmdha_owner_secret($email), OPENSSL_RAW_DATA, substr($raw, 0, 16));
    return $plain === false ? '' : (string)$plain;
}
function dmdha_clean_url($url) {
    $url = rtrim(trim((string)$url), '/');
    if ($url === '' || !preg_match('~^https?://~i', $url)) throw new InvalidArgumentException('URL Home Assistant invalide.');
    return $url;
}
function dmdha_clean_id($value) {
    $value = preg_replace('/[^a-zA-Z0-9._-]+/', '-', trim((string)$value));
    $value = trim((string)$value, '-.');
    return substr($value, 0, 80);
}
function dmdha_selected_entities_from_legacy($instance) {
    $out = array();
    if (isset($instance['entities']) && is_array($instance['entities'])) $out = $instance['entities'];
    foreach (array('cameras','sensors') as $legacy) {
        if (isset($instance[$legacy]) && is_array($instance[$legacy])) {
            foreach ($instance[$legacy] as $e) if (!in_array($e, $out, true)) $out[] = $e;
        }
    }
    $clean = array();
    foreach ($out as $e) {
        $e = trim((string)$e);
        if ($e !== '' && preg_match('/^[a-z0-9_]+\.[a-zA-Z0-9_]+$/', $e) && !in_array($e, $clean, true)) $clean[] = $e;
    }
    sort($clean, SORT_NATURAL | SORT_FLAG_CASE);
    return $clean;
}
function dmdha_normalize_instance($instance, $owner) {
    if (!is_array($instance)) $instance = array();
    $id = dmdha_clean_id(isset($instance['id']) ? $instance['id'] : '');
    if ($id === '') $id = 'ha-' . substr(bin2hex(random_bytes(8)), 0, 12);
    $name = trim((string)(isset($instance['name']) ? $instance['name'] : 'Home Assistant'));
    if ($name === '') $name = 'Home Assistant';
    $notify = isset($instance['notifications']) && is_array($instance['notifications']) ? $instance['notifications'] : array();
    $defaults = array('instance_offline'=>true,'instance_restored'=>true,'entity_unavailable'=>true,'entity_restored'=>true,'battery_low'=>true,'security_alert'=>true);
    foreach ($defaults as $k => $v) if (!array_key_exists($k, $notify)) $notify[$k] = $v;
    return array(
        'id' => $id,
        'owner' => dmdha_safe_email($owner),
        'name' => dmdha_substr($name, 0, 120),
        'base_url' => isset($instance['base_url']) ? rtrim(trim((string)$instance['base_url']), '/') : '',
        'token_enc' => isset($instance['token_enc']) ? (string)$instance['token_enc'] : '',
        'enabled' => !isset($instance['enabled']) || !empty($instance['enabled']),
        'verify_ssl' => !isset($instance['verify_ssl']) || !empty($instance['verify_ssl']),
        'entities' => dmdha_selected_entities_from_legacy($instance),
        'notifications' => $notify,
        'created_at' => isset($instance['created_at']) ? (string)$instance['created_at'] : dmdha_now_iso(),
        'updated_at' => isset($instance['updated_at']) ? (string)$instance['updated_at'] : dmdha_now_iso(),
        'last_ok_at' => isset($instance['last_ok_at']) ? (string)$instance['last_ok_at'] : '',
        'last_error' => isset($instance['last_error']) ? (string)$instance['last_error'] : ''
    );
}
function dmdha_load_instances($owner) {
    $owner = dmdha_safe_email($owner);
    if ($owner === '') return array();
    $instancesFile=dmdha_instances_file($owner);
    /* Compatibilité du tout premier HA monoinstance : users/profiles/<mail>/ha.json. */
    $legacyMono=DMDHA_DMD_ROOT.'/users/profiles/'.$owner.'/ha.json';
    if(!is_file($instancesFile)&&is_file($legacyMono)){
        $old=dmdha_json_read($legacyMono,array());
        if(!empty($old['base_url'])||!empty($old['token'])){
            $id='ha-'.substr(bin2hex(random_bytes(8)),0,12);
            $m=array('id'=>$id,'name'=>'HA','base_url'=>isset($old['base_url'])?$old['base_url']:'','token_enc'=>!empty($old['token'])?dmdha_encrypt($owner,(string)$old['token']):'','cameras'=>isset($old['cameras'])&&is_array($old['cameras'])?$old['cameras']:array(),'sensors'=>isset($old['sensors'])&&is_array($old['sensors'])?$old['sensors']:array());
            dmdha_save_instances($owner,array($m));
        }
    }
    $data = dmdha_json_read($instancesFile, array());
    $raw = isset($data['instances']) && is_array($data['instances']) ? $data['instances'] : (is_array($data) ? $data : array());
    $out = array(); $changed = false;
    foreach ($raw as $legacyId=>$item) {
        if (!is_array($item)) continue;
        if(empty($item['id'])&&!is_int($legacyId)&&!ctype_digit((string)$legacyId)){$item['id']=dmdha_clean_id((string)$legacyId);$changed=true;}
        $n = dmdha_normalize_instance($item, $owner);
        $out[] = $n;
        if (!isset($item['entities']) || !isset($item['verify_ssl']) || !isset($item['enabled'])) $changed = true;
    }
    if ($changed) dmdha_save_instances($owner, $out);
    return $out;
}
function dmdha_save_instances($owner, $items) {
    $owner = dmdha_safe_email($owner);
    if ($owner === '') throw new RuntimeException('Propriétaire invalide.');
    $out = array();
    foreach ($items as $item) if (is_array($item)) $out[] = dmdha_normalize_instance($item, $owner);
    return dmdha_json_write(dmdha_instances_file($owner), array('version'=>2,'module'=>DMDHA_MODULE_ID,'instances'=>$out,'updated_at'=>dmdha_now_iso()));
}
function dmdha_find_instance($owner, $id) {
    foreach (dmdha_load_instances($owner) as $item) if ((string)$item['id'] === (string)$id) return $item;
    return null;
}
function dmdha_public_instance($item, $viewer, $rights) {
    $copy = $item;
    unset($copy['token_enc']);
    $copy['token_saved'] = !empty($item['token_enc']);
    $copy['shared'] = strcasecmp((string)$item['owner'], (string)$viewer) !== 0;
    $copy['rights'] = array_values(array_unique($rights));
    $copy['ref'] = dmdha_instance_ref($item['owner'], $item['id']);
    return $copy;
}
function dmdha_instance_ref($owner, $id) { return dmdha_safe_email($owner) . '::' . dmdha_clean_id($id); }
function dmdha_parse_ref($ref) {
    $p = explode('::', (string)$ref, 2);
    if (count($p) !== 2) return array('', '');
    return array(dmdha_safe_email($p[0]), dmdha_clean_id($p[1]));
}
function dmdha_shares_file() { return dmdha_system_root() . '/shares.json'; }
function dmdha_load_shares() {
    $j = dmdha_json_read(dmdha_shares_file(), array('version'=>1,'grants'=>array()));
    if (!isset($j['grants']) || !is_array($j['grants'])) $j['grants'] = array();
    return $j;
}
function dmdha_save_shares($data) { return dmdha_json_write(dmdha_shares_file(), $data); }
function dmdha_share_right_catalog() {
    return array(
        'instance.view'=>'Voir l’instance','entity.view'=>'Voir les périphériques','entity.control'=>'Contrôle générique',
        'light.control'=>'Contrôler l’éclairage','cover.control'=>'Contrôler les ouvertures','climate.control'=>'Contrôler le climat',
        'media.control'=>'Contrôler le multimédia','camera.view'=>'Voir les caméras','security.control'=>'Contrôler la sécurité',
        'lock.control'=>'Contrôler les serrures','switch.control'=>'Contrôler les interrupteurs','fan.control'=>'Contrôler les ventilateurs',
        'vacuum.control'=>'Contrôler les robots','automation.control'=>'Exécuter les automatisations','energy.view'=>'Voir l’énergie'
    );
}
function dmdha_normalize_share_rights($rights) {
    if (!is_array($rights)) $rights = array();
    $allowed = array_keys(dmdha_share_right_catalog()); $out = array();
    foreach ($rights as $r) { $r = trim((string)$r); if (in_array($r, $allowed, true) && !in_array($r, $out, true)) $out[] = $r; }
    if (!in_array('instance.view', $out, true)) array_unshift($out, 'instance.view');
    if (!in_array('entity.view', $out, true)) $out[] = 'entity.view';
    return $out;
}
function dmdha_share_rights_for($owner, $instanceId, $viewer) {
    if (strcasecmp($owner, $viewer) === 0) return array_keys(dmdha_share_right_catalog());
    $data = dmdha_load_shares(); $rights = array();
    foreach ($data['grants'] as $g) {
        if (!is_array($g)) continue;
        if (strcasecmp((string)(isset($g['owner'])?$g['owner']:''), $owner) !== 0) continue;
        if ((string)(isset($g['instance_id'])?$g['instance_id']:'') !== (string)$instanceId) continue;
        $grantee = (string)(isset($g['grantee'])?$g['grantee']:'');
        if ($grantee !== '*' && strcasecmp($grantee, $viewer) !== 0) continue;
        foreach (dmdha_normalize_share_rights(isset($g['rights'])?$g['rights']:array()) as $r) if (!in_array($r, $rights, true)) $rights[] = $r;
    }
    return $rights;
}
function dmdha_instance_access($ref, $requiredRight) {
    list($owner, $id) = dmdha_parse_ref($ref);
    if ($owner === '' || $id === '') throw new InvalidArgumentException('Référence d’instance invalide.');
    $instance = dmdha_find_instance($owner, $id);
    if (!$instance) throw new RuntimeException('Instance Home Assistant introuvable.');
    $viewer = dmdha_current_email();
    $rights = dmdha_share_rights_for($owner, $id, $viewer);
    $coreRight = $requiredRight === 'instance.view' ? 'entity.view' : $requiredRight;
    if (strcasecmp($owner, $viewer) === 0) {
        if (!dmdha_permission($coreRight) && !($coreRight !== 'entity.view' && dmdha_permission('entity.control'))) throw new RuntimeException('Droit DoMyDesk insuffisant : ' . $coreRight . '.');
    } else {
        if (!dmdha_permission('use')) throw new RuntimeException('Accès au module refusé.');
        if (!in_array($requiredRight, $rights, true) && !($requiredRight !== 'entity.view' && $requiredRight !== 'instance.view' && in_array('entity.control', $rights, true))) throw new RuntimeException('Cette instance n’est pas partagée avec ce droit.');
        if (!dmdha_permission($coreRight) && !($coreRight !== 'entity.view' && dmdha_permission('entity.control'))) throw new RuntimeException('Droit DoMyDesk insuffisant : ' . $coreRight . '.');
    }
    return array($instance, $rights);
}
function dmdha_instance_access_for_user($email, $instance, $requiredRight) {
    $email = dmdha_safe_email($email);
    if ($email === '' || !is_array($instance)) return array(false, array());
    $owner = dmdha_safe_email(isset($instance['owner']) ? $instance['owner'] : '');
    $id = dmdha_clean_id(isset($instance['id']) ? $instance['id'] : '');
    if ($owner === '' || $id === '') return array(false, array());
    $rights = dmdha_share_rights_for($owner, $id, $email);
    $coreRight = $requiredRight === 'instance.view' ? 'entity.view' : $requiredRight;
    if (!dmdha_user_permission($email, 'use')) return array(false, $rights);
    if (strcasecmp($owner, $email) !== 0) {
        $allowedByShare = in_array($requiredRight, $rights, true)
            || ($requiredRight !== 'entity.view' && $requiredRight !== 'instance.view' && in_array('entity.control', $rights, true));
        if (!$allowedByShare) return array(false, $rights);
    }
    $allowedByCore = dmdha_user_permission($email, $coreRight)
        || ($coreRight !== 'entity.view' && dmdha_user_permission($email, 'entity.control'));
    return array($allowedByCore, $rights);
}
function dmdha_effective_instances($viewer) {
    $viewer = dmdha_safe_email($viewer); $out = array(); $seen = array();
    foreach (dmdha_load_instances($viewer) as $i) {
        $ref = dmdha_instance_ref($viewer, $i['id']); $seen[$ref] = true;
        $out[] = dmdha_public_instance($i, $viewer, array_keys(dmdha_share_right_catalog()));
    }
    $shares = dmdha_load_shares();
    foreach ($shares['grants'] as $g) {
        if (!is_array($g)) continue;
        $grantee = (string)(isset($g['grantee'])?$g['grantee']:'');
        if ($grantee !== '*' && strcasecmp($grantee, $viewer) !== 0) continue;
        $owner = dmdha_safe_email(isset($g['owner'])?$g['owner']:''); $id = dmdha_clean_id(isset($g['instance_id'])?$g['instance_id']:'');
        if ($owner === '' || $id === '') continue;
        $ref = dmdha_instance_ref($owner, $id); if (isset($seen[$ref])) continue;
        $i = dmdha_find_instance($owner, $id); if (!$i || empty($i['enabled'])) continue;
        $rights = dmdha_share_rights_for($owner, $id, $viewer);
        if (!in_array('instance.view', $rights, true)) continue;
        $seen[$ref] = true; $out[] = dmdha_public_instance($i, $viewer, $rights);
    }
    usort($out, 'dmdha_sort_instances'); return $out;
}
function dmdha_sort_instances($a, $b) { return strcasecmp((string)$a['name'], (string)$b['name']); }
function dmdha_users() {
    $root = DMDHA_DMD_ROOT . '/users/profiles'; $out = array(); if (!is_dir($root)) return $out;
    foreach ((array)@scandir($root) as $name) {
        if ($name === '.' || $name === '..' || !is_dir($root . '/' . $name)) continue;
        $email = dmdha_safe_email($name); if ($email === '') continue;
        $profile = dmdha_json_read($root . '/' . $email . '/profile/profile.json', array());
        $label = trim((string)(isset($profile['prenom'])?$profile['prenom']:(isset($profile['display_name'])?$profile['display_name']:$email)));
        $role = strtolower(trim((string)(isset($profile['role_system']) ? $profile['role_system'] : 'user')));
        if (!in_array($role, array('user','admin','superadmin'), true)) $role = 'user';
        $out[] = array('email'=>$email,'label'=>$label === '' ? $email : $label,'role'=>$role);
    }
    usort($out, 'dmdha_sort_users'); return $out;
}
function dmdha_sort_users($a,$b) { return strcasecmp((string)$a['label'], (string)$b['label']); }

function dmdha_preset_root() {
    $current = DMDHA_SYSTEM_ROOT . '/presets/current';
    if (is_file($current . '/catalog.json')) return $current;
    return DMDHA_BUNDLED_PRESETS;
}
function dmdha_load_presets() {
    static $cache = null; if ($cache !== null) return $cache;
    $root = dmdha_preset_root(); $catalog = dmdha_json_read($root . '/catalog.json', array());
    $families = array(); $presets = array();
    $rawFamilies = isset($catalog['families']) && is_array($catalog['families']) ? $catalog['families'] : array();
    foreach ($rawFamilies as $family) {
        if (!is_array($family)) continue; $file = basename((string)(isset($family['file'])?$family['file']:'')); if ($file === '') continue;
        $fd = dmdha_json_read($root . '/' . $file, array()); $fk = (string)(isset($family['key'])?$family['key']:'other');
        $meta = isset($fd['family']) && is_array($fd['family']) ? $fd['family'] : $family; $families[$fk] = $meta;
        $list = isset($fd['presets']) && is_array($fd['presets']) ? $fd['presets'] : array();
        foreach ($list as $p) {
            if (!is_array($p) || empty($p['key'])) continue;
            $p['_family_key'] = $fk; $p['_family_label'] = isset($meta['label']) ? (string)$meta['label'] : $fk; $p['_family_icon'] = isset($meta['icon']) ? (string)$meta['icon'] : '⌂'; $p['_family_order'] = isset($meta['order']) ? (int)$meta['order'] : 999;
            $presets[] = $p;
        }
    }
    $cache = array('root'=>$root,'catalog'=>$catalog,'families'=>$families,'presets'=>$presets); return $cache;
}
function dmdha_text_normalize($s) {
    $s = dmdha_lower((string)$s); $trans = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s); if ($trans !== false) $s = strtolower($trans);
    return preg_replace('/[^a-z0-9._ -]+/', ' ', $s);
}
function dmdha_keyword_matches($text, $keyword) {
    $text = (string)$text;
    $kw = trim((string)dmdha_text_normalize($keyword));
    if ($kw === '') return false;
    if (strpos($kw, ' ') === false && (strlen($kw) <= 2 || in_array($kw, array('eau'), true))) {
        return preg_match('/(^|[^a-z0-9])' . preg_quote($kw, '/') . '([^a-z0-9]|$)/', $text) === 1;
    }
    return strpos($text, $kw) !== false;
}
function dmdha_match_preset($entity, $meta = array()) {
    $all = dmdha_load_presets(); $entityId = (string)(isset($entity['entity_id'])?$entity['entity_id']:'');
    $domain = strpos($entityId, '.') !== false ? strtolower(substr($entityId, 0, strpos($entityId, '.'))) : '';
    $attrs = isset($entity['attributes']) && is_array($entity['attributes']) ? $entity['attributes'] : array();
    $deviceClass = strtolower((string)(isset($attrs['device_class'])?$attrs['device_class']:(isset($meta['original_device_class'])?$meta['original_device_class']:'')));
    $textParts = array(
        $entityId,
        isset($attrs['friendly_name'])?$attrs['friendly_name']:'',
        isset($attrs['manufacturer'])?$attrs['manufacturer']:'',
        isset($attrs['model'])?$attrs['model']:'',
        isset($meta['entity_name'])?$meta['entity_name']:'',
        isset($meta['device_name'])?$meta['device_name']:'',
        isset($meta['manufacturer'])?$meta['manufacturer']:'',
        isset($meta['model'])?$meta['model']:'',
        isset($meta['platform'])?$meta['platform']:''
    );
    $text = dmdha_text_normalize(implode(' ', $textParts));
    $best = null; $bestScore = -99999; $bestPriority = -1;
    foreach ($all['presets'] as $p) {
        $m = isset($p['match']) && is_array($p['match']) ? $p['match'] : array(); $score = 0; $matched = false; $keywordHit = 0; $classHit = 0;
        $domains = isset($m['domains']) && is_array($m['domains']) ? $m['domains'] : array();
        if ($domains) { if (!in_array($domain, $domains, true)) continue; $score += 30; $matched = true; }
        $classes = isset($m['device_classes']) && is_array($m['device_classes']) ? $m['device_classes'] : array();
        if ($classes && in_array($deviceClass, $classes, true)) { $score += 90; $classHit = 1; $matched = true; }
        $keywords = isset($m['keywords']) && is_array($m['keywords']) ? $m['keywords'] : array();
        foreach ($keywords as $kw) { if (dmdha_keyword_matches($text, $kw)) { $score += 110; $keywordHit++; $matched = true; } }
        $presetKey=(string)(isset($p['key'])?$p['key']:'');
        if(strpos($presetKey,'virtual.proxmox_')===0){
            $hasProxmox=dmdha_keyword_matches($text,'proxmox');
            $hasQemu=dmdha_keyword_matches($text,'qemu');
            $hasLxc=dmdha_keyword_matches($text,'lxc');
            if($presetKey==='virtual.proxmox_node' && !$hasProxmox) continue;
            if($presetKey==='virtual.proxmox_vm' && !$hasProxmox && !$hasQemu) continue;
            if($presetKey==='virtual.proxmox_lxc' && !$hasProxmox && !$hasLxc) continue;
        }
        if (($classes || $keywords) && !$classHit && $keywordHit === 0) continue;
        $fallbackByDomain=array('switch'=>'appliance.generic');
        if(!$classes&&!$keywords&&isset($fallbackByDomain[$domain])&&isset($p['key'])&&(string)$p['key']===$fallbackByDomain[$domain])$score+=25;
        $neg = isset($m['negative_keywords']) && is_array($m['negative_keywords']) ? $m['negative_keywords'] : array();
        foreach ($neg as $kw) { if (dmdha_keyword_matches($text, $kw)) $score -= 180; }
        if (!$matched) continue;
        $priority = isset($p['priority']) ? (int)$p['priority'] : 0;
        if ($score > $bestScore || ($score === $bestScore && $priority > $bestPriority)) { $best = $p; $bestScore = $score; $bestPriority = $priority; }
    }
    if ($best !== null && $bestScore > 0) return $best;
    return array('key'=>$domain . '.generic','label'=>ucfirst($domain === '' ? 'Périphérique' : $domain),'icon'=>'⌂','type'=>$domain . '.generic','priority'=>0,'action_profile'=>'generic','required_view'=>'entity.view','required_control'=>'entity.control','actions'=>array(),'notifications'=>array(),'_family_key'=>'other','_family_label'=>'Autres','_family_icon'=>'⌂','_family_order'=>999);
}
function dmdha_entity_is_technical($entityId, $meta) {
    $domain = strpos((string)$entityId,'.')!==false ? strtolower(substr((string)$entityId,0,strpos((string)$entityId,'.'))) : '';
    $category = strtolower(trim((string)(isset($meta['entity_category'])?$meta['entity_category']:'')));
    if ($category === 'diagnostic' || $category === 'config') return true;
    if (!empty($meta['hidden_by']) || !empty($meta['disabled_by'])) return true;
    return in_array($domain, array('update','persistent_notification','conversation','stt','tts'), true);
}
function dmdha_guess_device_name($state, $meta=array()) {
    $named=trim((string)(isset($meta['device_name'])?$meta['device_name']:'')); if($named!=='')return $named;
    $attrs=isset($state['attributes'])&&is_array($state['attributes'])?$state['attributes']:array();
    $friendly=trim((string)(isset($attrs['friendly_name'])?$attrs['friendly_name']:'')); if($friendly==='')return '';
    $entityId=(string)(isset($state['entity_id'])?$state['entity_id']:''); $object=strpos($entityId,'.')!==false?substr($entityId,strpos($entityId,'.')+1):$entityId;
    $parts=preg_split('/\s+/u',$friendly); $first=isset($parts[0])?trim($parts[0]):'';
    $norm=function($v){return preg_replace('/[^a-z0-9]+/','',dmdha_text_normalize((string)$v));};
    $firstNorm=$norm($first); $objNorm=$norm($object);
    if(strlen($firstNorm)>=4 && strpos($objNorm,$firstNorm)===0)return $first;
    return '';
}

function dmdha_network_switch_detect($state, $meta = array()) {
    $entityId=(string)(isset($state['entity_id'])?$state['entity_id']:'');
    $attrs=isset($state['attributes'])&&is_array($state['attributes'])?$state['attributes']:array();
    $platform=dmdha_text_normalize((string)(isset($meta['platform'])?$meta['platform']:''));
    $manufacturer=dmdha_text_normalize((string)(isset($meta['manufacturer'])?$meta['manufacturer']:(isset($attrs['manufacturer'])?$attrs['manufacturer']:'')));
    $model=dmdha_text_normalize((string)(isset($meta['model'])?$meta['model']:(isset($attrs['model'])?$attrs['model']:'')));
    $deviceName=dmdha_text_normalize((string)(isset($meta['device_name'])?$meta['device_name']:''));
    $friendly=dmdha_text_normalize((string)(isset($attrs['friendly_name'])?$attrs['friendly_name']:''));
    $text=' '.trim($entityId.' '.$platform.' '.$manufacturer.' '.$model.' '.$deviceName.' '.$friendly).' ';
    if($platform==='mokerlink' || strpos($text,' mokerlink ')!==false) return true;
    $brandHit=preg_match('/(^|[^a-z0-9])(ubiquiti|unifi|mikrotik|tp link|omada|cisco|netgear|aruba|hewlett packard enterprise|hpe|d link|dlink|zyxel|qnap)([^a-z0-9]|$)/',$text)===1;
    $switchHint=(strpos($text,' network switch ')!==false || strpos($text,' switch reseau ')!==false || strpos($text,' commutateur ')!==false ||
        preg_match('/(^|[^a-z0-9])(usw[a-z0-9_-]*|crs[0-9a-z_-]*|css[0-9a-z_-]*|tl[-_ ]?sg[0-9a-z_-]*|jetstream|catalyst|qsw[-_ ]?[0-9a-z_-]*)([^a-z0-9]|$)/',$text)===1);
    $portHint=preg_match('/(^|[^a-z0-9])port[ _-]*[0-9]{1,3}([^a-z0-9]|$)/',$text)===1;
    return ($brandHit && ($switchHint || $portHint)) || ($switchHint && $portHint);
}
function dmdha_network_switch_metric_order($state) {
    $entityId=(string)(isset($state['entity_id'])?$state['entity_id']:'');
    $attrs=isset($state['attributes'])&&is_array($state['attributes'])?$state['attributes']:array();
    $text=dmdha_text_normalize($entityId.' '.(string)(isset($attrs['friendly_name'])?$attrs['friendly_name']:''));
    $port=0; if(preg_match('/(?:^|[^a-z0-9])port[ _-]*([0-9]{1,3})(?:[^a-z0-9]|$)/',$text,$m))$port=(int)$m[1];
    $kind=80;
    if(strpos($text,' lien ')!==false||strpos($text,' link ')!==false||strpos($text,' connect')!==false||strpos($text,' status ')!==false)$kind=10;
    elseif(strpos($text,' vitesse ')!==false||strpos($text,' speed ')!==false||strpos($text,' rate ')!==false)$kind=20;
    elseif(strpos($text,' mac ')!==false||strpos($text,' client ')!==false)$kind=30;
    elseif(strpos($text,' poe ')!==false)$kind=40;
    elseif(strpos($text,' vlan ')!==false)$kind=50;
    elseif(strpos($text,' entrant ')!==false||strpos($text,' rx ')!==false)$kind=60;
    elseif(strpos($text,' sortant ')!==false||strpos($text,' tx ')!==false)$kind=61;
    return $port>0 ? ($port*100+$kind) : $kind;
}

function dmdha_nas_root_device_name($value) {
    $name=trim((string)$value);
    if($name==='')return '';

    $name=preg_replace('/\s*\((?:drive|disk|disque|volume|storage|stockage|pool|bay|baie|raid|ssd|hdd)\b[^)]*\)\s*$/iu','',$name);
    $name=preg_replace('/\s+(?:drive|disk|disque|volume|storage|stockage|pool|bay|baie)\s*[-#:]?\s*\d+\s*$/iu','',$name);
    $name=preg_replace('/\s+surveillance\s+station(?:\s+home\s+mode)?\s*$/iu','',$name);
    return trim($name);
}

function dmdha_entity_display_profile($state, $meta, $preset) {
    $entityId=(string)(isset($state['entity_id'])?$state['entity_id']:'');$domain=strpos($entityId,'.')!==false?strtolower(substr($entityId,0,strpos($entityId,'.'))):'';
    $attrs=isset($state['attributes'])&&is_array($state['attributes'])?$state['attributes']:array();$deviceName=dmdha_guess_device_name($state,$meta);
    $raw=implode(' ',array($entityId,$deviceName,(string)($attrs['friendly_name']??''),(string)($meta['manufacturer']??''),(string)($meta['model']??''),(string)($meta['platform']??'')));
    $text=dmdha_text_normalize($raw);
    $presetType=(string)($preset['type']??($domain.'.generic'));$presetLabel=(string)($preset['label']??ucfirst($domain?:'Périphérique'));$presetIcon=(string)($preset['icon']??'⌂');
    $profile=array(
        'device_name'=>$deviceName,
        'device_type_key'=>$presetType,'device_type_label'=>$presetLabel,'device_type_icon'=>$presetIcon,
        'family_key'=>(string)($preset['_family_key']??'other'),'family_label'=>(string)($preset['_family_label']??'Autres'),'family_icon'=>(string)($preset['_family_icon']??'⌂'),'family_order'=>(int)($preset['_family_order']??999),
        'group_type_key'=>$presetType,'group_type_label'=>$presetLabel,'group_type_icon'=>$presetIcon,
        'source'=>'preset'
    );
    $setType=function($key,$label,$icon)use(&$profile){$profile['device_type_key']=$key;$profile['device_type_label']=$label;$profile['device_type_icon']=$icon;$profile['source']='device';};
    $setGroup=function($key,$label,$icon,$familyKey,$familyLabel,$familyIcon,$familyOrder)use(&$profile){$profile['group_type_key']=$key;$profile['group_type_label']=$label;$profile['group_type_icon']=$icon;$profile['family_key']=$familyKey;$profile['family_label']=$familyLabel;$profile['family_icon']=$familyIcon;$profile['family_order']=$familyOrder;};
    $platform=strtolower(trim((string)($meta['platform']??''))); $model=strtolower(trim((string)($meta['model']??'')));
    if($platform==='proxmoxve'){
        $profile['family_key']='virtualization';$profile['family_label']='Virtualisation & conteneurs';$profile['family_icon']='🧱';$profile['family_order']=60;
        $kind='proxmox_device';$label='Proxmox VE';$icon='🖥️';
        if($model==='node'){$kind='proxmox_node';$label='Nœud Proxmox';$icon='🖥️';}
        elseif($model==='vm'){$kind='proxmox_vm';$label='VM Proxmox';$icon='💻';}
        elseif($model==='container'){$kind='proxmox_lxc';$label='Conteneur LXC';$icon='📦';}
        elseif($model==='storage'){$kind='proxmox_storage';$label='Stockage Proxmox';$icon='💾';}
        $profile['device_type_key']=$kind;$profile['device_type_label']=$label;$profile['device_type_icon']=$icon;
        $profile['group_type_key']=$kind;$profile['group_type_label']=$label;$profile['group_type_icon']=$icon;$profile['source']='registry';
        $profile['device_group_key']=trim((string)($meta['device_id']??''));if($profile['device_group_key']==='')$profile['device_group_key']=dmdha_clean_id($deviceName!==''?$deviceName:$entityId);
        $profile['device_group_label']=$deviceName!==''?$deviceName:$label;$profile['device_group_icon']=$icon;$profile['device_group']=true;
        $nameText=dmdha_text_normalize((string)($attrs['friendly_name']??'').' '.$entityId);$metricOrder=500;
        $metricRules=array(
            10=>array(' statut ',' status '),20=>array(' utilisation du processeur ',' cpu usage ',' cpu '),21=>array(' max cpu ',' cpu max '),
            30=>array(' pourcentage d utilisation de la memoire ',' memory percentage ',' memory percent '),31=>array(' utilisation de la memoire ',' memory usage ',' memory '),32=>array(' max memory ',' memoire maximale ',' utilisation maximale de la memoire '),
            40=>array(' utilisation du disque ',' disk usage ',' disk '),41=>array(' max disk ',' disque maximal ',' utilisation maximale du disque '),
            50=>array(' reseau entrant ',' network input ',' network in '),51=>array(' reseau sortant ',' network output ',' network out '),
            60=>array(' temps de fonctionnement ',' uptime '),70=>array(' derniere sauvegarde ',' last backup '),71=>array(' duree de la sauvegarde ',' backup duration '),72=>array(' etat de la sauvegarde ',' backup status ')
        );
        foreach($metricRules as $ord=>$needles){foreach($needles as $needle){if(strpos(' '.$nameText.' ',$needle)!==false){$metricOrder=$ord;break 2;}}}
        if($domain==='button')$metricOrder=800;
        $profile['metric_order']=$metricOrder;
        return $profile;
    }
    if(dmdha_network_switch_detect($state,$meta)){
        $profile['family_key']='network';$profile['family_label']='Réseau & IT';$profile['family_icon']='🌐';$profile['family_order']=80;
        $profile['device_type_key']='network_switch';$profile['device_type_label']='Switch réseau';$profile['device_type_icon']='🔀';
        $profile['group_type_key']='network_switch';$profile['group_type_label']='Switch réseau';$profile['group_type_icon']='🔀';$profile['source']='registry';
        $profile['device_group_key']=trim((string)($meta['device_id']??''));
        if($profile['device_group_key']==='')$profile['device_group_key']='switch-'.dmdha_clean_id($deviceName!==''?$deviceName:((string)($meta['manufacturer']??'').' '.(string)($meta['model']??'')));
        $label=$deviceName; if($label==='')$label=trim((string)($meta['manufacturer']??'').' '.(string)($meta['model']??'')); if($label==='')$label='Switch réseau';
        $profile['device_group_label']=$label;$profile['device_group_icon']='🔀';$profile['device_group']=true;
        $profile['switch_vendor']=trim((string)($meta['manufacturer']??''));$profile['switch_model']=trim((string)($meta['model']??''));
        $profile['metric_order']=dmdha_network_switch_metric_order($state);
        return $profile;
    } elseif(preg_match('/(^|[^a-z0-9])(mfc|dcp|hl)[-_ ]?[a-z0-9]{3,}/',$text)||preg_match('/(^|[^a-z0-9])(brother|epson|xerox|lexmark|kyocera|ricoh)([^a-z0-9]|$)/',$text)||strpos($text,' imprimante ')!==false||strpos($text,' printer ')!==false||strpos($text,' encre ')!==false||strpos($text,' toner ')!==false){
        $setType('printer','Imprimante','🖨️');$setGroup('printer','Imprimante','🖨️','printing','Imprimantes & scanners','🖨️',35);
    } elseif(strpos($text,'starlink')!==false){
        $setType('starlink','Starlink','🛰️');
    } elseif($domain==='camera'){
        $setType('camera','Caméra','📷');
    } elseif(preg_match('/(^|[^a-z0-9])(synology|qnap|nas[a-z0-9_-]*)([^a-z0-9]|$)/',$text)||strpos($text,'surveillance station')!==false){
        $setType('nas','NAS','🗄️');$setGroup('nas','NAS','🗄️','network','Réseau & IT','🌐',80);
        $nasRoot=dmdha_nas_root_device_name($deviceName!==''?$deviceName:(string)($attrs['friendly_name']??''));
        if($nasRoot==='')$nasRoot='NAS';
        $profile['device_group_key']='nas-'.dmdha_clean_id($nasRoot);
        $profile['device_group_label']=$nasRoot;$profile['device_group_icon']='🗄️';$profile['device_group']=true;
    } elseif($domain==='weather'){
        $setType('weather_station','Station météo','🌦️');
    }
    return $profile;
}
function dmdha_entity_public($state, $meta = array()) {
    $p = dmdha_match_preset($state, $meta); $attrs = isset($state['attributes']) && is_array($state['attributes']) ? $state['attributes'] : array();
    $entityId = (string)(isset($state['entity_id'])?$state['entity_id']:''); $display=dmdha_entity_display_profile($state,$meta,$p);
    return array(
        'entity_id'=>$entityId,'state'=>isset($state['state'])?(string)$state['state']:'unknown','attributes'=>$attrs,
        'friendly_name'=>trim((string)(isset($attrs['friendly_name'])?$attrs['friendly_name']:(isset($meta['entity_name'])?$meta['entity_name']:$entityId))),
        'unit'=>isset($attrs['unit_of_measurement'])?(string)$attrs['unit_of_measurement']:'',
        'preset'=>array('key'=>$p['key'],'label'=>$p['label'],'icon'=>$p['icon'],'type'=>$p['type'],'family_key'=>$p['_family_key'],'family_label'=>$p['_family_label'],'family_icon'=>$p['_family_icon'],'family_order'=>$p['_family_order'],'actions'=>isset($p['actions'])?$p['actions']:array(),'required_control'=>isset($p['required_control'])?$p['required_control']:'entity.control','notifications'=>isset($p['notifications'])?$p['notifications']:array()),
        'integration'=>isset($meta['platform'])?(string)$meta['platform']:'',
        'translation_key'=>isset($meta['translation_key'])?(string)$meta['translation_key']:'',
        'device_id'=>isset($meta['device_id'])?(string)$meta['device_id']:'',
        'device_name'=>isset($meta['device_name'])?(string)$meta['device_name']:'',
        'manufacturer'=>isset($meta['manufacturer'])?(string)$meta['manufacturer']:'',
        'model'=>isset($meta['model'])?(string)$meta['model']:'',
        'sw_version'=>isset($meta['sw_version'])?(string)$meta['sw_version']:'',
        'hw_version'=>isset($meta['hw_version'])?(string)$meta['hw_version']:'',
        'serial_number'=>isset($meta['serial_number'])?(string)$meta['serial_number']:'',
        'configuration_url'=>isset($meta['configuration_url'])?(string)$meta['configuration_url']:'',
        'display'=>$display,
        'entity_category'=>isset($meta['entity_category'])?(string)$meta['entity_category']:'',
        'technical'=>((isset($display['device_type_key']) && in_array($display['device_type_key'],array('printer','network_switch','nas'),true)) || strtolower(trim((string)($meta['platform']??'')))==='proxmoxve') ? false : dmdha_entity_is_technical($entityId,$meta),
        'last_changed'=>isset($state['last_changed'])?$state['last_changed']:'','last_updated'=>isset($state['last_updated'])?$state['last_updated']:''
    );
}
function dmdha_sort_entities($a,$b) {
    $ad=isset($a['display'])&&is_array($a['display'])?$a['display']:array();$bd=isset($b['display'])&&is_array($b['display'])?$b['display']:array();
    $ao=isset($ad['family_order'])?(int)$ad['family_order']:(isset($a['preset']['family_order'])?(int)$a['preset']['family_order']:999);$bo=isset($bd['family_order'])?(int)$bd['family_order']:(isset($b['preset']['family_order'])?(int)$b['preset']['family_order']:999);
    if($ao!==$bo)return $ao<$bo?-1:1;
    $ag=(string)($ad['device_group_label']??'');$bg=(string)($bd['device_group_label']??'');if($ag!==''||$bg!==''){$t=strcasecmp($ag,$bg);if($t!==0)return $t;$am=(int)($ad['metric_order']??500);$bm=(int)($bd['metric_order']??500);if($am!==$bm)return $am<$bm?-1:1;}
    $al=(string)($ad['group_type_label']??($a['preset']['label']??''));$bl=(string)($bd['group_type_label']??($b['preset']['label']??''));$t=strcasecmp($al,$bl);if($t!==0)return $t;
    return strcasecmp((string)$a['friendly_name'],(string)$b['friendly_name']);
}
function dmdha_instance_token($instance) { return dmdha_decrypt($instance['owner'], isset($instance['token_enc'])?$instance['token_enc']:''); }
function dmdha_ha_request($instance, $path, $method, $payload, $binary, $timeout = 14) {
    $base = dmdha_clean_url($instance['base_url']); $token = dmdha_instance_token($instance); if ($token === '') throw new RuntimeException('Token Home Assistant absent.');
    if (!function_exists('curl_init')) throw new RuntimeException('Extension PHP cURL requise pour communiquer avec Home Assistant.');
    $url = $base . '/' . ltrim((string)$path, '/'); $ch = curl_init($url); if (!$ch) throw new RuntimeException('cURL indisponible.');
    $headers = array('Authorization: Bearer ' . $token, 'Accept: application/json');
    $method = strtoupper((string)$method); $body = null;
    if ($payload !== null) { $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); $headers[] = 'Content-Type: application/json'; }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); $timeout=max(2,(int)$timeout); curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(5,$timeout)); curl_setopt($ch, CURLOPT_TIMEOUT, $timeout); curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    if (empty($instance['verify_ssl'])) { curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0); }
    $resp = curl_exec($ch); $err = curl_error($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE); curl_close($ch);
    if ($resp === false) throw new RuntimeException('Home Assistant inaccessible : ' . $err);
    if ($code < 200 || $code >= 300) {
        $msg='Home Assistant HTTP '.$code.'.';
        $snippet=trim((string)$resp);
        if($snippet!==''){
            $decoded=json_decode($snippet,true);
            if(is_array($decoded)){
                $candidate='';
                foreach(array('message','error','detail') as $k){if(isset($decoded[$k])&&is_scalar($decoded[$k])){$candidate=trim((string)$decoded[$k]);if($candidate!=='')break;}}
                if($candidate!=='')$snippet=$candidate;
            }
            $snippet=trim(strip_tags(preg_replace('/\s+/',' ',$snippet)));
            if($snippet!=='')$msg.=' '.dmdha_substr($snippet,0,240);
        }
        throw new RuntimeException($msg);
    }
    if ($binary) return array('body'=>$resp,'content_type'=>$ctype === '' ? 'application/octet-stream' : $ctype,'status'=>$code);
    if (trim((string)$resp) === '') return array(); $j = json_decode((string)$resp, true); if (!is_array($j)) throw new RuntimeException('Réponse Home Assistant invalide.'); return $j;
}
function dmdha_ha_stream_camera($instance, $entityId) {
    $entityId=trim((string)$entityId); if(!preg_match('/^camera\.[a-zA-Z0-9_]+$/',$entityId))throw new InvalidArgumentException('Entité caméra invalide.');
    $base=dmdha_clean_url($instance['base_url']); $token=dmdha_instance_token($instance); if($token==='')throw new RuntimeException('Token Home Assistant absent.');
    if(!function_exists('curl_init'))throw new RuntimeException('Extension PHP cURL requise pour le flux caméra.');
    $url=$base.'/api/camera_proxy_stream/'.rawurlencode($entityId); $status=0; $contentType=''; $errorBody='';
    if(session_status()===PHP_SESSION_ACTIVE) @session_write_close();
    @set_time_limit(0); @ini_set('zlib.output_compression','0'); @ini_set('output_buffering','0');
    if(!headers_sent()){
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache'); header('X-Accel-Buffering: no');
    }
    $ch=curl_init($url); if(!$ch)throw new RuntimeException('cURL indisponible.');
    $headers=array('Authorization: Bearer '.$token,'Accept: multipart/x-mixed-replace,image/jpeg,*/*');
    curl_setopt($ch,CURLOPT_HTTPHEADER,$headers); curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,5); curl_setopt($ch,CURLOPT_TIMEOUT,0); curl_setopt($ch,CURLOPT_RETURNTRANSFER,false); curl_setopt($ch,CURLOPT_FOLLOWLOCATION,false);
    if(empty($instance['verify_ssl'])){curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,0);}
    curl_setopt($ch,CURLOPT_HEADERFUNCTION,function($ch,$line)use(&$status,&$contentType){
        $trim=trim($line); if(preg_match('~^HTTP/[^ ]+\s+(\d+)~i',$trim,$m))$status=(int)$m[1];
        if(stripos($line,'Content-Type:')===0){$contentType=trim(substr($line,13));if($status>=200&&$status<300&&!headers_sent())header('Content-Type: '.$contentType);}
        return strlen($line);
    });
    curl_setopt($ch,CURLOPT_WRITEFUNCTION,function($ch,$chunk)use(&$status,&$contentType,&$errorBody){
        if($status>=200&&$status<300){
            if(!headers_sent()&&$contentType==='')header('Content-Type: multipart/x-mixed-replace');
            echo $chunk; @ob_flush(); @flush();
            return connection_aborted()?0:strlen($chunk);
        }
        if(strlen($errorBody)<2048)$errorBody.=substr($chunk,0,2048-strlen($errorBody)); return strlen($chunk);
    });
    $ok=curl_exec($ch); $err=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    if(connection_aborted())return true;
    if($code<200||$code>=300){$msg='Flux caméra Home Assistant HTTP '.$code.'.';if(trim($errorBody)!=='')$msg.=' '.dmdha_substr(strip_tags($errorBody),0,180);throw new RuntimeException($msg);}
    if($ok===false)throw new RuntimeException('Flux caméra Home Assistant interrompu : '.$err);
    return true;
}
function dmdha_test_connection_values($baseUrl, $token, $verifySsl) {
    $tmpOwner = dmdha_current_email(); $tmp = array('owner'=>$tmpOwner,'base_url'=>dmdha_clean_url($baseUrl),'token_enc'=>dmdha_encrypt($tmpOwner, $token),'verify_ssl'=>(bool)$verifySsl);
    $a = dmdha_ha_request($tmp, '/api/', 'GET', null, false); $cfg = dmdha_ha_request($tmp, '/api/config', 'GET', null, false);
    return array('message'=>isset($a['message'])?$a['message']:'API Home Assistant OK','location_name'=>isset($cfg['location_name'])?$cfg['location_name']:'','version'=>isset($cfg['version'])?$cfg['version']:'');
}

function dmdha_stream_read_exact($fp, $length) {
    $length=(int)$length; if($length<0 || $length>16777216) throw new RuntimeException('Réponse WebSocket Home Assistant trop volumineuse.');
    $data='';
    while(strlen($data)<$length){
        $chunk=fread($fp,$length-strlen($data));
        if($chunk===false || $chunk===''){
            $meta=stream_get_meta_data($fp);
            if(!empty($meta['timed_out'])) throw new RuntimeException('Timeout WebSocket Home Assistant.');
            if(feof($fp)) throw new RuntimeException('Connexion WebSocket Home Assistant interrompue.');
            usleep(1000); continue;
        }
        $data.=$chunk;
    }
    return $data;
}
function dmdha_ws_write_frame($fp, $payload, $opcode=1) {
    $payload=(string)$payload; $len=strlen($payload); $first=chr(0x80|($opcode&0x0f)); $mask=random_bytes(4);
    if($len<126){$head=$first.chr(0x80|$len);}elseif($len<=65535){$head=$first.chr(0x80|126).pack('n',$len);}else{$head=$first.chr(0x80|127).pack('NN',0,$len);}
    $masked=''; for($i=0;$i<$len;$i++)$masked.=$payload[$i]^$mask[$i%4];
    $written=@fwrite($fp,$head.$mask.$masked); if($written===false)throw new RuntimeException('Écriture WebSocket Home Assistant impossible.');
}
function dmdha_ws_read_message($fp) {
    $message=''; $started=false; $messageOpcode=0;
    while(true){
        $h=dmdha_stream_read_exact($fp,2); $b1=ord($h[0]);$b2=ord($h[1]);$fin=(bool)($b1&0x80);$opcode=$b1&0x0f;$masked=(bool)($b2&0x80);$len=$b2&0x7f;
        if($len===126){$u=unpack('nlen',dmdha_stream_read_exact($fp,2));$len=(int)$u['len'];}
        elseif($len===127){$u=unpack('Nhi/Nlo',dmdha_stream_read_exact($fp,8));if((int)$u['hi']!==0)throw new RuntimeException('Réponse WebSocket Home Assistant trop volumineuse.');$len=(int)$u['lo'];}
        $mask=$masked?dmdha_stream_read_exact($fp,4):''; $payload=$len>0?dmdha_stream_read_exact($fp,$len):'';
        if($masked){$tmp='';for($i=0;$i<$len;$i++)$tmp.=$payload[$i]^$mask[$i%4];$payload=$tmp;}
        if($opcode===0x8)throw new RuntimeException('Home Assistant a fermé la connexion WebSocket.');
        if($opcode===0x9){dmdha_ws_write_frame($fp,$payload,0xA);continue;}
        if($opcode===0xA)continue;
        if($opcode===0x1 || $opcode===0x2){$started=true;$messageOpcode=$opcode;$message=$payload;}
        elseif($opcode===0x0 && $started){$message.=$payload;} else {continue;}
        if($fin && $started){ if($messageOpcode!==0x1)continue; $decoded=json_decode($message,true); if(!is_array($decoded))throw new RuntimeException('Réponse WebSocket Home Assistant invalide.'); return $decoded; }
    }
}
function dmdha_ws_registry_data($instance) {
    if(!function_exists('stream_socket_client'))throw new RuntimeException('WebSocket PHP indisponible.');
    $url=dmdha_clean_url(isset($instance['base_url'])?$instance['base_url']:''); $parts=parse_url($url); if(!is_array($parts)||empty($parts['host']))throw new RuntimeException('URL Home Assistant invalide.');
    $https=strtolower((string)(isset($parts['scheme'])?$parts['scheme']:'http'))==='https'; $host=(string)$parts['host']; $port=isset($parts['port'])?(int)$parts['port']:($https?443:80); $verify=!isset($instance['verify_ssl'])||$instance['verify_ssl'];
    $path=isset($parts['path'])?rtrim((string)$parts['path'],'/'):''; $path=($path===''?'':$path).'/api/websocket';
    $ctx=stream_context_create(array('ssl'=>array('verify_peer'=>$verify,'verify_peer_name'=>$verify,'allow_self_signed'=>!$verify,'SNI_enabled'=>true,'peer_name'=>$host)));
    $target=($https?'ssl://':'tcp://').(strpos($host,':')!==false?'['.$host.']':$host).':'.$port; $errno=0;$errstr='';
    $fp=@stream_socket_client($target,$errno,$errstr,5,STREAM_CLIENT_CONNECT,$ctx); if(!$fp)throw new RuntimeException('Connexion WebSocket Home Assistant impossible'.($errstr!==''?' : '.$errstr:'.'));
    stream_set_timeout($fp,6); $key=base64_encode(random_bytes(16)); $hostHeader=$host.((($https&&$port!==443)||(!$https&&$port!==80))?':'.$port:''); $origin=($https?'https':'http').'://'.$hostHeader;
    $req="GET ".$path." HTTP/1.1\r\nHost: ".$hostHeader."\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ".$key."\r\nSec-WebSocket-Version: 13\r\nOrigin: ".$origin."\r\n\r\n";
    if(@fwrite($fp,$req)===false){fclose($fp);throw new RuntimeException('Handshake WebSocket Home Assistant impossible.');}
    $headers=''; while(!feof($fp)){ $line=fgets($fp); if($line===false)break; $headers.=$line; if($line==="\r\n")break; if(strlen($headers)>16384)break; }
    if(!preg_match('~^HTTP/1\.[01]\s+101\b~i',$headers)){fclose($fp);throw new RuntimeException('Home Assistant refuse le WebSocket.');}
    try{
        $hello=dmdha_ws_read_message($fp); if((string)(isset($hello['type'])?$hello['type']:'')!=='auth_required')throw new RuntimeException('Handshake Home Assistant inattendu.');
        dmdha_ws_write_frame($fp,json_encode(array('type'=>'auth','access_token'=>dmdha_instance_token($instance)),JSON_UNESCAPED_SLASHES));
        $auth=dmdha_ws_read_message($fp); if((string)(isset($auth['type'])?$auth['type']:'')!=='auth_ok')throw new RuntimeException('Authentification WebSocket Home Assistant refusée.');
        dmdha_ws_write_frame($fp,json_encode(array('id'=>1,'type'=>'config/entity_registry/list_for_display'),JSON_UNESCAPED_SLASHES));
        dmdha_ws_write_frame($fp,json_encode(array('id'=>2,'type'=>'config/device_registry/list'),JSON_UNESCAPED_SLASHES));
        $results=array(); $deadline=microtime(true)+6;
        while(count($results)<2 && microtime(true)<$deadline){$msg=dmdha_ws_read_message($fp);$id=isset($msg['id'])?(int)$msg['id']:0;if(($id===1||$id===2)&&isset($msg['type'])&&$msg['type']==='result')$results[$id]=$msg;}
        try{dmdha_ws_write_frame($fp,'',0x8);}catch(Exception $ignore){} fclose($fp);
        if(!isset($results[1])||empty($results[1]['success']))throw new RuntimeException('Registre des entités Home Assistant indisponible.');
        if(!isset($results[2])||empty($results[2]['success']))throw new RuntimeException('Registre des appareils Home Assistant indisponible.');
        return array('entities'=>$results[1]['result'],'devices'=>$results[2]['result']);
    }catch(Exception $e){if(is_resource($fp))fclose($fp);throw $e;}
}
function dmdha_registry_cache_file($instance) {
    $owner=isset($instance['owner'])?$instance['owner']:''; $id=dmdha_clean_id(isset($instance['id'])?$instance['id']:'ha');
    $dir=dmdha_owner_root($owner).'/cache'; dmdha_protect_dir($dir); return $dir.'/registry-'.$id.'.json';
}
function dmdha_registry_metadata($instance, $refresh) {
    $file=dmdha_registry_cache_file($instance); $cached=dmdha_json_read($file,array());
    if(!$refresh && isset($cached['schema'])&&(int)$cached['schema']>=3&&isset($cached['transport'])&&$cached['transport']==='websocket'&&isset($cached['entities'])&&is_array($cached['entities'])&&!empty($cached['entities']))return $cached['entities'];
    try{$registry=dmdha_ws_registry_data($instance);}catch(Exception $e){return isset($cached['entities'])&&is_array($cached['entities'])?$cached['entities']:array();}
    $devices=array(); foreach((array)(isset($registry['devices'])?$registry['devices']:array()) as $row){
        if(!is_array($row)||empty($row['id']))continue;$did=(string)$row['id'];
        $devices[$did]=array(
            'device_name'=>trim((string)(isset($row['name_by_user'])&&$row['name_by_user']!==null?$row['name_by_user']:(isset($row['name'])?$row['name']:(isset($row['default_name'])?$row['default_name']:'')))),
            'manufacturer'=>trim((string)(isset($row['manufacturer'])&&$row['manufacturer']!==null?$row['manufacturer']:(isset($row['default_manufacturer'])?$row['default_manufacturer']:''))),
            'model'=>trim((string)(isset($row['model'])&&$row['model']!==null?$row['model']:(isset($row['default_model'])?$row['default_model']:''))),
            'area_id'=>isset($row['area_id'])?(string)$row['area_id']:'',
            'via_device_id'=>isset($row['via_device_id'])?(string)$row['via_device_id']:(isset($row['via_device'])?(string)$row['via_device']:''),
            'configuration_url'=>isset($row['configuration_url'])?(string)$row['configuration_url']:'',
            'sw_version'=>trim((string)(isset($row['sw_version'])&&$row['sw_version']!==null?$row['sw_version']:'')),
            'hw_version'=>trim((string)(isset($row['hw_version'])&&$row['hw_version']!==null?$row['hw_version']:'')),
            'serial_number'=>trim((string)(isset($row['serial_number'])&&$row['serial_number']!==null?$row['serial_number']:''))
        );
    }
    $entityResult=isset($registry['entities'])&&is_array($registry['entities'])?$registry['entities']:array(); $rows=isset($entityResult['entities'])&&is_array($entityResult['entities'])?$entityResult['entities']:$entityResult;
    $categories=isset($entityResult['entity_categories'])&&is_array($entityResult['entity_categories'])?$entityResult['entity_categories']:array(); $meta=array();
    foreach((array)$rows as $row){
        if(!is_array($row))continue; $eid=trim((string)(isset($row['ei'])?$row['ei']:(isset($row['entity_id'])?$row['entity_id']:''))); if($eid==='')continue;
        $did=trim((string)(isset($row['di'])?$row['di']:(isset($row['device_id'])?$row['device_id']:''))); $ec=isset($row['ec'])?$row['ec']:(isset($row['entity_category'])?$row['entity_category']:'');
        if((is_int($ec)||ctype_digit((string)$ec))&&isset($categories[(string)$ec]))$ec=$categories[(string)$ec]; elseif((is_int($ec)||ctype_digit((string)$ec))&&isset($categories[(int)$ec]))$ec=$categories[(int)$ec];
        $m=array(
            'platform'=>trim((string)(isset($row['pl'])?$row['pl']:(isset($row['platform'])?$row['platform']:''))),
            'device_id'=>$did,
            'entity_name'=>trim((string)(isset($row['en'])?$row['en']:(isset($row['name'])?$row['name']:(isset($row['original_name'])?$row['original_name']:'')))),
            'translation_key'=>trim((string)(isset($row['tk'])?$row['tk']:(isset($row['translation_key'])?$row['translation_key']:''))),
            'original_device_class'=>trim((string)(isset($row['original_device_class'])?$row['original_device_class']:'')),
            'entity_category'=>trim((string)$ec), 'hidden_by'=>false,'disabled_by'=>false
        );
        if($did!==''&&isset($devices[$did]))$m=array_merge($m,$devices[$did]); $meta[$eid]=$m;
    }
    dmdha_json_write($file,array('schema'=>3,'updated_at'=>dmdha_now_iso(),'transport'=>'websocket','entities'=>$meta)); return $meta;
}
function dmdha_states_for_instance($instance, $onlySelected) {
    $states = dmdha_ha_request($instance, '/api/states', 'GET', null, false);
    $selected = isset($instance['entities']) && is_array($instance['entities']) ? $instance['entities'] : array();
    $selectedMap = array_flip($selected); $out = array(); $metadata=dmdha_registry_metadata($instance,false);
    $switchDevices=array();
    if($onlySelected){
        foreach((array)$states as $state){
            if(!is_array($state)||empty($state['entity_id']))continue; $eid=(string)$state['entity_id'];
            if(!isset($selectedMap[$eid]))continue;
            $meta=isset($metadata[$eid])&&is_array($metadata[$eid])?$metadata[$eid]:array();
            if(empty($meta['platform']))$meta['platform']=strpos($eid,'.')!==false?substr($eid,0,strpos($eid,'.')):'home_assistant';
            $did=trim((string)(isset($meta['device_id'])?$meta['device_id']:''));
            if($did!=='' && dmdha_network_switch_detect($state,$meta))$switchDevices[$did]=true;
        }
    }
    foreach ((array)$states as $state) {
        if (!is_array($state) || empty($state['entity_id'])) continue; $eid=(string)$state['entity_id'];
        $meta=isset($metadata[$eid])&&is_array($metadata[$eid])?$metadata[$eid]:array();
        if(empty($meta['platform']))$meta['platform']=strpos($eid,'.')!==false?substr($eid,0,strpos($eid,'.')):'home_assistant';
        $selectedEntity=isset($selectedMap[$eid]); $did=trim((string)(isset($meta['device_id'])?$meta['device_id']:''));
        $supporting=$onlySelected && !$selectedEntity && $did!=='' && isset($switchDevices[$did]);
        if ($onlySelected && !$selectedEntity && !$supporting) continue;
        $public=dmdha_entity_public($state,$meta); if($supporting)$public['supporting']=true;
        $out[]=$public;
    }
    usort($out, 'dmdha_sort_entities'); return $out;
}
function dmdha_services_for_instance($instance) {
    $raw=dmdha_ha_request($instance,'/api/services','GET',null,false); $out=array();
    foreach((array)$raw as $block){if(!is_array($block))continue;$domain=trim((string)(isset($block['domain'])?$block['domain']:''));if($domain==='')continue;foreach((array)(isset($block['services'])?$block['services']:array()) as $name=>$def){$name=trim((string)$name);if($name==='')continue;$key=$domain.'.'.$name;$out[$key]=array('domain'=>$domain,'name'=>$name,'description'=>is_array($def)&&isset($def['description'])?dmdha_substr((string)$def['description'],0,240):'');}}
    ksort($out,SORT_NATURAL|SORT_FLAG_CASE);return $out;
}
function dmdha_discover_for_instance($instance) {
    $states=dmdha_ha_request($instance,'/api/states','GET',null,false); $metadata=dmdha_registry_metadata($instance,true); $entities=array();
    foreach((array)$states as $state){
        if(!is_array($state)||empty($state['entity_id']))continue; $eid=(string)$state['entity_id'];
        $meta=isset($metadata[$eid])&&is_array($metadata[$eid])?$metadata[$eid]:array();
        if(empty($meta['platform']))$meta['platform']=strpos($eid,'.')!==false?substr($eid,0,strpos($eid,'.')):'home_assistant';
        $entities[]=dmdha_entity_public($state,$meta);
    }
    usort($entities,'dmdha_sort_entities'); return $entities;
}
function dmdha_filter_entities_for_viewer($entities,$instance,$rights) {
    $shared=strcasecmp((string)$instance['owner'],dmdha_current_email())!==0; $out=array();
    foreach((array)$entities as $e){if(!is_array($e))continue;$family=isset($e['preset']['family_key'])?(string)$e['preset']['family_key']:'';$entityId=isset($e['entity_id'])?(string)$e['entity_id']:'';
        if(($family==='video'||strpos($entityId,'camera.')===0)&&(!dmdha_permission('camera.view')||($shared&&!in_array('camera.view',$rights,true))))continue;
        if($family==='energy'&&(!dmdha_permission('energy.view')||($shared&&!in_array('energy.view',$rights,true))))continue;
        $out[]=$e;
    }
    return $out;
}
function dmdha_find_entity_state($instance, $entityId) {
    $j = dmdha_ha_request($instance, '/api/states/' . rawurlencode($entityId), 'GET', null, false); return is_array($j) ? $j : null;
}
function dmdha_allowed_action($preset, $service) {
    $actions = isset($preset['actions']) && is_array($preset['actions']) ? $preset['actions'] : array();
    foreach ($actions as $a) if (is_array($a) && (string)(isset($a['service'])?$a['service']:'') === (string)$service) return $a;
    return null;
}
function dmdha_service_payload($entityId, $widget, $value, $extra) {
    $data = array('entity_id'=>$entityId); $widget = (string)$widget;
    if ($widget === 'brightness') $data['brightness_pct'] = max(0, min(100, (int)$value));
    elseif ($widget === 'volume') $data['volume_level'] = max(0, min(100, (float)$value)) / 100;
    elseif ($widget === 'position') $data['position'] = max(0, min(100, (int)$value));
    elseif ($widget === 'temperature') $data['temperature'] = (float)$value;
    elseif ($widget === 'percentage') $data['percentage'] = max(0, min(100, (int)$value));
    elseif ($widget === 'source') $data['source'] = dmdha_substr((string)$value,0,120);
    elseif ($widget === 'hvac_mode') $data['hvac_mode'] = dmdha_substr((string)$value,0,50);
    elseif ($widget === 'option') $data['option'] = dmdha_substr((string)$value,0,120);
    elseif ($widget === 'number') $data['value'] = (float)$value;
    elseif ($widget === 'humidity') $data['humidity'] = max(0, min(100, (int)$value));
    elseif ($widget === 'humidifier_mode') $data['mode'] = dmdha_substr((string)$value,0,80);
    elseif ($widget === 'water_heater_mode') $data['operation_mode'] = dmdha_substr((string)$value,0,80);
    elseif ($widget === 'mute_on') $data['is_volume_muted'] = true;
    elseif ($widget === 'mute_off') $data['is_volume_muted'] = false;
    elseif ($widget === 'command') $data['command'] = dmdha_substr((string)$value,0,120);
    if (is_array($extra)) foreach ($extra as $k=>$v) if (preg_match('/^[a-zA-Z0-9_]+$/',(string)$k) && $k !== 'entity_id') $data[$k]=$v;
    return $data;
}
function dmdha_log($action, $target, $result, $details, $owner) {
    dmdha_protect_dir(DMDHA_LOG_ROOT . '/' . date('Y_m'));
    $file = DMDHA_LOG_ROOT . '/' . date('Y_m') . '/' . date('Y-m-d') . '.jsonl';
    $entry = array('timestamp'=>time(),'date_iso'=>dmdha_now_iso(),'user'=>dmdha_current_email(),'module'=>DMDHA_MODULE_ID,'action'=>(string)$action,'target'=>(string)$target,'result'=>(string)$result,'owner'=>(string)$owner,'details'=>is_array($details)?$details:array('message'=>(string)$details));
    @file_put_contents($file, json_encode($entry, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND|LOCK_EX); @chmod($file,0640);
    dmdha_activity_event($entry);
}
function dmdha_activity_event($entry) {
    $root = dmdha_system_root() . '/activity'; dmdha_protect_dir($root); $target = isset($entry['target'])?(string)$entry['target']:''; $file = $root . '/' . sha1($target) . '.json';
    dmdha_json_write($file, array('resource_id'=>$target,'module'=>DMDHA_MODULE_ID,'last_event'=>$entry));
    if (function_exists('dmd_module_event')) {
        $details = isset($entry['details']) && is_array($entry['details']) ? $entry['details'] : array();
        $resourceType = strpos($target, DMDHA_MODULE_ID . ':ha_entity:') === 0 ? 'ha_entity' : 'ha_instance';
        $resourceName = isset($details['name']) && trim((string)$details['name']) !== '' ? (string)$details['name'] : (isset($details['instance_name']) && trim((string)$details['instance_name']) !== '' ? (string)$details['instance_name'] : $target);
        $resource = array('id'=>$target,'type'=>$resourceType,'source'=>DMDHA_MODULE_ID,'name'=>$resourceName);
        $detailsText = $details ? json_encode($details, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) : '';
        try {
            dmd_module_event(DMDHA_MODULE_ID, isset($entry['action'])?(string)$entry['action']:'event', $resource, array(
                'email'=>isset($entry['user'])?(string)$entry['user']:'',
                'label'=>isset($entry['action'])?(string)$entry['action']:'Home Assistant',
                'target'=>$resourceName,
                'status'=>isset($entry['result'])?(string)$entry['result']:'info',
                'details'=>is_string($detailsText)?$detailsText:'',
                'meta'=>array('source'=>DMDHA_MODULE_ID,'owner'=>isset($entry['owner'])?(string)$entry['owner']:''),
                'log'=>false
            ));
        } catch (Exception $e) {}
    }
}
function dmdha_read_logs($limit) {
    $limit = (int)$limit; $unlimited = $limit <= 0; if (!$unlimited) $limit = max(1,$limit); $files = glob(DMDHA_LOG_ROOT . '/*/*.jsonl'); if (!$files) return array(); rsort($files,SORT_STRING); $out=array();
    foreach ($files as $file) { $lines=@file($file, FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES); if (!$lines) continue; for ($i=count($lines)-1;$i>=0;$i--) { $j=json_decode($lines[$i],true); if (is_array($j)) $out[]=$j; if (!$unlimited && count($out)>=$limit) break 2; } }
    return $out;
}
function dmdha_notification_store($recipient, $title, $message, $level, $meta) {
    $recipient = dmdha_safe_email($recipient); if ($recipient === '') return;
    $dir = dmdha_system_root() . '/notifications'; dmdha_protect_dir($dir); $entry=array('id'=>'ha-'.bin2hex(random_bytes(8)),'created_at'=>dmdha_now_iso(),'recipient'=>$recipient,'title'=>$title,'message'=>$message,'level'=>$level,'module'=>DMDHA_MODULE_ID,'meta'=>$meta,'read'=>false);
    @file_put_contents($dir . '/' . sha1(strtolower($recipient)) . '.jsonl', json_encode($entry,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n",FILE_APPEND|LOCK_EX);
    $tried=false;
    $eventName = isset($meta['event']) && trim((string)$meta['event']) !== '' ? trim((string)$meta['event']) : 'notification';
    $type = 'dmd-ha-v2.' . $eventName;
    $notifyOptions=array('level'=>$level,'module'=>DMDHA_MODULE_ID,'meta'=>$meta,'context'=>$meta);
    foreach((array)$meta as $mk=>$mv) if(is_scalar($mv)||$mv===null) $notifyOptions[(string)$mk]=$mv;
    $notifyOptions['message']=$message;
    if (function_exists('dmd_notify_many')) {
        $tried=true;
        @dmd_notify_many(array($recipient),$type,$title,$message,$notifyOptions);
    }
    if (!$tried && function_exists('dmd_notify_user')) {
        $tried=true;
        @dmd_notify_user($recipient,$type,$title,$message,$notifyOptions);
    }
    if (!$tried) foreach (array('dmd_notification_create','dmd_add_notification','dmd_notification_push') as $fn) if (function_exists($fn)) { $tried=true; @call_user_func($fn,$recipient,$title,$message,$level,$meta); break; }
    if (function_exists('dmd_notification_index_refresh_user')) @dmd_notification_index_refresh_user($recipient);
}
function dmdha_notify_share_change($owner,$grantee,$instance,$rights,$removed) {
    $title = $removed ? 'Partage Home Assistant retiré' : 'Instance Home Assistant partagée';
    $message = ($removed ? 'Le partage de ' : 'Accès à ') . $instance['name'] . ($removed ? ' a été retiré.' : ' a été accordé.');
    $recipients=array();
    if ($grantee === '*') { foreach(dmdha_users() as $u){$email=isset($u['email'])?$u['email']:'';if($email!==''&&strcasecmp($email,$owner)!==0)$recipients[]=$email;} }
    else $recipients[]=$grantee;
    foreach(array_unique($recipients) as $recipient)dmdha_notification_store($recipient,$title,$message,'info',array('event'=>$removed?'share_removed':'share_changed','owner'=>$owner,'instance_id'=>$instance['id'],'rights'=>$rights,'scope'=>$grantee==='*'?'all':'user'));
}
function dmdha_preset_status() {
    $bundled=dmdha_json_read(DMDHA_BUNDLED_PRESETS.'/catalog.json',array()); $active=dmdha_json_read(dmdha_preset_root().'/catalog.json',array()); $cfg=dmdha_json_read(dmdha_system_root().'/presets/config.json',array());
    $backup=dmdha_json_read(dmdha_system_root().'/presets/backup/catalog.json',array());
    return array('bundled_version'=>isset($bundled['catalog_version'])?$bundled['catalog_version']:'','active_version'=>isset($active['catalog_version'])?$active['catalog_version']:'','backup_version'=>isset($backup['catalog_version'])?$backup['catalog_version']:'','active_total'=>isset($active['total_presets'])?(int)$active['total_presets']:0,'families'=>isset($active['families'])&&is_array($active['families'])?$active['families']:array(),'source_url'=>isset($cfg['source_url'])?$cfg['source_url']:'','using_update'=>dmdha_preset_root()!==DMDHA_BUNDLED_PRESETS);
}
function dmdha_remote_get($url) {
    $url=trim((string)$url); if (!preg_match('~^https?://~i',$url)) throw new InvalidArgumentException('URL de presets invalide.');
    if (function_exists('curl_init')) { $ch=curl_init($url); curl_setopt($ch,CURLOPT_RETURNTRANSFER,true); curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true); curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,6); curl_setopt($ch,CURLOPT_TIMEOUT,20); curl_setopt($ch,CURLOPT_USERAGENT,'DoMyDesk-DMD-Ha.V2/'.DMDHA_MODULE_VERSION); $body=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch); if ($body===false || $code<200 || $code>=300) throw new RuntimeException('Téléchargement presets impossible : '.($err!==''?$err:'HTTP '.$code)); return (string)$body; }
    $ctx=stream_context_create(array('http'=>array('timeout'=>20,'user_agent'=>'DoMyDesk-DMD-Ha.V2/'.DMDHA_MODULE_VERSION))); $body=@file_get_contents($url,false,$ctx); if ($body===false) throw new RuntimeException('Téléchargement presets impossible.'); return (string)$body;
}
function dmdha_validate_catalog_dir($dir) {
    $dir=rtrim($dir,'/'); $catalog=dmdha_json_read($dir.'/catalog.json',array());
    if ((int)(isset($catalog['schema'])?$catalog['schema']:0)!==2) throw new RuntimeException('Catalogue de presets : schema 2 requis.');
    $catalogVersion=trim((string)(isset($catalog['catalog_version'])?$catalog['catalog_version']:'')); if($catalogVersion==='')throw new RuntimeException('Catalogue de presets sans version.');
    $min=trim((string)(isset($catalog['min_module_version'])?$catalog['min_module_version']:'')); if($min!==''&&version_compare(DMDHA_MODULE_VERSION,$min,'<'))throw new RuntimeException('Catalogue réservé à DMD-Ha.V2 '.$min.' ou supérieur.');
    $families=isset($catalog['families'])&&is_array($catalog['families'])?$catalog['families']:array(); $total=0;$keys=array(); if (!$families) throw new RuntimeException('Catalogue de presets vide.');
    foreach ($families as $f) {
        if(!is_array($f))throw new RuntimeException('Famille de presets invalide.'); $file=basename((string)(isset($f['file'])?$f['file']:'')); $familyKey=trim((string)(isset($f['key'])?$f['key']:''));
        if ($file==='' || $familyKey==='' || !is_file($dir.'/'.$file)) throw new RuntimeException('Fichier de famille absent ou invalide : '.$file);
        $raw=@file_get_contents($dir.'/'.$file); if($raw===false)throw new RuntimeException('Lecture impossible : '.$file);
        if(!empty($f['sha256'])&&!hash_equals(strtolower((string)$f['sha256']),strtolower(hash('sha256',$raw))))throw new RuntimeException('SHA-256 incorrect pour '.$file);
        $d=json_decode($raw,true); if(!is_array($d)||(int)(isset($d['schema'])?$d['schema']:0)!==2)throw new RuntimeException('Schema 2 requis dans '.$file);
        $meta=isset($d['family'])&&is_array($d['family'])?$d['family']:array(); if((string)(isset($meta['key'])?$meta['key']:'')!==$familyKey)throw new RuntimeException('Clé de famille incohérente dans '.$file);
        $ps=isset($d['presets'])&&is_array($d['presets'])?$d['presets']:array(); if(isset($f['count'])&&(int)$f['count']!==count($ps))throw new RuntimeException('Nombre de presets incohérent dans '.$file);
        foreach($ps as $p){ if(!is_array($p)||empty($p['key'])||empty($p['type'])||empty($p['match'])||!is_array($p['match'])) throw new RuntimeException('Preset invalide dans '.$file); $k=(string)$p['key']; if(isset($keys[$k])) throw new RuntimeException('Preset dupliqué : '.$k); $keys[$k]=true; $total++; }
    }
    if ($total < 100) throw new RuntimeException('Catalogue refusé : au moins 100 presets sont requis.'); if (isset($catalog['total_presets']) && (int)$catalog['total_presets']!==$total) throw new RuntimeException('Le nombre de presets annoncé ne correspond pas aux fichiers.'); return array('catalog'=>$catalog,'total'=>$total);
}
function dmdha_preset_check_remote($sourceUrl) {
    $raw=dmdha_remote_get($sourceUrl); $cat=json_decode($raw,true); if(!is_array($cat)||(int)(isset($cat['schema'])?$cat['schema']:0)!==2) throw new RuntimeException('catalog.json distant invalide.');
    return array('catalog_version'=>isset($cat['catalog_version'])?$cat['catalog_version']:'','total_presets'=>isset($cat['total_presets'])?(int)$cat['total_presets']:0,'families'=>isset($cat['families'])&&is_array($cat['families'])?count($cat['families']):0);
}
function dmdha_rrmdir($dir) {
    if(!is_dir($dir)) return; $items=scandir($dir); foreach((array)$items as $it){ if($it==='.'||$it==='..')continue; $p=$dir.'/'.$it; if(is_dir($p)&&!is_link($p))dmdha_rrmdir($p); else @unlink($p); } @rmdir($dir);
}
function dmdha_preset_install_remote($sourceUrl) {
    $sourceUrl=trim((string)$sourceUrl); $raw=dmdha_remote_get($sourceUrl); $cat=json_decode($raw,true); if(!is_array($cat)||(int)(isset($cat['schema'])?$cat['schema']:0)!==2) throw new RuntimeException('catalog.json distant invalide.');
    $base=preg_replace('~/[^/]*$~','/',$sourceUrl); $presetsRoot=dmdha_system_root().'/presets'; dmdha_protect_dir($presetsRoot); $stage=$presetsRoot.'/stage-'.bin2hex(random_bytes(5)); dmdha_protect_dir($stage); @file_put_contents($stage.'/catalog.json',$raw,LOCK_EX);
    try { foreach((array)(isset($cat['families'])?$cat['families']:array()) as $f){ $file=basename((string)(isset($f['file'])?$f['file']:'')); if($file==='')throw new RuntimeException('Nom de famille preset invalide.'); $body=dmdha_remote_get($base.rawurlencode($file)); if(isset($f['sha256'])&&$f['sha256']!==''&&!hash_equals(strtolower((string)$f['sha256']),strtolower(hash('sha256',$body))))throw new RuntimeException('SHA-256 incorrect pour '.$file); @file_put_contents($stage.'/'.$file,$body,LOCK_EX); } $valid=dmdha_validate_catalog_dir($stage); $current=$presetsRoot.'/current'; $backup=$presetsRoot.'/backup'; if(is_dir($backup))dmdha_rrmdir($backup); if(is_dir($current)&&!@rename($current,$backup))throw new RuntimeException('Impossible de sauvegarder le catalogue actuel.'); if(!@rename($stage,$current)){ if(is_dir($backup))@rename($backup,$current); throw new RuntimeException('Impossible d’activer le nouveau catalogue.'); } dmdha_json_write($presetsRoot.'/config.json',array('source_url'=>$sourceUrl,'installed_at'=>dmdha_now_iso(),'catalog_version'=>isset($valid['catalog']['catalog_version'])?$valid['catalog']['catalog_version']:'')); return $valid; } catch(Exception $e){ if(is_dir($stage))dmdha_rrmdir($stage); throw $e; }
}
function dmdha_preset_rollback() { $root=dmdha_system_root().'/presets'; $backup=$root.'/backup'; $current=$root.'/current'; if(!is_file($backup.'/catalog.json'))throw new RuntimeException('Aucun catalogue précédent disponible.'); dmdha_validate_catalog_dir($backup); if(is_dir($current))dmdha_rrmdir($current); if(!@rename($backup,$current))throw new RuntimeException('Impossible de restaurer le catalogue précédent.'); $cfg=dmdha_json_read($root.'/config.json',array());$cfg['rolled_back_at']=dmdha_now_iso();$cfg['catalog_version']=dmdha_preset_status()['active_version'];dmdha_json_write($root.'/config.json',$cfg);return dmdha_preset_status(); }
function dmdha_preset_restore_bundled() { $root=dmdha_system_root().'/presets'; if(is_dir($root.'/current'))dmdha_rrmdir($root.'/current'); dmdha_json_write($root.'/config.json',array('source_url'=>'','restored_at'=>dmdha_now_iso())); return dmdha_preset_status(); }
function dmdha_save_preset_source($url){ $url=trim((string)$url); if($url!==''&&!preg_match('~^https?://~i',$url))throw new InvalidArgumentException('URL de catalogue invalide.'); $cfg=dmdha_json_read(dmdha_system_root().'/presets/config.json',array()); $cfg['source_url']=$url; $cfg['updated_at']=dmdha_now_iso(); dmdha_json_write(dmdha_system_root().'/presets/config.json',$cfg); return $cfg; }
function dmdha_resource_id($instance,$entityId){ return DMDHA_MODULE_ID . ':ha_entity:' . substr(sha1(strtolower($instance['owner']).'|'.$instance['id'].'|'.$entityId),0,24); }
function dmdha_resource_for_entity($instance,$entity){ return array('id'=>dmdha_resource_id($instance,$entity['entity_id']),'type'=>'ha_entity','local_id'=>$entity['entity_id'],'name'=>$entity['friendly_name'],'instance_ref'=>dmdha_instance_ref($instance['owner'],$instance['id']),'preset_type'=>$entity['preset']['type']); }
function dmdha_instance_recipients($instance) {
    $out=array(); $owner=dmdha_safe_email($instance['owner']); if($owner!=='')$out[]=$owner; $shares=dmdha_load_shares(); $wild=false;
    foreach($shares['grants'] as $g){ if(!is_array($g))continue; if(strcasecmp((string)(isset($g['owner'])?$g['owner']:''),$owner)!==0||(string)(isset($g['instance_id'])?$g['instance_id']:'')!==(string)$instance['id'])continue; $gr=(string)(isset($g['grantee'])?$g['grantee']:''); if($gr==='*'){$wild=true;continue;} $gr=dmdha_safe_email($gr); if($gr!==''&&!in_array($gr,$out,true))$out[]=$gr; }
    if($wild)foreach(dmdha_users() as $u){$em=$u['email'];if(!in_array($em,$out,true))$out[]=$em;}
    return $out;
}
function dmdha_instance_status_file($instance){ $dir=dmdha_system_root().'/status/'.sha1(strtolower($instance['owner'])); dmdha_protect_dir($dir); return $dir.'/'.sha1($instance['id']).'.json'; }
function dmdha_notify_instance($instance,$title,$message,$level,$meta){
    $meta=is_array($meta)?$meta:array();
    $eventName=isset($meta['event'])&&trim((string)$meta['event'])!==''?trim((string)$meta['event']):'notification';
    $eventKey='dmd-ha-v2.'.$eventName;
    $recipients=dmdha_instance_recipients($instance);
    $payload=array_merge(array(
        'module_id'=>DMDHA_MODULE_ID,
        'module_name'=>'DMD-Ha.V2',
        'event'=>$eventName,
        'instance_id'=>isset($instance['id'])?(string)$instance['id']:'',
        'instance_name'=>isset($instance['name'])?(string)$instance['name']:'',
        'owner'=>isset($instance['owner'])?(string)$instance['owner']:'',
        'target_user'=>isset($instance['owner'])?(string)$instance['owner']:'',
        'context'=>$recipients,
        'context_users'=>$recipients,
        'title'=>(string)$title,
        'message'=>(string)$message
    ),$meta);
    if(function_exists('dmd_system_log')){
        $target=dmdha_instance_ref(isset($instance['owner'])?$instance['owner']:'',isset($instance['id'])?$instance['id']:'');
        if(!empty($meta['entity_id']))$target=(string)$meta['entity_id'];
        try{
            return (bool)dmd_system_log($eventKey,$target,(string)$level,(string)$message,$payload);
        }catch(Throwable $e){
        }
    }

    foreach($recipients as $recipient){
        dmdha_notification_store($recipient,$title,$message,$level,$payload);
    }
    return false;
}
function dmdha_status_log($instance,$action,$result,$details){
    $details=is_array($details)?$details:array('message'=>(string)$details);
    if(!isset($details['instance_name']))$details['instance_name']=isset($instance['name'])?(string)$instance['name']:'';
    dmdha_log($action,dmdha_instance_ref($instance['owner'],$instance['id']),$result,$details,$instance['owner']);
}
function dmdha_track_instance_success($instance,$entities){
    $file=dmdha_instance_status_file($instance); $old=dmdha_json_read($file,array()); $notify=isset($instance['notifications'])&&is_array($instance['notifications'])?$instance['notifications']:array();
    if(isset($old['online'])&&!$old['online']){
        dmdha_status_log($instance,'instance.restored','success',array('event'=>'instance_restored'));
        if(!empty($notify['instance_restored']))dmdha_notify_instance($instance,'Home Assistant rétabli',$instance['name'].' est de nouveau accessible.','success',array('event'=>'instance_restored'));
    }
    $prev=isset($old['entities'])&&is_array($old['entities'])?$old['entities']:array(); $snapshot=array();
    foreach($entities as $e){ if(!is_array($e)||empty($e['entity_id'])||!empty($e['supporting']))continue; $id=$e['entity_id']; $snapshot[$id]=array('state'=>$e['state'],'preset_key'=>$e['preset']['key'],'device_class'=>isset($e['attributes']['device_class'])?$e['attributes']['device_class']:''); $pstate=isset($prev[$id]['state'])?(string)$prev[$id]['state']:null; $state=(string)$e['state'];
        if($state==='unavailable'&&$pstate!=='unavailable'){
            dmdha_status_log($instance,'entity.unavailable','warning',array('event'=>'entity_unavailable','entity_id'=>$id,'name'=>$e['friendly_name'],'state'=>$state));
            if(!empty($notify['entity_unavailable']))dmdha_notify_instance($instance,'Périphérique HA indisponible',$e['friendly_name'].' est indisponible sur '.$instance['name'].'.','warning',array('event'=>'entity_unavailable','entity_id'=>$id,'entity_name'=>$e['friendly_name'],'state'=>$state));
        }
        if($state!=='unavailable'&&$pstate==='unavailable'){
            dmdha_status_log($instance,'entity.restored','success',array('event'=>'entity_restored','entity_id'=>$id,'name'=>$e['friendly_name'],'state'=>$state));
            if(!empty($notify['entity_restored']))dmdha_notify_instance($instance,'Périphérique HA rétabli',$e['friendly_name'].' est de nouveau disponible sur '.$instance['name'].'.','success',array('event'=>'entity_restored','entity_id'=>$id,'entity_name'=>$e['friendly_name'],'state'=>$state));
        }
        $dc=strtolower((string)(isset($e['attributes']['device_class'])?$e['attributes']['device_class']:''));
        if($dc==='battery'&&is_numeric($state)&&(float)$state<=20&&($pstate===null||!is_numeric($pstate)||(float)$pstate>20)){
            dmdha_status_log($instance,'battery.low','warning',array('event'=>'battery_low','entity_id'=>$id,'name'=>$e['friendly_name'],'value'=>$state));
            if(!empty($notify['battery_low']))dmdha_notify_instance($instance,'Batterie faible',$e['friendly_name'].' est à '.$state.'%.','warning',array('event'=>'battery_low','entity_id'=>$id,'entity_name'=>$e['friendly_name'],'value'=>$state,'state'=>$state));
        }
        if(in_array($dc,array('smoke','carbon_monoxide','gas','moisture','safety','problem'),true)&&in_array(strtolower($state),array('on','detected','problem','unsafe','wet'),true)&&strtolower((string)$pstate)!==strtolower($state)){
            dmdha_status_log($instance,'security.alert','danger',array('event'=>'security_alert','entity_id'=>$id,'name'=>$e['friendly_name'],'state'=>$state,'device_class'=>$dc));
            if(!empty($notify['security_alert']))dmdha_notify_instance($instance,'Alerte Home Assistant',$e['friendly_name'].' signale : '.$state.'.','danger',array('event'=>'security_alert','entity_id'=>$id,'entity_name'=>$e['friendly_name'],'state'=>$state));
        }
    }
    dmdha_json_write($file,array('online'=>true,'updated_at'=>dmdha_now_iso(),'entities'=>$snapshot));
}
function dmdha_track_instance_failure($instance,$message){
    $file=dmdha_instance_status_file($instance); $old=dmdha_json_read($file,array()); $notify=isset($instance['notifications'])&&is_array($instance['notifications'])?$instance['notifications']:array();
    if(!isset($old['online'])||$old['online']){
        dmdha_status_log($instance,'instance.offline','error',array('event'=>'instance_offline','error'=>dmdha_substr((string)$message,0,180)));
        if(!empty($notify['instance_offline']))dmdha_notify_instance($instance,'Home Assistant inaccessible',$instance['name'].' ne répond plus.','danger',array('event'=>'instance_offline','error'=>dmdha_substr((string)$message,0,180)));
    }
    dmdha_json_write($file,array('online'=>false,'updated_at'=>dmdha_now_iso(),'last_error'=>dmdha_substr((string)$message,0,400),'entities'=>isset($old['entities'])?$old['entities']:array()));
}
