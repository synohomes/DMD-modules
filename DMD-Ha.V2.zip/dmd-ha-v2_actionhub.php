<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



require_once __DIR__ . '/dmd-ha-v2_lib.php';

function dmdha_actionhub_result($ok, $message, $data = array(), $error = '') {
    return array(
        'ok'=>(bool)$ok,
        'message'=>(string)$message,
        'data'=>is_array($data)?$data:array(),
        'error'=>(string)$error,
        'event_emitted'=>true
    );
}

function dmdha_actionhub_resolve_resource($email, $resource) {
    $email = dmdha_safe_email($email);
    if ($email === '' || !is_array($resource)) return null;
    if ((string)(isset($resource['source'])?$resource['source']:'') !== DMDHA_MODULE_ID) return null;
    if ((string)(isset($resource['type'])?$resource['type']:'') !== 'ha_entity') return null;
    $resourceId = trim((string)(isset($resource['id'])?$resource['id']:''));
    if ($resourceId === '') return null;

    foreach (dmdha_effective_instances($email) as $public) {
        $ref = isset($public['ref']) ? (string)$public['ref'] : '';
        list($owner,$id) = dmdha_parse_ref($ref);
        if ($owner === '' || $id === '') continue;
        $instance = dmdha_find_instance($owner,$id);
        if (!$instance || empty($instance['enabled'])) continue;
        list($viewAllowed,$rights) = dmdha_instance_access_for_user($email,$instance,'entity.view');
        if (!$viewAllowed) continue;
        foreach ((array)(isset($instance['entities'])?$instance['entities']:array()) as $entityId) {
            $entityId = trim((string)$entityId);
            if ($entityId === '' || dmdha_resource_id($instance,$entityId) !== $resourceId) continue;
            $state = dmdha_find_entity_state($instance,$entityId);
            if (!$state) return null;
            $metaMap = dmdha_registry_metadata($instance,false);
            $meta = isset($metaMap[$entityId]) && is_array($metaMap[$entityId]) ? $metaMap[$entityId] : array();
            $entity = dmdha_entity_public($state,$meta);
            return array(
                'instance'=>$instance,
                'instance_ref'=>$ref,
                'rights'=>$rights,
                'entity_id'=>$entityId,
                'state'=>$state,
                'entity'=>$entity,
                'preset'=>dmdha_match_preset($state,$meta),
                'resource'=>dmdha_resource_for_entity($instance,$entity)
            );
        }
    }
    return null;
}

function dmdha_actionhub_resolve_payload($email, $payload) {
    $email = dmdha_safe_email($email);
    $payload = is_array($payload) ? $payload : array();
    $ref = trim((string)(isset($payload['instance_ref'])?$payload['instance_ref']:''));
    $entityId = trim((string)(isset($payload['entity_id'])?$payload['entity_id']:''));
    if ($email === '' || $ref === '' || !preg_match('/^[a-z0-9_]+\.[a-z0-9_]+$/i',$entityId)) return null;
    list($owner,$id) = dmdha_parse_ref($ref);
    if ($owner === '' || $id === '') return null;
    $instance = dmdha_find_instance($owner,$id);
    if (!$instance || empty($instance['enabled'])) return null;
    list($viewAllowed,$rights) = dmdha_instance_access_for_user($email,$instance,'entity.view');
    if (!$viewAllowed) return null;
    $metaMap = dmdha_registry_metadata($instance,false);
    $meta = isset($metaMap[$entityId]) && is_array($metaMap[$entityId]) ? $metaMap[$entityId] : array();
    $selection = dmdha_actionhub_selection_context($instance);
    $deviceId = trim((string)(isset($meta['device_id']) ? $meta['device_id'] : ''));
    if (!dmdha_actionhub_entity_selected_or_companion($entityId,$deviceId,$selection)) return null;
    $state = dmdha_find_entity_state($instance,$entityId);
    if (!$state) return null;
    $entity = dmdha_entity_public($state,$meta);
    return array(
        'instance'=>$instance,
        'instance_ref'=>$ref,
        'rights'=>$rights,
        'entity_id'=>$entityId,
        'state'=>$state,
        'entity'=>$entity,
        'preset'=>dmdha_match_preset($state,$meta),
        'resource'=>dmdha_resource_for_entity($instance,$entity)
    );
}

function dmdha_actionhub_input_for_widget($widget, $state) {
    $widget = (string)$widget;
    $attrs = isset($state['attributes']) && is_array($state['attributes']) ? $state['attributes'] : array();
    $input = null;
    if (in_array($widget,array('brightness','volume','position','percentage','temperature','number','humidity'),true)) {
        $default = '';
        if ($widget === 'brightness' && isset($attrs['brightness']) && is_numeric($attrs['brightness'])) $default = round(((float)$attrs['brightness'] / 255) * 100);
        elseif ($widget === 'volume' && isset($attrs['volume_level']) && is_numeric($attrs['volume_level'])) $default = round(((float)$attrs['volume_level']) * 100);
        elseif ($widget === 'position' && isset($attrs['current_position'])) $default = $attrs['current_position'];
        elseif ($widget === 'temperature' && isset($attrs['temperature'])) $default = $attrs['temperature'];
        elseif ($widget === 'percentage' && isset($attrs['percentage'])) $default = $attrs['percentage'];
        elseif ($widget === 'humidity' && isset($attrs['humidity'])) $default = $attrs['humidity'];
        elseif ($widget === 'number' && isset($state['state']) && is_numeric($state['state'])) $default = $state['state'];
        $input = array('id'=>'value','label'=>'Valeur','type'=>'number','required'=>true,'default'=>$default,'help'=>'Valeur transmise à Home Assistant.');
    } elseif (in_array($widget,array('source','hvac_mode','option','humidifier_mode','water_heater_mode'),true)) {
        $map = array(
            'source'=>'source_list',
            'hvac_mode'=>'hvac_modes',
            'option'=>'options',
            'humidifier_mode'=>'available_modes',
            'water_heater_mode'=>'operation_list'
        );
        $values = isset($attrs[$map[$widget]]) && is_array($attrs[$map[$widget]]) ? $attrs[$map[$widget]] : array();
        $values = array_values(array_filter(array_map('strval',$values),'strlen'));
        if ($values) $input = array('id'=>'value','label'=>'Valeur','type'=>'select','required'=>true,'options'=>$values,'default'=>isset($values[0])?$values[0]:'');
        else $input = array('id'=>'value','label'=>'Valeur','type'=>'text','required'=>true,'placeholder'=>'Valeur Home Assistant');
    } elseif ($widget === 'command') {
        $input = array('id'=>'value','label'=>'Commande','type'=>'text','required'=>true,'placeholder'=>'Commande à envoyer');
    }
    return $input;
}

function dmdha_actionhub_dynamic_id($service, $widget) {
    return 'entity.call.' . substr(sha1((string)$service . '|' . (string)$widget),0,16);
}

function dmdha_actionhub_scenario_dynamic_id($instanceRef, $entityId, $service, $widget) {
    return 'scenario.entity.' . substr(sha1((string)$instanceRef . '|' . (string)$entityId . '|' . (string)$service . '|' . (string)$widget),0,24);
}


function dmdha_actionhub_selection_context($instance) {
    $selected = isset($instance['entities']) && is_array($instance['entities']) ? $instance['entities'] : array();
    $selectedMap = array();
    foreach ($selected as $eid) {
        $eid = trim((string)$eid);
        if ($eid !== '') $selectedMap[$eid] = true;
    }
    $metadata = dmdha_registry_metadata($instance,false);
    $deviceMap = array();
    foreach ($selectedMap as $eid=>$yes) {
        $meta = isset($metadata[$eid]) && is_array($metadata[$eid]) ? $metadata[$eid] : array();
        $deviceId = trim((string)(isset($meta['device_id']) ? $meta['device_id'] : ''));
        if ($deviceId !== '') $deviceMap[$deviceId] = true;
    }
    return array('selected'=>$selectedMap,'devices'=>$deviceMap,'metadata'=>$metadata);
}

function dmdha_actionhub_entity_selected_or_companion($entityId, $deviceId, $selection) {
    $entityId = trim((string)$entityId);
    $deviceId = trim((string)$deviceId);
    if ($entityId === '' || !is_array($selection)) return false;
    if (isset($selection['selected'][$entityId])) return true;
    return $deviceId !== '' && isset($selection['devices'][$deviceId]);
}

function dmdha_actionhub_group_label($instanceName, $entity, $preset) {
    $display = isset($entity['display']) && is_array($entity['display']) ? $entity['display'] : array();
    $group = trim((string)(isset($display['group_type_label']) ? $display['group_type_label'] : ''));
    if ($group === '') $group = trim((string)(isset($display['family_label']) ? $display['family_label'] : ''));
    if ($group === '') $group = trim((string)(isset($preset['family_label']) ? $preset['family_label'] : ''));
    if ($group === '') $group = 'Home Assistant';
    return $instanceName . ' · ' . $group;
}

function dmdha_actionhub_proxmox_command_info($entity, $fallbackLabel) {
    $entity = is_array($entity) ? $entity : array();
    $entityId = trim((string)(isset($entity['entity_id']) ? $entity['entity_id'] : ''));
    $domain = strpos($entityId,'.') !== false ? strtolower(substr($entityId,0,strpos($entityId,'.'))) : '';
    $integration = strtolower(trim((string)(isset($entity['integration']) ? $entity['integration'] : '')));
    $translationKey = strtolower(trim((string)(isset($entity['translation_key']) ? $entity['translation_key'] : '')));
    $info = array('is_proxmox'=>false,'translation_key'=>$translationKey,'label'=>trim((string)$fallbackLabel),'dangerous'=>false);
    if ($integration !== 'proxmoxve' || $domain !== 'button') return $info;

    $info['is_proxmox'] = true;
    $labels = array(
        'start'=>'Démarrer',
        'stop'=>'Arrêt forcé',
        'restart'=>'Redémarrer',
        'reboot'=>'Redémarrer le nœud',
        'shutdown'=>'Arrêt propre',
        'hibernate'=>'Hiberner',
        'resume'=>'Reprendre',
        'reset'=>'Réinitialiser',
        'snapshot_create'=>'Créer un instantané',
        'start_all'=>'Tout démarrer',
        'stop_all'=>'Tout arrêter de force',
        'suspend_all'=>'Tout suspendre'
    );
    if ($translationKey !== '' && isset($labels[$translationKey])) $info['label'] = $labels[$translationKey];
    if ($translationKey === '' && dmdha_lower(trim((string)$info['label'])) === dmdha_lower('Exécuter')) {
        $friendly=trim((string)(isset($entity['friendly_name'])?$entity['friendly_name']:''));
        $display=isset($entity['display'])&&is_array($entity['display'])?$entity['display']:array();
        $device=trim((string)(isset($display['device_group_label'])?$display['device_group_label']:''));
        if($device==='')$device=trim((string)(isset($entity['device_name'])?$entity['device_name']:''));
        $command=$friendly;
        if($device!==''&&stripos($friendly,$device)===0)$command=trim(substr($friendly,strlen($device)));
        if($command!=='')$info['label']=$command;
    }
    $info['dangerous'] = in_array($translationKey,array('stop','shutdown','reset','reboot','stop_all'),true);
    return $info;
}

function dmdha_actionhub_scenario_label($entity, $commandLabel) {
    $entityId = trim((string)(isset($entity['entity_id']) ? $entity['entity_id'] : ''));
    $domain = strpos($entityId,'.') !== false ? strtolower(substr($entityId,0,strpos($entityId,'.'))) : '';
    $friendly = trim((string)(isset($entity['friendly_name']) ? $entity['friendly_name'] : $entityId));
    if ($friendly === '') $friendly = $entityId;

    $px = dmdha_actionhub_proxmox_command_info($entity,$commandLabel);
    if (!empty($px['is_proxmox'])) {
        $display = isset($entity['display']) && is_array($entity['display']) ? $entity['display'] : array();
        $device = trim((string)(isset($display['device_group_label']) ? $display['device_group_label'] : ''));
        if ($device === '') $device = trim((string)(isset($entity['device_name']) ? $entity['device_name'] : ''));
        if ($device === '') {
            return $friendly . (trim((string)$px['label']) !== '' ? ' — ' . $px['label'] : '');
        }
        return $device . ' — ' . (trim((string)$px['label']) !== '' ? $px['label'] : $friendly);
    }

    if ($domain === 'button' && dmdha_lower(trim((string)$commandLabel)) === dmdha_lower('Exécuter')) return $friendly;
    return $friendly . ' — ' . $commandLabel;
}

function dmdha_actionhub_scenario_actions($email) {
    $email = dmdha_safe_email($email);
    if ($email === '') return array();

    $out = array();
    foreach (dmdha_effective_instances($email) as $public) {
        if (!is_array($public)) continue;
        $ref = trim((string)(isset($public['ref']) ? $public['ref'] : ''));
        list($owner,$id) = dmdha_parse_ref($ref);
        if ($owner === '' || $id === '') continue;

        $instance = dmdha_find_instance($owner,$id);
        if (!$instance || empty($instance['enabled'])) continue;

        list($canView) = dmdha_instance_access_for_user($email,$instance,'entity.view');
        if (!$canView) continue;

        try {
            $selection = dmdha_actionhub_selection_context($instance);
            $entities = dmdha_states_for_instance($instance,false);
        } catch (Exception $e) {
            continue;
        }

        $instanceName = trim((string)(isset($instance['name']) ? $instance['name'] : $id));
        if ($instanceName === '') $instanceName = $id;

        foreach ((array)$entities as $entity) {
            if (!is_array($entity)) continue;
            $entityId = trim((string)(isset($entity['entity_id']) ? $entity['entity_id'] : ''));
            if ($entityId === '') continue;
            $deviceId = trim((string)(isset($entity['device_id']) ? $entity['device_id'] : ''));
            if (!dmdha_actionhub_entity_selected_or_companion($entityId,$deviceId,$selection)) continue;

            $preset = isset($entity['preset']) && is_array($entity['preset']) ? $entity['preset'] : array();
            $presetActions = (array)(isset($preset['actions']) ? $preset['actions'] : array());
            if (!$presetActions) continue;

            $required = trim((string)(isset($preset['required_control']) ? $preset['required_control'] : 'entity.control'));
            if ($required === '') $required = 'entity.control';
            list($canControl) = dmdha_instance_access_for_user($email,$instance,$required);
            if (!$canControl) continue;

            $friendly = trim((string)(isset($entity['friendly_name']) ? $entity['friendly_name'] : $entityId));
            if ($friendly === '') $friendly = $entityId;
            $presetLabel = trim((string)(isset($preset['label']) ? $preset['label'] : ''));
            $icon = isset($entity['display']['device_type_icon']) && (string)$entity['display']['device_type_icon'] !== ''
                ? (string)$entity['display']['device_type_icon']
                : (isset($preset['icon']) ? (string)$preset['icon'] : '⚡');

            foreach ($presetActions as $a) {
                if (!is_array($a)) continue;
                $service = trim((string)(isset($a['service']) ? $a['service'] : ''));
                $widget = trim((string)(isset($a['widget']) ? $a['widget'] : 'power'));
                if (!preg_match('/^[a-z0-9_]+\.[a-z0-9_]+$/i',$service)) continue;
                if ($service === 'camera.snapshot_proxy' || $service === 'camera.stream_proxy') continue;

                $commandLabel = trim((string)(isset($a['label']) ? $a['label'] : $service));
                if ($commandLabel === '') $commandLabel = $service;
                $pxCommand = dmdha_actionhub_proxmox_command_info($entity,$commandLabel);
                if (!empty($pxCommand['is_proxmox']) && trim((string)$pxCommand['label']) !== '') $commandLabel = (string)$pxCommand['label'];
                $dangerous = in_array($required,array('security.control','lock.control','cover.control'),true)
                    || preg_match('/^(alarm_control_panel|lock|cover|valve)\./',$service)
                    || !empty($pxCommand['dangerous']);

                $inputs = array();
                $valueInput = dmdha_actionhub_input_for_widget($widget,$entity);
                if ($valueInput) $inputs[] = $valueInput;

                $descriptionParts = array($instanceName, $entityId);
                $deviceName = trim((string)(isset($entity['display']['device_group_label']) ? $entity['display']['device_group_label'] : ''));
                if ($deviceName !== '') $descriptionParts[] = $deviceName;
                if ($presetLabel !== '') $descriptionParts[] = $presetLabel;

                $out[] = array(
                    'id'=>dmdha_actionhub_scenario_dynamic_id($ref,$entityId,$service,$widget),
                    'label'=>dmdha_actionhub_scenario_label($entity,$commandLabel),
                    'description'=>implode(' · ',array_values(array_unique($descriptionParts))),
                    'icon'=>$icon,
                    'group'=>dmdha_actionhub_group_label($instanceName,$entity,$preset),
                    'permission'=>$required,
                    'scope'=>'module',
                    'scenario'=>true,
                    'inputs'=>$inputs,
                    'dangerous'=>(bool)$dangerous,
                    'confirm'=>$dangerous ? 'Confirmer la commande Home Assistant « '.$friendly.' — '.$commandLabel.' » ?' : '',
                    'meta'=>array(
                        'ha_scenario'=>1,
                        'instance_ref'=>$ref,
                        'entity_id'=>$entityId,
                        'service'=>$service,
                        'widget'=>$widget,
                        'preset_key'=>isset($preset['key']) ? (string)$preset['key'] : '',
                        'device_id'=>$deviceId,
                        'translation_key'=>isset($entity['translation_key']) ? (string)$entity['translation_key'] : ''
                    )
                );
            }
        }
    }

    usort($out, function($a,$b) {
        $ga = isset($a['group']) ? (string)$a['group'] : '';
        $gb = isset($b['group']) ? (string)$b['group'] : '';
        $cmp = strcasecmp($ga,$gb);
        if ($cmp !== 0) return $cmp;
        return strcasecmp((string)(isset($a['label'])?$a['label']:''),(string)(isset($b['label'])?$b['label']:''));
    });
    return $out;
}

function dmdha_actionhub_catalog($context) {
    $context = is_array($context) ? $context : array();
    $resource = isset($context['resource']) && is_array($context['resource']) ? $context['resource'] : null;
    $email = isset($context['email']) ? (string)$context['email'] : '';
    if (!$resource) {
        return array('replace'=>true,'actions'=>dmdha_actionhub_scenario_actions($email));
    }

    try { $resolved = dmdha_actionhub_resolve_resource($email,$resource); }
    catch (Exception $e) { return array('replace'=>true,'actions'=>array()); }
    if (!$resolved) return array('replace'=>true,'actions'=>array());

    $entity = $resolved['entity'];
    $preset = $resolved['preset'];
    $state = $resolved['state'];
    $out = array(array(
        'id'=>'entity.inspect',
        'label'=>'Actualiser l’état',
        'description'=>'Relire immédiatement l’état de ce périphérique dans Home Assistant.',
        'icon'=>'↻',
        'group'=>'Home Assistant',
        'permission'=>'entity.view',
        'resource_types'=>array('ha_entity'),
        'scope'=>'resource',
        'scenario'=>false
    ));

    $required = trim((string)(isset($preset['required_control'])?$preset['required_control']:'entity.control'));
    list($canControl) = dmdha_instance_access_for_user($email,$resolved['instance'],$required);
    if (!$canControl) return array('replace'=>true,'actions'=>$out);

    foreach ((array)(isset($preset['actions'])?$preset['actions']:array()) as $a) {
        if (!is_array($a)) continue;
        $service = trim((string)(isset($a['service'])?$a['service']:''));
        $widget = trim((string)(isset($a['widget'])?$a['widget']:'power'));
        if (!preg_match('/^[a-z0-9_]+\.[a-z0-9_]+$/i',$service)) continue;
        if ($service === 'camera.snapshot_proxy' || $service === 'camera.stream_proxy') continue;
        $label = trim((string)(isset($a['label'])?$a['label']:$service));
        $dangerous = in_array($required,array('security.control','lock.control','cover.control'),true)
            || preg_match('/^(alarm_control_panel|lock|cover|valve)\./',$service);
        $inputs = array();
        $valueInput = dmdha_actionhub_input_for_widget($widget,$state);
        if ($valueInput) $inputs[] = $valueInput;
        $out[] = array(
            'id'=>dmdha_actionhub_dynamic_id($service,$widget),
            'label'=>$label,
            'description'=>$entity['friendly_name'].' · '.$preset['label'],
            'icon'=>isset($preset['icon'])?$preset['icon']:'⚡',
            'group'=>isset($preset['_family_label'])?$preset['_family_label']:'Home Assistant',
            'permission'=>$required,
            'resource_types'=>array('ha_entity'),
            'scope'=>'resource',
            'scenario'=>false,
            'inputs'=>$inputs,
            'dangerous'=>(bool)$dangerous,
            'confirm'=>$dangerous ? 'Confirmer la commande Home Assistant « '.$label.' » ?' : '',
            'meta'=>array('service'=>$service,'widget'=>$widget,'preset_key'=>isset($preset['key'])?$preset['key']:'')
        );
    }
    return array('replace'=>true,'actions'=>$out);
}

function dmdha_actionhub_execute_service($email, $resolved, $service, $widget, $value, $extra, $origin) {
    if (!$resolved || !is_array($resolved)) return dmdha_actionhub_result(false,'Périphérique Home Assistant introuvable.',array(),'resource_not_found');
    $service = trim((string)$service); $widget = trim((string)$widget);
    if (!preg_match('/^[a-z0-9_]+\.[a-z0-9_]+$/i',$service)) return dmdha_actionhub_result(false,'Service Home Assistant invalide.',array(),'invalid_service');
    if ($service === 'camera.snapshot_proxy' || $service === 'camera.stream_proxy') return dmdha_actionhub_result(false,'Cette action caméra s’utilise dans la fenêtre du module.',array(),'unsupported_proxy_action');

    $preset = $resolved['preset'];
    $allowed = null;
    foreach ((array)(isset($preset['actions'])?$preset['actions']:array()) as $a) {
        if (!is_array($a)) continue;
        if ((string)(isset($a['service'])?$a['service']:'') === $service && (string)(isset($a['widget'])?$a['widget']:'power') === $widget) { $allowed=$a; break; }
    }
    if (!$allowed) return dmdha_actionhub_result(false,'Cette commande n’est pas prévue par le preset de ce périphérique.',array(),'action_not_in_preset');

    $required = trim((string)(isset($preset['required_control'])?$preset['required_control']:'entity.control'));
    list($canControl) = dmdha_instance_access_for_user($email,$resolved['instance'],$required);
    if (!$canControl) return dmdha_actionhub_result(false,'Droit insuffisant pour commander ce périphérique.',array(),'permission_denied');

    $parts = explode('.',$service,2);
    $payload = dmdha_service_payload($resolved['entity_id'],$widget,$value,is_array($extra)?$extra:array());
    $resource = $resolved['resource'];
    $details = array(
        'entity_id'=>$resolved['entity_id'],
        'name'=>$resolved['entity']['friendly_name'],
        'instance_name'=>$resolved['instance']['name'],
        'instance_ref'=>$resolved['instance_ref'],
        'preset'=>isset($preset['key'])?$preset['key']:'',
        'service'=>$service,
        'widget'=>$widget,
        'translation_key'=>isset($resolved['entity']['translation_key']) ? (string)$resolved['entity']['translation_key'] : '',
        'origin'=>$origin
    );
    try {
        $result = dmdha_ha_request($resolved['instance'],'/api/services/'.$parts[0].'/'.$parts[1],'POST',$payload,false);
        dmdha_log('entity.control',$resource['id'],'success',$details,$resolved['instance']['owner']);
        $commandInfo=dmdha_actionhub_proxmox_command_info($resolved['entity'],isset($allowed['label'])?(string)$allowed['label']:$service);
        $targetLabel=trim((string)(isset($resolved['entity']['display']['device_group_label'])?$resolved['entity']['display']['device_group_label']:''));
        if($targetLabel==='')$targetLabel=trim((string)$resolved['entity']['friendly_name']);
        $sentLabel=trim((string)(isset($commandInfo['label'])?$commandInfo['label']:''));
        $message='Commande Home Assistant envoyée.';
        if($targetLabel!==''&&$sentLabel!=='')$message='Commande envoyée : '.$targetLabel.' — '.$sentLabel.'.';
        return dmdha_actionhub_result(true,$message,array('result'=>$result,'resource'=>$resource,'entity_id'=>$resolved['entity_id'],'service'=>$service,'translation_key'=>isset($resolved['entity']['translation_key'])?(string)$resolved['entity']['translation_key']:''));
    } catch (Exception $e) {
        $details['error'] = dmdha_substr($e->getMessage(),0,220);
        dmdha_log('entity.control',$resource['id'],'error',$details,$resolved['instance']['owner']);
        return dmdha_actionhub_result(false,$e->getMessage(),array('resource'=>$resource),'home_assistant_error');
    }
}

function dmdha_actionhub_handle($context) {
    $context = is_array($context) ? $context : array();
    $email = isset($context['email']) ? dmdha_safe_email($context['email']) : '';
    $action = isset($context['action']) && is_array($context['action']) ? $context['action'] : array();
    $payload = isset($context['payload']) && is_array($context['payload']) ? $context['payload'] : array();
    $resource = isset($context['resource']) && is_array($context['resource']) ? $context['resource'] : null;
    $actionId = trim((string)(isset($action['id'])?$action['id']:''));
    if ($email === '' || $actionId === '') return dmdha_actionhub_result(false,'Requête ActionHub invalide.',array(),'invalid_request');

    $actionMeta = isset($action['meta']) && is_array($action['meta']) ? $action['meta'] : array();
    if (!empty($actionMeta['ha_scenario'])) {
        $scenarioPayload = array(
            'instance_ref'=>isset($actionMeta['instance_ref']) ? $actionMeta['instance_ref'] : '',
            'entity_id'=>isset($actionMeta['entity_id']) ? $actionMeta['entity_id'] : ''
        );
        try { $resolved = dmdha_actionhub_resolve_payload($email,$scenarioPayload); }
        catch (Exception $e) { return dmdha_actionhub_result(false,$e->getMessage(),array(),'resource_not_found'); }
        $service = trim((string)(isset($actionMeta['service'])?$actionMeta['service']:''));
        $widget = trim((string)(isset($actionMeta['widget'])?$actionMeta['widget']:'power'));
        $value = isset($payload['value']) ? $payload['value'] : null;
        return dmdha_actionhub_execute_service($email,$resolved,$service,$widget,$value,array(),'actionhub_scenario');
    }

    if ($actionId === 'entity.scenario_command') {
        try { $resolved = dmdha_actionhub_resolve_payload($email,$payload); }
        catch (Exception $e) { return dmdha_actionhub_result(false,$e->getMessage(),array(),'resource_not_found'); }
        $service = trim((string)(isset($payload['service'])?$payload['service']:''));
        $widget = trim((string)(isset($payload['widget'])?$payload['widget']:'power'));
        $value = isset($payload['value']) ? $payload['value'] : null;
        return dmdha_actionhub_execute_service($email,$resolved,$service,$widget,$value,array(),'actionhub_scenario_legacy');
    }

    try { $resolved = dmdha_actionhub_resolve_resource($email,$resource); }
    catch (Exception $e) { return dmdha_actionhub_result(false,$e->getMessage(),array(),'resource_not_found'); }
    if (!$resolved) return dmdha_actionhub_result(false,'Périphérique Home Assistant introuvable ou non partagé.',array(),'resource_not_found');

    if ($actionId === 'entity.inspect') {
        $entity = $resolved['entity'];
        dmdha_log('entity.inspect',$resolved['resource']['id'],'success',array(
            'entity_id'=>$resolved['entity_id'],'name'=>$entity['friendly_name'],'instance_name'=>$resolved['instance']['name'],'origin'=>'actionhub'
        ),$resolved['instance']['owner']);
        return dmdha_actionhub_result(true,'État Home Assistant actualisé.',array('entity'=>$entity,'resource'=>$resolved['resource']));
    }

    $meta = isset($action['meta']) && is_array($action['meta']) ? $action['meta'] : array();
    $service = trim((string)(isset($meta['service'])?$meta['service']:''));
    $widget = trim((string)(isset($meta['widget'])?$meta['widget']:'power'));
    $value = isset($payload['value']) ? $payload['value'] : null;
    return dmdha_actionhub_execute_service($email,$resolved,$service,$widget,$value,array(),'actionhub');
}
