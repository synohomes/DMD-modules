<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




require_once __DIR__ . '/dmd-ha-v2_lib.php';
require_once __DIR__ . '/dmd-ha-v2_actionhub.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function audit_out($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function audit_domain($entityId) {
    $p = strpos((string)$entityId, '.');
    return $p === false ? '' : strtolower(substr((string)$entityId, 0, $p));
}

function audit_service_keys_for_domain($services, $domain) {
    $out = array();
    $prefix = $domain . '.';
    foreach ((array)$services as $key => $def) {
        if (strpos((string)$key, $prefix) === 0) $out[] = (string)$key;
    }
    sort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return $out;
}

function audit_preset_actions($preset, $services) {
    $out = array();
    foreach ((array)(isset($preset['actions']) ? $preset['actions'] : array()) as $a) {
        if (!is_array($a)) continue;
        $service = trim((string)(isset($a['service']) ? $a['service'] : ''));
        $widget = trim((string)(isset($a['widget']) ? $a['widget'] : 'power'));
        if ($service === '') continue;
        $out[] = array(
            'label' => trim((string)(isset($a['label']) ? $a['label'] : $service)),
            'service' => $service,
            'widget' => $widget,
            'service_exists_in_ha' => isset($services[$service])
        );
    }
    return $out;
}

try {
    dmdha_require_login();
    if (!dmdha_is_superadmin()) {
        audit_out(array('ok'=>false,'error'=>'Audit réservé au superadmin.'), 403);
    }

    $email = dmdha_current_email();
    $instances = dmdha_load_instances($email);
    $scenarioActions = dmdha_actionhub_scenario_actions($email);

    $actionhubByEntity = array();
    foreach ((array)$scenarioActions as $a) {
        if (!is_array($a)) continue;
        $meta = isset($a['meta']) && is_array($a['meta']) ? $a['meta'] : array();
        $eid = trim((string)(isset($meta['entity_id']) ? $meta['entity_id'] : ''));
        $ref = trim((string)(isset($meta['instance_ref']) ? $meta['instance_ref'] : ''));
        if ($eid === '' || $ref === '') continue;
        $k = $ref . '|' . $eid;
        if (!isset($actionhubByEntity[$k])) $actionhubByEntity[$k] = array();
        $actionhubByEntity[$k][] = array(
            'id' => isset($a['id']) ? (string)$a['id'] : '',
            'label' => isset($a['label']) ? (string)$a['label'] : '',
            'group' => isset($a['group']) ? (string)$a['group'] : '',
            'permission' => isset($a['permission']) ? (string)$a['permission'] : '',
            'inputs' => isset($a['inputs']) && is_array($a['inputs']) ? $a['inputs'] : array(),
            'service' => isset($meta['service']) ? (string)$meta['service'] : '',
            'widget' => isset($meta['widget']) ? (string)$meta['widget'] : ''
        );
    }

    $report = array(
        'ok' => true,
        'generated_at' => date('c'),
        'module' => DMDHA_MODULE_ID,
        'module_version' => defined('DMDHA_MODULE_VERSION') ? DMDHA_MODULE_VERSION : '',
        'user' => $email,
        'note' => 'Lecture seule. Aucun token, clé secrète ou en-tête Authorization n’est exporté.',
        'permissions' => dmdha_permissions_snapshot(),
        'shares_file_exists' => is_file(dmdha_shares_file()),
        'actionhub_total_actions' => count($scenarioActions),
        'actionhub_actions' => $scenarioActions,
        'instances' => array()
    );

    foreach ($instances as $instance) {
        if (!is_array($instance)) continue;
        $ref = dmdha_instance_ref($email, $instance['id']);
        $selected = isset($instance['entities']) && is_array($instance['entities']) ? array_values($instance['entities']) : array();
        $selectedMap = array_fill_keys($selected, true);

        $item = array(
            'id' => isset($instance['id']) ? (string)$instance['id'] : '',
            'ref' => $ref,
            'name' => isset($instance['name']) ? (string)$instance['name'] : '',
            'base_url' => isset($instance['base_url']) ? (string)$instance['base_url'] : '',
            'enabled' => !empty($instance['enabled']),
            'verify_ssl' => !empty($instance['verify_ssl']),
            'selected_count' => count($selected),
            'selected_entity_ids' => $selected,
            'ha' => array(),
            'domains' => array(),
            'selected_analysis' => array(),
            'unselected_entities' => array(),
            'errors' => array()
        );

        try {
            $cfg = dmdha_ha_request($instance, '/api/config', 'GET', null, false);
            $item['ha']['location_name'] = isset($cfg['location_name']) ? (string)$cfg['location_name'] : '';
            $item['ha']['version'] = isset($cfg['version']) ? (string)$cfg['version'] : '';
        } catch (Exception $e) {
            $item['errors'][] = 'config: ' . $e->getMessage();
        }

        $states = array();
        try {
            $states = dmdha_ha_request($instance, '/api/states', 'GET', null, false);
            $item['ha']['entities_total'] = count($states);
        } catch (Exception $e) {
            $item['errors'][] = 'states: ' . $e->getMessage();
        }

        $services = array();
        try {
            $services = dmdha_services_for_instance($instance);
            $item['ha']['services_total'] = count($services);
            $item['ha']['services'] = array_keys($services);
        } catch (Exception $e) {
            $item['errors'][] = 'services: ' . $e->getMessage();
        }

        $metadata = array();
        try {
            $metadata = dmdha_registry_metadata($instance, true);
        } catch (Exception $e) {
            $item['errors'][] = 'registry: ' . $e->getMessage();
        }

        $stateMap = array();
        foreach ((array)$states as $state) {
            if (!is_array($state) || empty($state['entity_id'])) continue;
            $eid = (string)$state['entity_id'];
            $stateMap[$eid] = $state;
            $domain = audit_domain($eid);
            if (!isset($item['domains'][$domain])) $item['domains'][$domain] = 0;
            $item['domains'][$domain]++;

            if (!isset($selectedMap[$eid])) {
                $attrs = isset($state['attributes']) && is_array($state['attributes']) ? $state['attributes'] : array();
                $meta = isset($metadata[$eid]) && is_array($metadata[$eid]) ? $metadata[$eid] : array();
                $item['unselected_entities'][] = array(
                    'entity_id' => $eid,
                    'friendly_name' => isset($attrs['friendly_name']) ? (string)$attrs['friendly_name'] : $eid,
                    'domain' => $domain,
                    'device_class' => isset($attrs['device_class']) ? (string)$attrs['device_class'] : (isset($meta['original_device_class']) ? (string)$meta['original_device_class'] : ''),
                    'platform' => isset($meta['platform']) ? (string)$meta['platform'] : ''
                );
            }
        }
        ksort($item['domains'], SORT_NATURAL | SORT_FLAG_CASE);

        foreach ($selected as $eid) {
            $domain = audit_domain($eid);
            $exists = isset($stateMap[$eid]);
            $state = $exists ? $stateMap[$eid] : array('entity_id'=>$eid,'attributes'=>array());
            $attrs = isset($state['attributes']) && is_array($state['attributes']) ? $state['attributes'] : array();
            $meta = isset($metadata[$eid]) && is_array($metadata[$eid]) ? $metadata[$eid] : array();
            $preset = dmdha_match_preset($state, $meta);
            $required = isset($preset['required_control']) ? (string)$preset['required_control'] : 'entity.control';
            $k = $ref . '|' . $eid;

            $item['selected_analysis'][] = array(
                'entity_id' => $eid,
                'friendly_name' => isset($attrs['friendly_name']) ? (string)$attrs['friendly_name'] : $eid,
                'domain' => $domain,
                'exists_in_ha' => $exists,
                'device_class' => isset($attrs['device_class']) ? (string)$attrs['device_class'] : (isset($meta['original_device_class']) ? (string)$meta['original_device_class'] : ''),
                'platform' => isset($meta['platform']) ? (string)$meta['platform'] : '',
                'preset' => array(
                    'key' => isset($preset['key']) ? (string)$preset['key'] : '',
                    'label' => isset($preset['label']) ? (string)$preset['label'] : '',
                    'family' => isset($preset['_family_label']) ? (string)$preset['_family_label'] : '',
                    'required_control' => $required,
                    'actions' => audit_preset_actions($preset, $services)
                ),
                'ha_domain_services' => audit_service_keys_for_domain($services, $domain),
                'actionhub_actions_count' => isset($actionhubByEntity[$k]) ? count($actionhubByEntity[$k]) : 0,
                'actionhub_actions' => isset($actionhubByEntity[$k]) ? $actionhubByEntity[$k] : array(),
                'actionhub_missing_reason' => isset($actionhubByEntity[$k]) && count($actionhubByEntity[$k]) > 0 ? '' : (
                    !$exists ? 'Entité sélectionnée mais absente de /api/states.' : (
                        empty($preset['actions']) ? 'Le preset détecté ne déclare aucune action.' : (
                            !dmdha_user_permission($email, $required) ? 'Le droit DoMyDesk requis n’est pas accordé : ' . $required : 'À vérifier : filtrage ActionHub ou service/preset.'
                        )
                    )
                )
            );
        }

        usort($item['unselected_entities'], function($a, $b) {
            return strcasecmp((string)$a['entity_id'], (string)$b['entity_id']);
        });

        $report['instances'][] = $item;
    }

    audit_out($report, 200);
} catch (Exception $e) {
    audit_out(array(
        'ok'=>false,
        'error'=>$e->getMessage(),
        'note'=>'Aucun token ou secret n’est inclus dans ce rapport.'
    ), http_response_code() >= 400 ? http_response_code() : 500);
}
