<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */





declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-planning_lib.php';

if (!dmd_planning_has_permission('module.view')) {
    echo '<section class="dplm-denied">Accès à DMD-Planning refusé.</section>';
    return;
}

$documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? '')) ?: '';
$moduleDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-Planning';
if ($documentRoot !== '' && str_starts_with(str_replace('\\', '/', $moduleDir), str_replace('\\', '/', $documentRoot))) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleDir, strlen($documentRoot))), '/');
}
$moduleWebPath = rtrim($moduleWebPath, '/');
$baseWeb = preg_replace('~/modules/DMD-Planning$~i', '', $moduleWebPath) ?: '';
$apiUrl = $moduleWebPath . '/dmd-planning_api.php';

$email = dmd_planning_email();
$safeUser = function_exists('dmd_safe_user_key') ? dmd_safe_user_key($email) : basename($email);
$theme = 'default';
$themeCss = null;
if ($safeUser !== '') {
    $themeJson = rtrim($documentRoot, DIRECTORY_SEPARATOR) . '/users/profiles/' . $safeUser . '/theme.json';
    if (is_file($themeJson)) {
        $raw = json_decode((string)@file_get_contents($themeJson), true);
        if (is_array($raw) && !empty($raw['theme'])) {
            $candidate = basename((string)$raw['theme']);
            $candidateCss = rtrim($documentRoot, DIRECTORY_SEPARATOR) . '/theme/' . $candidate . '/style.css';
            if (is_file($candidateCss)) {
                $theme = $candidate;
                $themeCss = $candidateCss;
            }
        }
    }
}
if ($themeCss === null) {
    $defaultCss = rtrim($documentRoot, DIRECTORY_SEPARATOR) . '/theme/default/style.css';
    if (is_file($defaultCss)) $themeCss = $defaultCss;
}
$themeUrl = rtrim($baseWeb, '/') . '/theme/' . rawurlencode($theme) . '/style.css';
$cssVer = rawurlencode(DMD_PLANNING_VERSION) . '-' . (int)@filemtime(__DIR__ . '/dmd-planning-mydesk.css');
$jsVer = rawurlencode(DMD_PLANNING_VERSION) . '-' . (int)@filemtime(__DIR__ . '/dmd-planning-mydesk.js');
$uid = 'dplm-' . bin2hex(random_bytes(5));
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWebPath . '/dmd-planning-mydesk.css?v=' . $cssVer, ENT_QUOTES, 'UTF-8') ?>">
<section
    id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
    class="dplm-app"
    data-dplm-root
    data-api="<?= htmlspecialchars($apiUrl, ENT_QUOTES, 'UTF-8') ?>"
    data-module="<?= htmlspecialchars($moduleWebPath, ENT_QUOTES, 'UTF-8') ?>"
    data-icon="<?= htmlspecialchars($moduleWebPath . '/icon.png', ENT_QUOTES, 'UTF-8') ?>"
>
    <header class="dplm-topbar">
        <div class="dplm-brand">
            <img src="<?= htmlspecialchars($moduleWebPath . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt="">
            <div>
                <strong>DMD-Planning</strong>
                <small data-dplm-subtitle>Chargement…</small>
            </div>
        </div>
        <div class="dplm-top-actions">
            <button type="button" class="dplm-btn dplm-btn-light" data-dplm-today>Aujourd’hui</button>
            <button type="button" class="dplm-btn dplm-btn-primary" data-dplm-new>+ RDV</button>
        </div>
    </header>

    <section class="dplm-summary">
        <article class="dplm-stat">
            <strong data-dplm-stat-today>0</strong>
            <span>Aujourd’hui</span>
        </article>
        <article class="dplm-stat">
            <strong data-dplm-stat-week>0</strong>
            <span>Semaine</span>
        </article>
        <article class="dplm-stat">
            <strong data-dplm-stat-month>0</strong>
            <span>Mois</span>
        </article>
        <article class="dplm-stat">
            <strong data-dplm-stat-total>0</strong>
            <span>Affichés</span>
        </article>
    </section>

    <section class="dplm-toolbar">
        <div class="dplm-nav">
            <button type="button" class="dplm-icon-btn" data-dplm-prev aria-label="Précédent">‹</button>
            <div class="dplm-period" data-dplm-period>—</div>
            <button type="button" class="dplm-icon-btn" data-dplm-next aria-label="Suivant">›</button>
        </div>
        <div class="dplm-views">
            <button type="button" class="dplm-chip is-active" data-dplm-view="day">Jour</button>
            <button type="button" class="dplm-chip" data-dplm-view="week">Semaine</button>
            <button type="button" class="dplm-chip" data-dplm-view="month">Mois</button>
        </div>
        <div class="dplm-filters">
            <select data-dplm-planning></select>
            <input type="search" data-dplm-search placeholder="Rechercher un rendez-vous…">
            <button type="button" class="dplm-btn dplm-btn-light" data-dplm-refresh>Actualiser</button>
        </div>
    </section>

    <section class="dplm-content">
        <div class="dplm-groups" data-dplm-groups>
            <div class="dplm-loading">Chargement du planning…</div>
        </div>
    </section>

    <section class="dplm-drawer" data-dplm-detail hidden>
        <div class="dplm-sheet">
            <header class="dplm-sheet-head">
                <div>
                    <strong data-dplm-detail-title>Événement</strong>
                    <small data-dplm-detail-subtitle>—</small>
                </div>
                <button type="button" class="dplm-icon-btn" data-dplm-detail-close aria-label="Fermer">×</button>
            </header>
            <div class="dplm-sheet-body" data-dplm-detail-body></div>
            <footer class="dplm-sheet-foot">
                <select data-dplm-detail-status></select>
                <button type="button" class="dplm-btn dplm-btn-light" data-dplm-status-apply>Statut</button>
                <button type="button" class="dplm-btn dplm-btn-light" data-dplm-qs>QuickSession</button>
                <button type="button" class="dplm-btn dplm-btn-light" data-dplm-edit>Modifier</button>
                <button type="button" class="dplm-btn dplm-btn-danger" data-dplm-delete>Supprimer</button>
            </footer>
        </div>
    </section>

    <section class="dplm-drawer" data-dplm-editor hidden>
        <form class="dplm-sheet dplm-editor-sheet" data-dplm-form>
            <header class="dplm-sheet-head">
                <div>
                    <strong data-dplm-form-title>Nouveau rendez-vous</strong>
                    <small data-dplm-form-subtitle>Planning MyDesk</small>
                </div>
                <button type="button" class="dplm-icon-btn" data-dplm-editor-close aria-label="Fermer">×</button>
            </header>
            <div class="dplm-sheet-body">
                <input type="hidden" name="id">
                <div class="dplm-grid">
                    <label class="dplm-field dplm-col-2">
                        <span>Catégorie</span>
                        <select name="category_id" required data-dplm-category></select>
                    </label>
                    <label class="dplm-field dplm-col-2">
                        <span>Titre</span>
                        <input type="text" name="title" maxlength="180" required>
                    </label>
                    <label class="dplm-field">
                        <span>Date</span>
                        <input type="date" name="date" required>
                    </label>
                    <label class="dplm-field dplm-check">
                        <span>Journée entière</span>
                        <input type="checkbox" name="all_day" data-dplm-all-day>
                    </label>
                    <label class="dplm-field dplm-time-field">
                        <span>Début</span>
                        <input type="time" name="start_time">
                    </label>
                    <label class="dplm-field dplm-time-field">
                        <span>Fin</span>
                        <input type="time" name="end_time">
                    </label>
                    <label class="dplm-field">
                        <span>Statut</span>
                        <select name="status"></select>
                    </label>
                    <label class="dplm-field dplm-col-2">
                        <span>Notes</span>
                        <textarea name="notes" rows="4" maxlength="6000"></textarea>
                    </label>
                </div>
                <section class="dplm-custom" data-dplm-custom-fields></section>
                <p class="dplm-form-error" data-dplm-form-error hidden></p>
            </div>
            <footer class="dplm-sheet-foot">
                <button type="button" class="dplm-btn dplm-btn-light" data-dplm-editor-close-2>Annuler</button>
                <button type="submit" class="dplm-btn dplm-btn-primary" data-dplm-save>Enregistrer</button>
            </footer>
        </form>
    </section>
</section>
<script src="<?= htmlspecialchars($moduleWebPath . '/dmd-planning-mydesk.js?v=' . $jsVer, ENT_QUOTES, 'UTF-8') ?>"></script>
