<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




declare(strict_types=1);

if (!defined('DMD_PLANNING_ID')) define('DMD_PLANNING_ID', 'DMD-Planning');
if (!defined('DMD_PLANNING_VERSION')) define('DMD_PLANNING_VERSION', '1.2.2');

function dmd_planning_root(): string
{
    $root = realpath(__DIR__ . '/../..');
    return $root !== false ? $root : dirname(__DIR__, 2);
}

function dmd_planning_boot_core(): void
{
    static $done = false;
    if ($done) return;
    $done = true;
    $root = dmd_planning_root();
    foreach ([
        $root . '/core/dmd_security.php',
        $root . '/core/dmd_permissions.php',
        $root . '/core/dmd_system_services.php',
        $root . '/core/dmd_activity.php',
        $root . '/core/dmd_module_logs.php',
        $root . '/core/dmd_module_events.php',
        $root . '/core/dmd_notification_mail.php',
        $root . '/Quick-Session/dmd_quick_session.php',
        $root . '/core/dmd_quick_session.php',
    ] as $file) {
        if (is_file($file)) require_once $file;
    }
}

function dmd_planning_email(): string
{
    $email = trim((string)($_SESSION['user']['email'] ?? $_SESSION['email'] ?? $_SESSION['user_email'] ?? ''));
    return strtolower($email);
}

function dmd_planning_logged_in(): bool
{
    return filter_var(dmd_planning_email(), FILTER_VALIDATE_EMAIL) !== false;
}

function dmd_planning_has_permission(string $permission): bool
{
    if (!dmd_planning_logged_in()) return false;
    dmd_planning_boot_core();
    if (function_exists('dmd_current_user_has_module_permission')) {
        try {
            return (bool)dmd_current_user_has_module_permission(DMD_PLANNING_ID, $permission);
        } catch (Throwable $e) {
            return false;
        }
    }
    return false;
}

function dmd_planning_user_has_permission(string $email, string $permission): bool
{
    $email = strtolower(trim($email));
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return false;
    dmd_planning_boot_core();
    if (function_exists('dmd_user_has_module_permission')) {
        try {
            return (bool)dmd_user_has_module_permission($email, DMD_PLANNING_ID, $permission);
        } catch (Throwable $e) {
            return false;
        }
    }
    return false;
}

function dmd_planning_reply(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function dmd_planning_require_permission(string $permission): void
{
    if (!dmd_planning_has_permission($permission)) {
        dmd_planning_reply(['ok' => false, 'error' => 'permission_denied', 'permission' => $permission, 'message' => 'Droit insuffisant.'], 403);
    }
}

function dmd_planning_csrf(): string
{
    dmd_planning_boot_core();
    if (function_exists('dmd_csrf_token')) {
        try {
            return (string)dmd_csrf_token('dmd-planning');
        } catch (Throwable $e) {
        }
    }
    if (empty($_SESSION['dmd_planning_csrf'])) $_SESSION['dmd_planning_csrf'] = bin2hex(random_bytes(24));
    return (string)$_SESSION['dmd_planning_csrf'];
}

function dmd_planning_validate_csrf(string $token): bool
{
    if ($token === '') return false;
    dmd_planning_boot_core();
    if (function_exists('dmd_csrf_validate')) {
        try {
            return (bool)dmd_csrf_validate($token, 'dmd-planning');
        } catch (Throwable $e) {
        }
    }
    return hash_equals(dmd_planning_csrf(), $token);
}

function dmd_planning_system_dir(): string
{
    $dir = dmd_planning_root() . '/data/modules/' . DMD_PLANNING_ID;
    dmd_planning_protect_dir($dir);
    return $dir;
}

function dmd_planning_protect_dir(string $dir): void
{
    if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) {
        throw new RuntimeException('Impossible de créer le stockage DMD-Planning.');
    }
    @chmod($dir, 0770);
    $htaccess = $dir . '/.htaccess';
    if (!is_file($htaccess)) {
        @file_put_contents($htaccess, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n", LOCK_EX);
    }
    $index = $dir . '/index.php';
    if (!is_file($index)) @file_put_contents($index, "<?php http_response_code(404); exit;\n", LOCK_EX);
}

function dmd_planning_atomic_write(string $path, string $contents, int $mode = 0600): void
{
    $dir = dirname($path);
    dmd_planning_protect_dir($dir);
    $tmp = tempnam($dir, '.dpl2-');
    if ($tmp === false) throw new RuntimeException('Impossible de préparer l’écriture.');
    try {
        if (file_put_contents($tmp, $contents, LOCK_EX) === false) throw new RuntimeException('Impossible d’écrire les données.');
        @chmod($tmp, $mode);
        if (!@rename($tmp, $path)) {
            if (!@copy($tmp, $path)) throw new RuntimeException('Impossible de finaliser l’écriture.');
            @unlink($tmp);
        }
        @chmod($path, $mode);
    } finally {
        if (is_file($tmp)) @unlink($tmp);
    }
}

function dmd_planning_read_json(string $path, array $fallback = []): array
{
    if (!is_file($path)) return $fallback;
    $raw = @file_get_contents($path);
    if (!is_string($raw) || trim($raw) === '') return $fallback;
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : $fallback;
}

function dmd_planning_write_json(string $path, array $data): void
{
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) throw new RuntimeException('Encodage JSON impossible.');
    dmd_planning_atomic_write($path, $json . "\n");
}

function dmd_planning_clean($value, int $max = 255): string
{
    $value = trim(is_scalar($value) ? (string)$value : '');
    return function_exists('mb_substr') ? mb_substr($value, 0, $max, 'UTF-8') : substr($value, 0, $max);
}

function dmd_planning_slug($value, string $fallback = ''): string
{
    $value = strtolower(dmd_planning_clean($value, 100));
    if (function_exists('iconv')) {
        $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if (is_string($ascii) && $ascii !== '') $value = strtolower($ascii);
    }
    $value = preg_replace('/[^a-z0-9_.-]+/', '-', $value) ?: '';
    $value = trim($value, '-_.');
    return $value !== '' ? $value : $fallback;
}

function dmd_planning_valid_date(string $value): bool
{
    $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $dt !== false && $dt->format('Y-m-d') === $value;
}

function dmd_planning_valid_time(string $value): bool
{
    return preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/D', $value) === 1;
}

function dmd_planning_default_config(): array
{
    return [
        'timezone' => 'Europe/Paris',
        'default_view' => 'month',
        'week_starts_monday' => true,
        'day_start' => 7,
        'day_end' => 21,
        'slot_minutes' => 30,
        'reminders_enabled' => true,
        'all_day_reminder_time' => '09:00',
        'default_reminders' => [],
        'plannings' => [
            ['id' => 'general', 'name' => 'Planning général', 'enabled' => true],
        ],
        'categories' => [],
        'statuses' => [
            ['id' => 'planned', 'label' => 'Planifié', 'icon' => '🗓️'],
            ['id' => 'confirmed', 'label' => 'Confirmé', 'icon' => '✅'],
            ['id' => 'in_progress', 'label' => 'En cours', 'icon' => '▶️'],
            ['id' => 'done', 'label' => 'Terminé', 'icon' => '✔️'],
            ['id' => 'cancelled', 'label' => 'Annulé', 'icon' => '⛔'],
        ],
        'templates' => [],
    ];
}

function dmd_planning_field_types(): array
{
    return ['text', 'textarea', 'number', 'date', 'time', 'datetime', 'checkbox', 'select', 'email', 'phone'];
}

function dmd_planning_sanitize_color($value): string
{
    $value = strtolower(dmd_planning_clean($value, 16));
    return preg_match('/^#[0-9a-f]{6}$/', $value) ? $value : '#808080';
}

function dmd_planning_sanitize_reminders(array $rows, bool $withIds = false): array
{
    $out = [];
    $seen = [];
    foreach ($rows as $row) {
        if (!is_array($row)) continue;
        if (array_key_exists('enabled', $row) && empty($row['enabled'])) continue;
        $offset = (int)($row['offset_minutes'] ?? -1);
        if ($offset < 0 || $offset > 525600) continue;
        $channel = dmd_planning_slug($row['channel'] ?? 'internal', 'internal');
        if (!in_array($channel, ['internal', 'email', 'both'], true)) $channel = 'internal';
        $clean = ['offset_minutes' => $offset, 'channel' => $channel, 'enabled' => true];
        if ($withIds) {
            $id = dmd_planning_slug($row['id'] ?? '', '');
            if ($id === '' || isset($seen[$id])) {
                do {
                    $id = 'rem-' . bin2hex(random_bytes(5));
                } while (isset($seen[$id]));
            }
            $seen[$id] = true;
            $clean['id'] = $id;
        }
        $out[] = $clean;
        if (count($out) >= 12) break;
    }
    usort($out, static fn(array $a, array $b): int => ((int)$b['offset_minutes']) <=> ((int)$a['offset_minutes']));
    return $out;
}

function dmd_planning_sanitize_fields(array $rows): array
{
    $out = [];
    $seen = [];
    foreach ($rows as $row) {
        if (!is_array($row)) continue;
        $label = dmd_planning_clean($row['label'] ?? '', 80);
        if ($label === '') continue;
        $id = dmd_planning_slug($row['id'] ?? '', 'field-' . (count($out) + 1));
        if (isset($seen[$id])) continue;
        $type = dmd_planning_slug($row['type'] ?? 'text', 'text');
        if (!in_array($type, dmd_planning_field_types(), true)) $type = 'text';
        $options = [];
        foreach ((array)($row['options'] ?? []) as $option) {
            $option = dmd_planning_clean($option, 80);
            if ($option !== '' && !in_array($option, $options, true)) $options[] = $option;
            if (count($options) >= 40) break;
        }
        if ($options && in_array($type, ['text', 'textarea'], true)) $type = 'select';
        $seen[$id] = true;
        $out[] = [
            'id' => $id,
            'label' => $label,
            'type' => $type,
            'required' => !empty($row['required']),
            'options' => $options,
        ];
        if (count($out) >= 30) break;
    }
    return $out;
}

function dmd_planning_sanitize_config(array $input): array
{
    $defaults = dmd_planning_default_config();

    $view = dmd_planning_slug($input['default_view'] ?? $defaults['default_view'], 'month');
    if (!in_array($view, ['day', 'week', 'month'], true)) $view = 'month';

    $timezone = dmd_planning_clean($input['timezone'] ?? $defaults['timezone'], 80);
    if (!in_array($timezone, timezone_identifiers_list(), true)) $timezone = $defaults['timezone'];

    $dayStart = max(0, min(23, (int)($input['day_start'] ?? $defaults['day_start'])));
    $dayEnd = max($dayStart + 1, min(24, (int)($input['day_end'] ?? $defaults['day_end'])));
    $slot = (int)($input['slot_minutes'] ?? $defaults['slot_minutes']);
    if (!in_array($slot, [15, 30, 60], true)) $slot = 30;

    $plannings = [];
    $planningIds = [];
    foreach ((array)($input['plannings'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $name = dmd_planning_clean($row['name'] ?? '', 100);
        if ($name === '') continue;
        $id = dmd_planning_slug($row['id'] ?? '', 'planning-' . (count($plannings) + 1));
        if (isset($planningIds[$id])) continue;
        $planningIds[$id] = true;
        $plannings[] = [
            'id' => $id,
            'name' => $name,
            'enabled' => !array_key_exists('enabled', $row) || !empty($row['enabled']),
        ];
        if (count($plannings) >= 50) break;
    }
    if (!$plannings) {
        $plannings = $defaults['plannings'];
        $planningIds = ['general' => true];
    }

    $categories = [];
    $categoryIds = [];
    foreach ((array)($input['categories'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $name = dmd_planning_clean($row['name'] ?? '', 100);
        if ($name === '') continue;
        $id = dmd_planning_slug($row['id'] ?? '', 'category-' . (count($categories) + 1));
        if (isset($categoryIds[$id])) continue;
        $planningId = dmd_planning_slug($row['planning_id'] ?? '', '');
        if (!isset($planningIds[$planningId])) $planningId = (string)$plannings[0]['id'];
        $categoryIds[$id] = true;
        $categories[] = [
            'id' => $id,
            'planning_id' => $planningId,
            'name' => $name,
            'color' => dmd_planning_sanitize_color($row['color'] ?? '#808080'),
            'default_duration' => max(15, min(1440, (int)($row['default_duration'] ?? 60))),
            'all_day_default' => !empty($row['all_day_default']),
            'default_reminders' => dmd_planning_sanitize_reminders((array)($row['default_reminders'] ?? []), false),
            'fields' => dmd_planning_sanitize_fields((array)($row['fields'] ?? [])),
        ];
        if (count($categories) >= 150) break;
    }

    $statuses = [];
    $statusIds = [];
    foreach ((array)($input['statuses'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $label = dmd_planning_clean($row['label'] ?? '', 60);
        $id = dmd_planning_slug($row['id'] ?? '', 'status-' . (count($statuses) + 1));
        if ($label === '' || isset($statusIds[$id])) continue;
        $statusIds[$id] = true;
        $statuses[] = [
            'id' => $id,
            'label' => $label,
            'icon' => dmd_planning_clean($row['icon'] ?? '', 16),
        ];
        if (count($statuses) >= 30) break;
    }
    if (!$statuses) $statuses = $defaults['statuses'];

    $templates = [];
    $templateIds = [];
    foreach ((array)($input['templates'] ?? []) as $row) {
        if (!is_array($row)) continue;
        $name = dmd_planning_clean($row['name'] ?? '', 100);
        $planningName = dmd_planning_clean($row['planning_name'] ?? '', 100);
        if ($name === '' || $planningName === '') continue;
        $id = dmd_planning_slug($row['id'] ?? '', 'template-' . (count($templates) + 1));
        if (isset($templateIds[$id])) continue;
        $templateIds[$id] = true;
        $templateCategories = [];
        foreach ((array)($row['categories'] ?? []) as $cat) {
            if (!is_array($cat)) continue;
            $catName = dmd_planning_clean($cat['name'] ?? '', 100);
            if ($catName === '') continue;
            $templateCategories[] = [
                'id' => dmd_planning_slug($cat['id'] ?? '', 'category-' . (count($templateCategories) + 1)),
                'name' => $catName,
                'color' => dmd_planning_sanitize_color($cat['color'] ?? '#808080'),
                'default_duration' => max(15, min(1440, (int)($cat['default_duration'] ?? 60))),
                'all_day_default' => !empty($cat['all_day_default']),
                'default_reminders' => dmd_planning_sanitize_reminders((array)($cat['default_reminders'] ?? []), false),
                'fields' => dmd_planning_sanitize_fields((array)($cat['fields'] ?? [])),
            ];
        }
        $templates[] = [
            'id' => $id,
            'name' => $name,
            'description' => dmd_planning_clean($row['description'] ?? '', 300),
            'planning_name' => $planningName,
            'categories' => array_slice($templateCategories, 0, 100),
        ];
        if (count($templates) >= 60) break;
    }

    $allDayReminderTime = dmd_planning_clean($input['all_day_reminder_time'] ?? $defaults['all_day_reminder_time'], 5);
    if (!dmd_planning_valid_time($allDayReminderTime)) $allDayReminderTime = '09:00';

    return [
        'timezone' => $timezone,
        'default_view' => $view,
        'week_starts_monday' => !array_key_exists('week_starts_monday', $input) || !empty($input['week_starts_monday']),
        'day_start' => $dayStart,
        'day_end' => $dayEnd,
        'slot_minutes' => $slot,
        'reminders_enabled' => !array_key_exists('reminders_enabled', $input) || !empty($input['reminders_enabled']),
        'all_day_reminder_time' => $allDayReminderTime,
        'default_reminders' => dmd_planning_sanitize_reminders((array)($input['default_reminders'] ?? []), false),
        'plannings' => $plannings,
        'categories' => $categories,
        'statuses' => $statuses,
        'templates' => $templates,
    ];
}

function dmd_planning_config_file(): string
{
    return dmd_planning_system_dir() . '/config.json';
}

function dmd_planning_config(): array
{
    return dmd_planning_sanitize_config(dmd_planning_read_json(dmd_planning_config_file(), dmd_planning_default_config()));
}

function dmd_planning_save_config(array $config): array
{
    $clean = dmd_planning_sanitize_config($config);
    dmd_planning_write_json(dmd_planning_config_file(), $clean);
    return $clean;
}

function dmd_planning_events_file(): string
{
    return dmd_planning_system_dir() . '/events.json';
}

function dmd_planning_normalize_event(array $event): array
{
    $reminders = dmd_planning_sanitize_reminders((array)($event['reminders'] ?? []), true);
    $resources = [];
    foreach ((array)($event['resources'] ?? []) as $resource) {
        $clean = dmd_planning_sanitize_resource($resource);
        if ($clean !== null) $resources[] = $clean;
        if (count($resources) >= 50) break;
    }
    $fields = [];
    foreach ((array)($event['fields'] ?? []) as $key => $value) {
        $key = dmd_planning_slug($key, '');
        if ($key === '') continue;
        if (is_bool($value)) $fields[$key] = $value;
        elseif (is_scalar($value) || $value === null) $fields[$key] = dmd_planning_clean($value ?? '', 2000);
    }
    return [
        'id' => dmd_planning_valid_event_id($event['id'] ?? '') ?? '',
        'planning_id' => dmd_planning_slug($event['planning_id'] ?? '', ''),
        'category_id' => dmd_planning_slug($event['category_id'] ?? '', ''),
        'title' => dmd_planning_clean($event['title'] ?? '', 180),
        'all_day' => !empty($event['all_day']),
        'date' => dmd_planning_clean($event['date'] ?? '', 10),
        'start_time' => dmd_planning_clean($event['start_time'] ?? '', 5),
        'end_time' => dmd_planning_clean($event['end_time'] ?? '', 5),
        'status' => dmd_planning_slug($event['status'] ?? 'planned', 'planned'),
        'notes' => dmd_planning_clean($event['notes'] ?? '', 6000),
        'fields' => $fields,
        'resources' => $resources,
        'reminders' => $reminders,
        'owner' => strtolower(dmd_planning_clean($event['owner'] ?? '', 254)),
        'created_by' => strtolower(dmd_planning_clean($event['created_by'] ?? ($event['owner'] ?? ''), 254)),
        'updated_by' => strtolower(dmd_planning_clean($event['updated_by'] ?? ($event['created_by'] ?? $event['owner'] ?? ''), 254)),
        'created_at' => dmd_planning_clean($event['created_at'] ?? '', 40),
        'updated_at' => dmd_planning_clean($event['updated_at'] ?? '', 40),
    ];
}

function dmd_planning_events(): array
{
    $rows = dmd_planning_read_json(dmd_planning_events_file(), []);
    $out = [];
    foreach ($rows as $row) {
        if (!is_array($row)) continue;
        $event = dmd_planning_normalize_event($row);
        if ($event['id'] === '' || $event['title'] === '' || !dmd_planning_valid_date($event['date'])) continue;
        $out[] = $event;
    }
    return $out;
}

function dmd_planning_save_events(array $events): void
{
    dmd_planning_write_json(dmd_planning_events_file(), array_values($events));
}

function dmd_planning_mutate_events(callable $callback)
{
    $dir = dmd_planning_system_dir();
    $lock = @fopen($dir . '/events.lock', 'c+');
    if (!$lock) throw new RuntimeException('Verrou du planning indisponible.');
    try {
        if (!flock($lock, LOCK_EX)) throw new RuntimeException('Impossible de verrouiller le planning.');
        $events = dmd_planning_events();
        $result = $callback($events);
        dmd_planning_save_events($events);
        flock($lock, LOCK_UN);
        return $result;
    } finally {
        @fclose($lock);
    }
}

function dmd_planning_valid_event_id($id): ?string
{
    $id = strtolower(dmd_planning_clean($id, 80));
    return preg_match('/^[a-z0-9][a-z0-9_.:-]{5,79}$/D', $id) ? $id : null;
}

function dmd_planning_find_event(array $events, string $id): ?array
{
    foreach ($events as $event) if ((string)($event['id'] ?? '') === $id) return $event;
    return null;
}

function dmd_planning_find_event_index(array $events, string $id): int
{
    foreach ($events as $index => $event) if ((string)($event['id'] ?? '') === $id) return (int)$index;
    return -1;
}

function dmd_planning_planning(array $config, string $id): ?array
{
    foreach ((array)($config['plannings'] ?? []) as $row) if ((string)($row['id'] ?? '') === $id) return $row;
    return null;
}

function dmd_planning_category(array $config, string $id): ?array
{
    foreach ((array)($config['categories'] ?? []) as $row) if ((string)($row['id'] ?? '') === $id) return $row;
    return null;
}

function dmd_planning_status(array $config, string $id): ?array
{
    foreach ((array)($config['statuses'] ?? []) as $row) if ((string)($row['id'] ?? '') === $id) return $row;
    return null;
}

function dmd_planning_sanitize_resource($resource): ?array
{
    if (!is_array($resource)) return null;
    $id = dmd_planning_clean($resource['id'] ?? '', 255);
    $type = dmd_planning_slug($resource['type'] ?? '', '');
    $source = dmd_planning_clean($resource['source'] ?? ($resource['module'] ?? ''), 100);
    if ($id === '' || $type === '' || $source === '') return null;
    $tags = [];
    foreach ((array)($resource['tags'] ?? []) as $tag) {
        $tag = dmd_planning_clean($tag, 80);
        if ($tag !== '' && !in_array($tag, $tags, true)) $tags[] = $tag;
        if (count($tags) >= 20) break;
    }
    return [
        'id' => $id,
        'type' => $type,
        'local_id' => dmd_planning_clean($resource['local_id'] ?? '', 180),
        'name' => dmd_planning_clean($resource['name'] ?? ($resource['label'] ?? $id), 180),
        'label' => dmd_planning_clean($resource['label'] ?? ($resource['name'] ?? $id), 180),
        'source' => $source,
        'module' => dmd_planning_clean($resource['module'] ?? $source, 100),
        'owner' => strtolower(dmd_planning_clean($resource['owner'] ?? '', 254)),
        'tags' => $tags,
    ];
}

function dmd_planning_clean_event_input(array $input, array $config, ?array $old = null, ?string $actor = null): array
{
    $categoryId = dmd_planning_slug($input['category_id'] ?? ($old['category_id'] ?? ''), '');
    $category = dmd_planning_category($config, $categoryId);
    if (!$category) throw new InvalidArgumentException('Catégorie invalide.');
    $planningId = dmd_planning_slug($category['planning_id'] ?? '', '');
    $planning = dmd_planning_planning($config, $planningId);
    if (!$planning) throw new InvalidArgumentException('Planning de la catégorie introuvable.');

    $title = dmd_planning_clean($input['title'] ?? '', 180);
    if ($title === '') throw new InvalidArgumentException('Le titre est obligatoire.');
    $date = dmd_planning_clean($input['date'] ?? '', 10);
    if (!dmd_planning_valid_date($date)) throw new InvalidArgumentException('Date invalide.');

    $allDay = !empty($input['all_day']);
    $start = $allDay ? '' : dmd_planning_clean($input['start_time'] ?? '', 5);
    $end = $allDay ? '' : dmd_planning_clean($input['end_time'] ?? '', 5);
    if (!$allDay) {
        if (!dmd_planning_valid_time($start) || !dmd_planning_valid_time($end)) throw new InvalidArgumentException('Heure de début ou de fin invalide.');
        if ($end <= $start) throw new InvalidArgumentException('L’heure de fin doit être après l’heure de début.');
    }

    $statusId = dmd_planning_slug($input['status'] ?? ($old['status'] ?? ($config['statuses'][0]['id'] ?? 'planned')), 'planned');
    if (!dmd_planning_status($config, $statusId)) throw new InvalidArgumentException('Statut invalide.');

    $fields = [];
    $rawFields = is_array($input['fields'] ?? null) ? $input['fields'] : [];
    foreach ((array)($category['fields'] ?? []) as $definition) {
        $fid = (string)($definition['id'] ?? '');
        if ($fid === '') continue;
        $type = (string)($definition['type'] ?? 'text');
        $raw = $rawFields[$fid] ?? null;
        if ($type === 'checkbox') {
            $value = !empty($raw);
        } else {
            $value = dmd_planning_clean($raw ?? '', $type === 'textarea' ? 4000 : 500);
        }
        if (!empty($definition['required']) && (($type === 'checkbox' && !$value) || ($type !== 'checkbox' && $value === ''))) {
            throw new InvalidArgumentException('Le champ « ' . (string)$definition['label'] . ' » est obligatoire.');
        }
        if ($type === 'email' && $value !== '' && filter_var($value, FILTER_VALIDATE_EMAIL) === false) throw new InvalidArgumentException('Adresse e-mail invalide pour « ' . (string)$definition['label'] . ' ».');
        if ($type === 'select' && $value !== '' && !in_array($value, (array)($definition['options'] ?? []), true)) throw new InvalidArgumentException('Valeur invalide pour « ' . (string)$definition['label'] . ' ».');
        $fields[$fid] = $value;
    }

    $resources = [];
    foreach ((array)($input['resources'] ?? []) as $resource) {
        $clean = dmd_planning_sanitize_resource($resource);
        if ($clean !== null) $resources[$clean['id']] = $clean;
        if (count($resources) >= 50) break;
    }

    $reminders = dmd_planning_sanitize_reminders((array)($input['reminders'] ?? []), true);
    $now = date(DATE_ATOM);
    $actor = strtolower(trim($actor ?? dmd_planning_email()));
    $owner = strtolower(dmd_planning_clean($old['owner'] ?? $actor, 254));
    if (filter_var($owner, FILTER_VALIDATE_EMAIL) === false) $owner = $actor;

    return [
        'id' => (string)($old['id'] ?? ''),
        'planning_id' => $planningId,
        'category_id' => $categoryId,
        'title' => $title,
        'all_day' => $allDay,
        'date' => $date,
        'start_time' => $start,
        'end_time' => $end,
        'status' => $statusId,
        'notes' => dmd_planning_clean($input['notes'] ?? '', 6000),
        'fields' => $fields,
        'resources' => array_values($resources),
        'reminders' => $reminders,
        'owner' => $owner,
        'created_by' => strtolower(dmd_planning_clean($old['created_by'] ?? $actor, 254)),
        'updated_by' => $actor,
        'created_at' => dmd_planning_clean($old['created_at'] ?? $now, 40),
        'updated_at' => $now,
    ];
}

function dmd_planning_can_edit(array $event): bool
{
    $email = dmd_planning_email();
    return dmd_planning_has_permission('event.edit.all') || ($email !== '' && $email === (string)($event['owner'] ?? '') && dmd_planning_has_permission('event.edit'));
}

function dmd_planning_can_delete(array $event): bool
{
    $email = dmd_planning_email();
    return dmd_planning_has_permission('event.delete.all') || ($email !== '' && $email === (string)($event['owner'] ?? '') && dmd_planning_has_permission('event.delete'));
}

function dmd_planning_event_resource(array $event): array
{
    $id = (string)($event['id'] ?? '');
    $label = dmd_planning_clean($event['title'] ?? 'Événement Planning', 180);
    return [
        'id' => DMD_PLANNING_ID . ':event:' . $id,
        'type' => 'planning_event',
        'local_id' => $id,
        'name' => $label,
        'label' => $label,
        'owner' => (string)($event['owner'] ?? ''),
        'module' => DMD_PLANNING_ID,
        'source' => DMD_PLANNING_ID,
        'tags' => array_values(array_filter(['planning', (string)($event['planning_id'] ?? ''), (string)($event['category_id'] ?? ''), (string)($event['status'] ?? '')])),
    ];
}

function dmd_planning_event_changes(?array $before, array $after): array
{
    if ($before === null) return [];
    $changes = [];
    foreach (['planning_id', 'category_id', 'title', 'all_day', 'date', 'start_time', 'end_time', 'status', 'notes', 'fields', 'resources', 'reminders'] as $key) {
        $a = $before[$key] ?? null;
        $b = $after[$key] ?? null;
        if ($a !== $b) $changes[$key] = ['before' => $a, 'after' => $b];
    }
    return $changes;
}

function dmd_planning_append_log(array $row): void
{
    $dir = dmd_planning_system_dir() . '/logs';
    dmd_planning_protect_dir($dir);
    $line = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($line) || file_put_contents($dir . '/' . date('Y-m') . '.jsonl', $line . "\n", FILE_APPEND | LOCK_EX) === false) {
        throw new RuntimeException('Impossible d’écrire le journal DMD-Planning.');
    }
}

function dmd_planning_audit(string $action, array $event, string $status = 'success', array $details = [], array $changes = [], ?string $actor = null): array
{
    $actor = strtolower(trim($actor ?? dmd_planning_email()));
    if ($actor === '') $actor = 'system';
    $resource = dmd_planning_event_resource($event);
    $row = [
        'datetime' => date(DATE_ATOM),
        'module' => DMD_PLANNING_ID,
        'user' => $actor,
        'action' => $action,
        'target' => (string)($event['id'] ?? ''),
        'status' => $status,
        'details' => $details,
        'changes' => $changes,
        'resource' => $resource,
    ];
    try {
        dmd_planning_append_log($row);
    } catch (Throwable $e) {
    }
    dmd_planning_boot_core();
    if (function_exists('dmd_module_event')) {
        try {
            $result = dmd_module_event(DMD_PLANNING_ID, $action, $resource, [
                'email' => $actor,
                'label' => $action,
                'target' => $resource['label'],
                'status' => $status,
                'details' => json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '',
                'changes' => $changes,
                'meta' => ['source' => DMD_PLANNING_ID],
                'scope' => $actor === 'system' ? 'system' : 'user',
                'log' => false,
            ]);
            if (is_array($result) && !empty($result['event'])) $row['core_event'] = $result['event'];
        } catch (Throwable $e) {
        }
    }
    return $row;
}

function dmd_planning_recent_logs(int $limit = 150): array
{
    $limit = max(1, min(500, $limit));
    $files = glob(dmd_planning_system_dir() . '/logs/*.jsonl') ?: [];
    rsort($files, SORT_STRING);
    $rows = [];
    foreach ($files as $file) {
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) continue;
        for ($i = count($lines) - 1; $i >= 0; $i--) {
            $row = json_decode($lines[$i], true);
            if (!is_array($row)) continue;
            $rows[] = $row;
            if (count($rows) >= $limit) return $rows;
        }
    }
    return $rows;
}

function dmd_planning_emit_notification(string $eventId, array $event, array $config, string $details = '', ?string $actor = null): void
{
    dmd_planning_boot_core();
    if (!function_exists('dmd_notification_emit')) return;
    $planning = dmd_planning_planning($config, (string)($event['planning_id'] ?? ''));
    $category = dmd_planning_category($config, (string)($event['category_id'] ?? ''));
    $status = dmd_planning_status($config, (string)($event['status'] ?? ''));
    $actor = strtolower(trim($actor ?? dmd_planning_email()));
    try {
        dmd_notification_emit(strtolower(DMD_PLANNING_ID . '.' . $eventId), [
            'user' => $actor,
            'target' => (string)($event['title'] ?? ''),
            'target_user' => (string)($event['owner'] ?? ''),
            'module_id' => DMD_PLANNING_ID,
            'event_id_local' => (string)($event['id'] ?? ''),
            'event_title' => (string)($event['title'] ?? ''),
            'event_date' => (string)($event['date'] ?? ''),
            'event_time' => !empty($event['all_day']) ? 'journée' : (string)($event['start_time'] ?? ''),
            'planning' => (string)($planning['name'] ?? ($event['planning_id'] ?? '')),
            'category' => (string)($category['name'] ?? ($event['category_id'] ?? '')),
            'status' => (string)($status['label'] ?? ($event['status'] ?? '')),
            'details' => $details,
        ], ['level' => $eventId === 'event.cancelled' ? 'warning' : 'info']);
    } catch (Throwable $e) {
    }
}

function dmd_planning_reminder_state_file(): string
{
    return dmd_planning_system_dir() . '/reminders_state.json';
}

function dmd_planning_reminder_status(): array
{
    $state = dmd_planning_read_json(dmd_planning_reminder_state_file(), []);
    return [
        'last_run' => (string)($state['last_run'] ?? ''),
        'last_run_ts' => (int)($state['last_run_ts'] ?? 0),
        'last_sent' => (string)($state['last_sent'] ?? ''),
        'sent_total' => count((array)($state['sent'] ?? [])),
        'runner_path' => __DIR__ . '/dmd-planning_reminders.php',
    ];
}

function dmd_planning_event_start_timestamp(array $event, array $config): ?int
{
    $date = (string)($event['date'] ?? '');
    if (!dmd_planning_valid_date($date)) return null;
    $time = !empty($event['all_day']) ? (string)($config['all_day_reminder_time'] ?? '09:00') : (string)($event['start_time'] ?? '');
    if (!dmd_planning_valid_time($time)) return null;
    try {
        $tz = new DateTimeZone((string)($config['timezone'] ?? 'Europe/Paris'));
        $dt = DateTimeImmutable::createFromFormat('!Y-m-d H:i', $date . ' ' . $time, $tz);
        return $dt ? $dt->getTimestamp() : null;
    } catch (Throwable $e) {
        return null;
    }
}

function dmd_planning_reminder_before_label(int $minutes): string
{
    if ($minutes === 0) return 'à l’heure prévue';
    if ($minutes % 1440 === 0) {
        $n = intdiv($minutes, 1440);
        return $n . ' jour' . ($n > 1 ? 's' : '') . ' avant';
    }
    if ($minutes % 60 === 0) {
        $n = intdiv($minutes, 60);
        return $n . ' heure' . ($n > 1 ? 's' : '') . ' avant';
    }
    return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' avant';
}

function dmd_planning_emit_reminder_channel(string $channel, array $event, array $config, int $offsetMinutes): array
{
    $channel = $channel === 'email' ? 'email' : 'internal';
    $eventId = $channel === 'email' ? 'event.reminder_email' : 'event.reminder_internal';
    dmd_planning_boot_core();
    if (!function_exists('dmd_notification_emit')) return ['ok' => false, 'reason' => 'notification_engine_unavailable', 'internal' => 0, 'emails_sent' => 0, 'emails_queued' => 0];

    $planning = dmd_planning_planning($config, (string)($event['planning_id'] ?? ''));
    $category = dmd_planning_category($config, (string)($event['category_id'] ?? ''));
    $status = dmd_planning_status($config, (string)($event['status'] ?? ''));
    $owner = strtolower(trim((string)($event['owner'] ?? $event['created_by'] ?? '')));
    $recipients = filter_var($owner, FILTER_VALIDATE_EMAIL) ? [$owner] : [];
    $before = dmd_planning_reminder_before_label($offsetMinutes);

    try {
        $result = dmd_notification_emit(strtolower(DMD_PLANNING_ID . '.' . $eventId), [
            'user' => $owner,
            'target' => (string)($event['title'] ?? ''),
            'target_user' => $owner,
            'recipient_emails' => $recipients,
            'module_id' => DMD_PLANNING_ID,
            'event_id_local' => (string)($event['id'] ?? ''),
            'event_title' => (string)($event['title'] ?? ''),
            'event_date' => (string)($event['date'] ?? ''),
            'event_time' => !empty($event['all_day']) ? 'journée' : (string)($event['start_time'] ?? ''),
            'planning' => (string)($planning['name'] ?? ($event['planning_id'] ?? '')),
            'category' => (string)($category['name'] ?? ($event['category_id'] ?? '')),
            'status' => (string)($status['label'] ?? ($event['status'] ?? '')),
            'reminder_before' => $before,
            'reminder_minutes' => $offsetMinutes,
            'details' => 'Rappel ' . $before . ' pour « ' . (string)($event['title'] ?? '') . ' ».',
        ], ['level' => 'info']);
        return is_array($result) ? $result : ['ok' => false, 'reason' => 'invalid_notification_result', 'internal' => 0, 'emails_sent' => 0, 'emails_queued' => 0];
    } catch (Throwable $e) {
        return ['ok' => false, 'reason' => 'notification_exception', 'message' => $e->getMessage(), 'internal' => 0, 'emails_sent' => 0, 'emails_queued' => 0];
    }
}

function dmd_planning_process_due_reminders(?int $now = null, bool $force = false): array
{
    $now = $now ?? time();
    $config = dmd_planning_config();
    if (empty($config['reminders_enabled'])) return ['ok' => true, 'enabled' => false, 'checked' => 0, 'sent' => 0, 'pending' => 0, 'last_run' => ''];

    $dir = dmd_planning_system_dir();
    $lock = @fopen($dir . '/reminders.lock', 'c+');
    if (!$lock) return ['ok' => false, 'error' => 'reminder_lock_unavailable', 'checked' => 0, 'sent' => 0, 'pending' => 0];
    try {
        if (!@flock($lock, LOCK_EX | LOCK_NB)) return ['ok' => true, 'busy' => true, 'checked' => 0, 'sent' => 0, 'pending' => 0];
        $state = dmd_planning_read_json(dmd_planning_reminder_state_file(), ['sent' => [], 'attempts' => []]);
        $state['sent'] = is_array($state['sent'] ?? null) ? $state['sent'] : [];
        $state['attempts'] = is_array($state['attempts'] ?? null) ? $state['attempts'] : [];
        $lastRun = (int)($state['last_run_ts'] ?? 0);
        if (!$force && $lastRun > 0 && ($now - $lastRun) < 45) {
            return ['ok' => true, 'throttled' => true, 'checked' => 0, 'sent' => 0, 'pending' => 0, 'last_run' => (string)($state['last_run'] ?? '')];
        }

        $checked = 0;
        $sentCount = 0;
        $pending = 0;
        $errors = [];
        foreach (dmd_planning_events() as $event) {
            if (in_array((string)($event['status'] ?? ''), ['done', 'cancelled'], true)) continue;
            $eventTs = dmd_planning_event_start_timestamp($event, $config);
            if (!$eventTs || $now >= $eventTs) continue;
            foreach (dmd_planning_sanitize_reminders((array)($event['reminders'] ?? []), true) as $reminder) {
                $checked++;
                $offset = (int)$reminder['offset_minutes'];
                $dueTs = $eventTs - ($offset * 60);
                if ($now < $dueTs) continue;
                $channels = (string)$reminder['channel'] === 'both' ? ['internal', 'email'] : [(string)$reminder['channel']];
                foreach ($channels as $channel) {
                    $signature = implode('|', [
                        (string)($event['id'] ?? ''),
                        (string)($reminder['id'] ?? ''),
                        $channel,
                        (string)($event['date'] ?? ''),
                        (string)($event['start_time'] ?? ''),
                        !empty($event['all_day']) ? '1' : '0',
                        (string)$offset,
                        (string)($event['owner'] ?? ''),
                    ]);
                    $key = hash('sha256', $signature);
                    if (isset($state['sent'][$key])) continue;
                    $pending++;
                    $lastAttempt = (int)($state['attempts'][$key]['ts'] ?? 0);
                    if (!$force && $lastAttempt > 0 && ($now - $lastAttempt) < 900) continue;
                    $delivery = dmd_planning_emit_reminder_channel($channel, $event, $config, $offset);
                    $delivered = (int)($delivery['internal'] ?? 0) + (int)($delivery['emails_sent'] ?? 0) + (int)($delivery['emails_queued'] ?? 0);
                    $state['attempts'][$key] = ['ts' => $now, 'at' => date(DATE_ATOM, $now), 'result' => $delivery];
                    if ($delivered > 0) {
                        $state['sent'][$key] = [
                            'sent_at' => date(DATE_ATOM, $now),
                            'event_id' => (string)($event['id'] ?? ''),
                            'event_ts' => $eventTs,
                            'reminder_id' => (string)($reminder['id'] ?? ''),
                            'channel' => $channel,
                            'offset_minutes' => $offset,
                            'delivery' => $delivery,
                        ];
                        unset($state['attempts'][$key]);
                        $state['last_sent'] = date(DATE_ATOM, $now);
                        $sentCount++;
                        dmd_planning_audit('event.reminder_sent', $event, 'success', ['channel' => $channel, 'offset_minutes' => $offset], [], 'system');
                    } elseif (empty($delivery['ok'])) {
                        $errors[] = ['event_id' => (string)($event['id'] ?? ''), 'channel' => $channel, 'reason' => (string)($delivery['reason'] ?? 'unknown')];
                    }
                }
            }
        }

        foreach ($state['sent'] as $key => $row) if ((int)($row['event_ts'] ?? 0) < $now - 7776000) unset($state['sent'][$key]);
        foreach ($state['attempts'] as $key => $row) if ((int)($row['ts'] ?? 0) < $now - 604800) unset($state['attempts'][$key]);
        $state['last_run_ts'] = $now;
        $state['last_run'] = date(DATE_ATOM, $now);
        $state['last_stats'] = ['checked' => $checked, 'sent' => $sentCount, 'pending' => $pending, 'errors' => count($errors)];
        dmd_planning_write_json(dmd_planning_reminder_state_file(), $state);
        @flock($lock, LOCK_UN);
        return ['ok' => true, 'enabled' => true, 'checked' => $checked, 'sent' => $sentCount, 'pending' => $pending, 'errors' => $errors, 'last_run' => $state['last_run']];
    } finally {
        @fclose($lock);
    }
}

function dmd_planning_set_status(string $id, string $status, string $source = 'ui', ?string $actor = null): array
{
    $config = dmd_planning_config();
    if (!dmd_planning_status($config, $status)) throw new InvalidArgumentException('Statut invalide.');
    $actor = strtolower(trim($actor ?? dmd_planning_email()));
    $result = dmd_planning_mutate_events(function (array &$events) use ($id, $status, $actor): array {
        $index = dmd_planning_find_event_index($events, $id);
        if ($index < 0) throw new OutOfBoundsException('Événement introuvable.');
        $before = $events[$index];
        $events[$index]['status'] = $status;
        $events[$index]['updated_at'] = date(DATE_ATOM);
        $events[$index]['updated_by'] = $actor;
        return ['before' => $before, 'after' => $events[$index]];
    });
    $changes = dmd_planning_event_changes($result['before'], $result['after']);
    dmd_planning_audit('event.status_changed', $result['after'], 'success', ['source' => $source], $changes, $actor);
    dmd_planning_emit_notification($status === 'cancelled' ? 'event.cancelled' : 'event.status_changed', $result['after'], $config, 'Source : ' . $source, $actor);
    return $result['after'];
}
