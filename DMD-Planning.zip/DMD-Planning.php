<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */





declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-planning_lib.php';

if (!dmd_planning_has_permission('module.view')) {
    echo '<section class="dpl2-tile dpl2-denied">Accès à DMD-Planning refusé.</section>';
    return;
}

$documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? '')) ?: '';
$moduleDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-Planning';
if ($documentRoot !== '' && str_starts_with(str_replace('\\', '/', $moduleDir), str_replace('\\', '/', $documentRoot))) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleDir, strlen($documentRoot))), '/');
}
$baseWeb = preg_replace('~/modules/DMD-Planning$~i', '', $moduleWebPath) ?: '';
$apiUrl = rtrim($moduleWebPath, '/') . '/dmd-planning_api.php';
$actionHubUrl = rtrim($baseWeb, '/') . '/ActionHub/api.php';
$uid = 'dpl2-' . bin2hex(random_bytes(5));
$cssVer = rawurlencode(DMD_PLANNING_VERSION) . '-' . (int)@filemtime(__DIR__ . '/dmd-planning.css');
$jsVer = rawurlencode(DMD_PLANNING_VERSION) . '-' . (int)@filemtime(__DIR__ . '/dmd-planning.js');
?>
<link rel="stylesheet" href="<?= htmlspecialchars(rtrim($moduleWebPath, '/') . '/dmd-planning.css?v=' . $cssVer, ENT_QUOTES, 'UTF-8') ?>">
<section
    id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
    class="dpl2-tile"
    data-dpl2-root
    data-build="<?= htmlspecialchars(DMD_PLANNING_VERSION, ENT_QUOTES, 'UTF-8') ?>"
    data-api="<?= htmlspecialchars($apiUrl, ENT_QUOTES, 'UTF-8') ?>"
    data-actionhub-api="<?= htmlspecialchars($actionHubUrl, ENT_QUOTES, 'UTF-8') ?>"
    data-icon="<?= htmlspecialchars(rtrim($moduleWebPath, '/') . '/modicone.png', ENT_QUOTES, 'UTF-8') ?>"
>
    <header class="dpl2-tile-head">
        <div class="dpl2-tile-brand">
            <img src="<?= htmlspecialchars(rtrim($moduleWebPath, '/') . '/modicone.png', ENT_QUOTES, 'UTF-8') ?>" alt="" width="32" height="32">
            <div>
                <strong>DMD-Planning</strong>
                <span>Planning métier configurable</span>
            </div>
        </div>
        <button type="button" class="dpl2-btn dpl2-btn-primary" data-dpl2-open>Ouvrir</button>
    </header>
    <div class="dpl2-tile-body" data-dpl2-tile-body>
        <span class="dpl2-muted">Chargement…</span>
    </div>
</section>
<script src="<?= htmlspecialchars(rtrim($moduleWebPath, '/') . '/dmd-planning.js?v=' . $jsVer, ENT_QUOTES, 'UTF-8') ?>"></script>
