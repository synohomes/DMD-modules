<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */





declare(strict_types=1);
require_once __DIR__ . '/dmd-planning_lib.php';

function dmd_planning_actionhub_local_id($resource): ?string
{
    if (!is_array($resource)) return null;

    foreach (['local_id', 'event_id', 'target', 'target_id'] as $key) {
        $local = dmd_planning_valid_event_id($resource[$key] ?? '');
        if ($local) return $local;
    }

    $id = trim((string)($resource['id'] ?? $resource['resource_id'] ?? ''));
    if ($id === '') return null;
    $prefixes = [
        DMD_PLANNING_ID . ':event:',
        strtolower(DMD_PLANNING_ID) . ':event:',
        DMD_PLANNING_ID . ':',
        strtolower(DMD_PLANNING_ID) . ':',
    ];
    foreach ($prefixes as $prefix) {
        if (str_starts_with(strtolower($id), strtolower($prefix))) {
            $candidate = substr($id, strlen($prefix));
            $local = dmd_planning_valid_event_id($candidate);
            if ($local) return $local;
        }
    }
    return dmd_planning_valid_event_id($id);
}

function dmd_planning_actionhub_event($resource): ?array
{
    $id = dmd_planning_actionhub_local_id($resource);
    if (!$id) return null;
    $event = dmd_planning_find_event(dmd_planning_events(), $id);
    return is_array($event) ? $event : null;
}

function dmd_planning_actionhub_catalog($context): array
{
    $context = is_array($context) ? $context : [];
    $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;
    $config = dmd_planning_config();

    $createInputs = [
        ['id'=>'title','label'=>'Titre','type'=>'text','required'=>true],
        ['id'=>'date','label'=>'Date','type'=>'date','required'=>true],
        ['id'=>'time','label'=>'Heure','type'=>'text','required'=>false,'placeholder'=>'HH:MM'],
        ['id'=>'duration','label'=>'Durée en minutes','type'=>'number','required'=>false,'default'=>60],
        [
            'id'=>'category_id','label'=>'Catégorie','type'=>'select','required'=>false,
            'options'=>array_values(array_map(static fn(array $cat): array => [
                'value'=>(string)($cat['id'] ?? ''),
                'label'=>(string)($cat['name'] ?? ($cat['id'] ?? 'Catégorie')),
            ], array_filter((array)($config['categories'] ?? []), static fn($cat): bool => is_array($cat) && !empty($cat['id'])))),
        ],
        ['id'=>'notes','label'=>'Notes','type'=>'textarea','required'=>false],
    ];

    if (!$resource) {
        return ['replace'=>true, 'actions'=>[[
            'id'=>'event.create-scenario','label'=>'Créer un événement Planning','description'=>'Crée un événement depuis un scénario ActionHub.','icon'=>'📅',
            'permission'=>'event.create','scope'=>'module','scenario'=>true,'group'=>'Planning','inputs'=>$createInputs,
        ]]];
    }

    $event = dmd_planning_actionhub_event($resource);
    if (!$event) return ['replace'=>true, 'actions'=>[]];

    $actions = [[
        'id'=>'event.open','label'=>'Ouvrir la fiche','description'=>'Ouvre la fiche de cet événement dans DMD-Planning.','icon'=>'📅',
        'permission'=>'module.view','resource_types'=>['planning_event'],'scope'=>'resource','group'=>'Planning',
    ]];

    if (dmd_planning_can_edit($event)) {
        $actions[] = [
            'id'=>'event.edit','label'=>'Modifier le rendez-vous','description'=>'Ouvre cet événement directement en modification.','icon'=>'✏️',
            'permission'=>'module.view','resource_types'=>['planning_event'],'scope'=>'resource','group'=>'Planning',
        ];
    }

    $status = (string)($event['status'] ?? 'planned');
    if ($status !== 'done') {
        $actions[] = ['id'=>'event.complete','label'=>'Marquer terminé','description'=>'Passe l’événement à l’état terminé.','icon'=>'✅','permission'=>'event.status','resource_types'=>['planning_event'],'scope'=>'resource','group'=>'Statut'];
    }
    if ($status !== 'cancelled') {
        $actions[] = ['id'=>'event.cancel','label'=>'Annuler l’événement','description'=>'Passe l’événement à l’état annulé.','icon'=>'⛔','permission'=>'event.status','resource_types'=>['planning_event'],'scope'=>'resource','group'=>'Statut'];
    }
    if (in_array($status, ['done','cancelled'], true)) {
        $actions[] = ['id'=>'event.reopen','label'=>'Rouvrir l’événement','description'=>'Repasse l’événement à l’état planifié.','icon'=>'↩️','permission'=>'event.status','resource_types'=>['planning_event'],'scope'=>'resource','group'=>'Statut'];
    }

    if (dmd_planning_can_delete($event)) {
        $actions[] = [
            'id'=>'event.delete','label'=>'Supprimer le rendez-vous','description'=>'Supprime définitivement cet événement.','icon'=>'🗑️',
            'permission'=>'module.view','resource_types'=>['planning_event'],'scope'=>'resource','group'=>'Gestion','dangerous'=>true,
            'confirm'=>'Supprimer définitivement ce rendez-vous ?',
        ];
    }

    return ['replace'=>true, 'actions'=>$actions];
}

function dmd_planning_actionhub_handle($context): array
{
    $context = is_array($context) ? $context : [];
    $email = strtolower(trim((string)($context['email'] ?? '')));
    $actionRaw = $context['action'] ?? $context['action_id'] ?? '';
    $action = is_array($actionRaw) ? $actionRaw : ['id' => (string)$actionRaw];
    $actionId = trim((string)($action['id'] ?? $context['action_id'] ?? ''));
    $payload = is_array($context['payload'] ?? null) ? $context['payload'] : (is_array($context['inputs'] ?? null) ? $context['inputs'] : []);
    $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;
    if (!$resource && is_array($context['source'] ?? null)) $resource = $context['source'];
    if (!$resource && !empty($payload['event_id'])) $resource = ['local_id' => $payload['event_id']];

    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false || $email !== dmd_planning_email()) {
        return ['ok'=>false,'error'=>'invalid_user','message'=>'Utilisateur invalide.'];
    }
    if ($actionId === 'event.create-scenario') {
        $config = dmd_planning_config();
        $categories = array_values(array_filter((array)($config['categories'] ?? []), static fn(array $c): bool => dmd_planning_planning($config, (string)($c['planning_id'] ?? '')) !== null));
        if (!$categories) return ['ok'=>false,'error'=>'planning_not_configured','message'=>'Aucune catégorie DMD-Planning n’est configurée.'];

        $requestedCategory = dmd_planning_slug($payload['category_id'] ?? '', '');
        $category = $requestedCategory !== '' ? dmd_planning_category($config, $requestedCategory) : null;
        if (!$category) $category = $categories[0];
        $date = dmd_planning_clean($payload['date'] ?? '', 10);
        $time = dmd_planning_clean($payload['time'] ?? '', 5);
        $allDay = $time === '';
        $duration = max(15, min(1440, (int)($payload['duration'] ?? ($category['default_duration'] ?? 60))));
        $end = '';
        if (!$allDay && dmd_planning_valid_date($date) && dmd_planning_valid_time($time)) {
            [$h,$m] = array_map('intval', explode(':', $time));
            $minutes = $h * 60 + $m + $duration;
            if ($minutes >= 1440) return ['ok'=>false,'error'=>'invalid_duration','message'=>'L’événement ne peut pas se terminer le lendemain.'];
            $end = sprintf('%02d:%02d', intdiv($minutes, 60), $minutes % 60);
        }

        $input = [
            'title'=>$payload['title'] ?? 'Événement ActionHub','date'=>$date,'all_day'=>$allDay,'start_time'=>$time,'end_time'=>$end,
            'category_id'=>$category['id'],'planning_id'=>$category['planning_id'],'status'=>$config['statuses'][0]['id'] ?? 'planned',
            'notes'=>$payload['notes'] ?? '','fields'=>[],'resources'=>[],'reminders'=>(array)($category['default_reminders'] ?? ($config['default_reminders'] ?? [])),
        ];
        try {
            $event = dmd_planning_clean_event_input($input, $config, null, $email);
            $event = dmd_planning_mutate_events(function (array &$events) use ($event): array {
                $new = $event;
                do { $new['id'] = 'evt-' . bin2hex(random_bytes(8)); } while (dmd_planning_find_event($events, $new['id']));
                $events[] = $new;
                return $new;
            });
        } catch (Throwable $e) {
            return ['ok'=>false,'error'=>'save_failed','message'=>$e->getMessage()];
        }
        dmd_planning_audit('event.created', $event, 'success', ['source'=>'actionhub'], [], $email);
        dmd_planning_emit_notification('event.created', $event, $config, 'Créé depuis ActionHub.', $email);
        return ['ok'=>true,'message'=>'Événement Planning créé.','data'=>['module'=>DMD_PLANNING_ID,'event_id'=>$event['id'],'resource'=>dmd_planning_event_resource($event),'reload'=>true],'event_emitted'=>true];
    }

    $event = dmd_planning_actionhub_event($resource);
    if (!$event) return ['ok'=>false,'error'=>'invalid_resource','message'=>'Événement Planning introuvable.'];
    $id = (string)$event['id'];

    if ($actionId === 'event.open') {
        return ['ok'=>true,'message'=>'Ouverture du rendez-vous.','data'=>['module'=>DMD_PLANNING_ID,'command'=>'open-event','event_id'=>$id],'event_emitted'=>true];
    }

    if ($actionId === 'event.edit') {
        if (!dmd_planning_can_edit($event)) return ['ok'=>false,'error'=>'permission_denied','message'=>'Modification non autorisée.'];
        return ['ok'=>true,'message'=>'Ouverture du rendez-vous en modification.','data'=>['module'=>DMD_PLANNING_ID,'command'=>'edit-event','event_id'=>$id],'event_emitted'=>true];
    }

    if ($actionId === 'event.delete') {
        if (!dmd_planning_can_delete($event)) return ['ok'=>false,'error'=>'permission_denied','message'=>'Suppression non autorisée.'];
        try {
            $deleted = dmd_planning_mutate_events(function (array &$events) use ($id): array {
                $index = dmd_planning_find_event_index($events, $id);
                if ($index < 0) throw new OutOfBoundsException('Événement introuvable.');
                $event = $events[$index];
                array_splice($events, $index, 1);
                return $event;
            });
        } catch (Throwable $e) {
            return ['ok'=>false,'error'=>'delete_failed','message'=>$e->getMessage()];
        }
        dmd_planning_audit('event.deleted', $deleted, 'success', ['source'=>'actionhub'], [], $email);
        return ['ok'=>true,'message'=>'Rendez-vous supprimé.','data'=>['module'=>DMD_PLANNING_ID,'event_id'=>$id,'reload'=>true],'event_emitted'=>true];
    }

    $statusMap = ['event.complete'=>'done','event.cancel'=>'cancelled','event.reopen'=>'planned'];
    if (isset($statusMap[$actionId])) {
        try {
            $updated = dmd_planning_set_status($id, $statusMap[$actionId], 'actionhub', $email);
        } catch (Throwable $e) {
            return ['ok'=>false,'error'=>'action_failed','message'=>$e->getMessage()];
        }
        return ['ok'=>true,'message'=>'Statut Planning mis à jour.','data'=>['module'=>DMD_PLANNING_ID,'event_id'=>$id,'status'=>$updated['status'],'reload'=>true],'event_emitted'=>true];
    }

    return ['ok'=>false,'error'=>'unknown_action','message'=>'Action Planning inconnue.'];
}
