<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-planning_lib.php';

if (!dmd_planning_has_permission('config.view')) {
    echo '<section class="dpl2-cfg dpl2-denied">Configuration DMD-Planning non autorisée.</section>';
    return;
}

$documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? '')) ?: '';
$moduleDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/DMD-Planning';
if ($documentRoot !== '' && str_starts_with(str_replace('\\', '/', $moduleDir), str_replace('\\', '/', $documentRoot))) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleDir, strlen($documentRoot))), '/');
}
$apiUrl = rtrim($moduleWebPath, '/') . '/dmd-planning_api.php';
$uid = 'dpl2cfg-' . bin2hex(random_bytes(5));
$cssVer = (int)@filemtime(__DIR__ . '/dmd-planning.css');
$jsVer = rawurlencode(DMD_PLANNING_VERSION) . '-' . (int)@filemtime(__DIR__ . '/dmd-planning-cfg.js');
?>
<link rel="stylesheet" href="<?= htmlspecialchars(rtrim($moduleWebPath, '/') . '/dmd-planning.css?v=' . $cssVer, ENT_QUOTES, 'UTF-8') ?>">
<section id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>" class="dpl2-cfg" data-dpl2-cfg data-api="<?= htmlspecialchars($apiUrl, ENT_QUOTES, 'UTF-8') ?>">
    <header class="dpl2-cfg-head">
        <div>
            <span class="dpl2-kicker">DMD-Planning <?= htmlspecialchars(DMD_PLANNING_VERSION, ENT_QUOTES, 'UTF-8') ?></span>
            <h3>Configuration du planning</h3>
            <p>Les métiers ne sont pas codés en dur : plannings, catégories, couleurs, champs, statuts, rappels et modèles sont construits ici.</p>
        </div>
        <div class="dpl2-cfg-head-actions">
            <span class="dpl2-save-state" data-cfg-state></span>
            <button type="button" class="dpl2-btn dpl2-btn-primary" data-cfg-save>Enregistrer</button>
        </div>
    </header>

    <nav class="dpl2-tabs" aria-label="Configuration DMD-Planning">
        <button type="button" class="is-active" data-cfg-tab-btn="general">Général</button>
        <button type="button" data-cfg-tab-btn="plannings">Plannings</button>
        <button type="button" data-cfg-tab-btn="categories">Catégories</button>
        <button type="button" data-cfg-tab-btn="statuses">Statuts</button>
        <button type="button" data-cfg-tab-btn="reminders">Rappels</button>
        <button type="button" data-cfg-tab-btn="templates">Modèles métier</button>
        <button type="button" data-cfg-tab-btn="logs">Journal</button>
        <button type="button" data-cfg-tab-btn="guide">Utilisation</button>
    </nav>

    <section class="dpl2-cfg-panel is-active" data-cfg-tab="general">
        <div class="dpl2-cfg-grid">
            <label><span>Vue par défaut</span><select data-cfg-default-view><option value="day">Jour</option><option value="week">Semaine</option><option value="month">Mois</option></select></label>
            <label><span>Fuseau horaire</span><input type="text" data-cfg-timezone value="Europe/Paris"></label>
            <label><span>Début de journée</span><input type="number" min="0" max="23" data-cfg-day-start></label>
            <label><span>Fin de journée</span><input type="number" min="1" max="24" data-cfg-day-end></label>
            <label><span>Pas horaire</span><select data-cfg-slot><option value="15">15 minutes</option><option value="30">30 minutes</option><option value="60">60 minutes</option></select></label>
            <label class="dpl2-check"><input type="checkbox" data-cfg-monday><span>Semaine à partir du lundi</span></label>
        </div>
        <div class="dpl2-info">Les couleurs appartiennent aux catégories. Les statuts restent indépendants des couleurs pour éviter de mélanger le type d’événement et son état.</div>
        <div class="dpl2-danger-zone">
            <div><strong>Vider uniquement la structure</strong><span>Supprime les plannings, catégories et modèles de la configuration. Les événements existants ne sont pas effacés.</span></div>
            <button type="button" class="dpl2-btn dpl2-btn-danger" data-cfg-reset>Vider la structure</button>
        </div>
    </section>

    <section class="dpl2-cfg-panel" data-cfg-tab="plannings">
        <div class="dpl2-panel-head"><div><h4>Plannings</h4><p>Un planning regroupe une ou plusieurs catégories.</p></div><button type="button" class="dpl2-btn" data-cfg-add-planning>+ Planning</button></div>
        <div class="dpl2-stack" data-cfg-plannings></div>
    </section>

    <section class="dpl2-cfg-panel" data-cfg-tab="categories">
        <div class="dpl2-panel-head"><div><h4>Catégories</h4><p>Une catégorie définit sa couleur et, seulement si nécessaire, une petite zone métier avec les choix utiles.</p></div><button type="button" class="dpl2-btn" data-cfg-add-category>+ Catégorie</button></div>
        <div class="dpl2-stack" data-cfg-categories></div>
    </section>

    <section class="dpl2-cfg-panel" data-cfg-tab="statuses">
        <div class="dpl2-panel-head"><div><h4>Statuts</h4><p>Les statuts sont globaux au module et totalement modifiables.</p></div><button type="button" class="dpl2-btn" data-cfg-add-status>+ Statut</button></div>
        <div class="dpl2-stack" data-cfg-statuses></div>
    </section>

    <section class="dpl2-cfg-panel" data-cfg-tab="reminders">
        <div class="dpl2-cfg-grid">
            <label class="dpl2-check"><input type="checkbox" data-cfg-reminders-enabled><span>Activer le moteur de rappels</span></label>
            <label><span>Heure des événements « journée »</span><input type="time" data-cfg-all-day-reminder-time></label>
        </div>
        <div class="dpl2-card-section">
            <div class="dpl2-panel-head"><div><h4>Rappels par défaut</h4><p>Utilisés lorsqu’une catégorie n’a pas ses propres rappels.</p></div><button type="button" class="dpl2-btn" data-cfg-add-default-reminder>+ Rappel</button></div>
            <div class="dpl2-reminder-list" data-cfg-default-reminders></div>
        </div>
        <div class="dpl2-card-section">
            <div class="dpl2-panel-head"><div><h4>Moteur de rappels</h4><p data-cfg-reminder-status>Chargement…</p></div><button type="button" class="dpl2-btn" data-cfg-run-reminders>Vérifier maintenant</button></div>
            <code class="dpl2-code">php <?= htmlspecialchars(__DIR__ . '/dmd-planning_reminders.php', ENT_QUOTES, 'UTF-8') ?></code>
            <p class="dpl2-muted">Pour les rappels sans utilisateur connecté, planifie cette commande côté serveur. Les e-mails et notifications passent par le moteur central DoMyDesk.</p>
        </div>
    </section>

    <section class="dpl2-cfg-panel" data-cfg-tab="templates">
        <div class="dpl2-panel-head"><div><h4>Modèles métier réutilisables</h4><p>Enregistre la structure d’un planning comme modèle, puis recrée-la autant de fois que nécessaire.</p></div></div>
        <div class="dpl2-template-create">
            <label><span>Nom du modèle</span><input type="text" data-template-name placeholder="Ex. Interventions atelier"></label>
            <label><span>Description</span><input type="text" data-template-description placeholder="Usage du modèle"></label>
            <label><span>Planning source</span><select data-template-source></select></label>
            <button type="button" class="dpl2-btn" data-template-create>Créer le modèle</button>
        </div>
        <div class="dpl2-stack" data-cfg-templates></div>
    </section>

    <section class="dpl2-cfg-panel" data-cfg-tab="logs">
        <div class="dpl2-panel-head"><div><h4>Journal DMD-Planning</h4><p>Créations, modifications, suppressions, changements de statut, rappels et activité transmise au Core DoMyDesk.</p></div><button type="button" class="dpl2-btn" data-cfg-refresh-logs>Actualiser</button></div>
        <div class="dpl2-log-list" data-cfg-logs><span class="dpl2-muted">Chargement…</span></div>
    </section>

    <section class="dpl2-cfg-panel" data-cfg-tab="guide">
        <div class="dpl2-guide-grid">
            <article><strong>1. Construire</strong><p>Crée un planning, puis ses catégories et champs. Rien n’est imposé par le module.</p></article>
            <article><strong>2. Utiliser</strong><p>Dans MyDesk, ouvre DMD-Planning puis utilise Jour, Semaine ou Mois. Un clic sur une case vide peut préparer un événement.</p></article>
            <article><strong>3. ActionHub</strong><p>Les événements sont publiés comme ressources Planning. Ils peuvent être terminés, annulés ou rouverts depuis ActionHub.</p></article>
            <article><strong>4. QuickSession</strong><p>L’activité du planning est transmise automatiquement au Core DoMyDesk et à QuickSession. Aucun bouton QuickSession n’est affiché dans la fiche d’un événement.</p></article>
        </div>
    </section>
</section>
<script src="<?= htmlspecialchars(rtrim($moduleWebPath, '/') . '/dmd-planning-cfg.js?v=' . $jsVer, ENT_QUOTES, 'UTF-8') ?>"></script>
