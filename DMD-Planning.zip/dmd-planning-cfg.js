(function () {
    'use strict';

    const KEY = 'DMDPlanningCfg120';
    const prior = window[KEY];
    if (prior && typeof prior.mountAll === 'function') { prior.mountAll(); return; }
    const apiObject = {};
    window[KEY] = apiObject;

    const esc = value => String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[ch]));
    const clone = value => JSON.parse(JSON.stringify(value));

    async function req(url, options = {}) {
        const response = await fetch(url, Object.assign({cache:'no-store', credentials:'same-origin'}, options));
        let data = null;
        try { data = await response.json(); } catch (_) { data = null; }
        if (!response.ok || !data || data.ok === false) throw new Error(data?.message || data?.error || `Erreur HTTP ${response.status}`);
        return data;
    }

    function slug(value, fallback = 'item') {
        let s = String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9_.-]+/g, '-').replace(/^[-_.]+|[-_.]+$/g, '');
        return s || fallback;
    }

    function uniqueId(base, rows) {
        const used = new Set((rows || []).map(row => row.id));
        let id = slug(base, 'item');
        let n = 2;
        while (used.has(id)) id = `${slug(base, 'item')}-${n++}`;
        return id;
    }

    function markDirty(state) {
        state.dirty = true;
        const el = state.root.querySelector('[data-cfg-state]');
        if (el) el.textContent = 'Modifications non enregistrées';
    }

    function setMessage(state, text, ok = true) {
        const el = state.root.querySelector('[data-cfg-state]');
        if (!el) return;
        el.textContent = text;
        el.style.opacity = ok ? '.8' : '1';
    }

    function canEdit(state) { return !!state.permissions['config.edit']; }

    function mountAll() {
        document.querySelectorAll('[data-dpl2-cfg]').forEach(root => {
            if (root.dataset.dpl2CfgMounted === '1') return;
            root.dataset.dpl2CfgMounted = '1';
            mount(root);
        });
    }
    apiObject.mountAll = mountAll;

    async function mount(root) {
        const state = {root, api:root.dataset.api || '', config:null, permissions:{}, csrf:'', reminderEngine:null, dirty:false};
        root._dpl2CfgState = state;
        bindTabs(state);
        try {
            const data = await req(`${state.api}?action=config_bootstrap`);
            state.config = clone(data.config || {});
            state.permissions = data.permissions || {};
            state.csrf = data.csrf || '';
            state.reminderEngine = data.reminder_engine || null;
            renderAll(state);
            bindStaticActions(state);
            setMessage(state, 'Configuration chargée');
        } catch (error) {
            setMessage(state, error.message, false);
        }
    }

    function bindTabs(state) {
        state.root.querySelectorAll('[data-cfg-tab-btn]').forEach(button => button.addEventListener('click', () => {
            const key = button.dataset.cfgTabBtn;
            state.root.querySelectorAll('[data-cfg-tab-btn]').forEach(b => b.classList.toggle('is-active', b === button));
            state.root.querySelectorAll('[data-cfg-tab]').forEach(panel => panel.classList.toggle('is-active', panel.dataset.cfgTab === key));
            if (key === 'logs' && state.config) loadLogs(state);
        }));
    }

    function bindStaticActions(state) {
        const root = state.root;
        root.querySelector('[data-cfg-save]').addEventListener('click', () => save(state));
        root.querySelector('[data-cfg-add-planning]').addEventListener('click', () => addPlanning(state));
        root.querySelector('[data-cfg-add-category]').addEventListener('click', () => addCategory(state));
        root.querySelector('[data-cfg-add-status]').addEventListener('click', () => addStatus(state));
        root.querySelector('[data-cfg-add-default-reminder]').addEventListener('click', () => {
            if (!canEdit(state)) return;
            state.config.default_reminders ||= [];
            state.config.default_reminders.push({offset_minutes:60,channel:'internal',enabled:true});
            markDirty(state); renderDefaultReminders(state);
        });
        root.querySelector('[data-cfg-run-reminders]').addEventListener('click', () => runReminders(state));
        root.querySelector('[data-template-create]').addEventListener('click', () => createTemplate(state));
        root.querySelector('[data-cfg-refresh-logs]').addEventListener('click', () => loadLogs(state));
        root.querySelector('[data-cfg-reset]').addEventListener('click', () => resetStructure(state));
    }

    function renderAll(state) {
        renderGeneral(state);
        renderPlannings(state);
        renderCategories(state);
        renderStatuses(state);
        renderDefaultReminders(state);
        renderReminderStatus(state);
        renderTemplateSource(state);
        renderTemplates(state);
        applyEditState(state);
    }

    function renderGeneral(state) {
        const root = state.root, c = state.config;
        root.querySelector('[data-cfg-default-view]').value = c.default_view || 'month';
        root.querySelector('[data-cfg-timezone]').value = c.timezone || 'Europe/Paris';
        root.querySelector('[data-cfg-day-start]').value = c.day_start ?? 7;
        root.querySelector('[data-cfg-day-end]').value = c.day_end ?? 21;
        root.querySelector('[data-cfg-slot]').value = String(c.slot_minutes ?? 30);
        root.querySelector('[data-cfg-monday]').checked = c.week_starts_monday !== false;
        root.querySelector('[data-cfg-reminders-enabled]').checked = c.reminders_enabled !== false;
        root.querySelector('[data-cfg-all-day-reminder-time]').value = c.all_day_reminder_time || '09:00';
        root.querySelectorAll('[data-cfg-default-view],[data-cfg-timezone],[data-cfg-day-start],[data-cfg-day-end],[data-cfg-slot],[data-cfg-monday],[data-cfg-reminders-enabled],[data-cfg-all-day-reminder-time]').forEach(el => {
            if (el.dataset.bound === '1') return;
            el.dataset.bound = '1';
            el.addEventListener('change', () => markDirty(state));
            if (el.tagName === 'INPUT') el.addEventListener('input', () => markDirty(state));
        });
    }

    function applyEditState(state) {
        const editable = canEdit(state);
        state.root.querySelectorAll('button,input,select,textarea').forEach(el => {
            if (el.closest('[data-cfg-tab="logs"]') && el.matches('[data-cfg-refresh-logs]')) return;
            if (el.closest('[data-cfg-tab-btn]')) return;
            if (!editable && !el.closest('[data-cfg-tab="logs"]')) el.disabled = true;
        });
    }

    function renderPlannings(state) {
        const zone = state.root.querySelector('[data-cfg-plannings]');
        const rows = state.config.plannings || [];
        zone.innerHTML = rows.map((p,i) => `<article class="dpl2-cfg-card" data-planning-index="${i}"><div class="dpl2-cfg-card-head"><div><strong>${esc(p.name || 'Planning')}</strong><div class="dpl2-id">${esc(p.id)}</div></div><button type="button" class="dpl2-btn dpl2-btn-danger" data-planning-delete>Supprimer</button></div><div class="dpl2-cfg-card-grid"><label><span>Nom</span><input data-planning-name value="${esc(p.name)}"></label><label><span>Identifiant</span><input data-planning-id value="${esc(p.id)}"></label><label class="dpl2-check"><input type="checkbox" data-planning-enabled ${p.enabled !== false ? 'checked' : ''}><span>Actif</span></label></div></article>`).join('');
        zone.querySelectorAll('[data-planning-index]').forEach(card => {
            const i = +card.dataset.planningIndex;
            card.querySelector('[data-planning-name]').addEventListener('input', e => { rows[i].name = e.target.value; markDirty(state); renderTemplateSource(state); });
            card.querySelector('[data-planning-id]').addEventListener('change', e => {
                const old = rows[i].id;
                const next = slug(e.target.value, old || `planning-${i+1}`);
                if ((rows || []).some((row,idx) => idx !== i && row.id === next)) { e.target.value = old; setMessage(state, 'Identifiant de planning déjà utilisé.', false); return; }
                rows[i].id = next; e.target.value = next;
                (state.config.categories || []).forEach(c => { if (c.planning_id === old) c.planning_id = next; });
                markDirty(state); renderCategories(state); renderTemplateSource(state);
            });
            card.querySelector('[data-planning-enabled]').addEventListener('change', e => { rows[i].enabled = e.target.checked; markDirty(state); });
            card.querySelector('[data-planning-delete]').addEventListener('click', () => {
                if ((state.config.categories || []).some(c => c.planning_id === rows[i].id)) { setMessage(state, 'Supprime ou déplace d’abord les catégories de ce planning.', false); return; }
                if (rows.length <= 1) { setMessage(state, 'Il faut conserver au moins un planning.', false); return; }
                if (!confirm(`Supprimer le planning « ${rows[i].name} » ?`)) return;
                rows.splice(i,1); markDirty(state); renderPlannings(state); renderCategories(state); renderTemplateSource(state); applyEditState(state);
            });
        });
    }

    function addPlanning(state) {
        if (!canEdit(state)) return;
        state.config.plannings ||= [];
        const id = uniqueId('planning', state.config.plannings);
        state.config.plannings.push({id,name:'Nouveau planning',enabled:true});
        markDirty(state); renderPlannings(state); renderCategories(state); renderTemplateSource(state); applyEditState(state);
    }

    function planningOptions(state, current) {
        return (state.config.plannings || []).map(p => `<option value="${esc(p.id)}" ${p.id === current ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    }

    function renderCategories(state) {
        const zone = state.root.querySelector('[data-cfg-categories]');
        const rows = state.config.categories || [];
        if (!rows.length) { zone.innerHTML = '<span class="dpl2-muted" style="font-size:10px">Aucune catégorie. Le module n’impose aucun métier.</span>'; return; }
        zone.innerHTML = rows.map((c,i) => `<article class="dpl2-cfg-card" data-category-index="${i}"><div class="dpl2-cfg-card-head"><div><strong>${esc(c.name || 'Catégorie')}</strong><div class="dpl2-id">${esc(c.id)}</div></div><button type="button" class="dpl2-btn dpl2-btn-danger" data-category-delete>Supprimer</button></div><div class="dpl2-cfg-card-grid"><label><span>Nom</span><input data-category-name value="${esc(c.name)}"></label><label><span>Identifiant</span><input data-category-id value="${esc(c.id)}"></label><label><span>Planning</span><select data-category-planning>${planningOptions(state,c.planning_id)}</select></label><label class="dpl2-color-input"><span>Couleur</span><input type="color" data-category-color value="${esc(c.color || '#808080')}"><input data-category-color-text value="${esc(c.color || '#808080')}"></label><label><span>Durée par défaut (min)</span><input type="number" min="15" max="1440" data-category-duration value="${esc(c.default_duration || 60)}"></label><label class="dpl2-check"><input type="checkbox" data-category-all-day ${c.all_day_default ? 'checked' : ''}><span>Journée par défaut</span></label></div><div class="dpl2-card-section"><div class="dpl2-panel-head"><div><h4>Rappels de cette catégorie</h4><p>Ils remplacent les rappels généraux pour les nouveaux événements.</p></div><button type="button" class="dpl2-btn" data-category-add-reminder>+ Rappel</button></div><div class="dpl2-reminder-list" data-category-reminders></div></div><div class="dpl2-card-section"><div class="dpl2-panel-head"><div><h4>Zone métier <span class="dpl2-muted">(facultative)</span></h4><p>Ajoute uniquement les informations utiles. Si tu renseignes des choix séparés par |, ils deviennent automatiquement une liste.</p></div><button type="button" class="dpl2-btn" data-category-add-field>+ Élément</button></div><div class="dpl2-field-list" data-category-fields></div></div></article>`).join('');
        zone.querySelectorAll('[data-category-index]').forEach(card => bindCategory(state, card, +card.dataset.categoryIndex));
    }

    function bindCategory(state, card, index) {
        const rows = state.config.categories || [];
        const c = rows[index];
        const name = card.querySelector('[data-category-name]');
        const id = card.querySelector('[data-category-id]');
        const plan = card.querySelector('[data-category-planning]');
        const color = card.querySelector('[data-category-color]');
        const colorText = card.querySelector('[data-category-color-text]');
        const duration = card.querySelector('[data-category-duration]');
        const allDay = card.querySelector('[data-category-all-day]');
        name.addEventListener('input', e => { c.name=e.target.value; markDirty(state); });
        id.addEventListener('change', e => {
            const old=c.id, next=slug(e.target.value,old||`category-${index+1}`);
            if (rows.some((row,idx)=>idx!==index&&row.id===next)) { e.target.value=old; setMessage(state,'Identifiant de catégorie déjà utilisé.',false); return; }
            c.id=next; e.target.value=next; markDirty(state);
        });
        plan.addEventListener('change', e => { c.planning_id=e.target.value; markDirty(state); });
        const syncColor = value => { if(/^#[0-9a-f]{6}$/i.test(value)){c.color=value.toLowerCase();color.value=c.color;colorText.value=c.color;markDirty(state);} };
        color.addEventListener('input', e => syncColor(e.target.value));
        colorText.addEventListener('change', e => syncColor(e.target.value));
        duration.addEventListener('input', e => { c.default_duration=Math.max(15,Math.min(1440,+e.target.value||60));markDirty(state); });
        allDay.addEventListener('change', e => { c.all_day_default=e.target.checked;markDirty(state); });
        card.querySelector('[data-category-delete]').addEventListener('click',()=>{if(!confirm(`Supprimer la catégorie « ${c.name} » ?`))return;rows.splice(index,1);markDirty(state);renderCategories(state);applyEditState(state);});
        card.querySelector('[data-category-add-field]').addEventListener('click',()=>{c.fields ||= [];c.fields.push({id:uniqueId('champ',c.fields),label:'Nouveau champ',type:'text',required:false,options:[]});markDirty(state);renderCategories(state);applyEditState(state);});
        card.querySelector('[data-category-add-reminder]').addEventListener('click',()=>{c.default_reminders ||= [];c.default_reminders.push({offset_minutes:60,channel:'internal',enabled:true});markDirty(state);renderCategories(state);applyEditState(state);});
        renderCategoryFields(state, card, c);
        renderReminderRows(state, card.querySelector('[data-category-reminders]'), c.default_reminders || [], () => { markDirty(state); renderCategories(state); applyEditState(state); });
    }

    function renderCategoryFields(state, card, c) {
        const zone = card.querySelector('[data-category-fields]');
        const fields = c.fields || [];
        if (!fields.length) { zone.innerHTML='<span class="dpl2-muted" style="font-size:9px">Aucun champ supplémentaire.</span>';return; }
        const typeLabels = {text:'Texte libre',textarea:'Texte long',number:'Nombre',date:'Date',time:'Heure',datetime:'Date + heure',checkbox:'Oui / Non',select:'Liste de choix',email:'E-mail',phone:'Téléphone'};
        zone.innerHTML = fields.map((f,i)=>`<div class="dpl2-field-row" data-field-index="${i}"><label><span>Libellé</span><input data-field-label value="${esc(f.label)}"></label><label><span>Format</span><select data-field-type>${Object.entries(typeLabels).map(([type,label])=>`<option value="${type}" ${f.type===type?'selected':''}>${label}</option>`).join('')}</select></label><label><span>Choix proposés (séparés par |)</span><input data-field-options value="${esc((f.options||[]).join(' | '))}" placeholder="Ex. AD | SQL | TSE | DATAS"></label><label class="dpl2-check"><input type="checkbox" data-field-required ${f.required?'checked':''}><span>Obligatoire</span></label><button type="button" class="dpl2-btn dpl2-btn-danger" data-field-delete>×</button><div class="dpl2-id">${esc(f.id)}</div></div>`).join('');
        zone.querySelectorAll('[data-field-index]').forEach(row=>{
            const i=+row.dataset.fieldIndex, f=fields[i];
            row.querySelector('[data-field-label]').addEventListener('input',e=>{f.label=e.target.value;markDirty(state);});
            row.querySelector('[data-field-type]').addEventListener('change',e=>{f.type=e.target.value;markDirty(state);renderCategoryFields(state,card,c);applyEditState(state);});
            row.querySelector('[data-field-options]').addEventListener('change',e=>{
                f.options=e.target.value.split('|').map(v=>v.trim()).filter(Boolean);
                if(f.options.length && ['text','textarea'].includes(f.type)) f.type='select';
                if(!f.options.length && f.type==='select') f.type='text';
                markDirty(state);renderCategoryFields(state,card,c);applyEditState(state);
            });
            row.querySelector('[data-field-required]').addEventListener('change',e=>{f.required=e.target.checked;markDirty(state);});
            row.querySelector('[data-field-delete]').addEventListener('click',()=>{fields.splice(i,1);markDirty(state);renderCategoryFields(state,card,c);applyEditState(state);});
        });
    }

    function addCategory(state) {
        if (!canEdit(state)) return;
        state.config.categories ||= [];
        const planning = state.config.plannings?.[0];
        if (!planning) { setMessage(state,'Crée d’abord un planning.',false);return; }
        state.config.categories.push({id:uniqueId('categorie',state.config.categories),planning_id:planning.id,name:'Nouvelle catégorie',color:'#808080',default_duration:60,all_day_default:false,default_reminders:[],fields:[]});
        markDirty(state);renderCategories(state);applyEditState(state);
    }

    function renderStatuses(state) {
        const zone=state.root.querySelector('[data-cfg-statuses]'),rows=state.config.statuses||[];
        zone.innerHTML=rows.map((s,i)=>`<article class="dpl2-cfg-card" data-status-index="${i}"><div class="dpl2-cfg-card-grid"><label><span>Libellé</span><input data-status-label value="${esc(s.label)}"></label><label><span>Identifiant</span><input data-status-id value="${esc(s.id)}"></label><label><span>Icône</span><input data-status-icon value="${esc(s.icon||'')}"></label></div><div class="dpl2-cfg-card-actions"><button type="button" class="dpl2-btn dpl2-btn-danger" data-status-delete>Supprimer</button></div></article>`).join('');
        zone.querySelectorAll('[data-status-index]').forEach(card=>{
            const i=+card.dataset.statusIndex,s=rows[i];
            card.querySelector('[data-status-label]').addEventListener('input',e=>{s.label=e.target.value;markDirty(state);});
            card.querySelector('[data-status-id]').addEventListener('change',e=>{const old=s.id,next=slug(e.target.value,old||`status-${i+1}`);if(rows.some((r,x)=>x!==i&&r.id===next)){e.target.value=old;setMessage(state,'Identifiant de statut déjà utilisé.',false);return;}s.id=next;e.target.value=next;markDirty(state);});
            card.querySelector('[data-status-icon]').addEventListener('input',e=>{s.icon=e.target.value;markDirty(state);});
            card.querySelector('[data-status-delete]').addEventListener('click',()=>{if(rows.length<=1){setMessage(state,'Il faut conserver au moins un statut.',false);return;}if(!confirm(`Supprimer le statut « ${s.label} » ?`))return;rows.splice(i,1);markDirty(state);renderStatuses(state);applyEditState(state);});
        });
    }

    function addStatus(state){if(!canEdit(state))return;state.config.statuses||=[];state.config.statuses.push({id:uniqueId('status',state.config.statuses),label:'Nouveau statut',icon:'•'});markDirty(state);renderStatuses(state);applyEditState(state);}

    function reminderParts(minutes){minutes=Math.max(0,+minutes||0);if(minutes>0&&minutes%1440===0)return{value:minutes/1440,unit:'days'};if(minutes>0&&minutes%60===0)return{value:minutes/60,unit:'hours'};return{value:minutes,unit:'minutes'};}
    function reminderMinutes(value,unit){const n=Math.max(0,+value||0);return unit==='days'?n*1440:unit==='hours'?n*60:n;}

    function renderReminderRows(state, zone, rows, rerender) {
        if (!rows.length) { zone.innerHTML='<span class="dpl2-muted" style="font-size:9px">Aucun rappel.</span>';return; }
        zone.innerHTML=rows.map((r,i)=>{const p=reminderParts(r.offset_minutes);return`<div class="dpl2-reminder-row" data-rem-index="${i}"><input type="number" min="0" max="525600" data-rem-value value="${esc(p.value)}"><select data-rem-unit><option value="minutes" ${p.unit==='minutes'?'selected':''}>minute(s) avant</option><option value="hours" ${p.unit==='hours'?'selected':''}>heure(s) avant</option><option value="days" ${p.unit==='days'?'selected':''}>jour(s) avant</option></select><select data-rem-channel><option value="internal" ${r.channel==='internal'?'selected':''}>Interne</option><option value="email" ${r.channel==='email'?'selected':''}>E-mail</option><option value="both" ${r.channel==='both'?'selected':''}>Interne + e-mail</option></select><button type="button" class="dpl2-btn" data-rem-delete>×</button></div>`;}).join('');
        zone.querySelectorAll('[data-rem-index]').forEach(row=>{
            const i=+row.dataset.remIndex;
            const sync=()=>{rows[i].offset_minutes=reminderMinutes(row.querySelector('[data-rem-value]').value,row.querySelector('[data-rem-unit]').value);rows[i].channel=row.querySelector('[data-rem-channel]').value;rows[i].enabled=true;markDirty(state);};
            row.querySelectorAll('input,select').forEach(el=>el.addEventListener('change',sync));
            row.querySelector('[data-rem-delete]').addEventListener('click',()=>{rows.splice(i,1);markDirty(state);rerender();});
        });
    }

    function renderDefaultReminders(state){renderReminderRows(state,state.root.querySelector('[data-cfg-default-reminders]'),state.config.default_reminders||[],()=>{renderDefaultReminders(state);applyEditState(state);});}

    function renderReminderStatus(state){const el=state.root.querySelector('[data-cfg-reminder-status]'),s=state.reminderEngine||{};el.textContent=s.last_run?`Dernière vérification : ${s.last_run}${s.last_sent?` · dernier envoi : ${s.last_sent}`:''}`:'Aucune vérification enregistrée.';}
    async function runReminders(state){if(!canEdit(state))return;try{const data=await post(state,'reminders_run',{});state.reminderEngine=data.status||null;renderReminderStatus(state);setMessage(state,`${data.result?.checked||0} rappel(s) vérifié(s), ${data.result?.sent||0} envoi(s).`);}catch(e){setMessage(state,e.message,false);}}

    function renderTemplateSource(state){const select=state.root.querySelector('[data-template-source]');if(!select)return;const current=select.value;select.innerHTML=(state.config.plannings||[]).map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('');if((state.config.plannings||[]).some(p=>p.id===current))select.value=current;}

    function snapshotPlanning(state, planningId){const p=(state.config.plannings||[]).find(x=>x.id===planningId);if(!p)return null;return{planning_name:p.name,categories:clone((state.config.categories||[]).filter(c=>c.planning_id===planningId).map(c=>({id:c.id,name:c.name,color:c.color,default_duration:c.default_duration,all_day_default:!!c.all_day_default,default_reminders:c.default_reminders||[],fields:c.fields||[]})))};}

    function createTemplate(state){if(!canEdit(state))return;const name=state.root.querySelector('[data-template-name]').value.trim(),desc=state.root.querySelector('[data-template-description]').value.trim(),source=state.root.querySelector('[data-template-source]').value;if(!name){setMessage(state,'Indique un nom de modèle.',false);return;}const snap=snapshotPlanning(state,source);if(!snap){setMessage(state,'Planning source introuvable.',false);return;}state.config.templates||=[];state.config.templates.push({id:uniqueId(name,state.config.templates),name,description:desc,planning_name:snap.planning_name,categories:snap.categories});state.root.querySelector('[data-template-name]').value='';state.root.querySelector('[data-template-description]').value='';markDirty(state);renderTemplates(state);applyEditState(state);}

    function renderTemplates(state){const zone=state.root.querySelector('[data-cfg-templates]'),rows=state.config.templates||[];if(!rows.length){zone.innerHTML='<span class="dpl2-muted" style="font-size:10px">Aucun modèle métier enregistré.</span>';return;}zone.innerHTML=rows.map((t,i)=>`<article class="dpl2-cfg-card" data-template-index="${i}"><div class="dpl2-cfg-card-head"><div><strong>${esc(t.name)}</strong><div class="dpl2-id">${esc(t.id)} · ${esc(t.planning_name)} · ${(t.categories||[]).length} catégorie(s)</div></div></div><div class="dpl2-cfg-card-grid"><label><span>Nom du modèle</span><input data-template-row-name value="${esc(t.name)}"></label><label class="dpl2-grow"><span>Description</span><input data-template-row-description value="${esc(t.description||'')}"></label></div><div class="dpl2-cfg-card-actions"><button type="button" class="dpl2-btn" data-template-apply>Appliquer</button><button type="button" class="dpl2-btn" data-template-update>Mettre à jour depuis un planning</button><select data-template-update-source>${(state.config.plannings||[]).map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select><button type="button" class="dpl2-btn dpl2-btn-danger" data-template-delete>Supprimer</button></div></article>`).join('');zone.querySelectorAll('[data-template-index]').forEach(card=>{const i=+card.dataset.templateIndex,t=rows[i];card.querySelector('[data-template-row-name]').addEventListener('input',e=>{t.name=e.target.value;markDirty(state);});card.querySelector('[data-template-row-description]').addEventListener('input',e=>{t.description=e.target.value;markDirty(state);});card.querySelector('[data-template-apply]').addEventListener('click',()=>applyTemplate(state,i));card.querySelector('[data-template-update]').addEventListener('click',()=>{const snap=snapshotPlanning(state,card.querySelector('[data-template-update-source]').value);if(!snap)return;t.planning_name=snap.planning_name;t.categories=snap.categories;markDirty(state);renderTemplates(state);applyEditState(state);});card.querySelector('[data-template-delete]').addEventListener('click',()=>{if(!confirm(`Supprimer le modèle « ${t.name} » ?`))return;rows.splice(i,1);markDirty(state);renderTemplates(state);applyEditState(state);});});}

    function applyTemplate(state,index){if(!canEdit(state))return;const t=state.config.templates?.[index];if(!t)return;const planningId=uniqueId(t.planning_name,state.config.plannings||[]);state.config.plannings.push({id:planningId,name:t.planning_name,enabled:true});state.config.categories||=[];(t.categories||[]).forEach(cat=>{const id=uniqueId(cat.name,state.config.categories);state.config.categories.push({id,planning_id:planningId,name:cat.name,color:cat.color||'#808080',default_duration:cat.default_duration||60,all_day_default:!!cat.all_day_default,default_reminders:clone(cat.default_reminders||[]),fields:clone(cat.fields||[]).map(f=>Object.assign({},f,{id:uniqueId(f.id||f.label,[])}))});});markDirty(state);renderPlannings(state);renderCategories(state);renderTemplateSource(state);applyEditState(state);setMessage(state,`Modèle « ${t.name} » appliqué. Enregistre pour valider.`);}

    function harvestGeneral(state){const r=state.root,c=state.config;c.default_view=r.querySelector('[data-cfg-default-view]').value;c.timezone=r.querySelector('[data-cfg-timezone]').value.trim();c.day_start=+r.querySelector('[data-cfg-day-start]').value||0;c.day_end=+r.querySelector('[data-cfg-day-end]').value||24;c.slot_minutes=+r.querySelector('[data-cfg-slot]').value||30;c.week_starts_monday=r.querySelector('[data-cfg-monday]').checked;c.reminders_enabled=r.querySelector('[data-cfg-reminders-enabled]').checked;c.all_day_reminder_time=r.querySelector('[data-cfg-all-day-reminder-time]').value||'09:00';}

    async function save(state){if(!canEdit(state))return;harvestGeneral(state);const button=state.root.querySelector('[data-cfg-save]');button.disabled=true;try{const data=await post(state,'config_save',{config:state.config});state.config=clone(data.config);state.dirty=false;renderAll(state);setMessage(state,'Configuration enregistrée');}catch(e){setMessage(state,e.message,false);}finally{button.disabled=false;applyEditState(state);}}
    async function post(state,action,payload){return req(`${state.api}?action=${encodeURIComponent(action)}`,{method:'POST',headers:{'Content-Type':'application/json','X-DMD-CSRF':state.csrf},body:JSON.stringify(payload||{})});}

    async function loadLogs(state){const zone=state.root.querySelector('[data-cfg-logs]');if(!state.permissions['logs.view']){zone.innerHTML='<span class="dpl2-muted">Droit logs.view requis.</span>';return;}zone.innerHTML='<span class="dpl2-muted">Chargement…</span>';try{const data=await req(`${state.api}?action=logs&limit=200`);const rows=data.logs||[];zone.innerHTML=rows.length?rows.map(row=>`<div class="dpl2-log-row"><span>${esc(row.datetime||'')}</span><strong>${esc(row.action||'')}</strong><span>${esc(row.user||'')}</span><span>${esc(row.resource?.label||row.target||'')}</span></div>`).join(''):'<span class="dpl2-muted">Aucune entrée.</span>';}catch(e){zone.innerHTML=`<span class="dpl2-muted">${esc(e.message)}</span>`;}}

    function resetStructure(state){if(!canEdit(state))return;if(!confirm('Vider les plannings, catégories et modèles de la configuration ? Les événements existants restent enregistrés.'))return;state.config.plannings=[{id:'general',name:'Planning général',enabled:true}];state.config.categories=[];state.config.templates=[];markDirty(state);renderPlannings(state);renderCategories(state);renderTemplateSource(state);renderTemplates(state);applyEditState(state);}

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountAll, {once:true}); else mountAll();
})();
