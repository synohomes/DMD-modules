(function () {
    'use strict';

    const GLOBAL_KEY = 'DMDPlanningRuntimeCategories';
    const existing = window[GLOBAL_KEY];
    if (existing && typeof existing.mountAll === 'function') {
        existing.mountAll();
        return;
    }

    /* Nettoyage d'un ancien runtime DMD-Planning encore présent dans la page.
       Sans cela, une mise à jour du module pouvait continuer à exécuter l'ancien JS. */
    document.querySelectorAll('[data-dpl2-root]').forEach(root => {
        const oldState = root._dpl2State;
        try {
            if (oldState?.reminderTimer) clearInterval(oldState.reminderTimer);
            if (oldState?.windows instanceof Map) {
                oldState.windows.forEach(win => { try { win?.remove(); } catch (_) {} });
            }
        } catch (_) {}
        try { delete root._dpl2State; } catch (_) { root._dpl2State = null; }
        root.dataset.dpl2Mounted = '0';

        /* Retire l'ancien listener du bouton Ouvrir en remplaçant uniquement le bouton. */
        const oldOpen = root.querySelector('[data-dpl2-open]');
        if (oldOpen?.parentNode) oldOpen.replaceWith(oldOpen.cloneNode(true));
    });
    ['DMDPlanning120', 'DMDPlanning121', 'DMDPlanning122'].forEach(key => {
        try { delete window[key]; } catch (_) { window[key] = undefined; }
    });

    /* Retire aussi d'éventuelles fenêtres Planning laissées par l'ancien runtime. */
    document.querySelectorAll('.dpl2-window, .dpl2-popup').forEach(win => {
        if (win.closest('[data-dpl2-root]')) return;
        try { win.remove(); } catch (_) {}
    });

    const apiObject = {};
    window[GLOBAL_KEY] = apiObject;
    let fallbackZ = 12000;

    const esc = (value) => String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[ch]));
    const clone = (value) => JSON.parse(JSON.stringify(value));
    const pad2 = (n) => String(n).padStart(2, '0');
    const dateKey = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    const parseDate = (value) => {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value || ''));
        return m ? new Date(+m[1], +m[2] - 1, +m[3], 12, 0, 0, 0) : new Date();
    };
    const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
    const startMonth = (d) => new Date(d.getFullYear(), d.getMonth(), 1, 12);
    const minutes = (time) => { const m = /^(\d{2}):(\d{2})$/.exec(String(time || '')); return m ? (+m[1] * 60 + +m[2]) : 0; };
    const timeString = (mins) => `${pad2(Math.floor(mins / 60) % 24)}:${pad2(mins % 60)}`;
    const todayKey = () => dateKey(new Date());
    const isMobile = () => !!(window.DMDWorkspace && typeof window.DMDWorkspace.isMobileView === 'function' && window.DMDWorkspace.isMobileView()) || window.innerWidth <= 900;

    async function request(url, options = {}) {
        const response = await fetch(url, Object.assign({cache: 'no-store', credentials: 'same-origin'}, options));
        let data = null;
        try { data = await response.json(); } catch (_) { data = null; }
        if (!response.ok || !data || data.ok === false) {
            const error = new Error(data?.message || data?.error || `Erreur HTTP ${response.status}`);
            error.status = response.status;
            error.data = data;
            throw error;
        }
        return data;
    }

    function category(state, id) {
        return (state.config?.categories || []).find(row => row.id === id) || null;
    }
    function planning(state, id) {
        return (state.config?.plannings || []).find(row => row.id === id) || null;
    }
    function statusRow(state, id) {
        return (state.config?.statuses || []).find(row => row.id === id) || null;
    }
    function eventCanEdit(state, event) {
        return !!state.permissions['event.edit.all'] || (!!state.permissions['event.edit'] && event.owner === state.user);
    }
    function eventCanDelete(state, event) {
        return !!state.permissions['event.delete.all'] || (!!state.permissions['event.delete'] && event.owner === state.user);
    }

    function weekStart(state, date) {
        const d = new Date(date);
        const day = d.getDay();
        const delta = state.config?.week_starts_monday !== false ? (day === 0 ? -6 : 1 - day) : -day;
        return addDays(d, delta);
    }

    function mountAll() {
        document.querySelectorAll('[data-dpl2-root]').forEach(root => {
            if (root.dataset.dpl2Mounted === '1') return;
            root.dataset.dpl2Mounted = '1';
            mountRoot(root);
        });
    }
    apiObject.mountAll = mountAll;

    function mountRoot(root) {
        const state = {
            root,
            api: root.dataset.api || '',
            actionHubApi: root.dataset.actionhubApi || '',
            icon: root.dataset.icon || '',
            config: null,
            permissions: {},
            csrf: '',
            user: '',
            events: [],
            tileEvents: [],
            actionResources: null,
            hiddenCategories: new Set(),
            query: '',
            view: 'month',
            cursor: new Date(),
            windows: new Map(),
            reminderTimer: null,
        };
        root._dpl2State = state;
        root.querySelector('[data-dpl2-open]')?.addEventListener('click', () => openCalendar(state));
        bootstrap(state).catch(error => {
            const body = root.querySelector('[data-dpl2-tile-body]');
            if (body) body.innerHTML = `<span class="dpl2-tile-empty">${esc(error.message)}</span>`;
        });
    }

    async function bootstrap(state) {
        const data = await request(`${state.api}?action=bootstrap`);
        state.config = data.config || {};
        state.permissions = data.permissions || {};
        state.csrf = data.csrf || '';
        state.user = data.user || '';
        state.view = ['day', 'week', 'month'].includes(state.config.default_view) ? state.config.default_view : 'month';
        const today = new Date();
        const tile = await request(`${state.api}?action=events_list&from=${dateKey(today)}&to=${dateKey(addDays(today, 45))}`);
        state.tileEvents = tile.events || [];
        renderTile(state);
        if (state.reminderTimer) clearInterval(state.reminderTimer);
        state.reminderTimer = setInterval(() => {
            if (!state.root.isConnected) {
                clearInterval(state.reminderTimer);
                state.reminderTimer = null;
                return;
            }
            request(`${state.api}?action=reminders_tick`).catch(() => {});
        }, 60000);
    }

    function renderTile(state) {
        const body = state.root.querySelector('[data-dpl2-tile-body]');
        if (!body) return;
        const now = todayKey();
        const upcoming = (state.tileEvents || [])
            .filter(e => e.date >= now && !['cancelled', 'done'].includes(e.status))
            .sort((a, b) => `${a.date} ${a.all_day ? '00:00' : a.start_time}`.localeCompare(`${b.date} ${b.all_day ? '00:00' : b.start_time}`));
        if (!upcoming.length) {
            body.innerHTML = `<span class="dpl2-tile-empty">${(state.config?.categories || []).length ? 'Aucun événement à venir.' : 'Aucune catégorie configurée.'}</span>`;
            return;
        }
        body.innerHTML = upcoming.map(e => {
            const c = category(state, e.category_id);
            const when = e.date === now ? (e.all_day ? 'Aujourd’hui' : e.start_time) : `${e.date.slice(8,10)}/${e.date.slice(5,7)}`;
            return `<button type="button" class="dpl2-tile-row" data-dpl2-tile-event="${esc(e.id)}"><i class="dpl2-tile-dot" style="background:${esc(c?.color || '#808080')}"></i><strong>${esc(e.title)}</strong><time>${esc(when)}</time></button>`;
        }).join('');
        body.querySelectorAll('[data-dpl2-tile-event]').forEach(button => button.addEventListener('click', () => {
            const id = button.dataset.dpl2TileEvent;
            if (id) openEventById(state, id);
        }));
    }

    function initialGeometry(width, height, stagger = 0) {
        const dash = document.getElementById('dashboard');
        const viewportW = window.innerWidth || document.documentElement.clientWidth || 1280;
        const viewportH = window.innerHeight || document.documentElement.clientHeight || 800;
        const w = Math.min(width, Math.max(360, viewportW - 40));
        const h = Math.min(height, Math.max(260, viewportH - 50));
        const scrollX = dash ? (dash.scrollLeft || window.scrollX || 0) : (window.scrollX || 0);
        const scrollY = dash ? (dash.scrollTop || window.scrollY || 0) : (window.scrollY || 0);
        return {
            left: Math.max(8, scrollX + Math.floor((viewportW - w) / 2) + stagger),
            top: Math.max(8, scrollY + Math.floor((viewportH - h) / 2) + stagger),
            width: w,
            height: h,
        };
    }

    function requestWorkspaceExpansion() {
        if (typeof window.DMDExpandDashboardCanvas === 'function') {
            requestAnimationFrame(() => window.DMDExpandDashboardCanvas());
        } else if (typeof window.expandCanvasLT === 'function') {
            requestAnimationFrame(() => window.expandCanvasLT());
        }
    }

    function elementZIndex(el) {
        if (!el) return 0;
        const inline = parseInt(el.style.zIndex || '0', 10);
        if (Number.isFinite(inline) && inline > 0) return inline;
        try {
            const computed = parseInt(window.getComputedStyle(el).zIndex || '0', 10);
            return Number.isFinite(computed) ? computed : 0;
        } catch (_) {
            return 0;
        }
    }

    function planningMaxZ(except = null) {
        let max = fallbackZ;
        document.querySelectorAll('#dashboard > .module, #dashboard .dmd-managed-window, #dashboard .dpl2-window, #dashboard .dpl2-popup, #dashboard .dmd-qs-window, body > .dpl2-window, body > .dpl2-popup').forEach(node => {
            if (node === except) return;
            max = Math.max(max, elementZIndex(node));
        });
        return max;
    }

    function fallbackBringToFront(el) {
        fallbackZ = Math.max(fallbackZ, planningMaxZ(el)) + 1;
        el.style.zIndex = String(fallbackZ);
    }

    function bringToFront(el) {
        if (!el || !el.isConnected) return;

        /* Le Core peut gérer le déplacement/redimensionnement, mais DMD-Planning
           garde sa propre pile visuelle. On force donc TOUJOURS la fenêtre
           cliquée au-dessus de tout le workspace après l'appel Core. */
        if (el.dataset.dmdWindowManaged === '1') {
            try {
                const Ev = window.PointerEvent || window.MouseEvent;
                el.dispatchEvent(new Ev('pointerdown', {bubbles: true, cancelable: true}));
            } catch (_) {}
        }
        fallbackBringToFront(el);
    }

    function fallbackMovable(el, handleSelector) {
        const handle = el.querySelector(handleSelector);
        const resize = el.querySelector('.dpl2-resize');
        if (!handle) return;
        let drag = null;
        handle.addEventListener('pointerdown', event => {
            if (isMobile() || event.target.closest('button,input,select,textarea,a')) return;
            const rect = el.getBoundingClientRect();
            drag = {id: event.pointerId, x: event.clientX, y: event.clientY, left: rect.left + window.scrollX, top: rect.top + window.scrollY};
            try { handle.setPointerCapture(event.pointerId); } catch (_) {}
            bringToFront(el);
        });
        handle.addEventListener('pointermove', event => {
            if (!drag || drag.id !== event.pointerId) return;
            el.style.left = Math.max(0, drag.left + event.clientX - drag.x) + 'px';
            el.style.top = Math.max(0, drag.top + event.clientY - drag.y) + 'px';
            requestWorkspaceExpansion();
        });
        const stopDrag = event => {
            if (!drag || (event.pointerId != null && event.pointerId !== drag.id)) return;
            try { handle.releasePointerCapture(drag.id); } catch (_) {}
            drag = null;
        };
        handle.addEventListener('pointerup', stopDrag);
        handle.addEventListener('pointercancel', stopDrag);

        if (resize) {
            let sizing = null;
            resize.addEventListener('pointerdown', event => {
                if (isMobile()) return;
                sizing = {id: event.pointerId, x: event.clientX, y: event.clientY, width: el.offsetWidth, height: el.offsetHeight};
                try { resize.setPointerCapture(event.pointerId); } catch (_) {}
                event.preventDefault();
                bringToFront(el);
            });
            resize.addEventListener('pointermove', event => {
                if (!sizing || sizing.id !== event.pointerId) return;
                const minW = el.classList.contains('dpl2-window') ? 680 : 360;
                const minH = el.classList.contains('dpl2-window') ? 470 : 260;
                el.style.width = Math.max(minW, sizing.width + event.clientX - sizing.x) + 'px';
                el.style.height = Math.max(minH, sizing.height + event.clientY - sizing.y) + 'px';
                requestWorkspaceExpansion();
            });
            const stopSize = event => {
                if (!sizing || (event.pointerId != null && event.pointerId !== sizing.id)) return;
                try { resize.releasePointerCapture(sizing.id); } catch (_) {}
                sizing = null;
            };
            resize.addEventListener('pointerup', stopSize);
            resize.addEventListener('pointercancel', stopSize);
        }
        el.addEventListener('pointerdown', () => bringToFront(el), true);
    }

    function mountWindow(state, key, element, handleSelector, geometry) {
        const mobile = isMobile();
        const dashboard = document.getElementById('dashboard');
        const host = mobile ? document.body : (dashboard || document.body);
        Object.assign(element.style, {
            left: geometry.left + 'px',
            top: geometry.top + 'px',
            width: geometry.width + 'px',
            height: geometry.height + 'px',
        });
        element.dataset.dpl2WindowKey = key;
        host.appendChild(element);
        state.windows.set(key, element);

        let managed = false;
        if (!mobile && window.DMDWorkspace && typeof window.DMDWorkspace.registerPopup === 'function') {
            try {
                window.DMDWorkspace.registerPopup(element, {key: `DMD-Planning:${key}`, handle: handleSelector});
                managed = element.dataset.dmdWindowManaged === '1';
            } catch (_) {
                managed = false;
            }
        }
        if (!managed) fallbackMovable(element, handleSelector);
        /* Même une fenêtre gérée par DMDWorkspace doit reprendre le dessus
           lorsqu'on clique dedans. */
        if (element.dataset.dpl2FrontBound !== '1') {
            element.dataset.dpl2FrontBound = '1';
            element.addEventListener('pointerdown', () => fallbackBringToFront(element), true);
        }
        bringToFront(element);
        requestAnimationFrame(() => bringToFront(element));
        requestWorkspaceExpansion();
        return element;
    }

    function closeWindow(state, key) {
        const element = state.windows.get(key);
        if (!element) return;
        state.windows.delete(key);
        try {
            if (typeof window.interact === 'function' && element.dataset.dmdWindowManaged === '1') window.interact(element).unset();
        } catch (_) {}
        element.remove();
        requestWorkspaceExpansion();
    }

    function detailWindowKey(eventOrId) {
        const id = typeof eventOrId === 'object' && eventOrId ? eventOrId.id : eventOrId;
        return `detail:${String(id || '').trim()}`;
    }

    function detailWindowEntries(state) {
        return [...state.windows.entries()].filter(([key, element]) => key.startsWith('detail:') && element?.isConnected);
    }

    function closeAllDetails(state) {
        detailWindowEntries(state).forEach(([key]) => closeWindow(state, key));
    }

    function topPlanningWindow(state, prefix = '') {
        let top = null;
        let topZ = -Infinity;
        state.windows.forEach((element, key) => {
            if (!element?.isConnected || (prefix && !key.startsWith(prefix))) return;
            const z = elementZIndex(element);
            if (z >= topZ) { top = [key, element]; topZ = z; }
        });
        return top;
    }

    function closeCalendar(state) {
        closeWindow(state, 'editor');
        closeWindow(state, 'daylist');
        closeAllDetails(state);
        closeWindow(state, 'calendar');
    }

    async function openCalendar(state) {
        const current = state.windows.get('calendar');
        if (current?.isConnected) {
            bringToFront(current);
            return current;
        }
        const geom = initialGeometry(1280, 820, 0);
        const win = document.createElement('section');
        win.className = 'dpl2-window dpl2-calendar-window';
        win.innerHTML = `
            <header class="dpl2-window-head">
                <div class="dpl2-window-title"><img src="${esc(state.icon)}" alt=""><strong>DMD-Planning</strong><small>planning métier configurable</small></div>
                <div class="dpl2-window-actions"><button type="button" class="dpl2-btn dpl2-btn-primary" data-dpl2-new>+ Événement</button><button type="button" class="dpl2-btn dpl2-close" data-dpl2-close aria-label="Fermer">×</button></div>
            </header>
            <div class="dpl2-toolbar">
                <div class="dpl2-toolbar-group"><button type="button" class="dpl2-btn" data-dpl2-prev>‹</button><button type="button" class="dpl2-btn" data-dpl2-today>Aujourd’hui</button><button type="button" class="dpl2-btn" data-dpl2-next>›</button><span class="dpl2-period" data-dpl2-period></span></div>
                <div class="dpl2-toolbar-group"><input class="dpl2-search" data-dpl2-search placeholder="Rechercher titre, note, ressource…"><button type="button" class="dpl2-btn dpl2-view" data-dpl2-view="day">Jour</button><button type="button" class="dpl2-btn dpl2-view" data-dpl2-view="week">Semaine</button><button type="button" class="dpl2-btn dpl2-view" data-dpl2-view="month">Mois</button></div>
            </div>
            <div class="dpl2-legend" data-dpl2-legend></div>
            <div class="dpl2-calendar-wrap" data-dpl2-calendar><div class="dpl2-loading">Chargement…</div></div>
            <div class="dpl2-resize" aria-hidden="true"></div>`;
        mountWindow(state, 'calendar', win, '.dpl2-window-head', geom);
        win.querySelector('[data-dpl2-close]').addEventListener('click', () => closeCalendar(state));
        win.querySelector('[data-dpl2-new]').disabled = !state.permissions['event.create'];
        win.querySelector('[data-dpl2-new]').addEventListener('click', () => openEditor(state, null, {date: dateKey(state.cursor), start_time: '09:00'}));
        win.querySelector('[data-dpl2-prev]').addEventListener('click', () => navigate(state, -1));
        win.querySelector('[data-dpl2-next]').addEventListener('click', () => navigate(state, 1));
        win.querySelector('[data-dpl2-today]').addEventListener('click', () => { state.cursor = new Date(); refreshCalendar(state); });
        win.querySelector('[data-dpl2-search]').addEventListener('input', event => { state.query = event.target.value.trim().toLowerCase(); renderCalendar(state); });
        win.querySelectorAll('[data-dpl2-view]').forEach(button => button.addEventListener('click', () => {
            state.view = button.dataset.dpl2View;
            refreshCalendar(state);
        }));
        await refreshCalendar(state);
        return win;
    }

    function navigate(state, direction) {
        if (state.view === 'day') state.cursor = addDays(state.cursor, direction);
        else if (state.view === 'week') state.cursor = addDays(state.cursor, direction * 7);
        else state.cursor = new Date(state.cursor.getFullYear(), state.cursor.getMonth() + direction, 1, 12);
        refreshCalendar(state);
    }

    function rangeFor(state) {
        if (state.view === 'day') return [new Date(state.cursor), new Date(state.cursor)];
        if (state.view === 'week') {
            const start = weekStart(state, state.cursor);
            return [start, addDays(start, 6)];
        }
        const start = weekStart(state, startMonth(state.cursor));
        return [start, addDays(start, 41)];
    }

    async function refreshCalendar(state) {
        const win = state.windows.get('calendar');
        if (!win?.isConnected) return;
        const [from, to] = rangeFor(state);
        win.querySelector('[data-dpl2-calendar]').innerHTML = '<div class="dpl2-loading">Chargement…</div>';
        try {
            const data = await request(`${state.api}?action=events_list&from=${dateKey(from)}&to=${dateKey(to)}`);
            state.events = data.events || [];
            renderCalendar(state);
        } catch (error) {
            win.querySelector('[data-dpl2-calendar]').innerHTML = `<div class="dpl2-calendar-empty">${esc(error.message)}</div>`;
        }
    }

    function filteredEvents(state) {
        return (state.events || []).filter(event => {
            if (state.hiddenCategories.has(event.category_id)) return false;
            if (!state.query) return true;
            const resourceText = (event.resources || []).map(r => `${r.label || ''} ${r.name || ''} ${r.source || ''}`).join(' ');
            const fieldText = Object.values(event.fields || {}).join(' ');
            return `${event.title || ''} ${event.notes || ''} ${resourceText} ${fieldText}`.toLowerCase().includes(state.query);
        });
    }

    function periodLabel(state) {
        const months = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
        if (state.view === 'day') return `${pad2(state.cursor.getDate())} ${months[state.cursor.getMonth()]} ${state.cursor.getFullYear()}`;
        if (state.view === 'week') {
            const start = weekStart(state, state.cursor);
            const end = addDays(start, 6);
            return `${pad2(start.getDate())}/${pad2(start.getMonth() + 1)} → ${pad2(end.getDate())}/${pad2(end.getMonth() + 1)} ${end.getFullYear()}`;
        }
        return `${months[state.cursor.getMonth()]} ${state.cursor.getFullYear()}`;
    }

    function renderLegend(state) {
        const win = state.windows.get('calendar');
        const zone = win?.querySelector('[data-dpl2-legend]');
        if (!zone) return;
        const categories = state.config?.categories || [];
        if (!categories.length) {
            zone.innerHTML = '<span class="dpl2-muted" style="font-size:9px">Aucune catégorie configurée.</span>';
            return;
        }
        zone.innerHTML = categories.map(c => `<button type="button" class="dpl2-legend-btn ${state.hiddenCategories.has(c.id) ? 'is-hidden' : ''}" data-dpl2-category="${esc(c.id)}"><i class="dpl2-color-dot" style="background:${esc(c.color)}"></i>${esc(c.name)}</button>`).join('');
        zone.querySelectorAll('[data-dpl2-category]').forEach(button => button.addEventListener('click', () => {
            const id = button.dataset.dpl2Category;
            if (state.hiddenCategories.has(id)) state.hiddenCategories.delete(id); else state.hiddenCategories.add(id);
            renderLegend(state);
            renderCalendar(state);
        }));
    }

    function eventHtml(state, event) {
        const c = category(state, event.category_id);
        const st = statusRow(state, event.status);
        const time = event.all_day ? 'Journée' : `${event.start_time}–${event.end_time}`;
        const classes = ['dpl2-event'];
        if (event.status === 'cancelled') classes.push('is-cancelled');
        if (event.status === 'done') classes.push('is-done');
        return `<button type="button" class="${classes.join(' ')}" style="--event-color:${esc(c?.color || '#808080')}" data-dpl2-event="${esc(event.id)}" title="${esc(event.title)}"><span class="dpl2-event-line"><span class="dpl2-event-time">${esc(time)}</span><span class="dpl2-event-title">${esc(event.title)}</span><span class="dpl2-event-status">${esc(st?.icon || '')}</span></span></button>`;
    }

    function sortDayEvents(events) {
        return [...(events || [])].sort((a, b) => {
            const aKey = `${a.all_day ? '00:00' : (a.start_time || '00:00')} ${a.title || ''}`;
            const bKey = `${b.all_day ? '00:00' : (b.start_time || '00:00')} ${b.title || ''}`;
            return aKey.localeCompare(bKey);
        });
    }

    function monthDayContent(state, date, dayEvents) {
        const sorted = sortDayEvents(dayEvents);
        if (sorted.length <= 2) {
            return sorted.map(event => eventHtml(state, event)).join('');
        }
        const grouped = new Map();
        sorted.forEach(event => {
            const key = event.category_id || '__uncategorized__';
            if (!grouped.has(key)) grouped.set(key, []);
            grouped.get(key).push(event);
        });
        const rows = [...grouped.entries()].sort((a, b) => {
            if (b[1].length !== a[1].length) return b[1].length - a[1].length;
            const aCat = category(state, a[0]);
            const bCat = category(state, b[0]);
            return `${aCat?.name || ''}`.localeCompare(`${bCat?.name || ''}`);
        });
        return `<div class="dpl2-day-summary-grid">${rows.map(([categoryId, items]) => {
            const cat = category(state, categoryId);
            const label = cat?.name || 'Autre';
            const color = cat?.color || '#808080';
            const count = items.length;
            return `<button type="button" class="dpl2-day-summary" style="--dpl2-summary-color:${esc(color)}" data-dpl2-day-summary="1" data-dpl2-date="${esc(date)}" data-dpl2-category="${esc(categoryId)}" title="${count} RDV · ${esc(label)}" aria-label="${count} RDV · ${esc(label)}"><strong class="dpl2-day-summary-count">${count}</strong></button>`;
        }).join('')}</div>`;
    }

    function eventsForDay(state, date, categoryId = '') {
        const list = filteredEvents(state).filter(event => {
            if (event.date !== date) return false;
            if (!categoryId) return true;
            if (categoryId === '__uncategorized__') return !event.category_id;
            return event.category_id === categoryId;
        });
        return sortDayEvents(list);
    }

    function dayListTitle(date, categoryLabel) {
        if (!date) return categoryLabel ? `RDV · ${categoryLabel}` : 'Rendez-vous';
        const parts = `${date}`.split('-');
        const label = parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : date;
        return categoryLabel ? `${label} · ${categoryLabel}` : `RDV du ${label}`;
    }

    function openDayList(state, date, categoryId = '') {
        const items = eventsForDay(state, date, categoryId);
        if (!items.length) return;
        closeWindow(state, 'daylist');
        const cat = categoryId ? category(state, categoryId) : null;
        const geom = initialGeometry(360, 420, -60);
        const popup = document.createElement('section');
        popup.className = 'dpl2-popup dpl2-day-list-popup';
        popup.innerHTML = `
            <header class="dpl2-popup-head"><div class="dpl2-popup-title"><strong>${esc(dayListTitle(date, cat?.name || ''))}</strong></div><div class="dpl2-popup-actions"><button type="button" class="dpl2-btn dpl2-close" data-dpl2-daylist-close aria-label="Fermer">×</button></div></header>
            <div class="dpl2-popup-body">
                <div class="dpl2-day-list">${items.map(event => {
                    const itemCat = category(state, event.category_id);
                    const itemStatus = statusRow(state, event.status);
                    const when = event.all_day ? 'Journée' : `${event.start_time} → ${event.end_time}`;
                    return `<button type="button" class="dpl2-day-list-item" data-dpl2-daylist-event="${esc(event.id)}"><i class="dpl2-color-dot" style="background:${esc(itemCat?.color || '#808080')}"></i><div class="dpl2-day-list-text"><strong>${esc(event.title || '(sans titre)')}</strong><small>${esc(when)}${itemStatus?.label ? ` · ${esc(itemStatus.label)}` : ''}</small></div></button>`;
                }).join('')}</div>
            </div>
            <footer class="dpl2-popup-footer"><button type="button" class="dpl2-btn" data-dpl2-daylist-close>Fermer</button></footer>
            <div class="dpl2-resize" aria-hidden="true"></div>`;
        mountWindow(state, 'daylist', popup, '.dpl2-popup-head', geom);
        popup.querySelectorAll('[data-dpl2-daylist-close]').forEach(button => button.addEventListener('click', () => closeWindow(state, 'daylist')));
        popup.querySelectorAll('[data-dpl2-daylist-event]').forEach(button => button.addEventListener('click', () => {
            const eventId = button.dataset.dpl2DaylistEvent;
            const found = items.find(entry => `${entry.id}` === `${eventId}`);
            closeWindow(state, 'daylist');
            if (found) openDetail(state, found); else openEventById(state, eventId);
        }));
    }

    function renderCalendar(state) {
        const win = state.windows.get('calendar');
        if (!win?.isConnected) return;
        win.querySelector('[data-dpl2-period]').textContent = periodLabel(state);
        win.querySelectorAll('[data-dpl2-view]').forEach(button => button.classList.toggle('is-active', button.dataset.dpl2View === state.view));
        renderLegend(state);
        if (state.view === 'month') renderMonth(state); else renderTime(state);
    }

    function renderMonth(state) {
        const win = state.windows.get('calendar');
        const zone = win.querySelector('[data-dpl2-calendar]');
        const events = filteredEvents(state);
        const byDay = new Map();
        events.forEach(event => {
            if (!byDay.has(event.date)) byDay.set(event.date, []);
            byDay.get(event.date).push(event);
        });
        const start = rangeFor(state)[0];
        const weekdays = state.config?.week_starts_monday !== false ? ['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'] : ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'];
        let html = `<div class="dpl2-month">${weekdays.map(day => `<div class="dpl2-month-weekday">${day}</div>`).join('')}`;
        for (let i = 0; i < 42; i++) {
            const d = addDays(start, i);
            const key = dateKey(d);
            const dayEvents = sortDayEvents(byDay.get(key) || []);
            const classes = ['dpl2-month-day'];
            if (d.getMonth() !== state.cursor.getMonth()) classes.push('is-outside');
            if (key === todayKey()) classes.push('is-today');
            html += `<div class="${classes.join(' ')}" data-dpl2-date="${key}"><span class="dpl2-day-number">${d.getDate()}</span><div class="dpl2-day-events">${monthDayContent(state, key, dayEvents)}</div></div>`;
        }
        html += '</div>';
        zone.innerHTML = html;
        bindCalendarClicks(state, zone);
    }

    function renderTime(state) {
        const win = state.windows.get('calendar');
        const zone = win.querySelector('[data-dpl2-calendar]');
        const days = state.view === 'day' ? [new Date(state.cursor)] : Array.from({length: 7}, (_, i) => addDays(weekStart(state, state.cursor), i));
        const dayKeys = days.map(dateKey);
        const events = filteredEvents(state);
        const allDay = new Map(dayKeys.map(k => [k, []]));
        const timed = new Map(dayKeys.map(k => [k, new Map()]));
        const dayStart = +state.config.day_start || 7;
        const dayEnd = +state.config.day_end || 21;
        const slot = +state.config.slot_minutes || 30;
        events.forEach(event => {
            if (!dayKeys.includes(event.date)) return;
            if (event.all_day) {
                allDay.get(event.date).push(event);
                return;
            }
            const start = minutes(event.start_time);
            const bucket = Math.floor((start - dayStart * 60) / slot);
            if (bucket < 0 || start >= dayEnd * 60) return;
            if (!timed.get(event.date).has(bucket)) timed.get(event.date).set(bucket, []);
            timed.get(event.date).get(bucket).push(event);
        });
        const dayNames = ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'];
        let html = `<div class="dpl2-time-view ${state.view === 'day' ? 'is-day' : 'is-week'}" style="--dpl-days:${days.length}"><div class="dpl2-time-head dpl2-time-corner"></div>`;
        days.forEach(d => html += `<div class="dpl2-time-head ${dateKey(d) === todayKey() ? 'is-today' : ''}">${dayNames[d.getDay()]} ${pad2(d.getDate())}/${pad2(d.getMonth()+1)}</div>`);
        html += '<div class="dpl2-all-day-label">Journée</div>';
        days.forEach(d => {
            const key = dateKey(d);
            const dayAllDayEvents = sortDayEvents(allDay.get(key) || []);
            const allDayContent = state.view === 'week'
                ? monthDayContent(state, key, dayAllDayEvents)
                : dayAllDayEvents.map(e => eventHtml(state, e)).join('');
            html += `<div class="dpl2-all-day-cell" data-dpl2-date="${key}" data-dpl2-all-day="1">${allDayContent}</div>`;
        });
        const totalSlots = Math.ceil(((dayEnd - dayStart) * 60) / slot);
        for (let row = 0; row < totalSlots; row++) {
            const minute = dayStart * 60 + row * slot;
            html += `<div class="dpl2-time-label">${timeString(minute)}</div>`;
            days.forEach(d => {
                const key = dateKey(d);
                const slotEvents = timed.get(key)?.get(row) || [];
                html += `<div class="dpl2-time-cell" data-dpl2-date="${key}" data-dpl2-time="${timeString(minute)}">${slotEvents.map(e => eventHtml(state,e)).join('')}</div>`;
            });
        }
        html += '</div>';
        zone.innerHTML = html;
        bindCalendarClicks(state, zone);
    }

    function bindCalendarClicks(state, zone) {
        if (zone.dataset.dpl2ClickBound === '1') return;
        zone.dataset.dpl2ClickBound = '1';
        zone.addEventListener('click', event => {
            const summaryButton = event.target.closest('[data-dpl2-day-summary]');
            if (summaryButton) {
                event.stopPropagation();
                openDayList(state, summaryButton.dataset.dpl2Date, summaryButton.dataset.dpl2Category || '');
                return;
            }
            const eventButton = event.target.closest('[data-dpl2-event]');
            if (eventButton) {
                event.stopPropagation();
                openEventById(state, eventButton.dataset.dpl2Event);
                return;
            }
            if (!state.permissions['event.create']) return;
            const cell = event.target.closest('[data-dpl2-date]');
            if (!cell || event.target.closest('button')) return;
            const prefill = {date: cell.dataset.dpl2Date};
            if (cell.dataset.dpl2AllDay === '1') prefill.all_day = true;
            if (cell.dataset.dpl2Time) prefill.start_time = cell.dataset.dpl2Time;
            openEditor(state, null, prefill);
        });
    }

    async function openEventById(state, id) {
        if (!id) return;
        try {
            const data = await request(`${state.api}?action=event_get&id=${encodeURIComponent(id)}`);
            openDetail(state, data.event);
        } catch (error) {
            toast(state, error.message, true);
        }
    }

    function closeDetail(state, eventOrId) {
        const key = detailWindowKey(eventOrId);
        if (key !== 'detail:') closeWindow(state, key);
    }
    function closeEditor(state) { closeWindow(state, 'editor'); }

    function openDetail(state, event) {
        if (!event?.id) return;
        const detailKey = detailWindowKey(event);
        const alreadyOpen = state.windows.get(detailKey);
        if (alreadyOpen?.isConnected) {
            bringToFront(alreadyOpen);
            return alreadyOpen;
        }
        const c = category(state, event.category_id);
        const p = planning(state, event.planning_id);
        const st = statusRow(state, event.status);
        const fieldDefs = c?.fields || [];
        const fieldRows = fieldDefs.map(def => {
            let value = event.fields?.[def.id];
            if (def.type === 'checkbox') value = value ? 'Oui' : 'Non';
            if (value === undefined || value === null || value === '') value = '—';
            return `<dt>${esc(def.label)}</dt><dd>${esc(value)}</dd>`;
        }).join('');
        const reminderChips = (event.reminders || []).map(rem => `<span class="dpl2-chip">⏰ ${esc(reminderLabel(rem))}</span>`).join('') || '<span class="dpl2-muted" style="font-size:9px">Aucun rappel.</span>';
        const resources = (event.resources || []).map(r => `<div class="dpl2-resource-line"><div><strong>${esc(r.label || r.name || r.id)}</strong><small>${esc(r.source)} · ${esc(r.type)}</small></div></div>`).join('');
        const detailCount = detailWindowEntries(state).length;
        const geom = initialGeometry(430, 470, -180 + (detailCount % 6) * 28);
        const popup = document.createElement('section');
        popup.className = 'dpl2-popup dpl2-detail';
        popup.innerHTML = `
            <header class="dpl2-popup-head"><div class="dpl2-popup-title"><strong>${esc(event.title)}</strong></div><div class="dpl2-popup-actions"><button type="button" class="dpl2-btn dpl2-close" data-dpl2-popup-close aria-label="Fermer">×</button></div></header>
            <div class="dpl2-popup-body">
                <dl class="dpl2-detail-grid">
                    <dt>Planning</dt><dd>${esc(p?.name || event.planning_id || '—')}</dd>
                    <dt>Catégorie</dt><dd><i class="dpl2-color-dot" style="background:${esc(c?.color || '#808080')}"></i> ${esc(c?.name || event.category_id || '—')}</dd>
                    <dt>Date</dt><dd>${esc(event.date)} ${event.all_day ? '· journée' : `· ${esc(event.start_time)} → ${esc(event.end_time)}`}</dd>
                    <dt>Statut</dt><dd>${esc(st?.icon || '')} ${esc(st?.label || event.status)}</dd>
                    <dt>Créé par</dt><dd>${esc(event.created_by || event.owner || '—')}</dd>
                    ${fieldRows}
                    <dt>Notes</dt><dd class="dpl2-detail-notes">${esc(event.notes || '—')}</dd>
                </dl>
                <div class="dpl2-section-title">Rappels</div><div class="dpl2-chip-list">${reminderChips}</div>
                ${resources ? `<div class="dpl2-section-title">Ressources liées</div>${resources}` : ''}
            </div>
            <footer class="dpl2-popup-footer">
                ${eventCanEdit(state,event) ? '<button type="button" class="dpl2-btn" data-dpl2-edit>Modifier</button>' : ''}
                ${state.permissions['event.status'] && event.status !== 'done' ? '<button type="button" class="dpl2-btn" data-dpl2-status="done">✓ Terminé</button>' : ''}
                ${state.permissions['event.status'] && event.status !== 'cancelled' ? '<button type="button" class="dpl2-btn" data-dpl2-status="cancelled">⛔ Annuler</button>' : ''}
                ${state.permissions['event.status'] && ['done','cancelled'].includes(event.status) ? '<button type="button" class="dpl2-btn" data-dpl2-status="planned">↩ Rouvrir</button>' : ''}
                ${eventCanDelete(state,event) ? '<button type="button" class="dpl2-btn dpl2-btn-danger" data-dpl2-delete>Supprimer</button>' : ''}
            </footer>
            <div class="dpl2-resize" aria-hidden="true"></div>`;
        mountWindow(state, detailKey, popup, '.dpl2-popup-head', geom);
        popup.querySelector('[data-dpl2-popup-close]').addEventListener('click', () => closeWindow(state, detailKey));
        popup.querySelector('[data-dpl2-edit]')?.addEventListener('click', () => { closeWindow(state, detailKey); openEditor(state, event, {}); });
        popup.querySelectorAll('[data-dpl2-status]').forEach(button => button.addEventListener('click', async () => {
            try {
                const data = await post(state, 'event_status', {id: event.id, status: button.dataset.dpl2Status});
                closeWindow(state, detailKey);
                await refreshAfterChange(state);
                openDetail(state, data.event);
            } catch (error) { toast(state, error.message, true); }
        }));
        popup.querySelector('[data-dpl2-delete]')?.addEventListener('click', async () => {
            if (!window.confirm(`Supprimer « ${event.title} » ?`)) return;
            try {
                await post(state, 'event_delete', {id: event.id});
                closeWindow(state, detailKey);
                await refreshAfterChange(state);
                toast(state, 'Événement supprimé.');
            } catch (error) { toast(state, error.message, true); }
        });
    }

    function reminderLabel(reminder) {
        const n = Math.max(0, +reminder?.offset_minutes || 0);
        let before = 'À l’heure prévue';
        if (n > 0 && n % 1440 === 0) before = `${n / 1440} j avant`;
        else if (n > 0 && n % 60 === 0) before = `${n / 60} h avant`;
        else if (n > 0) before = `${n} min avant`;
        const channel = reminder?.channel === 'email' ? 'E-mail' : reminder?.channel === 'both' ? 'Interne + e-mail' : 'Interne';
        return `${before} · ${channel}`;
    }

    function reminderParts(offset) {
        const n = Math.max(0, +offset || 0);
        if (n > 0 && n % 1440 === 0) return {value: n / 1440, unit: 'days'};
        if (n > 0 && n % 60 === 0) return {value: n / 60, unit: 'hours'};
        return {value: n, unit: 'minutes'};
    }
    function reminderMinutes(value, unit) {
        const n = Math.max(0, +value || 0);
        return unit === 'days' ? n * 1440 : unit === 'hours' ? n * 60 : n;
    }
    function defaultReminders(state, cat) {
        const source = (cat?.default_reminders || []).length ? cat.default_reminders : (state.config?.default_reminders || []);
        return clone(source || []).map(r => ({id: '', offset_minutes: +r.offset_minutes || 0, channel: r.channel || 'internal', enabled: true}));
    }

    async function loadActionResources(state) {
        if (Array.isArray(state.actionResources)) return state.actionResources;
        if (!state.permissions['resource.link'] || !state.actionHubApi) return [];
        try {
            const data = await request(`${state.actionHubApi}?action=resources&limit=200`);
            state.actionResources = (data.resources || []).filter(r => r && r.id && r.type && r.source && r.source !== 'DMD-Planning');
        } catch (_) {
            state.actionResources = [];
        }
        return state.actionResources;
    }

    async function openEditor(state, sourceEvent, prefill = {}) {
        if (!state.permissions['event.create'] && !sourceEvent) return;

        const categories = state.config?.categories || [];
        const plans = state.config?.plannings || [];
        const enabledPlanIds = new Set(plans.filter(p => p.enabled !== false).map(p => p.id));
        const usableCategories = categories.filter(c => enabledPlanIds.has(c.planning_id));

        if (!categories.length || (!sourceEvent && !usableCategories.length)) {
            toast(state, 'Crée d’abord au moins un planning actif et une catégorie dans la configuration.', true);
            return;
        }

        closeEditor(state);
        await loadActionResources(state);

        const sourceCategory = sourceEvent ? category(state, sourceEvent.category_id) : null;
        let cat = sourceCategory || usableCategories[0] || categories[0] || null;
        if (!cat) {
            toast(state, 'Aucune catégorie utilisable.', true);
            return;
        }

        const hasPrefillTime = Object.prototype.hasOwnProperty.call(prefill, 'start_time') && !!prefill.start_time;
        const hasPrefillAllDay = prefill.all_day === true;
        const initialAllDay = sourceEvent
            ? !!sourceEvent.all_day
            : (hasPrefillAllDay ? true : (hasPrefillTime ? false : !!cat.all_day_default));

        const event = sourceEvent ? clone(sourceEvent) : {
            id: '',
            planning_id: cat.planning_id || '',
            category_id: cat.id || '',
            title: '',
            all_day: initialAllDay,
            date: prefill.date || dateKey(state.cursor),
            start_time: prefill.start_time || '09:00',
            end_time: '',
            status: state.config?.statuses?.[0]?.id || 'planned',
            notes: '',
            fields: {},
            resources: [],
            reminders: [],
        };

        event.category_id = cat.id || event.category_id || '';
        event.planning_id = cat.planning_id || event.planning_id || '';
        if (!sourceEvent && !(event.reminders || []).length) event.reminders = defaultReminders(state, cat);
        if (!event.all_day && !event.end_time) {
            event.end_time = timeString(minutes(event.start_time) + (+cat.default_duration || 60));
        }

        const geom = initialGeometry(470, 640, 220);
        const popup = document.createElement('section');
        popup.className = 'dpl2-popup dpl2-editor';
        popup.innerHTML = `
            <header class="dpl2-popup-head"><div class="dpl2-popup-title"><strong>${sourceEvent ? 'Modifier l’événement' : 'Nouvel événement'}</strong></div><div class="dpl2-popup-actions"><button type="button" class="dpl2-btn dpl2-close" data-dpl2-popup-close aria-label="Fermer">×</button></div></header>
            <div class="dpl2-popup-body">
                <form class="dpl2-form" data-dpl2-event-form>
                    <div class="dpl2-form-grid">
                        <label class="dpl2-span-2"><span>Titre</span><input name="title" maxlength="180" required value="${esc(event.title)}" placeholder="Titre de l’événement"></label>
                        <label class="dpl2-span-2"><span>Catégorie</span><select name="category_id"></select></label>
                        <label><span>Date</span><input type="date" name="date" required value="${esc(event.date)}"></label>
                        <label class="dpl2-check"><input type="checkbox" name="all_day" ${event.all_day ? 'checked' : ''}><span>Journée entière</span></label>
                        <label data-dpl2-time-field><span>Début</span><input type="time" name="start_time" value="${esc(event.start_time)}"></label>
                        <label data-dpl2-time-field><span>Fin</span><input type="time" name="end_time" value="${esc(event.end_time)}"></label>
                        <label><span>Statut</span><select name="status">${(state.config?.statuses || []).map(s => `<option value="${esc(s.id)}" ${s.id === event.status ? 'selected' : ''}>${esc(s.icon || '')} ${esc(s.label)}</option>`).join('')}</select></label>
                        <div></div>
                        <div class="dpl2-custom-fields" data-dpl2-custom-fields></div>
                        <label class="dpl2-span-2"><span>Notes</span><textarea name="notes" placeholder="Informations utiles…">${esc(event.notes)}</textarea></label>
                        <div class="dpl2-reminder-box"><div class="dpl2-box-head"><strong>⏰ Rappels</strong><button type="button" class="dpl2-btn" data-dpl2-reminder-add>+ Rappel</button></div><div class="dpl2-reminder-list" data-dpl2-reminders></div></div>
                        ${state.permissions['resource.link'] ? `<div class="dpl2-resource-box"><div class="dpl2-box-head"><strong>⚡ Ressources DoMyDesk</strong><button type="button" class="dpl2-btn" data-dpl2-resource-toggle>Lier une ressource</button></div><div class="dpl2-linked-list" data-dpl2-linked></div><div class="dpl2-resource-picker" data-dpl2-picker hidden><input type="text" data-dpl2-resource-search placeholder="Rechercher une ressource…"><div class="dpl2-resource-results" data-dpl2-resource-results></div></div></div>` : ''}
                    </div>
                </form>
            </div>
            <footer class="dpl2-popup-footer"><button type="button" class="dpl2-btn" data-dpl2-cancel>Annuler</button><button type="button" class="dpl2-btn dpl2-btn-primary" data-dpl2-save>${sourceEvent ? 'Enregistrer' : 'Créer'}</button></footer>
            <div class="dpl2-resize" aria-hidden="true"></div>`;
        mountWindow(state, 'editor', popup, '.dpl2-popup-head', geom);

        const form = popup.querySelector('[data-dpl2-event-form]');
        const catSelect = form.elements.category_id;
        const allDay = form.elements.all_day;
        let reminders = clone(event.reminders || []);
        let linked = clone(event.resources || []);

        // L’utilisateur choisit directement une catégorie. Le planning parent est
        // déduit automatiquement de cette catégorie : aucun double choix inutile.
        const editorCategories = sourceEvent && sourceCategory && !usableCategories.some(c => c.id === sourceCategory.id)
            ? [sourceCategory, ...usableCategories]
            : usableCategories;
        catSelect.innerHTML = editorCategories.map(c => `<option value="${esc(c.id)}" ${c.id === event.category_id ? 'selected' : ''}>${esc(c.name)}</option>`).join('');
        if (!editorCategories.some(c => c.id === catSelect.value) && editorCategories[0]) catSelect.value = editorCategories[0].id;
        cat = category(state, catSelect.value) || cat;

        const renderFields = (catRow) => {
            const zone = form.querySelector('[data-dpl2-custom-fields]');
            const defs = catRow?.fields || [];
            if (!defs.length) { zone.innerHTML = ''; return; }
            zone.innerHTML = `<div class="dpl2-business-title"><strong>Zone métier</strong><span>Renseigne seulement ce qui concerne cet événement.</span></div>${defs.map(def => customFieldHtml(def, event.fields?.[def.id])).join('')}`;
        };
        const renderTimeFields = () => form.querySelectorAll('[data-dpl2-time-field]').forEach(label => label.hidden = !!allDay.checked);
        const renderReminders = () => {
            const zone = form.querySelector('[data-dpl2-reminders]');
            if (!reminders.length) {
                zone.innerHTML = '<span class="dpl2-linked-empty">Aucun rappel.</span>';
                return;
            }
            zone.innerHTML = reminders.map((r, i) => {
                const p = reminderParts(r.offset_minutes);
                return `<div class="dpl2-reminder-row" data-reminder-index="${i}"><input type="number" min="0" max="525600" value="${esc(p.value)}" data-rem-value><select data-rem-unit><option value="minutes" ${p.unit === 'minutes' ? 'selected' : ''}>minute(s) avant</option><option value="hours" ${p.unit === 'hours' ? 'selected' : ''}>heure(s) avant</option><option value="days" ${p.unit === 'days' ? 'selected' : ''}>jour(s) avant</option></select><select data-rem-channel><option value="internal" ${r.channel === 'internal' ? 'selected' : ''}>Interne</option><option value="email" ${r.channel === 'email' ? 'selected' : ''}>E-mail</option><option value="both" ${r.channel === 'both' ? 'selected' : ''}>Interne + e-mail</option></select><button type="button" class="dpl2-btn" data-rem-delete>×</button></div>`;
            }).join('');
            zone.querySelectorAll('[data-reminder-index]').forEach(row => {
                const i = +row.dataset.reminderIndex;
                const sync = () => {
                    reminders[i].offset_minutes = reminderMinutes(row.querySelector('[data-rem-value]').value, row.querySelector('[data-rem-unit]').value);
                    reminders[i].channel = row.querySelector('[data-rem-channel]').value;
                    reminders[i].enabled = true;
                };
                row.querySelectorAll('input,select').forEach(input => input.addEventListener('change', sync));
                row.querySelector('[data-rem-delete]').addEventListener('click', () => { reminders.splice(i, 1); renderReminders(); });
            });
        };
        const renderLinked = () => {
            const zone = form.querySelector('[data-dpl2-linked]');
            if (!zone) return;
            if (!linked.length) { zone.innerHTML = '<span class="dpl2-linked-empty">Aucune ressource liée.</span>'; return; }
            zone.innerHTML = linked.map((r, i) => `<div class="dpl2-resource-option"><div><strong>${esc(r.label || r.name || r.id)}</strong><small>${esc(r.source)} · ${esc(r.type)}</small></div><button type="button" class="dpl2-btn" data-linked-delete="${i}">Retirer</button></div>`).join('');
            zone.querySelectorAll('[data-linked-delete]').forEach(button => button.addEventListener('click', () => { linked.splice(+button.dataset.linkedDelete, 1); renderLinked(); renderResourceResults(); }));
        };
        const renderResourceResults = () => {
            const zone = form.querySelector('[data-dpl2-resource-results]');
            const search = form.querySelector('[data-dpl2-resource-search]');
            if (!zone || !search) return;
            const q = search.value.trim().toLowerCase();
            const linkedIds = new Set(linked.map(r => r.id));
            const rows = (state.actionResources || []).filter(r => !linkedIds.has(r.id) && (!q || `${r.label || r.name || ''} ${r.source || ''} ${r.type || ''}`.toLowerCase().includes(q))).slice(0, 80);
            zone.innerHTML = rows.length ? rows.map((r, i) => `<div class="dpl2-resource-option" data-resource-id="${esc(r.id)}"><div><strong>${esc(r.label || r.name || r.id)}</strong><small>${esc(r.source)} · ${esc(r.type)}</small></div><button type="button" class="dpl2-btn" data-resource-add="${i}">Ajouter</button></div>`).join('') : '<span class="dpl2-linked-empty">Aucune ressource.</span>';
            zone.querySelectorAll('[data-resource-id]').forEach(row => {
                row.querySelector('[data-resource-add]')?.addEventListener('click', () => {
                    const resource = (state.actionResources || []).find(r => r.id === row.dataset.resourceId);
                    if (resource) { linked.push(clone(resource)); renderLinked(); renderResourceResults(); }
                });
            });
        };

        let currentCat = cat;
        renderFields(currentCat);
        renderTimeFields();
        renderReminders();
        renderLinked();
        renderResourceResults();

        catSelect.addEventListener('change', () => {
            currentCat = category(state, catSelect.value);
            event.category_id = currentCat?.id || '';
            event.planning_id = currentCat?.planning_id || '';
            event.fields = {};
            renderFields(currentCat);

            if (!sourceEvent) {
                // Les valeurs configurées sur la catégorie sont réellement reprises
                // lors de la création d’un nouvel événement.
                allDay.checked = !!currentCat?.all_day_default;
                renderTimeFields();
                reminders = defaultReminders(state, currentCat);
                if (!allDay.checked) {
                    form.elements.end_time.value = timeString(minutes(form.elements.start_time.value) + (+currentCat?.default_duration || 60));
                }
                renderReminders();
            }
        });
        allDay.addEventListener('change', renderTimeFields);
        form.elements.start_time.addEventListener('change', () => {
            if (!sourceEvent && !allDay.checked) form.elements.end_time.value = timeString(minutes(form.elements.start_time.value) + (+currentCat?.default_duration || 60));
        });
        form.querySelector('[data-dpl2-reminder-add]').addEventListener('click', () => { reminders.push({id: '', offset_minutes: 60, channel: 'internal', enabled: true}); renderReminders(); });
        form.querySelector('[data-dpl2-resource-toggle]')?.addEventListener('click', () => {
            const picker = form.querySelector('[data-dpl2-picker]');
            picker.hidden = !picker.hidden;
            if (!picker.hidden) form.querySelector('[data-dpl2-resource-search]')?.focus();
        });
        form.querySelector('[data-dpl2-resource-search]')?.addEventListener('input', renderResourceResults);
        popup.querySelector('[data-dpl2-popup-close]').addEventListener('click', () => closeEditor(state));
        popup.querySelector('[data-dpl2-cancel]').addEventListener('click', () => closeEditor(state));
        popup.querySelector('[data-dpl2-save]').addEventListener('click', async () => {
            if (!form.reportValidity()) return;
            const fd = new FormData(form);
            const activeCategory = category(state, fd.get('category_id'));
            if (!activeCategory) {
                toast(state, 'Catégorie invalide.', true);
                return;
            }
            const fields = {};
            (activeCategory.fields || []).forEach(def => {
                const input = form.elements[`field_${def.id}`];
                if (!input) return;
                fields[def.id] = def.type === 'checkbox' ? !!input.checked : input.value;
            });
            form.querySelectorAll('[data-reminder-index]').forEach(row => {
                const i = +row.dataset.reminderIndex;
                if (!reminders[i]) return;
                reminders[i].offset_minutes = reminderMinutes(row.querySelector('[data-rem-value]').value, row.querySelector('[data-rem-unit]').value);
                reminders[i].channel = row.querySelector('[data-rem-channel]').value;
                reminders[i].enabled = true;
            });
            const payload = {
                id: sourceEvent?.id || '',
                title: fd.get('title'),
                planning_id: activeCategory.planning_id,
                category_id: activeCategory.id,
                date: fd.get('date'),
                all_day: allDay.checked,
                start_time: allDay.checked ? '' : fd.get('start_time'),
                end_time: allDay.checked ? '' : fd.get('end_time'),
                status: fd.get('status'),
                notes: fd.get('notes'),
                fields,
                resources: linked,
                reminders,
            };
            const saveButton = popup.querySelector('[data-dpl2-save]');
            saveButton.disabled = true;
            try {
                await post(state, 'event_save', payload);
                closeEditor(state);
                await refreshAfterChange(state);
                toast(state, sourceEvent ? 'Événement modifié.' : 'Événement créé.');
            } catch (error) {
                toast(state, error.message, true);
            } finally {
                if (saveButton.isConnected) saveButton.disabled = false;
            }
        });
    }

    function customFieldHtml(def, value) {
        const name = `field_${def.id}`;
        const required = def.required ? 'required' : '';
        const label = `<span>${esc(def.label)}${def.required ? ' *' : ''}</span>`;
        if (def.type === 'textarea') return `<label class="dpl2-span-2">${label}<textarea name="${esc(name)}" ${required}>${esc(value || '')}</textarea></label>`;
        if (def.type === 'select' || (def.options || []).length) return `<label>${label}<select name="${esc(name)}" ${required}><option value="">— Non concerné / choisir —</option>${(def.options || []).map(opt => `<option value="${esc(opt)}" ${String(value ?? '') === String(opt) ? 'selected' : ''}>${esc(opt)}</option>`).join('')}</select></label>`;
        if (def.type === 'checkbox') return `<label class="dpl2-check"><input type="checkbox" name="${esc(name)}" ${value ? 'checked' : ''}><span>${esc(def.label)}</span></label>`;
        const typeMap = {number:'number',date:'date',time:'time',datetime:'datetime-local',email:'email',phone:'tel'};
        const type = typeMap[def.type] || 'text';
        return `<label>${label}<input type="${type}" name="${esc(name)}" value="${esc(value ?? '')}" ${required}></label>`;
    }

    async function post(state, action, payload) {
        return request(`${state.api}?action=${encodeURIComponent(action)}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json', 'X-DMD-CSRF': state.csrf},
            body: JSON.stringify(payload || {}),
        });
    }

    async function refreshAfterChange(state) {
        if (state.windows.get('calendar')?.isConnected) await refreshCalendar(state);
        try {
            const today = new Date();
            const data = await request(`${state.api}?action=events_list&from=${dateKey(today)}&to=${dateKey(addDays(today,45))}`);
            state.tileEvents = data.events || [];
            renderTile(state);
        } catch (_) {}
    }

    function toast(state, message, error = false) {
        const top = topPlanningWindow(state);
        const host = top?.[1] || state.root;
        if (!host) return;
        host.querySelector('.dpl2-toast')?.remove();
        const node = document.createElement('div');
        node.className = `dpl2-toast${error ? ' is-error' : ''}`;
        node.textContent = message;
        host.appendChild(node);
        setTimeout(() => node.remove(), 3600);
    }

    document.addEventListener('keydown', event => {
        if (event.key !== 'Escape') return;
        document.querySelectorAll('[data-dpl2-root]').forEach(root => {
            const state = root._dpl2State;
            if (!state) return;
            if (state.windows.get('editor')?.isConnected) closeEditor(state);
            else {
                const topDetail = topPlanningWindow(state, 'detail:');
                if (topDetail) closeWindow(state, topDetail[0]);
            }
        });
    });

    function handleActionHubComplete(event) {
        const detail = event?.detail || {};
        const result = detail.result || detail.response || detail.data || detail || {};
        const data = result.data || result.result?.data || result.payload || result;
        const moduleId = String(data.module || data.module_id || result.module || '').trim();
        if (moduleId && moduleId.toLowerCase() !== 'dmd-planning') return;
        const eventId = String(data.event_id || data.local_id || data.id || '').trim();
        const command = String(data.command || data.action || '').trim();
        if (!eventId && !data.reload) return;

        document.querySelectorAll('[data-dpl2-root]').forEach(root => {
            const state = root._dpl2State;
            if (!state) return;
            if (command === 'open-event' && eventId) {
                openEventById(state, eventId);
                return;
            }
            if (command === 'edit-event' && eventId) {
                request(`${state.api}?action=event_get&id=${encodeURIComponent(eventId)}`)
                    .then(response => openEditor(state, response.event, {}))
                    .catch(error => toast(state, error.message, true));
                return;
            }
            if (data.reload) refreshAfterChange(state).catch(() => {});
        });
    }

    [
        'dmd:actionhub-action-complete',
        'dmd:actionhub:action-complete',
        'actionhub:action-complete',
        'dmd-actionhub-action-complete'
    ].forEach(name => document.addEventListener(name, handleActionHubComplete));

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountAll, {once: true});
    else mountAll();
})();
