<?php



/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */





declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-planning_lib.php';

function dmd_planning_api_input(): array
{
    $contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
    if (str_contains($contentType, 'application/json')) {
        $raw = file_get_contents('php://input');
        $decoded = json_decode(is_string($raw) ? $raw : '', true);
        return is_array($decoded) ? $decoded : [];
    }
    return is_array($_POST) ? $_POST : [];
}

function dmd_planning_api_permissions(): array
{
    $ids = ['module.view', 'event.create', 'event.edit', 'event.edit.all', 'event.delete', 'event.delete.all', 'event.status', 'resource.link', 'config.view', 'config.edit', 'logs.view'];
    $out = [];
    foreach ($ids as $id) $out[$id] = dmd_planning_has_permission($id);
    return $out;
}

function dmd_planning_api_require_write(array $input): void
{
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
        dmd_planning_reply(['ok' => false, 'error' => 'method_not_allowed', 'message' => 'Méthode POST requise.'], 405);
    }
    $token = trim((string)($_SERVER['HTTP_X_DMD_CSRF'] ?? ($input['csrf_token'] ?? '')));
    if (!dmd_planning_validate_csrf($token)) {
        dmd_planning_reply(['ok' => false, 'error' => 'csrf', 'message' => 'Session expirée. Rechargez la page.'], 419);
    }
}

$action = strtolower(trim((string)($_GET['action'] ?? $_POST['action'] ?? 'bootstrap')));

if ($action === 'bootstrap') {
    dmd_planning_require_permission('module.view');
    $tick = dmd_planning_process_due_reminders(null, false);
    dmd_planning_reply([
        'ok' => true,
        'version' => DMD_PLANNING_VERSION,
        'config' => dmd_planning_config(),
        'permissions' => dmd_planning_api_permissions(),
        'csrf' => dmd_planning_csrf(),
        'user' => dmd_planning_email(),
        'server_time' => date(DATE_ATOM),
        'reminder_engine' => dmd_planning_reminder_status(),
        'reminder_tick' => $tick,
    ]);
}

if ($action === 'config_bootstrap') {
    dmd_planning_require_permission('config.view');
    dmd_planning_reply([
        'ok' => true,
        'version' => DMD_PLANNING_VERSION,
        'config' => dmd_planning_config(),
        'permissions' => dmd_planning_api_permissions(),
        'csrf' => dmd_planning_csrf(),
        'user' => dmd_planning_email(),
        'reminder_engine' => dmd_planning_reminder_status(),
    ]);
}

if ($action === 'events_list') {
    dmd_planning_require_permission('module.view');
    $from = dmd_planning_clean($_GET['from'] ?? '', 10);
    $to = dmd_planning_clean($_GET['to'] ?? '', 10);
    $events = dmd_planning_events();
    if (dmd_planning_valid_date($from)) $events = array_values(array_filter($events, static fn(array $e): bool => (string)($e['date'] ?? '') >= $from));
    if (dmd_planning_valid_date($to)) $events = array_values(array_filter($events, static fn(array $e): bool => (string)($e['date'] ?? '') <= $to));
    usort($events, static function (array $a, array $b): int {
        $ak = (string)($a['date'] ?? '') . ' ' . (!empty($a['all_day']) ? '00:00' : (string)($a['start_time'] ?? ''));
        $bk = (string)($b['date'] ?? '') . ' ' . (!empty($b['all_day']) ? '00:00' : (string)($b['start_time'] ?? ''));
        return strcmp($ak, $bk);
    });
    dmd_planning_reply(['ok' => true, 'events' => $events]);
}

if ($action === 'event_get') {
    dmd_planning_require_permission('module.view');
    $id = dmd_planning_valid_event_id($_GET['id'] ?? '');
    if (!$id) dmd_planning_reply(['ok' => false, 'error' => 'invalid_id'], 400);
    $event = dmd_planning_find_event(dmd_planning_events(), $id);
    if (!$event) dmd_planning_reply(['ok' => false, 'error' => 'not_found', 'message' => 'Événement introuvable.'], 404);
    dmd_planning_reply(['ok' => true, 'event' => $event]);
}

if ($action === 'logs') {
    dmd_planning_require_permission('logs.view');
    dmd_planning_reply(['ok' => true, 'logs' => dmd_planning_recent_logs((int)($_GET['limit'] ?? 150))]);
}

if ($action === 'reminders_status') {
    dmd_planning_require_permission('config.view');
    dmd_planning_reply(['ok' => true, 'status' => dmd_planning_reminder_status()]);
}

if ($action === 'reminders_tick') {
    dmd_planning_require_permission('module.view');
    $tick = dmd_planning_process_due_reminders(null, false);
    dmd_planning_reply(['ok' => true, 'result' => $tick, 'status' => dmd_planning_reminder_status()]);
}

$input = dmd_planning_api_input();
dmd_planning_api_require_write($input);

if ($action === 'event_save') {
    $id = dmd_planning_valid_event_id($input['id'] ?? '');
    $config = dmd_planning_config();
    if (!$id) dmd_planning_require_permission('event.create');
    if (!empty($input['resources']) && !dmd_planning_has_permission('resource.link')) {
        dmd_planning_reply(['ok' => false, 'error' => 'permission_denied', 'permission' => 'resource.link', 'message' => 'Droit insuffisant pour lier une ressource.'], 403);
    }

    try {
        $saved = dmd_planning_mutate_events(function (array &$events) use ($id, $input, $config): array {
            $old = null;
            $index = -1;
            if ($id) {
                $index = dmd_planning_find_event_index($events, $id);
                if ($index < 0) throw new OutOfBoundsException('Événement introuvable.');
                $old = $events[$index];
                if (!dmd_planning_can_edit($old)) throw new RuntimeException('permission_denied');
            }
            $event = dmd_planning_clean_event_input($input, $config, $old);
            if (!$id) {
                do {
                    $newId = 'evt-' . bin2hex(random_bytes(8));
                } while (dmd_planning_find_event($events, $newId));
                $event['id'] = $newId;
                $events[] = $event;
                $eventAction = 'event.created';
            } else {
                $event['id'] = $id;
                $events[$index] = $event;
                if ((string)($old['status'] ?? '') !== (string)$event['status']) {
                    $eventAction = $event['status'] === 'cancelled' ? 'event.cancelled' : 'event.status_changed';
                } elseif (
                    (string)($old['date'] ?? '') !== (string)$event['date'] ||
                    (string)($old['start_time'] ?? '') !== (string)$event['start_time'] ||
                    (string)($old['end_time'] ?? '') !== (string)$event['end_time'] ||
                    !empty($old['all_day']) !== !empty($event['all_day'])
                ) {
                    $eventAction = 'event.moved';
                } else {
                    $eventAction = 'event.updated';
                }
            }
            return ['event' => $event, 'old' => $old, 'action' => $eventAction];
        });
    } catch (OutOfBoundsException $e) {
        dmd_planning_reply(['ok' => false, 'error' => 'not_found', 'message' => $e->getMessage()], 404);
    } catch (InvalidArgumentException $e) {
        dmd_planning_reply(['ok' => false, 'error' => 'invalid_input', 'message' => $e->getMessage()], 400);
    } catch (RuntimeException $e) {
        if ($e->getMessage() === 'permission_denied') dmd_planning_reply(['ok' => false, 'error' => 'permission_denied', 'message' => 'Modification non autorisée.'], 403);
        dmd_planning_reply(['ok' => false, 'error' => 'save_failed', 'message' => $e->getMessage()], 500);
    }

    $event = $saved['event'];
    $changes = $saved['old'] ? dmd_planning_event_changes($saved['old'], $event) : [];
    $audit = dmd_planning_audit($saved['action'], $event, 'success', ['source' => 'ui'], $changes);
    dmd_planning_emit_notification($saved['action'], $event, $config, $saved['old'] ? 'Événement modifié.' : 'Événement créé.');
    dmd_planning_reply(['ok' => true, 'event' => $event, 'resource' => dmd_planning_event_resource($event), 'activity' => $audit]);
}

if ($action === 'event_delete') {
    $id = dmd_planning_valid_event_id($input['id'] ?? '');
    if (!$id) dmd_planning_reply(['ok' => false, 'error' => 'invalid_id'], 400);
    try {
        $event = dmd_planning_mutate_events(function (array &$events) use ($id): array {
            $index = dmd_planning_find_event_index($events, $id);
            if ($index < 0) throw new OutOfBoundsException('Événement introuvable.');
            $event = $events[$index];
            if (!dmd_planning_can_delete($event)) throw new RuntimeException('permission_denied');
            array_splice($events, $index, 1);
            return $event;
        });
    } catch (OutOfBoundsException $e) {
        dmd_planning_reply(['ok' => false, 'error' => 'not_found', 'message' => $e->getMessage()], 404);
    } catch (RuntimeException $e) {
        if ($e->getMessage() === 'permission_denied') dmd_planning_reply(['ok' => false, 'error' => 'permission_denied', 'message' => 'Suppression non autorisée.'], 403);
        dmd_planning_reply(['ok' => false, 'error' => 'delete_failed', 'message' => $e->getMessage()], 500);
    }
    dmd_planning_audit('event.deleted', $event, 'success', ['source' => 'ui']);
    dmd_planning_reply(['ok' => true, 'deleted' => $id]);
}

if ($action === 'event_status') {
    dmd_planning_require_permission('event.status');
    $id = dmd_planning_valid_event_id($input['id'] ?? '');
    $status = dmd_planning_slug($input['status'] ?? '', '');
    if (!$id || $status === '') dmd_planning_reply(['ok' => false, 'error' => 'invalid_input'], 400);
    try {
        $event = dmd_planning_set_status($id, $status, 'ui');
    } catch (Throwable $e) {
        dmd_planning_reply(['ok' => false, 'error' => 'status_failed', 'message' => $e->getMessage()], 400);
    }
    dmd_planning_reply(['ok' => true, 'event' => $event]);
}

if ($action === 'quicksession_add') {
    dmd_planning_require_permission('module.view');
    $id = dmd_planning_valid_event_id($input['id'] ?? '');
    $event = $id ? dmd_planning_find_event(dmd_planning_events(), $id) : null;
    if (!$event) dmd_planning_reply(['ok' => false, 'error' => 'not_found', 'message' => 'Événement introuvable.'], 404);
    dmd_planning_boot_core();
    if (!function_exists('dmd_qs_add_resource')) dmd_planning_reply(['ok' => false, 'error' => 'quicksession_unavailable', 'message' => 'QuickSession indisponible.'], 409);

    $added = 0;
    $first = dmd_qs_add_resource(dmd_planning_email(), dmd_planning_event_resource($event));
    if (!empty($first['ok']) && !empty($first['added'])) $added++;
    if (empty($first['ok'])) dmd_planning_reply(['ok' => false, 'error' => $first['error'] ?? 'no_active_session', 'message' => 'Aucune QuickSession active.'], 409);
    foreach ((array)($event['resources'] ?? []) as $resource) {
        try {
            $result = dmd_qs_add_resource(dmd_planning_email(), $resource);
            if (!empty($result['ok']) && !empty($result['added'])) $added++;
        } catch (Throwable $e) {
        }
    }
    dmd_planning_audit('event.quicksession_added', $event, 'success', ['resources_added' => $added]);
    dmd_planning_reply(['ok' => true, 'added' => $added]);
}

if ($action === 'reminders_run') {
    dmd_planning_require_permission('config.edit');
    $result = dmd_planning_process_due_reminders(null, true);
    dmd_planning_reply(['ok' => true, 'result' => $result, 'status' => dmd_planning_reminder_status()]);
}

if ($action === 'config_save') {
    dmd_planning_require_permission('config.edit');
    $config = is_array($input['config'] ?? null) ? $input['config'] : [];
    $before = dmd_planning_config();
    $after = dmd_planning_save_config($config);
    $dummy = ['id' => 'config-dmd-planning', 'title' => 'Configuration DMD-Planning', 'owner' => dmd_planning_email(), 'planning_id' => '', 'category_id' => '', 'status' => ''];
    dmd_planning_audit('config.updated', $dummy, 'success', ['before' => $before, 'after' => $after]);
    dmd_planning_reply(['ok' => true, 'config' => $after]);
}

dmd_planning_reply(['ok' => false, 'error' => 'unknown_action', 'message' => 'Action inconnue.'], 404);
