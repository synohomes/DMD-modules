(function(){
"use strict";
const root=document.querySelector('[data-dplm-root]');
if(!root||root.dataset.ready==='1')return;
root.dataset.ready='1';

const state={
    api:root.dataset.api||'',
    config:null,
    permissions:{},
    csrf:'',
    user:'',
    view:'day',
    cursor:new Date(),
    events:[],
    selectedPlanning:'',
    query:'',
    activeEvent:null
};

const $=(sel,ctx=root)=>ctx.querySelector(sel);
const $$=(sel,ctx=root)=>Array.from(ctx.querySelectorAll(sel));
const esc=(v)=>String(v??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[m]));
const pad=(n)=>String(n).padStart(2,'0');
const dateKey=(d)=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const cloneDate=(d)=>new Date(d.getFullYear(),d.getMonth(),d.getDate(),12,0,0,0);
const addDays=(d,n)=>{const x=cloneDate(d);x.setDate(x.getDate()+n);return x;};
const startMonth=(d)=>new Date(d.getFullYear(),d.getMonth(),1,12);
const endMonth=(d)=>new Date(d.getFullYear(),d.getMonth()+1,0,12);
const parseDate=(value)=>{const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(String(value||''));return m?new Date(+m[1],+m[2]-1,+m[3],12,0,0,0):new Date();};
const isMondayWeek=()=>state.config?.week_starts_monday!==false;
const startWeek=(d)=>{const x=cloneDate(d);const day=x.getDay();const delta=isMondayWeek()?(day===0?-6:1-day):-day;return addDays(x,delta);};
const endWeek=(d)=>addDays(startWeek(d),6);
const rangeForView=()=>state.view==='day'?{from:cloneDate(state.cursor),to:cloneDate(state.cursor)}:state.view==='week'?{from:startWeek(state.cursor),to:endWeek(state.cursor)}:{from:startMonth(state.cursor),to:endMonth(state.cursor)};
const periodLabel=()=>{const locale='fr-FR';if(state.view==='day')return new Intl.DateTimeFormat(locale,{weekday:'long',day:'2-digit',month:'long',year:'numeric'}).format(state.cursor);if(state.view==='week'){const a=startWeek(state.cursor),b=endWeek(state.cursor);return `${new Intl.DateTimeFormat(locale,{day:'2-digit',month:'short'}).format(a)} → ${new Intl.DateTimeFormat(locale,{day:'2-digit',month:'short',year:'numeric'}).format(b)}`;}return new Intl.DateTimeFormat(locale,{month:'long',year:'numeric'}).format(state.cursor);};
const today=()=>cloneDate(new Date());
const categoryById=(id)=>((state.config?.categories)||[]).find(x=>x.id===id)||null;
const planningById=(id)=>((state.config?.plannings)||[]).find(x=>x.id===id)||null;
const statusById=(id)=>((state.config?.statuses)||[]).find(x=>x.id===id)||null;
const categoryColor=(event)=>categoryById(event.category_id)?.color||'var(--accent)';
const categoryLabel=(event)=>categoryById(event.category_id)?.label||event.category_id||'Catégorie';
const planningLabel=(event)=>planningById(event.planning_id)?.label||event.planning_id||'Planning';
const statusLabel=(event)=>statusById(event.status)?.label||event.status||'Statut';
const statusColor=(event)=>statusById(event.status)?.color||'var(--border)';
const dateLabel=(value)=>new Intl.DateTimeFormat('fr-FR',{weekday:'long',day:'2-digit',month:'long',year:'numeric'}).format(parseDate(value));
const timeLabel=(event)=>event.all_day?'Toute la journée':`${event.start_time||'--:--'} → ${event.end_time||'--:--'}`;
const notePreview=(value)=>String(value||'').replace(/\s+/g,' ').trim();

async function request(url,options){
    const response=await fetch(url,Object.assign({cache:'no-store',credentials:'same-origin'},options||{}));
    let data=null;
    try{data=await response.json();}catch(_){}
    if(!response.ok||!data||data.ok===false){
        throw new Error(data?.message||data?.error||`Erreur HTTP ${response.status}`);
    }
    return data;
}
async function get(action,params){
    const url=new URL(state.api,location.href);
    url.searchParams.set('action',action);
    Object.entries(params||{}).forEach(([k,v])=>url.searchParams.set(k,v));
    return request(url.toString());
}
async function post(action,payload){
    return request(state.api,{
        method:'POST',
        headers:{'Content-Type':'application/json','X-DMD-CSRF':state.csrf},
        body:JSON.stringify(Object.assign({action,csrf_token:state.csrf},payload||{}))
    });
}

function renderPlanningFilter(){
    const select=$('[data-dplm-planning]');
    const opts=['<option value="">Tous les plannings</option>'].concat(((state.config?.plannings)||[]).map(p=>`<option value="${esc(p.id)}">${esc(p.label||p.id)}</option>`));
    select.innerHTML=opts.join('');
    select.value=state.selectedPlanning;
}
function renderStatusOptions(select,value){
    if(!select)return;
    select.innerHTML=((state.config?.statuses)||[]).map(s=>`<option value="${esc(s.id)}">${esc(s.label||s.id)}</option>`).join('');
    if(value)select.value=value;
}
function renderCategoryOptions(value){
    const select=$('[data-dplm-category]');
    const opts=((state.config?.categories)||[]).map(c=>{
        const parent=planningById(c.planning_id)?.label||c.planning_id||'Planning';
        return `<option value="${esc(c.id)}">${esc(parent)} · ${esc(c.label||c.id)}</option>`;
    });
    select.innerHTML=opts.join('');
    if(value)select.value=value;
    if(!select.value&&opts.length)select.value=((state.config?.categories)||[0])[0]?.id||'';
    renderCustomFields();
}
function filteredEvents(){
    const q=state.query.trim().toLowerCase();
    return state.events.filter(event=>{
        if(state.selectedPlanning&&event.planning_id!==state.selectedPlanning)return false;
        if(!q)return true;
        const hay=[event.title,event.notes,event.date,event.start_time,event.end_time,planningLabel(event),categoryLabel(event),statusLabel(event),JSON.stringify(event.fields||{})].join(' ').toLowerCase();
        return hay.includes(q);
    });
}
function updateSummary(allEvents,shownEvents){
    const now=today();
    const wkStart=startWeek(now), wkEnd=endWeek(now), moStart=startMonth(now), moEnd=endMonth(now);
    const asDate=(v)=>parseDate(v);
    const countIn=(from,to)=>allEvents.filter(e=>{const d=asDate(e.date);return d>=from&&d<=to;}).length;
    $('[data-dplm-stat-today]').textContent=String(countIn(now,now));
    $('[data-dplm-stat-week]').textContent=String(countIn(wkStart,wkEnd));
    $('[data-dplm-stat-month]').textContent=String(countIn(moStart,moEnd));
    $('[data-dplm-stat-total]').textContent=String(shownEvents.length);
}
function renderPeriod(){
    $('[data-dplm-period]').textContent=periodLabel();
    $$('[data-dplm-view]').forEach(btn=>btn.classList.toggle('is-active',btn.dataset.dplmView===state.view));
}
function groupEvents(events){
    const map=new Map();
    events.forEach(event=>{
        const key=String(event.date||'');
        if(!map.has(key))map.set(key,[]);
        map.get(key).push(event);
    });
    return Array.from(map.entries()).sort((a,b)=>a[0].localeCompare(b[0])).map(([key,list])=>({
        key,
        label:dateLabel(key),
        items:list.sort((a,b)=>{
            const ak=(a.all_day?'00:00':(a.start_time||''))+' '+(a.title||'');
            const bk=(b.all_day?'00:00':(b.start_time||''))+' '+(b.title||'');
            return ak.localeCompare(bk);
        })
    }));
}
function renderEvents(){
    const host=$('[data-dplm-groups]');
    const shown=filteredEvents();
    updateSummary(state.events,shown);
    if(!shown.length){
        host.innerHTML='<div class="dplm-empty">Aucun rendez-vous à afficher sur cette période.</div>';
        return;
    }
    const groups=groupEvents(shown);
    host.innerHTML=groups.map(group=>`
        <article class="dplm-group">
            <header class="dplm-group-head">
                <strong>${esc(group.label)}</strong>
                <span>${group.items.length} événement(s)</span>
            </header>
            <div class="dplm-list">
                ${group.items.map(event=>`
                    <article class="dplm-item" data-dplm-event="${esc(event.id)}">
                        <div class="dplm-item-color" style="background:${esc(categoryColor(event))}"></div>
                        <div class="dplm-item-main">
                            <div class="dplm-item-top">
                                <div class="dplm-item-title">${esc(event.title||'Sans titre')}</div>
                                <div class="dplm-item-time">${esc(timeLabel(event))}</div>
                            </div>
                            <div class="dplm-item-meta">
                                <span class="dplm-badge">${esc(planningLabel(event))}</span>
                                <span class="dplm-badge">${esc(categoryLabel(event))}</span>
                                <span class="dplm-badge"><i class="dplm-status-dot" style="background:${esc(statusColor(event))}"></i>${esc(statusLabel(event))}</span>
                            </div>
                            ${notePreview(event.notes)?`<div class="dplm-item-note">${esc(notePreview(event.notes))}</div>`:''}
                        </div>
                        <div class="dplm-item-arrow">›</div>
                    </article>
                `).join('')}
            </div>
        </article>
    `).join('');
}
function syncSubtitle(){
    const count=state.events.length;
    $('[data-dplm-subtitle]').textContent=`${periodLabel()} · ${count} événement(s)`;
}
function toRangeFetchWindow(){
    const range=rangeForView();
    const todayDate=today();
    const monthStart=startMonth(todayDate), monthEnd=endMonth(todayDate);
    const from=range.from<monthStart?range.from:monthStart;
    const to=range.to>monthEnd?range.to:monthEnd;
    return {from:dateKey(from),to:dateKey(to),focusFrom:dateKey(range.from),focusTo:dateKey(range.to)};
}
async function load(){
    renderPeriod();
    const win=toRangeFetchWindow();
    const data=await get('events_list',{from:win.from,to:win.to});
    const focusFrom=parseDate(win.focusFrom), focusTo=parseDate(win.focusTo);
    state.events=(data.events||[]).filter(e=>{
        const d=parseDate(e.date);
        return d>=focusFrom&&d<=focusTo;
    });
    syncSubtitle();
    renderEvents();
}
function setLoading(text){
    $('[data-dplm-groups]').innerHTML=`<div class="dplm-loading">${esc(text||'Chargement…')}</div>`;
}
function navigate(delta){
    if(state.view==='day')state.cursor=addDays(state.cursor,delta);
    else if(state.view==='week')state.cursor=addDays(state.cursor,delta*7);
    else state.cursor=new Date(state.cursor.getFullYear(),state.cursor.getMonth()+delta,1,12);
    refresh();
}
async function refresh(){
    try{
        setLoading('Chargement du planning…');
        await load();
    }catch(error){
        $('[data-dplm-groups]').innerHTML=`<div class="dplm-empty">${esc(error.message)}</div>`;
        $('[data-dplm-subtitle]').textContent='Erreur de chargement';
    }
}
function currentEvent(id){
    return state.events.find(e=>e.id===id)||null;
}
function detailBody(event){
    const fields=event.fields&&typeof event.fields==='object'?Object.entries(event.fields).filter(([,v])=>String(v??'')!==''):[];
    const resources=Array.isArray(event.resources)?event.resources:[];
    return `
    <div class="dplm-detail-grid">
        <section class="dplm-detail-block">
            <h4>Informations</h4>
            <div class="dplm-detail-list">
                <div class="dplm-detail-row"><span>Date</span><strong>${esc(dateLabel(event.date))}</strong></div>
                <div class="dplm-detail-row"><span>Heure</span><strong>${esc(timeLabel(event))}</strong></div>
                <div class="dplm-detail-row"><span>Planning</span><strong>${esc(planningLabel(event))}</strong></div>
                <div class="dplm-detail-row"><span>Catégorie</span><strong>${esc(categoryLabel(event))}</strong></div>
                <div class="dplm-detail-row"><span>Statut</span><strong>${esc(statusLabel(event))}</strong></div>
                <div class="dplm-detail-row"><span>Propriétaire</span><strong>${esc(event.owner||'—')}</strong></div>
            </div>
        </section>
        ${notePreview(event.notes)?`<section class="dplm-detail-block"><h4>Notes</h4><div class="dplm-item-note" style="display:block;-webkit-line-clamp:unset">${esc(event.notes)}</div></section>`:''}
        ${fields.length?`<section class="dplm-detail-block"><h4>Champs métier</h4><div class="dplm-detail-list">${fields.map(([k,v])=>`<div class="dplm-detail-row"><span>${esc(fieldLabel(event.category_id,k))}</span><strong>${esc(formatFieldValue(v))}</strong></div>`).join('')}</div></section>`:''}
        ${resources.length?`<section class="dplm-detail-block"><h4>Ressources liées</h4><div class="dplm-detail-list">${resources.map(r=>`<div class="dplm-detail-row"><span>${esc(r.type||'Ressource')}</span><strong>${esc(r.label||r.id||'')}</strong></div>`).join('')}</div></section>`:''}
    </div>`;
}
function fieldDefs(categoryId){
    return (categoryById(categoryId)?.fields)||[];
}
function fieldLabel(categoryId,id){
    const def=fieldDefs(categoryId).find(x=>x.id===id);
    return def?.label||id;
}
function formatFieldValue(v){
    if(v===true)return 'Oui';
    if(v===false)return 'Non';
    return String(v??'');
}
function openDetail(id){
    const event=currentEvent(id);
    if(!event)return;
    state.activeEvent=event;
    $('[data-dplm-detail-title]').textContent=event.title||'Événement';
    $('[data-dplm-detail-subtitle]').textContent=`${dateLabel(event.date)} · ${timeLabel(event)}`;
    $('[data-dplm-detail-body]').innerHTML=detailBody(event);
    renderStatusOptions($('[data-dplm-detail-status]'),event.status);
    $('[data-dplm-edit]').disabled=!(state.permissions['event.edit.all']|| (state.permissions['event.edit']&&event.owner===state.user));
    $('[data-dplm-delete]').disabled=!(state.permissions['event.delete.all']|| (state.permissions['event.delete']&&event.owner===state.user));
    $('[data-dplm-status-apply]').disabled=!state.permissions['event.status'];
    $('[data-dplm-detail]').hidden=false;
}
function closeDetail(){ $('[data-dplm-detail]').hidden=true; state.activeEvent=null; }
function renderCustomFields(values){
    const categoryId=$('[data-dplm-category]').value||'';
    const defs=fieldDefs(categoryId);
    const host=$('[data-dplm-custom-fields]');
    if(!defs.length){ host.innerHTML=''; return; }
    host.innerHTML=`<div class="dplm-custom-group"><strong>Champs métier</strong><div class="dplm-grid">${defs.map(def=>customFieldHtml(def)).join('')}</div></div>`;
    defs.forEach(def=>{
        const name=`field_${def.id}`;
        const el=host.querySelector(`[name="${CSS.escape(name)}"]`);
        if(!el)return;
        const val=values&&Object.prototype.hasOwnProperty.call(values,def.id)?values[def.id]:'';
        if(def.type==='checkbox')el.checked=!!val;
        else el.value=val==null?'':String(val);
    });
}
function customFieldHtml(def){
    const name=`field_${def.id}`;
    const label=esc(def.label||def.id);
    const required=def.required?' required':'';
    const type=String(def.type||'text');
    if(type==='textarea')return `<label class="dplm-field dplm-col-2"><span>${label}</span><textarea name="${esc(name)}"${required}></textarea></label>`;
    if(type==='select')return `<label class="dplm-field"><span>${label}</span><select name="${esc(name)}"${required}><option value="">Choisir…</option>${(def.options||[]).map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('')}</select></label>`;
    if(type==='checkbox')return `<label class="dplm-check"><span>${label}</span><input type="checkbox" name="${esc(name)}"></label>`;
    const inputType=['email','number','date','tel'].includes(type)?type:'text';
    return `<label class="dplm-field"><span>${label}</span><input type="${esc(inputType)}" name="${esc(name)}"${required}></label>`;
}
function updateTimeVisibility(){
    const allDay=$('[name="all_day"]').checked;
    $$('.dplm-time-field').forEach(x=>x.hidden=allDay);
}
function openEditor(event){
    const form=$('[data-dplm-form]');
    form.reset();
    $('[data-dplm-form-error]').hidden=true;
    $('[data-dplm-form-error]').textContent='';
    $('[data-dplm-form-title]').textContent=event?'Modifier le rendez-vous':'Nouveau rendez-vous';
    renderCategoryOptions(event?.category_id||'');
    renderStatusOptions(form.elements.status,event?.status||((state.config?.statuses||[])[0]?.id||''));
    form.elements.id.value=event?.id||'';
    form.elements.title.value=event?.title||'';
    form.elements.date.value=event?.date||dateKey(state.cursor);
    form.elements.all_day.checked=!!event?.all_day;
    form.elements.start_time.value=event?.start_time||'09:00';
    form.elements.end_time.value=event?.end_time||'10:00';
    form.elements.notes.value=event?.notes||'';
    renderCustomFields(event?.fields||{});
    updateTimeVisibility();
    $('[data-dplm-editor]').hidden=false;
}
function closeEditor(){ $('[data-dplm-editor]').hidden=true; }
function formPayload(){
    const form=$('[data-dplm-form]');
    const categoryId=form.elements.category_id.value;
    const defs=fieldDefs(categoryId);
    const fields={};
    defs.forEach(def=>{
        const name=`field_${def.id}`;
        const el=form.elements[name];
        if(!el)return;
        fields[def.id]=def.type==='checkbox'?!!el.checked:String(el.value||'');
    });
    return {
        id:form.elements.id.value||'',
        category_id:categoryId,
        title:form.elements.title.value||'',
        date:form.elements.date.value||'',
        all_day:!!form.elements.all_day.checked,
        start_time:form.elements.start_time.value||'',
        end_time:form.elements.end_time.value||'',
        status:form.elements.status.value||'',
        notes:form.elements.notes.value||'',
        fields:fields,
        reminders:[]
    };
}
async function saveForm(event){
    event.preventDefault();
    const form=$('[data-dplm-form]');
    const errorBox=$('[data-dplm-form-error]');
    errorBox.hidden=true;
    errorBox.textContent='';
    const saveBtn=$('[data-dplm-save]');
    saveBtn.disabled=true;
    try{
        await post('event_save',formPayload());
        closeEditor();
        await refresh();
        if(state.activeEvent) closeDetail();
    }catch(error){
        errorBox.textContent=error.message;
        errorBox.hidden=false;
    }finally{
        saveBtn.disabled=false;
    }
}
async function applyStatus(){
    if(!state.activeEvent)return;
    const btn=$('[data-dplm-status-apply]');
    btn.disabled=true;
    try{
        await post('event_status',{id:state.activeEvent.id,status:$('[data-dplm-detail-status]').value});
        closeDetail();
        await refresh();
    }catch(error){
        alert(error.message);
    }finally{
        btn.disabled=false;
    }
}
async function quickSession(){
    if(!state.activeEvent)return;
    const btn=$('[data-dplm-qs]');
    btn.disabled=true;
    try{
        const res=await post('quicksession_add',{id:state.activeEvent.id});
        alert(res.message||'Événement ajouté à QuickSession.');
    }catch(error){
        alert(error.message);
    }finally{
        btn.disabled=false;
    }
}
async function removeEvent(){
    if(!state.activeEvent)return;
    if(!confirm('Supprimer définitivement ce rendez-vous ?'))return;
    const btn=$('[data-dplm-delete]');
    btn.disabled=true;
    try{
        await post('event_delete',{id:state.activeEvent.id});
        closeDetail();
        await refresh();
    }catch(error){
        alert(error.message);
    }finally{
        btn.disabled=false;
    }
}
function bind(){
    $('[data-dplm-refresh]').addEventListener('click',refresh);
    $('[data-dplm-today]').addEventListener('click',()=>{state.cursor=today();refresh();});
    $('[data-dplm-prev]').addEventListener('click',()=>navigate(-1));
    $('[data-dplm-next]').addEventListener('click',()=>navigate(1));
    $$('[data-dplm-view]').forEach(btn=>btn.addEventListener('click',()=>{state.view=btn.dataset.dplmView;refresh();}));
    $('[data-dplm-planning]').addEventListener('change',e=>{state.selectedPlanning=e.target.value;renderEvents();});
    $('[data-dplm-search]').addEventListener('input',e=>{state.query=e.target.value||'';renderEvents();});
    $('[data-dplm-groups]').addEventListener('click',e=>{const item=e.target.closest('[data-dplm-event]');if(item)openDetail(item.dataset.dplmEvent);});
    $('[data-dplm-detail-close]').addEventListener('click',closeDetail);
    $('[data-dplm-detail]').addEventListener('click',e=>{if(e.target===e.currentTarget)closeDetail();});
    $('[data-dplm-editor]').addEventListener('click',e=>{if(e.target===e.currentTarget)closeEditor();});
    $('[data-dplm-new]').addEventListener('click',()=>openEditor(null));
    $('[data-dplm-edit]').addEventListener('click',()=>{if(state.activeEvent){const ev=state.activeEvent;closeDetail();openEditor(ev);}});
    $('[data-dplm-editor-close]').addEventListener('click',closeEditor);
    $('[data-dplm-editor-close-2]').addEventListener('click',closeEditor);
    $('[data-dplm-form]').addEventListener('submit',saveForm);
    $('[data-dplm-category]').addEventListener('change',()=>renderCustomFields());
    $('[data-dplm-all-day]').addEventListener('change',updateTimeVisibility);
    $('[data-dplm-status-apply]').addEventListener('click',applyStatus);
    $('[data-dplm-qs]').addEventListener('click',quickSession);
    $('[data-dplm-delete]').addEventListener('click',removeEvent);
}
async function bootstrap(){
    const data=await get('bootstrap');
    state.config=data.config||{};
    state.permissions=data.permissions||{};
    state.csrf=data.csrf||'';
    state.user=(data.user||'').toLowerCase();
    state.view=['day','week','month'].includes(state.config?.default_view)?state.config.default_view:'day';
    renderPlanningFilter();
    bind();
    await refresh();
}
bootstrap().catch(error=>{
    $('[data-dplm-subtitle]').textContent='Erreur';
    $('[data-dplm-groups]').innerHTML=`<div class="dplm-empty">${esc(error.message)}</div>`;
});
})();