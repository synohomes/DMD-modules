<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




declare(strict_types=1);
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo "DMD-Planning : exécution CLI uniquement.\n";
    exit(1);
}
require_once __DIR__ . '/dmd-planning_lib.php';
$config = dmd_planning_config();
if (!empty($config['timezone']) && in_array((string)$config['timezone'], timezone_identifiers_list(), true)) {
    date_default_timezone_set((string)$config['timezone']);
}
try {
    $result = dmd_planning_process_due_reminders(null, true);
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . PHP_EOL;
    exit(!empty($result['ok']) ? 0 : 2);
} catch (Throwable $e) {
    fwrite(STDERR, 'DMD-Planning : ' . $e->getMessage() . PHP_EOL);
    exit(2);
}
