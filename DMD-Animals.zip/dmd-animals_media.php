<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




require_once __DIR__ . '/dmd-animals_lib.php';
try {
    dmd_animals_require('module.view');
    dmd_animals_require('animal.view');
    dmd_animals_require('animal.media.view');

    $id = dmd_animals_valid_id($_GET['id'] ?? '');
    $aid = dmd_animals_valid_id($_GET['attachment'] ?? '');
    if (!$id || !$aid) throw new InvalidArgumentException('Identifiant invalide.');

    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    $attachment = dmd_animals_attachment($animal, $aid);
    if (!$attachment) throw new OutOfBoundsException('Fichier introuvable.');
    $path = dmd_animals_attachment_path($animal, $attachment);
    if ($path === '') throw new OutOfBoundsException('Fichier absent du stockage.');

    $mime = dmd_animals_detect_mime($path);
    $kind = (string)($attachment['kind'] ?? 'document');
    $isSafeImage = $kind === 'image' && dmd_animals_allowed_image_mime($mime);
    if ($kind === 'image' && !$isSafeImage) $mime = 'application/octet-stream';

    $previewRequested = !empty($_GET['preview']);
    $downloadRequested = !empty($_GET['download']);
    $legacyInline = !empty($_GET['inline']);
    $safePreviewMime = $isSafeImage || in_array($mime, array('application/pdf', 'text/plain', 'text/csv'), true);
    $inline = !$downloadRequested && (($previewRequested && $safePreviewMime) || ($legacyInline && $isSafeImage));

    $filename = str_replace(array('"', "\r", "\n"), '_', basename((string)($attachment['name'] ?? 'fichier')));
    header('Content-Type: ' . $mime . (strpos($mime, 'text/') === 0 ? '; charset=utf-8' : ''));
    header('Content-Length: ' . (string)filesize($path));
    header('Cache-Control: private, max-age=300');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $filename . '"');
    readfile($path);
    exit;
} catch (Throwable $e) {
    http_response_code(http_response_code() >= 400 ? http_response_code() : 404);
    header('Content-Type: text/plain; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo $e->getMessage();
}
