<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



require_once __DIR__ . '/dmd-animals_lib.php';

function dmd_animals_export_photo_data_uri($animal) {
    if (!dmd_animals_permission('animal.media.view') || !is_array($animal)) return '';
    $photoId = dmd_animals_valid_id($animal['photo_id'] ?? '');
    if (!$photoId) return '';
    $attachment = dmd_animals_attachment($animal, $photoId);
    if (!$attachment || ($attachment['kind'] ?? '') !== 'image') return '';
    $path = dmd_animals_attachment_path($animal, $attachment);
    if ($path === '' || !is_file($path)) return '';
    $mime = dmd_animals_detect_mime($path);
    if (!dmd_animals_allowed_image_mime($mime)) return '';
    $size = @filesize($path);
    if ($size === false || $size <= 0 || $size > 12 * 1024 * 1024) return '';
    $raw = @file_get_contents($path);
    if ($raw === false || $raw === '') return '';
    return 'data:' . $mime . ';base64,' . base64_encode($raw);
}

try {
    dmd_animals_require('module.view');
    dmd_animals_require('animal.view');
    dmd_animals_require('animal.export');
    dmd_animals_initialize();
    $id = dmd_animals_valid_id($_GET['id'] ?? '');
    $animals = $id ? array_filter(array(dmd_animals_load($id))) : array_map('dmd_animals_load', array_column(dmd_animals_all(true), 'id'));
    $animals = array_values(array_filter(array_map('dmd_animals_filter_animal_for_current_user', $animals)));
    $fields = array();
    foreach (dmd_animals_visible_fields() as $field) if (!empty($field['id'])) $fields[(string)$field['id']] = $field;
    $profiles = dmd_animals_profile_map();
    foreach ($animals as $animal) if ($animal) dmd_animals_event('animal.export', $animal, array('label'=>'Export fiche animale','target'=>$animal['name'],'status'=>'success','details'=>$id?'Export individuel.':'Export global.','activity'=>false));
} catch (Throwable $e) {
    http_response_code(http_response_code() >= 400 ? http_response_code() : 403);
    exit(dmd_animals_h($e->getMessage()));
}
?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DMD-Animals · Export</title>
<style>body{font-family:system-ui,sans-serif;margin:18px;color:#111;background:#fff;font-size:12px}.top{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:16px}.sheet{break-inside:avoid;border:1px solid #bbb;border-radius:10px;padding:14px;margin:0 0 14px}.sheet-head{display:grid;grid-template-columns:96px minmax(0,1fr);gap:12px;align-items:start}.sheet-head.no-photo{grid-template-columns:1fr}.animal-photo{width:96px;height:96px;object-fit:cover;border:1px solid #ccc;border-radius:9px}.animal-name{margin:0 0 8px;font-size:19px}.title{font-size:20px;margin:0}.meta{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px;margin:10px 0}.box{border:1px solid #ddd;border-radius:7px;padding:7px}.box small{display:block;color:#666}.sections{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.section{border-top:1px solid #ddd;padding-top:8px}.section h3{font-size:13px;margin:0 0 7px}.line{display:flex;justify-content:space-between;gap:8px;padding:3px 0;border-bottom:1px dotted #ddd}.note{white-space:pre-wrap}.print{padding:7px 10px}@media print{.print{display:none}body{margin:0}.sheet{border-color:#999}}@media(max-width:700px){.meta,.sections{grid-template-columns:1fr}.sheet-head{grid-template-columns:76px minmax(0,1fr)}.animal-photo{width:76px;height:76px}}</style></head><body>
<div class="top"><div><h1 class="title">DMD-Animals</h1><div><?= dmd_animals_h($id?'Fiche individuelle':'Export global') ?> · <?= dmd_animals_h(date('d/m/Y H:i')) ?></div></div><button class="print" onclick="window.print()">Imprimer / PDF</button></div>
<?php foreach($animals as $animal): if(!$animal)continue;$profile=$profiles[$animal['profile_id']??'']??array();$sections=array();foreach((array)($profile['fields']??array()) as $fid){if(!isset($fields[$fid]))continue;$def=$fields[$fid];$val=$animal['fields'][$fid]??'';if($val===''||$val===null||$val===false)continue;$section=(string)($def['section']??'Autres');$sections[$section][]=array($def,$val);}$photoUri=dmd_animals_export_photo_data_uri($animal); ?>
<article class="sheet"><div class="sheet-head<?= $photoUri===''?' no-photo':'' ?>"><?php if($photoUri!==''):?><img class="animal-photo" src="<?= dmd_animals_h($photoUri) ?>" alt="Photo de <?= dmd_animals_h($animal['name']??'animal') ?>"><?php endif;?><div><h2 class="animal-name"><?= dmd_animals_h($animal['name']??'Sans nom') ?></h2><div class="meta"><div class="box"><small>Espèce</small><?= dmd_animals_h($animal['species']??'—') ?></div><div class="box"><small>Race</small><?= dmd_animals_h($animal['breed']??'—') ?></div><div class="box"><small>Statut</small><?= dmd_animals_h($animal['status']??'—') ?></div><div class="box"><small>Profil métier</small><?= dmd_animals_h($profile['label']??($animal['profile_id']??'—')) ?></div><div class="box"><small>Sexe</small><?= dmd_animals_h($animal['sex']??'—') ?></div><div class="box"><small>Naissance</small><?= dmd_animals_h($animal['birth_date']??'—') ?></div><div class="box"><small>Identification</small><?= dmd_animals_h($animal['identification']??'—') ?></div><div class="box"><small>Couleur</small><?= dmd_animals_h($animal['color']??'—') ?></div></div></div></div>
<?php if(!empty($animal['notes'])):?><div class="section"><h3>Notes</h3><div class="note"><?= dmd_animals_h($animal['notes']) ?></div></div><?php endif;?>
<div class="sections"><?php foreach($sections as $section=>$rows):?><section class="section"><h3><?= dmd_animals_h($section) ?></h3><?php foreach($rows as $row):?><div class="line"><span><?= dmd_animals_h($row[0]['label']??'Champ') ?></span><strong><?= dmd_animals_h(is_bool($row[1])?($row[1]?'Oui':'Non'):$row[1]) ?></strong></div><?php endforeach;?></section><?php endforeach;?></div>
<?php if(dmd_animals_permission('animal.reminder.view')&&!empty($animal['reminders'])):?><section class="section"><h3>Rappels</h3><?php foreach($animal['reminders'] as $r):?><div class="line"><span><?= dmd_animals_h(($r['date']??'').' · '.($r['title']??'')) ?></span><strong><?= !empty($r['done'])?'Terminé':'À faire' ?></strong></div><?php endforeach;?></section><?php endif;?>
<?php if(dmd_animals_permission('animal.history.view')&&!empty($animal['history'])):?><section class="section"><h3>Historique</h3><?php foreach(array_reverse($animal['history']) as $r):?><div class="line"><span><?= dmd_animals_h(($r['date']??'').' · '.($r['type']??'').' · '.($r['title']??'')) ?></span><span><?= dmd_animals_h($r['note']??'') ?></span></div><?php endforeach;?></section><?php endif;?></article><?php endforeach;?></body></html>
