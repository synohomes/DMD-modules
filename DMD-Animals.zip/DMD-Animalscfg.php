<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



require_once __DIR__ . '/dmd-animals_lib.php';
$error='';try{dmd_animals_require('module.view');dmd_animals_require('config.view');dmd_animals_initialize();}catch(Throwable $e){$error=$e->getMessage();}
$base=dmd_animals_module_web_path();
?>
<link rel="stylesheet" href="<?= dmd_animals_h($base) ?>/dmd-animals.css?v=<?= dmd_animals_h(DMD_ANIMALS_VERSION) ?>">
<div class="dmd-animals" id="dmd-animals-cfg" data-api="<?= dmd_animals_h($base) ?>/dmd-animals_api.php">
<?php if($error!==''):?><div class="da-cfg"><div class="da-empty">⛔ <?= dmd_animals_h($error) ?></div></div><?php else:?>
<div class="da-cfg">
<header class="da-cfg-head"><div><h2>DMD-Animals · Configuration</h2><p>Profils métier, champs, taxonomies et comportement du registre système.</p></div><span class="da-pill">Stockage : /data/modules/DMD-Animals/</span></header>
<nav class="da-cfg-tabs"><button class="da-cfg-tab is-active" data-cfg-tab="general">Général</button><button class="da-cfg-tab" data-cfg-tab="profiles">Profils métier</button><button class="da-cfg-tab" data-cfg-tab="fields">Champs</button><button class="da-cfg-tab" data-cfg-tab="taxonomy">Taxonomies</button><button class="da-cfg-tab" data-cfg-tab="migration">Migration</button></nav>
<section class="da-cfg-pane" data-cfg-pane="general"><div class="da-cfg-card" data-general-pane><div class="da-loading">Chargement…</div></div></section>
<section class="da-cfg-pane" data-cfg-pane="profiles" hidden><div class="da-cfg-layout"><aside class="da-cfg-card"><h3>Profils métier</h3><div class="da-cfg-list" data-profile-list></div><div class="da-cfg-actions"><button type="button" data-new-profile>＋ Profil</button></div></aside><div class="da-cfg-card" data-profile-editor><div class="da-empty">Sélectionne un profil.</div></div></div></section>
<section class="da-cfg-pane" data-cfg-pane="fields" hidden><div class="da-cfg-layout"><aside class="da-cfg-card"><h3>Champs configurables</h3><div class="da-cfg-list" data-field-list></div><div class="da-cfg-actions"><button type="button" data-new-field>＋ Champ</button></div></aside><div class="da-cfg-card" data-field-editor><div class="da-empty">Sélectionne un champ.</div></div></div></section>
<section class="da-cfg-pane" data-cfg-pane="taxonomy" hidden><div class="da-cfg-card" data-taxonomy-pane><div class="da-loading">Chargement…</div></div></section>
<section class="da-cfg-pane" data-cfg-pane="migration" hidden><div class="da-cfg-card" data-migration-pane><div class="da-loading">Chargement…</div></div></section>
<div class="da-message" data-cfg-message role="status" aria-live="polite"></div>
</div>
<?php endif;?>
</div>
<?php if($error===''):?><script src="<?= dmd_animals_h($base) ?>/dmd-animals-cfg.js?v=<?= dmd_animals_h(DMD_ANIMALS_VERSION) ?>"></script><?php endif;?>
