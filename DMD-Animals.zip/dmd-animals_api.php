<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



require_once __DIR__ . '/dmd-animals_lib.php';

try {
    if (!dmd_animals_logged_in()) dmd_animals_json(array('ok'=>false,'error'=>'Connexion requise.'),401);
    dmd_animals_initialize();
    $action = strtolower(trim((string)($_POST['action'] ?? $_GET['action'] ?? '')));
    if ($action === '') dmd_animals_json(array('ok'=>false,'error'=>'Action manquante.'),400);

    if ($action === 'bootstrap') {
        dmd_animals_require('module.view'); dmd_animals_require('animal.view');
        $animals = array_map('dmd_animals_filter_summary_for_current_user', dmd_animals_all(!empty(dmd_animals_config()['show_archived'])));
        $permissions = array(
            'create'=>dmd_animals_permission('animal.create'),
            'identity_edit'=>dmd_animals_permission('animal.identity.edit'),
            'status_edit'=>dmd_animals_permission('animal.status.edit'),
            'health_view'=>dmd_animals_permission('animal.health.view'),'health_edit'=>dmd_animals_permission('animal.health.edit'),
            'contacts_view'=>dmd_animals_permission('animal.contacts.view'),'contacts_edit'=>dmd_animals_permission('animal.contacts.edit'),
            'professional_view'=>dmd_animals_permission('animal.professional.view'),'professional_edit'=>dmd_animals_permission('animal.professional.edit'),
            'delete'=>dmd_animals_permission('animal.delete'),'media_view'=>dmd_animals_permission('animal.media.view'),
            'media_add'=>dmd_animals_permission('animal.media.add'),'media_delete'=>dmd_animals_permission('animal.media.delete'),
            'history_view'=>dmd_animals_permission('animal.history.view'),'history_add'=>dmd_animals_permission('animal.history.add'),
            'history_delete'=>dmd_animals_permission('animal.history.delete'),'reminder_view'=>dmd_animals_permission('animal.reminder.view'),
            'reminder_manage'=>dmd_animals_permission('animal.reminder.manage'),'export'=>dmd_animals_permission('animal.export'),
            'config_view'=>dmd_animals_permission('config.view')
        );
        $permissions['edit_any'] = $permissions['identity_edit'] || $permissions['status_edit'] || $permissions['health_edit'] || $permissions['contacts_edit'] || $permissions['professional_edit'];
        dmd_animals_json(array(
            'ok'=>true,'animals'=>$animals,'stats'=>dmd_animals_stats($animals),
            'profiles'=>array_values(array_filter(dmd_animals_profiles(), static function($p){ return !empty($p['enabled']); })),
            'fields'=>dmd_animals_visible_fields(),'taxonomy'=>dmd_animals_taxonomy(),'config'=>dmd_animals_config(),
            'card_field_catalog'=>dmd_animals_card_field_catalog(),
            'permissions'=>$permissions,'csrf'=>dmd_animals_csrf_token()
        ));
    }

    if ($action === 'get') {
        dmd_animals_require('module.view'); dmd_animals_require('animal.view');
        $id = dmd_animals_valid_id($_GET['id'] ?? $_POST['id'] ?? '');
        $animal = $id ? dmd_animals_load($id) : null;
        if (!$animal) dmd_animals_json(array('ok'=>false,'error'=>'Animal introuvable.'),404);
        dmd_animals_event('animal.open',$animal,array('label'=>'Fiche animale consultée','target'=>$animal['name'],'status'=>'success','details'=>'Ouverture de la fiche système.'));
        dmd_animals_json(array('ok'=>true,'animal'=>dmd_animals_filter_animal_for_current_user($animal)));
    }

    if ($action === 'save') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view');
        $inputRaw = $_POST['payload'] ?? '';
        $input = is_array($inputRaw) ? $inputRaw : json_decode((string)$inputRaw, true);
        if (!is_array($input)) $input = $_POST;
        $id = dmd_animals_valid_id($input['id'] ?? $_POST['id'] ?? '');
        $existing = $id ? dmd_animals_load($id) : null;
        if (!$existing) {
            dmd_animals_require('animal.create');
            $fieldMap = dmd_animals_field_map();
            $incomingFields = is_array($input['fields'] ?? null) ? $input['fields'] : array();
            foreach ($incomingFields as $fieldId=>$value) {
                if (!isset($fieldMap[$fieldId])) continue;
                $normalizedValue = dmd_animals_normalize_field_value($fieldMap[$fieldId], $value);
                if (dmd_animals_required_value_empty($fieldMap[$fieldId], $normalizedValue)) continue;
                $permission = dmd_animals_field_edit_permission($fieldMap[$fieldId]);
                if (!dmd_animals_permission($permission)) throw new RuntimeException('Droit ' . $permission . ' requis pour renseigner « ' . (string)$fieldMap[$fieldId]['label'] . ' » à la création.');
            }
        }

        if ($existing) {
            dmd_animals_require('animal.view');
            $normalized = dmd_animals_clean_animal_input($input, $existing);
            $identityKeys = array('name','profile_id','species','breed','cross','sex','birth_date','death_date','identification','color','purpose','notes');
            foreach ($identityKeys as $key) {
                if (($existing[$key] ?? null) !== ($normalized[$key] ?? null) && !dmd_animals_permission('animal.identity.edit')) {
                    throw new RuntimeException('Droit animal.identity.edit requis pour modifier l’identité générale.');
                }
            }
            if (($existing['status'] ?? null) !== ($normalized['status'] ?? null) && !dmd_animals_permission('animal.status.edit')) {
                throw new RuntimeException('Droit animal.status.edit requis pour changer le statut.');
            }
            $fieldMap = dmd_animals_field_map();
            $incomingFields = is_array($input['fields'] ?? null) ? $input['fields'] : array();
            foreach ($incomingFields as $fieldId=>$value) {
                if (!isset($fieldMap[$fieldId])) continue;
                $beforeValue = $existing['fields'][$fieldId] ?? null;
                $afterValue = dmd_animals_normalize_field_value($fieldMap[$fieldId],$value);
                if ($beforeValue === $afterValue) continue;
                $permission = dmd_animals_field_edit_permission($fieldMap[$fieldId]);
                if (!dmd_animals_permission($permission)) throw new RuntimeException('Droit ' . $permission . ' requis pour modifier « ' . (string)$fieldMap[$fieldId]['label'] . ' ».');
            }
        }
        $animal = dmd_animals_save($input,$existing ? $id : null);
        dmd_animals_json(array(
            'ok'=>true,
            'animal'=>dmd_animals_filter_animal_for_current_user($animal),
            'summary'=>dmd_animals_filter_summary_for_current_user(dmd_animals_summary($animal)),
            'message'=>$existing?'Animal modifié.':'Animal créé.'
        ));
    }

    if ($action === 'delete') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_require('animal.delete');
        $id = dmd_animals_valid_id($_POST['id'] ?? ''); if(!$id)throw new InvalidArgumentException('Identifiant invalide.');
        dmd_animals_delete($id); dmd_animals_json(array('ok'=>true,'message'=>'Animal supprimé.'));
    }

    if ($action === 'attachment_add') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_require('animal.media.add');
        $id=dmd_animals_valid_id($_POST['id']??'');if(!$id)throw new InvalidArgumentException('Identifiant invalide.');
        if(empty($_FILES['file']))throw new InvalidArgumentException('Fichier manquant.');
        $result=dmd_animals_add_attachment($id,$_FILES['file'],$_POST['category']??'Autre');
        dmd_animals_json(array('ok'=>true,'animal'=>dmd_animals_filter_animal_for_current_user($result['animal']),'attachment'=>$result['attachment'],'message'=>'Fichier ajouté.'));
    }

    if ($action === 'attachment_delete') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_require('animal.media.delete');
        $id=dmd_animals_valid_id($_POST['id']??'');$aid=dmd_animals_valid_id($_POST['attachment_id']??'');if(!$id||!$aid)throw new InvalidArgumentException('Identifiant invalide.');
        $animal=dmd_animals_delete_attachment($id,$aid);dmd_animals_json(array('ok'=>true,'animal'=>dmd_animals_filter_animal_for_current_user($animal),'message'=>'Fichier supprimé.'));
    }

    if ($action === 'history_add') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_require('animal.history.add');
        $id=dmd_animals_valid_id($_POST['id']??'');if(!$id)throw new InvalidArgumentException('Identifiant invalide.');
        $result=dmd_animals_add_history($id,$_POST);dmd_animals_json(array('ok'=>true,'animal'=>dmd_animals_filter_animal_for_current_user($result['animal']),'history'=>$result['history'],'message'=>'Historique ajouté.'));
    }
    if ($action === 'history_delete') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_require('animal.history.delete');
        $id=dmd_animals_valid_id($_POST['id']??'');$hid=dmd_animals_valid_id($_POST['history_id']??'');if(!$id||!$hid)throw new InvalidArgumentException('Identifiant invalide.');
        $animal=dmd_animals_delete_history($id,$hid);dmd_animals_json(array('ok'=>true,'animal'=>dmd_animals_filter_animal_for_current_user($animal),'message'=>'Historique supprimé.'));
    }
    if ($action === 'reminder_add') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_require('animal.reminder.manage');
        $id=dmd_animals_valid_id($_POST['id']??'');if(!$id)throw new InvalidArgumentException('Identifiant invalide.');
        $result=dmd_animals_add_reminder($id,$_POST);dmd_animals_json(array('ok'=>true,'animal'=>dmd_animals_filter_animal_for_current_user($result['animal']),'reminder'=>$result['reminder'],'message'=>'Rappel ajouté.'));
    }
    if ($action === 'reminder_toggle') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_require('animal.reminder.manage');
        $id=dmd_animals_valid_id($_POST['id']??'');$rid=dmd_animals_valid_id($_POST['reminder_id']??'');if(!$id||!$rid)throw new InvalidArgumentException('Identifiant invalide.');
        $animal=dmd_animals_update_reminder($id,$rid,!empty($_POST['done']));dmd_animals_json(array('ok'=>true,'animal'=>dmd_animals_filter_animal_for_current_user($animal),'message'=>'Rappel mis à jour.'));
    }
    if ($action === 'reminder_delete') {
        dmd_animals_require_mutation(); dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_require('animal.reminder.manage');
        $id=dmd_animals_valid_id($_POST['id']??'');$rid=dmd_animals_valid_id($_POST['reminder_id']??'');if(!$id||!$rid)throw new InvalidArgumentException('Identifiant invalide.');
        $animal=dmd_animals_delete_reminder($id,$rid);dmd_animals_json(array('ok'=>true,'animal'=>dmd_animals_filter_animal_for_current_user($animal),'message'=>'Rappel supprimé.'));
    }

    if ($action === 'config_bootstrap') {
        dmd_animals_require('module.view'); dmd_animals_require('config.view');
        $migration = dmd_animals_read_json(dmd_animals_migration_marker_file(),array());
        dmd_animals_json(array('ok'=>true,'config'=>dmd_animals_config(),'taxonomy'=>dmd_animals_taxonomy(),'fields'=>dmd_animals_fields(),'profiles'=>dmd_animals_profiles(),'card_field_catalog'=>dmd_animals_card_field_catalog(),'migration'=>$migration,'csrf'=>dmd_animals_csrf_token(),'permissions'=>array('edit'=>dmd_animals_permission('config.edit'),'fields'=>dmd_animals_permission('config.fields'),'profiles'=>dmd_animals_permission('config.profiles'),'taxonomy'=>dmd_animals_permission('config.taxonomy'))));
    }

    if ($action === 'migration_run') {
        dmd_animals_require_mutation();dmd_animals_require('module.view');dmd_animals_require('config.edit');
        $migration=dmd_animals_migrate_legacy_once(true);
        dmd_animals_system_config_event('config.migration.run','Migration historique DMD-Animals relancée.',array());
        dmd_animals_json(array('ok'=>true,'migration'=>$migration,'message'=>'Migration relancée.'));
    }
    if ($action === 'config_save') {
        dmd_animals_require_mutation();dmd_animals_require('module.view');dmd_animals_require('config.edit');
        $result=dmd_animals_save_config($_POST);dmd_animals_system_config_event('config.update','Configuration générale modifiée.',dmd_animals_diff($result['before'],$result['after'],array('default_profile','card_fields','show_archived')));
        dmd_animals_json(array('ok'=>true,'config'=>$result['after'],'message'=>'Configuration enregistrée.'));
    }
    if ($action === 'taxonomy_save') {
        dmd_animals_require_mutation();dmd_animals_require('module.view');dmd_animals_require('config.taxonomy');
        $result=dmd_animals_save_taxonomy($_POST);dmd_animals_system_config_event('config.taxonomy.update','Taxonomies DMD-Animals modifiées.',dmd_animals_diff($result['before'],$result['after'],array('statuses','sexes','history_types','document_categories','species')));
        dmd_animals_json(array('ok'=>true,'taxonomy'=>$result['after'],'message'=>'Taxonomies enregistrées.'));
    }
    if ($action === 'field_save') {
        dmd_animals_require_mutation();dmd_animals_require('module.view');dmd_animals_require('config.fields');$beforeMap=dmd_animals_field_map();$candidateId=dmd_animals_slug($_POST['id']??$_POST['label']??'','');$beforeField=$candidateId!==''&&isset($beforeMap[$candidateId])?$beforeMap[$candidateId]:array();$field=dmd_animals_save_field($_POST);dmd_animals_system_config_event('config.field.save','Champ configuré : '.(string)$field['label'],dmd_animals_diff($beforeField,$field,array('label','type','section','access_group','required','options')));dmd_animals_json(array('ok'=>true,'field'=>$field,'fields'=>dmd_animals_fields(),'message'=>'Champ enregistré.'));
    }
    if ($action === 'field_delete') {
        dmd_animals_require_mutation();dmd_animals_require('module.view');dmd_animals_require('config.fields');$id=(string)($_POST['id']??'');$beforeField=dmd_animals_field_map()[dmd_animals_slug($id,'')]??array();dmd_animals_delete_field($id);dmd_animals_system_config_event('config.field.delete','Champ supprimé : '.$id,array(array('field'=>'field','label'=>(string)($beforeField['label']??$id),'before'=>$beforeField,'after'=>null)));dmd_animals_json(array('ok'=>true,'fields'=>dmd_animals_fields(),'profiles'=>dmd_animals_profiles(),'message'=>'Champ supprimé.'));
    }
    if ($action === 'profile_save') {
        dmd_animals_require_mutation();dmd_animals_require('module.view');dmd_animals_require('config.profiles');$beforeProfiles=dmd_animals_profile_map();$candidateId=dmd_animals_slug($_POST['id']??$_POST['label']??'','');$beforeProfile=$candidateId!==''&&isset($beforeProfiles[$candidateId])?$beforeProfiles[$candidateId]:array();$profile=dmd_animals_save_profile($_POST);dmd_animals_system_config_event('config.profile.save','Profil métier configuré : '.(string)$profile['label'],dmd_animals_diff($beforeProfile,$profile,array('label','description','enabled','fields')));dmd_animals_json(array('ok'=>true,'profile'=>$profile,'profiles'=>dmd_animals_profiles(),'message'=>'Profil enregistré.'));
    }
    if ($action === 'profile_delete') {
        dmd_animals_require_mutation();dmd_animals_require('module.view');dmd_animals_require('config.profiles');$id=(string)($_POST['id']??'');$beforeProfile=dmd_animals_profile_map()[dmd_animals_slug($id,'')]??array();dmd_animals_delete_profile($id);dmd_animals_system_config_event('config.profile.delete','Profil métier supprimé : '.$id,array(array('field'=>'profile','label'=>(string)($beforeProfile['label']??$id),'before'=>$beforeProfile,'after'=>null)));dmd_animals_json(array('ok'=>true,'profiles'=>dmd_animals_profiles(),'message'=>'Profil supprimé.'));
    }

    dmd_animals_json(array('ok'=>false,'error'=>'Action inconnue : '.$action),400);
} catch (Throwable $e) {
    $status=http_response_code();if($status<400)$status=400;
    dmd_animals_json(array('ok'=>false,'error'=>$e->getMessage()),$status);
}
