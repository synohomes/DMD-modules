<?php

/* * =====================================================================
                                DoMyDesk
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.

Vue DMD-MyDesk de DMD-Animals.
Cette vue charge explicitement le thème choisi par l'utilisateur DoMyDesk,
réutilise l'interface fonctionnelle du module et applique uniquement les
adaptations compactes nécessaires au WebView DMD-MyDesk.

* * ===================================================================== * */

if (session_status() === PHP_SESSION_NONE) @session_start();

require_once __DIR__ . '/dmd-animals_lib.php';

$email = dmd_animals_email();
$rootDir = dmd_animals_root();
$moduleBase = rtrim(dmd_animals_module_web_path(), '/');

/* Déduire la racine Web depuis /modules/DMD-Animals. */
$webRoot = preg_replace('~/modules/' . preg_quote(DMD_ANIMALS_ID, '~') . '/?$~', '', $moduleBase);
if (!is_string($webRoot)) $webRoot = '';
$webRoot = rtrim($webRoot, '/');

/* Même logique de sélection de thème que le Core DoMyDesk. */
$theme = 'default';
if ($email !== '') {
    $safeEmail = basename($email);
    $themeFile = $rootDir . '/users/profiles/' . $safeEmail . '/theme.json';
    if (is_file($themeFile)) {
        $themeData = json_decode((string)@file_get_contents($themeFile), true);
        if (is_array($themeData) && !empty($themeData['theme'])) {
            $candidate = basename((string)$themeData['theme']);
            if (is_file($rootDir . '/theme/' . $candidate . '/style.css')) {
                $theme = $candidate;
            }
        }
    }
}

$themeUrl = ($webRoot !== '' ? $webRoot : '') . '/theme/' . rawurlencode($theme) . '/style.css';
$userThemeCssUrl = ($webRoot !== '' ? $webRoot : '') . '/core/dmd_theme_user.css.php';
$myDeskCssVersion = is_file(__DIR__ . '/dmd-animals-mydesk.css')
    ? (string)filemtime(__DIR__ . '/dmd-animals-mydesk.css')
    : DMD_ANIMALS_VERSION;
?>
<link rel="stylesheet" href="<?= dmd_animals_h($themeUrl) ?>">
<link rel="stylesheet" href="<?= dmd_animals_h($userThemeCssUrl) ?>?v=<?= dmd_animals_h($myDeskCssVersion) ?>">
<?php require __DIR__ . '/DMD-Animals.php'; ?>
<link rel="stylesheet" href="<?= dmd_animals_h($moduleBase) ?>/dmd-animals-mydesk.css?v=<?= dmd_animals_h($myDeskCssVersion) ?>">
<script>
(() => {
    const variableNames = [
        '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg',
        '--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft',
        '--border-color','--danger-color','--success-color','--warning-color','--shadow-color',
        '--radius-sm','--radius','--radius-lg','--font-family','--dmd-ui-scale','--dmd-ui-scale-factor',
        '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow',
        '--dmdm-background-bg','--dmdm-front-bg','--dmdm-surface-bg','--dmdm-input-bg',
        '--dmdm-text-color','--dmdm-muted-color','--dmdm-title-color','--dmdm-primary-color',
        '--dmdm-primary-dark','--dmdm-primary-soft','--dmdm-border-color','--dmdm-danger-color',
        '--dmdm-success-color','--dmdm-warning-color','--dmdm-shadow-color',
        '--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
    ];

    function sourceWindow() {
        const candidates = [];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}
        for (const candidate of candidates) {
            try {
                if (candidate.document && candidate.location.origin === window.location.origin) return candidate;
            } catch (_) {}
        }
        return null;
    }

    function markHost() {
        document.documentElement.classList.add('dmd-animals-mydesk-host');
        if (document.body) document.body.classList.add('dmd-animals-mydesk-host');
        const root = document.getElementById('dmd-animals-root');
        if (root) root.classList.add('da-mydesk');
    }

    function syncTheme() {
        markHost();
        const source = sourceWindow();
        if (!source) return;
        const targets = [document.documentElement, document.body].filter(Boolean);
        const sources = [source.document.documentElement, source.document.body].filter(Boolean);

        for (const sourceRoot of sources) {
            const computed = source.getComputedStyle(sourceRoot);
            for (const name of variableNames) {
                const value = computed.getPropertyValue(name);
                if (value && value.trim()) {
                    for (const target of targets) target.style.setProperty(name, value.trim());
                }
            }
        }

        try {
            const bodyStyle = source.getComputedStyle(source.document.body);
            for (const target of targets) {
                if (bodyStyle.fontFamily) target.style.fontFamily = bodyStyle.fontFamily;
            }
        } catch (_) {}
    }

    markHost();
    syncTheme();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', syncTheme, {once:true});
    }
    window.addEventListener('load', syncTheme, {once:true});
})();
</script>
