<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if (session_status() === PHP_SESSION_NONE) @session_start();

if (!defined('DMD_ANIMALS_ID')) define('DMD_ANIMALS_ID', 'DMD-Animals');
if (!defined('DMD_ANIMALS_VERSION')) define('DMD_ANIMALS_VERSION', '2.0.6');

function dmd_animals_root() {
    $root = realpath(__DIR__ . '/../..');
    return $root !== false ? $root : dirname(__DIR__, 2);
}

function dmd_animals_boot_core() {
    $root = dmd_animals_root();
    foreach (array(
        $root . '/core/dmd_permissions.php',
        $root . '/core/dmd_security.php',
        $root . '/core/dmd_system_services.php',
        $root . '/core/dmd_activity.php',
        $root . '/core/dmd_module_logs.php',
        $root . '/core/dmd_module_events.php',
        $root . '/Quick-Session/dmd_quick_session.php',
        $root . '/core/dmd_quick_session.php'
    ) as $file) {
        if (is_file($file)) require_once $file;
    }
}

dmd_animals_boot_core();

function dmd_animals_h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_animals_clean($value, $max = 500) {
    $value = trim(is_scalar($value) ? (string)$value : '');
    $value = preg_replace('/\x00/u', '', $value);
    return function_exists('mb_substr') ? mb_substr($value, 0, (int)$max, 'UTF-8') : substr($value, 0, (int)$max);
}

function dmd_animals_email() {
    return trim((string)($_SESSION['user']['email'] ?? $_SESSION['email'] ?? $_SESSION['user_email'] ?? ''));
}

function dmd_animals_logged_in() {
    return filter_var(dmd_animals_email(), FILTER_VALIDATE_EMAIL) !== false;
}

function dmd_animals_module_web_path() {
    $doc = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? ''));
    $mod = realpath(__DIR__);
    if ($doc !== false && $mod !== false) {
        $docN = rtrim(str_replace('\\', '/', $doc), '/');
        $modN = rtrim(str_replace('\\', '/', $mod), '/');
        if ($docN !== '' && ($modN === $docN || strpos($modN, $docN . '/') === 0)) {
            return '/' . ltrim(substr($modN, strlen($docN)), '/');
        }
    }
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $pos = strpos($script, '/modules/' . DMD_ANIMALS_ID . '/');
    if ($pos !== false) return substr($script, 0, $pos) . '/modules/' . DMD_ANIMALS_ID;
    return '/domydesk/modules/' . rawurlencode(DMD_ANIMALS_ID);
}

function dmd_animals_storage_root($create = true) {
    $root = dmd_animals_root() . '/data/modules/' . DMD_ANIMALS_ID;
    if ($create && !is_dir($root)) @mkdir($root, 0750, true);
    if ($create && is_dir($root)) {
        @chmod($root, 0750);
        $ht = $root . '/.htaccess';
        if (!is_file($ht)) @file_put_contents($ht, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n", LOCK_EX);
        foreach (array('animals','backups','migration','legacy-repertoire') as $dir) {
            if (!is_dir($root . '/' . $dir)) @mkdir($root . '/' . $dir, 0750, true);
            @chmod($root . '/' . $dir, 0750);
        }
    }
    return $root;
}

function dmd_animals_atomic_write($path, $content, $mode = 0640) {
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Impossible de créer le stockage DMD-Animals.');
    $tmp = tempnam($dir, '.dmd-animals-');
    if ($tmp === false) throw new RuntimeException('Impossible de préparer l’écriture DMD-Animals.');
    try {
        if (@file_put_contents($tmp, $content, LOCK_EX) === false) throw new RuntimeException('Écriture DMD-Animals impossible.');
        @chmod($tmp, $mode);
        if (!@rename($tmp, $path)) {
            if (!@copy($tmp, $path)) throw new RuntimeException('Finalisation DMD-Animals impossible.');
            @unlink($tmp);
        }
        @chmod($path, $mode);
    } finally {
        if (is_file($tmp)) @unlink($tmp);
    }
}

function dmd_animals_read_json($path, $fallback = array()) {
    if (!is_file($path)) return $fallback;
    $raw = @file_get_contents($path);
    if (!is_string($raw) || trim($raw) === '') return $fallback;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
}

function dmd_animals_write_json($path, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) throw new RuntimeException('Encodage JSON DMD-Animals impossible.');
    dmd_animals_atomic_write($path, $json . "\n");
}

function dmd_animals_slug($value, $fallback = 'item') {
    $value = dmd_animals_clean($value, 160);
    if (function_exists('transliterator_transliterate')) {
        $converted = @transliterator_transliterate('Any-Latin; Latin-ASCII', $value);
        if (is_string($converted) && $converted !== '') $value = $converted;
    } elseif (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if (is_string($converted) && $converted !== '') $value = $converted;
    }
    $value = strtolower($value);
    $value = preg_replace('/[^a-z0-9._-]+/', '-', $value);
    $value = trim((string)$value, '-_.');
    return $value !== '' ? $value : $fallback;
}

function dmd_animals_valid_id($id) {
    $id = strtolower(trim((string)$id));
    return preg_match('/^[a-f0-9]{16}$/D', $id) ? $id : null;
}

function dmd_animals_new_id() {
    return bin2hex(random_bytes(8));
}

function dmd_animals_default_config() {
    return array(
        'default_profile' => 'particulier',
        'card_fields' => array('identification','birth_date'),
        'show_archived' => false,
        'migration_checked' => false,
        'updated_at' => date(DATE_ATOM)
    );
}

function dmd_animals_default_taxonomy() {
    return array(
        'species' => array(
            'Chien' => array('Berger allemand','Berger australien','Border Collie','Bouledogue français','Caniche','Husky','Labrador','Malinois','Golden Retriever','Shih Tzu'),
            'Chat' => array('Européen','Maine Coon','Siamois','Sacré de Birmanie','Persan','Bengal'),
            'Cheval / équidé' => array('Selle français','Pur-sang','Frison','Quarter Horse','Poney','Âne'),
            'Bovin' => array('Holstein','Charolaise','Limousine','Normande','Montbéliarde'),
            'Ovin' => array('Mérinos','Suffolk','Texel','Île-de-France'),
            'Caprin' => array('Alpine','Saanen','Poitevine','Naine'),
            'Porcin' => array('Large White','Landrace','Duroc','Nain'),
            'Volaille' => array('Poule','Canard','Oie','Dinde','Pintade'),
            'Lapin' => array('Nain','Bélier','Rex'),
            'Oiseau' => array(),
            'Reptile' => array(),
            'Poisson' => array(),
            'NAC' => array(),
            'Autre' => array()
        ),
        'statuses' => array('Vivant','Décédé','Disponible','Réservé','Adopté','Famille d’accueil','En soin','Quarantaine','Vendu','Perdu','Retrouvé','Archivé'),
        'sexes' => array('Mâle','Femelle','Inconnu'),
        'history_types' => array('Note','Santé','Vaccin','Traitement','Poids','Entrée','Sortie','Adoption','Reproduction','Naissance','Vente','Document','Autre'),
        'document_categories' => array('Photo principale','Photo','Photo médicale','Photo adoption','Photo avant / après','Document','Facture','Certificat','Contrat','Ordonnance','Passeport','LOF / LOOF','Assurance','Autre'),
        'updated_at' => date(DATE_ATOM)
    );
}

function dmd_animals_default_fields() {
    return array(
        array('id'=>'vet_name','label'=>'Vétérinaire','type'=>'text','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'vet_phone','label'=>'Téléphone vétérinaire','type'=>'phone','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'sterilized','label'=>'Stérilisé / castré','type'=>'checkbox','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'weight','label'=>'Poids','type'=>'number','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'food','label'=>'Alimentation','type'=>'textarea','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'allergies','label'=>'Allergies','type'=>'textarea','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'diseases','label'=>'Pathologies','type'=>'textarea','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'treatments','label'=>'Traitements','type'=>'textarea','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'vaccine_last','label'=>'Dernier vaccin','type'=>'date','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'vaccine_next','label'=>'Prochain vaccin','type'=>'date','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'worm_last','label'=>'Dernier vermifuge','type'=>'date','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'worm_next','label'=>'Prochain vermifuge','type'=>'date','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'flea_last','label'=>'Dernier antiparasitaire','type'=>'date','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'flea_next','label'=>'Prochain antiparasitaire','type'=>'date','section'=>'Santé','required'=>false,'options'=>array()),
        array('id'=>'owner','label'=>'Propriétaire / responsable','type'=>'text','section'=>'Contacts','required'=>false,'options'=>array()),
        array('id'=>'owner_phone','label'=>'Téléphone','type'=>'phone','section'=>'Contacts','required'=>false,'options'=>array()),
        array('id'=>'owner_email','label'=>'E-mail','type'=>'email','section'=>'Contacts','required'=>false,'options'=>array()),
        array('id'=>'insurance','label'=>'Assurance','type'=>'text','section'=>'Contacts','required'=>false,'options'=>array()),
        array('id'=>'petsitter','label'=>'Personne de garde','type'=>'text','section'=>'Contacts','required'=>false,'options'=>array()),
        array('id'=>'adoption_status','label'=>'Statut adoption','type'=>'text','section'=>'Refuge / adoption','required'=>false,'options'=>array()),
        array('id'=>'entry_date','label'=>'Date d’entrée','type'=>'date','section'=>'Refuge / adoption','required'=>false,'options'=>array()),
        array('id'=>'origin','label'=>'Provenance','type'=>'text','section'=>'Refuge / adoption','required'=>false,'options'=>array()),
        array('id'=>'foster_family','label'=>'Famille d’accueil','type'=>'text','section'=>'Refuge / adoption','required'=>false,'options'=>array()),
        array('id'=>'compat_dogs','label'=>'Compatible chiens','type'=>'select','section'=>'Refuge / adoption','required'=>false,'options'=>array('Oui','Non','À tester')),
        array('id'=>'compat_cats','label'=>'Compatible chats','type'=>'select','section'=>'Refuge / adoption','required'=>false,'options'=>array('Oui','Non','À tester')),
        array('id'=>'compat_children','label'=>'Compatible enfants','type'=>'select','section'=>'Refuge / adoption','required'=>false,'options'=>array('Oui','Non','À tester')),
        array('id'=>'housing','label'=>'Conditions de placement','type'=>'textarea','section'=>'Refuge / adoption','required'=>false,'options'=>array()),
        array('id'=>'adoption_notes','label'=>'Notes adoption','type'=>'textarea','section'=>'Refuge / adoption','required'=>false,'options'=>array()),
        array('id'=>'adopter','label'=>'Adoptant','type'=>'text','section'=>'Refuge / adoption','required'=>false,'options'=>array()),
        array('id'=>'adoption_date','label'=>'Date adoption','type'=>'date','section'=>'Refuge / adoption','required'=>false,'options'=>array()),
        array('id'=>'father','label'=>'Père','type'=>'text','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'mother','label'=>'Mère','type'=>'text','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'lineage','label'=>'Lignée','type'=>'text','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'litter','label'=>'Portée','type'=>'text','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'mating_date','label'=>'Date saillie','type'=>'date','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'expected_birth','label'=>'Naissance prévue','type'=>'date','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'birth_event_date','label'=>'Date mise bas','type'=>'date','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'offspring_count','label'=>'Nombre de petits','type'=>'number','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'reservation_status','label'=>'Statut réservation','type'=>'text','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'buyer','label'=>'Acquéreur','type'=>'text','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'sale_price','label'=>'Prix de cession','type'=>'number','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'departure_date','label'=>'Date de départ','type'=>'date','section'=>'Élevage / reproduction','required'=>false,'options'=>array()),
        array('id'=>'box_number','label'=>'Box / emplacement','type'=>'text','section'=>'Exploitation','required'=>false,'options'=>array()),
        array('id'=>'group_name','label'=>'Groupe / meute','type'=>'text','section'=>'Exploitation','required'=>false,'options'=>array()),
        array('id'=>'arrival_date','label'=>'Date d’arrivée','type'=>'date','section'=>'Exploitation','required'=>false,'options'=>array()),
        array('id'=>'departure_planned','label'=>'Départ prévu','type'=>'date','section'=>'Exploitation','required'=>false,'options'=>array()),
        array('id'=>'daily_rate','label'=>'Tarif / jour','type'=>'number','section'=>'Exploitation','required'=>false,'options'=>array()),
        array('id'=>'client_reference','label'=>'Référence client','type'=>'text','section'=>'Exploitation','required'=>false,'options'=>array())
    );
}

function dmd_animals_default_profiles() {
    $health = array('vet_name','vet_phone','sterilized','weight','food','allergies','diseases','treatments','vaccine_last','vaccine_next','worm_last','worm_next','flea_last','flea_next');
    $contacts = array('owner','owner_phone','owner_email','insurance','petsitter');
    $refuge = array('adoption_status','entry_date','origin','foster_family','compat_dogs','compat_cats','compat_children','housing','adoption_notes','adopter','adoption_date');
    $breeding = array('father','mother','lineage','litter','mating_date','expected_birth','birth_event_date','offspring_count','reservation_status','buyer','sale_price','departure_date');
    $operations = array('box_number','group_name','arrival_date','departure_planned','daily_rate','client_reference');
    return array(
        array('id'=>'particulier','label'=>'Particulier','description'=>'Suivi familial et santé courante.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$contacts)))),
        array('id'=>'refuge','label'=>'Refuge / SPA','description'=>'Entrées, compatibilités, familles d’accueil et adoption.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$contacts,$refuge,$operations)))),
        array('id'=>'eleveur','label'=>'Élevage','description'=>'Lignées, reproduction, portées, réservations et départs.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$contacts,$breeding,$operations)))),
        array('id'=>'pension','label'=>'Pension / garde','description'=>'Séjours, clients, box, alimentation, traitements et départs.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$contacts,$operations)))),
        array('id'=>'veterinaire','label'=>'Vétérinaire / soins','description'=>'Dossier de suivi clinique et coordonnées du responsable, sans imposer un logiciel médical externe.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$contacts)))),
        array('id'=>'toilettage','label'=>'Toilettage','description'=>'Clients, consignes, santé utile au rendez-vous et suivi des passages.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$contacts,$operations)))),
        array('id'=>'education','label'=>'Éducation / comportement','description'=>'Suivi du responsable, contexte, séances et observations personnalisables.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($contacts,$operations)))),
        array('id'=>'chenil','label'=>'Chenil / meute','description'=>'Gestion de groupes, emplacements, soins et mouvements.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$operations)))),
        array('id'=>'musher','label'=>'Musher / attelage','description'=>'Chiens de travail, groupes, rôles, soins, mouvements et suivi opérationnel.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$operations)))),
        array('id'=>'centre-equestre','label'=>'Centre équestre','description'=>'Équidés, propriétaires, soins, emplacements et mouvements.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$contacts,$operations)))),
        array('id'=>'ferme','label'=>'Ferme / exploitation','description'=>'Animaux d’exploitation, reproduction, mouvements et suivi personnalisé.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$breeding,$operations)))),
        array('id'=>'association','label'=>'Association / protection animale','description'=>'Prises en charge, familles d’accueil et placements.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$contacts,$refuge)))),
        array('id'=>'parc','label'=>'Parc animalier / sanctuaire','description'=>'Suivi de pensionnaires, groupes, soins, reproduction et historique.','enabled'=>true,'fields'=>array_values(array_unique(array_merge($health,$breeding,$operations))))
    );
}

function dmd_animals_config_file() { return dmd_animals_storage_root() . '/config.json'; }
function dmd_animals_taxonomy_file() { return dmd_animals_storage_root() . '/taxonomy.json'; }
function dmd_animals_fields_file() { return dmd_animals_storage_root() . '/fields.json'; }
function dmd_animals_profiles_file() { return dmd_animals_storage_root() . '/profiles.json'; }

function dmd_animals_config() {
    $file = dmd_animals_config_file();
    $cfg = array_replace(dmd_animals_default_config(), dmd_animals_read_json($file, array()));
    return $cfg;
}
function dmd_animals_taxonomy() {
    $file = dmd_animals_taxonomy_file();
    $data = dmd_animals_read_json($file, array());
    return $data ? $data : dmd_animals_default_taxonomy();
}
function dmd_animals_fields() {
    $file = dmd_animals_fields_file();
    $data = dmd_animals_read_json($file, array());
    $fields = $data ? array_values(array_filter($data, 'is_array')) : dmd_animals_default_fields();
    foreach ($fields as &$field) {
        if (!is_array($field)) continue;
        $group = strtolower(trim((string)($field['access_group'] ?? '')));
        if (!in_array($group, array('health','contacts','professional'), true)) {
            $section = strtolower((string)($field['section'] ?? ''));
            if (strpos($section, 'sant') !== false || strpos($section, 'health') !== false || strpos($section, 'soin') !== false || strpos($section, 'médic') !== false || strpos($section, 'medic') !== false || strpos($section, 'vét') !== false || strpos($section, 'vet') !== false) $group = 'health';
            elseif (strpos($section, 'contact') !== false || strpos($section, 'propri') !== false || strpos($section, 'client') !== false || strpos($section, 'adoptant') !== false) $group = 'contacts';
            else $group = 'professional';
        }
        $field['access_group'] = $group;
    }
    unset($field);
    return $fields;
}
function dmd_animals_profiles() {
    $file = dmd_animals_profiles_file();
    $data = dmd_animals_read_json($file, array());
    return $data ? array_values(array_filter($data, 'is_array')) : dmd_animals_default_profiles();
}

function dmd_animals_field_map() {
    $out = array();
    foreach (dmd_animals_fields() as $field) if (!empty($field['id'])) $out[(string)$field['id']] = $field;
    return $out;
}
function dmd_animals_profile_map() {
    $out = array();
    foreach (dmd_animals_profiles() as $profile) if (!empty($profile['id'])) $out[(string)$profile['id']] = $profile;
    return $out;
}

function dmd_animals_card_field_catalog() {
    $out = array(
        array('id'=>'identification','label'=>'Identification','section'=>'Fiche','source'=>'base'),
        array('id'=>'birth_date','label'=>'Date de naissance','section'=>'Fiche','source'=>'base'),
        array('id'=>'sex','label'=>'Sexe','section'=>'Fiche','source'=>'base'),
        array('id'=>'color','label'=>'Couleur / robe','section'=>'Fiche','source'=>'base'),
        array('id'=>'purpose','label'=>'Utilité / rôle','section'=>'Fiche','source'=>'base')
    );
    foreach (dmd_animals_fields() as $field) {
        if (empty($field['id'])) continue;
        $out[] = array(
            'id'=>(string)$field['id'],'label'=>(string)($field['label'] ?? $field['id']),
            'section'=>(string)($field['section'] ?? 'Autres'),'source'=>'dynamic'
        );
    }
    return $out;
}

function dmd_animals_field_permission_group($field) {
    if (is_array($field)) {
        $explicit = strtolower(trim((string)($field['access_group'] ?? '')));
        if (in_array($explicit, array('health','contacts','professional'), true)) return $explicit;
        $section = strtolower((string)($field['section'] ?? ''));
    } else {
        $section = strtolower((string)$field);
    }
    if (strpos($section, 'sant') !== false || strpos($section, 'health') !== false || strpos($section, 'soin') !== false || strpos($section, 'médic') !== false || strpos($section, 'medic') !== false || strpos($section, 'vét') !== false || strpos($section, 'vet') !== false) return 'health';
    if (strpos($section, 'contact') !== false || strpos($section, 'propri') !== false || strpos($section, 'client') !== false || strpos($section, 'adoptant') !== false) return 'contacts';
    return 'professional';
}

function dmd_animals_field_view_permission($field) {
    return 'animal.' . dmd_animals_field_permission_group($field) . '.view';
}

function dmd_animals_field_edit_permission($field) {
    return 'animal.' . dmd_animals_field_permission_group($field) . '.edit';
}

function dmd_animals_visible_fields() {
    $out = array();
    foreach (dmd_animals_fields() as $field) {
        if (dmd_animals_permission(dmd_animals_field_view_permission($field))) $out[] = $field;
    }
    return $out;
}

function dmd_animals_filter_animal_for_current_user($animal) {
    if (!is_array($animal)) return $animal;
    $fieldMap = dmd_animals_field_map();
    $visible = array();
    foreach ((array)($animal['fields'] ?? array()) as $id=>$value) {
        if (!isset($fieldMap[$id])) continue;
        if (dmd_animals_permission(dmd_animals_field_view_permission($fieldMap[$id]))) $visible[$id] = $value;
    }
    $animal['fields'] = $visible;
    if (!dmd_animals_permission('animal.history.view')) $animal['history'] = array();
    if (!dmd_animals_permission('animal.reminder.view')) $animal['reminders'] = array();
    if (!dmd_animals_permission('animal.media.view')) {
        $animal['attachments'] = array();
        $animal['photo_id'] = '';
    }
    unset($animal['legacy_raw'], $animal['legacy_source']);
    return $animal;
}

function dmd_animals_filter_summary_for_current_user($summary) {
    if (!is_array($summary)) return $summary;
    if (!dmd_animals_permission('animal.reminder.view')) $summary['reminders'] = array();
    if (!dmd_animals_permission('animal.media.view')) $summary['photo_id'] = '';
    $fieldMap = dmd_animals_field_map();
    foreach ((array)($summary['card_values'] ?? array()) as $id=>$value) {
        if (isset($fieldMap[$id]) && !dmd_animals_permission(dmd_animals_field_view_permission($fieldMap[$id]))) unset($summary['card_values'][$id]);
    }
    return $summary;
}

function dmd_animals_initialize() {
    $root = dmd_animals_storage_root();
    if (!is_file($root . '/config.json')) dmd_animals_write_json($root . '/config.json', dmd_animals_default_config());
    if (!is_file($root . '/taxonomy.json')) dmd_animals_write_json($root . '/taxonomy.json', dmd_animals_default_taxonomy());
    if (!is_file($root . '/fields.json')) dmd_animals_write_json($root . '/fields.json', dmd_animals_default_fields());
    if (!is_file($root . '/profiles.json')) dmd_animals_write_json($root . '/profiles.json', dmd_animals_default_profiles());
    dmd_animals_migrate_legacy_once();
}

function dmd_animals_permission($permission) {
    if (!dmd_animals_logged_in()) return false;
    dmd_animals_boot_core();
    if (!function_exists('dmd_current_user_has_module_permission')) return false;
    try { return (bool)dmd_current_user_has_module_permission(DMD_ANIMALS_ID, (string)$permission); }
    catch (Throwable $e) { return false; }
}

function dmd_animals_user_permission($email, $permission) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return false;
    dmd_animals_boot_core();
    if (!function_exists('dmd_user_has_module_permission')) return false;
    try { return (bool)dmd_user_has_module_permission($email, DMD_ANIMALS_ID, (string)$permission); }
    catch (Throwable $e) { return false; }
}

function dmd_animals_require($permission) {
    if (!dmd_animals_logged_in()) {
        http_response_code(401);
        throw new RuntimeException('Connexion requise.');
    }
    if (!dmd_animals_permission($permission)) {
        http_response_code(403);
        throw new RuntimeException('Accès refusé : ' . $permission . '.');
    }
}

function dmd_animals_csrf_token() {
    dmd_animals_boot_core();
    if (!function_exists('dmd_csrf_token')) throw new RuntimeException('Service CSRF DoMyDesk indisponible.');
    return dmd_csrf_token('dmd_animals');
}
function dmd_animals_validate_csrf($token) {
    dmd_animals_boot_core();
    if (!function_exists('dmd_csrf_validate')) return false;
    try { return (bool)dmd_csrf_validate((string)$token, 'dmd_animals'); }
    catch (Throwable $e) { return false; }
}
function dmd_animals_require_mutation() {
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
        http_response_code(405);
        throw new RuntimeException('Méthode HTTP refusée.');
    }
    $token = (string)($_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!dmd_animals_validate_csrf($token)) {
        http_response_code(403);
        throw new RuntimeException('Formulaire expiré ou CSRF invalide.');
    }
}

function dmd_animals_animal_dir($id, $create = false) {
    $id = dmd_animals_valid_id($id);
    if ($id === null) return '';
    $dir = dmd_animals_storage_root() . '/animals/' . $id;
    if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
    if ($create) {
        foreach (array('media','documents') as $sub) if (!is_dir($dir . '/' . $sub)) @mkdir($dir . '/' . $sub, 0750, true);
    }
    return $dir;
}
function dmd_animals_animal_file($id) {
    $dir = dmd_animals_animal_dir($id, false);
    return $dir !== '' ? $dir . '/info.json' : '';
}

function dmd_animals_load($id) {
    $file = dmd_animals_animal_file($id);
    if ($file === '' || !is_file($file)) return null;
    $data = dmd_animals_read_json($file, array());
    if (!$data) return null;
    $data['id'] = (string)$id;
    return $data;
}

function dmd_animals_summary($animal) {
    $animal = is_array($animal) ? $animal : array();
    $name = dmd_animals_clean($animal['name'] ?? $animal['prenom'] ?? 'Sans nom', 120);
    $profile = dmd_animals_clean($animal['profile_id'] ?? '', 80);
    $profileMap = dmd_animals_profile_map();
    $profileLabel = isset($profileMap[$profile]) ? (string)($profileMap[$profile]['label'] ?? $profile) : $profile;
    $cardValues = array();
    $fieldMap = dmd_animals_field_map();
    foreach ((array)(dmd_animals_config()['card_fields'] ?? array()) as $fieldId) {
        $fieldId = (string)$fieldId;
        if (array_key_exists($fieldId, $animal)) {
            $value = $animal[$fieldId];
            if ($value !== '' && $value !== null && $value !== false) $cardValues[$fieldId] = $value;
        } elseif (isset($fieldMap[$fieldId]) && array_key_exists($fieldId, (array)($animal['fields'] ?? array()))) {
            $value = $animal['fields'][$fieldId];
            if ($value !== '' && $value !== null && $value !== false) $cardValues[$fieldId] = $value;
        }
    }
    return array(
        'id'=>(string)($animal['id'] ?? ''),
        'name'=>$name !== '' ? $name : 'Sans nom',
        'species'=>(string)($animal['species'] ?? ''),
        'breed'=>(string)($animal['breed'] ?? ''),
        'sex'=>(string)($animal['sex'] ?? ''),
        'birth_date'=>(string)($animal['birth_date'] ?? ''),
        'status'=>(string)($animal['status'] ?? ''),
        'profile_id'=>$profile,
        'profile_label'=>$profileLabel,
        'identification'=>(string)($animal['identification'] ?? ''),
        'photo_id'=>(string)($animal['photo_id'] ?? ''),
        'reminders'=>is_array($animal['reminders'] ?? null) ? $animal['reminders'] : array(),
        'card_values'=>$cardValues,
        'updated_at'=>(string)($animal['updated_at'] ?? '')
    );
}
function dmd_animals_all($includeArchived = false) {
    dmd_animals_initialize();
    $out = array();
    $root = dmd_animals_storage_root() . '/animals';
    foreach (glob($root . '/*/info.json') ?: array() as $file) {
        $data = dmd_animals_read_json($file, array());
        if (!$data) continue;
        $id = basename(dirname($file));
        if (dmd_animals_valid_id($id) === null) continue;
        $data['id'] = $id;
        if (!$includeArchived && strcasecmp((string)($data['status'] ?? ''), 'Archivé') === 0) continue;
        $out[] = dmd_animals_summary($data);
    }
    usort($out, static function($a,$b){ return strcasecmp((string)$a['name'], (string)$b['name']); });
    return $out;
}

function dmd_animals_resource($animal) {
    $id = (string)($animal['id'] ?? '');
    $name = dmd_animals_clean($animal['name'] ?? $animal['prenom'] ?? 'Animal', 120);
    $tags = array('animal');
    foreach (array('species','profile_id','status') as $key) {
        $v = dmd_animals_clean($animal[$key] ?? '', 80);
        if ($v !== '') $tags[] = $v;
    }
    return array(
        'type'=>'animal',
        'id'=>DMD_ANIMALS_ID . ':animal:' . $id,
        'local_id'=>$id,
        'name'=>$name !== '' ? $name : 'Animal',
        'label'=>$name !== '' ? $name : 'Animal',
        'source'=>DMD_ANIMALS_ID,
        'module'=>DMD_ANIMALS_ID,
        'tags'=>array_values(array_unique($tags))
    );
}

function dmd_animals_event($action, $animal, $options = array()) {
    dmd_animals_boot_core();
    if (!function_exists('dmd_module_event')) throw new RuntimeException('Bus événementiel DoMyDesk indisponible.');
    $options = is_array($options) ? $options : array();
    $options['email'] = $options['email'] ?? dmd_animals_email();
    $options['scope'] = 'system';
    $result = dmd_module_event(DMD_ANIMALS_ID, (string)$action, dmd_animals_resource($animal), $options);
    if (!is_array($result) || empty($result['ok'])) throw new RuntimeException('Journalisation/activité Core impossible.');
    return $result;
}

function dmd_animals_diff($before, $after, $keys) {
    $changes = array();
    foreach ((array)$keys as $key) {
        $a = $before[$key] ?? null;
        $b = $after[$key] ?? null;
        if ($a !== $b) $changes[] = array('field'=>(string)$key,'before'=>$a,'after'=>$b);
    }
    return $changes;
}

function dmd_animals_animal_changes($before, $after) {
    $before = is_array($before) ? $before : array();
    $after = is_array($after) ? $after : array();
    $labels = array(
        'name'=>'Nom','profile_id'=>'Profil métier','species'=>'Espèce','breed'=>'Race','cross'=>'Croisement',
        'sex'=>'Sexe','birth_date'=>'Date de naissance','death_date'=>'Date de décès','status'=>'Statut',
        'identification'=>'Identification','color'=>'Couleur / robe','purpose'=>'Utilité / rôle','notes'=>'Notes générales'
    );
    $changes = array();
    foreach ($labels as $key=>$label) {
        $a = $before[$key] ?? null; $b = $after[$key] ?? null;
        if ($a !== $b) $changes[] = array('field'=>$key,'label'=>$label,'before'=>$a,'after'=>$b);
    }
    $fieldMap = dmd_animals_field_map();
    $beforeFields = is_array($before['fields'] ?? null) ? $before['fields'] : array();
    $afterFields = is_array($after['fields'] ?? null) ? $after['fields'] : array();
    foreach (array_values(array_unique(array_merge(array_keys($beforeFields),array_keys($afterFields)))) as $fieldId) {
        $a = $beforeFields[$fieldId] ?? null; $b = $afterFields[$fieldId] ?? null;
        if ($a === $b) continue;
        $def = $fieldMap[$fieldId] ?? array();
        $changes[] = array(
            'field'=>'fields.' . $fieldId,
            'label'=>(string)($def['label'] ?? $fieldId),
            'section'=>(string)($def['section'] ?? 'Autres'),
            'before'=>$a,'after'=>$b
        );
    }
    return $changes;
}

function dmd_animals_normalize_field_value($definition, $value) {
    $type = strtolower((string)($definition['type'] ?? 'text'));
    if ($type === 'checkbox') return !empty($value);
    if ($type === 'number') {
        $v = str_replace(',', '.', trim((string)$value));
        return $v === '' ? '' : (is_numeric($v) ? (float)$v : '');
    }
    if ($type === 'date') {
        $v = trim((string)$value);
        return preg_match('/^\d{4}-\d{2}-\d{2}$/D', $v) ? $v : '';
    }
    if ($type === 'email') {
        $v = dmd_animals_clean($value, 255);
        return $v === '' || filter_var($v, FILTER_VALIDATE_EMAIL) ? $v : '';
    }
    if ($type === 'url') {
        $v = dmd_animals_clean($value, 2048);
        if ($v === '') return '';
        $valid = filter_var($v, FILTER_VALIDATE_URL);
        $scheme = $valid ? strtolower((string)parse_url($v, PHP_URL_SCHEME)) : '';
        return $valid && in_array($scheme, array('http','https'), true) ? $v : '';
    }
    if ($type === 'select') {
        $v = dmd_animals_clean($value, 255);
        $options = array_map('strval', (array)($definition['options'] ?? array()));
        return !$options || in_array($v, $options, true) ? $v : '';
    }
    return dmd_animals_clean($value, $type === 'textarea' ? 10000 : 1000);
}

function dmd_animals_required_value_empty($definition, $value) {
    $type = strtolower((string)($definition['type'] ?? 'text'));
    if ($type === 'checkbox') return empty($value);
    if ($type === 'number') return $value === '' || $value === null;
    return trim(is_scalar($value) ? (string)$value : '') === '';
}

function dmd_animals_validate_required_fields($clean, $input, $existing = array()) {
    $profiles = dmd_animals_profile_map();
    $fieldMap = dmd_animals_field_map();
    $profileId = (string)($clean['profile_id'] ?? '');
    $profile = isset($profiles[$profileId]) && is_array($profiles[$profileId]) ? $profiles[$profileId] : array('fields'=>array());
    $incoming = is_array($input['fields'] ?? null) ? $input['fields'] : array();
    $existing = is_array($existing) ? $existing : array();
    $isCreate = empty($existing);
    $profileChanged = !$isCreate && (string)($existing['profile_id'] ?? '') !== $profileId;

    foreach ((array)($profile['fields'] ?? array()) as $fieldId) {
        $fieldId = (string)$fieldId;
        if (empty($fieldMap[$fieldId]) || empty($fieldMap[$fieldId]['required'])) continue;
        $definition = $fieldMap[$fieldId];
        $newValue = $clean['fields'][$fieldId] ?? null;
        $oldValue = $existing['fields'][$fieldId] ?? null;

        /* Les anciennes fiches incomplètes restent modifiables tant que ce champ
           obligatoire n'est pas touché et que le profil métier ne change pas. */
        $mustEnforce = $isCreate || $profileChanged || array_key_exists($fieldId, $incoming) || !dmd_animals_required_value_empty($definition, $oldValue);
        if ($mustEnforce && dmd_animals_required_value_empty($definition, $newValue)) {
            throw new InvalidArgumentException('Le champ « ' . (string)($definition['label'] ?? $fieldId) . ' » est obligatoire pour ce profil métier.');
        }
    }
}

function dmd_animals_clean_animal_input($input, $existing = array()) {
    $taxonomy = dmd_animals_taxonomy();
    $profiles = dmd_animals_profile_map();
    $fieldMap = dmd_animals_field_map();
    $existing = is_array($existing) ? $existing : array();

    $name = dmd_animals_clean($input['name'] ?? '', 120);
    if ($name === '') throw new InvalidArgumentException('Le nom de l’animal est obligatoire.');
    $profile = dmd_animals_slug($input['profile_id'] ?? dmd_animals_config()['default_profile'], 'particulier');
    if (!isset($profiles[$profile]) || empty($profiles[$profile]['enabled'])) throw new InvalidArgumentException('Profil métier invalide ou désactivé.');

    $species = dmd_animals_clean($input['species'] ?? '', 120);
    $breed = dmd_animals_clean($input['breed'] ?? '', 160);
    $sex = dmd_animals_clean($input['sex'] ?? '', 40);
    $status = dmd_animals_clean($input['status'] ?? 'Vivant', 80);
    if (!in_array($sex, (array)($taxonomy['sexes'] ?? array()), true)) $sex = '';
    if (!in_array($status, (array)($taxonomy['statuses'] ?? array()), true)) $status = (string)(($taxonomy['statuses'][0] ?? 'Vivant'));

    $fields = is_array($existing['fields'] ?? null) ? $existing['fields'] : array();
    $incomingFields = is_array($input['fields'] ?? null) ? $input['fields'] : array();
    foreach ($fieldMap as $id=>$definition) {
        if (array_key_exists($id, $incomingFields)) $fields[$id] = dmd_animals_normalize_field_value($definition, $incomingFields[$id]);
    }

    $clean = array(
        'name'=>$name,
        'profile_id'=>$profile,
        'species'=>$species,
        'breed'=>$breed,
        'cross'=>dmd_animals_clean($input['cross'] ?? '', 200),
        'sex'=>$sex,
        'birth_date'=>preg_match('/^\d{4}-\d{2}-\d{2}$/D', (string)($input['birth_date'] ?? '')) ? (string)$input['birth_date'] : '',
        'death_date'=>preg_match('/^\d{4}-\d{2}-\d{2}$/D', (string)($input['death_date'] ?? '')) ? (string)$input['death_date'] : '',
        'status'=>$status,
        'identification'=>dmd_animals_clean($input['identification'] ?? '', 255),
        'color'=>dmd_animals_clean($input['color'] ?? '', 160),
        'purpose'=>dmd_animals_clean($input['purpose'] ?? '', 255),
        'notes'=>dmd_animals_clean($input['notes'] ?? '', 12000),
        'fields'=>$fields
    );
    dmd_animals_validate_required_fields($clean, $input, $existing);
    return $clean;
}

function dmd_animals_save($input, $id = null) {
    dmd_animals_initialize();
    $isEdit = $id !== null && dmd_animals_valid_id($id) !== null;
    $before = $isEdit ? dmd_animals_load($id) : null;
    if ($isEdit && !$before) throw new OutOfBoundsException('Animal introuvable.');
    if (!$isEdit) $id = dmd_animals_new_id();
    $clean = dmd_animals_clean_animal_input($input, $before ?: array());
    $now = date(DATE_ATOM);
    $actor = dmd_animals_email();
    $animal = array_merge($before ?: array(), $clean);
    $animal['id'] = $id;
    $animal['history'] = is_array($animal['history'] ?? null) ? $animal['history'] : array();
    $animal['reminders'] = is_array($animal['reminders'] ?? null) ? $animal['reminders'] : array();
    $animal['attachments'] = is_array($animal['attachments'] ?? null) ? $animal['attachments'] : array();
    $animal['photo_id'] = (string)($animal['photo_id'] ?? '');
    if (!$isEdit) {
        $animal['created_at'] = $now;
        $animal['created_by'] = $actor;
    }
    $animal['updated_at'] = $now;
    $animal['updated_by'] = $actor;

    $changes = $isEdit ? dmd_animals_animal_changes($before, $animal) : array();
    dmd_animals_animal_dir($id, true);
    dmd_animals_write_json(dmd_animals_animal_file($id), $animal);
    dmd_animals_event($isEdit ? 'animal.update' : 'animal.create', $animal, array(
        'label'=>$isEdit ? 'Fiche animale modifiée' : 'Animal créé',
        'target'=>$animal['name'],
        'status'=>'success',
        'details'=>$isEdit ? 'Mise à jour de la fiche système.' : 'Nouvelle fiche système.',
        'changes'=>$changes,
        'meta'=>array('profile_id'=>$animal['profile_id'])
    ));
    return $animal;
}

function dmd_animals_delete($id) {
    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    $dir = dmd_animals_animal_dir($id, false);
    if (!dmd_animals_rrmdir($dir)) throw new RuntimeException('Suppression de la fiche système impossible.');
    dmd_animals_event('animal.delete', $animal, array('label'=>'Animal supprimé','target'=>$animal['name'],'status'=>'success','details'=>'Suppression de la fiche et de ses médias système.'));
    return true;
}

function dmd_animals_rrmdir($dir) {
    $real = realpath($dir);
    $base = realpath(dmd_animals_storage_root() . '/animals');
    if ($real === false || $base === false || strpos($real, rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) !== 0) return false;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($real, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $item) $item->isDir() ? @rmdir($item->getPathname()) : @unlink($item->getPathname());
    return @rmdir($real);
}

function dmd_animals_allowed_upload($name) {
    $ext = strtolower(pathinfo((string)$name, PATHINFO_EXTENSION));
    return in_array($ext, array('jpg','jpeg','png','webp','gif','pdf','txt','csv','doc','docx','xls','xlsx','odt','ods'), true);
}
function dmd_animals_is_image($name) { return (bool)preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', (string)$name); }

function dmd_animals_detect_mime($path) {
    if (!is_file($path)) return 'application/octet-stream';
    if (function_exists('finfo_open')) {
        $f = @finfo_open(FILEINFO_MIME_TYPE);
        if ($f) {
            $mime = @finfo_file($f, $path);
            @finfo_close($f);
            if (is_string($mime) && $mime !== '') return strtolower(trim($mime));
        }
    }
    return 'application/octet-stream';
}

function dmd_animals_allowed_image_mime($mime) {
    return in_array(strtolower((string)$mime), array('image/jpeg','image/png','image/gif','image/webp'), true);
}

function dmd_animals_add_attachment($id, $file, $category) {
    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    if (!is_array($file) || (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new InvalidArgumentException('Fichier invalide.');
    $name = dmd_animals_clean($file['name'] ?? 'fichier', 255);
    if ((int)($file['size'] ?? 0) > 25 * 1024 * 1024) throw new InvalidArgumentException('Fichier trop volumineux (25 Mo maximum).');
    if (!dmd_animals_allowed_upload($name)) throw new InvalidArgumentException('Type de fichier non autorisé.');
    $tmpName = (string)($file['tmp_name'] ?? '');
    if (!is_uploaded_file($tmpName)) throw new InvalidArgumentException('Téléversement invalide.');
    $detectedMime = dmd_animals_detect_mime($tmpName);
    if (dmd_animals_is_image($name) && !dmd_animals_allowed_image_mime($detectedMime)) {
        throw new InvalidArgumentException('Le fichier porte une extension image mais son contenu n’est pas une image autorisée.');
    }
    $taxonomy = dmd_animals_taxonomy();
    $category = dmd_animals_clean($category, 120);
    if (!in_array($category, (array)($taxonomy['document_categories'] ?? array()), true)) $category = 'Autre';
    $attachmentId = dmd_animals_new_id();
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $stored = $attachmentId . ($ext !== '' ? '.' . preg_replace('/[^a-z0-9]/', '', $ext) : '');
    $sub = dmd_animals_is_image($name) ? 'media' : 'documents';
    $dir = dmd_animals_animal_dir($id, true) . '/' . $sub;
    $dest = $dir . '/' . $stored;
    if (!@move_uploaded_file($tmpName, $dest)) throw new RuntimeException('Impossible d’enregistrer le fichier.');
    @chmod($dest, 0640);
    $row = array(
        'id'=>$attachmentId,'name'=>$name,'stored_name'=>$stored,'kind'=>$sub === 'media' ? 'image' : 'document',
        'category'=>$category,'mime'=>$detectedMime,'size'=>(int)($file['size'] ?? 0),
        'uploaded_at'=>date(DATE_ATOM),'uploaded_by'=>dmd_animals_email()
    );
    $animal['attachments'] = is_array($animal['attachments'] ?? null) ? $animal['attachments'] : array();
    $animal['attachments'][] = $row;
    if ($row['kind'] === 'image' && (empty($animal['photo_id']) || $category === 'Photo principale')) $animal['photo_id'] = $attachmentId;
    $animal['updated_at'] = date(DATE_ATOM);
    $animal['updated_by'] = dmd_animals_email();
    dmd_animals_write_json(dmd_animals_animal_file($id), $animal);
    dmd_animals_event('animal.media.add', $animal, array('label'=>'Fichier ajouté','target'=>$animal['name'],'status'=>'success','details'=>$name,'meta'=>array('attachment_id'=>$attachmentId,'category'=>$category)));
    return array('animal'=>$animal,'attachment'=>$row);
}

function dmd_animals_attachment($animal, $attachmentId) {
    foreach ((array)($animal['attachments'] ?? array()) as $attachment) {
        if (is_array($attachment) && hash_equals((string)($attachment['id'] ?? ''), (string)$attachmentId)) return $attachment;
    }
    return null;
}
function dmd_animals_attachment_path($animal, $attachment) {
    $id = dmd_animals_valid_id($animal['id'] ?? '');
    if ($id === null || !is_array($attachment)) return '';
    $kind = ($attachment['kind'] ?? '') === 'image' ? 'media' : 'documents';
    $stored = basename((string)($attachment['stored_name'] ?? ''));
    if ($stored === '') return '';
    $path = dmd_animals_animal_dir($id, false) . '/' . $kind . '/' . $stored;
    return is_file($path) ? $path : '';
}

function dmd_animals_delete_attachment($id, $attachmentId) {
    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    $new = array(); $removed = null;
    foreach ((array)($animal['attachments'] ?? array()) as $attachment) {
        if (is_array($attachment) && (string)($attachment['id'] ?? '') === (string)$attachmentId) { $removed = $attachment; continue; }
        $new[] = $attachment;
    }
    if (!$removed) throw new OutOfBoundsException('Fichier introuvable.');
    $path = dmd_animals_attachment_path($animal, $removed);
    if ($path !== '') @unlink($path);
    $animal['attachments'] = $new;
    if ((string)($animal['photo_id'] ?? '') === (string)$attachmentId) {
        $animal['photo_id'] = '';
        foreach ($new as $a) if (($a['kind'] ?? '') === 'image') { $animal['photo_id'] = (string)$a['id']; break; }
    }
    $animal['updated_at'] = date(DATE_ATOM); $animal['updated_by'] = dmd_animals_email();
    dmd_animals_write_json(dmd_animals_animal_file($id), $animal);
    dmd_animals_event('animal.media.delete', $animal, array('label'=>'Fichier supprimé','target'=>$animal['name'],'status'=>'success','details'=>(string)($removed['name'] ?? 'Fichier')));
    return $animal;
}

function dmd_animals_add_history($id, $input, $actorEmail = null) {
    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    $taxonomy = dmd_animals_taxonomy();
    $type = dmd_animals_clean($input['type'] ?? 'Note', 80);
    if (!in_array($type, (array)($taxonomy['history_types'] ?? array()), true)) $type = 'Autre';
    $title = dmd_animals_clean($input['title'] ?? '', 180);
    if ($title === '') throw new InvalidArgumentException('Titre d’historique obligatoire.');
    $date = (string)($input['date'] ?? date('Y-m-d'));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $date)) $date = date('Y-m-d');
    $row = array('id'=>dmd_animals_new_id(),'date'=>$date,'type'=>$type,'title'=>$title,'note'=>dmd_animals_clean($input['note'] ?? '', 6000),'created_at'=>date(DATE_ATOM),'created_by'=>$actorEmail ?: dmd_animals_email());
    $animal['history'] = is_array($animal['history'] ?? null) ? $animal['history'] : array();
    $animal['history'][] = $row;
    $animal['updated_at'] = date(DATE_ATOM); $animal['updated_by'] = $actorEmail ?: dmd_animals_email();
    dmd_animals_write_json(dmd_animals_animal_file($id), $animal);
    dmd_animals_event('animal.history.add', $animal, array('email'=>$actorEmail ?: dmd_animals_email(),'label'=>'Historique ajouté','target'=>$animal['name'],'status'=>'success','details'=>$type . ' · ' . $title,'meta'=>array('history_id'=>$row['id'])));
    return array('animal'=>$animal,'history'=>$row);
}

function dmd_animals_delete_history($id, $historyId) {
    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    $new = array(); $removed = null;
    foreach ((array)($animal['history'] ?? array()) as $row) {
        if (is_array($row) && (string)($row['id'] ?? '') === (string)$historyId) { $removed = $row; continue; }
        $new[] = $row;
    }
    if (!$removed) throw new OutOfBoundsException('Ligne d’historique introuvable.');
    $animal['history'] = $new; $animal['updated_at'] = date(DATE_ATOM); $animal['updated_by'] = dmd_animals_email();
    dmd_animals_write_json(dmd_animals_animal_file($id), $animal);
    dmd_animals_event('animal.history.delete', $animal, array('label'=>'Historique supprimé','target'=>$animal['name'],'status'=>'success','details'=>(string)($removed['title'] ?? 'Historique')));
    return $animal;
}

function dmd_animals_add_reminder($id, $input, $actorEmail = null) {
    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    $date = (string)($input['date'] ?? '');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $date)) throw new InvalidArgumentException('Date de rappel invalide.');
    $title = dmd_animals_clean($input['title'] ?? '', 180);
    if ($title === '') throw new InvalidArgumentException('Titre du rappel obligatoire.');
    $row = array('id'=>dmd_animals_new_id(),'date'=>$date,'title'=>$title,'note'=>dmd_animals_clean($input['note'] ?? '', 3000),'done'=>false,'created_at'=>date(DATE_ATOM),'created_by'=>$actorEmail ?: dmd_animals_email());
    $animal['reminders'] = is_array($animal['reminders'] ?? null) ? $animal['reminders'] : array();
    $animal['reminders'][] = $row;
    $animal['updated_at'] = date(DATE_ATOM); $animal['updated_by'] = $actorEmail ?: dmd_animals_email();
    dmd_animals_write_json(dmd_animals_animal_file($id), $animal);
    dmd_animals_event('animal.reminder.add', $animal, array('email'=>$actorEmail ?: dmd_animals_email(),'label'=>'Rappel ajouté','target'=>$animal['name'],'status'=>'success','details'=>$date . ' · ' . $title,'meta'=>array('reminder_id'=>$row['id'])));
    return array('animal'=>$animal,'reminder'=>$row);
}

function dmd_animals_update_reminder($id, $reminderId, $done) {
    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    $found = false;
    foreach ($animal['reminders'] as &$row) {
        if (is_array($row) && (string)($row['id'] ?? '') === (string)$reminderId) { $row['done'] = (bool)$done; $row['updated_at'] = date(DATE_ATOM); $found = true; break; }
    }
    unset($row);
    if (!$found) throw new OutOfBoundsException('Rappel introuvable.');
    $animal['updated_at'] = date(DATE_ATOM); $animal['updated_by'] = dmd_animals_email();
    dmd_animals_write_json(dmd_animals_animal_file($id), $animal);
    dmd_animals_event('animal.reminder.update', $animal, array('label'=>'Rappel mis à jour','target'=>$animal['name'],'status'=>'success','details'=>$done ? 'Rappel terminé.' : 'Rappel rouvert.'));
    return $animal;
}

function dmd_animals_delete_reminder($id, $reminderId) {
    $animal = dmd_animals_load($id);
    if (!$animal) throw new OutOfBoundsException('Animal introuvable.');
    $new = array(); $removed = null;
    foreach ((array)($animal['reminders'] ?? array()) as $row) {
        if (is_array($row) && (string)($row['id'] ?? '') === (string)$reminderId) { $removed = $row; continue; }
        $new[] = $row;
    }
    if (!$removed) throw new OutOfBoundsException('Rappel introuvable.');
    $animal['reminders'] = $new; $animal['updated_at'] = date(DATE_ATOM); $animal['updated_by'] = dmd_animals_email();
    dmd_animals_write_json(dmd_animals_animal_file($id), $animal);
    dmd_animals_event('animal.reminder.delete', $animal, array('label'=>'Rappel supprimé','target'=>$animal['name'],'status'=>'success','details'=>(string)($removed['title'] ?? 'Rappel')));
    return $animal;
}

function dmd_animals_save_config($payload) {
    $current = dmd_animals_config();
    $profiles = dmd_animals_profile_map();
    $default = dmd_animals_slug($payload['default_profile'] ?? $current['default_profile'], 'particulier');
    if (!isset($profiles[$default])) $default = (string)($current['default_profile'] ?? 'particulier');
    $card = array();
    $allowedCard = array(); foreach (dmd_animals_card_field_catalog() as $row) $allowedCard[(string)$row['id']] = true;
    foreach ((array)($payload['card_fields'] ?? array()) as $id) {
        $id = dmd_animals_slug($id, '');
        if ($id !== '' && isset($allowedCard[$id]) && !in_array($id, $card, true)) $card[] = $id;
        if (count($card) >= 4) break;
    }
    $next = array_replace($current, array('default_profile'=>$default,'card_fields'=>$card,'show_archived'=>!empty($payload['show_archived']),'updated_at'=>date(DATE_ATOM)));
    dmd_animals_write_json(dmd_animals_config_file(), $next);
    return array('before'=>$current,'after'=>$next);
}

function dmd_animals_save_taxonomy($payload) {
    $current = dmd_animals_taxonomy();
    $next = $current;
    foreach (array('statuses','sexes','history_types','document_categories') as $key) {
        if (isset($payload[$key])) {
            $raw = is_array($payload[$key]) ? $payload[$key] : preg_split('/\R+/', (string)$payload[$key]);
            $list = array();
            foreach ((array)$raw as $value) {
                $value = dmd_animals_clean($value, 120);
                if ($value !== '' && !in_array($value, $list, true)) $list[] = $value;
            }
            if ($list) $next[$key] = $list;
        }
    }
    if (isset($payload['species_json'])) {
        $decoded = json_decode((string)$payload['species_json'], true);
        if (is_array($decoded)) {
            $species = array();
            foreach ($decoded as $name=>$breeds) {
                $name = dmd_animals_clean($name, 120); if ($name === '') continue;
                $clean = array(); foreach ((array)$breeds as $breed) { $breed = dmd_animals_clean($breed, 160); if ($breed !== '' && !in_array($breed,$clean,true)) $clean[]=$breed; }
                $species[$name] = $clean;
            }
            if ($species) $next['species'] = $species;
        }
    }
    $next['updated_at'] = date(DATE_ATOM);
    dmd_animals_write_json(dmd_animals_taxonomy_file(), $next);
    return array('before'=>$current,'after'=>$next);
}

function dmd_animals_save_field($payload) {
    $fields = dmd_animals_fields();
    $rawId = dmd_animals_slug($payload['id'] ?? $payload['label'] ?? '', 'field');
    if ($rawId === '' || strlen($rawId) > 80) throw new InvalidArgumentException('Identifiant de champ invalide.');
    $type = strtolower(dmd_animals_clean($payload['type'] ?? 'text', 30));
    if (!in_array($type, array('text','textarea','number','date','select','checkbox','email','phone','url'), true)) throw new InvalidArgumentException('Type de champ invalide.');
    $label = dmd_animals_clean($payload['label'] ?? '', 120); if ($label === '') throw new InvalidArgumentException('Libellé obligatoire.');
    $section = dmd_animals_clean($payload['section'] ?? 'Autres', 120); if ($section === '') $section = 'Autres';
    $options = array();
    $rawOptions = $payload['options'] ?? array();
    if (!is_array($rawOptions)) $rawOptions = preg_split('/\R+/', (string)$rawOptions);
    foreach ((array)$rawOptions as $option) { $option=dmd_animals_clean($option,120); if($option!==''&&!in_array($option,$options,true))$options[]=$option; }
    $accessGroup = strtolower(dmd_animals_clean($payload['access_group'] ?? '', 30));
    if (!in_array($accessGroup, array('health','contacts','professional'), true)) {
        $accessGroup = dmd_animals_field_permission_group(array('section'=>$section));
    }
    $row = array('id'=>$rawId,'label'=>$label,'type'=>$type,'section'=>$section,'access_group'=>$accessGroup,'required'=>!empty($payload['required']),'options'=>$options,'updated_at'=>date(DATE_ATOM));
    $replaced = false;
    foreach ($fields as $i=>$field) if ((string)($field['id'] ?? '') === $rawId) { $fields[$i] = array_replace($field,$row); $replaced=true; break; }
    if (!$replaced) $fields[] = $row;
    dmd_animals_write_json(dmd_animals_fields_file(), array_values($fields));
    return $row;
}

function dmd_animals_delete_field($id) {
    $id = dmd_animals_slug($id, '');
    $fields = dmd_animals_fields(); $new = array(); $found = false;
    foreach ($fields as $field) { if ((string)($field['id'] ?? '') === $id) { $found=true; continue; } $new[]=$field; }
    if (!$found) throw new OutOfBoundsException('Champ introuvable.');
    dmd_animals_write_json(dmd_animals_fields_file(), $new);
    $profiles = dmd_animals_profiles();
    foreach ($profiles as &$profile) $profile['fields'] = array_values(array_diff((array)($profile['fields'] ?? array()), array($id)));
    unset($profile);
    dmd_animals_write_json(dmd_animals_profiles_file(), $profiles);
    return true;
}

function dmd_animals_save_profile($payload) {
    $profiles = dmd_animals_profiles();
    $id = dmd_animals_slug($payload['id'] ?? $payload['label'] ?? '', 'profil');
    $label = dmd_animals_clean($payload['label'] ?? '', 120); if ($label === '') throw new InvalidArgumentException('Nom du profil obligatoire.');
    $fieldMap = dmd_animals_field_map(); $selected = array();
    foreach ((array)($payload['fields'] ?? array()) as $fieldId) { $fieldId=dmd_animals_slug($fieldId,''); if(isset($fieldMap[$fieldId])&&!in_array($fieldId,$selected,true))$selected[]=$fieldId; }
    $row = array('id'=>$id,'label'=>$label,'description'=>dmd_animals_clean($payload['description'] ?? '',1000),'enabled'=>!array_key_exists('enabled',$payload) || !empty($payload['enabled']),'fields'=>$selected,'updated_at'=>date(DATE_ATOM));
    $replaced=false; foreach($profiles as $i=>$profile) if((string)($profile['id']??'')===$id){$profiles[$i]=array_replace($profile,$row);$replaced=true;break;}
    if(!$replaced)$profiles[]=$row;
    dmd_animals_write_json(dmd_animals_profiles_file(), array_values($profiles));
    return $row;
}

function dmd_animals_delete_profile($id) {
    $id = dmd_animals_slug($id,'');
    $cfg = dmd_animals_config();
    if ($id === (string)$cfg['default_profile']) throw new RuntimeException('Le profil par défaut ne peut pas être supprimé.');
    foreach (dmd_animals_all(true) as $animal) if ((string)($animal['profile_id'] ?? '') === $id) throw new RuntimeException('Ce profil est encore utilisé par au moins un animal.');
    $profiles=dmd_animals_profiles();$new=array();$found=false;foreach($profiles as $profile){if((string)($profile['id']??'')===$id){$found=true;continue;}$new[]=$profile;}if(!$found)throw new OutOfBoundsException('Profil introuvable.');
    dmd_animals_write_json(dmd_animals_profiles_file(),$new); return true;
}

function dmd_animals_system_config_event($action, $details, $changes = array()) {
    dmd_animals_boot_core();
    if (!function_exists('dmd_module_event')) throw new RuntimeException('Bus événementiel DoMyDesk indisponible.');
    $resource = array(
        'type'=>'module_config','id'=>DMD_ANIMALS_ID . ':config','local_id'=>'config',
        'name'=>'Configuration DMD-Animals','label'=>'Configuration DMD-Animals',
        'source'=>DMD_ANIMALS_ID,'module'=>DMD_ANIMALS_ID,'tags'=>array('configuration','animals')
    );
    $result = dmd_module_event(DMD_ANIMALS_ID, (string)$action, $resource, array(
        'email'=>dmd_animals_email(),'scope'=>'system','label'=>'Configuration DMD-Animals',
        'target'=>'DMD-Animals','status'=>'success','details'=>(string)$details,'changes'=>$changes,
        'meta'=>array('resource_type'=>'module_config')
    ));
    if (!is_array($result) || empty($result['ok'])) throw new RuntimeException('Journalisation/activité Core impossible.');
    return $result;
}

function dmd_animals_legacy_sources() {
    $root = dmd_animals_root();
    return array(
        $root . '/modules/animals/repertoire',
        $root . '/modules/DMD-Animals/repertoire',
        dmd_animals_storage_root() . '/legacy-repertoire'
    );
}

function dmd_animals_copy_tree($source, $target) {
    if (!is_dir($source)) return;
    if (!is_dir($target)) @mkdir($target,0750,true);
    foreach (array_diff((array)@scandir($source), array('.','..')) as $name) {
        $s=$source.'/'.$name;$t=$target.'/'.$name;
        if (is_link($s)) continue;
        if (is_dir($s)) dmd_animals_copy_tree($s,$t);
        elseif (is_file($s) && !is_file($t)) { @copy($s,$t); @chmod($t,0640); }
    }
}

function dmd_animals_legacy_value($legacy, $group, $key) {
    return isset($legacy[$group]) && is_array($legacy[$group]) ? ($legacy[$group][$key] ?? '') : '';
}

function dmd_animals_legacy_stable_id($legacy) {
    $legacyId = trim((string)($legacy['id'] ?? ''));
    $valid = dmd_animals_valid_id($legacyId);
    if ($valid) return $valid;
    if ($legacyId !== '') return substr(hash('sha256', 'dmd-animals-legacy-id|' . $legacyId), 0, 16);
    $fingerprint = array(
        (string)($legacy['prenom'] ?? ''),
        (string)($legacy['type'] ?? ''),
        (string)($legacy['race'] ?? ''),
        (string)($legacy['date_naissance'] ?? ''),
        (string)($legacy['identification'] ?? ''),
        (string)($legacy['created_at'] ?? '')
    );
    return substr(hash('sha256', 'dmd-animals-legacy-fingerprint|' . implode('|', $fingerprint)), 0, 16);
}

function dmd_animals_convert_legacy($legacy, $legacyDir) {
    $id = dmd_animals_legacy_stable_id($legacy);
    $existingFile = dmd_animals_animal_file($id);
    if ($existingFile !== '' && is_file($existingFile)) return array('animal'=>dmd_animals_load($id),'imported'=>false,'id'=>$id);
    $mode = dmd_animals_slug($legacy['usage_mode'] ?? 'particulier','particulier');
    if (!isset(dmd_animals_profile_map()[$mode])) $mode = 'particulier';
    $statusMap = array('vivant'=>'Vivant','decede'=>'Décédé','disponible'=>'Disponible','reserve'=>'Réservé','adopte'=>'Adopté','famille_accueil'=>'Famille d’accueil','en_soin'=>'En soin','quarantaine'=>'Quarantaine','vendu'=>'Vendu','perdu'=>'Perdu','retrouve'=>'Retrouvé');
    $sexMap = array('male'=>'Mâle','mâle'=>'Mâle','femelle'=>'Femelle','female'=>'Femelle');
    $legacyStatus = dmd_animals_slug($legacy['status'] ?? 'vivant','vivant');
    $legacySex = strtolower(trim((string)($legacy['sexe'] ?? '')));
    $fields = array(
        'vet_name'=>dmd_animals_legacy_value($legacy,'health','vet_name'),'vet_phone'=>dmd_animals_legacy_value($legacy,'health','vet_phone'),'sterilized'=>!empty($legacy['health']['sterilized']),
        'weight'=>dmd_animals_legacy_value($legacy,'health','weight'),'food'=>dmd_animals_legacy_value($legacy,'health','food'),'allergies'=>dmd_animals_legacy_value($legacy,'health','allergies'),'diseases'=>dmd_animals_legacy_value($legacy,'health','diseases'),'treatments'=>dmd_animals_legacy_value($legacy,'health','treatments'),
        'vaccine_last'=>dmd_animals_legacy_value($legacy,'health','vaccine_last'),'vaccine_next'=>dmd_animals_legacy_value($legacy,'health','vaccine_next'),'worm_last'=>dmd_animals_legacy_value($legacy,'health','worm_last'),'worm_next'=>dmd_animals_legacy_value($legacy,'health','worm_next'),'flea_last'=>dmd_animals_legacy_value($legacy,'health','flea_last'),'flea_next'=>dmd_animals_legacy_value($legacy,'health','flea_next'),
        'owner'=>dmd_animals_legacy_value($legacy,'contacts','owner'),'owner_phone'=>dmd_animals_legacy_value($legacy,'contacts','phone'),'owner_email'=>dmd_animals_legacy_value($legacy,'contacts','email'),'insurance'=>dmd_animals_legacy_value($legacy,'contacts','insurance'),'petsitter'=>dmd_animals_legacy_value($legacy,'contacts','petsitter'),
        'adoption_status'=>dmd_animals_legacy_value($legacy,'refuge','adoption_status'),'entry_date'=>dmd_animals_legacy_value($legacy,'refuge','entry_date'),'origin'=>dmd_animals_legacy_value($legacy,'refuge','origin'),'foster_family'=>dmd_animals_legacy_value($legacy,'refuge','foster_family'),'compat_dogs'=>dmd_animals_legacy_value($legacy,'refuge','compat_dogs'),'compat_cats'=>dmd_animals_legacy_value($legacy,'refuge','compat_cats'),'compat_children'=>dmd_animals_legacy_value($legacy,'refuge','compat_children'),'housing'=>dmd_animals_legacy_value($legacy,'refuge','housing'),'adoption_notes'=>dmd_animals_legacy_value($legacy,'refuge','adoption_notes'),'adopter'=>dmd_animals_legacy_value($legacy,'refuge','adopter'),'adoption_date'=>dmd_animals_legacy_value($legacy,'refuge','adoption_date'),
        'father'=>dmd_animals_legacy_value($legacy,'breeding','father'),'mother'=>dmd_animals_legacy_value($legacy,'breeding','mother'),'lineage'=>dmd_animals_legacy_value($legacy,'breeding','lineage'),'litter'=>dmd_animals_legacy_value($legacy,'breeding','litter'),'mating_date'=>dmd_animals_legacy_value($legacy,'breeding','mating_date'),'expected_birth'=>dmd_animals_legacy_value($legacy,'breeding','expected_birth'),'birth_event_date'=>dmd_animals_legacy_value($legacy,'breeding','birth_date'),'offspring_count'=>dmd_animals_legacy_value($legacy,'breeding','offspring_count'),'reservation_status'=>dmd_animals_legacy_value($legacy,'breeding','reservation_status'),'buyer'=>dmd_animals_legacy_value($legacy,'breeding','buyer'),'sale_price'=>dmd_animals_legacy_value($legacy,'breeding','sale_price'),'departure_date'=>dmd_animals_legacy_value($legacy,'breeding','departure_date')
    );
    foreach ((array)($legacy['custom'] ?? array()) as $label=>$value) {
        $fid = 'legacy-' . dmd_animals_slug($label,'champ');
        $fields[$fid] = is_scalar($value) ? (string)$value : json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }
    $animal = array(
        'id'=>$id,'name'=>(string)($legacy['prenom'] ?? 'Sans nom'),'profile_id'=>$mode,'species'=>(string)($legacy['type'] ?? ''),'breed'=>(string)($legacy['race'] ?? ''),'cross'=>'','sex'=>$sexMap[$legacySex] ?? (string)($legacy['sexe'] ?? ''),'birth_date'=>(string)($legacy['date_naissance'] ?? ''),'death_date'=>(string)($legacy['death'] ?? ''),'status'=>$statusMap[$legacyStatus] ?? (string)($legacy['status'] ?? 'Vivant'),'identification'=>(string)($legacy['identification'] ?? ''),'color'=>(string)($legacy['couleur'] ?? ''),'purpose'=>(string)($legacy['utility'] ?? ''),'notes'=>(string)($legacy['note'] ?? ''),'fields'=>$fields,
        'history'=>is_array($legacy['history'] ?? null) ? array_values($legacy['history']) : array(),'reminders'=>is_array($legacy['reminders'] ?? null) ? array_values($legacy['reminders']) : array(),'attachments'=>array(),'photo_id'=>'','legacy_source'=>array('module'=>'animals','path'=>$legacyDir),'legacy_raw'=>$legacy,'created_at'=>(string)($legacy['created_at'] ?? date(DATE_ATOM)),'updated_at'=>date(DATE_ATOM),'created_by'=>'migration','updated_by'=>'migration'
    );
    $dir = dmd_animals_animal_dir($id,true);
    $paths = array();
    if (!empty($legacy['image'])) $paths[] = array('path'=>$legacy['image'],'name'=>basename((string)$legacy['image']),'category'=>'Photo principale');
    foreach ((array)($legacy['documents'] ?? array()) as $doc) if (is_array($doc) && !empty($doc['path'])) $paths[] = array('path'=>$doc['path'],'name'=>(string)($doc['name'] ?? basename((string)$doc['path'])),'category'=>(string)($doc['category'] ?? 'Autre'));
    foreach ((array)($legacy['files'] ?? array()) as $p) if (is_string($p) && $p !== '') $paths[] = array('path'=>$p,'name'=>basename($p),'category'=>'Autre');
    $seen=array();
    foreach($paths as $p){
        $rel=str_replace('\\','/',(string)$p['path']); if(isset($seen[$rel]))continue;$seen[$rel]=true;
        $source=realpath($legacyDir.'/'.$rel);$legacyReal=realpath($legacyDir);if(!$source||!$legacyReal||strpos($source,rtrim($legacyReal,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR)!==0||!is_file($source))continue;
        $aid=dmd_animals_new_id();$ext=strtolower(pathinfo($source,PATHINFO_EXTENSION));$stored=$aid.($ext!==''?'.'.preg_replace('/[^a-z0-9]/','',$ext):'');$kind=dmd_animals_is_image($source)?'image':'document';$sub=$kind==='image'?'media':'documents';$dest=$dir.'/'.$sub.'/'.$stored;if(@copy($source,$dest)){@chmod($dest,0640);$animal['attachments'][]=array('id'=>$aid,'name'=>dmd_animals_clean($p['name'],255),'stored_name'=>$stored,'kind'=>$kind,'category'=>dmd_animals_clean($p['category'],120),'mime'=>'','size'=>(int)@filesize($dest),'uploaded_at'=>date(DATE_ATOM),'uploaded_by'=>'migration');if($kind==='image'&&$animal['photo_id']==='')$animal['photo_id']=$aid;}
    }
    dmd_animals_write_json($dir.'/info.json',$animal);
    return array('animal'=>$animal,'imported'=>true,'id'=>$id);
}

function dmd_animals_migration_register_custom_fields($legacy, &$fields, &$fieldMap, &$report) {
    if (!is_array($legacy)) return;
    foreach ((array)($legacy['custom'] ?? array()) as $label=>$value) {
        $id = 'legacy-' . dmd_animals_slug($label, 'champ');
        if (isset($fieldMap[$id])) continue;
        $fields[] = array(
            'id'=>$id,'label'=>dmd_animals_clean($label,120),'type'=>'text','section'=>'Champs importés',
            'required'=>false,'options'=>array(),'updated_at'=>date(DATE_ATOM)
        );
        $fieldMap[$id] = true;
        $report['fields_imported']++;
    }
}

function dmd_animals_find_legacy_info_files($source) {
    $sourceReal = realpath($source);
    if ($sourceReal === false || !is_dir($sourceReal)) return array();
    $files = array();
    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($sourceReal, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($iterator as $entry) {
            if (!$entry instanceof SplFileInfo || !$entry->isFile() || $entry->getFilename() !== 'info.json') continue;
            $path = $entry->getRealPath();
            if ($path === false) continue;
            $pathN = str_replace('\\','/',$path);
            $rootN = rtrim(str_replace('\\','/',$sourceReal),'/') . '/';
            if (strpos($pathN,$rootN) !== 0) continue;
            $files[] = $path;
        }
    } catch (Throwable $e) {}
    sort($files, SORT_STRING);
    return array_values(array_unique($files));
}

function dmd_animals_migration_marker_file() {
    return dmd_animals_storage_root() . '/migration/legacy-animals-v3.json';
}

function dmd_animals_migrate_legacy_once($force = false) {
    $root = dmd_animals_storage_root();
    $marker = dmd_animals_migration_marker_file();
    if (!$force && is_file($marker)) return dmd_animals_read_json($marker,array());
    $report = array('ran_at'=>date(DATE_ATOM),'sources'=>array(),'animals_found'=>0,'animals_imported'=>0,'animals_already_present'=>0,'fields_imported'=>0);
    $fields = dmd_animals_fields(); $fieldMap = array(); foreach($fields as $f) $fieldMap[(string)($f['id']??'')]=true;
    foreach (dmd_animals_legacy_sources() as $source) {
        if (!is_dir($source)) continue;
        $sourceReal = realpath($source) ?: $source;
        $infoFiles = dmd_animals_find_legacy_info_files($sourceReal);
        $report['sources'][] = array('path'=>$sourceReal,'info_files'=>count($infoFiles));
        $legacyFields = dmd_animals_read_json($sourceReal . '/addline.json', array());
        foreach ((array)$legacyFields as $label) {
            $id = 'legacy-' . dmd_animals_slug($label,'champ');
            if (!isset($fieldMap[$id])) { $fields[] = array('id'=>$id,'label'=>dmd_animals_clean($label,120),'type'=>'text','section'=>'Champs importés','access_group'=>'professional','required'=>false,'options'=>array(),'updated_at'=>date(DATE_ATOM));$fieldMap[$id]=true;$report['fields_imported']++; }
        }
        foreach ($infoFiles as $file) {
            $legacy = dmd_animals_read_json($file,array());
            if(!$legacy) continue;
            $report['animals_found']++;
            dmd_animals_migration_register_custom_fields($legacy,$fields,$fieldMap,$report);
            $converted = dmd_animals_convert_legacy($legacy, dirname($file));
            if (is_array($converted) && !empty($converted['imported'])) $report['animals_imported']++;
            else $report['animals_already_present']++;
        }
    }
    if ($report['fields_imported'] > 0) dmd_animals_write_json(dmd_animals_fields_file(),$fields);
    dmd_animals_write_json($marker,$report);
    return $report;
}

function dmd_animals_stats($animals = null) {
    $animals = is_array($animals) ? $animals : dmd_animals_all(false);
    $today = date('Y-m-d'); $soon = date('Y-m-d', strtotime('+30 days'));
    $stats = array('total'=>count($animals),'profiles'=>array(),'species'=>array(),'reminders'=>0);
    foreach ($animals as $animal) {
        $p=(string)($animal['profile_label']??$animal['profile_id']??''); if($p!=='')$stats['profiles'][$p]=($stats['profiles'][$p]??0)+1;
        $s=(string)($animal['species']??''); if($s!=='')$stats['species'][$s]=($stats['species'][$s]??0)+1;
        foreach((array)($animal['reminders']??array()) as $r){$d=(string)($r['date']??'');if(empty($r['done'])&&$d!==''&&$d>=$today&&$d<=$soon){$stats['reminders']++;break;}}
    }
    arsort($stats['profiles']);arsort($stats['species']);return $stats;
}

function dmd_animals_public_payload($animal, $includeDetails = true) {
    if (!$animal) return null;
    $payload = $animal;
    if (!$includeDetails) return dmd_animals_summary($animal);
    return $payload;
}

function dmd_animals_json($payload, $status = 200) {
    http_response_code((int)$status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache'); header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

dmd_animals_storage_root(true);
