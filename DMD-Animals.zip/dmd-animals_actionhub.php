<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



require_once __DIR__ . '/dmd-animals_lib.php';
function dmd_animals_actionhub_local_id($resource) {
    if (!is_array($resource)) return null;
    $id = (string)($resource['id'] ?? '');
    $prefix = DMD_ANIMALS_ID . ':animal:';
    if (strpos($id, $prefix) !== 0) return null;
    return dmd_animals_valid_id(substr($id, strlen($prefix)));
}

function dmd_animals_actionhub_check($email, $permission) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return false;
    if (dmd_animals_email() !== '' && strcasecmp(dmd_animals_email(), $email) !== 0) return false;
    return dmd_animals_user_permission($email, $permission);
}

function dmd_animals_actionhub_check_all($email, $permissions) {
    foreach ((array)$permissions as $permission) {
        if (!dmd_animals_actionhub_check($email, $permission)) return false;
    }
    return true;
}

function dmd_animals_ah_options($items) {
    $out = array();
    foreach ((array)$items as $value => $label) {
        if (is_int($value)) $value = $label;
        $value = trim((string)$value);
        $label = trim((string)$label);
        if ($value === '') continue;
        $out[] = array('value'=>$value, 'label'=>$label !== '' ? $label : $value);
    }
    return $out;
}

function dmd_animals_ah_animal_options($requiredFieldId = '') {
    $profiles = dmd_animals_profile_map();
    $animals = dmd_animals_all(true);
    usort($animals, static function($a, $b) {
        return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
    });
    $out = array();
    foreach ($animals as $animal) {
        $id = dmd_animals_valid_id($animal['id'] ?? '');
        if ($id === null) continue;
        $profileId = (string)($animal['profile_id'] ?? '');
        if ($requiredFieldId !== '') {
            $profileFields = isset($profiles[$profileId]) && is_array($profiles[$profileId]) ? (array)($profiles[$profileId]['fields'] ?? array()) : array();
            if (!in_array($requiredFieldId, $profileFields, true)) continue;
        }
        $profile = isset($profiles[$profileId]) ? (string)($profiles[$profileId]['label'] ?? $profileId) : $profileId;
        $meta = array_filter(array(
            (string)($animal['species'] ?? ''),
            (string)($animal['breed'] ?? ''),
            $profile,
            (string)($animal['status'] ?? '')
        ), static fn($v) => trim((string)$v) !== '');
        $label = trim((string)($animal['name'] ?? $id));
        if ($meta) $label .= ' · ' . implode(' · ', $meta);
        $out[] = array('value'=>$id, 'label'=>$label);
        if (count($out) >= 1000) break;
    }
    return $out;
}

function dmd_animals_ah_profile_options() {
    $out = array();
    foreach (dmd_animals_profiles() as $profile) {
        if (!is_array($profile) || empty($profile['enabled']) || empty($profile['id'])) continue;
        $out[] = array('value'=>(string)$profile['id'], 'label'=>(string)($profile['label'] ?? $profile['id']));
    }
    return $out;
}

function dmd_animals_ah_input($id, $label, $type='text', $required=false, $options=array(), $default='', $placeholder='', $help='') {
    return array(
        'id'=>$id,
        'label'=>$label,
        'type'=>$type,
        'required'=>(bool)$required,
        'options'=>array_values((array)$options),
        'default'=>$default,
        'placeholder'=>$placeholder,
        'help'=>$help,
    );
}

function dmd_animals_ah_field_input($field, $id='value') {
    $type = strtolower(trim((string)($field['type'] ?? 'text')));
    if ($type === 'checkbox') $ahType = 'boolean';
    elseif (in_array($type, array('textarea','date','number','select'), true)) $ahType = $type;
    else $ahType = 'text';
    $options = array();
    if ($ahType === 'select') $options = dmd_animals_ah_options((array)($field['options'] ?? array()));
    return dmd_animals_ah_input(
        $id,
        (string)($field['label'] ?? $id),
        $ahType,
        !empty($field['required']),
        $options,
        $ahType === 'boolean' ? false : '',
        '',
        (string)($field['section'] ?? '')
    );
}

function dmd_animals_ah_action($id, $label, $group, $permissions, $inputs=array(), $scenario=true, $scope='module', $resourceTypes=array(), $meta=array(), $icon='⚡', $description='', $dangerous=false, $confirm='') {
    return array(
        'id'=>$id,
        'label'=>$label,
        'description'=>$description,
        'icon'=>$icon,
        'group'=>$group,
        'permissions'=>array_values(array_unique((array)$permissions)),
        'scope'=>$scope,
        'scenario'=>(bool)$scenario,
        'resource_types'=>array_values((array)$resourceTypes),
        'inputs'=>array_values((array)$inputs),
        'dangerous'=>(bool)$dangerous,
        'confirm'=>$confirm,
        'meta'=>$meta,
    );
}

function dmd_animals_ah_animal_input($options) {
    return dmd_animals_ah_input('animal_id', 'Animal', 'select', true, $options);
}

function dmd_animals_ah_dynamic_group($field) {
    $group = dmd_animals_field_permission_group($field);
    if ($group === 'health') return 'Santé';
    if ($group === 'contacts') return 'Contacts';
    $section = trim((string)($field['section'] ?? 'Métier'));
    return $section !== '' && strcasecmp($section, 'Métier') !== 0 ? 'Métier · ' . $section : 'Métier';
}

function dmd_animals_ah_ui_result($animal, $type, $message, $tab='') {
    $ui = array(
        'type'=>$type,
        'module'=>DMD_ANIMALS_ID,
        'animal_id'=>(string)$animal['id'],
    );
    if ($tab !== '') $ui['tab'] = $tab;
    return array(
        'ok'=>true,
        'message'=>$message,
        'data'=>array(
            'module'=>DMD_ANIMALS_ID,
            'animal_id'=>(string)$animal['id'],
            'resource_id'=>dmd_animals_resource($animal)['id'],
            'ui'=>$ui,
        ),
        /* La consultation réelle sera journalisée lors de l'ouverture de la fiche. */
        'event_emitted'=>true,
    );
}

function dmd_animals_actionhub_catalog($context) {
    $context = is_array($context) ? $context : array();
    $email = trim((string)($context['email'] ?? ''));
    $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;
    dmd_animals_initialize();

    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false || !dmd_animals_actionhub_check($email, 'module.view')) {
        return array('replace'=>true, 'actions'=>array());
    }

    /* Actions disponibles depuis une ressource récente ActionHub. */
    if ($resource !== null) {
        $id = dmd_animals_actionhub_local_id($resource);
        $animal = $id !== null ? dmd_animals_load($id) : null;
        if (!$animal || !dmd_animals_actionhub_check($email, 'animal.view')) return array('replace'=>true, 'actions'=>array());

        $actions = array();
        $actions[] = dmd_animals_ah_action('animal.open','Ouvrir la fiche','Fiche',array('module.view','animal.view'),array(),false,'resource',array('animal'),array('ui_action'=>'open'),'🐾','Ouvre la fiche de l’animal dans DMD-Animals.');
        if (dmd_animals_actionhub_check($email,'animal.identity.edit')) {
            $actions[] = dmd_animals_ah_action('animal.edit','Modifier la fiche','Fiche',array('module.view','animal.view','animal.identity.edit'),array(),false,'resource',array('animal'),array('ui_action'=>'edit'),'✏️','Ouvre la modification de la fiche.');
        }
        if (dmd_animals_actionhub_check($email,'animal.media.view')) {
            $actions[] = dmd_animals_ah_action('animal.documents','Voir les documents / photos','Documents / Photos',array('module.view','animal.view','animal.media.view'),array(),false,'resource',array('animal'),array('ui_action'=>'tab','tab'=>'media'),'📎','Ouvre directement les documents et photos de l’animal.');
        }
        if (dmd_animals_actionhub_check($email,'animal.history.view')) {
            $actions[] = dmd_animals_ah_action('animal.history','Voir l’historique','Historique',array('module.view','animal.view','animal.history.view'),array(),false,'resource',array('animal'),array('ui_action'=>'tab','tab'=>'history'),'📝','Ouvre directement la chronologie de l’animal.');
        }
        if (dmd_animals_actionhub_check($email,'animal.reminder.view')) {
            $actions[] = dmd_animals_ah_action('animal.reminders','Voir les rappels','Rappels',array('module.view','animal.view','animal.reminder.view'),array(),false,'resource',array('animal'),array('ui_action'=>'tab','tab'=>'reminders'),'⏰','Ouvre directement les rappels de l’animal.');
        }
        if (dmd_animals_actionhub_check($email,'animal.export')) {
            $actions[] = dmd_animals_ah_action('animal.export','Exporter / imprimer','Export',array('module.view','animal.view','animal.export'),array(),false,'resource',array('animal'),array('ui_action'=>'export'),'🖨️','Ouvre l’export dans la popup interne DMD-Animals.');
        }
        if (dmd_animals_actionhub_check($email,'animal.delete')) {
            $actions[] = dmd_animals_ah_action('animal.delete','Supprimer l’animal','Fiche',array('module.view','animal.view','animal.delete'),array(),false,'resource',array('animal'),array('mutation'=>'delete'),'🗑️','Supprime définitivement la fiche et ses fichiers.',true,'Supprimer définitivement cet animal et tous ses fichiers ?');
        }
        return array('replace'=>true, 'actions'=>$actions);
    }
    $actions = array();
    $animalOptions = dmd_animals_ah_animal_options();
    $taxonomy = dmd_animals_taxonomy();
    $profiles = dmd_animals_profiles();
    $profileMap = dmd_animals_profile_map();
    $fieldMap = dmd_animals_field_map();

    if ($animalOptions && dmd_animals_actionhub_check($email,'animal.view')) {
        $animalInput = dmd_animals_ah_animal_input($animalOptions);
        $actions[] = dmd_animals_ah_action('scenario.animal.open','Ouvrir une fiche','Fiche',array('module.view','animal.view'),array($animalInput),true,'module',array(),array('ui_action'=>'open'),'🐾','Ouvre l’animal sélectionné dans DMD-Animals.');
        if (dmd_animals_actionhub_check($email,'animal.identity.edit')) {
            $actions[] = dmd_animals_ah_action('scenario.animal.edit','Ouvrir la modification','Fiche',array('module.view','animal.view','animal.identity.edit'),array($animalInput),true,'module',array(),array('ui_action'=>'edit'),'✏️','Ouvre directement l’éditeur de la fiche sélectionnée.');
        }
        if (dmd_animals_actionhub_check($email,'animal.media.view')) {
            $actions[] = dmd_animals_ah_action('scenario.animal.documents','Ouvrir documents / photos','Documents / Photos',array('module.view','animal.view','animal.media.view'),array($animalInput),true,'module',array(),array('ui_action'=>'tab','tab'=>'media'),'📎','Ouvre l’onglet Documents de l’animal sélectionné.');
        }
        if (dmd_animals_actionhub_check($email,'animal.history.view')) {
            $actions[] = dmd_animals_ah_action('scenario.animal.history','Ouvrir l’historique','Historique',array('module.view','animal.view','animal.history.view'),array($animalInput),true,'module',array(),array('ui_action'=>'tab','tab'=>'history'),'📝','Ouvre l’historique de l’animal sélectionné.');
        }
        if (dmd_animals_actionhub_check($email,'animal.reminder.view')) {
            $actions[] = dmd_animals_ah_action('scenario.animal.reminders','Ouvrir les rappels','Rappels',array('module.view','animal.view','animal.reminder.view'),array($animalInput),true,'module',array(),array('ui_action'=>'tab','tab'=>'reminders'),'⏰','Ouvre les rappels de l’animal sélectionné.');
        }
        if (dmd_animals_actionhub_check($email,'animal.export')) {
            $actions[] = dmd_animals_ah_action('scenario.animal.export','Exporter / imprimer une fiche','Export',array('module.view','animal.view','animal.export'),array($animalInput),true,'module',array(),array('ui_action'=>'export'),'🖨️','Ouvre l’export de la fiche sélectionnée dans DMD-Animals.');
        }

        if (dmd_animals_actionhub_check($email,'animal.status.edit')) {
            $actions[] = dmd_animals_ah_action(
                'scenario.animal.set-status','Changer le statut','Statut',
                array('module.view','animal.view','animal.status.edit'),
                array($animalInput, dmd_animals_ah_input('status','Nouveau statut','select',true,dmd_animals_ah_options((array)($taxonomy['statuses'] ?? array())))),
                true,'module',array(),array('mutation'=>'status'),'🔄','Change le statut opérationnel de l’animal.'
            );
        }

        if (dmd_animals_actionhub_check($email,'animal.history.add')) {
            $actions[] = dmd_animals_ah_action(
                'scenario.animal.add-history','Ajouter une ligne d’historique','Historique',
                array('module.view','animal.view','animal.history.add'),
                array(
                    $animalInput,
                    dmd_animals_ah_input('date','Date','date',false,array(),date('Y-m-d')),
                    dmd_animals_ah_input('type','Type','select',true,dmd_animals_ah_options((array)($taxonomy['history_types'] ?? array())),'Note'),
                    dmd_animals_ah_input('title','Titre','text',true),
                    dmd_animals_ah_input('note','Détails','textarea',false)
                ),
                true,'module',array(),array('mutation'=>'history.add'),'📝','Ajoute un événement structuré à la chronologie.'
            );
        }

        if (dmd_animals_actionhub_check($email,'animal.reminder.manage')) {
            $actions[] = dmd_animals_ah_action(
                'scenario.animal.add-reminder','Créer un rappel','Rappels',
                array('module.view','animal.view','animal.reminder.manage'),
                array(
                    $animalInput,
                    dmd_animals_ah_input('date','Date','date',true),
                    dmd_animals_ah_input('title','Rappel','text',true),
                    dmd_animals_ah_input('note','Note','textarea',false)
                ),
                true,'module',array(),array('mutation'=>'reminder.add'),'⏰','Crée une échéance sur l’animal.'
            );
        }

        if (dmd_animals_actionhub_check($email,'animal.identity.edit')) {
            $identity = array(
                'name'=>array('Nom','text',true,array()),
                'profile_id'=>array('Profil métier','select',true,dmd_animals_ah_profile_options()),
                'species'=>array('Espèce','select',false,dmd_animals_ah_options(array_keys((array)($taxonomy['species'] ?? array())))),
                'breed'=>array('Race','text',false,array()),
                'cross'=>array('Croisement','text',false,array()),
                'sex'=>array('Sexe','select',false,dmd_animals_ah_options((array)($taxonomy['sexes'] ?? array()))),
                'birth_date'=>array('Date de naissance','date',false,array()),
                'death_date'=>array('Date de décès','date',false,array()),
                'identification'=>array('Identification','text',false,array()),
                'color'=>array('Couleur / robe','text',false,array()),
                'purpose'=>array('Utilité / rôle','text',false,array()),
                'notes'=>array('Notes générales','textarea',false,array()),
            );
            foreach ($identity as $fieldId=>$def) {
                [$label,$type,$required,$options] = $def;
                $actions[] = dmd_animals_ah_action(
                    'scenario.identity.' . $fieldId,
                    'Modifier · ' . $label,
                    'Fiche',
                    array('module.view','animal.view','animal.identity.edit'),
                    array($animalInput, dmd_animals_ah_input('value',$label,$type,$required,$options)),
                    true,'module',array(),array('mutation'=>'identity','core_field'=>$fieldId),'✏️','Modifie uniquement « '.$label.' » sur l’animal sélectionné.'
                );
            }
        }

        foreach ($fieldMap as $fieldId=>$field) {
            $permission = dmd_animals_field_edit_permission($field);
            if (!dmd_animals_actionhub_check($email,$permission)) continue;
            $fieldAnimalOptions = dmd_animals_ah_animal_options($fieldId);
            if (!$fieldAnimalOptions) continue;
            $fieldAnimalInput = dmd_animals_ah_animal_input($fieldAnimalOptions);
            $actions[] = dmd_animals_ah_action(
                'scenario.field.' . $fieldId,
                'Modifier · ' . (string)($field['label'] ?? $fieldId),
                dmd_animals_ah_dynamic_group($field),
                array('module.view','animal.view',$permission),
                array($fieldAnimalInput, dmd_animals_ah_field_input($field,'value')),
                true,'module',array(),array('mutation'=>'dynamic-field','field_id'=>$fieldId),'🧩','Modifie le champ configurable « '.(string)($field['label'] ?? $fieldId).' ».'
            );
        }
    }

    if (dmd_animals_actionhub_check($email,'animal.create')) {
        foreach ($profiles as $profile) {
            if (!is_array($profile) || empty($profile['enabled']) || empty($profile['id'])) continue;
            $profileId = (string)$profile['id'];
            $profileLabel = (string)($profile['label'] ?? $profileId);
            $inputs = array(
                dmd_animals_ah_input('name','Nom','text',true),
                dmd_animals_ah_input('species','Espèce','select',false,dmd_animals_ah_options(array_keys((array)($taxonomy['species'] ?? array())))),
                dmd_animals_ah_input('breed','Race','text',false),
                dmd_animals_ah_input('cross','Croisement','text',false),
                dmd_animals_ah_input('sex','Sexe','select',false,dmd_animals_ah_options((array)($taxonomy['sexes'] ?? array()))),
                dmd_animals_ah_input('birth_date','Date de naissance','date',false),
                dmd_animals_ah_input('death_date','Date de décès','date',false),
                dmd_animals_ah_input('status','Statut','select',false,dmd_animals_ah_options((array)($taxonomy['statuses'] ?? array())),'Vivant'),
                dmd_animals_ah_input('identification','Identification','text',false),
                dmd_animals_ah_input('color','Couleur / robe','text',false),
                dmd_animals_ah_input('purpose','Utilité / rôle','text',false),
                dmd_animals_ah_input('notes','Notes','textarea',false),
            );
            $blockedRequired = false;
            foreach ((array)($profile['fields'] ?? array()) as $fieldId) {
                if (!isset($fieldMap[$fieldId])) continue;
                $field = $fieldMap[$fieldId];
                $permission = dmd_animals_field_edit_permission($field);
                if (!dmd_animals_actionhub_check($email,$permission)) {
                    if (!empty($field['required'])) $blockedRequired = true;
                    continue;
                }
                $inputs[] = dmd_animals_ah_field_input($field,'field__'.$fieldId);
            }
            if ($blockedRequired) continue;
            $actions[] = dmd_animals_ah_action(
                'scenario.animal.create.' . $profileId,
                'Créer · ' . $profileLabel,
                'Création',
                array('module.view','animal.create'),
                $inputs,
                true,'module',array(),array('mutation'=>'create','fixed_profile_id'=>$profileId),'➕','Crée une fiche « '.$profileLabel.' » avec les champs définis dans le CFG.'
            );
        }
    }

    return array('replace'=>true, 'actions'=>$actions);
}

function dmd_animals_actionhub_resolve_animal($resource, $payload) {
    $id = null;
    if (is_array($resource)) $id = dmd_animals_actionhub_local_id($resource);
    if ($id === null) $id = dmd_animals_valid_id($payload['animal_id'] ?? '');
    if ($id === null) return array(null, null);
    return array($id, dmd_animals_load($id));
}

function dmd_animals_actionhub_handle($context) {
    $context = is_array($context) ? $context : array();
    $email = trim((string)($context['email'] ?? ''));
    $action = is_array($context['action'] ?? null) ? $context['action'] : array();
    $actionId = (string)($action['id'] ?? '');
    $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;
    $payload = is_array($context['payload'] ?? null) ? $context['payload'] : array();
    $meta = is_array($action['meta'] ?? null) ? $action['meta'] : array();

    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return array('ok'=>false,'error'=>'invalid_user','message'=>'Utilisateur DMD-Animals invalide.');
    dmd_animals_initialize();

    if (!dmd_animals_actionhub_check($email,'module.view')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit module.view requis.');

    if (($meta['mutation'] ?? '') === 'create' || strpos($actionId,'scenario.animal.create.') === 0 || $actionId === 'animal.create') {
        if (!dmd_animals_actionhub_check($email,'animal.create')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.create requis.');
        try {
            $profileId = trim((string)($meta['fixed_profile_id'] ?? ($payload['profile_id'] ?? dmd_animals_config()['default_profile'])));
            $fields = array();
            $fieldMap = dmd_animals_field_map();
            foreach ($payload as $key=>$value) {
                if (strpos((string)$key,'field__') !== 0) continue;
                $fieldId = substr((string)$key,7);
                if (!isset($fieldMap[$fieldId])) continue;
                $permission = dmd_animals_field_edit_permission($fieldMap[$fieldId]);
                if (!dmd_animals_actionhub_check($email,$permission)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit '.$permission.' requis pour « '.(string)$fieldMap[$fieldId]['label'].' ».');
                $fields[$fieldId] = $value;
            }
            if (is_array($payload['fields'] ?? null)) {
                foreach ($payload['fields'] as $fieldId=>$value) {
                    if (!isset($fieldMap[$fieldId])) continue;
                    $permission = dmd_animals_field_edit_permission($fieldMap[$fieldId]);
                    if (!dmd_animals_actionhub_check($email,$permission)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit '.$permission.' requis pour « '.(string)$fieldMap[$fieldId]['label'].' ».');
                    $fields[$fieldId] = $value;
                }
            }
            $animal = dmd_animals_save(array(
                'name'=>$payload['name'] ?? '',
                'profile_id'=>$profileId,
                'species'=>$payload['species'] ?? '',
                'breed'=>$payload['breed'] ?? '',
                'cross'=>$payload['cross'] ?? '',
                'sex'=>$payload['sex'] ?? '',
                'birth_date'=>$payload['birth_date'] ?? '',
                'death_date'=>$payload['death_date'] ?? '',
                'status'=>$payload['status'] ?? 'Vivant',
                'identification'=>$payload['identification'] ?? '',
                'color'=>$payload['color'] ?? '',
                'purpose'=>$payload['purpose'] ?? '',
                'notes'=>$payload['notes'] ?? '',
                'fields'=>$fields,
            ));
            return array(
                'ok'=>true,
                'message'=>'Animal créé dans DMD-Animals.',
                'data'=>array(
                    'module'=>DMD_ANIMALS_ID,
                    'animal_id'=>$animal['id'],
                    'resource_id'=>dmd_animals_resource($animal)['id'],
                    'ui'=>array('type'=>'dmd-animals.open','module'=>DMD_ANIMALS_ID,'animal_id'=>$animal['id'])
                ),
                'event_emitted'=>true
            );
        } catch (Throwable $e) {
            return array('ok'=>false,'error'=>'create_failed','message'=>$e->getMessage());
        }
    }

    [$id,$animal] = dmd_animals_actionhub_resolve_animal($resource,$payload);
    if ($id === null || !$animal) return array('ok'=>false,'error'=>'not_found','message'=>'Animal introuvable.');
    if (!dmd_animals_actionhub_check($email,'animal.view')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.view requis.');

    $uiAction = (string)($meta['ui_action'] ?? '');
    if ($uiAction !== '') {
        if ($uiAction === 'edit') {
            if (!dmd_animals_actionhub_check($email,'animal.identity.edit')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.identity.edit requis.');
            return dmd_animals_ah_ui_result($animal,'dmd-animals.edit','Ouverture de la modification DMD-Animals.');
        }
        if ($uiAction === 'export') {
            if (!dmd_animals_actionhub_check($email,'animal.export')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.export requis.');
            return dmd_animals_ah_ui_result($animal,'dmd-animals.export','Export DMD-Animals prêt.');
        }
        if ($uiAction === 'tab') {
            $tab = (string)($meta['tab'] ?? 'overview');
            $permission = $tab === 'media' ? 'animal.media.view' : ($tab === 'history' ? 'animal.history.view' : ($tab === 'reminders' ? 'animal.reminder.view' : 'animal.view'));
            if (!dmd_animals_actionhub_check($email,$permission)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit '.$permission.' requis.');
            return dmd_animals_ah_ui_result($animal,'dmd-animals.open','Ouverture de DMD-Animals.',$tab);
        }
        return dmd_animals_ah_ui_result($animal,'dmd-animals.open','Ouverture de la fiche DMD-Animals.');
    }

    $mutation = (string)($meta['mutation'] ?? '');
    if ($mutation === 'status' || $actionId === 'animal.set-status') {
        if (!dmd_animals_actionhub_check($email,'animal.status.edit')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.status.edit requis.');
        $status = dmd_animals_clean($payload['status'] ?? '',80);
        $allowed = (array)(dmd_animals_taxonomy()['statuses'] ?? array());
        if ($status === '' || !in_array($status,$allowed,true)) return array('ok'=>false,'error'=>'invalid_status','message'=>'Statut DMD-Animals invalide.');
        try {
            $input=$animal; $input['status']=$status; $updated=dmd_animals_save($input,$id);
            return array('ok'=>true,'message'=>'Statut de '.$animal['name'].' mis à jour.','data'=>array('module'=>DMD_ANIMALS_ID,'animal_id'=>$id,'status'=>$updated['status'],'reload'=>true),'event_emitted'=>true);
        } catch(Throwable $e) { return array('ok'=>false,'error'=>'status_failed','message'=>$e->getMessage()); }
    }

    if ($mutation === 'history.add' || $actionId === 'animal.add-history') {
        if (!dmd_animals_actionhub_check($email,'animal.history.add')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.history.add requis.');
        try {
            $result=dmd_animals_add_history($id,array('date'=>$payload['date']??date('Y-m-d'),'type'=>$payload['type']??'Note','title'=>$payload['title']??'Intervention','note'=>$payload['note']??''),$email);
            return array('ok'=>true,'message'=>'Historique ajouté à '.$animal['name'].'.','data'=>array('module'=>DMD_ANIMALS_ID,'animal_id'=>$id,'history_id'=>$result['history']['id'],'reload'=>true),'event_emitted'=>true);
        } catch(Throwable $e) { return array('ok'=>false,'error'=>'history_failed','message'=>$e->getMessage()); }
    }

    if ($mutation === 'reminder.add' || $actionId === 'animal.add-reminder') {
        if (!dmd_animals_actionhub_check($email,'animal.reminder.manage')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.reminder.manage requis.');
        try {
            $result=dmd_animals_add_reminder($id,array('date'=>$payload['date']??'','title'=>$payload['title']??'','note'=>$payload['note']??''),$email);
            return array('ok'=>true,'message'=>'Rappel ajouté à '.$animal['name'].'.','data'=>array('module'=>DMD_ANIMALS_ID,'animal_id'=>$id,'reminder_id'=>$result['reminder']['id'],'reload'=>true),'event_emitted'=>true);
        } catch(Throwable $e) { return array('ok'=>false,'error'=>'reminder_failed','message'=>$e->getMessage()); }
    }

    if ($mutation === 'identity') {
        if (!dmd_animals_actionhub_check($email,'animal.identity.edit')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.identity.edit requis.');
        $field = (string)($meta['core_field'] ?? '');
        $allowed = array('name','profile_id','species','breed','cross','sex','birth_date','death_date','identification','color','purpose','notes');
        if (!in_array($field,$allowed,true)) return array('ok'=>false,'error'=>'invalid_field','message'=>'Champ d’identité invalide.');
        try {
            $input=$animal; $input[$field]=$payload['value'] ?? '';
            $updated=dmd_animals_save($input,$id);
            return array('ok'=>true,'message'=>'« '.$field.' » mis à jour pour '.$animal['name'].'.','data'=>array('module'=>DMD_ANIMALS_ID,'animal_id'=>$id,'reload'=>true),'event_emitted'=>true);
        } catch(Throwable $e) { return array('ok'=>false,'error'=>'identity_failed','message'=>$e->getMessage()); }
    }

    if ($mutation === 'dynamic-field') {
        $fieldId = (string)($meta['field_id'] ?? '');
        $fieldMap = dmd_animals_field_map();
        if (!isset($fieldMap[$fieldId])) return array('ok'=>false,'error'=>'invalid_field','message'=>'Champ métier introuvable ou supprimé.');
        $permission = dmd_animals_field_edit_permission($fieldMap[$fieldId]);
        if (!dmd_animals_actionhub_check($email,$permission)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit '.$permission.' requis.');
        try {
            $input=$animal;
            $input['fields'] = is_array($animal['fields'] ?? null) ? $animal['fields'] : array();
            $input['fields'][$fieldId] = $payload['value'] ?? '';
            dmd_animals_save($input,$id);
            return array('ok'=>true,'message'=>'« '.(string)($fieldMap[$fieldId]['label'] ?? $fieldId).' » mis à jour pour '.$animal['name'].'.','data'=>array('module'=>DMD_ANIMALS_ID,'animal_id'=>$id,'reload'=>true),'event_emitted'=>true);
        } catch(Throwable $e) { return array('ok'=>false,'error'=>'field_failed','message'=>$e->getMessage()); }
    }

    if ($mutation === 'delete' || $actionId === 'animal.delete') {
        if (!dmd_animals_actionhub_check($email,'animal.delete')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.delete requis.');
        try {
            $name=(string)$animal['name']; dmd_animals_delete($id);
            return array('ok'=>true,'message'=>$name.' supprimé de DMD-Animals.','data'=>array('module'=>DMD_ANIMALS_ID,'animal_id'=>$id,'reload'=>true),'event_emitted'=>true);
        } catch(Throwable $e) { return array('ok'=>false,'error'=>'delete_failed','message'=>$e->getMessage()); }
    }

    if ($actionId === 'animal.open') return dmd_animals_ah_ui_result($animal,'dmd-animals.open','Ouverture de la fiche DMD-Animals.');
    if ($actionId === 'animal.edit') {
        if (!dmd_animals_actionhub_check($email,'animal.identity.edit')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.identity.edit requis.');
        return dmd_animals_ah_ui_result($animal,'dmd-animals.edit','Ouverture de la modification DMD-Animals.');
    }
    if ($actionId === 'animal.export') {
        if (!dmd_animals_actionhub_check($email,'animal.export')) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit animal.export requis.');
        return dmd_animals_ah_ui_result($animal,'dmd-animals.export','Export DMD-Animals prêt.');
    }

    return array('ok'=>false,'error'=>'unknown_action','message'=>'Action ActionHub DMD-Animals inconnue.');
}
