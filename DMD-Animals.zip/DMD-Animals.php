<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




require_once __DIR__ . '/dmd-animals_lib.php';
$error='';
try { dmd_animals_require('module.view'); dmd_animals_require('animal.view'); dmd_animals_initialize(); }
catch(Throwable $e){ $error=$e->getMessage(); }
$base=dmd_animals_module_web_path();
$initialAnimalId=dmd_animals_valid_id($_GET['animal_id']??$_GET['dmd_animal']??'')?:'';
$initialAnimalMode=(string)($_GET['mode']??'')==='edit'?'edit':'view';
?>
<link rel="stylesheet" href="<?= dmd_animals_h($base) ?>/dmd-animals.css?v=<?= dmd_animals_h(DMD_ANIMALS_VERSION) ?>">
<div class="dmd-animals" id="dmd-animals-root"
 data-api="<?= dmd_animals_h($base) ?>/dmd-animals_api.php"
 data-media="<?= dmd_animals_h($base) ?>/dmd-animals_media.php"
 data-export="<?= dmd_animals_h($base) ?>/dmd-animals_export.php"
 data-config="<?= dmd_animals_h($base) ?>/DMD-Animalscfg.php" data-open-id="<?= dmd_animals_h($initialAnimalId) ?>" data-open-mode="<?= dmd_animals_h($initialAnimalMode) ?>">
<?php if($error!==''): ?>
  <div class="da-shell"><div class="da-empty">⛔ <?= dmd_animals_h($error) ?></div></div>
<?php else: ?>
  <div class="da-shell">
    <header class="da-head">
      <div class="da-brand">
        <div><p>Registre système · métiers configurables · ActionHub · QuickSession · MyDesk</p></div>
      </div>
      <div class="da-head-actions">
        <?php if(dmd_animals_permission('animal.create')): ?><button type="button" class="da-primary" data-da-new>＋ Animal</button><?php endif; ?>
        <?php if(dmd_animals_permission('animal.export')): ?><button type="button" class="da-btn" data-da-export>Export</button><?php endif; ?>
      </div>
    </header>

    <div class="da-toolbar">
      <input type="search" data-da-search placeholder="Rechercher nom, identification, espèce, race…" autocomplete="off">
      <select data-da-profile-filter aria-label="Filtrer par profil"><option value="">Tous les métiers</option></select>
      <select data-da-species-filter aria-label="Filtrer par espèce"><option value="">Toutes les espèces</option></select>
      <select data-da-status-filter aria-label="Filtrer par statut"><option value="">Tous les statuts</option></select>
    </div>

    <section class="da-stats" data-da-stats>
      <div class="da-stat"><strong>—</strong><span>Animaux</span></div><div class="da-stat"><strong>—</strong><span>Métiers</span></div><div class="da-stat"><strong>—</strong><span>Espèces</span></div><div class="da-stat"><strong>—</strong><span>Rappels 30 j</span></div>
    </section>

    <main class="da-grid" data-da-grid><div class="da-loading">Chargement de DMD-Animals…</div></main>
    <div class="da-message" data-da-message role="status" aria-live="polite"></div>
  </div>

  <div class="da-panel-backdrop" data-da-backdrop hidden></div>
  <section class="da-panel" data-da-panel hidden aria-label="Fiche DMD-Animals">
    <header class="da-panel-head">
      <div class="da-panel-identity">
        <button type="button" class="da-panel-photo" data-da-panel-photo hidden aria-label="Agrandir la photo principale"><img data-da-panel-photo-img alt=""></button>
        <div class="da-panel-head-copy"><h3 data-da-panel-title>Animal</h3><p data-da-panel-subtitle></p></div>
      </div>
      <div class="da-panel-actions"><button type="button" data-da-panel-export hidden>Export</button><button type="button" data-da-panel-edit hidden>Modifier</button><button type="button" data-da-close>×</button></div>
    </header>
    <div class="da-panel-body" data-da-panel-body></div>
    <footer class="da-panel-footer" data-da-panel-footer hidden></footer>
  </section>
<?php endif; ?>
</div>
<?php if($error===''): ?><script src="<?= dmd_animals_h($base) ?>/dmd-animals.js?v=<?= dmd_animals_h(DMD_ANIMALS_VERSION) ?>"></script><?php endif; ?>
