<?php
/** DMD-EAT · fiche PDF illustrée, autonome, sans Composer (PHP 7.4+). */
function eat_pdf_text($str) {
    $str = html_entity_decode(strip_tags((string)$str), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $str = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u','',$str);
    $str = str_replace(["\r","\t","\xC2\xA0"],['',' ',' '],(string)$str);
    $s = @iconv('UTF-8','Windows-1252//TRANSLIT//IGNORE',$str);
    return is_string($s) ? $s : preg_replace('/[^\x20-\x7e\n]/','?', $str);
}
function eat_pdf_escape($s) { return str_replace(['\\','(',')',"\r","\n"],['\\\\','\\(','\\)',' ',' '],$s); }
function eat_pdf_lines($str, $width, $size=10) {
    // Découpage selon la largeur typographique approximative de Helvetica (WinAnsi).
    $max = max(8,(int)floor($width / ($size * .54)));
    $all=[];
    foreach (explode("\n", str_replace("\r",'',(string)$str)) as $row) {
        $line='';
        foreach (preg_split('/\s+/u', trim($row)) as $word) {
            if ($word==='') continue;
            $word = trim($word);
            while (strlen(eat_pdf_text($word)) > $max) {
                if ($line!=='') {$all[]=$line; $line='';}
                $bytes = eat_pdf_text($word);
                $first = substr($bytes,0,$max-1);
                $reencoded = @iconv('Windows-1252','UTF-8//IGNORE',$first);
                if (!$reencoded) break;
                $all[]=$reencoded.'-';
                $word = (string)@iconv('Windows-1252','UTF-8//IGNORE',substr($bytes,$max-1));
            }
            $next=$line===''?$word:($line.' '.$word);
            if (strlen(eat_pdf_text($next))>$max && $line!=='') {$all[]=$line;$line=$word;}
            else $line=$next;
        }
        if ($line!=='') $all[]=$line;
    }
    return $all;
}

/** Récupère une photo distante publique, vérifie les redirections et fixe l'adresse DNS. */
function eat_pdf_fetch_image($url, $referer = '') {
    if (!is_string($url) || strlen($url)>1600 || !function_exists('curl_init')) return null;
    for ($hop=0;$hop<3;$hop++) {
        $p=@parse_url($url);
        if (!is_array($p) || !in_array(strtolower((string)($p['scheme']??'')),['http','https'],true)
            || empty($p['host']) || isset($p['user']) || isset($p['pass']) || isset($p['port'])) return null;
        $host=strtolower(rtrim($p['host'],'.'));
        if (!preg_match('/^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/',$host) || filter_var($host,FILTER_VALIDATE_IP)) return null;
        $ips=@gethostbynamel($host);
        if (!is_array($ips) || !$ips) return null;
        foreach ($ips as $ip) if (!eat_public_ipv4($ip)) return null;
        $port=strtolower($p['scheme'])==='https'?443:80;
        $ch=curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_HEADER=>true, CURLOPT_FOLLOWLOCATION=>false,
            CURLOPT_CONNECTTIMEOUT=>4, CURLOPT_TIMEOUT=>10, CURLOPT_MAXREDIRS=>0,
            CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2,
            CURLOPT_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS, CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4,
            CURLOPT_RESOLVE=>[$host.':'.$port.':'.$ips[0]],
            CURLOPT_USERAGENT=>'DoMyDesk-EAT/1.1 (recipe photo)',
            CURLOPT_REFERER=>(is_string($referer) && preg_match('~^https?://~i',$referer)) ? $referer : '',
            CURLOPT_HTTPHEADER=>['Accept: image/jpeg,image/png,image/webp,image/*;q=0.8'],
            CURLOPT_NOPROGRESS=>false,
            CURLOPT_PROGRESSFUNCTION=>static function($resource,$total,$received,$ut,$un){return $received>4000000 ? 1 : 0;}
        ]);
        $data=curl_exec($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
        $hsize=(int)curl_getinfo($ch,CURLINFO_HEADER_SIZE);curl_close($ch);
        if (!is_string($data)) return null;
        $headers=substr($data,0,$hsize);$bytes=substr($data,$hsize);
        if ($code>=300 && $code<400 && preg_match('~^location:\s*(.+)$~im',$headers,$m)) {
            $new=eat_absolute_url(trim($m[1]),$url);
            if (!$new || $new===$url) return null;
            $url=$new; continue;
        }
        if ($code!==200 || strlen($bytes)>4000000 || strlen($bytes)<100) return null;
        $info=@getimagesizefromstring($bytes);
        if (!$info || $info[0]<1 || $info[1]<1 || $info[0]*$info[1]>16000000) return null;
        if ($info[2]===IMAGETYPE_JPEG && ($info['channels']??3)===3) return $bytes;
        // Pour PNG/WEBP/JPEG CMYK, GD est utilisé uniquement s'il est déjà installé.
        if (function_exists('imagecreatefromstring') && function_exists('imagejpeg')) {
            $src=@imagecreatefromstring($bytes);
            if (!$src) return null;
            $scale=min(1,1600/max(imagesx($src),imagesy($src)));
            $w=max(1,(int)round(imagesx($src)*$scale)); $h=max(1,(int)round(imagesy($src)*$scale));
            $dst=imagecreatetruecolor($w,$h);
            imagefill($dst,0,0,imagecolorallocate($dst,255,255,255));
            imagecopyresampled($dst,$src,0,0,0,0,$w,$h,imagesx($src),imagesy($src));
            ob_start(); imagejpeg($dst,null,82); $jpg=ob_get_clean();
            imagedestroy($dst); imagedestroy($src);
            return is_string($jpg) && strlen($jpg)>100 ? $jpg : null;
        }
        return null;
    }
    return null;
}

class EatPdfLayout {
    private $pages=[];
    private $page='';
    private $photo=null;
    private $photoW=0;
    private $photoH=0;
    const HEIGHT = 841.89;

    public function __construct($photo) {
        if (is_string($photo) && strlen($photo)>100) {
            $i=@getimagesizefromstring($photo);
            if ($i && $i[2]===IMAGETYPE_JPEG && ($i['channels']??3)===3) {
                $this->photo=$photo; $this->photoW=$i[0]; $this->photoH=$i[1];
            }
        }
    }
    private function rgb($hex) {
        $hex=ltrim($hex,'#');
        return sprintf('%.3f %.3f %.3f',hexdec(substr($hex,0,2))/255,hexdec(substr($hex,2,2))/255,hexdec(substr($hex,4,2))/255);
    }
    public function rect($x,$top,$w,$h,$color) {
        $this->page.=$this->rgb($color)." rg ".sprintf('%.2f %.2f %.2f %.2f',$x,self::HEIGHT-$top-$h,$w,$h)." re f\n";
    }
    public function rule($x,$top,$w,$color='#E0E6EC') {$this->rect($x,$top,$w,.8,$color);}
    public function text($str,$x,$top,$size=10,$bold=false,$color='#182A3B') {
        $bytes=eat_pdf_escape(eat_pdf_text($str));
        $this->page.='BT /'.($bold?'F2':'F1').' '.sprintf('%.2f',$size).' Tf '.$this->rgb($color).' rg '.sprintf('%.2f %.2f',$x,self::HEIGHT-$top-$size).' Td ('.$bytes.") Tj ET\n";
    }
    public function lines($s,$x,$top,$width,$font=10,$lh=15,$bold=false,$color='#25394B') {
        foreach(eat_pdf_lines($s,$width,$font) as $ln) {$this->text($ln,$x,$top,$font,$bold,$color);$top+=$lh;}
        return $top;
    }
    public function page() {
        if ($this->page!=='') $this->pages[]=$this->page;
        $this->page='';
        $this->rect(0,0,595.28,841.89,'#FFFFFF');
        $this->rect(0,0,595.28,6,'#D69E33');
        $this->rect(38,26,27,27,'#14283A');
        $this->text('E',46,29,17,true,'#F3B94D');
        $this->text('DMD-EAT',75,30,13,true,'#14283A');
        $this->text('LA BIBLIOTHÈQUE CULINAIRE',390,34,8,true,'#698092');
        $this->rule(38,62,519);
    }
    public function image($x,$top,$w,$h) {
        if (!$this->photo) return;
        $iw=$this->photoW; $ih=$this->photoH;
        $scale=min($w/$iw,$h/$ih);$dw=$iw*$scale;$dh=$ih*$scale;
        $px=$x+($w-$dw)/2; $py=self::HEIGHT-$top-($h+$dh)/2;
        $this->page.='q '.sprintf('%.3f 0 0 %.3f %.3f %.3f',$dw,$dh,$px,$py)." cm /Im1 Do Q\n";
    }
    public function footer($p,$total) {
        $this->rule(38,807,519);
        $this->text('DoMyDesk  /  DMD-EAT   ·   Fiche recette sauvegardée',38,816,8,false,'#698092');
        $this->text('PAGE '.$p.' / '.$total,507,816,8,true,'#698092');
    }
    public function build() {
        if ($this->page!=='') {$this->pages[]=$this->page;$this->page='';}
        $n=count($this->pages);$hasImage=$this->photo!==null;
        $objs=[1=>'<< /Type /Catalog /Pages 2 0 R >>',
               3=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
               4=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'];
        $first=$hasImage?6:5;
        if ($hasImage) $objs[5]='<< /Type /XObject /Subtype /Image /Width '.$this->photoW.' /Height '.$this->photoH.' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '.strlen($this->photo)." >>\nstream\n".$this->photo."\nendstream";
        $kids=[];
        foreach($this->pages as $i=>$raw) {
            $no=$first+$i*2;$stream=$no+1;$kids[]=$no.' 0 R';
            $xobject=$hasImage?' /XObject << /Im1 5 0 R >>':'';
            $objs[$no]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /Font << /F1 3 0 R /F2 4 0 R >>'.$xobject.' >> /Contents '.$stream.' 0 R >>';
            // Ajout du pied de page dans le flux final (numérotation après pagination).
            $footer="0.863 0.894 0.925 rg 38 34 519 0.8 re f\n";
            $footer.='BT /F1 8 Tf 0.41 0.50 0.57 rg 38 17 Td (DoMyDesk / DMD-EAT - Fiche recette sauvegardee) Tj ET' ."\n";
            $footer.='BT /F2 8 Tf 0.41 0.50 0.57 rg 508 17 Td (PAGE '.($i+1).' / '.$n.") Tj ET\n";
            $body=$raw.$footer;
            $objs[$stream]='<< /Length '.strlen($body)." >>\nstream\n".$body."endstream";
        }
        $objs[2]='<< /Type /Pages /Kids [ '.implode(' ',$kids).' ] /Count '.$n.' >>';
        ksort($objs);$pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$positions=[0=>0];
        foreach($objs as $id=>$obj) {$positions[$id]=strlen($pdf);$pdf.=$id." 0 obj\n".$obj."\nendobj\n";}
        $max=max(array_keys($objs));$start=strlen($pdf);$pdf.="xref\n0 ".($max+1)."\n0000000000 65535 f \n";
        for($i=1;$i<=$max;$i++) $pdf.=sprintf('%010d 00000 n ',(int)($positions[$i]??0))."\n";
        $pdf.="trailer\n<< /Size ".($max+1)." /Root 1 0 R >>\nstartxref\n".$start."\n%%EOF\n";
        return $pdf;
    }
    public function hasPhoto() {return $this->photo!==null;}
}
function eat_make_pdf($rec,$jpeg=null) {
    $doc=new EatPdfLayout($jpeg);$doc->page();
    $title=trim((string)($rec['title']??'Recette'));if($title==='')$title='Recette';
    $category=function_exists('eat_recipe_category')?eat_recipe_category($rec):($rec['category']??'Recette');
    $hasPhoto=$doc->hasPhoto();
    $heroX=38;$heroTop=73;$heroW=519;
    $leftX=53;$titleWidth=$hasPhoto?335:485;
    $titleLines=eat_pdf_lines($title,$titleWidth,19);
    $description=eat_pdf_lines((string)($rec['description']??''),$titleWidth,9.1);
    $description=array_slice($description,0,22);
    $leftHeight=38+count($titleLines)*24+($description?12+count($description)*13:0);
    $heroH=max($hasPhoto?147:108,$leftHeight+9);
    $heroH=min($heroH,425);
    $doc->rect($heroX,$heroTop,$heroW,$heroH,'#F2F5F7');
    $doc->rect($heroX,$heroTop,3,$heroH,'#D4A04B');
    $doc->text(strtoupper($category).'  /  '.strtoupper((string)($rec['source']??'RECETTE')),53,$heroTop+12,8,true,'#B17820');
    $yy=$heroTop+33;
    foreach($titleLines as $ln) {$doc->text($ln,53,$yy,19,true,'#132C42');$yy+=24;}
    if($description) {
        $yy+=8;
        foreach($description as $ln) {$doc->text($ln,53,$yy,9.1,false,'#5C6B79');$yy+=13;}
    }
    if($hasPhoto) {
        $doc->rect(414,$heroTop+12,130,123,'#E4EBF0');
        $doc->image(416,$heroTop+14,126,119);
    }
    $meta=[];
    foreach(['servings'=>'PORTIONS','prep'=>'PRÉPARATION','cook'=>'CUISSON','total'=>'TEMPS TOTAL'] as $key=>$label) {
        if(!empty($rec[$key])) $meta[]=$label.' : '.$rec[$key];
    }
    $y=$heroTop+$heroH+13; $x=38;
    foreach($meta as $pill) {
        $width=min(519,max(96,strlen(eat_pdf_text($pill))*5.2+21));
        if($x+$width>557){$x=38;$y+=27;}
        $doc->rect($x,$y,$width,22,'#ECF1F4');
        $doc->text($pill,$x+9,$y+5.5,8.4,true,'#405D72');$x+=$width+7;
    }
    $y+=count($meta)?39:12;
    $ingredients=is_array($rec['ingredients']??null)?$rec['ingredients']:[];
    $steps=is_array($rec['steps']??null)?$rec['steps']:[];
    if(!$ingredients)$ingredients=['Ingrédients non renseignés'];
    if(!$steps)$steps=['Étapes non renseignées'];
    $left=[];$right=[];
    foreach($ingredients as $a) {
        if(!is_scalar($a))continue;
        $lines=eat_pdf_lines((string)$a,169,9.2);
        if($lines)$left[]=$lines;
    }
    foreach($steps as $a) {
        if(!is_scalar($a))continue;
        $lines=eat_pdf_lines((string)$a,263,9.5);
        if($lines)$right[]=$lines;
    }
    $leftIdx=0;$rightIdx=0;$leftOffset=0;$rightOffset=0;$attempt=0;
    while(($leftIdx<count($left) || $rightIdx<count($right)) && $attempt++<90) {
        if($y>700){$doc->page();$y=81;}
        $start=$y;$end=783;$contentTop=$start+40;
        // Hauteur adaptée aux recettes courtes ; une recette longue garde la page entière.
        $needL=0; for($k=$leftIdx;$k<count($left);$k++) $needL+=(count($left[$k])-($k===$leftIdx?$leftOffset:0))*13+8;
        $needR=0; for($k=$rightIdx;$k<count($right);$k++) $needR+=(count($right[$k])-($k===$rightIdx?$rightOffset:0))*14.3+9;
        $end=min(783,max($start+103,$contentTop+max($needL,$needR)+23));
        if ($leftIdx<count($left)) $doc->rect(38,$start,199,$end-$start,'#F6F8FA');
        $doc->rect(248,$start,309,$end-$start,'#F6F8FA');
        if ($leftIdx<count($left)) $doc->rect(38,$start,199,31,'#E9EFF3');
        $doc->rect(248,$start,309,31,'#E9EFF3');
        if ($leftIdx<count($left)) $doc->rect(38,$start,3,31,'#D4A04B');
        $doc->rect(248,$start,3,31,'#D4A04B');
        if ($leftIdx<count($left)) $doc->text('INGRÉDIENTS'.($leftIdx?' - SUITE':''),51,$start+9,10,true,'#173A55');
        $doc->text('PRÉPARATION'.($rightIdx?' - SUITE':''),261,$start+9,10,true,'#173A55');
        $yl=$contentTop;$yr=$contentTop;
        while($leftIdx<count($left)) {
            $lines=$left[$leftIdx];
            while($leftOffset<count($lines) && $yl+12<$end-10) {
                if($leftOffset===0) $doc->rect(50,$yl+6,4,4,'#D4A04B');
                $doc->text($lines[$leftOffset],60,$yl,9.2,false,'#273C4B');$yl+=13;$leftOffset++;
            }
            if($leftOffset<count($lines)) break;
            $leftIdx++;$leftOffset=0;$yl+=8;
            if($yl+12>=$end-10) break;
        }
        while($rightIdx<count($right)) {
            $lines=$right[$rightIdx];
            while($rightOffset<count($lines) && $yr+12<$end-10) {
                if($rightOffset===0) $doc->text(sprintf('%02d',$rightIdx+1),261,$yr,9.5,true,'#B17A29');
                $doc->text($lines[$rightOffset],284,$yr,9.5,false,'#273C4B');$yr+=14.3;$rightOffset++;
            }
            if($rightOffset<count($lines)) break;
            $rightIdx++;$rightOffset=0;$yr+=9;
            if($yr+12>=$end-10) break;
        }
        if($leftIdx>=count($left) && $rightIdx>=count($right)) {
            $y=max($yl,$yr)+14;
            break;
        }
        $doc->page();$y=81;
    }
    if(!empty($rec['url'])) {
        $source=eat_pdf_lines('Source : '.$rec['url'],506,8);
        if($y+18+count($source)*12>782){$doc->page();$y=83;}
        $doc->rule(38,$y,519);$y+=10;
        foreach($source as $line){$doc->text($line,43,$y,8,false,'#617C8A');$y+=12;}
    }
    return $doc->build();
}
