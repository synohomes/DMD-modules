<?php
/** Contrat sortant pour un module « Liste de courses » indépendant (aucune écriture ailleurs). */
function eat_shopping_fold($s) {
    $s=trim((string)$s);
    $s=function_exists('mb_strtolower')?mb_strtolower($s,'UTF-8'):strtolower($s);
    return trim(preg_replace('/\s+/u',' ',$s));
}
function eat_shopping_ingredient($text) {
    $text=trim((string)$text);
    $fraction=['½'=>'0.5','¼'=>'0.25','¾'=>'0.75'];
    $text=strtr($text,$fraction);
    // Exemple : 200 g de farine, 2 oeufs, 1,5 L de lait, 1 c. à soupe de sucre.
    // Extraire le nombre puis reconnaître explicitement l’unité afin de ne pas confondre « oeufs » avec une unité.
    if(!preg_match('/^([0-9]+(?:[.,][0-9]+)?)(?:\s+|$)(.*)$/u',$text,$n)) return ['name'=>$text,'quantity'=>null,'unit'=>'','raw'=>$text];
    $qty=(float)str_replace(',','.',$n[1]);$rest=trim($n[2]);$unit='pièce';
    $units=[
      ['~^(kg|kilogrammes?)\b\.?\s*~iu','g',1000],
      ['~^(g|gr|grammes?)\b\.?\s*~iu','g',1],
      ['~^(litres?|l)\b\.?\s*~iu','ml',1000],
      ['~^(dl)\b\.?\s*~iu','ml',100],
      ['~^(cl)\b\.?\s*~iu','ml',10],
      ['~^(ml|millilitres?)\b\.?\s*~iu','ml',1],
      ['~^(c\.?\s*à\s*soupe|cuill[eè]res?\s*à\s*soupe|cas)\b\.?\s*~iu','c. à soupe',1],
      ['~^(c\.?\s*à\s*caf[eé]|cuill[eè]res?\s*à\s*caf[eé]|cac)\b\.?\s*~iu','c. à café',1],
      ['~^(bo[iî]tes?|sachets?|pots?|bocaux|pinc[eé]es?|poign[eé]es?|tranches?|gousses?|branches?|bottes?)\b\s*~iu',null,1],
    ];
    foreach($units as $u) {
        if(preg_match($u[0],$rest,$match)) {
            $rest=trim(substr($rest,strlen($match[0])));
            $unit=$u[1]??eat_shopping_fold(trim($match[1]));
            $qty*=$u[2];break;
        }
    }
    $rest=preg_replace('/^(de\s+la\s+|de\s+l[’\']|de\s+|du\s+|des\s+|d[’\'])/iu','',$rest);
    $name=trim($rest);
    if($name==='') return ['name'=>$text,'quantity'=>null,'unit'=>'','raw'=>$text];
    return ['name'=>$name,'quantity'=>$qty,'unit'=>$unit,'raw'=>$text];
}
function eat_shopping_export($selection) {
    if(!is_array($selection) || !$selection || count($selection)>30) throw new InvalidArgumentException('Sélectionnez entre 1 et 30 recettes.');
    $used=[];$recipes=[];$groups=[];
    foreach($selection as $entry) {
        if(!is_array($entry)) throw new InvalidArgumentException('Sélection invalide.');
        $id=(string)($entry['id']??'');
        if(!preg_match('/^[a-f0-9]{24}$/D',$id) || isset($used[$id])) throw new InvalidArgumentException('Identifiant de recette invalide ou en double.');
        $used[$id]=true;
        $r=eat_find_saved($id);if(!$r) throw new InvalidArgumentException('Une recette sélectionnée est introuvable.');
        $desired=filter_var($entry['servings']??null,FILTER_VALIDATE_INT);
        if(!$desired || $desired<1 || $desired>100) throw new InvalidArgumentException('Nombre de personnes invalide (1 à 100).');
        $original=null;
        if(preg_match('/(\d+(?:[.,]\d+)?)/u',(string)($r['servings']??''),$serv)) {
            $original=(float)str_replace(',','.',$serv[1]);
            if($original<=0) $original=null;
        }
        $factor=$original!==null?$desired/$original:1.0;
        $recipes[]=['id'=>$id,'title'=>$r['title'],'source'=>$r['source']??'', 'original_servings'=>$original,'target_servings'=>$desired,'scaled'=>$original!==null];
        foreach(array_slice($r['ingredients']??[],0,150) as $raw) {
            if(!is_string($raw) || trim($raw)==='') continue;
            $item=eat_shopping_ingredient($raw);
            $name=eat_shopping_fold($item['name']);
            $quantity=$item['quantity']!==null?round($item['quantity']*$factor,3):null;
            $key=$name.'|'.$item['unit'].'|'.($quantity===null?'unknown':'number');
            if(!isset($groups[$key])) $groups[$key]=['name'=>$item['name'],'quantity'=>$quantity,'unit'=>$item['unit'],
                'sources'=>[],'original_ingredients'=>[],'in_stock'=>false,'requires_review'=>($original===null || $quantity===null)];
            elseif($quantity!==null) $groups[$key]['quantity']=round($groups[$key]['quantity']+$quantity,3);
            $groups[$key]['sources'][]=$id;
            $groups[$key]['original_ingredients'][]=$item['raw'];
            if($original===null) $groups[$key]['requires_review']=true;
        }
    }
    $items=[];
    foreach($groups as $key=>$item) {
        $item['sources']=array_values(array_unique($item['sources']));
        $item['original_ingredients']=array_values(array_unique($item['original_ingredients']));
        $item['id']=substr(hash('sha256',$key),0,16);
        $items[]=$item;
    }
    usort($items,static function($a,$b){return strcoll(eat_shopping_fold($a['name']),eat_shopping_fold($b['name']));});
    return ['schema'=>'dmd.shopping-list.v1','source_module'=>'DMD-EAT','generated_at'=>date('c'),
       'recipes'=>$recipes,'items'=>$items];
}
