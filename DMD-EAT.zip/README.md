# DMD-EAT 1.2.0

Module culinaire pour DoMyDesk 1.4.0 : rechercher des recettes sur des sites administrés, consulter les fiches Recipe (JSON-LD) et sauvegarder une fiche PDF A4 illustrée et mise en page sans bibliothèque externe.

## Installation
Importer l'archive ZIP via la gestion des modules DoMyDesk. Aucun fichier du Core/Agent n'est modifié. Le Core gère l'affectation du module aux utilisateurs. La page de configuration est réservée aux administrateurs DoMyDesk.

## Stockage
- **Public** (réglage initial) : `data/modules/DMD-EAT/recettes/` pour tous les membres autorisés.
- **Privé** : `users/profiles/<clé-compte>/modules/DMD-EAT/recettes/` pour chaque compte.
- Les réglages (partagés) : `data/modules/DMD-EAT/cfg/settings.json`.
- Un `.json` (métadonnées) + un `.pdf` par recette, ainsi qu’une photo `.jpg` si disponible ; duplication d'URL évitée.
- Lecture/écriture des PDF seulement via API authentifiée : aucun lien direct vers les dossiers de données.
- Une modification public/privé **ne transfère pas** les recettes existantes, afin de préserver la confidentialité.

## Sites compatibles
Le site doit avoir un moteur de recherche HTML côté serveur avec des liens vers ses recettes, ainsi que des fiches `schema.org/Recipe` en JSON-LD comprenant ingrédients et/ou étapes. Dans l'administration, fournir un nom et un modèle d'URL contenant exactement `{query}` (ex. `https://www.exemple.com/?s={query}`). Le domaine hôte est verrouillé par source. Un site dont la recherche utilise exclusivement JavaScript, nécessite une session ou refuse l'accès automatisé pourra ne pas retourner de résultats. Le module affiche alors une erreur par source au lieu d'inventer des fiches.

La source initiale est **Marmiton**, activée ; elle est modifiable ou supprimable. Les autres sources sont configurables dans l'administration. La disponibilité dépend des règles des sites externes.

PHP 7.4+ avec extensions **cURL**, **DOM/XML**, **iconv** et **OpenSSL/TLS** (habituellement déjà présentes sur une installation PHP web complète). Aucune installation de service externe, aucun Node/Docker/Composer, aucune API payante.

## Sécurité
Autorisation module via le Core DoMyDesk et gestion des profils ; pages d'administration réservées au rôle administrateur ; CSRF sur toutes modifications ; téléchargements PDF soumis aux droits ; les URL des recettes sont limitées au domaine source ; DNS vers IP non publiques rejeté et résolution fixée dans cURL (anti SSRF) ; redirections croisées refusées ; requêtes extérieures limitées en durée/taille ; échappement HTML côté interface.

**Limite de confiance** : en mode public, chaque membre autorisé peut enregistrer les recettes ; leur suppression est réservée à l’auteur ou à un administrateur. Les rôles fins sont disponibles dans les métadonnées pour intégration Core, mais cette version applique l'autorisation générale du module sur ces actions.

## Test minimal
1. Dans le menu configuration DMD-EAT, vérifier le mode et la source active.
2. Rechercher une recette ; ouvrir une vignette ; vérifier ingrédients et préparation.
3. Cliquer « Enregistrer en PDF ». Voir la recette dans la bibliothèque.
4. Tester ouverture/téléchargement/suppression PDF depuis deux comptes en mode public.
5. Passer en privé et vérifier la séparation des bibliothèques de chaque compte.

## Nouveautés 1.1.0
- Bibliothèque compacte : vignettes horizontales, photos pleine vignette, regroupement par catégories et filtres avec compteurs.
- Catégorisation depuis `recipeCategory` des sites, et classement de secours pour les anciennes recettes.
- Correction manuelle de la catégorie par l'auteur ou un administrateur (mode public), par l'utilisateur en mode privé.
- Nouvelle mise en page PDF A4 avec photo, catégories, temps, ingrédients en colonne, étapes numérotées, pagination.
- Régénération automatique des PDF précédents au premier accès, sans perdre la fiche JSON enregistrée.
- Impression depuis la fiche recette, sans passer par le PDF.
- Les photos sont récupérées au moment de la sauvegarde ; JPEG natif pris en charge, PNG/WEBP si GD est disponible sur le serveur. Si une source refuse la récupération d'image, le PDF reste disponible sans photo.
- Aucun changement du Core DoMyDesk, du stockage public/privé ou des droits de base.

## DMD-EAT 1.2.0 — Refonte de la bibliothèque
- Cartes lisibles : deux colonnes dans les fenêtres DoMyDesk d'environ 700 px, disposition adaptative aux autres tailles.
- Photos carrées recadrées sans déformation, titres sur trois lignes, source et date alignées.
- Catégories ordonnées avec filtres compacts, titres de section discrets, suppression de la catégorie doublonnée dans chaque carte.
- Recherche multi-sites, PDF, impression, droits et sauvegardes inchangés.
- Mise à jour par-dessus la 1.1.0 : ne supprime pas les données stockées.

## 1.2.1 : correction de la bibliothèque
- Suppression des cartes étirées sur toute la ligne quand la catégorie a un nombre impair de recettes.
- Grille régulière sur la largeur réelle de la fenêtre du module (1, 2, 3 ou 4 colonnes).
- Cartes compactes de 80 px, photos recadrées, titres et métadonnées alignés.
- Corrections limitées aux styles de la bibliothèque ; aucune modification du fonctionnement de la recherche, des sauvegardes, de l'impression ou du PDF.
- Installer par-dessus la version existante ; aucune donnée n'est supprimée.

## DMD-EAT 1.3.0 — Catégories personnalisables

- Administration > Catégories de recettes : ajouter, renommer et supprimer des catégories (30 maximum).
- Supprimer une catégorie propose une catégorie de destination, sans effacer ni déplacer les recettes ni leurs photos.
- Les recettes déjà sauvegardées sont automatiquement présentées sous le nouveau classement, y compris dans les bibliothèques privées.
- Les PDF sauvegardés sont actualisés à leur prochaine ouverture si le classement a changé.
- La catégorie « Autres recettes » reste disponible comme catégorie de secours.
- Le classement des recettes se fait depuis leur fiche. Lorsque plus de cinq catégories contiennent des recettes, le filtre utilise une liste déroulante compacte.
- Configuration mise à jour sans écraser les sites ou le mode public/privé existants ; aucune migration manuelle.


## DMD-EAT 1.4.0 — Recettes personnelles et passerelle vers les courses

### Recettes personnelles
- Bouton **+ Ma recette** : création libre depuis la recherche ou la bibliothèque, sans site externe.
- Titre, description, catégorie administrée, nombre de personnes, préparation, cuisson, ingrédients et étapes (une ligne par élément).
- Photo locale facultative JPG ; PNG/WEBP si l'extension GD est disponible ; 4 Mo maximum, dimensions limitées.
- Génération du même PDF illustré A4 que pour les recettes des sites, visible et téléchargeable depuis la fiche.
- Auteur (ou administrateur en mode public) : modification du texte, changement de photo, de catégorie et suppression.
- Les recettes restent dans la bibliothèque publique ou privée **déjà configurée**, avec les mêmes droits ; aucune migration.
- Les photos personnelles sont servies par l'API authentifiée `action=photo` et ne sont pas exposées par un chemin public.

### Passerelle Liste de courses (autre module)
- Dans **Bibliothèque**, bouton « Liste de courses » pour sélectionner une ou plusieurs recettes déjà enregistrées (30 au maximum).
- Paramétrage du nombre de personnes pour chaque recette ; calcul des ingrédients, conversion de `kg → g`, `l/cl/dl → ml`, regroupement des noms et unités identiques.
- Cases à cocher « déjà en stock » ; les articles sont conservés avec `in_stock:true` ou `false` dans l'export.
- Les quantités ambiguës ou les recettes dont le nombre initial de parts est inconnu portent `requires_review:true` : aucune fausse précision n'est présentée.
- **Contrat JSON pour un module destinataire** : le POST authentifié `DMD-EAT_api.php?action=shopping_export`, avec CSRF et `selection` JSON `[{"id":"<id recette>","servings":4}]`, retourne `shopping` au format `dmd.shopping-list.v1`, contenant `source_module`, `generated_at`, `recipes`, `items` (nom, quantité, unité, provenance et révision éventuelle).
- L'interface fournit aussi le téléchargement de ce JSON ; **aucun module extérieur n'est modifié** ni supposé exister. Le raccordement direct, son enregistrement et sa liste de courses persistante seront implémentés côté module destinataire lorsqu'il sera identifié/fourni.
- Les quantités sont une aide pratique : vérifier unités non standards, ingrédients rédigés librement et arrondis avant les achats.

### Mise à jour
Importer le ZIP 1.4.0 par-dessus 1.3.0. Le Core DoMyDesk, l'Agent, les données sauvegardées, les recherches multi-sites, l'administration des catégories et les anciens PDF restent inchangés. En cas de code JavaScript déjà chargé dans une session, actualiser la fenêtre du module.
