/* DMD-EAT · interface module + administration ; aucun framework ni dépendance */
(function () {
'use strict';
const esc = v => String(v == null ? '' : v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const attr = esc;
const safeImage = u => /^https?:\/\//i.test(String(u || '')) ? String(u) : '';
let categories=['Apéritifs','Entrées','Soupes','Plats','Accompagnements','Desserts','Boulangerie','Boissons','Autres recettes'];
const setCategories = value => { if(Array.isArray(value) && value.every(x=>typeof x==='string' && x.length>0) && value.includes('Autres recettes')) categories=value.slice(); };
const recipeCategory = r => categories.includes(r.category) ? r.category : 'Autres recettes';
const date = s => { try {return new Date(s).toLocaleDateString('fr-FR');} catch(_){return '';} };
const find = (el,q) => el.querySelector(q);
function factory(root){
 const base = root.dataset.base, token = root.dataset.csrf, api = base + '/DMD-EAT_api.php';
 const noticeEl = find(root,'[data-eat-notice]');
 const notice = (str,error=false) => { noticeEl.textContent=str; noticeEl.classList.toggle('is-error',!!error);noticeEl.hidden=!str; };
 async function req(action, data, params={}) {
   const url = new URL(api,location.href);url.searchParams.set('action',action);
   Object.entries(params).forEach(([k,v])=>url.searchParams.set(k,String(v)));
   const opt = {credentials:'same-origin', cache:'no-store'};
   if (data) {const body=data instanceof FormData?data:new URLSearchParams();if(!(data instanceof FormData))Object.entries(data).forEach(([k,v])=>body.set(k,String(v)));body.set('csrf',token);opt.method='POST';opt.body=body;}
   const response = await fetch(url.toString(), opt);
   const json = await response.json().catch(()=>({ok:false,message:'Réponse serveur invalide.'}));
   if(!response.ok || !json.ok) throw new Error(json.message || ('HTTP '+response.status));
   return json;
 }
 return {base,api,root,req,notice};
}
function card(item,saved,selecting=false,selected=false){
 const image=safeImage(item.image), id=saved?String(item.id||''):'';
 const imageHtml=image?'<img src="'+attr(image)+'" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.hidden=true">':'';
 const body='<button type="button" class="eat-card" title="'+attr(item.title)+'" '+(saved?'data-eat-open-saved="'+attr(id)+'"':'data-eat-open-url="'+attr(item.url||'')+'"')+'><span class="eat-card-visual">'+imageHtml+'<span class="eat-card-glyph" aria-hidden="true"><svg viewBox="0 0 24 24" width="25" height="25" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round"><path d="M6 13.9a4 4 0 0 1-1.3-7.4 4.2 4.2 0 0 1 7.3-1.6A4.2 4.2 0 0 1 19 8a4 4 0 0 1-1 6v5H6z"/><path d="M6 17h12"/></svg></span></span><span class="eat-card-main"><strong>'+esc(item.title)+'</strong><span class="eat-card-bottom"><span>'+esc(item.source||'Recette')+'</span><span>'+(saved?esc(date(item.saved_at)):'Ouvrir →')+'</span></span>'+'</span></button>';
 return selecting&&saved?'<div class="eat-choice '+(selected?'is-selected':'')+'">'+body+'<label class="eat-choice-box" title="Sélectionner pour les courses"><input type="checkbox" data-eat-shopping-id="'+attr(id)+'" '+(selected?'checked':'')+'><span>Courses</span></label></div>':body;
}
function initMain(root){
 if(root.dataset.eatReady) return;root.dataset.eatReady='1';
 const {api,req,notice}=factory(root);
 let library=[],active='search',page=0,category='all',detail=null,detailSaved=false,searchResults=[];
 let shoppingSelecting=false,shoppingSelected=new Set(),shoppingPayload=null;
 const result = find(root,'[data-eat-results]'), lib = find(root,'[data-eat-library]'), modal=find(root,'[data-eat-modal]'), view=find(root,'[data-eat-detail]');
 const tabs = root.querySelectorAll('[data-eat-tab]');
 const perPage=24;
 const showTab = key => {active=key; tabs.forEach(btn=>btn.classList.toggle('active',btn.dataset.eatTab===key));root.querySelectorAll('[data-eat-panel]').forEach(panel=>panel.hidden=panel.dataset.eatPanel!==key);notice('');if(key==='library') loadLibrary();};
 tabs.forEach(btn=>btn.addEventListener('click',()=>showTab(btn.dataset.eatTab)));
 function renderLibrary(){
    const q=(find(root,'[data-eat-filter]').value||'').trim().toLocaleLowerCase('fr');
    const counts={};categories.forEach(c=>counts[c]=0);
    for(const item of library) counts[recipeCategory(item)]++;
    const chips=find(root,'[data-eat-categories]');
    const available=categories.filter(c=>counts[c]);
    if(category!=='all' && !categories.includes(category)) category='all';
    if(available.length>5) {
      chips.innerHTML='<label class="eat-category-select-label">Catégorie <select data-eat-category-select aria-label="Filtrer les recettes par catégorie">'+
        '<option value="all"'+(category==='all'?' selected':'')+'>Toutes les catégories ('+library.length+')</option>'+
        available.map(c=>'<option value="'+attr(c)+'"'+(category===c?' selected':'')+'>'+esc(c)+' ('+counts[c]+')</option>').join('')+'</select></label>';
    } else {
      chips.innerHTML='<button type="button" data-eat-category="all" class="'+(category==='all'?'active':'')+'">Toutes <b>'+library.length+'</b></button>'+
        available.map(c=>'<button type="button" data-eat-category="'+attr(c)+'" class="'+(category===c?'active':'')+'">'+esc(c)+' <b>'+counts[c]+'</b></button>').join('');
    }
    const filtered=library.filter(x=>(category==='all'||recipeCategory(x)===category) && (x.title+' '+x.source+' '+recipeCategory(x)).toLocaleLowerCase('fr').includes(q));
    const ordered=categories.flatMap(c=>filtered.filter(x=>recipeCategory(x)===c));
    const pages=Math.max(1,Math.ceil(ordered.length/perPage));page=Math.max(0,Math.min(page,pages-1));
    const slice=ordered.slice(page*perPage,(page+1)*perPage);
    const parts=[];
    for(const cat of categories){const items=slice.filter(x=>recipeCategory(x)===cat);if(!items.length)continue;
      parts.push('<section class="eat-category-section"><div class="eat-category-heading"><strong>'+esc(cat)+'</strong><span>'+items.length+' recette'+(items.length>1?'s':'')+'</span></div><div class="eat-grid">'+items.map(r=>card(r,true,shoppingSelecting,shoppingSelected.has(r.id))).join('')+'</div></section>');
    }
    lib.innerHTML=ordered.length?parts.join('')+(pages>1?'<div class="eat-pagination"><button type="button" data-eat-page="prev" '+(page===0?'disabled':'')+'>‹ Précédent</button><span>Page '+(page+1)+' / '+pages+'</span><button type="button" data-eat-page="next" '+(page>=pages-1?'disabled':'')+'>Suivant ›</button></div>':''):'<div class="eat-empty">Aucune recette dans cette catégorie.</div>';
    find(root,'[data-eat-lib-count]').textContent=filtered.length+' / '+library.length+' recettes';
 }
 const shopBar=find(root,'[data-eat-shop-toolbar]'),shopCount=find(root,'[data-eat-shop-count]');
 const shopButton=find(root,'[data-eat-shop-select]');
 const updateShopControls=()=>{
   shopBar.hidden=!shoppingSelecting;
   shopButton.classList.toggle('eat-btn-primary',shoppingSelecting);
   shopCount.textContent=shoppingSelected.size+' recette'+(shoppingSelected.size>1?'s':'')+' sélectionnée'+(shoppingSelected.size>1?'s':'');
   find(root,'[data-eat-shop-generate]').disabled=shoppingSelected.size===0;
 };
 shopButton.addEventListener('click',()=>{shoppingSelecting=!shoppingSelecting;if(!shoppingSelecting)shoppingSelected.clear();updateShopControls();renderLibrary();});
 find(root,'[data-eat-shop-cancel]').addEventListener('click',()=>{shoppingSelecting=false;shoppingSelected.clear();updateShopControls();renderLibrary();});
 find(root,'[data-eat-shop-generate]').addEventListener('click',()=>openShopping());
 lib.addEventListener('change',e=>{const input=e.target.closest('[data-eat-shopping-id]');if(!input)return;
   if(input.checked)shoppingSelected.add(input.dataset.eatShoppingId);else shoppingSelected.delete(input.dataset.eatShoppingId);
   input.closest('.eat-choice').classList.toggle('is-selected',input.checked);updateShopControls();
 });
 const catBar=find(root,'[data-eat-categories]');
 catBar.addEventListener('click',e=>{
   const b=e.target.closest('[data-eat-category]');if(!b)return;
   category=b.dataset.eatCategory;page=0;renderLibrary();
 });
 catBar.addEventListener('change',e=>{
   if(!e.target.matches('[data-eat-category-select]')) return;
   category=e.target.value;page=0;renderLibrary();
 });
 async function loadLibrary(){lib.innerHTML='<div class="eat-empty">Chargement de la bibliothèque…</div>';try {const data=await req('library');setCategories(data.categories);library=data.items||[];shoppingSelected=new Set([...shoppingSelected].filter(id=>library.some(r=>r.id===id)));updateShopControls();renderLibrary();}catch(e){lib.innerHTML='<div class="eat-empty eat-error">'+esc(e.message)+'</div>';}}
 find(root,'[data-eat-filter]').addEventListener('input',()=>{page=0;renderLibrary();});
 lib.addEventListener('click',e=>{const btn=e.target.closest('button');if(!btn)return; const step=btn.dataset.eatPage;
    if(step){page+=step==='next'?1:-1;renderLibrary();return;} const id=btn.dataset.eatOpenSaved;if(id)openSaved(id); });
 result.addEventListener('click',e=>{const btn=e.target.closest('[data-eat-open-url]');if(btn)openRemote(btn.dataset.eatOpenUrl);});
 find(root,'[data-eat-search]').addEventListener('submit',async e=>{
    e.preventDefault();const q=new FormData(e.currentTarget).get('q').trim();if(q.length<2)return;
    result.innerHTML='<div class="eat-empty"><span class="eat-spinner"></span> Recherche dans les sites configurés…</div>';notice('');
    const submit=e.currentTarget.querySelector('button[type="submit"]');submit.disabled=true;
    try {const data=await req('search',null,{q});searchResults=data.results||[];
         result.innerHTML=searchResults.length?searchResults.map(x=>card(x,false)).join(''):'<div class="eat-empty">Aucune recette trouvée. Vérifiez les sites activés ou modifiez les mots-clés.</div>';
         find(root,'[data-eat-count]').textContent=searchResults.length+' résultat'+(searchResults.length>1?'s':'');
         if(data.warnings?.length) notice('Certaines sources n’ont pas répondu : '+data.warnings.join(' · '),true);
    } catch(e) {result.innerHTML='<div class="eat-empty eat-error">Recherche impossible : '+esc(e.message)+'</div>';}
    finally{submit.disabled=false;}
 });
 function recipeHtml(r,saved,canDelete){
    const img=safeImage(r.image), meta=[r.servings&&'Portions : '+r.servings,r.prep&&'Préparation : '+r.prep,r.cook&&'Cuisson : '+r.cook,r.total&&'Total : '+r.total].filter(Boolean);
    const ingredients=Array.isArray(r.ingredients)?r.ingredients:[],steps=Array.isArray(r.steps)?r.steps:[];
    const url=/^https?:\/\//i.test(String(r.url||''))?r.url:'';
    return '<div class="eat-detail-title"><div><span class="eat-detail-source">'+esc(r.source||'Recette')+'</span><h2>'+esc(r.title)+'</h2>'+ (r.description?'<p>'+esc(r.description)+'</p>':'')+'</div>'+(img?'<img src="'+attr(img)+'" alt="" referrerpolicy="no-referrer" loading="lazy">':'')+'</div>'+
    '<div class="eat-recipe-class">'+esc(recipeCategory(r))+'</div>'+
    '<div class="eat-meta">'+meta.map(x=>'<span>'+esc(x)+'</span>').join('')+'</div>'+
    '<div class="eat-detail-cols"><section><h3>Ingrédients</h3><ul>'+ingredients.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul></section><section><h3>Préparation</h3><ol>'+steps.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ol></section></div>'+
    (saved&&canDelete?'<div class="eat-category-edit"><label for="eat-edit-cat">Classer dans</label><select id="eat-edit-cat" data-eat-change-category>'+categories.map(c=>'<option value="'+attr(c)+'" '+(recipeCategory(r)===c?'selected':'')+'>'+esc(c)+'</option>').join('')+'</select><button type="button" class="eat-btn eat-btn-small" data-eat-category-save="'+attr(r.id)+'">Modifier la catégorie</button></div>':'')+
    '<div class="eat-detail-actions">'+(saved?
     '<a class="eat-btn eat-btn-primary" href="'+attr(api+'?action=pdf&id='+encodeURIComponent(r.id))+'" target="_blank" rel="noopener">Voir le PDF</a><a class="eat-btn" href="'+attr(api+'?action=pdf&download=1&id='+encodeURIComponent(r.id))+'">Télécharger</a>'+(canDelete?((r.origin==='manual'?'<button type="button" class="eat-btn" data-eat-edit-manual>Modifier</button>':'')+'<button type="button" class="eat-btn eat-btn-danger" data-eat-delete="'+attr(r.id)+'">Supprimer</button>'):''):
     '<button type="button" class="eat-btn eat-btn-primary" data-eat-save="'+attr(r.url||'')+'">Enregistrer en PDF</button>')+'<button type="button" class="eat-btn" data-eat-print>Imprimer</button>'+(url?'<a class="eat-btn" target="_blank" rel="noopener noreferrer" href="'+attr(url)+'">Site d’origine ↗</a>':'')+'</div>';
 }
 function printRecipe(r){
   const w=window.open('','_blank','width=940,height=800');
   if(!w){notice('Le navigateur bloque la fenêtre d’impression.',true);return;}
   const img=safeImage(r.image),meta=[r.servings&&'Portions : '+r.servings,r.prep&&'Préparation : '+r.prep,r.cook&&'Cuisson : '+r.cook,r.total&&'Total : '+r.total].filter(Boolean);
   const ingredients=Array.isArray(r.ingredients)?r.ingredients:[],steps=Array.isArray(r.steps)?r.steps:[];
   const html='<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>'+esc(r.title)+' — DMD-EAT</title><style>'+
   '@page{size:A4;margin:14mm}*{box-sizing:border-box}body{margin:0;background:#fff;color:#193044;font:12px/1.5 Arial,sans-serif}'+
   '.top{display:flex;align-items:center;justify-content:space-between;border-bottom:2px solid #d8a344;padding:0 0 13px;margin-bottom:14px}.brand{font-weight:800;font-size:17px}.tag{font-size:10px;color:#90702f;text-transform:uppercase;letter-spacing:.06em}'+
   '.hero{display:flex;gap:18px;justify-content:space-between;align-items:flex-start;padding:17px;background:#f1f5f8;border-left:4px solid #d5a149;margin-bottom:12px;break-inside:avoid}.hero h1{font-size:23px;line-height:1.18;margin:5px 0 10px}.hero p{color:#596e7a;margin:0;white-space:pre-line}.hero img{width:175px;height:135px;object-fit:cover;border-radius:5px}'+
   '.meta{display:flex;flex-wrap:wrap;gap:7px;margin:0 0 16px}.meta span{padding:5px 9px;background:#edf2f5;font-size:11px;font-weight:600}'+
   '.cols{display:grid;grid-template-columns:39% 1fr;gap:12px;align-items:start}.cols section{padding:13px;background:#f6f8fa;border:1px solid #e1e8ec;border-radius:5px}.cols h2{font-size:14px;margin:-13px -13px 12px;background:#e7eef3;border-left:3px solid #d5a149;padding:10px 13px}.cols li{margin:0 0 9px;break-inside:avoid;overflow-wrap:anywhere}li::marker{color:#bb842d;font-weight:700}ul,ol{padding-left:19px;margin:0}.source{margin-top:15px;font-size:10px;color:#6c7c89;overflow-wrap:anywhere;border-top:1px solid #dae2e8;padding-top:8px}'+
   '@media print{.hero,.meta span,.cols section,.cols h2{-webkit-print-color-adjust:exact;print-color-adjust:exact}}'+
   '</style></head><body><header class="top"><span class="brand">DMD-EAT</span><span class="tag">Fiche recette · DoMyDesk</span></header>'+
   '<div class="hero"><div><div class="tag">'+esc(recipeCategory(r))+' · '+esc(r.source||'Recette')+'</div><h1>'+esc(r.title)+'</h1>'+(r.description?'<p>'+esc(r.description)+'</p>':'')+'</div>'+(img?'<img src="'+attr(img)+'" alt="Photo de la recette" referrerpolicy="no-referrer">':'')+'</div>'+
   '<div class="meta">'+meta.map(x=>'<span>'+esc(x)+'</span>').join('')+'</div>'+
   '<div class="cols"><section><h2>Ingrédients</h2><ul>'+ingredients.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul></section><section><h2>Préparation</h2><ol>'+steps.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ol></section></div>'+
   (r.url?'<footer class="source">Source : '+esc(r.url)+'</footer>':'')+
   '<script>window.addEventListener("load",function(){setTimeout(function(){window.focus();window.print();},450);});<\/script></body></html>';
   w.document.open();w.document.write(html);w.document.close();
 }
 async function openRemote(url){modal.hidden=false;view.innerHTML='<div class="eat-empty"><span class="eat-spinner"></span> Lecture de la recette…</div>';document.body.classList.add('eat-modal-open');
   try{ const data=await req('detail',null,{url});detail=data.recipe;detailSaved=false;view.innerHTML=recipeHtml(detail,false); }
   catch(e){view.innerHTML='<div class="eat-empty eat-error">'+esc(e.message)+'</div>';}
 }
 async function openSaved(id){modal.hidden=false;view.innerHTML='<div class="eat-empty">Chargement…</div>';document.body.classList.add('eat-modal-open');
    try {const data=await req('saved',null,{id});setCategories(data.categories);detail=data.recipe;detailSaved=true;view.innerHTML=recipeHtml(detail,true,!!data.can_delete);}
    catch(e){view.innerHTML='<div class="eat-empty eat-error">'+esc(e.message)+'</div>';}
 }
 function close(){modal.hidden=true;view.innerHTML='';document.body.classList.remove('eat-modal-open');}
 modal.querySelectorAll('[data-eat-close]').forEach(b=>b.addEventListener('click',close));
 root.addEventListener('keydown',e=>{if(e.key==='Escape' && !modal.hidden)close();});
 view.addEventListener('click',async e=>{
   const save=e.target.closest('[data-eat-save]'), del=e.target.closest('[data-eat-delete]'),print=e.target.closest('[data-eat-print]'),change=e.target.closest('[data-eat-category-save]');
   if(e.target.closest('[data-eat-edit-manual]') && detail && detail.origin==='manual'){openManual(detail);return;}
   const inStock=e.target.closest('[data-eat-in-stock]');if(inStock && shoppingPayload){const item=shoppingPayload.items[Number(inStock.dataset.eatInStock)];if(item)item.in_stock=!!inStock.checked;return;}
   if(e.target.closest('[data-eat-shopping-download]') && shoppingPayload){downloadShopping();return;}
   if(print && detail){printRecipe(detail);return;}
   if(change){const select=find(view,'[data-eat-change-category]');if(!select)return;change.disabled=true;
     try{await req('category_save',{id:change.dataset.eatCategorySave,category:select.value});detail.category=select.value;view.innerHTML=recipeHtml(detail,true,true);await loadLibrary();}
     catch(err){change.disabled=false;view.insertAdjacentHTML('beforeend','<p class="eat-inline-error">'+esc(err.message)+'</p>');}return;}
   if(save){save.disabled=true;save.textContent='Enregistrement…';try {const d=await req('save',{url:save.dataset.eatSave});close();notice(d.message);if(active==='library')loadLibrary();}
     catch(err){save.disabled=false;save.textContent='Enregistrer en PDF';view.insertAdjacentHTML('beforeend','<p class="eat-inline-error">'+esc(err.message)+'</p>');} }
   if(del){if(!window.confirm('Supprimer cette recette enregistrée et son PDF ?'))return;
     del.disabled=true;try {await req('delete',{id:del.dataset.eatDelete});close();notice('Recette supprimée.');loadLibrary();}
     catch(err){del.disabled=false;view.insertAdjacentHTML('beforeend','<p class="eat-inline-error">'+esc(err.message)+'</p>');}}
 });
 find(root,'[data-eat-manual-new]').addEventListener('click',()=>openManual(null));
 function openManual(r){
   detail=r||null;detailSaved=!!r;shoppingPayload=null;
   modal.hidden=false;document.body.classList.add('eat-modal-open');
   const val=(key)=>r?esc(r[key]||''):'';
   view.innerHTML='<form class="eat-manual-form" data-eat-manual-form enctype="multipart/form-data">'+
    '<div class="eat-manual-title"><h2>'+(r?'Modifier ma recette':'Créer une recette')+'</h2><span>Enregistrement dans la bibliothèque active et génération PDF</span></div>'+
    '<input type="hidden" name="id" value="'+(r?attr(r.id):'')+'">'+
    '<label class="eat-manual-full">Nom de la recette <input type="text" name="title" maxlength="160" value="'+val('title')+'" required placeholder="Nom du plat"></label>'+
    '<label class="eat-manual-full">Description (facultatif)<textarea name="description" rows="2" maxlength="1000" placeholder="Quelques mots sur la recette…">'+val('description')+'</textarea></label>'+
    '<div class="eat-manual-quad"><label>Catégorie <select name="category">'+categories.map(c=>'<option value="'+attr(c)+'"'+(r&&recipeCategory(r)===c?' selected':'')+'>'+esc(c)+'</option>').join('')+'</select></label>'+
    '<label>Personnes <input type="number" name="servings" value="'+(r?attr(parseInt(r.servings,10)||''):'')+'" min="1" max="100" placeholder="4"></label>'+
    '<label>Préparation <input type="text" name="prep" maxlength="70" value="'+val('prep')+'" placeholder="20 min"></label>'+
    '<label>Cuisson <input type="text" name="cook" maxlength="70" value="'+val('cook')+'" placeholder="35 min"></label></div>'+
    '<div class="eat-manual-columns"><label>Ingrédients <span>Un ingrédient par ligne, avec sa quantité</span><textarea name="ingredients" rows="11" required placeholder="250 g de farine&#10;2 œufs&#10;50 cl de lait">'+(r?esc((r.ingredients||[]).join('\n')):'')+'</textarea></label>'+
    '<label>Préparation <span>Une étape par ligne</span><textarea name="steps" rows="11" required placeholder="Mélanger les ingrédients…&#10;Laisser reposer…">'+(r?esc((r.steps||[]).join('\n')):'')+'</textarea></label></div>'+
    '<label class="eat-manual-full">Photo de la recette (JPG, PNG ou WEBP · 4 Mo max)<input type="file" name="photo" accept="image/jpeg,image/png,image/webp"></label>'+
    (r&&r.image?'<label class="eat-inline-check"><input type="checkbox" name="remove_photo" value="1"> Retirer la photo actuelle</label>':'')+
    '<div class="eat-manual-actions"><button type="button" class="eat-btn" data-eat-close>Annuler</button><button type="submit" class="eat-btn eat-btn-primary">'+(r?'Enregistrer les modifications':'Enregistrer la recette et le PDF')+'</button></div><div data-eat-manual-error class="eat-inline-error" hidden></div></form>';
 }
 view.addEventListener('submit',async e=>{
   const form=e.target.closest('[data-eat-manual-form]');if(form){
     e.preventDefault();const b=form.querySelector('[type="submit"]');b.disabled=true;
     try{const data=await req('manual_save',new FormData(form));close();notice(data.message);showTab('library');}
     catch(err){const el=find(form,'[data-eat-manual-error]');el.textContent=err.message;el.hidden=false;}
     finally{b.disabled=false;}return;
   }
   const sf=e.target.closest('[data-eat-shopping-form]');if(!sf)return;
   e.preventDefault();const b=sf.querySelector('[type="submit"]');b.disabled=true;
   const selection=[...sf.querySelectorAll('[data-eat-shopping-servings]')].map(el=>({id:el.dataset.eatShoppingServings,servings:Number(el.value)}));
   try{const data=await req('shopping_export',{selection:JSON.stringify(selection)});shoppingPayload=data.shopping;renderShoppingResult();}
   catch(err){const error=find(sf,'[data-eat-shop-error]');error.textContent=err.message;error.hidden=false;}
   finally{b.disabled=false;}
 });
 function openShopping(){
    if(!shoppingSelected.size)return;
    shoppingPayload=null;detail=null;modal.hidden=false;document.body.classList.add('eat-modal-open');
    const chosen=library.filter(r=>shoppingSelected.has(r.id));
    view.innerHTML='<form data-eat-shopping-form class="eat-shopping-prep"><h2>Préparer les ingrédients</h2><p>Choisissez les portions pour chaque recette. Les quantités compatibles seront regroupées.</p>'+
      chosen.map(r=>'<div class="eat-shopping-recipe"><strong>'+esc(r.title)+'</strong><label>Personnes <input type="number" min="1" max="100" required value="'+attr(parseInt(r.servings,10)||4)+'" data-eat-shopping-servings="'+attr(r.id)+'"></label></div>').join('')+
      '<div class="eat-manual-actions"><button type="submit" class="eat-btn eat-btn-primary">Calculer les ingrédients</button></div><p class="eat-inline-error" data-eat-shop-error hidden></p></form>';
 }
 function renderShoppingResult(){
   const data=shoppingPayload;
   view.innerHTML='<div class="eat-shopping-summary"><h2>Ingrédients regroupés</h2><p>'+data.recipes.length+' recettes · '+data.items.length+' articles. Cochez ce que vous avez déjà.</p>'+
     '<div class="eat-shopping-items">'+data.items.map((item,i)=>'<label class="eat-shopping-item"><input type="checkbox" data-eat-in-stock="'+i+'"><span class="eat-shopping-quantity">'+(item.quantity===null?'—':esc(Number(item.quantity.toFixed(3)).toLocaleString('fr-FR'))+' '+esc(item.unit))+'</span><strong>'+esc(item.name)+'</strong>'+(item.requires_review?'<small title="Quantité à vérifier">À vérifier</small>':'')+'</label>').join('')+'</div>'+
     '<p class="eat-shopping-info">Préparé pour un module de listes de courses externe. Le module destinataire n’est pas encore raccordé ; export JSON disponible.</p>'+
     '<div class="eat-manual-actions"><button type="button" class="eat-btn eat-btn-primary" data-eat-shopping-download>Exporter le JSON</button><button type="button" class="eat-btn" data-eat-close>Fermer</button></div></div>';
 }
 function downloadShopping(){
   const blob=new Blob([JSON.stringify(shoppingPayload,null,2)],{type:'application/json;charset=utf-8'});
   const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;
   link.download='DMD-EAT-Liste-de-courses.json';document.body.appendChild(link);link.click();link.remove();
   setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 view.addEventListener('click',e=>{if(e.target.closest('[data-eat-close]'))close();});
 find(root,'[data-eat-refresh]').addEventListener('click',async()=>{
   try {const data=await req('status');updateStatus(data);if(active==='library')loadLibrary();else if(find(root,'[data-eat-search] input').value.trim().length>=2) find(root,'[data-eat-search]').requestSubmit();else notice('Sources actualisées.');}catch(e){notice(e.message,true);}
 });
 function updateStatus(data){setCategories(data.categories);find(root,'[data-eat-mode]').textContent=data.mode==='private'?'Bibliothèque privée':'Bibliothèque partagée';
    const sites=(data.sites||[]).filter(s=>s.enabled).map(s=>s.name);
    find(root,'[data-eat-sources]').textContent=sites.length?'Sites actifs : '+sites.join(' · '):'Aucun site actif. Ajoutez des sources depuis l’administration.';
    const tab=find(root,'[data-eat-tab="library"]');tab.textContent=data.mode==='private'?'Mes recettes':'Bibliothèque commune';
 }
 req('status').then(updateStatus).catch(e=>notice(e.message,true));
}
function initAdmin(root){
 if(root.dataset.eatReady) return;root.dataset.eatReady='1';
 const {req,notice}=factory(root);let sites=[],adminCategories=[];
 const form=find(root,'[data-eat-site-form]'), container=find(root,'[data-eat-site-list]');
 const catList=find(root,'[data-eat-admin-categories]'),catForm=find(root,'[data-eat-category-form]');
 const setAdminCategories = settings => { adminCategories=settings.categories||[]; setCategories(adminCategories);renderAdminCategories(); };
 const controls=(list,selected) => list.filter(c=>c!==selected).map(c=>'<option value="'+attr(c)+'"'+(c==='Autres recettes'?' selected':'')+'>'+esc(c)+'</option>').join('');
 function renderAdminCategories(){catList.innerHTML=adminCategories.map(c=>
   '<div class="eat-cat-admin-row" data-eat-cat-row="'+attr(c)+'"><strong class="eat-cat-admin-name">'+esc(c)+'</strong>'+
   (c!=='Autres recettes'?'<button type="button" class="eat-btn eat-btn-small" data-eat-cat-rename="'+attr(c)+'">Renommer</button>'+
   '<button type="button" class="eat-btn eat-btn-small eat-btn-danger" data-eat-cat-delete="'+attr(c)+'">Supprimer</button>':'<span class="eat-help">Catégorie de secours</span>')+
   '</div>').join(''); }
 catForm.addEventListener('submit',async e=>{e.preventDefault();const name=catForm.elements.name.value.trim();if(!name)return;const b=catForm.querySelector('[type=submit]');b.disabled=true;
   try {const d=await req('category_add',{name});setAdminCategories(d.settings);catForm.reset();notice('Catégorie ajoutée.');}
   catch(err){notice(err.message,true);}finally{b.disabled=false;}
 });
 catList.addEventListener('click',async e=>{
   const row=e.target.closest('[data-eat-cat-row]');if(!row)return;const old=row.dataset.eatCatRow;
   const edit=e.target.closest('[data-eat-cat-rename]'),del=e.target.closest('[data-eat-cat-delete]');
   if(edit){row.innerHTML='<input class="eat-cat-admin-input" type="text" maxlength="40" aria-label="Nouveau nom de catégorie" value="'+attr(old)+'" required>'+
     '<button type="button" class="eat-btn eat-btn-small eat-btn-primary" data-eat-cat-confirm-rename>Enregistrer</button>'+
     '<button type="button" class="eat-btn eat-btn-small" data-eat-cat-cancel>Annuler</button>';row.querySelector('input').focus();return;}
   if(del){row.innerHTML='<span class="eat-cat-admin-name">'+esc(old)+' →</span><select class="eat-cat-admin-select" aria-label="Reclasser les recettes dans">'+controls(adminCategories,old)+'</select>'+
     '<button type="button" class="eat-btn eat-btn-small eat-btn-danger" data-eat-cat-confirm-delete>Confirmer</button>'+
     '<button type="button" class="eat-btn eat-btn-small" data-eat-cat-cancel>Annuler</button>';return;}
   if(e.target.closest('[data-eat-cat-cancel]')) {renderAdminCategories();return;}
   const ren=e.target.closest('[data-eat-cat-confirm-rename]'),remove=e.target.closest('[data-eat-cat-confirm-delete]');if(!ren&&!remove)return;
   if(remove&&!window.confirm('Supprimer la catégorie « '+old+' » et reclasser ses recettes sans les effacer ?')) return;
   const btn=ren||remove;btn.disabled=true;
   try{const d=await req(ren?'category_rename':'category_delete',ren?{name:old,new_name:row.querySelector('input').value.trim()}:{name:old,replacement:row.querySelector('select').value});
     setAdminCategories(d.settings);notice(ren?'Catégorie renommée. Les recettes sont conservées.':'Catégorie supprimée. Les recettes ont été reclassées.');}
   catch(err){btn.disabled=false;notice(err.message,true);}
 });
 catList.addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.matches('.eat-cat-admin-input')){e.preventDefault();e.target.closest('[data-eat-cat-row]').querySelector('[data-eat-cat-confirm-rename]').click();}});
 const reset=()=>{form.reset();form.elements.id.value='';form.querySelector('[type="submit"]').textContent='Ajouter le site';};
 function render(){container.innerHTML=sites.length?sites.map(s=>'<div class="eat-site-item"><div class="eat-site-descr"><strong>'+esc(s.name)+'</strong><small>'+esc(s.search_url)+'</small></div><span class="eat-site-status '+(s.enabled?'enabled':'')+'">'+(s.enabled?'Activé':'Désactivé')+'</span><button type="button" class="eat-btn eat-btn-small" data-edit="'+attr(s.id)+'">Modifier</button><button type="button" class="eat-btn eat-btn-small eat-btn-danger" data-delete="'+attr(s.id)+'">Supprimer</button></div>').join(''):'<div class="eat-empty">Aucun site configuré.</div>';}
 async function load(){try{const d=await req('config');sites=d.settings.sites||[];render();setAdminCategories(d.settings);const mode=d.settings.visibility;const radio=root.querySelector('[name="eat-visibility"][value="'+mode+'"]');if(radio)radio.checked=true;}catch(e){notice(e.message,true);}}
 container.addEventListener('click',async e=>{
   const edit=e.target.closest('[data-edit]'),del=e.target.closest('[data-delete]');
   if(edit){const s=sites.find(v=>v.id===edit.dataset.edit);if(!s)return;form.elements.id.value=s.id;form.elements.name.value=s.name;form.elements.search_url.value=s.search_url;form.elements.enabled.checked=!!s.enabled;form.querySelector('[type="submit"]').textContent='Enregistrer le site';form.scrollIntoView({behavior:'smooth',block:'nearest'});}
   if(del){if(!window.confirm('Supprimer ce site de recherche ?'))return;try{const d=await req('site_delete',{id:del.dataset.delete});sites=d.settings.sites;render();reset();notice('Site supprimé.');}catch(e){notice(e.message,true);}}
 });
 find(root,'[data-eat-site-reset]').addEventListener('click',reset);
 form.addEventListener('submit',async e=>{e.preventDefault();
   const b=form.querySelector('[type="submit"]');b.disabled=true;
   try {const d=await req('site_save',{id:form.elements.id.value,name:form.elements.name.value,search_url:form.elements.search_url.value,enabled:form.elements.enabled.checked?'1':''});sites=d.settings.sites;render();reset();notice('Site enregistré.');}
   catch(err){notice(err.message,true);}finally{b.disabled=false;}
 });
 find(root,'[data-eat-save-mode]').addEventListener('click',async e=>{const selected=root.querySelector('[name="eat-visibility"]:checked');if(!selected)return;
   const btn=e.currentTarget;btn.disabled=true;
   try{await req('config_save',{visibility:selected.value});notice('Mode '+(selected.value==='private'?'privé':'public')+' enregistré. Les anciennes bibliothèques ne sont pas déplacées.');}
   catch(err){notice(err.message,true);}finally{btn.disabled=false;}
 });
 load();
}
window.DMDEATBuild=140;
window.DMDEATInit=function(){document.querySelectorAll('[data-eat-root]').forEach(initMain);document.querySelectorAll('[data-eat-admin]').forEach(initAdmin);};
window.DMDEATInit();
}());
