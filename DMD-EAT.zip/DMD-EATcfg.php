<?php
require_once __DIR__.'/DMD-EAT_lib.php';
if (!eat_allowed() || !eat_admin()) { echo '<div class="dmd-eat-denied">Accès administrateur DMD-EAT refusé.</div>'; return; }
$eatUrl=eat_base_url();
?>
<link rel="stylesheet" href="<?= eat_e($eatUrl) ?>/DMD-EAT.css?v=140">
<div class="dmd-eat eat-admin" data-eat-admin data-base="<?= eat_e($eatUrl) ?>" data-csrf="<?= eat_e(eat_csrf()) ?>">
 <header class="eat-header"><div class="eat-identity"><div class="eat-brandmark">E</div><div><strong>Administration DMD-EAT</strong><span>Sources de recettes et confidentialité des bibliothèques</span></div></div></header>
 <div class="eat-notice" data-eat-notice hidden></div>
 <section class="eat-admin-section"><div class="eat-admin-h"><strong>Visibilité des recettes enregistrées</strong></div>
  <div class="eat-radio-grid"><label><input type="radio" name="eat-visibility" value="public"> <span><strong>Public</strong><small>Une bibliothèque commune accessible à tous les membres autorisés.</small><code>/data/modules/DMD-EAT/recettes/</code></span></label><label><input type="radio" name="eat-visibility" value="private"> <span><strong>Privé</strong><small>Chaque utilisateur conserve ses PDF dans son propre dossier.</small><code>/users/profiles/&lt;utilisateur&gt;/modules/DMD-EAT/</code></span></label></div>
  <div class="eat-admin-actions"><span class="eat-help">Changer de mode ne déplace et ne supprime aucune ancienne recette.</span><button type="button" class="eat-btn eat-btn-primary" data-eat-save-mode>Enregistrer le mode</button></div>
 </section>
 <section class="eat-admin-section"><div class="eat-admin-h"><strong>Catégories de recettes</strong><span>Création, renommage et suppression · 30 maximum</span></div>
  <div class="eat-category-admin-list" data-eat-admin-categories></div>
  <form class="eat-category-form" data-eat-category-form><input type="text" name="name" maxlength="40" placeholder="Nouvelle catégorie…" aria-label="Nom de la nouvelle catégorie" required><button type="submit" class="eat-btn eat-btn-primary">Ajouter</button></form>
  <p class="eat-help">Supprimer une catégorie ne supprime aucune recette. Les recettes sont reclassées dans la catégorie sélectionnée. « Autres recettes » reste disponible.</p>
 </section>
 <section class="eat-admin-section"><div class="eat-admin-h"><strong>Sites de recettes</strong><span>Jusqu'à 15 sources actives ou inactives.</span></div><div class="eat-site-table" data-eat-site-list></div>
 <form class="eat-site-form" data-eat-site-form><input type="hidden" name="id"><label>Nom du site<input name="name" maxlength="90" placeholder="Ex. Mon site culinaire" required></label><label>URL de recherche<input name="search_url" type="text" placeholder="https://www.exemple.fr/?s={query}" required></label><label class="eat-toggle"><input type="checkbox" name="enabled" checked> Source activée</label>
 <div class="eat-admin-actions"><button type="button" class="eat-btn" data-eat-site-reset>Annuler</button><button type="submit" class="eat-btn eat-btn-primary">Ajouter le site</button></div><p class="eat-help">L'URL doit contenir <code>{query}</code>. DMD-EAT analyse les liens de recettes et lit les données structurées Recipe (JSON-LD) des fiches. Certains sites peuvent bloquer l'extraction automatique.</p></form></section>
</div>
<script>(function(){function boot(){if(window.DMDEATInit)window.DMDEATInit();}if(window.DMDEATInit&&window.DMDEATBuild===140){boot();return;}var s=document.createElement('script');s.src=<?= json_encode($eatUrl.'/DMD-EAT.js?v=140',JSON_UNESCAPED_SLASHES) ?>;s.onload=boot;document.head.appendChild(s);}());</script>
