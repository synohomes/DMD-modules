<?php
/** DMD-EAT · services partagés · DoMyDesk 1.4 · PHP 7.4+ */
if (session_status() === PHP_SESSION_NONE) session_start();
$__eat_functions = dirname(__DIR__, 2) . '/functions.php';
if (is_file($__eat_functions)) require_once $__eat_functions;

function eat_root() { return dirname(__DIR__, 2); }
function eat_user() { return trim((string)($_SESSION['user']['email'] ?? '')); }
function eat_profile() {
    $email = eat_user();
    if ($email && function_exists('dmd_read_profile')) {
        try { $p = dmd_read_profile($email); if (is_array($p)) return $p; } catch (Throwable $e) {}
    }
    return is_array($_SESSION['user'] ?? null) ? $_SESSION['user'] : [];
}
function eat_admin() {
    $p = eat_profile();
    $role = strtolower((string)($p['role_system'] ?? $_SESSION['user']['role_system'] ?? ''));
    return in_array($role, ['admin','superadmin','administrator'], true);
}
function eat_allowed() {
    if (eat_user() === '') return false;
    if (function_exists('dmd_user_can_use_module')) {
        try { return (bool)dmd_user_can_use_module(eat_user(), 'DMD-EAT'); } catch (Throwable $e) { return false; }
    }
    return false; // Refuser par défaut si le Core DoMyDesk n'est pas chargé.
}
function eat_need_access($admin = false) {
    if (!eat_allowed() || ($admin && !eat_admin())) eat_fail('Accès refusé.',403);
}
function eat_e($s) { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function eat_base_url() {
    $doc = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? ''));
    $module = realpath(__DIR__);
    if ($doc !== false && $module !== false && ($module === $doc || strpos($module, $doc . DIRECTORY_SEPARATOR) === 0)) {
        return '/' . trim(str_replace('\\', '/', substr($module, strlen($doc))), '/');
    }
    $script = str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME'] ?? ''));
    if (preg_match('~^(.*?/modules/DMD-EAT)(?:/|$)~i',$script,$m)) return $m[1];
    return '/domydesk/modules/DMD-EAT';
}
function eat_csrf() {
    if (empty($_SESSION['csrf_dmd_eat'])) $_SESSION['csrf_dmd_eat'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_dmd_eat'];
}
function eat_verify_csrf() {
    $token = (string)($_POST['csrf'] ?? $_SERVER['HTTP_X_DMD_CSRF'] ?? '');
    if ($token === '' || !hash_equals(eat_csrf(), $token)) eat_fail('Jeton de sécurité invalide.', 403);
}
function eat_json($payload,$status=200) {
    if (!headers_sent()) { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); header('X-Content-Type-Options: nosniff'); }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE); exit;
}
function eat_fail($message, $status=400) { eat_json(['ok'=>false,'message'=>$message],$status); }
function eat_mkdir($dir) {
    if (!is_dir($dir) && !@mkdir($dir,0750,true) && !is_dir($dir)) throw new RuntimeException('Impossible de créer le dossier de stockage.');
    $h = rtrim($dir, '/\\') . '/.htaccess';
    if (!is_file($h)) @file_put_contents($h,"Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n", LOCK_EX);
    $index = rtrim($dir, '/\\') . '/index.html';
    if (!is_file($index)) @file_put_contents($index, '');
}
function eat_system_dir() {
    if (function_exists('dmd_module_system_data_dir')) {
        try { $path = dmd_module_system_data_dir('DMD-EAT', true); if (is_string($path) && $path !== '') return rtrim($path,'/\\'); } catch (Throwable $e) {}
    }
    return eat_root() . '/data/modules/DMD-EAT';
}
function eat_user_dir() {
    $email = eat_user(); if ($email === '') throw new RuntimeException('Compte utilisateur absent.');
    $safe = '';
    if (function_exists('dmd_safe_user_key')) {
        try { $safe = (string)dmd_safe_user_key($email); } catch (Throwable $e) {}
    }
    if ($safe === '' && function_exists('dmd_profile_path')) {
        try { $file = (string)dmd_profile_path($email, false); if ($file !== '') {
            $base = dirname($file);
            $root = realpath(eat_root() . '/users/profiles');
            $real = realpath($base);
            if ($root && $real && strpos($real,$root.DIRECTORY_SEPARATOR)===0) return $real . '/modules/DMD-EAT';
        } } catch (Throwable $e) {}
    }
    if ($safe === '') $safe = hash('sha256',strtolower($email));
    if (!preg_match('/^[a-zA-Z0-9_.@-]+$/', $safe) || $safe === '.' || $safe === '..') $safe = hash('sha256',strtolower($email));
    return eat_root() . '/users/profiles/' . $safe . '/modules/DMD-EAT';
}
function eat_recipe_dir() {
    $folder = eat_settings()['visibility'] === 'private' ? eat_user_dir() : eat_system_dir();
    $folder .= '/recettes'; eat_mkdir($folder); return $folder;
}
function eat_default_categories() {
    return ['Apéritifs', 'Entrées', 'Soupes', 'Plats', 'Accompagnements', 'Desserts', 'Boulangerie', 'Boissons', 'Autres recettes'];
}
function eat_settings() {
    $base = ['visibility'=>'public','categories'=>eat_default_categories(),'category_aliases'=>[],'sites'=>[
        ['id'=>'marmiton','name'=>'Marmiton','host'=>'www.marmiton.org','search_url'=>'https://www.marmiton.org/recettes/recherche.aspx?aqt={query}','enabled'=>true],
    ]];
    $path = eat_system_dir() . '/cfg/settings.json';
    if (!is_file($path)) return $base;
    $a = json_decode((string)@file_get_contents($path),true);
    if (!is_array($a)) return $base;
    $categories=$a['categories']??null;
    if (!is_array($categories) || !in_array('Autres recettes',$categories,true)) $categories=$base['categories'];
    $categories=array_values(array_unique(array_filter($categories,static function($c){return is_string($c) && $c!=='';})));
    $aliases=is_array($a['category_aliases']??null)?$a['category_aliases']:[];
    return ['visibility'=>(($a['visibility'] ?? '') === 'private' ? 'private':'public'),'sites'=>is_array($a['sites'] ?? null)?$a['sites']:$base['sites'],'categories'=>$categories,'category_aliases'=>$aliases];
}
function eat_save_settings($s) {
    $folder = eat_system_dir() . '/cfg'; eat_mkdir($folder);
    $f = $folder . '/settings.json';
    $tmp = $f . '.' . bin2hex(random_bytes(6)) . '.tmp';
    $raw = json_encode($s, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    if (!is_string($raw) || file_put_contents($tmp,$raw,LOCK_EX) === false || !@rename($tmp,$f)) {
        @unlink($tmp); throw new RuntimeException('Écriture de configuration impossible.');
    }
    @chmod($f,0640);
}
function eat_validate_site($site, $id='') {
    $name = trim((string)($site['name'] ?? ''));
    $template = trim((string)($site['search_url'] ?? ''));
    if ($name === '' || strlen($name)>90) throw new InvalidArgumentException('Nom du site invalide.');
    if (substr_count($template,'{query}') !== 1) throw new InvalidArgumentException('L’URL de recherche doit contenir {query} une fois.');
    $probe = str_replace('{query}','recette',$template);
    $p = parse_url($probe);
    if (!is_array($p) || !in_array(strtolower($p['scheme'] ?? ''),['https','http'],true) || !empty($p['user']) || !empty($p['pass']) || !empty($p['fragment']) || !empty($p['port']) || empty($p['host'])) throw new InvalidArgumentException('URL de recherche non autorisée (HTTP/HTTPS standard uniquement).');
    $host = strtolower(rtrim((string)$p['host'],'.'));
    if (!preg_match('/^(?=.{4,253}$)[a-z0-9-]+(?:\.[a-z0-9-]+)+$/',$host) || filter_var($host,FILTER_VALIDATE_IP)) throw new InvalidArgumentException('Nom de domaine du site invalide.');
    return ['id'=> $id !== '' ? $id : bin2hex(random_bytes(7)), 'name'=>$name, 'host'=>$host, 'search_url'=>$template, 'enabled'=>!empty($site['enabled'])];
}
function eat_public_ipv4($ip) {
    if (!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4|FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)) return false;
    $n=ip2long($ip); if ($n===false) return false;
    $ranges=[
        ['100.64.0.0',10],['169.254.0.0',16],['192.0.0.0',24],
        ['192.0.2.0',24],['192.88.99.0',24],['198.18.0.0',15],
        ['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],
        ['240.0.0.0',4]
    ];
    foreach($ranges as $block) {
        $mask=(0xffffffff << (32-$block[1])) & 0xffffffff;
        if (($n & $mask) === (ip2long($block[0]) & $mask)) return false;
    }
    return true;
}

function eat_url_ok($url,$host) {
    $p = parse_url($url);
    return is_array($p) && in_array(strtolower($p['scheme'] ?? ''),['http','https'],true) && strtolower(rtrim((string)($p['host'] ?? ''),'.')) === strtolower($host) && !isset($p['port']) && !isset($p['user']) && !isset($p['pass']);
}
function eat_absolute_url($href,$base) {
    $href = trim(html_entity_decode((string)$href,ENT_QUOTES|ENT_HTML5,'UTF-8'));
    if ($href === '' || preg_match('~^(?:javascript:|data:|mailto:|#)~i',$href)) return '';
    if (preg_match('~^https?://~i',$href)) return $href;
    $b = parse_url($base);
    if (!$b || empty($b['host'])) return '';
    $origin = strtolower($b['scheme']) . '://' . $b['host'];
    if (substr($href,0,2)==='//') return strtolower($b['scheme']).':'.$href;
    if ($href[0]==='/') return $origin.$href;
    $path = (string)($b['path']??'/');
    if ($href[0]==='?') return $origin.$path.$href;
    $dir = preg_replace('~/[^/]*$~','/',$path);
    $parts = explode('/',$dir.$href); $arr=[];
    foreach ($parts as $part) { if ($part==='..') array_pop($arr); elseif ($part!=='.') $arr[]=$part; }
    return $origin . implode('/',$arr);
}
function eat_fetch($url,$host,$max=3000000) {
    if (!function_exists('curl_init')) throw new RuntimeException('Extension PHP cURL requise sur le serveur.');
    for ($hop=0;$hop<3;$hop++) {
        if (!eat_url_ok($url,$host)) throw new RuntimeException('Domaine extérieur non autorisé.');
        $ips = @gethostbynamel($host);
        if (!is_array($ips) || !$ips) throw new RuntimeException('Résolution DNS du site impossible.');
        foreach ($ips as $ip) if (!eat_public_ipv4($ip)) throw new RuntimeException('Adresse réseau du site non autorisée.');
        $ip = $ips[0]; $scheme = strtolower((string)parse_url($url,PHP_URL_SCHEME)); $port = $scheme==='https'?443:80;
        $ch = curl_init($url);
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_HEADER=>true, CURLOPT_CONNECTTIMEOUT=>5, CURLOPT_TIMEOUT=>12,
            CURLOPT_FOLLOWLOCATION=>false, CURLOPT_MAXREDIRS=>0, CURLOPT_SSL_VERIFYPEER=>true, CURLOPT_SSL_VERIFYHOST=>2,
            CURLOPT_USERAGENT=>'DoMyDesk-EAT/1.0 (recipe viewer)', CURLOPT_HTTPHEADER=>['Accept: text/html,application/ld+json;q=0.9','Accept-Language: fr-FR,fr;q=0.9,en;q=0.5'],
            CURLOPT_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS, CURLOPT_IPRESOLVE=>CURL_IPRESOLVE_V4,
            CURLOPT_RESOLVE=>[ $host . ':' . $port . ':' . $ip ], CURLOPT_ENCODING=>'',
            CURLOPT_NOPROGRESS=>false,
            CURLOPT_PROGRESSFUNCTION=>static function($resource,$total,$received,$ut,$un) use($max) { return $received > $max ? 1 : 0; }
        ]);
        $data=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $headerSize=(int)curl_getinfo($ch,CURLINFO_HEADER_SIZE); $error=curl_error($ch); curl_close($ch);
        if (!is_string($data)) throw new RuntimeException('Site inaccessible : '.$error);
        $headers=substr($data,0,$headerSize); $body=substr($data,$headerSize);
        if (strlen($body)>$max) throw new RuntimeException('Réponse du site trop volumineuse.');
        if ($code>=300 && $code<400 && preg_match('~^location:\s*(.+)$~im',$headers,$m)) { $url=eat_absolute_url(trim($m[1]),$url); continue; }
        if ($code<200 || $code>=300) throw new RuntimeException('Réponse HTTP '.$code.' du site.');
        return [$body,$url];
    }
    throw new RuntimeException('Trop de redirections du site.');
}
function eat_dom($html) {
    if (!class_exists('DOMDocument')) throw new RuntimeException('Extension PHP DOM/XML requise sur le serveur.');
    $d=new DOMDocument(); $prior=libxml_use_internal_errors(true);
    $d->loadHTML('<?xml encoding="utf-8" ?>'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);
    libxml_clear_errors(); libxml_use_internal_errors($prior); return $d;
}
function eat_text($str,$max=8000) {
    if (is_array($str)) return '';
    $str=trim(preg_replace('/\s+/u',' ',html_entity_decode(strip_tags((string)$str),ENT_QUOTES|ENT_HTML5,'UTF-8')) ?? '');
    return function_exists('mb_substr') ? mb_substr($str,0,$max) : substr($str,0,$max);
}
function eat_site_for_url($url) {
    foreach (eat_settings()['sites'] as $s) if (!empty($s['enabled']) && eat_url_ok($url,$s['host'])) return $s;
    return null;
}
function eat_recipe_link($url,$title='') {
    $p=parse_url($url); $path=strtolower((string)($p['path']??''));
    if (preg_match('~/(?:recherche|search)(?:[./_-]|$)~i',$path)) return false;
    if (preg_match('~/(recettes?|recipe|recipes|cuisine|plat|dessert|entree|entr[eé]es?)/~u',$path)) return true;
    if (preg_match('~(recette|recipe|recipes|cuisine|plat|dessert|entree|meal)~i',$path)) return true;
    return false;
}
function eat_search_site($s,$query) {
    $template=(string)$s['search_url'];
    [$html,$actual]=eat_fetch(str_replace('{query}',rawurlencode($query),$template),$s['host']);
    $dom=eat_dom($html); $xpath=new DOMXPath($dom); $items=[]; $seen=[];
    foreach ($xpath->query('//a[@href]') as $a) {
        $href=eat_absolute_url($a->getAttribute('href'),$actual);
        if (!eat_url_ok($href,$s['host']) || !eat_recipe_link($href)) continue;
        $title=eat_text($a->getAttribute('title') ?: $a->textContent,160);
        $img='';
        foreach ($a->getElementsByTagName('img') as $im) {
            if ($title==='' || strlen($title)<7) $title=eat_text($im->getAttribute('alt'),160);
            $img=(string)($im->getAttribute('data-src') ?: $im->getAttribute('src'));
            if ($img) break;
        }
        if (strlen($title)<5 || preg_match('/^(voir|voir la recette|recette|en savoir plus|lire la suite|découvrir|image|photo)$/iu',$title)) continue;
        $path=(string)parse_url($href,PHP_URL_PATH); if ($path==='') continue;
        // Nettoyer les paramètres de suivi sans altérer les URL recettes réelles.
        $key=hash('sha256',$href); if (isset($seen[$key])) continue; $seen[$key]=true;
        $items[]=['title'=>$title,'url'=>$href,'image'=> $img ? eat_absolute_url($img,$actual) : '', 'source'=>$s['name'],'source_id'=>$s['id']];
        if (count($items)>=45) break;
    }
    // Classement par pertinence du titre ; aucune fiche inventée.
    $tokens=preg_split('/\s+/u',trim($query));
    usort($items,static function($a,$b) use($tokens) {
        $score=static function($item) use($tokens) { $title=function_exists('mb_strtolower')?mb_strtolower($item['title'],'UTF-8'):strtolower($item['title']); $n=0; foreach($tokens as $t) if (stripos($title,$t)!==false) $n++; return $n; };
        return $score($b)<=>$score($a);
    });
    return array_slice($items,0,24);
}
function eat_schema_recipe($entry) {
    if (!is_array($entry)) return null;
    if (array_keys($entry)===range(0,count($entry)-1)) { foreach ($entry as $e) { $r=eat_schema_recipe($e); if($r) return $r; } return null; }
    if (isset($entry['@graph']) && is_array($entry['@graph'])) { $r=eat_schema_recipe($entry['@graph']); if($r) return $r; }
    $type=$entry['@type']??''; if (is_array($type)) $types=$type; else $types=[$type];
    foreach ($types as $t) if (is_string($t) && (strtolower($t)==='recipe'||preg_match('~/recipe$~i',$t))) return $entry;
    return null;
}
function eat_list_string($val) {
    if (is_string($val)) { $x=preg_split('/\r\n|\r|\n/u',$val); return array_values(array_filter(array_map(static function($v){return eat_text($v,500);},$x))); }
    if (!is_array($val)) return [];
    $out=[]; foreach ($val as $v) {
        if (is_string($v)) $out[]=eat_text($v,500);
        elseif (is_array($v)) { $t=eat_text($v['text']??$v['name']??'',1800); if ($t) $out[]=$t; elseif (!empty($v['itemListElement'])) $out=array_merge($out,eat_list_string($v['itemListElement'])); }
    }
    return array_values(array_filter($out,static function($s){return $s!=='';}));
}
function eat_duration($s) {
    $s=(string)$s;
    if (preg_match('/^P(?:\d+D)?T(?:(\d+)H)?(?:(\d+)M)?/i',$s,$m)) {
        $minutes=(int)($m[1]??0)*60+(int)($m[2]??0); if ($minutes) return ($minutes>=60?intdiv($minutes,60).' h '.($minutes%60 ? ($minutes%60).' min':''):$minutes.' min');
    }
    return eat_text($s,90);
}
/** Catégories globales administrables, rétrocompatibles avec les fiches existantes. */
function eat_categories() { return eat_settings()['categories']; }
function eat_category_resolve($category,$settings=null) {
    $settings=$settings===null?eat_settings():$settings;
    $aliases=$settings['category_aliases']??[];
    $category=(string)$category;
    for($n=0;$n<40 && isset($aliases[$category]);$n++) {
        $next=(string)$aliases[$category];
        if($next===$category) break;
        $category=$next;
    }
    return in_array($category,$settings['categories'],true) ? $category : 'Autres recettes';
}
function eat_category_revision() {
    $s=eat_settings();
    return hash('sha256',json_encode([$s['categories'],$s['category_aliases']], JSON_UNESCAPED_UNICODE));
}
function eat_validate_category_name($raw) {
    $name=trim(preg_replace('/\s+/u',' ',(string)$raw)??'');
    if($name==='' || (function_exists('mb_strlen')?mb_strlen($name,'UTF-8'):strlen($name))>40 || preg_match('/[<>\x00-\x1f\x7f]/u',$name))
        throw new InvalidArgumentException('Nom de catégorie invalide (1 à 40 caractères).');
    return $name;
}
function eat_same_category($a,$b) {
    if(function_exists('mb_strtolower')) return mb_strtolower($a,'UTF-8')===mb_strtolower($b,'UTF-8');
    return strcasecmp($a,$b)===0;
}
/** Création/renommage/suppression sans toucher aux fichiers des recettes ni aux PDF. */
function eat_manage_category($action,$name,$new='',$replacement='Autres recettes') {
    $s=eat_settings(); $list=$s['categories'];
    if($action==='category_add') {
        $new=eat_validate_category_name($name);
        if(count($list)>=30) throw new InvalidArgumentException('Maximum 30 catégories.');
        foreach($list as $c) if(eat_same_category($c,$new)) throw new InvalidArgumentException('Catégorie déjà existante.');
        // Ne jamais réutiliser un ancien nom alias : cela ferait réapparaître des recettes supprimées d'une catégorie.
        if(array_key_exists($new,$s['category_aliases'])) throw new InvalidArgumentException('Ancien nom réservé. Choisissez un autre nom.');
        $list[]= $new;
    } else {
        if(!in_array($name,$list,true)) throw new InvalidArgumentException('Catégorie introuvable.');
        if($name==='Autres recettes') throw new InvalidArgumentException('« Autres recettes » est la catégorie de secours et ne peut pas être modifiée.');
        if($action==='category_rename') {
            $new=eat_validate_category_name($new);
            foreach($list as $c) if($c!==$name && eat_same_category($c,$new)) throw new InvalidArgumentException('Catégorie déjà existante.');
            if($new!==$name && array_key_exists($new,$s['category_aliases'])) throw new InvalidArgumentException('Ancien nom réservé. Choisissez un autre nom.');
            $target=$new;
            $list[array_search($name,$list,true)]=$target;
        } elseif($action==='category_delete') {
            if($replacement===$name || !in_array($replacement,$list,true)) throw new InvalidArgumentException('Catégorie de destination invalide.');
            $target=$replacement;
            $list=array_values(array_filter($list,static function($c)use($name){return $c!==$name;}));
        } else throw new InvalidArgumentException('Opération de catégorie inconnue.');
        // Les anciens JSON gardent leur catégorie ; ces alias en conservent le classement actuel.
        foreach($s['category_aliases'] as $old=>$dest) if($dest===$name) $s['category_aliases'][$old]=$target;
        if($target!==$name) $s['category_aliases'][$name]=$target;
    }
    $s['categories']=array_values($list);
    eat_save_settings($s);
    return $s;
}
function eat_category($raw, $title='') {
    $raw = is_array($raw) ? implode(' ', array_filter($raw, 'is_string')) : (string)$raw;
    $v = function_exists('mb_strtolower') ? mb_strtolower($raw.' '.(string)$title, 'UTF-8') : strtolower($raw.' '.(string)$title);
    $v = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $v) ?: $v;
    $matches = [
        'Boissons' => '~\b(boisson|cocktail|smoothie|jus de|limonade|milkshake|infusion|the glace|chocolat chaud)\b~i',
        'Soupes' => '~\b(soupe|potage|veloute|bouillon|gaspacho)\b~i',
        'Apéritifs' => '~\b(aperitif|apero|amuse.bouche|toast|canape|verrine|tapas)\b~i',
        'Boulangerie' => '~\b(pain|brioche|baguette|fougasse|croissant|viennoiserie|boulangerie|pate a pizza)\b~i',
        'Desserts' => '~\b(dessert|gateau|tarte sucree|tarte aux|tiramisu|mousse au|creme brulee|flan|biscuit|cookie|brownie|fondant au|clafoutis|crepe sucree|cheesecake|patisserie|chocolat|glace|sorbet|panna cotta|macaron|beignet|confiture)\b~i',
        'Accompagnements' => '~\b(accompagnement|garniture|puree|gratin dauphinois|riz pilaf|pommes de terre sautees)\b~i',
        'Entrées' => '~\b(entree|salade|carpaccio|taboule|terrine|quiche|oeufs mimosa|bruschetta)\b~i',
        'Plats' => '~\b(plat principal|plat de resistance|plats?|viande|poisson|poulet|boeuf|porc|agneau|saumon|lasagne|pates|risotto|pizza|burger|curry|fondue|raclette|hachis|blanquette|roti|couscous|chili|omelette)\b~i',
    ];
    // Priorité à la catégorie annoncée par le site pour éviter « gâteau apéro » mal classé.
    foreach ($matches as $category => $pattern) if ($raw !== '' && preg_match($pattern, @iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$raw) ?: $raw)) return $category;
    foreach ($matches as $category => $pattern) if (preg_match($pattern, $v)) return $category;
    return 'Autres recettes';
}
function eat_recipe_category($recipe) {
    $manual = (string)($recipe['category'] ?? '');
    if ($manual !== '') return eat_category_resolve($manual);
    return eat_category_resolve(eat_category($recipe['recipe_category'] ?? '', $recipe['title'] ?? ''));
}

function eat_extract_recipe($html,$url,$s) {
    $dom=eat_dom($html); $xp=new DOMXPath($dom); $data=null;
    foreach ($xp->query('//script[@type="application/ld+json"]') as $sc) {
        $json=trim($sc->textContent);
        $obj=json_decode($json,true); if (!is_array($obj)) continue;
        $found=eat_schema_recipe($obj); if($found) { $data=$found; break; }
    }
    if (!$data) throw new RuntimeException('Cette page ne fournit pas de fiche recette structurée exploitable.');
    $image=$data['image']??''; if(is_array($image)) { if(isset($image['url'])) $image=$image['url']; else $image=reset($image); } if(is_array($image)) $image=$image['url']??'';
    $instructions=eat_list_string($data['recipeInstructions']??[]);
    $ingredients=eat_list_string($data['recipeIngredient']??$data['ingredients']??[]);
    if (!$instructions && !$ingredients) throw new RuntimeException('Ingrédients et préparation absents de cette fiche.');
    $yield=$data['recipeYield']??''; if(is_array($yield)) $yield=implode(', ',array_filter($yield,'is_string'));
    return ['title'=>eat_text($data['name']??'',180) ?: 'Recette', 'description'=>eat_text($data['description']??'',1000), 'image'=>is_string($image)?eat_absolute_url($image,$url):'',
        'ingredients'=>array_slice($ingredients,0,150), 'steps'=>array_slice($instructions,0,120), 'prep'=>eat_duration($data['prepTime']??''), 'cook'=>eat_duration($data['cookTime']??''), 'total'=>eat_duration($data['totalTime']??''),
        'servings'=>eat_text($yield,100), 'recipe_category'=>eat_text(is_array($data['recipeCategory']??null)?implode(', ',array_filter($data['recipeCategory'],'is_string')):($data['recipeCategory']??''),150), 'category'=>eat_category($data['recipeCategory']??'', $data['name']??''), 'source'=>(string)$s['name'], 'url'=>$url, 'fetched_at'=>date('c')];
}
function eat_find_saved($id) {
    if (!preg_match('/^[a-f0-9]{24}$/D',(string)$id)) throw new InvalidArgumentException('Identifiant de recette invalide.');
    $base=eat_recipe_dir(); $file=$base.'/'.$id.'.json';
    if (!is_file($file)) return null;
    $data=json_decode((string)file_get_contents($file),true);
    if(!is_array($data)) return null;
    if(($data['origin']??'')==='manual') $data['image']=is_file($base.'/'.$id.'.jpg')?eat_manual_image_url($id):'';
    return $data;
}
function eat_list_saved() {
    $base=eat_recipe_dir(); $items=[];
    foreach (glob($base.'/*.json') ?: [] as $file) {
        if (!preg_match('/^[a-f0-9]{24}\.json$/',basename($file))) continue;
        $rec=json_decode((string)@file_get_contents($file),true);
        if(is_array($rec) && isset($rec['id'],$rec['title'])) $items[]=['id'=>$rec['id'],'title'=>$rec['title'],'source'=>$rec['source']??'','servings'=>$rec['servings']??'','image'=>(($rec['origin']??'')==='manual' && is_file($base.'/'.$rec['id'].'.jpg')) ? eat_manual_image_url($rec['id']) : ($rec['image']??''),'category'=>eat_recipe_category($rec),'saved_at'=>$rec['saved_at']??''];
    }
    usort($items,static function($a,$b){return strcmp($b['saved_at'],$a['saved_at']);});
    return $items;
}
function eat_save_recipe($recipe) {
    $id=substr(hash('sha256',(string)($recipe['url']??'')),0,24);
    $base=eat_recipe_dir();
    if (is_file($base.'/'.$id.'.json') && is_file($base.'/'.$id.'.pdf')) return $id;
    $recipe['id']=$id; $recipe['saved_by']=eat_user(); $recipe['saved_at']=date('c'); $recipe['category']=eat_recipe_category($recipe); $recipe['pdf_version']=2; $recipe['pdf_categories_revision']=eat_category_revision();
    $raw=json_encode($recipe,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
    $image=eat_pdf_fetch_image($recipe['image']??'', $recipe['url']??'');
    $pdf=eat_make_pdf($recipe,$image);
    $tmp=$base.'/'.$id.'.'.bin2hex(random_bytes(6));
    if (@file_put_contents($tmp.'.pdf',$pdf,LOCK_EX)===false || @file_put_contents($tmp.'.json',$raw,LOCK_EX)===false || ($image!==null && @file_put_contents($tmp.'.jpg',$image,LOCK_EX)===false)) {
        @unlink($tmp.'.pdf'); @unlink($tmp.'.json'); @unlink($tmp.'.jpg'); throw new RuntimeException('Impossible de sauvegarder la recette.');
    }
    if (!@rename($tmp.'.pdf',$base.'/'.$id.'.pdf') || !@rename($tmp.'.json',$base.'/'.$id.'.json')) {
        @unlink($tmp.'.pdf'); @unlink($tmp.'.json'); @unlink($tmp.'.jpg'); throw new RuntimeException('Impossible de finaliser la sauvegarde.');
    }
    if ($image!==null) { @rename($tmp.'.jpg',$base.'/'.$id.'.jpg'); @chmod($base.'/'.$id.'.jpg',0640); }
    @chmod($base.'/'.$id.'.pdf',0640); @chmod($base.'/'.$id.'.json',0640);
    return $id;
}

function eat_can_delete($recipe) {
    if (eat_settings()['visibility'] === 'private') return true;
    return eat_admin() || (!empty($recipe['saved_by']) && hash_equals((string)$recipe['saved_by'],eat_user()));
}

/** Mise à niveau transparente des PDF anciens, en conservant l'archive originale si une erreur survient. */
function eat_pdf_saved($recipe) {
    $id = (string)$recipe['id'];
    $base = eat_recipe_dir();
    $file = $base.'/'.$id.'.pdf';
    $revision=eat_category_revision();
    if (($recipe['pdf_version']??0) >= 2 && ($recipe['pdf_categories_revision']??'') === $revision && is_file($file)) return $file;
    $lock = @fopen($base.'/'.$id.'.lock', 'c');
    if ($lock) @flock($lock, LOCK_EX);
    try {
        $latest = eat_find_saved($id);
        if (!$latest) throw new RuntimeException('Recette introuvable.');
        if (($latest['pdf_version']??0) < 2 || ($latest['pdf_categories_revision']??'') !== $revision || !is_file($file)) {
            $jpg = $base.'/'.$id.'.jpg';
            $image = is_file($jpg) ? @file_get_contents($jpg) : eat_pdf_fetch_image($latest['image']??'', $latest['url']??'');
            if ($image !== null && !is_file($jpg)) @file_put_contents($jpg,$image,LOCK_EX);
            $pdf = eat_make_pdf($latest,$image);
            $tmp = $file.'.'.bin2hex(random_bytes(5)).'.tmp';
            if (@file_put_contents($tmp,$pdf,LOCK_EX) === false || !@rename($tmp,$file)) {
                @unlink($tmp); throw new RuntimeException('Actualisation du PDF impossible.');
            }
            $latest['pdf_version']=2;
            $latest['pdf_categories_revision']=$revision;
            @file_put_contents($base.'/'.$id.'.json',json_encode($latest,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),LOCK_EX);
        }
    } finally { if ($lock) { @flock($lock,LOCK_UN); @fclose($lock); } }
    return $file;
}
function eat_change_category($id,$category) {
    if (!in_array($category,eat_categories(),true)) throw new InvalidArgumentException('Catégorie inconnue.');
    $rec = eat_find_saved($id);
    if (!$rec) throw new InvalidArgumentException('Recette introuvable.');
    if (!eat_can_delete($rec)) throw new RuntimeException('Modification réservée à l’auteur ou à un administrateur.');
    $rec['category']=$category;
    $rec['pdf_version']=1; // régénération à la prochaine ouverture du PDF
    $base = eat_recipe_dir();
    $path = $base.'/'.$id.'.json';
    $tmp = $path.'.'.bin2hex(random_bytes(5)).'.tmp';
    if (@file_put_contents($tmp,json_encode($rec,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),LOCK_EX) === false || !@rename($tmp,$path)) {
        @unlink($tmp); throw new RuntimeException('Enregistrement de la catégorie impossible.');
    }
    return $category;
}


/** Recettes personnelles : même stockage, droits et moteur PDF que les recettes importées. */
function eat_manual_lines($raw, $limit=100, $itemLimit=500) {
    if (!is_string($raw)) throw new InvalidArgumentException('Liste invalide.');
    if (strlen($raw)>65000) throw new InvalidArgumentException('Texte trop long.');
    $lines=preg_split('/\r\n|\r|\n/u',$raw);$out=[];
    foreach($lines as $line) {
        $line=eat_text($line,$itemLimit);
        if($line!=='') $out[]=$line;
        if(count($out)>$limit) throw new InvalidArgumentException('Trop de lignes dans la recette.');
    }
    return $out;
}
function eat_manual_picture($file) {
    if (!is_array($file) || ($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) return null;
    if(($file['error']??1)!==UPLOAD_ERR_OK || ($file['size']??0)>4000000 || ($file['size']??0)<100 ||
       !is_uploaded_file((string)($file['tmp_name']??''))) throw new InvalidArgumentException('Photo invalide (JPG, PNG ou WEBP, maximum 4 Mo).');
    $bytes=@file_get_contents($file['tmp_name']);
    if(!is_string($bytes) || strlen($bytes)>4000000) throw new InvalidArgumentException('Photo trop volumineuse.');
    $info=@getimagesizefromstring($bytes);
    if(!$info || $info[0]<1 || $info[1]<1 || $info[0]*$info[1]>16000000 ||
        !in_array($info[2],[IMAGETYPE_JPEG,IMAGETYPE_PNG,IMAGETYPE_WEBP],true)) throw new InvalidArgumentException('Photo non prise en charge.');
    if(function_exists('imagecreatefromstring') && function_exists('imagejpeg')) {
        $src=@imagecreatefromstring($bytes);
        if(!$src) throw new InvalidArgumentException('Photo illisible.');
        $scale=min(1,1600/max(imagesx($src),imagesy($src)));
        $w=max(1,(int)round(imagesx($src)*$scale));$h=max(1,(int)round(imagesy($src)*$scale));
        $dst=imagecreatetruecolor($w,$h);
        imagefill($dst,0,0,imagecolorallocate($dst,255,255,255));
        imagecopyresampled($dst,$src,0,0,0,0,$w,$h,imagesx($src),imagesy($src));
        ob_start(); imagejpeg($dst,null,85);$jpg=ob_get_clean();
        imagedestroy($dst);imagedestroy($src);
        if(!is_string($jpg)||strlen($jpg)<100) throw new RuntimeException('Conversion de la photo impossible.');
        return $jpg;
    }
    if($info[2]===IMAGETYPE_JPEG && ($info['channels']??3)===3) return $bytes;
    throw new InvalidArgumentException('Pour les photos PNG/WEBP, le serveur doit avoir GD activé.');
}
function eat_manual_image_url($id) {
    return rtrim(eat_base_url(),'/').'/DMD-EAT_api.php?action=photo&id='.rawurlencode($id);
}
function eat_manual_save($input, $files) {
    $id=trim((string)($input['id']??''));$existing=null;
    if($id!=='') {
        $existing=eat_find_saved($id);
        if(!$existing) throw new InvalidArgumentException('Recette à modifier introuvable.');
        if(($existing['origin']??'')!=='manual') throw new InvalidArgumentException('Seules les recettes personnelles peuvent être modifiées.');
        if(!eat_can_delete($existing)) eat_fail('Modification réservée à l’auteur ou un administrateur.',403);
    } else $id=bin2hex(random_bytes(12));
    $title=eat_text($input['title']??'',160);if($title==='' || strlen($title)>260) throw new InvalidArgumentException('Titre obligatoire (160 caractères maximum).');
    $category=trim((string)($input['category']??'Autres recettes'));
    if(!in_array($category,eat_categories(),true)) throw new InvalidArgumentException('Catégorie inconnue.');
    $ingredients=eat_manual_lines($input['ingredients']??'',150,250);
    $steps=eat_manual_lines($input['steps']??'',120,1200);
    if(!$ingredients || !$steps) throw new InvalidArgumentException('Ajoutez des ingrédients et des étapes de préparation.');
    $servings=(string)($input['servings']??'');
    if($servings!=='' && (!ctype_digit($servings) || (int)$servings<1 || (int)$servings>100)) throw new InvalidArgumentException('Le nombre de personnes doit être compris entre 1 et 100.');
    $prep=eat_text($input['prep']??'',70);$cook=eat_text($input['cook']??'',70);
    $description=eat_text($input['description']??'',1000);
    $base=eat_recipe_dir();$pictureFile=$base.'/'.$id.'.jpg';
    $picture=eat_manual_picture($files['photo']??null);
    $remove=!empty($input['remove_photo']);
    if($picture===null && !$remove && is_file($pictureFile)) $picture=@file_get_contents($pictureFile);
    $rec=['id'=>$id,'origin'=>'manual','title'=>$title,'description'=>$description,
        'image'=>$picture!==null?eat_manual_image_url($id):'',
        'ingredients'=>$ingredients,'steps'=>$steps,'prep'=>$prep,'cook'=>$cook,'total'=>'',
        'servings'=>$servings!==''?$servings.' personnes':'',
        'category'=>$category,'recipe_category'=>$category,'source'=>'Recette personnelle','url'=>'',
        'saved_by'=>$existing['saved_by']??eat_user(),
        'saved_at'=>$existing['saved_at']??date('c'),'updated_at'=>date('c'),
        'pdf_version'=>2,'pdf_categories_revision'=>eat_category_revision()];
    $json=json_encode($rec,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
    $pdf=eat_make_pdf($rec,$picture);
    if(!is_string($pdf)||!is_string($json)) throw new RuntimeException('Génération de la recette impossible.');
    $tmp=$base.'/'.$id.'.'.bin2hex(random_bytes(6)).'.tmp';
    $written=[];
    try {
        if(@file_put_contents($tmp.'.pdf',$pdf,LOCK_EX)===false) throw new RuntimeException('Écriture du PDF impossible.');
        $written[]=$tmp.'.pdf';
        if(@file_put_contents($tmp.'.json',$json,LOCK_EX)===false) throw new RuntimeException('Écriture de la recette impossible.');
        $written[]=$tmp.'.json';
        if($picture!==null && @file_put_contents($tmp.'.jpg',$picture,LOCK_EX)===false) throw new RuntimeException('Écriture de la photo impossible.');
        if($picture!==null) $written[]=$tmp.'.jpg';
        if($picture!==null && !@rename($tmp.'.jpg',$pictureFile)) throw new RuntimeException('Photo impossible à enregistrer.');
        if(!@rename($tmp.'.pdf',$base.'/'.$id.'.pdf')) throw new RuntimeException('PDF impossible à finaliser.');
        if(!@rename($tmp.'.json',$base.'/'.$id.'.json')) throw new RuntimeException('Recette impossible à finaliser.');
        if($picture===null && is_file($pictureFile)) @unlink($pictureFile);
        foreach(['pdf','json','jpg'] as $ext) if(is_file($base.'/'.$id.'.'.$ext)) @chmod($base.'/'.$id.'.'.$ext,0640);
        return $id;
    } finally {foreach($written as $path) @unlink($path);}
}
