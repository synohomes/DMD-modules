<?php
require_once __DIR__.'/DMD-EAT_lib.php';
require_once __DIR__.'/DMD-EAT_pdf.php';
require_once __DIR__.'/DMD-EAT_shopping.php';
try {
    eat_need_access();
    $action=(string)($_GET['action']??$_POST['action']??'status');
    $method=(string)($_SERVER['REQUEST_METHOD']??'GET');
    $post=['manual_save','shopping_export','save','delete','category_save','category_add','category_rename','category_delete','config_save','site_save','site_delete'];
    if (in_array($action,$post,true)) {
        if ($method!=='POST') eat_fail('Méthode non autorisée.',405);
        eat_verify_csrf();
    } elseif ($method!=='GET') eat_fail('Méthode non autorisée.',405);
    if ($action==='status') {
        $settings=eat_settings();
        eat_json(['ok'=>true,'mode'=>$settings['visibility'],'sites'=>array_values(array_map(static function($s){ return ['id'=>$s['id'],'name'=>$s['name'],'enabled'=>$s['enabled']]; },$settings['sites'])),'admin'=>eat_admin(),'categories'=>$settings['categories']]);
    }
    if ($action==='search') {
        $q=trim((string)($_GET['q']??''));
        if (strlen($q)<2 || strlen($q)>130) eat_fail('Saisissez entre 2 et 130 caractères.',422);
        $list=[]; $errors=[];
        foreach (eat_settings()['sites'] as $s) {
            if(empty($s['enabled'])) continue;
            try { $list=array_merge($list,eat_search_site($s,$q)); }
            catch(Throwable $e) { $errors[]=$s['name'].' : '.$e->getMessage(); }
        }
        // Limiter les doublons par URL
        $seen=[]; $results=[];
        foreach($list as $r) { if(isset($seen[$r['url']])) continue; $seen[$r['url']]=1; $results[]=$r; }
        eat_json(['ok'=>true,'results'=>array_slice($results,0,100),'warnings'=>$errors]);
    }
    if ($action==='detail') {
        $url=trim((string)($_GET['url']??''));
        if (strlen($url)>1800) eat_fail('URL trop longue.');
        $s=eat_site_for_url($url); if (!$s) eat_fail('Recette hors des sites autorisés.',403);
        [$html,$final]=eat_fetch($url,$s['host']);
        eat_json(['ok'=>true,'recipe'=>eat_extract_recipe($html,$final,$s)]);
    }
    if ($action==='library') eat_json(['ok'=>true,'items'=>eat_list_saved(),'visibility'=>eat_settings()['visibility'],'categories'=>eat_categories()]);
    if ($action==='saved') {
        $r=eat_find_saved((string)($_GET['id']??''));
        if (!$r) eat_fail('Recette introuvable.',404);
        $canDelete=eat_can_delete($r); $r['category']=eat_recipe_category($r); unset($r['saved_by']);
        eat_json(['ok'=>true,'recipe'=>$r,'can_delete'=>$canDelete, 'can_edit_category'=>$canDelete,'can_edit_manual'=>($canDelete && ($r['origin']??'')==='manual'),'categories'=>eat_categories()]);
    }
    if ($action==='pdf') {
        $id=(string)($_GET['id']??''); $rec=eat_find_saved($id); if (!$rec) eat_fail('Recette introuvable.',404);
        $file=eat_pdf_saved($rec);
        if (!is_file($file)) eat_fail('PDF introuvable.',404);
        $download=!empty($_GET['download']);
        clearstatcache(true,$file); header('Content-Type: application/pdf'); header('Content-Length: '.filesize($file));
        header('X-Content-Type-Options: nosniff'); header('Cache-Control: private, no-store');
        header('Content-Disposition: '.($download?'attachment':'inline').'; filename="DMD-EAT-'.$id.'.pdf"');
        readfile($file); exit;
    }
    if ($action==='save') {
        $url=trim((string)($_POST['url']??''));
        if(strlen($url)>1800) eat_fail('URL trop longue.');
        $s=eat_site_for_url($url); if (!$s) eat_fail('Recette hors des sites autorisés.',403);
        // Ne jamais accepter recette/ingrédients provenant du navigateur : relecture côté serveur.
        [$html,$final]=eat_fetch($url,$s['host']);
        $recipe=eat_extract_recipe($html,$final,$s);
        $id=eat_save_recipe($recipe);
        eat_json(['ok'=>true,'message'=>'Recette et PDF enregistrés.','id'=>$id]);
    }
    if ($action==='manual_save') {
        $id=eat_manual_save($_POST,$_FILES);
        eat_json(['ok'=>true,'message'=>'Recette personnelle et PDF enregistrés.','id'=>$id]);
    }
    if ($action==='photo') {
        $id=(string)($_GET['id']??'');
        $rec=eat_find_saved($id);
        if(!$rec || ($rec['origin']??'')!=='manual') eat_fail('Photo introuvable.',404);
        $path=eat_recipe_dir().'/'.$id.'.jpg';
        if(!is_file($path)) eat_fail('Photo introuvable.',404);
        header('Content-Type: image/jpeg');
        header('Cache-Control: private, no-store');
        header('X-Content-Type-Options: nosniff');
        header('Content-Length: '.filesize($path));
        readfile($path);exit;
    }
    if ($action==='shopping_export') {
        $selection=json_decode((string)($_POST['selection']??''),true);
        eat_json(['ok'=>true,'shopping'=>eat_shopping_export($selection)]);
    }
    if ($action==='category_save') {
        $id=(string)($_POST['id']??''); $category=(string)($_POST['category']??'');
        eat_json(['ok'=>true,'category'=>eat_change_category($id,$category)]);
    }
    if ($action==='delete') {
        $id=(string)($_POST['id']??''); $rec=eat_find_saved($id); if(!$rec) eat_fail('Recette introuvable.',404);
        if(!eat_can_delete($rec)) eat_fail('Suppression réservée à l’auteur ou à un administrateur.',403);
        $dir=eat_recipe_dir();
        if(!@unlink($dir.'/'.$id.'.pdf')) eat_fail('Suppression du PDF impossible.',500);
        if(!@unlink($dir.'/'.$id.'.json')) eat_fail('Suppression de la fiche impossible.',500);
        @unlink($dir.'/'.$id.'.jpg'); @unlink($dir.'/'.$id.'.lock');
        eat_json(['ok'=>true,'message'=>'Recette supprimée.']);
    }
    if (in_array($action,['config','config_save','site_save','site_delete','category_add','category_rename','category_delete'],true)) {
        eat_need_access(true);
        if($action==='config') eat_json(['ok'=>true,'settings'=>eat_settings()]);
        if(in_array($action,['category_add','category_rename','category_delete'],true)) {
            $s=eat_manage_category($action,(string)($_POST['name']??''),(string)($_POST['new_name']??''),(string)($_POST['replacement']??'Autres recettes'));
            eat_json(['ok'=>true,'message'=>'Catégories mises à jour.','settings'=>$s]);
        }
        $s=eat_settings();
        if($action==='config_save') {
            $mode=(string)($_POST['visibility']??'');
            if(!in_array($mode,['public','private'],true)) eat_fail('Mode invalide.');
            // Le changement ne déplace ni n'expose les fichiers privés ou publics déjà existants.
            $s['visibility']=$mode;
        } elseif($action==='site_save') {
            $id=trim((string)($_POST['id']??''));
            $site=eat_validate_site($_POST,$id);
            if($id!=='' && !preg_match('/^[a-f0-9]{14}$|^marmiton$/D',$id)) eat_fail('Identifiant invalide.');
            $found=false;
            foreach ($s['sites'] as &$old) if($old['id']===$id) { $old=$site; $found=true; break; }
            unset($old);
            if(!$found) { if($id!=='') eat_fail('Site à modifier introuvable.',404); if(count($s['sites'])>=15) eat_fail('Maximum 15 sites.',422); $s['sites'][]=$site; }
        } elseif($action==='site_delete') {
            $id=(string)($_POST['id']??'');
            $s['sites']=array_values(array_filter($s['sites'],static function($entry)use($id){return $entry['id']!==$id;}));
        }
        eat_save_settings($s); eat_json(['ok'=>true,'message'=>'Configuration enregistrée.','settings'=>$s]);
    }
    eat_fail('Action inconnue.',404);
} catch(InvalidArgumentException $e) { eat_fail($e->getMessage(),422); }
catch(Throwable $e) { error_log('DMD-EAT: '.$e->getMessage()); eat_fail($e->getMessage(),500); }
