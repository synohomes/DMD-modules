<?php
/* Entrée autonome pour DoMyDesk MyDesk : reprend la même interface et les mêmes droits. */
require_once __DIR__.'/DMD-EAT_lib.php';
if (!eat_allowed()) { http_response_code(403); echo 'Module non autorisé'; exit; }
$theme='default'; $email=eat_user(); $safe='';
if(function_exists('dmd_safe_user_key')) try{$safe=dmd_safe_user_key($email);}catch(Throwable $e){}
if ($safe!=='' && preg_match('/^[a-zA-Z0-9_.@-]+$/',$safe)) {
 $file=eat_root().'/users/profiles/'.$safe.'/theme.json';
 if(is_file($file)){ $d=json_decode((string)@file_get_contents($file),true); foreach(['theme','selected_theme','selected','name'] as $k) { $v=(string)($d[$k]??'');if(preg_match('/^[a-zA-Z0-9_-]+$/',$v) && is_file(eat_root().'/theme/'.$v.'/style.css')) {$theme=$v;break;} } }
}
$rootUrl=preg_replace('~/modules/DMD-EAT/?$~','',eat_base_url());
?><!DOCTYPE html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>DMD-EAT · MyDesk</title><link rel="stylesheet" href="<?= eat_e($rootUrl) ?>/theme/<?= rawurlencode($theme) ?>/style.css"><style>body{margin:0;padding:8px;font-family:system-ui,sans-serif;background:var(--bg-color,var(--body-bg,#101827));color:var(--text-color,#e7edf6)}.dmd-eat{min-height:calc(100vh - 16px)}</style></head><body><?php include __DIR__.'/DMD-EAT.php'; ?></body></html>
