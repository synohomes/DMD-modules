<?php
require_once __DIR__.'/DMD-EAT_lib.php';
if (!eat_allowed()) { echo '<div class="dmd-eat-denied">Accès au module DMD-EAT non autorisé.</div>'; return; }
$eatUrl=eat_base_url();
?>
<link rel="stylesheet" href="<?= eat_e($eatUrl) ?>/DMD-EAT.css?v=140">
<div class="dmd-eat" data-eat-root data-base="<?= eat_e($eatUrl) ?>" data-csrf="<?= eat_e(eat_csrf()) ?>">
  <header class="eat-header">
    <div class="eat-identity"><div class="eat-brandmark">E</div><div><strong>DMD-EAT</strong><span>Bibliothèque culinaire DoMyDesk</span></div></div>
    <div class="eat-header-right"><span class="eat-mode" data-eat-mode>Chargement…</span><button type="button" class="eat-btn eat-btn-small" data-eat-refresh title="Actualiser">⟳ Actualiser</button></div>
  </header>
  <div class="eat-toolbar">
    <div class="eat-tabs"><button type="button" class="active" data-eat-tab="search">Rechercher</button><button type="button" data-eat-tab="library">Mes recettes</button></div>
    <div class="eat-toolbar-actions"><button type="button" class="eat-btn eat-btn-primary eat-btn-small" data-eat-manual-new>+ Ma recette</button><div class="eat-count" data-eat-count></div></div>
  </div>
  <div class="eat-notice" data-eat-notice hidden></div>
  <section class="eat-section" data-eat-panel="search">
    <form class="eat-search" data-eat-search><input type="search" name="q" aria-label="Chercher une recette" placeholder="Chercher une recette, un plat, un ingrédient…" minlength="2" maxlength="130" required><button class="eat-btn eat-btn-primary" type="submit">Rechercher</button></form>
    <div class="eat-sourcebar" data-eat-sources>Sources configurées dans l'administration</div>
    <div class="eat-grid" data-eat-results><div class="eat-empty">Cherchez un plat pour afficher les recettes disponibles sur vos sites.</div></div>
  </section>
  <section class="eat-section" data-eat-panel="library" hidden>
    <div class="eat-libtools"><input type="search" placeholder="Rechercher dans les recettes…" data-eat-filter><button type="button" class="eat-btn eat-btn-small" data-eat-shop-select>Liste de courses</button><span data-eat-lib-count></span></div>
    <div class="eat-shopping-toolbar" data-eat-shop-toolbar hidden><span data-eat-shop-count>0 sélectionnée</span><button type="button" class="eat-btn eat-btn-small eat-btn-primary" data-eat-shop-generate disabled>Préparer</button><button type="button" class="eat-btn eat-btn-small" data-eat-shop-cancel>Annuler</button></div>
    <div class="eat-categories" data-eat-categories role="group" aria-label="Catégories de recettes"></div>
    <div class="eat-library-list" data-eat-library><div class="eat-empty">Chargement de la bibliothèque…</div></div>
  </section>
  <div class="eat-modal" data-eat-modal hidden role="dialog" aria-modal="true" aria-label="Fiche recette">
    <div class="eat-backdrop" data-eat-close></div>
    <div class="eat-dialog"><div class="eat-dialog-bar"><strong>Fiche recette</strong><button type="button" class="eat-icon-btn" data-eat-close aria-label="Fermer">✕</button></div><div class="eat-dialog-content" data-eat-detail></div></div>
  </div>
</div>
<script>(function(){function boot(){if(window.DMDEATInit)window.DMDEATInit();}if(window.DMDEATInit&&window.DMDEATBuild===140){boot();return;}var s=document.createElement('script');s.src=<?= json_encode($eatUrl.'/DMD-EAT.js?v=140',JSON_UNESCAPED_SLASHES) ?>;s.onload=boot;document.head.appendChild(s);}());</script>
