<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
require_once __DIR__ . '/dmd-games_lib.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$email = dmd_games_current_email();
if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'not_logged'));
    exit;
}
if (!dmd_games_require_permissions(array('module.view', 'games.save'), true)) {
    exit;
}

$game = trim((string)($_GET['game'] ?? $_POST['game'] ?? ''));
if (!preg_match('/^[a-zA-Z0-9_-]{2,64}$/', $game)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'invalid_game'));
    exit;
}

$profiles = realpath(__DIR__ . '/../../users/profiles');
if ($profiles === false) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'profiles_unavailable'));
    exit;
}

$profileDir = $profiles . DIRECTORY_SEPARATOR . $email;
$profileReal = realpath($profileDir);
if ($profileReal === false || !is_dir($profileReal)) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'profile_unavailable'));
    exit;
}

$moduleDir = $profileReal . DIRECTORY_SEPARATOR . 'DMD-Games';
$saveDir = $moduleDir . DIRECTORY_SEPARATOR . 'saves';
if (!is_dir($saveDir) && !@mkdir($saveDir, 0750, true) && !is_dir($saveDir)) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'mkdir_failed'));
    exit;
}
@chmod($moduleDir, 0750);
@chmod($saveDir, 0750);

$htaccess = $moduleDir . DIRECTORY_SEPARATOR . '.htaccess';
if (!is_file($htaccess)) {
    @file_put_contents($htaccess, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n", LOCK_EX);
    @chmod($htaccess, 0640);
}

$file = $saveDir . DIRECTORY_SEPARATOR . $game . '.json';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $data = array();
    if (is_file($file)) {
        $decoded = json_decode((string)@file_get_contents($file), true);
        if (is_array($decoded)) $data = $decoded;
    }
    echo json_encode(array('ok' => true, 'data' => $data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array('ok' => false, 'error' => 'method_not_allowed'));
    exit;
}

$raw = (string)file_get_contents('php://input');
if (strlen($raw) > 262144) {
    http_response_code(413);
    echo json_encode(array('ok' => false, 'error' => 'too_large'));
    exit;
}

$payload = json_decode($raw, true);
$data = is_array($payload) ? ($payload['data'] ?? null) : null;
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'invalid_data'));
    exit;
}

$data['_updated'] = date(DATE_ATOM);
$json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if ($json === false || @file_put_contents($file, $json, LOCK_EX) === false) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'save_failed'));
    exit;
}
@chmod($file, 0640);
echo json_encode(array('ok' => true));
