<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
require_once __DIR__ . '/dmd-games_lib.php';

if (!dmd_games_require_permissions(array('module.view'))) {
    return;
}

$moduleBaseUrl = dmd_games_module_base_url();
$games = dmd_games_scan();
$canPlay = dmd_games_has_permission('games.play');
$canSave = dmd_games_has_permission('games.save');
$uid = 'dmdGames_' . substr(hash('sha256', __DIR__ . microtime(true)), 0, 10);
$cssUrl = $moduleBaseUrl . '/DMD-Games.css?v=' . (int)@filemtime(__DIR__ . '/DMD-Games.css');
?>
<link rel="stylesheet" href="<?= dmd_games_h($cssUrl) ?>">

<div class="dmd-games" id="<?= dmd_games_h($uid) ?>" data-dmd-games-root="1" data-can-play="<?= $canPlay ? '1' : '0' ?>" data-can-save="<?= $canSave ? '1' : '0' ?>">
    <section class="dmd-games-library" data-library>
        <div class="dmd-games-toolbar">
            <div class="dmd-games-brand">
                <span class="dmd-games-brand-icon" aria-hidden="true">🎮</span>
                <span>
                    <strong>DMD-Games</strong>
                    <small><?= count($games) ?> jeux locaux<?= !$canSave ? ' · progression non enregistrée' : '' ?></small>
                </span>
            </div>
            <input data-search class="dmd-games-search" type="search" placeholder="Rechercher…" autocomplete="off" aria-label="Rechercher un jeu">
        </div>

        <?php if (!$canPlay): ?>
            <div class="dmd-games-rights-note">🔒 Le droit <strong>Jouer</strong> n’est pas accordé à ce compte.</div>
        <?php endif; ?>

        <div class="dmd-games-grid" data-grid>
            <?php foreach ($games as $game):
                $searchText = $game['name'] . ' ' . $game['description'] . ' ' . $game['category'];
                $searchText = function_exists('mb_strtolower') ? mb_strtolower($searchText, 'UTF-8') : strtolower($searchText);
                $gameUrl = dmd_games_game_url($game, $moduleBaseUrl);
            ?>
                <button
                    class="dmd-game-card<?= !$canPlay ? ' is-disabled' : '' ?>"
                    type="button"
                    data-game-card
                    data-search-text="<?= dmd_games_h($searchText) ?>"
                    data-game-url="<?= dmd_games_h($gameUrl) ?>"
                    data-game-title="<?= dmd_games_h($game['name']) ?>"
                    title="<?= $canPlay ? 'Jouer à ' . dmd_games_h($game['name']) : 'Jeu non autorisé pour ce compte' ?>"
                    <?= !$canPlay ? 'disabled aria-disabled="true"' : '' ?>
                >
                    <span class="dmd-game-icon" aria-hidden="true"><?= dmd_games_h($game['emoji']) ?></span>
                    <span class="dmd-game-copy">
                        <strong><?= dmd_games_h($game['name']) ?></strong>
                        <small><?= dmd_games_h($game['description']) ?></small>
                    </span>
                    <span class="dmd-game-play"><?= $canPlay ? 'Jouer ›' : 'Interdit' ?></span>
                </button>
            <?php endforeach; ?>
        </div>

        <?php if (!$games): ?>
            <div class="dmd-games-empty">Aucun jeu valide détecté dans <code>jeu/</code>.</div>
        <?php endif; ?>
    </section>

    <section class="dmd-games-player" data-player hidden>
        <div class="dmd-games-playerbar">
            <button type="button" data-back>‹ Jeux</button>
            <strong data-player-title>Jeu</strong>
            <button type="button" data-reload title="Recharger" aria-label="Recharger le jeu">↻</button>
        </div>
        <iframe
            data-frame
            class="dmd-games-frame"
            title="Jeu DMD-Games"
            src="about:blank"
            sandbox="allow-scripts allow-same-origin allow-forms allow-modals allow-downloads"
        ></iframe>
    </section>
</div>

<script>
(() => {
    const root = document.getElementById(<?= json_encode($uid, JSON_UNESCAPED_SLASHES) ?>);
    if (!root || root.dataset.ready === '1') return;
    root.dataset.ready = '1';

    const library = root.querySelector('[data-library]');
    const player = root.querySelector('[data-player]');
    const frame = root.querySelector('[data-frame]');
    const title = root.querySelector('[data-player-title]');
    const search = root.querySelector('[data-search]');
    const canPlay = root.dataset.canPlay === '1';

    function announceResize(){
        try { root.dispatchEvent(new CustomEvent('dmd:module-content-resize', { bubbles:true, detail:{ module:'DMD-Games' } })); } catch (_) {}
    }

    function showLibrary(){
        frame.src = 'about:blank';
        player.hidden = true;
        player.style.display = 'none';
        library.style.display = 'flex';
        announceResize();
    }

    function openGame(card){
        if (!canPlay || !card || card.disabled) return;
        const url = card.dataset.gameUrl || '';
        if (!url) return;
        title.textContent = card.dataset.gameTitle || 'Jeu';
        frame.src = url;
        library.style.display = 'none';
        player.hidden = false;
        player.style.display = 'grid';
        announceResize();
    }

    root.addEventListener('click', event => {
        const card = event.target.closest('[data-game-card]');
        if (card && root.contains(card)) { event.preventDefault(); openGame(card); return; }
        if (event.target.closest('[data-back]')) { event.preventDefault(); showLibrary(); return; }
        if (event.target.closest('[data-reload]')) {
            event.preventDefault();
            try { frame.contentWindow.location.reload(); } catch (_) { frame.src = frame.src; }
        }
    });

    if (search) search.addEventListener('input', () => {
        const q = search.value.trim().toLocaleLowerCase('fr');
        root.querySelectorAll('[data-game-card]').forEach(card => {
            card.hidden = q !== '' && !(card.dataset.searchText || '').includes(q);
        });
        announceResize();
    });
})();
</script>
