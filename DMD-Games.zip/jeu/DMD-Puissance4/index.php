<?php require_once __DIR__ . '/../_shared/bootstrap.php'; ?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="<?= htmlspecialchars($dmdGameThemeCss, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="../_shared/game.css">
<style>
.p4-wrap{display:grid;grid-template-columns:minmax(360px,620px) 180px;gap:10px;justify-content:center;align-items:start}.p4-boardbox{padding:8px}.p4-columns{display:grid;grid-template-columns:repeat(7,1fr);gap:5px;margin-bottom:5px}.p4-col{height:25px;border:1px solid #31516f;border-radius:5px;background:#10223a;color:#9fc3df;cursor:pointer;font-size:11px}.p4-col:hover:not(:disabled){background:#183454;color:#fff}.p4-col:disabled{opacity:.28;cursor:not-allowed}.p4-board{display:grid;grid-template-columns:repeat(7,1fr);gap:5px;padding:9px;border-radius:8px;background:linear-gradient(180deg,#123a68,#0d2c52);box-shadow:inset 0 0 0 1px #315b84}.p4-slot{position:relative;aspect-ratio:1;border-radius:50%;border:1px solid #3d6285;background:#07111f;box-shadow:inset 0 5px 10px rgba(0,0,0,.55);overflow:hidden}.p4-disc{position:absolute;inset:5%;border-radius:50%;transform:scale(.94);box-shadow:inset 0 3px 5px rgba(255,255,255,.18),0 2px 5px rgba(0,0,0,.3)}.p4-disc.red{background:linear-gradient(145deg,#ff6b72,#c93d49)}.p4-disc.yellow{background:linear-gradient(145deg,#ffe275,#d4a82d)}.p4-slot.drop .p4-disc{animation:p4drop .22s ease-out}.p4-slot.win{box-shadow:0 0 0 3px #fff,0 0 16px #fff}.p4-side{padding:8px;display:grid;align-content:start;gap:7px}.p4-turn{font-weight:700;color:#e8c34c}.p4-legend{display:flex;align-items:center;gap:5px;font-size:9px;color:#9fb5d0}.p4-dot{width:12px;height:12px;border-radius:50%}.p4-dot.you{background:#d8535c}.p4-dot.cpu{background:#e8c34c}@keyframes p4drop{from{transform:translateY(-120%) scale(.9);opacity:.2}to{transform:translateY(0) scale(.94);opacity:1}}@media(max-width:650px){.p4-wrap{grid-template-columns:1fr}.p4-side{grid-template-columns:repeat(2,minmax(0,1fr))}.p4-side .g-message{grid-column:1/-1}}
</style>
</head>
<body>
<div class="g-app"><section class="g-shell">
<header class="g-top">
  <div class="g-title"><span>🔴</span><div><b>DMD-Puissance 4</b><div class="g-sub">Aligne 4 jetons avant l'ordinateur</div></div></div>
  <div class="g-actions">
    <select id="difficulty" class="g-select" title="Difficulté"><option value="easy">Facile</option><option value="normal" selected>Normal</option><option value="hard">Difficile</option></select>
    <button id="new" class="g-btn primary" type="button">Nouvelle partie</button>
  </div>
</header>
<div class="g-body p4-wrap">
  <section class="g-panel p4-boardbox">
    <div id="columns" class="p4-columns" aria-label="Choisir une colonne"></div>
    <div id="board" class="p4-board" role="grid" aria-label="Grille de Puissance 4"></div>
  </section>
  <aside class="g-panel p4-side">
    <div class="g-stat"><small>Victoires</small><strong id="wins">0</strong></div>
    <div class="g-stat"><small>Ordinateur</small><strong id="losses">0</strong></div>
    <div class="g-stat"><small>Nuls</small><strong id="draws">0</strong></div>
    <div class="p4-legend"><span class="p4-dot you"></span> Toi</div>
    <div class="p4-legend"><span class="p4-dot cpu"></span> Ordinateur</div>
    <div id="msg" class="g-message"><span class="p4-turn">À toi :</span> choisis une colonne.</div>
  </aside>
</div>
</section></div>
<div id="over" class="g-overlay"><div class="g-modal"><h2 id="title">Partie terminée</h2><p id="endmsg"></p><button id="again" class="g-btn primary" type="button">Rejouer</button></div></div>
<script>
(() => {
'use strict';
const ROWS=6,COLS=7,HUMAN=1,CPU=2;
const boardEl=document.getElementById('board');
const columnsEl=document.getElementById('columns');
const msgEl=document.getElementById('msg');
const overEl=document.getElementById('over');
const titleEl=document.getElementById('title');
const endEl=document.getElementById('endmsg');
const diffEl=document.getElementById('difficulty');
let board=[],busy=false,ended=false,lastDrop=null;
let stats={wins:0,losses:0,draws:0};

function freshBoard(){return Array.from({length:ROWS},()=>Array(COLS).fill(0));}
function validCols(b=board){const out=[];for(let c=0;c<COLS;c++)if(b[0][c]===0)out.push(c);return out;}
function drop(b,col,player){if(col<0||col>=COLS||b[0][col]!==0)return -1;for(let r=ROWS-1;r>=0;r--){if(b[r][col]===0){b[r][col]=player;return r;}}return -1;}
function clone(b){return b.map(r=>r.slice());}
function winLine(player,b=board){const dirs=[[0,1],[1,0],[1,1],[1,-1]];for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){if(b[r][c]!==player)continue;for(const [dr,dc] of dirs){const cells=[];for(let k=0;k<4;k++){const rr=r+dr*k,cc=c+dc*k;if(rr<0||rr>=ROWS||cc<0||cc>=COLS||b[rr][cc]!==player){cells.length=0;break;}cells.push([rr,cc]);}if(cells.length===4)return cells;}}return null;}
function boardFull(b=board){return validCols(b).length===0;}
function isWinCell(line,r,c){return Array.isArray(line)&&line.some(([rr,cc])=>rr===r&&cc===c);}
function render(line=null){
  boardEl.innerHTML='';
  for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){
    const slot=document.createElement('div');slot.className='p4-slot';slot.setAttribute('role','gridcell');
    if(isWinCell(line,r,c))slot.classList.add('win');
    if(lastDrop&&lastDrop.r===r&&lastDrop.c===c)slot.classList.add('drop');
    const v=board[r][c];if(v){const disc=document.createElement('span');disc.className='p4-disc '+(v===HUMAN?'red':'yellow');slot.appendChild(disc);}boardEl.appendChild(slot);
  }
  columnsEl.innerHTML='';
  for(let c=0;c<COLS;c++){
    const btn=document.createElement('button');btn.type='button';btn.className='p4-col';btn.textContent='▼';btn.title='Jouer colonne '+(c+1);btn.disabled=busy||ended||board[0][c]!==0;btn.addEventListener('click',()=>humanPlay(c));columnsEl.appendChild(btn);
  }
  document.getElementById('wins').textContent=stats.wins;
  document.getElementById('losses').textContent=stats.losses;
  document.getElementById('draws').textContent=stats.draws;
}
function scoreWindow(vals){const cpu=vals.filter(v=>v===CPU).length,h=vals.filter(v=>v===HUMAN).length,e=vals.filter(v=>v===0).length;if(cpu===4)return 100000;if(cpu===3&&e===1)return 120;if(cpu===2&&e===2)return 14;if(h===3&&e===1)return -140;if(h===2&&e===2)return -10;return 0;}
function scorePosition(b){let s=0;const center=[];for(let r=0;r<ROWS;r++)center.push(b[r][3]);s+=center.filter(v=>v===CPU).length*6;for(let r=0;r<ROWS;r++)for(let c=0;c<COLS-3;c++)s+=scoreWindow([b[r][c],b[r][c+1],b[r][c+2],b[r][c+3]]);for(let c=0;c<COLS;c++)for(let r=0;r<ROWS-3;r++)s+=scoreWindow([b[r][c],b[r+1][c],b[r+2][c],b[r+3][c]]);for(let r=0;r<ROWS-3;r++)for(let c=0;c<COLS-3;c++)s+=scoreWindow([b[r][c],b[r+1][c+1],b[r+2][c+2],b[r+3][c+3]]);for(let r=3;r<ROWS;r++)for(let c=0;c<COLS-3;c++)s+=scoreWindow([b[r][c],b[r-1][c+1],b[r-2][c+2],b[r-3][c+3]]);return s;}
function minimax(b,depth,alpha,beta,maxing){const cpuWin=winLine(CPU,b),humanWin=winLine(HUMAN,b),valid=validCols(b);if(cpuWin)return 1000000+depth;if(humanWin)return -1000000-depth;if(depth===0||valid.length===0)return scorePosition(b);if(maxing){let value=-Infinity;for(const c of valid){const n=clone(b);drop(n,c,CPU);value=Math.max(value,minimax(n,depth-1,alpha,beta,false));alpha=Math.max(alpha,value);if(alpha>=beta)break;}return value;}let value=Infinity;for(const c of valid){const n=clone(b);drop(n,c,HUMAN);value=Math.min(value,minimax(n,depth-1,alpha,beta,true));beta=Math.min(beta,value);if(alpha>=beta)break;}return value;}
function immediateMove(player){for(const c of validCols()){const b=clone(board);drop(b,c,player);if(winLine(player,b))return c;}return null;}
function cpuChoice(){const valid=validCols();if(!valid.length)return null;const diff=diffEl.value;if(diff==='easy')return valid[Math.floor(Math.random()*valid.length)];let c=immediateMove(CPU);if(c!==null)return c;c=immediateMove(HUMAN);if(c!==null)return c;if(diff==='normal'){const prefs=[3,2,4,1,5,0,6].filter(x=>valid.includes(x));return Math.random()<.72?prefs[0]:prefs[Math.floor(Math.random()*prefs.length)];}let bestScore=-Infinity,best=[];for(const col of valid){const b=clone(board);drop(b,col,CPU);const score=minimax(b,4,-Infinity,Infinity,false);if(score>bestScore){bestScore=score;best=[col];}else if(score===bestScore)best.push(col);}return best[Math.floor(Math.random()*best.length)];}
async function loadStats(){try{const r=await fetch('../../save.php?game=dmd-puissance4',{cache:'no-store'});if(!r.ok)return;const j=await r.json();const d=j&&j.data&&typeof j.data==='object'?j.data:{};stats={wins:Number(d.wins)||0,losses:Number(d.losses??d.cpu)||0,draws:Number(d.draws)||0};render();}catch(_){}}
function saveStats(){fetch('../../save.php?game=dmd-puissance4',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data:stats})}).catch(()=>{});}
function finish(result,line){ended=true;busy=false;render(line);if(result==='human'){stats.wins++;titleEl.textContent='Bravo 🎉';endEl.textContent='Tu as aligné quatre jetons avant l’ordinateur.';}else if(result==='cpu'){stats.losses++;titleEl.textContent='L’ordinateur gagne';endEl.textContent='Il a aligné quatre jetons. Revanche ?';}else{stats.draws++;titleEl.textContent='Match nul';endEl.textContent='La grille est pleine : personne ne gagne.';}saveStats();render(line);overEl.classList.add('show');}
function cpuPlay(){if(ended)return;const col=cpuChoice();if(col===null){finish('draw',null);return;}const row=drop(board,col,CPU);lastDrop={r:row,c:col};render();const line=winLine(CPU);if(line){finish('cpu',line);return;}if(boardFull()){finish('draw',null);return;}busy=false;msgEl.innerHTML='<span class="p4-turn">À toi :</span> choisis une colonne.';render();}
function humanPlay(col){if(busy||ended||board[0][col]!==0)return;const row=drop(board,col,HUMAN);lastDrop={r:row,c:col};render();const line=winLine(HUMAN);if(line){finish('human',line);return;}if(boardFull()){finish('draw',null);return;}busy=true;msgEl.textContent='L’ordinateur réfléchit…';render();window.setTimeout(cpuPlay,diffEl.value==='hard'?220:320);}
function start(){board=freshBoard();busy=false;ended=false;lastDrop=null;overEl.classList.remove('show');msgEl.innerHTML='<span class="p4-turn">À toi :</span> choisis une colonne.';render();}

document.getElementById('new').addEventListener('click',start);
document.getElementById('again').addEventListener('click',start);
diffEl.addEventListener('change',start);
start();
loadStats();
})();
</script>
</body></html>
