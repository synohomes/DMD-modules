<?php
if (session_status() === PHP_SESSION_NONE) @session_start();

require_once dirname(__DIR__, 2) . '/dmd-games_lib.php';

/* Un URL direct vers jeu/... ne doit jamais contourner les droits du module. */
if (!dmd_games_require_permissions(array('module.view', 'games.play'))) {
    exit;
}

$dmdGameThemeName = 'default';
$dmdGameEmail = dmd_games_current_email();
if ($dmdGameEmail !== '' && filter_var($dmdGameEmail, FILTER_VALIDATE_EMAIL)) {
    $dmdGameThemeFile = DMD_ROOT . '/users/profiles/' . $dmdGameEmail . '/theme.json';
    if (is_file($dmdGameThemeFile)) {
        $dmdGameThemeData = json_decode((string)@file_get_contents($dmdGameThemeFile), true);
        $dmdGameCandidate = is_array($dmdGameThemeData)
            ? ($dmdGameThemeData['theme'] ?? $dmdGameThemeData['selected_theme'] ?? $dmdGameThemeData['selected'] ?? $dmdGameThemeData['name'] ?? null)
            : null;
        if (is_string($dmdGameCandidate) && preg_match('/^[a-zA-Z0-9_-]+$/', $dmdGameCandidate)) {
            $dmdGameThemeName = $dmdGameCandidate;
        }
    }
}
$dmdGameThemeFs = DMD_ROOT . '/theme/' . $dmdGameThemeName . '/style.css';
if (!is_file($dmdGameThemeFs)) $dmdGameThemeName = 'default';
$dmdGameThemeCss = '../../../../theme/' . rawurlencode($dmdGameThemeName) . '/style.css';
