window.DMDGameSave = {
  async load(game){try{const r=await fetch('../../save.php?game='+encodeURIComponent(game),{cache:'no-store'});if(!r.ok)return {};const j=await r.json();return j&&j.data&&typeof j.data==='object'?j.data:{}}catch(e){return {}}},
  async save(game,data){try{const r=await fetch('../../save.php?game='+encodeURIComponent(game),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({data})});return r.ok}catch(e){return false}}
};
window.DMDUtil={shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a},time(s){const m=Math.floor(s/60);return String(m).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}};
