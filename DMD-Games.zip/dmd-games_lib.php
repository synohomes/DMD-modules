<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

if (!defined('DMD_ROOT')) {
    define('DMD_ROOT', dirname(__DIR__, 2));
}
if (!defined('DMD_GAMES_ID')) {
    define('DMD_GAMES_ID', 'DMD-Games');
}
if (!defined('DMD_GAMES_VERSION')) {
    define('DMD_GAMES_VERSION', '1.4.2');
}

$permissionsFile = DMD_ROOT . '/core/dmd_permissions.php';
if (is_file($permissionsFile)) {
    require_once $permissionsFile;
}

if (!function_exists('dmd_games_h')) {
    function dmd_games_h($value) {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('dmd_games_current_email')) {
    function dmd_games_current_email() {
        return trim((string)($_SESSION['user']['email'] ?? ''));
    }
}

if (!function_exists('dmd_games_has_permission')) {
    function dmd_games_has_permission($permission) {
        $email = dmd_games_current_email();
        if ($email === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            return false;
        }
        if (function_exists('dmd_user_has_module_permission')) {
            return dmd_user_has_module_permission($email, DMD_GAMES_ID, (string)$permission);
        }
        return false;
    }
}

if (!function_exists('dmd_games_require_permissions')) {
    function dmd_games_require_permissions($permissions, $json = false) {
        $permissions = is_array($permissions) ? $permissions : array($permissions);
        $ok = true;
        foreach ($permissions as $permission) {
            if (!dmd_games_has_permission((string)$permission)) {
                $ok = false;
                break;
            }
        }
        if ($ok) return true;

        http_response_code(403);
        if ($json) {
            header('Content-Type: application/json; charset=utf-8');
            header('X-Content-Type-Options: nosniff');
            echo json_encode(array('ok' => false, 'error' => 'forbidden'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } else {
            echo '<div class="dmd-games-denied">⛔ Accès DMD-Games refusé.</div>';
        }
        return false;
    }
}

if (!function_exists('dmd_games_module_base_url')) {
    function dmd_games_module_base_url() {
        $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
        $moduleDir = realpath(__DIR__) ?: __DIR__;
        if ($docRoot !== '' && strpos($moduleDir, $docRoot) === 0) {
            return '/' . ltrim(str_replace('\\', '/', substr($moduleDir, strlen($docRoot))), '/');
        }

        $scriptName = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
        $scriptDir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
        if ($scriptDir !== '' && $scriptDir !== '.' && $scriptDir !== '/') {
            return $scriptDir;
        }

        return '/domydesk/modules/DMD-Games';
    }
}

if (!function_exists('dmd_games_user_theme_url')) {
    function dmd_games_user_theme_url($email, $moduleBaseUrl = '') {
        $email = trim((string)$email);
        $theme = 'default';

        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) !== false) {
            $safe = function_exists('dmd_safe_user_key') ? dmd_safe_user_key($email) : basename($email);
            if ($safe !== '') {
                $themeFile = DMD_ROOT . '/users/profiles/' . $safe . '/theme.json';
                if (is_file($themeFile)) {
                    $data = json_decode((string)@file_get_contents($themeFile), true);
                    $candidate = is_array($data)
                        ? ($data['theme'] ?? $data['selected_theme'] ?? $data['selected'] ?? $data['name'] ?? '')
                        : '';
                    if (is_string($candidate) && preg_match('/^[a-zA-Z0-9_-]+$/', $candidate)) {
                        $candidate = basename($candidate);
                        if (is_file(DMD_ROOT . '/theme/' . $candidate . '/style.css')) {
                            $theme = $candidate;
                        }
                    }
                }
            }
        }

        $base = rtrim((string)$moduleBaseUrl, '/');
        $webRoot = preg_replace('~/modules/DMD-Games/?$~i', '', $base);
        if (!is_string($webRoot)) $webRoot = '';
        return ($webRoot !== '' ? $webRoot : '') . '/theme/' . rawurlencode($theme) . '/style.css';
    }
}

if (!function_exists('dmd_games_scan')) {
    function dmd_games_scan() {
        $games = array();
        $gamesRoot = __DIR__ . '/jeu';
        if (!is_dir($gamesRoot)) return $games;

        $entries = @scandir($gamesRoot);
        if (!is_array($entries)) return $games;

        foreach ($entries as $dir) {
            if ($dir === '.' || $dir === '..' || substr($dir, 0, 1) === '_') continue;
            if (!preg_match('/^[a-zA-Z0-9_-]+$/', $dir)) continue;

            $folder = $gamesRoot . '/' . $dir;
            $manifestFile = $folder . '/game.json';
            if (!is_dir($folder) || !is_file($manifestFile)) continue;

            $manifest = json_decode((string)@file_get_contents($manifestFile), true);
            if (!is_array($manifest)) continue;

            $entry = trim((string)($manifest['entrypoint'] ?? 'index.php'));
            if (
                $entry === '' ||
                strpos($entry, '..') !== false ||
                substr($entry, 0, 1) === '/' ||
                preg_match('~^[a-z][a-z0-9+.-]*://~i', $entry)
            ) {
                continue;
            }

            $entry = str_replace('\\', '/', $entry);
            $entryPath = $folder . '/' . $entry;
            $entryReal = realpath($entryPath);
            $folderReal = realpath($folder);
            if (
                $entryReal === false ||
                $folderReal === false ||
                strpos($entryReal, $folderReal . DIRECTORY_SEPARATOR) !== 0 ||
                !is_file($entryReal)
            ) {
                continue;
            }

            $games[] = array(
                'id' => trim((string)($manifest['id'] ?? $dir)),
                'dir' => $dir,
                'name' => trim((string)($manifest['name'] ?? $dir)),
                'emoji' => trim((string)($manifest['emoji'] ?? '🎮')),
                'description' => trim((string)($manifest['description'] ?? '')),
                'category' => trim((string)($manifest['category'] ?? 'Jeu')),
                'version' => trim((string)($manifest['version'] ?? '1.0.0')),
                'entrypoint' => $entry,
            );
        }

        usort($games, function ($a, $b) {
            return strnatcasecmp((string)$a['name'], (string)$b['name']);
        });
        return $games;
    }
}

if (!function_exists('dmd_games_game_url')) {
    function dmd_games_game_url($game, $moduleBaseUrl) {
        if (!is_array($game)) return '';
        $dir = rawurlencode((string)($game['dir'] ?? ''));
        $entry = str_replace('\\', '/', (string)($game['entrypoint'] ?? 'index.php'));
        $parts = array();
        foreach (explode('/', $entry) as $part) {
            if ($part === '') continue;
            $parts[] = rawurlencode($part);
        }
        return rtrim((string)$moduleBaseUrl, '/') . '/jeu/' . $dir . '/' . implode('/', $parts);
    }
}
