<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
require_once __DIR__ . '/dmd-games_lib.php';

$email = dmd_games_current_email();
if ($email === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    echo '<div class="dmd-games-mydesk dmd-games-md-denied">⛔ Connexion MyDesk requise.</div>';
    return;
}
if (!dmd_games_require_permissions(array('module.view'))) {
    return;
}

$moduleBaseUrl = dmd_games_module_base_url();
$themeUrl = dmd_games_user_theme_url($email, $moduleBaseUrl);
$games = dmd_games_scan();
$canPlay = dmd_games_has_permission('games.play');
$canSave = dmd_games_has_permission('games.save');
$uid = 'dmdGamesMyDesk_' . substr(hash('sha256', __DIR__ . microtime(true)), 0, 10);
$cssVersion = is_file(__DIR__ . '/DMD-Games-mydesk.css') ? (string)@filemtime(__DIR__ . '/DMD-Games-mydesk.css') : DMD_GAMES_VERSION;
$fullUrl = rtrim($moduleBaseUrl, '/') . '/DMD-Games.php?dmd_games_mydesk_full=1';
?>
<link rel="stylesheet" href="<?= dmd_games_h($themeUrl) ?>">
<link rel="stylesheet" href="<?= dmd_games_h(rtrim($moduleBaseUrl, '/') . '/DMD-Games-mydesk.css?v=' . rawurlencode($cssVersion)) ?>">

<script>
(() => {
    function sourceWindow(){
        const candidates=[];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}
        for (const candidate of candidates) {
            try { if (candidate.document && candidate.location.origin === window.location.origin) return candidate; } catch (_) {}
        }
        return null;
    }
    function syncTheme(){
        const source=sourceWindow();
        if (!source) return;
        const names=[
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color','--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg','--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];
        const targets=[document.documentElement,document.body].filter(Boolean);
        [source.document.documentElement,source.document.body].filter(Boolean).forEach(sourceRoot=>{
            const cs=source.getComputedStyle(sourceRoot);
            names.forEach(name=>{
                const value=cs.getPropertyValue(name);
                if(value && value.trim()) targets.forEach(target=>target.style.setProperty(name,value.trim()));
            });
        });
        try {
            const bodyStyle=source.getComputedStyle(source.document.body);
            targets.forEach(target=>{ target.style.fontFamily=bodyStyle.fontFamily||''; });
        } catch (_) {}
        document.documentElement.classList.add('dmd-games-mydesk-host');
        if(document.body) document.body.classList.add('dmd-games-mydesk-host');
    }
    syncTheme();
    window.addEventListener('load',syncTheme,{once:true});
})();
</script>

<section
    class="dmd-games-mydesk"
    id="<?= dmd_games_h($uid) ?>"
    data-full-url="<?= dmd_games_h($fullUrl) ?>"
    data-can-play="<?= $canPlay ? '1' : '0' ?>"
    data-can-save="<?= $canSave ? '1' : '0' ?>"
    data-dmd-module-id="DMD-Games"
    data-dmd-context-type="game_library"
    data-dmd-context-id="DMD-Games:library"
    data-dmd-context-name="DMD-Games"
>
    <header class="dgm-head">
        <div class="dgm-title">
            <img src="<?= dmd_games_h(rtrim($moduleBaseUrl, '/') . '/icon.png') ?>" alt="" class="dgm-icon">
            <div><strong>DMD-Games</strong><small><?= count($games) ?> jeux · ludothèque rapide</small></div>
        </div>
        <div class="dgm-actions">
            <span class="dgm-count" data-count><?= count($games) ?></span>
            <button type="button" class="dgm-iconbtn" data-action="refresh" title="Actualiser" aria-label="Actualiser">↻</button>
            <button type="button" class="dgm-iconbtn" data-action="full" title="Ouvrir DMD-Games complet dans DoMyDesk / PWA" aria-label="Ouvrir DMD-Games complet">↗</button>
        </div>
    </header>

    <div class="dgm-searchrow">
        <label class="dgm-search"><span aria-hidden="true">⌕</span><input type="search" data-search autocomplete="off" placeholder="Rechercher un jeu…"></label>
    </div>

    <?php if (!$canPlay): ?>
        <div class="dgm-rights">🔒 Le droit <strong>Jouer</strong> n’est pas accordé à ce compte.</div>
    <?php elseif (!$canSave): ?>
        <div class="dgm-rights is-info">ℹ️ Les jeux sont autorisés, mais les records/progressions ne seront pas enregistrés.</div>
    <?php endif; ?>

    <section class="dgm-library" data-library>
        <div class="dgm-grid" data-grid>
            <?php foreach ($games as $game):
                $searchText = $game['name'] . ' ' . $game['description'] . ' ' . $game['category'];
                $searchText = function_exists('mb_strtolower') ? mb_strtolower($searchText, 'UTF-8') : strtolower($searchText);
                $gameUrl = dmd_games_game_url($game, $moduleBaseUrl);
            ?>
                <button
                    type="button"
                    class="dgm-card<?= !$canPlay ? ' is-disabled' : '' ?>"
                    data-game-card
                    data-search-text="<?= dmd_games_h($searchText) ?>"
                    data-game-url="<?= dmd_games_h($gameUrl) ?>"
                    data-game-title="<?= dmd_games_h($game['name']) ?>"
                    <?= !$canPlay ? 'disabled aria-disabled="true"' : '' ?>
                >
                    <span class="dgm-game-icon" aria-hidden="true"><?= dmd_games_h($game['emoji']) ?></span>
                    <span class="dgm-game-copy"><strong><?= dmd_games_h($game['name']) ?></strong><small><?= dmd_games_h($game['description']) ?></small></span>
                    <span class="dgm-play"><?= $canPlay ? 'Jouer ›' : '🔒' ?></span>
                </button>
            <?php endforeach; ?>
        </div>
        <?php if (!$games): ?><div class="dgm-empty">Aucun jeu installé.</div><?php endif; ?>
    </section>

    <section class="dgm-player" data-player hidden>
        <div class="dgm-playerbar">
            <button type="button" data-action="back">‹ Jeux</button>
            <strong data-player-title>Jeu</strong>
            <button type="button" data-action="reload" title="Recharger" aria-label="Recharger le jeu">↻</button>
        </div>
        <iframe data-frame class="dgm-frame" title="Jeu DMD-Games" src="about:blank" sandbox="allow-scripts allow-same-origin allow-forms allow-modals allow-downloads"></iframe>
    </section>
</section>

<script>
(() => {
    'use strict';
    const root=document.getElementById(<?= json_encode($uid, JSON_UNESCAPED_SLASHES) ?>);
    if(!root || root.dataset.ready==='1') return;
    root.dataset.ready='1';

    const fullUrl=root.dataset.fullUrl;
    const canPlay=root.dataset.canPlay==='1';
    const library=root.querySelector('[data-library]');
    const player=root.querySelector('[data-player]');
    const frame=root.querySelector('[data-frame]');
    const playerTitle=root.querySelector('[data-player-title]');
    const search=root.querySelector('[data-search]');
    const count=root.querySelector('[data-count]');

    function requestSize(mode){
        const isPlayer=mode==='player';
        const width=isPlayer?620:390;
        const height=isPlayer?620:560;
        try { window.resizeTo(width,height); } catch (_) {}
        const detail={type:'dmd:mydesk-resize',module:'DMD-Games',mode:isPlayer?'player':'compact',width,height};
        try { if(window.opener && !window.opener.closed) window.opener.postMessage(detail,window.location.origin); } catch(_){ }
        try { if(window.parent && window.parent!==window) window.parent.postMessage(detail,window.location.origin); } catch(_){ }
        try { window.dispatchEvent(new CustomEvent('dmd:mydesk-resize',{detail})); } catch(_){ }
    }

    function visibleCount(){
        return Array.from(root.querySelectorAll('[data-game-card]')).filter(card=>!card.hidden).length;
    }
    function updateCount(){ if(count) count.textContent=String(visibleCount()); }

    function showLibrary(){
        frame.src='about:blank';
        player.hidden=true;
        player.style.display='none';
        library.hidden=false;
        library.style.display='block';
        requestSize('compact');
    }
    function openGame(card){
        if(!canPlay || !card || card.disabled) return;
        const url=card.dataset.gameUrl||'';
        if(!url) return;
        playerTitle.textContent=card.dataset.gameTitle||'Jeu';
        frame.src=url;
        library.hidden=true;
        library.style.display='none';
        player.hidden=false;
        player.style.display='grid';
        requestSize('player');
    }
    function openFull(){
        const detail={type:'dmd:mydesk-open-full',module:'DMD-Games',url:fullUrl,target:'domydesk-pwa'};
        try { if(window.opener && !window.opener.closed) window.opener.postMessage(detail,window.location.origin); } catch(_){ }
        try { if(window.parent && window.parent!==window) window.parent.postMessage(detail,window.location.origin); } catch(_){ }
        try { window.dispatchEvent(new CustomEvent('dmd:mydesk-open-full',{detail})); } catch(_){ }
        try {
            const opened=window.open(fullUrl,'_blank');
            if(opened){ try{opened.focus();}catch(_){ } return; }
        } catch(_){ }
        window.location.assign(fullUrl);
    }

    root.addEventListener('click',event=>{
        const card=event.target.closest('[data-game-card]');
        if(card && root.contains(card)){event.preventDefault();openGame(card);return;}
        const action=event.target.closest('[data-action]')?.dataset.action;
        if(!action) return;
        event.preventDefault();
        if(action==='back') showLibrary();
        if(action==='reload') { try{frame.contentWindow.location.reload();}catch(_){frame.src=frame.src;} }
        if(action==='refresh') window.location.reload();
        if(action==='full') openFull();
    });

    if(search) search.addEventListener('input',()=>{
        const q=search.value.trim().toLocaleLowerCase('fr');
        root.querySelectorAll('[data-game-card]').forEach(card=>{ card.hidden=q!=='' && !(card.dataset.searchText||'').includes(q); });
        updateCount();
    });

    updateCount();
    requestSize('compact');
})();
</script>
