<?php
require_once __DIR__ . '/dmd-mail-lib.php';

if (!function_exists('dmd_mail_actionhub_account_options')) {
    function dmd_mail_actionhub_account_options(string $email): array {
        $out = array();
        foreach (dmd_mail_accounts($email) as $account) {
            if (!is_array($account) || empty($account['id']) || (array_key_exists('enabled', $account) && $account['enabled'] === false)) continue;
            $label = trim((string)($account['name'] ?? ''));
            $address = trim((string)($account['email'] ?? ''));
            if ($label === '') $label = $address !== '' ? $address : (string)$account['id'];
            if ($address !== '' && strcasecmp($label, $address) !== 0) $label .= ' · ' . $address;
            $out[] = array('value'=>(string)$account['id'], 'label'=>$label);
        }
        return $out;
    }
}

if (!function_exists('dmd_mail_actionhub_action')) {
    function dmd_mail_actionhub_action(
        string $id,
        string $label,
        string $group,
        $permissions,
        array $inputs = array(),
        bool $dangerous = false,
        string $confirm = '',
        string $description = '',
        string $icon = '✉',
        string $scope = 'module',
        array $resourceTypes = array(),
        array $meta = array()
    ): array {
        $permissions = is_array($permissions) ? array_values($permissions) : array((string)$permissions);
        return array(
            'id'=>$id,
            'label'=>$label,
            'description'=>$description,
            'icon'=>$icon,
            'group'=>$group,
            'permissions'=>$permissions,
            'permission'=>(string)($permissions[0] ?? 'module.view'),
            'scope'=>$scope,
            'scenario'=>$scope === 'module',
            'resource_types'=>$resourceTypes,
            'inputs'=>$inputs,
            'dangerous'=>$dangerous,
            'confirm'=>$confirm,
            'meta'=>$meta,
        );
    }
}

if (!function_exists('dmd_mail_actionhub_resource_account_id')) {
    function dmd_mail_actionhub_resource_account_id(array $resource): string {
        $id = trim((string)($resource['id'] ?? ''));
        if ($id === '') return '';
        foreach (array('DMD-Mail:mailbox:', 'dmd-mail:mailbox:', 'mailbox:') as $prefix) {
            if (stripos($id, $prefix) === 0) return substr($id, strlen($prefix));
        }
        return $id;
    }
}

if (!function_exists('dmd_mail_actionhub_catalog')) {
    function dmd_mail_actionhub_catalog(array $context): array {
        $email = trim((string)($context['email'] ?? ''));
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return array('replace'=>true,'actions'=>array());
        $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;
        $options = dmd_mail_actionhub_account_options($email);
        if (!$options) return array('replace'=>true,'actions'=>array());

        if ($resource && strtolower((string)($resource['type'] ?? '')) === 'mailbox') {
            $accountId = dmd_mail_actionhub_resource_account_id($resource);
            if (!dmd_mail_account($accountId, $email)) return array('replace'=>true,'actions'=>array());
            $actions = array();
            if (dmd_mail_has_permission('mail.read', $email)) {
                $actions[] = dmd_mail_actionhub_action('mailbox.open-inbox','Ouvrir la boîte de réception','Lecture','mail.read',array(),false,'','Ouvre cette messagerie dans DMD-Mail.','📥','resource',array('mailbox'),array('ui_action'=>'open-inbox','fixed_account_id'=>$accountId));
                $actions[] = dmd_mail_actionhub_action('mailbox.open-unread','Ouvrir les non lus','Lecture','mail.read',array(),false,'','Ouvre les messages non lus de cette messagerie.','●','resource',array('mailbox'),array('ui_action'=>'open-unread','fixed_account_id'=>$accountId));
            }
            if (dmd_mail_has_permission('mail.send', $email)) {
                $actions[] = dmd_mail_actionhub_action('mailbox.compose','Nouveau mail','Rédaction','mail.send',array(),false,'','Ouvre un nouveau message depuis cette messagerie.','✉','resource',array('mailbox'),array('ui_action'=>'compose','fixed_account_id'=>$accountId));
            }
            if (dmd_mail_has_any_permission(array('accounts.test','config.edit'), $email)) {
                $testPermission = dmd_mail_has_permission('accounts.test', $email) ? 'accounts.test' : 'config.edit';
                $actions[] = dmd_mail_actionhub_action('mailbox.test','Tester la messagerie','Compte',$testPermission,array(),false,'','Teste la connexion de cette messagerie.','✓','resource',array('mailbox'),array('server_action'=>'test','fixed_account_id'=>$accountId));
            }
            return array('replace'=>true,'actions'=>$actions);
        }

        $accountInput = array('id'=>'account','label'=>'Messagerie','type'=>'select','required'=>true,'options'=>$options);
        $actions = array();
        if (dmd_mail_has_permission('mail.read', $email)) {
            $actions[] = dmd_mail_actionhub_action('scenario.mail.open-inbox','Ouvrir la boîte de réception','Lecture','mail.read',array($accountInput),false,'','Ouvre DMD-Mail sur la boîte choisie.','📥');
            $actions[] = dmd_mail_actionhub_action('scenario.mail.open-unread','Ouvrir les messages non lus','Lecture','mail.read',array($accountInput),false,'','Ouvre DMD-Mail et filtre les messages non lus.','●');
        }
        if (dmd_mail_has_permission('mail.search', $email)) {
            $actions[] = dmd_mail_actionhub_action('scenario.mail.search','Rechercher des mails','Lecture','mail.search',array(
                $accountInput,
                array('id'=>'query','label'=>'Recherche','type'=>'text','required'=>true,'placeholder'=>'Expéditeur, objet, mot-clé…')
            ),false,'','Ouvre DMD-Mail avec une recherche préremplie.','⌕');
        }
        if (dmd_mail_has_permission('mail.send', $email)) {
            $actions[] = dmd_mail_actionhub_action('scenario.mail.compose','Préparer un nouveau mail','Rédaction','mail.send',array(
                $accountInput,
                array('id'=>'to','label'=>'À','type'=>'text','required'=>false,'placeholder'=>'destinataire@domaine.tld'),
                array('id'=>'cc','label'=>'Cc','type'=>'text','required'=>false),
                array('id'=>'bcc','label'=>'Cci','type'=>'text','required'=>false),
                array('id'=>'subject','label'=>'Objet','type'=>'text','required'=>false),
                array('id'=>'body','label'=>'Message','type'=>'textarea','required'=>false)
            ),false,'','Ouvre la fenêtre de rédaction sans envoyer automatiquement.','✉');
            $actions[] = dmd_mail_actionhub_action('scenario.mail.send','Envoyer un mail','Rédaction','mail.send',array(
                $accountInput,
                array('id'=>'to','label'=>'À','type'=>'text','required'=>true,'placeholder'=>'destinataire@domaine.tld'),
                array('id'=>'cc','label'=>'Cc','type'=>'text','required'=>false),
                array('id'=>'bcc','label'=>'Cci','type'=>'text','required'=>false),
                array('id'=>'subject','label'=>'Objet','type'=>'text','required'=>false),
                array('id'=>'body','label'=>'Message','type'=>'textarea','required'=>true)
            ),true,'Envoyer ce message maintenant ?','Envoie directement le message depuis la messagerie choisie.','➤');
        }
        if (dmd_mail_has_any_permission(array('accounts.test','config.edit'), $email)) {
            $testPermission = dmd_mail_has_permission('accounts.test', $email) ? 'accounts.test' : 'config.edit';
            $actions[] = dmd_mail_actionhub_action('scenario.mail.test-account','Tester une messagerie','Compte',$testPermission,array($accountInput),false,'','Teste la connexion du compte sélectionné.','✓');
        }
        if (dmd_mail_has_any_permission(array('mail.mark','mail.modify'), $email)) {
            $markPermission = dmd_mail_has_permission('mail.mark', $email) ? 'mail.mark' : 'mail.modify';
            $common = array($accountInput,array('id'=>'folder','label'=>'Dossier','type'=>'text','required'=>true,'default'=>'INBOX'),array('id'=>'message_id','label'=>'ID du message','type'=>'text','required'=>true));
            $actions[] = dmd_mail_actionhub_action('scenario.mail.mark-read','Marquer un message comme lu','Message',$markPermission,$common,false,'','Marque un message précis comme lu.','✓');
            $actions[] = dmd_mail_actionhub_action('scenario.mail.mark-unread','Marquer un message comme non lu','Message',$markPermission,$common,false,'','Marque un message précis comme non lu.','●');
        }
        if (dmd_mail_has_any_permission(array('mail.delete','mail.modify'), $email)) {
            $deletePermission = dmd_mail_has_permission('mail.delete', $email) ? 'mail.delete' : 'mail.modify';
            $actions[] = dmd_mail_actionhub_action('scenario.mail.delete','Supprimer un message','Message',$deletePermission,array(
                $accountInput,
                array('id'=>'folder','label'=>'Dossier','type'=>'text','required'=>true,'default'=>'INBOX'),
                array('id'=>'message_id','label'=>'ID du message','type'=>'text','required'=>true)
            ),true,'Supprimer définitivement ce message ?','Supprime le message ciblé via son identifiant.','⌫');
        }
        return array('replace'=>true,'actions'=>$actions);
    }
}

if (!function_exists('dmd_mail_actionhub_handle')) {
    function dmd_mail_actionhub_handle($context) {
        $context = is_array($context) ? $context : array();
        $email = trim((string)($context['email'] ?? ''));
        $action = is_array($context['action'] ?? null) ? $context['action'] : array();
        $payload = is_array($context['payload'] ?? null) ? $context['payload'] : array();
        $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;
        $meta = is_array($action['meta'] ?? null) ? $action['meta'] : array();
        $id = trim((string)($action['id'] ?? ''));
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return array('ok'=>false,'error'=>'invalid_user','message'=>'Utilisateur DMD-Mail invalide.');

        $required = isset($action['permissions']) && is_array($action['permissions']) ? $action['permissions'] : array((string)($action['permission'] ?? 'module.view'));
        if (!dmd_mail_has_any_permission($required, $email)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit DMD-Mail insuffisant.');

        $fixed = trim((string)($meta['fixed_account_id'] ?? ''));
        if ($fixed === '' && $resource && strtolower((string)($resource['type'] ?? '')) === 'mailbox') $fixed = dmd_mail_actionhub_resource_account_id($resource);
        $accountId = $fixed !== '' ? $fixed : trim((string)($payload['account'] ?? ''));
        $account = $accountId !== '' ? dmd_mail_account($accountId, $email) : null;
        if ($accountId !== '' && (!$account || (array_key_exists('enabled',$account) && $account['enabled'] === false))) return array('ok'=>false,'error'=>'account_not_found','message'=>'Messagerie DMD-Mail introuvable ou désactivée.');

        $uiMap = array(
            'scenario.mail.open-inbox'=>'open-inbox', 'mailbox.open-inbox'=>'open-inbox',
            'scenario.mail.open-unread'=>'open-unread', 'mailbox.open-unread'=>'open-unread',
            'scenario.mail.search'=>'search',
            'scenario.mail.compose'=>'compose', 'mailbox.compose'=>'compose'
        );
        if (isset($uiMap[$id])) {
            return array('ok'=>true,'message'=>'DMD-Mail prêt.','data'=>array('module'=>'DMD-Mail','ui'=>array(
                'type'=>'dmd-mail.' . $uiMap[$id],
                'account_id'=>$accountId,
                'query'=>(string)($payload['query'] ?? ''),
                'to'=>(string)($payload['to'] ?? ''),
                'cc'=>(string)($payload['cc'] ?? ''),
                'bcc'=>(string)($payload['bcc'] ?? ''),
                'subject'=>(string)($payload['subject'] ?? ''),
                'body'=>(string)($payload['body'] ?? '')
            )),'event_emitted'=>true);
        }

        if (!$account) return array('ok'=>false,'error'=>'account_required','message'=>'Sélectionnez une messagerie.');

        try {
            if ($id === 'scenario.mail.send') {
                dmd_mail_send($account,(string)($payload['to']??''),(string)($payload['cc']??''),(string)($payload['bcc']??''),(string)($payload['subject']??''),(string)($payload['body']??''),array());
                return array('ok'=>true,'message'=>'Message envoyé.','data'=>array('account_id'=>$accountId),'event_emitted'=>true);
            }
            if ($id === 'scenario.mail.test-account' || $id === 'mailbox.test') {
                $folders = dmd_mail_provider_folders($account);
                return array('ok'=>true,'message'=>'Connexion réussie : '.count($folders).' dossier(s) détecté(s).','data'=>array('account_id'=>$accountId,'folders_count'=>count($folders)),'event_emitted'=>true);
            }
            $folder = trim((string)($payload['folder'] ?? 'INBOX')); if ($folder === '') $folder = 'INBOX';
            $messageId = trim((string)($payload['message_id'] ?? ''));
            if ($id === 'scenario.mail.mark-read' || $id === 'scenario.mail.mark-unread') {
                if ($messageId === '') return array('ok'=>false,'error'=>'message_required','message'=>'ID du message requis.');
                dmd_mail_provider_mark_read($account,$folder,$messageId,$id === 'scenario.mail.mark-read');
                return array('ok'=>true,'message'=>$id === 'scenario.mail.mark-read'?'Message marqué comme lu.':'Message marqué comme non lu.','data'=>array('account_id'=>$accountId,'message_id'=>$messageId,'reload'=>true),'event_emitted'=>true);
            }
            if ($id === 'scenario.mail.delete') {
                if ($messageId === '') return array('ok'=>false,'error'=>'message_required','message'=>'ID du message requis.');
                dmd_mail_provider_delete($account,$folder,$messageId);
                return array('ok'=>true,'message'=>'Message supprimé.','data'=>array('account_id'=>$accountId,'message_id'=>$messageId,'reload'=>true),'event_emitted'=>true);
            }
        } catch (Throwable $e) {
            return array('ok'=>false,'error'=>'mail_action_failed','message'=>$e->getMessage());
        }
        return array('ok'=>false,'error'=>'unknown_action','message'=>'Action ActionHub DMD-Mail inconnue.');
    }
}
