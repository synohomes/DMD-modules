<?php
// L'API doit toujours renvoyer du JSON propre, même si PHP émet un warning.
@ini_set('display_errors', '0');
@ini_set('html_errors', '0');
if (ob_get_level() === 0) { ob_start(); }
require_once __DIR__ . '/dmd-mail-lib.php';
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, no-cache, must-revalidate');

function dmd_mail_api_utf8($value) {
    if (is_array($value)) {
        $out = array();
        foreach ($value as $k => $v) $out[$k] = dmd_mail_api_utf8($v);
        return $out;
    }
    if (!is_string($value) || $value === '') return $value;
    if (@preg_match('//u', $value) === 1) return $value;
    if (function_exists('mb_detect_encoding') && function_exists('mb_convert_encoding')) {
        $enc = @mb_detect_encoding($value, array('UTF-8','Windows-1252','ISO-8859-1'), true);
        if ($enc) {
            $x = @mb_convert_encoding($value, 'UTF-8', $enc);
            if (is_string($x)) return $x;
        }
    }
    if (function_exists('iconv')) {
        $x = @iconv('Windows-1252', 'UTF-8//IGNORE', $value);
        if (is_string($x)) return $x;
    }
    return preg_replace('/[\x80-\xFF]/', '?', $value) ?? '';
}
function dmd_mail_api_reply(bool $ok, string $message = '', array $extra = array(), int $status = 200): void {
    // Supprime toute sortie parasite (warning/notice) avant la réponse JSON.
    while (ob_get_level() > 0) { @ob_end_clean(); }
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    $payload = dmd_mail_api_utf8(array_merge(array('ok'=>$ok,'message'=>$message),$extra));
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    if (defined('JSON_PARTIAL_OUTPUT_ON_ERROR')) $flags |= JSON_PARTIAL_OUTPUT_ON_ERROR;
    $json = json_encode($payload, $flags);
    if (!is_string($json) || $json === '') {
        $json = '{"ok":false,"message":"Erreur d’encodage de la réponse DMD-Mail."}';
        if ($status < 400) http_response_code(500);
    }
    echo $json;
    exit;
}
function dmd_mail_api_input(): array {
    $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
    if (strpos($ct,'application/json') !== false) {
        $raw = file_get_contents('php://input'); $j = json_decode((string)$raw,true); return is_array($j)?$j:array();
    }
    return $_POST;
}
function dmd_mail_api_account(string $id): array {
    $a = dmd_mail_account($id); if(!$a || empty($a['enabled'])) throw new RuntimeException('Compte mail introuvable ou désactivé.'); return $a;
}
function dmd_mail_api_write_guard(array $in): void {
    $token=(string)($in['csrf'] ?? ($_SERVER['HTTP_X_DMD_CSRF'] ?? ''));
    if(!dmd_mail_check_csrf($token)) dmd_mail_api_reply(false,'Jeton de sécurité invalide.',array(),403);
}
function dmd_mail_api_require_permission($permissions): void {
    $permissions = is_array($permissions) ? $permissions : array((string)$permissions);
    if (!dmd_mail_has_any_permission($permissions)) {
        dmd_mail_api_reply(false, 'Accès refusé : droit DMD-Mail insuffisant.', array('required_permissions'=>$permissions), 403);
    }
}

try {
    dmd_mail_require_user();
    $action = trim((string)($_GET['action'] ?? $_POST['action'] ?? 'bootstrap'));
    $in = dmd_mail_api_input();

    /*
     * PHP verrouille le fichier de session tant que session_start() reste ouvert.
     * Une lecture IMAP un peu lente bloquait donc TOUTES les autres requêtes DoMyDesk
     * du même utilisateur. DMD-Mail ne garde le verrou que pour les deux opérations
     * Microsoft qui écrivent volontairement un état temporaire dans la session.
     */
    dmd_mail_csrf(); // garantit que le jeton existe avant de libérer la session
    if (!in_array($action, array('microsoft_device_start','microsoft_device_poll'), true)
        && session_status() === PHP_SESSION_ACTIVE) {
        @session_write_close();
    }

    if ($action === 'bootstrap') {
        dmd_mail_api_require_permission('module.view');
        $accounts=array_map('dmd_mail_public_account', dmd_mail_accounts());
        $ms=dmd_mail_microsoft_config();
        dmd_mail_api_reply(true,'',array('csrf'=>dmd_mail_csrf(),'accounts'=>$accounts,'oauth_redirect_uri'=>dmd_mail_oauth_redirect_uri(),'microsoft'=>array('configured'=>!empty($ms['configured'])),'features'=>array('imap'=>function_exists('stream_socket_client'),'curl'=>function_exists('curl_init'),'openssl'=>function_exists('openssl_encrypt')),'permissions'=>dmd_mail_permissions_snapshot()));
    }
    if ($action === 'accounts') {
        dmd_mail_api_require_permission(array('config.view','config.edit'));
        dmd_mail_api_reply(true,'',array('accounts'=>array_map('dmd_mail_public_account',dmd_mail_accounts())));
    }
    if ($action === 'microsoft_config') {
        dmd_mail_api_require_permission(array('config.view','accounts.connect','config.edit'));
        $ms=dmd_mail_microsoft_config();
        dmd_mail_api_reply(true,'',array('configured'=>!empty($ms['configured']),'client_id'=>(string)($ms['client_id']??'')));
    }
    if ($action === 'save_microsoft_config') {
        dmd_mail_api_require_permission(array('accounts.connect','config.edit'));
        dmd_mail_api_write_guard($in);$ms=dmd_mail_save_microsoft_config((string)($in['client_id']??''));
        dmd_mail_api_reply(true,'Configuration Microsoft enregistrée.',array('configured'=>true,'client_id'=>$ms['client_id']));
    }
    if ($action === 'save_account') {
        $incomingId = trim((string)($in['id'] ?? ''));
        $exists = $incomingId !== '' && dmd_mail_account($incomingId) !== null;
        dmd_mail_api_require_permission($exists ? array('accounts.edit','config.edit') : array('accounts.create','config.edit'));
        dmd_mail_api_write_guard($in); $saved=dmd_mail_save_account_input($in); dmd_mail_api_reply(true,'Compte enregistré.',array('account'=>$saved));
    }
    if ($action === 'save_test_account') {
        $incomingId = trim((string)($in['id'] ?? ''));
        $exists = $incomingId !== '' && dmd_mail_account($incomingId) !== null;
        dmd_mail_api_require_permission($exists ? array('accounts.edit','accounts.test','config.edit') : array('accounts.create','accounts.test','config.edit'));
        dmd_mail_api_write_guard($in); $r=dmd_mail_save_test_account_input($in);
        dmd_mail_api_reply(true, !empty($r['needs_oauth']) ? 'Compte enregistré. Connexion OAuth requise.' : 'Connexion réussie.', $r);
    }
    if ($action === 'delete_account') {
        dmd_mail_api_require_permission(array('accounts.delete','config.edit'));
        dmd_mail_api_write_guard($in); $id=trim((string)($in['id']??''));$accounts=dmd_mail_accounts();$next=array_values(array_filter($accounts,fn($a)=>!is_array($a)||!hash_equals((string)($a['id']??''),$id)));if(count($next)===count($accounts))throw new RuntimeException('Compte introuvable.');dmd_mail_backup_accounts_snapshot($accounts);dmd_mail_save_accounts($next);$tokens=dmd_mail_json_read(dmd_mail_tokens_file(),array());unset($tokens[$id]);dmd_mail_json_write(dmd_mail_tokens_file(),$tokens);dmd_mail_api_reply(true,'Compte supprimé.');
    }
    if ($action === 'microsoft_device_start') {
        dmd_mail_api_require_permission(array('accounts.connect','config.edit'));
        dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));if(($a['provider']??'')!=='microsoft')throw new RuntimeException('Compte Microsoft requis.');$r=dmd_mail_ms_device_start($a);dmd_mail_api_reply(true,'Connexion Microsoft démarrée.',$r);
    }
    if ($action === 'microsoft_device_poll') {
        dmd_mail_api_require_permission(array('accounts.connect','config.edit'));
        dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));if(($a['provider']??'')!=='microsoft')throw new RuntimeException('Compte Microsoft requis.');$r=dmd_mail_ms_device_poll($a);dmd_mail_api_reply(true,$r['connected']?'Microsoft connecté.':'Validation en attente.',$r);
    }

    if ($action === 'contacts') {
        dmd_mail_api_require_permission(array('mail.send','mail.read'));
        $q=trim((string)($_GET['q']??$in['q']??''));
        $rows=dmd_mail_contacts();
        if($q!==''){
            $needle=function_exists('mb_strtolower')?mb_strtolower($q,'UTF-8'):strtolower($q);
            $rows=array_values(array_filter($rows,static function($c) use($needle){
                $hay=(string)($c['name']??'').' '.(string)($c['company']??'').' '.implode(' ',(array)($c['emails']??array())).' '.(string)($c['phone']??'').' '.(string)($c['tags']??'');
                $hay=function_exists('mb_strtolower')?mb_strtolower($hay,'UTF-8'):strtolower($hay);
                return strpos($hay,$needle)!==false;
            }));
        }
        $total=count($rows);
        dmd_mail_api_reply(true,'',array('contacts'=>array_slice($rows,0,80),'contacts_total'=>$total,'dmd_contact_available'=>dmd_mail_contact_module_available()));
    }
    if ($action === 'contact_create') {
        dmd_mail_api_require_permission(array('mail.send','mail.read'));
        dmd_mail_api_write_guard($in);
        $contact=dmd_mail_contact_create(array(
            'email'=>(string)($in['email']??''),
            'name'=>(string)($in['name']??''),
            'company'=>(string)($in['company']??'')
        ));
        dmd_mail_api_reply(true,'Contact ajouté à DMD-Contact.',array('contact'=>$contact));
    }
    if ($action === 'folders') {
        dmd_mail_api_require_permission('mail.read');
        $a=dmd_mail_api_account(trim((string)($_GET['account']??$in['account']??'')));$folders=dmd_mail_provider_folders($a);dmd_mail_api_reply(true,'',array('folders'=>$folders));
    }
    if ($action === 'messages') {
        $query = trim((string)($_GET['q'] ?? $in['q'] ?? ''));
        dmd_mail_api_require_permission($query !== '' ? 'mail.search' : 'mail.read');
        $a=dmd_mail_api_account(trim((string)($_GET['account']??$in['account']??'')));$folder=(string)($_GET['folder']??$in['folder']??'');$q=trim((string)($_GET['q']??$in['q']??''));$limit=(int)($_GET['limit']??$in['limit']??40);$messages=dmd_mail_provider_list($a,$folder,$q,$limit);dmd_mail_api_reply(true,'',array('messages'=>$messages));
    }
    if ($action === 'message') {
        dmd_mail_api_require_permission('mail.read');
        $a=dmd_mail_api_account(trim((string)($_GET['account']??'')));$folder=(string)($_GET['folder']??'');$id=(string)($_GET['id']??'');$msg=dmd_mail_provider_message($a,$folder,$id);dmd_mail_api_reply(true,'',array('message'=>$msg));
    }
    if ($action === 'mark_read') {
        dmd_mail_api_require_permission(array('mail.mark','mail.modify'));
        dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));dmd_mail_provider_mark_read($a,(string)($in['folder']??''),(string)($in['id']??''),!empty($in['read']));dmd_mail_api_reply(true,'État du message modifié.');
    }
    if ($action === 'delete_message') {
        dmd_mail_api_require_permission(array('mail.delete','mail.modify'));
        dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));dmd_mail_provider_delete($a,(string)($in['folder']??''),(string)($in['id']??''));dmd_mail_api_reply(true,'Message supprimé.');
    }
    if ($action === 'signature') {
        dmd_mail_api_require_permission(array('mail.send','config.view'));
        $id=trim((string)($_GET['account']??$in['account']??''));
        dmd_mail_api_reply(true,'',array('signature'=>dmd_mail_signature($id)));
    }
    if ($action === 'save_signature') {
        dmd_mail_api_require_permission(array('mail.signature','config.edit','mail.send'));
        dmd_mail_api_write_guard($in);$id=trim((string)($in['account']??''));$sig=dmd_mail_save_signature($id,(string)($in['html']??''),!array_key_exists('enabled',$in)||!empty($in['enabled']));
        dmd_mail_api_reply(true,'Signature enregistrée.',array('signature'=>$sig));
    }
    if ($action === 'create_folder') {
        dmd_mail_api_require_permission(array('mail.folders','mail.modify'));dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));$r=dmd_mail_provider_create_folder($a,trim((string)($in['name']??'')),(string)($in['parent']??''));dmd_mail_api_reply(true,'Dossier créé.',array('folder'=>$r));
    }
    if ($action === 'rename_folder') {
        dmd_mail_api_require_permission(array('mail.folders','mail.modify'));dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));dmd_mail_provider_rename_folder($a,(string)($in['folder']??''),trim((string)($in['name']??'')));dmd_mail_api_reply(true,'Dossier renommé.');
    }
    if ($action === 'delete_folder') {
        dmd_mail_api_require_permission(array('mail.folders','mail.modify'));dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));dmd_mail_provider_delete_folder($a,(string)($in['folder']??''));dmd_mail_api_reply(true,'Dossier supprimé.');
    }
    if ($action === 'bulk_action') {
        dmd_mail_api_write_guard($in);$op=(string)($in['op']??'');$items=$in['items']??array();if(is_string($items)){$x=json_decode($items,true);$items=is_array($x)?$x:array();}if(!is_array($items)||!$items)throw new RuntimeException('Aucun message sélectionné.');
        if(in_array($op,array('read','unread'),true))dmd_mail_api_require_permission(array('mail.mark','mail.modify'));
        elseif($op==='delete')dmd_mail_api_require_permission(array('mail.delete','mail.modify'));
        elseif($op==='move')dmd_mail_api_require_permission(array('mail.move','mail.modify'));else throw new RuntimeException('Action groupée invalide.');
        // Regroupe par compte + dossier : une seule session IMAP / requête bulk par groupe.
        // L'ancienne boucle ouvrait jusqu'à une connexion réseau par message et pouvait saturer le NAS.
        $groups=array();
        foreach($items as $item){
            if(!is_array($item))continue;
            $aid=trim((string)($item['account']??''));$f=(string)($item['folder']??'');$id=(string)($item['id']??'');
            if($aid===''||$id==='')continue;
            $k=$aid."\n".$f;
            if(!isset($groups[$k]))$groups[$k]=array('account'=>$aid,'folder'=>$f,'ids'=>array());
            $groups[$k]['ids'][]=$id;
        }
        $done=0;$target=(string)($in['target']??'');
        foreach($groups as $g){$a=dmd_mail_api_account($g['account']);$done+=dmd_mail_provider_bulk($a,$g['folder'],$g['ids'],$op,$target);}
        dmd_mail_api_reply(true,$done.' message'.($done>1?'s':'').' traité'.($done>1?'s':'').'.',array('count'=>$done));
    }
    if ($action === 'send') {
        dmd_mail_api_require_permission('mail.send');
        dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));$files=array();foreach((array)($_FILES['attachments']['name']??array()) as$i=>$name){$err=(int)($_FILES['attachments']['error'][$i]??UPLOAD_ERR_NO_FILE);if($err!==UPLOAD_ERR_OK)continue;$tmp=(string)($_FILES['attachments']['tmp_name'][$i]??'');$size=(int)($_FILES['attachments']['size'][$i]??0);if($size>15*1024*1024)throw new RuntimeException('Une pièce jointe dépasse 15 Mo.');$data=@file_get_contents($tmp);if($data===false)continue;$files[]=array('name'=>basename((string)$name),'type'=>(string)($_FILES['attachments']['type'][$i]??'application/octet-stream'),'data'=>$data);}
        dmd_mail_send($a,(string)($in['to']??''),(string)($in['cc']??''),(string)($in['bcc']??''),(string)($in['subject']??''),(string)($in['body']??''),$files);dmd_mail_api_reply(true,'Message envoyé.');
    }
    if ($action === 'test_account') {
        dmd_mail_api_require_permission(array('accounts.test','config.edit'));
        dmd_mail_api_write_guard($in);$a=dmd_mail_api_account(trim((string)($in['account']??'')));$p=(string)($a['provider']??'imap');if(($p==='google'||$p==='microsoft')&&!dmd_mail_token((string)$a['id']))dmd_mail_api_reply(false,'Connexion OAuth requise.',array('needs_oauth'=>true),409);$folders=dmd_mail_provider_folders($a);dmd_mail_api_reply(true,'Connexion réussie.',array('folders_count'=>count($folders)));
    }
    if ($action === 'attachment') {
        dmd_mail_api_require_permission('mail.attachments');
        $a=dmd_mail_api_account(trim((string)($_GET['account']??'')));$mid=(string)($_GET['message']??'');$aid=(string)($_GET['attachment']??'');$folder=(string)($_GET['folder']??'');$name=basename((string)($_GET['name']??'piece-jointe'));$mime='application/octet-stream';$data='';$p=(string)($a['provider']??'imap');
        if($p==='google'){$data=dmd_mail_gmail_attachment($a,$mid,$aid);}elseif($p==='microsoft'){$r=dmd_mail_graph_attachment($a,$mid,$aid);$data=$r['data'];$name=$r['name'];$mime=$r['mime'];}else{$r=dmd_mail_imap_attachment($a,$folder,$mid,$aid);$data=$r['data'];$name=$r['name'];$mime=$r['mime'];}
        while (ob_get_level() > 0) { @ob_end_clean(); } header('Content-Type: '.$mime);header('Content-Disposition: attachment; filename="'.str_replace('"','',basename($name)).'"');header('Content-Length: '.strlen($data));echo $data;exit;
    }
    dmd_mail_api_reply(false,'Action inconnue : '.$action,array(),404);
} catch (Throwable $e) {
    dmd_mail_api_reply(false,$e->getMessage(),array(),400);
}
