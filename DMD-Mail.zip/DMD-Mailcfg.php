<?php
require_once __DIR__ . '/dmd-mail-lib.php';
try { dmd_mail_require_user();
dmd_mail_require_permission('config.view'); } catch (Throwable $e) { echo 'Connexion requise.'; return; }
$base = dmd_mail_web_base();
$accounts = array_map('dmd_mail_public_account', dmd_mail_accounts());
$csrf = dmd_mail_csrf();
$msCfg = dmd_mail_microsoft_config();
$stdPresets = dmd_mail_standard_presets();
$standalone = !empty($_GET['standalone']);
$uid = 'dmdMailCfg_' . substr(md5(__DIR__.microtime(true)),0,9);
if ($standalone) { ?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DMD-Mail — Comptes</title><?php }
?><link rel="stylesheet" href="<?= htmlspecialchars($base.'dmd-mail.css?v=1.0.0',ENT_QUOTES,'UTF-8') ?>">
<style>
.dmd-mail-cfg,.dmd-mail-cfg *{box-sizing:border-box}.dmd-mail-cfg [hidden]{display:none!important}
.dmd-mail-cfg{min-height:420px;padding:18px;color:var(--text-color,inherit);background:transparent;font:inherit}
.dmd-mail-cfg-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:16px;padding:0 2px}
.dmd-mail-cfg-head h2{margin:0;font-size:18px;font-weight:800;letter-spacing:-.02em}
.dmd-mail-cfg-head>div{display:flex;gap:8px!important;align-items:center}
.dmd-mail-cfg-shell{display:grid;grid-template-columns:260px minmax(0,1fr);gap:14px;align-items:stretch;min-height:520px}
.dmd-mail-cfg-list{border:1px solid color-mix(in srgb,var(--border-color,currentColor) 62%,transparent);border-radius:14px;background:color-mix(in srgb,var(--panel-bg,transparent) 92%,var(--background-color,transparent));overflow:hidden;box-shadow:0 10px 28px rgba(0,0,0,.08)}
.dmd-mail-cfg-list-head{height:44px;display:flex;align-items:center;justify-content:space-between;padding:0 14px;border-bottom:1px solid color-mix(in srgb,var(--border-color,currentColor) 48%,transparent);font-size:11px;text-transform:uppercase;letter-spacing:.12em;opacity:.72}
.dmd-mail-cfg-items{padding:8px;display:grid;gap:6px}
.dmd-mail-cfg-item{position:relative;width:100%;min-height:62px;padding:10px 12px 10px 48px;border:1px solid transparent;border-radius:11px;background:transparent;color:inherit;text-align:left;cursor:pointer;transition:background .16s ease,border-color .16s ease,transform .16s ease}
.dmd-mail-cfg-item::before{content:attr(data-provider-icon);position:absolute;left:11px;top:50%;transform:translateY(-50%);width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--primary-color,currentColor) 16%,transparent);font-size:11px;font-weight:800;opacity:.9}
.dmd-mail-cfg-item:hover{background:color-mix(in srgb,var(--primary-color,currentColor) 7%,transparent);transform:translateX(1px)}
.dmd-mail-cfg-item.active{background:color-mix(in srgb,var(--primary-color,currentColor) 12%,transparent);border-color:color-mix(in srgb,var(--primary-color,currentColor) 55%,transparent);box-shadow:inset 3px 0 0 var(--primary-color,currentColor)}
.dmd-mail-cfg-item strong{display:block;font-size:13px;line-height:1.25;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dmd-mail-cfg-item small{display:block;margin-top:4px;font-size:10px;opacity:.58;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dmd-mail-cfg-card{position:relative;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 58%,transparent);border-radius:14px;background:color-mix(in srgb,var(--panel-bg,transparent) 97%,var(--background-color,transparent));padding:20px;box-shadow:0 10px 28px rgba(0,0,0,.08)}
.dmd-mail-cfg-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px 16px}
.dmd-mail-cfg-field{display:grid;gap:6px;min-width:0}.dmd-mail-cfg-field.full{grid-column:1/-1}
.dmd-mail-cfg-field>span{font-size:10px;font-weight:800;opacity:.62;text-transform:uppercase;letter-spacing:.07em}
.dmd-mail-cfg-field input,.dmd-mail-cfg-field select{width:100%;height:40px;padding:0 12px;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 62%,transparent);border-radius:9px;background:color-mix(in srgb,var(--input-bg,var(--panel-bg,transparent)) 96%,transparent);color:inherit;outline:none;font:inherit;transition:border-color .16s ease,box-shadow .16s ease,background .16s ease}
.dmd-mail-cfg-field input:hover,.dmd-mail-cfg-field select:hover{border-color:color-mix(in srgb,var(--primary-color,currentColor) 40%,var(--border-color,currentColor))}
.dmd-mail-cfg-field input:focus,.dmd-mail-cfg-field select:focus{border-color:var(--primary-color,currentColor);box-shadow:0 0 0 3px color-mix(in srgb,var(--primary-color,currentColor) 14%,transparent)}
.dmd-mail-cfg-section{grid-column:1/-1;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px 16px;padding:18px;margin-top:4px;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 46%,transparent);border-radius:12px;background:color-mix(in srgb,var(--background-color,var(--panel-bg,transparent)) 28%,transparent)}
.dmd-mail-cfg-section-title{grid-column:1/-1;font-size:12px;font-weight:900;letter-spacing:.01em;margin-bottom:1px}
.dmd-mail-cfg-note{grid-column:1/-1;padding:11px 12px;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 44%,transparent);border-radius:9px;background:color-mix(in srgb,var(--panel-bg,transparent) 72%,transparent);font-size:10px;line-height:1.5;opacity:.78}
.dmd-mail-cfg-note strong{opacity:1}.dmd-mail-cfg-callback{margin-top:5px;font-family:ui-monospace,Consolas,monospace;overflow-wrap:anywhere;user-select:all}
.dmd-mail-cfg-actions{display:flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap;margin-top:18px;padding-top:16px;border-top:1px solid color-mix(in srgb,var(--border-color,currentColor) 42%,transparent)}
.dmd-mail-cfg-actions .dmd-mail-btn{min-height:36px;border-radius:9px;padding:0 13px}
.dmd-mail-cfg-actions [data-delete]{margin-right:auto;color:var(--danger-color,#d9534f)}
.dmd-mail-cfg-status{order:-1;width:100%;min-height:0;margin:0 0 4px 0;padding:0;font-size:10px;opacity:.72}.dmd-mail-cfg-status:empty{display:none}.dmd-mail-cfg-status.error{padding:9px 11px;border:1px solid color-mix(in srgb,var(--danger-color,#c33) 65%,transparent);border-radius:8px;background:color-mix(in srgb,var(--danger-color,#c33) 8%,transparent);color:var(--danger-color,#c33);opacity:1}
.dmd-mail-cfg-empty{padding:26px 12px;text-align:center;font-size:11px;opacity:.54}
.dmd-mail-cfg-provider-state{display:inline-flex;align-items:center;gap:6px;font-size:10px;opacity:.72}.dmd-mail-cfg-dot{width:7px;height:7px;border-radius:50%;background:currentColor;opacity:.35}.dmd-mail-cfg-dot.ok{opacity:1;color:var(--success-color,#2b8a3e)}
.dmd-mail-ms-global-btn{height:36px;padding:0 12px;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 55%,transparent);border-radius:9px;background:color-mix(in srgb,var(--panel-bg,transparent) 92%,transparent);color:inherit;cursor:pointer;font:inherit;font-size:11px}.dmd-mail-ms-global-btn:hover{border-color:var(--primary-color,currentColor)}
.dmd-mail-cfg-head .dmd-mail-btn.primary{height:36px;border-radius:9px;padding:0 14px;font-weight:800}
.dmd-mail-ms-overlay[hidden]{display:none!important}.dmd-mail-ms-overlay{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(0,0,0,.68);backdrop-filter:blur(3px)}
.dmd-mail-ms-modal{width:min(980px,96vw);max-height:92vh;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 58%,transparent);border-radius:16px;background:var(--panel-bg,#fff);color:inherit;box-shadow:0 30px 100px rgba(0,0,0,.48);overflow:hidden;display:flex;flex-direction:column}
.dmd-mail-ms-modal-head{min-height:56px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid color-mix(in srgb,var(--border-color,currentColor) 45%,transparent);flex:0 0 auto}.dmd-mail-ms-modal-head strong{font-size:17px}.dmd-mail-ms-modal-body{padding:18px;display:grid;gap:14px;overflow:auto;min-height:0}
.dmd-mail-ms-row{display:flex;gap:8px;align-items:center}.dmd-mail-ms-row input{flex:1;height:40px;padding:0 12px;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 58%,transparent);border-radius:9px;background:var(--input-bg,var(--panel-bg,transparent));color:inherit;font-size:13px}.dmd-mail-ms-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:4px 0}.dmd-mail-ms-ready-line{display:flex;align-items:center;justify-content:space-between;gap:8px}.dmd-mail-ms-ready-line strong{font-size:13px}.dmd-mail-ms-ok{font-size:12px;opacity:.82}.dmd-mail-ms-hint{font-size:12px;line-height:1.55;opacity:.86;padding:12px 14px;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 48%,transparent);border-radius:10px}.dmd-mail-ms-hint a{color:inherit;font-weight:700;text-decoration:underline}
.dmd-mail-ms-steps{counter-reset:dmdms;list-style:none;margin:8px 0 0;padding:0;display:grid;gap:10px;font-size:13px;line-height:1.55}.dmd-mail-ms-steps li{counter-increment:dmdms;position:relative;padding:13px 14px 13px 52px;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 48%,transparent);border-radius:11px;background:color-mix(in srgb,var(--input-bg,rgba(127,127,127,.06)) 84%,transparent);min-height:48px}.dmd-mail-ms-steps li::before{content:counter(dmdms);position:absolute;left:14px;top:12px;width:27px;height:27px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:var(--primary-color,currentColor);color:var(--primary-contrast,#fff);font-weight:900;font-size:12px}.dmd-mail-ms-steps code{display:inline-block;padding:2px 5px;border-radius:5px;background:rgba(127,127,127,.16);font-family:ui-monospace,Consolas,monospace;font-size:.94em;overflow-wrap:anywhere}.dmd-mail-ms-panel-title{font-size:15px;font-weight:900;margin:4px 0 2px}.dmd-mail-ms-device-code{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:14px 16px!important;border:2px solid var(--primary-color,currentColor)!important;border-radius:10px;background:color-mix(in srgb,var(--primary-color,currentColor) 11%,transparent);font-size:12px!important;opacity:1!important}.dmd-mail-ms-device-code strong{display:inline-block;padding:8px 14px;border-radius:8px;background:var(--primary-color,currentColor);color:var(--primary-contrast,#fff);font-size:22px;letter-spacing:1.8px;line-height:1.1;user-select:all}.dmd-mail-ms-warning{padding:12px 14px;border:1px solid var(--warning-color,#d49b28);border-radius:10px;background:rgba(212,155,40,.10);font-size:12px;line-height:1.55}
@media(max-width:860px){.dmd-mail-cfg{padding:10px}.dmd-mail-cfg-shell{grid-template-columns:1fr}.dmd-mail-cfg-list{max-height:230px}.dmd-mail-cfg-items{grid-template-columns:repeat(auto-fit,minmax(180px,1fr))}.dmd-mail-cfg-item{min-height:56px}.dmd-mail-cfg-grid,.dmd-mail-cfg-section{grid-template-columns:1fr}.dmd-mail-cfg-field.full,.dmd-mail-cfg-section-title,.dmd-mail-cfg-note{grid-column:auto}}
@media(max-width:540px){.dmd-mail-cfg-head{align-items:flex-start}.dmd-mail-cfg-head>div{flex-wrap:wrap;justify-content:flex-end}.dmd-mail-cfg-card{padding:14px}.dmd-mail-cfg-section{padding:13px}.dmd-mail-cfg-actions{justify-content:stretch}.dmd-mail-cfg-actions .dmd-mail-btn{flex:1}.dmd-mail-cfg-actions [data-delete]{margin-right:0;flex:0 0 auto}}
</style>
<style>
/* CFG 30 — compact, lisible, sans grands cadres */
.dmd-mail-cfg{padding:12px 14px;min-height:0!important;background:transparent!important}
.dmd-mail-cfg-head{margin:0 0 10px;padding:0 2px;min-height:36px}
.dmd-mail-cfg-head h2{font-size:15px;letter-spacing:0}
.dmd-mail-cfg-shell{grid-template-columns:220px minmax(0,1fr);gap:12px;min-height:0!important;align-items:start}
.dmd-mail-cfg-list{align-self:start;border-radius:10px;box-shadow:none;background:color-mix(in srgb,var(--panel-bg,transparent) 45%,transparent);max-height:440px;overflow:auto}
.dmd-mail-cfg-list-head{height:34px;padding:0 10px;font-size:10px}
.dmd-mail-cfg-items{padding:5px;gap:3px}
.dmd-mail-cfg-item{min-height:48px;padding:7px 8px 7px 42px;border-radius:8px;transform:none!important}
.dmd-mail-cfg-item::before{left:8px;width:26px;height:26px}
.dmd-mail-cfg-item strong{font-size:12px}.dmd-mail-cfg-item small{font-size:9px;margin-top:2px}
.dmd-mail-cfg-item.active{box-shadow:inset 3px 0 0 var(--primary-color,currentColor);background:color-mix(in srgb,var(--primary-color,currentColor) 9%,transparent)}
.dmd-mail-cfg-card{padding:0 4px 4px;border:0;border-radius:0;background:transparent;box-shadow:none}
.dmd-mail-cfg-grid{gap:10px 12px}
.dmd-mail-cfg-field{gap:4px}.dmd-mail-cfg-field>span{font-size:9px;letter-spacing:.04em}
.dmd-mail-cfg-field input,.dmd-mail-cfg-field select{height:36px;border-radius:7px;padding:0 10px;background:color-mix(in srgb,var(--input-bg,var(--panel-bg,transparent)) 70%,transparent)}
.dmd-mail-cfg-section{gap:9px 12px;padding:12px 0 2px;margin-top:2px;border:0;border-top:1px solid color-mix(in srgb,var(--border-color,currentColor) 45%,transparent);border-radius:0;background:transparent}
.dmd-mail-cfg-section-title{font-size:11px;margin-bottom:0}
.dmd-mail-cfg-note{padding:8px 10px;border-radius:7px;font-size:9px;line-height:1.42;background:color-mix(in srgb,var(--panel-bg,transparent) 36%,transparent)}
.dmd-mail-cfg-actions{margin-top:12px;padding-top:10px;justify-content:flex-start;gap:6px}
.dmd-mail-cfg-actions .dmd-mail-btn{min-height:34px;height:34px;border-radius:7px;padding:0 11px}
.dmd-mail-cfg-actions [data-delete]{margin-left:auto;margin-right:0}
.dmd-mail-cfg-status{order:0;width:auto;flex:1;min-width:160px;margin:0;padding:0 4px}
.dmd-mail-cfg-head .dmd-mail-btn.primary,.dmd-mail-ms-global-btn{height:34px;border-radius:7px}
@media(max-width:760px){.dmd-mail-cfg-shell{grid-template-columns:1fr}.dmd-mail-cfg-list{max-height:170px}.dmd-mail-cfg-items{grid-template-columns:repeat(auto-fit,minmax(160px,1fr))}.dmd-mail-cfg-card{padding:0}.dmd-mail-cfg-grid,.dmd-mail-cfg-section{grid-template-columns:1fr}}
</style>
<style>
/* Correctif 31 — CFG compact et sans débordement horizontal */
.dmd-mail-cfg{max-width:1180px;margin:0 auto;padding:14px 16px}
.dmd-mail-cfg-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}.dmd-mail-cfg-head h2{margin:0}
.dmd-mail-cfg-shell{grid-template-columns:250px minmax(0,1fr);gap:14px}
.dmd-mail-cfg-list{width:100%;min-width:0;overflow:hidden!important;max-height:none;background:color-mix(in srgb,var(--panel-bg,transparent) 64%,transparent)}
.dmd-mail-cfg-items{overflow-y:auto;overflow-x:hidden;max-height:500px;padding:6px}
.dmd-mail-cfg-item{display:grid!important;grid-template-columns:32px minmax(0,1fr);grid-template-rows:auto auto;column-gap:9px;align-items:center;padding:8px!important;min-width:0!important;width:100%!important;text-align:left}
.dmd-mail-cfg-item::before{position:static!important;grid-row:1/3;grid-column:1;width:30px;height:30px}.dmd-mail-cfg-item strong{grid-column:2;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dmd-mail-cfg-item small{grid-column:2;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0!important}
.dmd-mail-cfg-card{min-width:0;padding:2px 0}.dmd-mail-cfg-grid{grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:10px 12px}.dmd-mail-cfg-field{min-width:0}.dmd-mail-cfg-field.full{grid-column:1/-1}.dmd-mail-cfg-field input,.dmd-mail-cfg-field select{width:100%;min-width:0}
.dmd-mail-cfg-section{padding:12px 0;margin-top:4px}.dmd-mail-cfg-note{max-width:100%;overflow-wrap:anywhere}.dmd-mail-cfg-actions{justify-content:flex-end}.dmd-mail-cfg-actions [data-delete]{margin-right:auto;margin-left:0}.dmd-mail-cfg-status{order:-1;width:100%;flex:0 0 100%;padding:0}
@media(max-width:780px){.dmd-mail-cfg{padding:10px}.dmd-mail-cfg-shell{grid-template-columns:1fr}.dmd-mail-cfg-list{max-height:190px}.dmd-mail-cfg-items{max-height:145px}.dmd-mail-cfg-grid,.dmd-mail-cfg-section{grid-template-columns:1fr}.dmd-mail-cfg-field.full{grid-column:1}}
</style>
<style>
/* Correctif 32 — liste des comptes plus propre et compacte */
.dmd-mail-cfg-shell{grid-template-columns:280px minmax(0,1fr);gap:16px}
.dmd-mail-cfg-list{border-radius:12px;background:color-mix(in srgb,var(--panel-bg,transparent) 46%,transparent);border:1px solid color-mix(in srgb,var(--border-color,currentColor) 42%,transparent);overflow:hidden!important}
.dmd-mail-cfg-list-head{height:38px;padding:0 12px;border-bottom:1px solid color-mix(in srgb,var(--border-color,currentColor) 36%,transparent);font-size:10px;letter-spacing:.08em}
.dmd-mail-cfg-items{padding:6px;gap:4px;max-height:500px;overflow-y:auto;overflow-x:hidden}
.dmd-mail-cfg-item{display:grid!important;grid-template-columns:minmax(0,1fr) auto;grid-template-rows:auto auto;gap:2px 8px;min-height:54px!important;padding:8px 10px!important;border-radius:9px!important;border:1px solid transparent!important;box-shadow:none!important;background:transparent!important;transform:none!important}
.dmd-mail-cfg-item::before{display:none!important;content:none!important}
.dmd-mail-cfg-item strong{grid-column:1;grid-row:1;font-size:12px;line-height:1.25;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.dmd-mail-cfg-item small{grid-column:1;grid-row:2;font-size:9px;line-height:1.2;opacity:.58;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;margin:0!important}
.dmd-mail-cfg-item .dmd-mail-cfg-provider-chip{grid-column:2;grid-row:1/3;align-self:center;justify-self:end;max-width:82px;padding:3px 7px;border-radius:999px;border:1px solid color-mix(in srgb,var(--border-color,currentColor) 40%,transparent);font-size:8px;line-height:1.1;opacity:.68;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.dmd-mail-cfg-item:hover{background:color-mix(in srgb,var(--primary-color,currentColor) 5%,transparent)!important;border-color:color-mix(in srgb,var(--border-color,currentColor) 30%,transparent)!important}
.dmd-mail-cfg-item.active{background:color-mix(in srgb,var(--primary-color,currentColor) 9%,transparent)!important;border-color:color-mix(in srgb,var(--primary-color,currentColor) 42%,transparent)!important;box-shadow:inset 3px 0 0 var(--primary-color,currentColor)!important}
.dmd-mail-cfg-item.active strong{color:var(--primary-color,currentColor)}
.dmd-mail-cfg-card{padding:0!important}
@media(max-width:780px){.dmd-mail-cfg-shell{grid-template-columns:1fr}.dmd-mail-cfg-list{max-height:190px}.dmd-mail-cfg-items{grid-template-columns:repeat(auto-fit,minmax(210px,1fr));max-height:145px}}
</style>
<?php if ($standalone) { ?></head><body><?php } ?>
<div class="dmd-mail-cfg" id="<?= htmlspecialchars($uid,ENT_QUOTES,'UTF-8') ?>" data-api="<?= htmlspecialchars($base.'dmd-mail-api.php',ENT_QUOTES,'UTF-8') ?>" data-oauth="<?= htmlspecialchars($base.'dmd-mail-oauth.php',ENT_QUOTES,'UTF-8') ?>">
  <div class="dmd-mail-cfg-head">
    <h2>✉ DMD-Mail — Comptes</h2>
    <div style="display:flex;gap:6px;align-items:center">
      <button class="dmd-mail-ms-global-btn" type="button" data-ms-help>Microsoft : procédure</button>
      <button class="dmd-mail-btn primary" type="button" data-new>＋ Ajouter</button>
    </div>
  </div>
  <div class="dmd-mail-cfg-shell">
    <aside class="dmd-mail-cfg-list">
      <div class="dmd-mail-cfg-list-head"><strong>Messageries</strong><span data-total></span></div>
      <div class="dmd-mail-cfg-items" data-list></div>
    </aside>
    <section class="dmd-mail-cfg-card">
      <form data-form autocomplete="off">
        <input type="hidden" name="id" data-id>
        <div class="dmd-mail-cfg-grid">
          <label class="dmd-mail-cfg-field">
            <span>Type de compte</span>
            <select name="preset" data-preset>
              <optgroup label="Principaux fournisseurs">
                <option value="gmail_app">Gmail — mot de passe d’application</option>
                <option value="microsoft">Microsoft 365 — compte professionnel / tenant</option>
                <option value="microsoft_personal">Outlook.com / Hotmail / Microsoft 365 Personnel</option>
                <option value="orange">Orange / Wanadoo</option>
                <option value="free">Free</option>
                <option value="sfr">SFR / Neuf</option>
                <option value="laposte">LaPoste.net</option>
                <option value="ovh">OVHcloud / MX Plan</option>
                <option value="yahoo">Yahoo Mail</option>
                <option value="icloud">Apple iCloud Mail</option>
                <option value="infomaniak">Infomaniak</option>
                <option value="gandi">Gandi</option>
                <option value="ionos">IONOS</option>
                <option value="gmx">GMX</option>
                <option value="fastmail">Fastmail</option>
                <option value="zoho_eu">Zoho Mail Europe</option>
                <option value="zoho_com">Zoho Mail International</option>
                <option value="proton_bridge">Proton Mail Bridge</option>
              </optgroup>
              <optgroup label="Universel">
                <option value="custom">Autre fournisseur — IMAP / SMTP</option>
                <option value="google_oauth">Gmail OAuth — avancé</option>
              </optgroup>
            </select>
          </label>
          <label class="dmd-mail-cfg-field"><span>Nom affiché</span><input name="name" placeholder="Gmail perso, Pro, Support…"></label>
          <label class="dmd-mail-cfg-field full"><span>Adresse e-mail</span><input name="email" type="email" required placeholder="moi@domaine.tld"></label>

          <div class="dmd-mail-cfg-section" data-section="gmail_app">
            <div class="dmd-mail-cfg-section-title">Gmail</div>
            <label class="dmd-mail-cfg-field full"><span>Mot de passe d’application Google <em data-pw-state></em></span><input name="password" type="password" autocomplete="new-password" placeholder="xxxx xxxx xxxx xxxx"></label>
            <div class="dmd-mail-cfg-note"><strong>Configuration automatique.</strong> DMD-Mail utilise imap.gmail.com et smtp.gmail.com. Ici il faut le mot de passe d’application Google à 16 caractères, pas le mot de passe normal du compte.</div>
          </div>

          <div class="dmd-mail-cfg-section" data-section="standard" hidden>
            <div class="dmd-mail-cfg-section-title" data-standard-title>Fournisseur IMAP / SMTP</div>
            <label class="dmd-mail-cfg-field full"><span>Mot de passe de la boîte <em data-pw-state-standard></em></span><input name="standard_password" type="password" autocomplete="new-password" placeholder="Laisser vide pour conserver"></label>
            <label class="dmd-mail-cfg-field"><span>Utilisateur IMAP</span><input name="username" placeholder="Par défaut : adresse e-mail"></label>
            <label class="dmd-mail-cfg-field"><span>Utilisateur SMTP</span><input name="smtp_username" placeholder="Par défaut : identique"></label>
            <div class="dmd-mail-cfg-note" data-standard-note><strong>Configuration automatique.</strong> Les serveurs IMAP/SMTP sont renseignés par DMD-Mail.</div>
          </div>

          <div class="dmd-mail-cfg-section" data-section="proton_bridge" hidden>
            <div class="dmd-mail-cfg-section-title">Proton Mail Bridge</div>
            <label class="dmd-mail-cfg-field"><span>Serveur IMAP Bridge</span><input name="proton_imap_host" value="127.0.0.1"></label>
            <label class="dmd-mail-cfg-field"><span>Port IMAP Bridge</span><input name="proton_imap_port" type="number" value="1143"></label>
            <label class="dmd-mail-cfg-field"><span>Serveur SMTP Bridge</span><input name="proton_smtp_host" value="127.0.0.1"></label>
            <label class="dmd-mail-cfg-field"><span>Port SMTP Bridge</span><input name="proton_smtp_port" type="number" value="1025"></label>
            <label class="dmd-mail-cfg-field"><span>Utilisateur Bridge</span><input name="proton_username"></label>
            <label class="dmd-mail-cfg-field full"><span>Mot de passe Bridge <em data-pw-state-proton></em></span><input name="proton_password" type="password" autocomplete="new-password" placeholder="Mot de passe généré par Proton Bridge"></label>
            <div class="dmd-mail-cfg-note"><strong>Bridge requis.</strong> Utilisez les identifiants et ports affichés par Proton Mail Bridge. Le Bridge doit être accessible depuis le serveur DoMyDesk.</div>
          </div>

          <div class="dmd-mail-cfg-section" data-section="custom" hidden>
            <div class="dmd-mail-cfg-section-title">Réception IMAP</div>
            <label class="dmd-mail-cfg-field"><span>Serveur IMAP</span><input name="imap_host" placeholder="imap.exemple.tld"></label>
            <label class="dmd-mail-cfg-field"><span>Port IMAP</span><input name="imap_port" type="number" value="993"></label>
            <label class="dmd-mail-cfg-field"><span>Sécurité IMAP</span><select name="imap_security"><option value="ssl">SSL/TLS</option><option value="tls">STARTTLS</option><option value="none">Aucune</option></select></label>
            <label class="dmd-mail-cfg-field"><span>Utilisateur IMAP</span><input name="custom_username"></label>
            <label class="dmd-mail-cfg-field full"><span>Mot de passe IMAP <em data-pw-state-custom></em></span><input name="custom_password" type="password" autocomplete="new-password" placeholder="Laisser vide pour conserver"></label>
            <div class="dmd-mail-cfg-section-title">Envoi SMTP</div>
            <label class="dmd-mail-cfg-field"><span>Serveur SMTP</span><input name="smtp_host" placeholder="smtp.exemple.tld"></label>
            <label class="dmd-mail-cfg-field"><span>Port SMTP</span><input name="smtp_port" type="number" value="465"></label>
            <label class="dmd-mail-cfg-field"><span>Sécurité SMTP</span><select name="smtp_security"><option value="ssl">SSL/TLS</option><option value="tls">STARTTLS</option><option value="none">Aucune</option></select></label>
            <label class="dmd-mail-cfg-field"><span>Utilisateur SMTP</span><input name="custom_smtp_username"></label>
            <label class="dmd-mail-cfg-field full"><span>Mot de passe SMTP <em data-spw-state></em></span><input name="smtp_password" type="password" autocomplete="new-password" placeholder="Vide = même mot de passe que l’IMAP"></label>
          </div>

          <div class="dmd-mail-cfg-section" data-section="google_oauth" hidden>
            <div class="dmd-mail-cfg-section-title">Google OAuth — mode avancé</div>
            <label class="dmd-mail-cfg-field full"><span>Client ID</span><input name="client_id" autocomplete="off"></label>
            <label class="dmd-mail-cfg-field full"><span>Client secret <em data-secret-state-google></em></span><input name="client_secret" type="password" autocomplete="new-password" placeholder="Laisser vide pour conserver"></label>
            <div class="dmd-mail-cfg-note">URI de redirection à déclarer dans l’application Google OAuth :<div class="dmd-mail-cfg-callback"><?= htmlspecialchars(dmd_mail_oauth_redirect_uri(),ENT_QUOTES,'UTF-8') ?></div></div>
          </div>

          <div class="dmd-mail-cfg-section" data-section="microsoft" hidden>
            <div class="dmd-mail-cfg-section-title">Microsoft 365 — compte professionnel / tenant</div>
            <div class="dmd-mail-cfg-note"><strong>Connexion Microsoft officielle.</strong> DMD-Mail ne demande jamais votre mot de passe ni votre code MFA. Après l’enregistrement de l’adresse, utilisez « Connecter Microsoft » : Microsoft ouvre sa page de connexion et gère mot de passe, push, SMS ou Authenticator.</div>
            <div class="dmd-mail-cfg-note">Configuration DMD-Mail Microsoft : <strong data-ms-config-state><?= !empty($msCfg['configured']) ? 'prête' : 'à faire une seule fois' ?></strong>. <button class="dmd-mail-ms-global-btn" type="button" data-ms-help-inline>Voir la procédure</button></div>
            <div class="dmd-mail-cfg-note dmd-mail-ms-device-code" data-ms-device hidden><span><b>CODE À SAISIR CHEZ MICROSOFT</b><br><small>Ce n’est PAS le code Microsoft Authenticator.</small></span><strong data-ms-code></strong></div>
          </div>
          <div class="dmd-mail-cfg-section" data-section="microsoft_personal" hidden>
            <div class="dmd-mail-cfg-section-title">Outlook.com / Hotmail / Microsoft 365 Personnel</div>
            <div class="dmd-mail-cfg-note"><strong>Compte Microsoft personnel.</strong> Utilisez ce mode pour @outlook.com, @hotmail.com, @live.*, @msn.com et les abonnements Microsoft 365 Personnel/Famille. Aucun tenant n’est demandé pour la boîte. DMD-Mail utilise le flux Microsoft <code>consumers</code>.</div>
            <div class="dmd-mail-cfg-note">Configuration OAuth DMD-Mail : <strong data-ms-config-state-personal><?= !empty($msCfg['configured']) ? 'prête' : 'à faire une seule fois' ?></strong>. <button class="dmd-mail-ms-global-btn" type="button" data-ms-help-personal>Voir la procédure O365 Personnel / Outlook.com</button></div>
            <div class="dmd-mail-cfg-note dmd-mail-ms-device-code" data-ms-device-personal hidden><span><b>CODE À SAISIR CHEZ MICROSOFT</b><br><small>Ce n’est PAS le code Microsoft Authenticator.</small></span><strong data-ms-code-personal></strong></div>
          </div>

        </div>
        <div class="dmd-mail-cfg-actions">
          <button class="dmd-mail-btn primary" type="submit">Enregistrer</button>
          <button class="dmd-mail-btn" type="button" data-save-test>Enregistrer + tester</button>
          <button class="dmd-mail-btn" type="button" data-oauth-connect hidden>Connecter le compte</button>
          <button class="dmd-mail-btn" type="button" data-delete hidden>Supprimer</button>
          <span class="dmd-mail-cfg-provider-state" data-state hidden><span class="dmd-mail-cfg-dot" data-state-dot></span><span data-state-label></span></span>
          <span class="dmd-mail-cfg-status" data-status></span>
        </div>
      </form>
    </section>
  </div>
  <div class="dmd-mail-ms-overlay" data-ms-overlay hidden>
  <div class="dmd-mail-ms-modal" role="dialog" aria-modal="true" aria-label="Configuration Microsoft">
    <div class="dmd-mail-ms-modal-head"><strong>Microsoft — configuration DMD-Mail</strong><button class="dmd-mail-ms-global-btn" type="button" data-ms-close>Fermer</button></div>
    <div class="dmd-mail-ms-modal-body">
      <div class="dmd-mail-ms-ready-line"><strong>ID d’application (client)</strong><span class="dmd-mail-ms-ok" data-ms-modal-state><?= !empty($msCfg['configured']) ? '✓ configuré' : 'non configuré' ?></span></div>
      <div class="dmd-mail-ms-row"><input data-ms-client-id value="<?= htmlspecialchars((string)($msCfg['client_id'] ?? ''),ENT_QUOTES,'UTF-8') ?>" placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"><button class="dmd-mail-btn primary" type="button" data-ms-save>Enregistrer l’ID</button></div>
      <div class="dmd-mail-ms-hint">Cet ID est enregistré dans l’espace DMD-Mail de votre utilisateur. Un seul ID peut servir à vos comptes Microsoft 365 ET Outlook.com si l’application est créée avec le type de comptes indiqué ci-dessous. Aucun secret client n’est nécessaire avec le Device Code Flow.</div>
      <div class="dmd-mail-ms-actions"><button class="dmd-mail-btn" type="button" data-ms-tab="m365">Procédure Microsoft 365</button><button class="dmd-mail-btn" type="button" data-ms-tab="outlook">Procédure O365 Personnel / Outlook.com</button></div>
      <div data-ms-panel="m365">
        <div class="dmd-mail-ms-panel-title">Microsoft 365 — procédure complète</div>
        <ol class="dmd-mail-ms-steps">
          <li>Ouvrez <b>entra.microsoft.com</b> avec le compte qui administre votre Microsoft 365, puis allez dans <b>Entra ID → Inscriptions d’applications → Nouvelle inscription</b>.</li>
          <li>Nom : <b>DMD-Mail</b>. Dans <b>Types de comptes pris en charge</b>, choisissez <b>Comptes dans n’importe quel annuaire organisationnel et comptes Microsoft personnels</b>. Ce choix permet d’utiliser le même ID pour Microsoft 365 et Outlook.com/Hotmail.</li>
          <li>Validez l’inscription. Dans <b>Vue d’ensemble</b>, copiez uniquement l’<b>ID d’application (client)</b>. <b>Ne créez aucun secret client.</b></li>
          <li>Allez dans <b>Authentication (Preview)</b> ou <b>Authentification</b> → <b>Ajouter une plateforme</b> → <b>Applications mobiles et de bureau</b>. Ajoutez l’URI <code>https://login.microsoftonline.com/common/oauth2/nativeclient</code>, puis enregistrez.</li>
          <li><b>Rendre l’application cliente publique :</b> si votre page Authentification affiche <b>Autoriser les flux clients publics / Allow public client flows</b>, mettez-le sur <b>Oui</b> puis enregistrez. <b>Si ce réglage n’apparaît pas dans votre interface</b>, allez dans <b>Manifeste</b>, cherchez <code>isFallbackPublicClient</code>, mettez sa valeur à <code>true</code>, puis enregistrez le manifeste.</li>
          <li>Allez dans <b>API autorisées / Autorisations d’API → Ajouter une autorisation → Microsoft Graph → Autorisations déléguées</b>. Ajoutez <b>User.Read</b>, <b>Mail.ReadWrite</b> et <b>Mail.Send</b>. Si votre organisation interdit le consentement utilisateur, utilisez ensuite <b>Accorder le consentement administrateur</b>.</li>
          <li>Revenez dans cette fenêtre DMD-Mail, collez l’<b>ID d’application (client)</b> dans le champ ci-dessus et cliquez <b>Enregistrer l’ID</b>.</li>
          <li><b>Connexion et code :</b> dans la fiche de votre adresse Microsoft 365, cliquez <b>Connecter Microsoft</b>. DMD-Mail choisit automatiquement le bon flux : <b>Outlook.com / Hotmail / Live → comptes Microsoft personnels</b>, autres domaines Microsoft 365 → flux organisationnel. DMD-Mail affiche ensuite très visiblement un <b>CODE DE CONNEXION MICROSOFT</b> (exemple : <code>D43QBU9SH</code>) et ouvre la page Microsoft. <b>Recopiez CE code dans « Saisir le code pour autoriser l’accès ».</b> Ne saisissez surtout pas le code à 6 chiffres de Microsoft Authenticator : ce n’est pas le même code.</li>
          <li><b>Approbation administrateur :</b> si Microsoft affiche <b>« Approbation administrateur requise »</b>, l’application doit être approuvée par un administrateur du tenant. Connectez-vous avec un compte administrateur puis allez dans <b>Entra → Inscriptions d’applications → DMD-Mail → API autorisées</b> et cliquez <b>Accorder le consentement administrateur pour l’organisation</b>, puis confirmez. Les autorisations doivent ensuite apparaître comme <b>Accordé</b>. Relancez ensuite <b>Connecter Microsoft</b> dans DMD-Mail.</li>
          <li>Une fois le consentement accordé, Microsoft poursuit normalement avec le mot de passe puis, si votre compte l’exige, le MFA (push, SMS ou Authenticator). DMD-Mail ne voit ni votre mot de passe ni votre code MFA.</li>
        </ol>
        <div class="dmd-mail-ms-hint"><b>Erreur AADSTS70002 / “application must be marked as mobile” :</b> l’étape 4 ou 5 n’est pas appliquée. Vérifiez la plateforme <b>Applications mobiles et de bureau</b> et <code>isFallbackPublicClient: true</code>.</div>
      </div>
      <div data-ms-panel="outlook" hidden>
        <div class="dmd-mail-ms-panel-title">Microsoft 365 Personnel / Outlook.com / Hotmail / Live — procédure complète</div>
        <ol class="dmd-mail-ms-steps">
          <li><b>Choisissez dans DMD-Mail « Outlook.com / Hotmail / Microsoft 365 Personnel ».</b> Ce mode est destiné aux comptes personnels Microsoft : @outlook.com, @hotmail.com, @live.*, @msn.com et abonnements Microsoft 365 Personnel/Famille. Il ne demande aucun tenant pour la boîte.</li>
          <li>Le compte personnel n’a pas besoin de posséder son propre tenant Entra. DMD-Mail utilise l’<b>application OAuth DMD-Mail</b>. Si l’ID d’application DMD-Mail est déjà configuré et autorise les <b>comptes Microsoft personnels</b>, passez directement à l’étape 8.</li>
          <li>Si l’instance DMD-Mail n’a encore aucun ID OAuth Microsoft, l’administrateur/éditeur de DMD-Mail doit enregistrer <b>une seule application DMD-Mail</b>. Les utilisateurs personnels ne créent pas un tenant pour leur propre boîte.</li>
          <li>Dans <b>Types de comptes pris en charge</b>, choisissez <b>Comptes dans n’importe quel annuaire organisationnel et comptes Microsoft personnels</b> (recommandé), puis copiez l’<b>ID d’application (client)</b>. Ne créez pas de secret client.</li>
          <li>Dans <b>Authentication (Preview)</b> / <b>Authentification</b>, ajoutez la plateforme <b>Applications mobiles et de bureau</b> avec <code>https://login.microsoftonline.com/common/oauth2/nativeclient</code>.</li>
          <li>Si <b>Autoriser les flux clients publics</b> est visible, activez-le. S’il n’est pas visible, ouvrez <b>Manifeste</b> et mettez <code>isFallbackPublicClient</code> à <code>true</code>. Enregistrez.</li>
          <li>Dans <b>Microsoft Graph → Autorisations déléguées</b>, ajoutez <b>User.Read</b>, <b>Mail.ReadWrite</b> et <b>Mail.Send</b>.</li>
          <li>Dans DMD-Mail, enregistrez cet ID une seule fois. Ajoutez ensuite votre adresse en choisissant <b>Outlook.com / Hotmail / Microsoft 365 Personnel</b>, puis cliquez <b>Connecter Microsoft</b>.</li>
          <li><b>Code de connexion :</b> DMD-Mail affiche un code court (exemple : <code>D43QBU9SH</code>). Dans la page Microsoft <b>« Saisir le code pour autoriser l’accès »</b>, recopiez exactement ce code. <b>N’utilisez pas le code Microsoft Authenticator à 6 chiffres.</b></li>
          <li>Si Microsoft affiche <b>« Approbation administrateur requise »</b> pour un compte d’organisation, accordez le consentement depuis <b>Entra → DMD-Mail → API autorisées → Accorder le consentement administrateur</b>, puis recommencez la connexion. Pour un compte Outlook.com personnel pur, cette étape n’existe normalement pas.</li>
          <li>Le mot de passe et le MFA restent uniquement sur la page Microsoft.</li>
        </ol>
        <div class="dmd-mail-ms-hint">Le même ID DMD-Mail peut servir aux comptes Microsoft 365 et aux comptes Outlook.com personnels si le type de comptes choisi à l’inscription inclut bien les <b>comptes Microsoft personnels</b>.</div>
      </div>
      <div class="dmd-mail-cfg-status" data-ms-status></div>
    </div>
  </div>
  </div>
</div>
<script>
(function(){
 const root=document.getElementById(<?= json_encode($uid) ?>); if(!root||root.dataset.ready==='1')return; root.dataset.ready='1';
 const api=root.dataset.api, oauth=root.dataset.oauth, csrf=<?= json_encode($csrf) ?>;
 let accounts=<?= json_encode($accounts,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>, current=null, saveMode='create', msConfigured=<?= !empty($msCfg['configured']) ? 'true' : 'false' ?>;
 const $=s=>root.querySelector(s), $$=s=>[...root.querySelectorAll(s)], form=$('[data-form]'), preset=$('[data-preset]'), statusEl=$('[data-status]');
 const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
 const stdPresets=<?= json_encode($stdPresets,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
 const labels={gmail_app:'Gmail',custom:'IMAP / SMTP',google_oauth:'Gmail OAuth',microsoft:'Microsoft',proton_bridge:'Proton Mail Bridge'}; Object.entries(stdPresets).forEach(([k,v])=>labels[k]=v.label||k);
 function status(t,err=false){statusEl.textContent=t||'';statusEl.classList.toggle('error',!!err)}
 function msStatus(t,err=false){const x=$('[data-ms-status]');if(!x)return;x.textContent=t||'';x.classList.toggle('error',!!err)}
 function openMs(panel){const o=$('[data-ms-overlay]');if(!o)return;o.hidden=false;$$('[data-ms-panel]').forEach(x=>x.hidden=x.dataset.msPanel!==(panel||'m365'));}
 function closeMs(){const o=$('[data-ms-overlay]');if(o)o.hidden=true;}
 async function post(action,data){const r=await fetch(api+'?action='+encodeURIComponent(action),{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-DMD-CSRF':csrf},body:JSON.stringify({...data,csrf})});let j={};try{j=await r.json()}catch(e){}if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));return j}
 function renderList(){ $('[data-total]').textContent=accounts.length; $('[data-list]').innerHTML=accounts.length?accounts.map(a=>{const provider=labels[a.preset]||a.provider||'Mail';const state=a.oauth_connected?' · connecté':'';return `<button class="dmd-mail-cfg-item ${current&&a.id===current.id?'active':''}" type="button" data-edit="${esc(a.id)}"><strong>${esc(a.name||a.email)}</strong><small>${esc(a.email||'')}${state}</small><span class="dmd-mail-cfg-provider-chip">${esc(provider)}</span></button>`}).join(''):'<div class="dmd-mail-cfg-empty">Aucun compte.</div>'; }
 function applyPreset(){const p=preset.value,section=stdPresets[p]?'standard':p;$$('[data-section]').forEach(x=>x.hidden=x.dataset.section!==section);if(stdPresets[p]){const c=stdPresets[p];const t=$('[data-standard-title]');if(t)t.textContent=c.label||'Messagerie';const n=$('[data-standard-note]');if(n)n.innerHTML='<strong>Configuration automatique.</strong> '+esc(c.imap_host)+':'+esc(c.imap_port)+' / '+esc(c.smtp_host)+':'+esc(c.smtp_port);}const oauthMode=p==='google_oauth'||p==='microsoft'||p==='microsoft_personal';const cb=$('[data-oauth-connect]');cb.hidden=!oauthMode||!current;cb.textContent=(p==='microsoft'||p==='microsoft_personal')?'Connecter Microsoft':'Connecter Google';const md=$('[data-ms-device]');if(md&&p!=='microsoft')md.hidden=true;const mdp=$('[data-ms-device-personal]');if(mdp&&p!=='microsoft_personal')mdp.hidden=true;$('[data-delete]').hidden=!current;updateState();}
 function updateState(){const box=$('[data-state]');if(!current){box.hidden=true;return;}box.hidden=false;const oauthMode=current.provider==='google'||current.provider==='microsoft';const ok=oauthMode?!!current.oauth_connected:!!current.password_saved;$('[data-state-dot]').classList.toggle('ok',ok);$('[data-state-label]').textContent=oauthMode?(ok?'OAuth connecté':'OAuth à connecter'):(ok?'Identifiants enregistrés':'Identifiants manquants');}
 function reset(){current=null;saveMode='create';form.reset();$('[data-id]').value='';preset.value='gmail_app';form.elements.imap_port.value=993;form.elements.smtp_port.value=465;form.elements.imap_security.value='ssl';form.elements.smtp_security.value='ssl';$$('em').forEach(x=>x.textContent='');applyPreset();renderList();status('Nouveau compte.');}
 function fill(a){current=a;saveMode='update';form.reset();$('[data-id]').value=a.id||'';preset.value=a.preset||((a.provider==='google')?'google_oauth':(a.provider==='microsoft'?'microsoft':'custom'));form.elements.name.value=a.name||'';form.elements.email.value=a.email||'';form.elements.imap_host.value=a.imap_host||'';form.elements.imap_port.value=a.imap_port||993;form.elements.imap_security.value=a.imap_security||'ssl';form.elements.smtp_host.value=a.smtp_host||'';form.elements.smtp_port.value=a.smtp_port||465;form.elements.smtp_security.value=a.smtp_security||'ssl';form.elements.username.value=a.username||'';form.elements.custom_username.value=a.username||'';form.elements.smtp_username.value=a.smtp_username||'';form.elements.custom_smtp_username.value=a.smtp_username||'';form.elements.proton_imap_host.value=a.imap_host||'127.0.0.1';form.elements.proton_imap_port.value=a.imap_port||1143;form.elements.proton_smtp_host.value=a.smtp_host||'127.0.0.1';form.elements.proton_smtp_port.value=a.smtp_port||1025;form.elements.proton_username.value=a.username||'';form.elements.client_id.value=a.client_id||'';const saved=a.password_saved?'(enregistré)':'';$('[data-pw-state]').textContent=saved;const ps=$('[data-pw-state-standard]');if(ps)ps.textContent=saved; const pp=$('[data-pw-state-proton]');if(pp)pp.textContent=saved;$('[data-pw-state-custom]').textContent=saved;$('[data-spw-state]').textContent=a.smtp_password_saved?'(enregistré)':'';$('[data-secret-state-google]').textContent=a.client_secret_saved?'(enregistré)':'';applyPreset();renderList();status('');}
 function payload(){const p=preset.value,o={id:$('[data-id]').value,save_mode:saveMode,preset:p,name:form.elements.name.value.trim(),email:form.elements.email.value.trim(),enabled:true};if(p==='gmail_app'){o.password=form.elements.password.value;}else if(stdPresets[p]){o.password=form.elements.standard_password.value;o.username=form.elements.username.value;o.smtp_username=form.elements.smtp_username.value;o.smtp_same_password=true;}else if(p==='proton_bridge'){o.imap_host=form.elements.proton_imap_host.value;o.imap_port=form.elements.proton_imap_port.value;o.imap_security='tls';o.username=form.elements.proton_username.value;o.password=form.elements.proton_password.value;o.smtp_host=form.elements.proton_smtp_host.value;o.smtp_port=form.elements.proton_smtp_port.value;o.smtp_security='tls';o.smtp_username=form.elements.proton_username.value;o.smtp_same_password=true;}else if(p==='custom'){o.imap_host=form.elements.imap_host.value;o.imap_port=form.elements.imap_port.value;o.imap_security=form.elements.imap_security.value;o.username=form.elements.custom_username.value;o.password=form.elements.custom_password.value;o.smtp_host=form.elements.smtp_host.value;o.smtp_port=form.elements.smtp_port.value;o.smtp_security=form.elements.smtp_security.value;o.smtp_username=form.elements.custom_smtp_username.value;o.smtp_password=form.elements.smtp_password.value;}else if(p==='google_oauth'){o.client_id=form.elements.client_id.value;o.client_secret=form.elements.client_secret.value;}return o}
 async function save(){const creating=saveMode==='create';status(creating?'Ajout de la messagerie…':'Enregistrement…');const j=await post('save_account',payload());const i=accounts.findIndex(a=>a.id===j.account.id);if(i>=0)accounts[i]=j.account;else accounts.push(j.account);fill(j.account);status(creating?'Messagerie ajoutée.':'Compte enregistré.');try{window.opener&&window.opener.postMessage({type:'dmd-mail-accounts-changed',account:j.account.id},location.origin)}catch(e){}return j.account}
 async function test(a){status('Test de connexion…');const j=await post('test_account',{account:a.id});status('Connexion réussie · '+(j.folders_count??0)+' dossier(s).');return j}
 preset.onchange=()=>{const changed=!!current && (current.preset||((current.provider==='google')?'google_oauth':(current.provider==='microsoft'?'microsoft':'custom')))!==preset.value;applyPreset();if(changed){status('Type de compte changé : les anciens identifiants ne seront pas réutilisés. Renseignez ceux de ce fournisseur.');const box=$('[data-state]');if(box)box.hidden=true;}};$('[data-new]').onclick=reset;$('[data-list]').onclick=e=>{const b=e.target.closest('[data-edit]');if(!b)return;const a=accounts.find(x=>x.id===b.dataset.edit);if(a)fill(a)};
 form.onsubmit=async e=>{e.preventDefault();try{await save()}catch(err){status(err.message,true)}};
 $('[data-delete]').onclick=async()=>{if(!current||!current.id)return;const label=current.name||current.email||'ce compte';if(!confirm('Supprimer définitivement la messagerie « '+label+' » de DMD-Mail ?'))return;const deletedId=current.id;status('Suppression du compte…');try{await post('delete_account',{id:deletedId});accounts=accounts.filter(a=>a.id!==deletedId);current=null;saveMode='create';renderList();if(accounts.length)fill(accounts[0]);else reset();status('Compte supprimé.');try{window.opener&&window.opener.postMessage({type:'dmd-mail-accounts-changed',account:deletedId,deleted:true},location.origin)}catch(e){}}catch(err){status('Suppression impossible : '+err.message,true)}};
 $('[data-save-test]').onclick=async()=>{const creating=saveMode==='create';status(creating?'Ajout et test…':'Enregistrement et test…');try{const j=await post('save_test_account',payload());const a=j.account;const i=accounts.findIndex(x=>x.id===a.id);if(i>=0)accounts[i]=a;else accounts.push(a);fill(a);try{window.opener&&window.opener.postMessage({type:'dmd-mail-accounts-changed',account:a.id},location.origin)}catch(e){}if(j.needs_oauth){status(a.provider==='microsoft'?'Compte enregistré. Cliquez sur « Connecter Microsoft ».':'Compte enregistré. Cliquez sur « Connecter Google ».');return;}status('Connexion réussie · '+(j.folders_count??0)+' dossier(s).')}catch(err){status('Échec : '+err.message+' — configuration précédente conservée.',true);try{const boot=await fetch(api+'?action=bootstrap',{credentials:'same-origin',cache:'no-store'}).then(x=>x.json());if(boot.ok){const oldId=current&&current.id;accounts=boot.accounts||[];const old=oldId?accounts.find(x=>x.id===oldId):null;if(old)fill(old);else renderList();status('Échec : '+err.message+' — configuration précédente conservée.',true)}}catch(e){}}};

 $('[data-oauth-connect]').onclick=async()=>{if(!current)return;const p=preset.value;if((p==='microsoft'||p==='microsoft_personal')&&!msConfigured){openMs(p==='microsoft_personal'?'outlook':'m365');msStatus('Enregistrez d’abord l’ID d’application Microsoft.');return;}let w=null;if(p==='microsoft'||p==='microsoft_personal')w=window.open('about:blank','DMDMailMicrosoft','width=760,height=760,resizable=yes,scrollbars=yes');try{const a=await save();if(p==='microsoft'||p==='microsoft_personal'){const j=await post('microsoft_device_start',{account:a.id});const md=p==='microsoft_personal'?$('[data-ms-device-personal]'):$('[data-ms-device]');if(md){md.hidden=false;const codeEl=p==='microsoft_personal'?$('[data-ms-code-personal]'):$('[data-ms-code]');if(codeEl)codeEl.textContent=j.user_code||'';}status('Code Microsoft : '+(j.user_code||'')+' — validation en attente…');if(w)w.location.href=j.verification_uri||'https://microsoft.com/devicelogin';let delay=Math.max(3000,Number(j.interval||5)*1000);const started=Date.now();const poll=async()=>{try{const r=await post('microsoft_device_poll',{account:a.id});if(r.connected){status('Microsoft connecté. Test en cours…');if(md)md.hidden=true;const b=await post('accounts',{}).catch(()=>null);const boot=await fetch(api+'?action=bootstrap',{credentials:'same-origin',cache:'no-store'}).then(x=>x.json());if(boot.ok){accounts=boot.accounts||[];const na=accounts.find(x=>x.id===a.id);if(na)fill(na);}await test(accounts.find(x=>x.id===a.id)||a);return;}if(Date.now()-started<Number(j.expires_in||900)*1000)setTimeout(poll,r.slow_down?delay+5000:delay);}catch(e){status(e.message,true);}};setTimeout(poll,delay);return;}const gw=window.open(oauth+'?start='+encodeURIComponent(a.id),'DMDMailOAuth','width=720,height=760,resizable=yes,scrollbars=yes');if(!gw)status('Fenêtre OAuth bloquée par le navigateur.',true)}catch(err){if(w&&!w.closed)w.close();status(err.message,true)}};
 $('[data-ms-help]').onclick=()=>openMs('m365'); $('[data-ms-help-inline]').onclick=()=>openMs('m365'); const hp=$('[data-ms-help-personal]');if(hp)hp.onclick=()=>openMs('outlook'); $('[data-ms-close]').onclick=closeMs; $('[data-ms-overlay]').onclick=e=>{if(e.target===$('[data-ms-overlay]'))closeMs()}; $$('[data-ms-tab]').forEach(b=>b.onclick=()=>{$$('[data-ms-panel]').forEach(x=>x.hidden=x.dataset.msPanel!==b.dataset.msTab)}); $('[data-ms-save]').onclick=async()=>{const v=$('[data-ms-client-id]').value.trim();msStatus('Enregistrement…');try{const j=await post('save_microsoft_config',{client_id:v});msConfigured=!!j.configured;$('[data-ms-modal-state]').textContent=msConfigured?'✓ configuré':'non configuré';const st=$('[data-ms-config-state]');if(st)st.textContent=msConfigured?'prête':'à faire une seule fois';const stp=$('[data-ms-config-state-personal]');if(stp)stp.textContent=msConfigured?'prête':'à faire une seule fois';msStatus('Configuration Microsoft enregistrée. Vous pouvez maintenant connecter le compte.');}catch(err){msStatus(err.message,true)}};
 window.addEventListener('message',ev=>{if(ev.origin!==location.origin||!ev.data||ev.data.type!=='dmd-mail-oauth')return;status(ev.data.message||'OAuth terminé.',!ev.data.ok);fetch(api+'?action=bootstrap',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(j=>{if(j.ok){accounts=j.accounts||[];const a=current?accounts.find(x=>x.id===current.id):null;if(a)fill(a);else renderList();}})});
 const forceNew=new URLSearchParams(location.search).get('mode')==='new'; reset(); if(!forceNew&&accounts.length)fill(accounts[0]);
})();
</script>
<?php if ($standalone) { ?></body></html><?php } ?>
