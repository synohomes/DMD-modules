<?php
if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
if (!function_exists('dmd_mail_root')) {
    function dmd_mail_root(): string {
        $r = realpath(__DIR__ . '/../..');
        return $r ?: dirname(__DIR__, 2);
    }
}
if (!function_exists('dmd_mail_boot_core')) {
    function dmd_mail_boot_core(): void {
        $root = dmd_mail_root();
        foreach (array(
            $root . '/core/dmd_permissions.php',
            $root . '/core/dmd_activity.php',
            $root . '/core/dmd_module_logs.php',
            $root . '/core/dmd_module_events.php'
        ) as $file) {
            if (is_file($file)) require_once $file;
        }
    }
}
if (!function_exists('dmd_mail_user_email')) {
    function dmd_mail_user_email(): string {
        return trim((string)($_SESSION['user']['email'] ?? $_SESSION['email'] ?? $_SESSION['user_email'] ?? ''));
    }
}

if (!function_exists('dmd_mail_require_user')) {
    function dmd_mail_require_user(): string {
        $email = dmd_mail_user_email();
        if ($email === '') {
            http_response_code(401);
            throw new RuntimeException('Connexion requise.');
        }
        return $email;
    }
}
if (!function_exists('dmd_mail_has_permission')) {
    function dmd_mail_has_permission(string $permission, ?string $email = null): bool {
        $email = trim((string)($email ?: dmd_mail_user_email()));
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return false;
        dmd_mail_boot_core();
        if (!function_exists('dmd_user_has_module_permission')) return false;
        try { return (bool)dmd_user_has_module_permission($email, 'DMD-Mail', $permission); }
        catch (Throwable $e) { return false; }
    }
}
if (!function_exists('dmd_mail_has_any_permission')) {
    function dmd_mail_has_any_permission(array $permissions, ?string $email = null): bool {
        foreach ($permissions as $permission) {
            if (dmd_mail_has_permission((string)$permission, $email)) return true;
        }
        return false;
    }
}
if (!function_exists('dmd_mail_require_permission')) {
    function dmd_mail_require_permission($permissions, ?string $email = null): string {
        $email = trim((string)($email ?: dmd_mail_require_user()));
        $permissions = is_array($permissions) ? $permissions : array((string)$permissions);
        if (!dmd_mail_has_any_permission($permissions, $email)) {
            http_response_code(403);
            throw new RuntimeException('Accès refusé : droit DMD-Mail insuffisant.');
        }
        return $email;
    }
}
if (!function_exists('dmd_mail_permissions_snapshot')) {
    function dmd_mail_permissions_snapshot(?string $email = null): array {
        $email = trim((string)($email ?: dmd_mail_user_email()));
        $ids = array(
            'module.view','mail.read','mail.search','mail.attachments','mail.send','mail.mark','mail.delete','mail.move','mail.folders','mail.signature','mail.modify',
            'config.view','accounts.create','accounts.edit','accounts.delete','accounts.test','accounts.connect','config.edit'
        );
        $out = array();
        foreach ($ids as $id) $out[$id] = dmd_mail_has_permission($id, $email);
        return $out;
    }
}
if (!function_exists('dmd_mail_safe_user_key')) {
    function dmd_mail_safe_user_key(string $email): string {
        return preg_replace('/[^a-zA-Z0-9_@.\-]+/', '_', $email) ?: '_user';
    }
}
if (!function_exists('dmd_mail_user_dir')) {
    function dmd_mail_user_dir(?string $email = null): string {
        $email = $email ?: dmd_mail_require_user();
        $dir = dmd_mail_root() . '/users/profiles/' . dmd_mail_safe_user_key($email) . '/dmd-mail';
        if (!is_dir($dir)) { @mkdir($dir, 0770, true); }
        return $dir;
    }
}
if (!function_exists('dmd_mail_json_read')) {
    function dmd_mail_json_read(string $file, $fallback = array()) {
        if (!is_file($file)) return $fallback;
        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') return $fallback;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $fallback;
    }
}
if (!function_exists('dmd_mail_json_write')) {
    function dmd_mail_json_write(string $file, $data): bool {
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0770, true);
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | (defined('JSON_INVALID_UTF8_SUBSTITUTE') ? JSON_INVALID_UTF8_SUBSTITUTE : 0));
        if ($json === false) return false;
        $tmp = $file . '.tmp.' . bin2hex(random_bytes(4));
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        @chmod($tmp, 0600);
        if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
        @chmod($file, 0600);
        return true;
    }
}
if (!function_exists('dmd_mail_key')) {
    function dmd_mail_key(?string $email = null): string {
        $dir = dmd_mail_user_dir($email);
        $file = $dir . '/secret.key';
        if (!is_file($file)) {
            $key = random_bytes(32);
            @file_put_contents($file, base64_encode($key), LOCK_EX);
            @chmod($file, 0600);
            return $key;
        }
        $raw = base64_decode(trim((string)@file_get_contents($file)), true);
        if (!is_string($raw) || strlen($raw) !== 32) {
            throw new RuntimeException('Clé de chiffrement DMD-Mail invalide.');
        }
        return $raw;
    }
}
if (!function_exists('dmd_mail_encrypt')) {
    function dmd_mail_encrypt(string $plain, ?string $email = null): array {
        if ($plain === '') return array();
        if (!function_exists('openssl_encrypt')) throw new RuntimeException('Extension OpenSSL PHP requise.');
        $iv = random_bytes(12); $tag = '';
        $cipher = openssl_encrypt($plain, 'aes-256-gcm', dmd_mail_key($email), OPENSSL_RAW_DATA, $iv, $tag, 'DMD-Mail');
        if ($cipher === false) throw new RuntimeException('Chiffrement impossible.');
        return array('v'=>1,'iv'=>base64_encode($iv),'tag'=>base64_encode($tag),'data'=>base64_encode($cipher));
    }
}
if (!function_exists('dmd_mail_decrypt')) {
    function dmd_mail_decrypt($enc, ?string $email = null): string {
        if (!is_array($enc) || empty($enc['iv']) || empty($enc['tag']) || empty($enc['data'])) return '';
        $iv = base64_decode((string)$enc['iv'], true);
        $tag = base64_decode((string)$enc['tag'], true);
        $data = base64_decode((string)$enc['data'], true);
        if ($iv === false || $tag === false || $data === false) return '';
        $plain = openssl_decrypt($data, 'aes-256-gcm', dmd_mail_key($email), OPENSSL_RAW_DATA, $iv, $tag, 'DMD-Mail');
        return is_string($plain) ? $plain : '';
    }
}
if (!function_exists('dmd_mail_accounts_file')) {
    function dmd_mail_accounts_file(?string $email = null): string { return dmd_mail_user_dir($email) . '/accounts.json'; }
}
if (!function_exists('dmd_mail_tokens_file')) {
    function dmd_mail_tokens_file(?string $email = null): string { return dmd_mail_user_dir($email) . '/tokens.json'; }
}
if (!function_exists('dmd_mail_global_data_dir')) {
    function dmd_mail_global_data_dir(): string {
        $dir = dmd_mail_root() . '/data/dmd-mail';
        if (!is_dir($dir)) { @mkdir($dir, 0770, true); }
        return $dir;
    }
}
if (!function_exists('dmd_mail_microsoft_builtin_file')) {
    function dmd_mail_microsoft_builtin_file(): string { return __DIR__ . '/dmd-mail-microsoft-app.php'; }
}
if (!function_exists('dmd_mail_microsoft_user_file')) {
    function dmd_mail_microsoft_user_file(?string $email = null): string { return dmd_mail_user_dir($email) . '/microsoft-oauth.json'; }
}
if (!function_exists('dmd_mail_valid_client_id')) {
    function dmd_mail_valid_client_id(string $v): bool {
        return (bool)preg_match('/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/', trim($v));
    }
}
if (!function_exists('dmd_mail_microsoft_config')) {
    function dmd_mail_microsoft_config(?string $email = null): array {
        // Priorité : configuration de l'utilisateur, puis identité éventuellement livrée avec le module.
        $client = '';
        $user = dmd_mail_json_read(dmd_mail_microsoft_user_file($email), array());
        if (is_array($user)) $client = trim((string)($user['client_id'] ?? ''));
        if ($client === '') {
            $file = dmd_mail_microsoft_builtin_file();
            if (is_file($file)) {
                $cfg = require $file;
                if (is_array($cfg)) $client = trim((string)($cfg['client_id'] ?? ''));
            }
        }
        if ($client === '' && defined('DMD_MAIL_MICROSOFT_CLIENT_ID')) $client = trim((string)DMD_MAIL_MICROSOFT_CLIENT_ID);
        if ($client === '') $client = trim((string)getenv('DMD_MAIL_MICROSOFT_CLIENT_ID'));
        return array('client_id'=>dmd_mail_valid_client_id($client) ? $client : '', 'configured'=>dmd_mail_valid_client_id($client));
    }
}
if (!function_exists('dmd_mail_save_microsoft_config')) {
    function dmd_mail_save_microsoft_config(string $clientId, ?string $email = null): array {
        $clientId = trim($clientId);
        if (!dmd_mail_valid_client_id($clientId)) throw new RuntimeException('ID d’application Microsoft invalide. Il doit être au format xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx.');
        if (!dmd_mail_json_write(dmd_mail_microsoft_user_file($email), array('client_id'=>$clientId,'updated_at'=>date(DATE_ATOM)))) {
            throw new RuntimeException('Impossible d’enregistrer la configuration Microsoft.');
        }
        return array('client_id'=>$clientId,'configured'=>true);
    }
}
if (!function_exists('dmd_mail_microsoft_client_id')) {
    function dmd_mail_microsoft_client_id(): string {
        $cfg = dmd_mail_microsoft_config();
        $client = trim((string)($cfg['client_id'] ?? ''));
        if (!dmd_mail_valid_client_id($client)) {
            throw new RuntimeException('Microsoft n’est pas encore configuré. Ouvrez la procédure Microsoft dans Comptes et enregistrez l’ID d’application une seule fois.');
        }
        return $client;
    }
}
if (!function_exists('dmd_mail_standard_presets')) {
    function dmd_mail_standard_presets(): array {
        return array(
            'ovh'        => array('label'=>'OVHcloud / MX Plan','imap_host'=>'ssl0.ovh.net','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'ssl0.ovh.net','smtp_port'=>465,'smtp_security'=>'ssl'),
            'orange'     => array('label'=>'Orange / Wanadoo','imap_host'=>'imap.orange.fr','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.orange.fr','smtp_port'=>465,'smtp_security'=>'ssl'),
            'free'       => array('label'=>'Free','imap_host'=>'imap.free.fr','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.free.fr','smtp_port'=>465,'smtp_security'=>'ssl'),
            'sfr'        => array('label'=>'SFR / Neuf','imap_host'=>'imap.sfr.fr','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.sfr.fr','smtp_port'=>465,'smtp_security'=>'ssl'),
            'laposte'    => array('label'=>'LaPoste.net','imap_host'=>'imap.laposte.net','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.laposte.net','smtp_port'=>465,'smtp_security'=>'ssl'),
            'yahoo'      => array('label'=>'Yahoo Mail','imap_host'=>'imap.mail.yahoo.com','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.mail.yahoo.com','smtp_port'=>465,'smtp_security'=>'ssl'),
            'icloud'     => array('label'=>'Apple iCloud Mail','imap_host'=>'imap.mail.me.com','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.mail.me.com','smtp_port'=>587,'smtp_security'=>'tls'),
            'infomaniak' => array('label'=>'Infomaniak Mail','imap_host'=>'mail.infomaniak.com','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'mail.infomaniak.com','smtp_port'=>465,'smtp_security'=>'ssl'),
            'gandi'      => array('label'=>'Gandi Mail','imap_host'=>'mail.gandi.net','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'mail.gandi.net','smtp_port'=>465,'smtp_security'=>'ssl'),
            'ionos'      => array('label'=>'IONOS','imap_host'=>'imap.ionos.fr','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.ionos.fr','smtp_port'=>465,'smtp_security'=>'ssl'),
            'gmx'        => array('label'=>'GMX','imap_host'=>'imap.gmx.com','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'mail.gmx.com','smtp_port'=>465,'smtp_security'=>'ssl'),
            'fastmail'   => array('label'=>'Fastmail','imap_host'=>'imap.fastmail.com','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.fastmail.com','smtp_port'=>465,'smtp_security'=>'ssl'),
            'zoho_eu'    => array('label'=>'Zoho Mail Europe','imap_host'=>'imap.zoho.eu','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.zoho.eu','smtp_port'=>465,'smtp_security'=>'ssl'),
            'zoho_com'   => array('label'=>'Zoho Mail International','imap_host'=>'imap.zoho.com','imap_port'=>993,'imap_security'=>'ssl','smtp_host'=>'smtp.zoho.com','smtp_port'=>465,'smtp_security'=>'ssl')
        );
    }
}

if (!function_exists('dmd_mail_account_preset')) {
    function dmd_mail_account_preset(array $a): string {
        $preset = strtolower(trim((string)($a['preset'] ?? '')));
        if ($preset === 'outlook_password') return 'microsoft'; // migration des builds qui tentaient encore l'authentification basique Outlook
        if (in_array($preset, array_merge(array('gmail_app','custom','google_oauth','microsoft','microsoft_personal','proton_bridge'), array_keys(dmd_mail_standard_presets())), true)) return $preset;
        $provider = strtolower((string)($a['provider'] ?? 'imap'));
        if ($provider === 'google') return 'google_oauth';
        if ($provider === 'microsoft') return 'microsoft';
        $ih = strtolower((string)($a['imap_host'] ?? ''));
        $sh = strtolower((string)($a['smtp_host'] ?? ''));
        if ($ih === 'imap.gmail.com' || $sh === 'smtp.gmail.com') return 'gmail_app';
        if ($ih === 'ssl0.ovh.net' || $sh === 'ssl0.ovh.net') return 'ovh';
        if ($ih === 'outlook.office365.com' || $sh === 'smtp-mail.outlook.com') return 'microsoft';
        foreach (dmd_mail_standard_presets() as $key => $cfg) {
            if ($ih === strtolower((string)$cfg['imap_host']) && $sh === strtolower((string)$cfg['smtp_host'])) return $key;
        }
        if (($a['preset'] ?? '') === 'proton_bridge') return 'proton_bridge';
        return 'custom';
    }
}
if (!function_exists('dmd_mail_accounts')) {
    function dmd_mail_accounts(?string $email = null): array {
        $data = dmd_mail_json_read(dmd_mail_accounts_file($email), array());
        $accounts = isset($data['accounts']) && is_array($data['accounts']) ? $data['accounts'] : array();
        $changed = false;
        foreach ($accounts as $i => $a) {
            if (!is_array($a)) continue;
            if (($a['provider'] ?? '') === 'google' && empty($a['client_secret_enc'])) {
                $address = strtolower(trim((string)($a['email'] ?? '')));
                $domain = (string)substr(strrchr($address, '@') ?: '', 1);
                $isConsumerGmail = in_array($domain, array('gmail.com','googlemail.com'), true);
                $candidate = preg_replace('/\s+/', '', (string)($a['client_id'] ?? ''));
                if ($isConsumerGmail && preg_match('/^[A-Za-z0-9]{16}$/', $candidate)) {
                    $a['provider'] = 'imap';
                    $a['preset'] = 'gmail_app';
                    $a['imap_host'] = 'imap.gmail.com';
                    $a['imap_port'] = 993;
                    $a['imap_security'] = 'ssl';
                    $a['smtp_host'] = 'smtp.gmail.com';
                    $a['smtp_port'] = 465;
                    $a['smtp_security'] = 'ssl';
                    $a['username'] = (string)($a['email'] ?? '');
                    $a['smtp_username'] = (string)($a['email'] ?? '');
                    $a['password_enc'] = dmd_mail_encrypt($candidate, $email);
                    unset($a['client_id'], $a['client_secret_enc'], $a['tenant']);
                    $a['updated_at'] = date(DATE_ATOM);
                    $accounts[$i] = $a;
                    $changed = true;
                }
            }
            $legacyPreset = strtolower(trim((string)($a['preset'] ?? '')));
            $ih = strtolower(trim((string)($a['imap_host'] ?? '')));
            $sh = strtolower(trim((string)($a['smtp_host'] ?? '')));
            $legacyOutlook = $legacyPreset === 'outlook_password'
                || (($a['provider'] ?? '') === 'imap' && ($ih === 'outlook.office365.com' || $sh === 'smtp-mail.outlook.com'));
            if ($legacyOutlook) {
                $a['provider'] = 'microsoft';
                $a['preset'] = 'microsoft';
                foreach (array('password_enc','smtp_password_enc','imap_host','imap_port','imap_security','smtp_host','smtp_port','smtp_security','username','smtp_username','client_id','client_secret_enc','tenant') as $k) unset($a[$k]);
                $a['updated_at'] = date(DATE_ATOM);
                $accounts[$i] = $a;
                $changed = true;
            }
        }
        if ($changed) dmd_mail_save_accounts($accounts, $email);
        return $accounts;
    }
}
if (!function_exists('dmd_mail_save_accounts')) {
    function dmd_mail_save_accounts(array $accounts, ?string $email = null): bool {
        return dmd_mail_json_write(dmd_mail_accounts_file($email), array('schema'=>1,'accounts'=>$accounts));
    }
}
if (!function_exists('dmd_mail_account')) {
    function dmd_mail_account(string $id, ?string $email = null): ?array {
        foreach (dmd_mail_accounts($email) as $a) if (is_array($a) && hash_equals((string)($a['id'] ?? ''), $id)) return $a;
        return null;
    }
}
if (!function_exists('dmd_mail_public_account')) {
    function dmd_mail_public_account(array $a): array {
        $out = $a;
        foreach (array('password_enc','smtp_password_enc','client_secret_enc') as $k) unset($out[$k]);
        if (($a['provider'] ?? '') === 'microsoft') { unset($out['client_id'], $out['tenant']); }
        $out['preset'] = dmd_mail_account_preset($a);
        $out['password_saved'] = !empty($a['password_enc']);
        $out['smtp_password_saved'] = !empty($a['smtp_password_enc']);
        $out['client_secret_saved'] = !empty($a['client_secret_enc']);
        $token = dmd_mail_token((string)($a['id'] ?? ''));
        $out['oauth_connected'] = (is_array($token) && !empty($token['refresh_token_enc'])) || (is_array($token) && !empty($token['access_token_enc']));
        return $out;
    }
}
if (!function_exists('dmd_mail_csrf')) {
    function dmd_mail_csrf(): string {
        if (empty($_SESSION['dmd_mail_csrf'])) $_SESSION['dmd_mail_csrf'] = bin2hex(random_bytes(32));
        return (string)$_SESSION['dmd_mail_csrf'];
    }
}
if (!function_exists('dmd_mail_check_csrf')) {
    function dmd_mail_check_csrf(?string $token): bool {
        return is_string($token) && $token !== '' && hash_equals(dmd_mail_csrf(), $token);
    }
}

if (!function_exists('dmd_mail_web_base')) {
    function dmd_mail_web_base(): string {
        $doc = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
        $dir = realpath(__DIR__) ?: __DIR__;
        if ($doc !== '' && strpos($dir, $doc) === 0) return '/' . ltrim(str_replace('\\','/',substr($dir, strlen($doc))), '/') . '/';
        return '/domydesk/modules/DMD-Mail/';
    }
}
if (!function_exists('dmd_mail_absolute_url')) {
    function dmd_mail_absolute_url(string $path): string {
        $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || ((string)($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
        $scheme = $https ? 'https' : 'http';
        $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost');
        return $scheme . '://' . $host . '/' . ltrim($path, '/');
    }
}
if (!function_exists('dmd_mail_oauth_redirect_uri')) {
    function dmd_mail_oauth_redirect_uri(): string { return dmd_mail_absolute_url(dmd_mail_web_base() . 'dmd-mail-oauth.php?callback=1'); }
}

if (!function_exists('dmd_mail_http')) {
    function dmd_mail_http(string $method, string $url, array $headers = array(), $body = null): array {
        if (!function_exists('curl_init')) throw new RuntimeException('Extension cURL PHP requise.');
        $ch = curl_init($url);
        curl_setopt_array($ch, array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>20,CURLOPT_CUSTOMREQUEST=>strtoupper($method),CURLOPT_HTTPHEADER=>$headers));
        if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        $raw = curl_exec($ch); $err = curl_error($ch); $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); $ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE); curl_close($ch);
        if ($raw === false) throw new RuntimeException('Erreur réseau : ' . $err);
        return array('status'=>$status,'body'=>$raw,'content_type'=>$ctype);
    }
}
if (!function_exists('dmd_mail_http_json')) {
    function dmd_mail_http_json(string $method, string $url, array $headers = array(), $body = null): array {
        $r = dmd_mail_http($method,$url,$headers,$body);
        $json = json_decode((string)$r['body'], true);
        if ($r['status'] < 200 || $r['status'] >= 300) {
            $msg = is_array($json) ? (string)($json['error']['message'] ?? $json['error_description'] ?? $json['error'] ?? '') : '';
            throw new RuntimeException($msg !== '' ? $msg : ('HTTP ' . $r['status']));
        }
        return is_array($json) ? $json : array();
    }
}
if (!function_exists('dmd_mail_token')) {
    function dmd_mail_token(string $accountId, ?string $email = null): ?array {
        $tokens = dmd_mail_json_read(dmd_mail_tokens_file($email), array());
        $t = $tokens[$accountId] ?? null;
        return is_array($t) ? $t : null;
    }
}
if (!function_exists('dmd_mail_clear_token')) {
    function dmd_mail_clear_token(string $accountId, ?string $email = null): bool {
        $tokens = dmd_mail_json_read(dmd_mail_tokens_file($email), array());
        if (!array_key_exists($accountId, $tokens)) return true;
        unset($tokens[$accountId]);
        return dmd_mail_json_write(dmd_mail_tokens_file($email), $tokens);
    }
}
if (!function_exists('dmd_mail_save_token')) {
    function dmd_mail_save_token(string $accountId, array $token, ?string $email = null): bool {
        $tokens = dmd_mail_json_read(dmd_mail_tokens_file($email), array());
        $old = isset($tokens[$accountId]) && is_array($tokens[$accountId]) ? $tokens[$accountId] : array();
        if (!empty($token['access_token'])) $old['access_token_enc'] = dmd_mail_encrypt((string)$token['access_token'], $email);
        if (!empty($token['refresh_token'])) $old['refresh_token_enc'] = dmd_mail_encrypt((string)$token['refresh_token'], $email);
        $old['expires_at'] = time() + max(60, ((int)($token['expires_in'] ?? 3600)) - 60);
        $old['token_type'] = (string)($token['token_type'] ?? 'Bearer');
        $old['scope'] = (string)($token['scope'] ?? ($old['scope'] ?? ''));
        $tokens[$accountId] = $old;
        return dmd_mail_json_write(dmd_mail_tokens_file($email), $tokens);
    }
}
if (!function_exists('dmd_mail_oauth_scope')) {
    function dmd_mail_oauth_scope(array $a): string {
        return ($a['provider'] ?? '') === 'google'
            ? 'openid email profile https://www.googleapis.com/auth/gmail.modify https://www.googleapis.com/auth/gmail.send'
            : 'offline_access User.Read Mail.ReadWrite Mail.Send';
    }
}
if (!function_exists('dmd_mail_oauth_authorize_url')) {
    function dmd_mail_oauth_authorize_url(array $a, string $state): string {
        $provider = (string)($a['provider'] ?? '');
        $clientId = $provider === 'microsoft' ? dmd_mail_microsoft_client_id() : trim((string)($a['client_id'] ?? ''));
        if ($clientId === '') throw new RuntimeException('Client ID OAuth manquant.');
        $params = array('client_id'=>$clientId,'response_type'=>'code','redirect_uri'=>dmd_mail_oauth_redirect_uri(),'scope'=>dmd_mail_oauth_scope($a),'state'=>$state);
        if ($provider === 'google') {
            $params['access_type'] = 'offline'; $params['prompt'] = 'consent'; $params['include_granted_scopes'] = 'true';
            return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
        }
        $tenant = dmd_mail_microsoft_tenant($a);
        $params['response_mode'] = 'query';
        return 'https://login.microsoftonline.com/' . rawurlencode($tenant) . '/oauth2/v2.0/authorize?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }
}
if (!function_exists('dmd_mail_oauth_exchange')) {
    function dmd_mail_oauth_exchange(array $a, string $code): array {
        $provider = (string)($a['provider'] ?? '');
        $secret = dmd_mail_decrypt($a['client_secret_enc'] ?? array());
        if ($provider === 'google' && $secret === '') throw new RuntimeException('Client secret OAuth manquant.');
        $params = array('client_id'=>$provider === 'microsoft' ? dmd_mail_microsoft_client_id() : (string)($a['client_id'] ?? ''),'code'=>$code,'redirect_uri'=>dmd_mail_oauth_redirect_uri(),'grant_type'=>'authorization_code');
        if ($provider === 'google') {
            $params['client_secret'] = $secret;
            $r = dmd_mail_http_json('POST','https://oauth2.googleapis.com/token',array('Content-Type: application/x-www-form-urlencoded'),http_build_query($params));
        } else {
            $tenant = dmd_mail_microsoft_tenant($a);
            $params['scope'] = dmd_mail_oauth_scope($a);
            $r = dmd_mail_http_json('POST','https://login.microsoftonline.com/' . rawurlencode($tenant) . '/oauth2/v2.0/token',array('Content-Type: application/x-www-form-urlencoded'),http_build_query($params));
        }
        dmd_mail_save_token((string)$a['id'], $r);
        return $r;
    }
}
if (!function_exists('dmd_mail_access_token')) {
    function dmd_mail_access_token(array $a): string {
        $t = dmd_mail_token((string)$a['id']);
        if (!$t) throw new RuntimeException('Compte OAuth non connecté.');
        $access = dmd_mail_decrypt($t['access_token_enc'] ?? array());
        if ($access !== '' && (int)($t['expires_at'] ?? 0) > time()+30) return $access;
        $refresh = dmd_mail_decrypt($t['refresh_token_enc'] ?? array());
        if ($refresh === '') throw new RuntimeException('Session OAuth expirée : reconnectez le compte.');
        $provider = (string)($a['provider'] ?? '');
        $secret = dmd_mail_decrypt($a['client_secret_enc'] ?? array());
        $params = array('client_id'=>$provider === 'microsoft' ? dmd_mail_microsoft_client_id() : (string)($a['client_id'] ?? ''),'refresh_token'=>$refresh,'grant_type'=>'refresh_token');
        if ($provider === 'google') {
            if ($secret === '') throw new RuntimeException('Client secret OAuth manquant.');
            $params['client_secret'] = $secret;
            $r = dmd_mail_http_json('POST','https://oauth2.googleapis.com/token',array('Content-Type: application/x-www-form-urlencoded'),http_build_query($params));
        } else {
            $tenant = dmd_mail_microsoft_tenant($a);
            $params['scope'] = dmd_mail_oauth_scope($a);
            $r = dmd_mail_http_json('POST','https://login.microsoftonline.com/' . rawurlencode($tenant) . '/oauth2/v2.0/token',array('Content-Type: application/x-www-form-urlencoded'),http_build_query($params));
        }
        if (empty($r['refresh_token'])) $r['refresh_token'] = $refresh;
        dmd_mail_save_token((string)$a['id'], $r);
        return (string)($r['access_token'] ?? '');
    }
}
if (!function_exists('dmd_mail_microsoft_tenant')) {
    function dmd_mail_microsoft_tenant(array $a): string {
        // Mode explicite ajouté sans supprimer le mode Microsoft 365/tenant existant.
        // microsoft_personal force l'autorité grand public Microsoft, même pour un alias
        // ou une adresse personnalisée rattachée à Microsoft 365 Personnel/Famille.
        $preset = strtolower(trim((string)($a['preset'] ?? '')));
        if ($preset === 'microsoft_personal') return 'consumers';

        // Le mode microsoft historique reste inchangé : compte professionnel/tenant.
        // Pour compatibilité avec les comptes déjà créés avant l'ajout du mode explicite,
        // les domaines personnels connus continuent d'être reconnus automatiquement.
        $email = strtolower(trim((string)($a['email'] ?? '')));
        $domain = '';
        $at = strrpos($email, '@');
        if ($at !== false) $domain = substr($email, $at + 1);
        $personal = array(
            'outlook.com','outlook.fr','hotmail.com','hotmail.fr','live.com','live.fr',
            'msn.com','windowslive.com'
        );
        return in_array($domain, $personal, true) ? 'consumers' : 'common';
    }
}
if (!function_exists('dmd_mail_ms_device_start')) {
    function dmd_mail_ms_device_start(array $a): array {
        if (($a['provider'] ?? '') !== 'microsoft') throw new RuntimeException('Compte Microsoft requis.');
        $client=dmd_mail_microsoft_client_id();
        $tenant=dmd_mail_microsoft_tenant($a);
        $r=dmd_mail_http_json('POST','https://login.microsoftonline.com/'.rawurlencode($tenant).'/oauth2/v2.0/devicecode',array('Content-Type: application/x-www-form-urlencoded'),http_build_query(array('client_id'=>$client,'scope'=>dmd_mail_oauth_scope($a))));
        if (empty($r['device_code']) || empty($r['user_code'])) throw new RuntimeException('Microsoft n’a pas fourni de code de connexion.');
        if (!isset($_SESSION['dmd_mail_ms_device']) || !is_array($_SESSION['dmd_mail_ms_device'])) $_SESSION['dmd_mail_ms_device']=array();
        $_SESSION['dmd_mail_ms_device'][(string)$a['id']]=array('device_code_enc'=>dmd_mail_encrypt((string)$r['device_code']),'expires_at'=>time()+max(60,(int)($r['expires_in']??900)),'interval'=>max(3,(int)($r['interval']??5)));
        return array('user_code'=>(string)$r['user_code'],'verification_uri'=>(string)($r['verification_uri']??$r['verification_url']??'https://microsoft.com/devicelogin'),'message'=>(string)($r['message']??''),'interval'=>max(3,(int)($r['interval']??5)),'expires_in'=>max(60,(int)($r['expires_in']??900)));
    }
}
if (!function_exists('dmd_mail_ms_device_poll')) {
    function dmd_mail_ms_device_poll(array $a): array {
        $id=(string)($a['id']??''); $st=$_SESSION['dmd_mail_ms_device'][$id]??null;
        if (!is_array($st)) throw new RuntimeException('Connexion Microsoft non démarrée.');
        if ((int)($st['expires_at']??0)<time()) { unset($_SESSION['dmd_mail_ms_device'][$id]); throw new RuntimeException('Code Microsoft expiré. Recommencez la connexion.'); }
        $device=dmd_mail_decrypt($st['device_code_enc']??array()); if ($device==='') throw new RuntimeException('Code Microsoft invalide.');
        $tenant=dmd_mail_microsoft_tenant($a);
        $r=dmd_mail_http('POST','https://login.microsoftonline.com/'.rawurlencode($tenant).'/oauth2/v2.0/token',array('Content-Type: application/x-www-form-urlencoded'),http_build_query(array('grant_type'=>'urn:ietf:params:oauth:grant-type:device_code','client_id'=>dmd_mail_microsoft_client_id(),'device_code'=>$device)));
        $j=json_decode((string)$r['body'],true); $j=is_array($j)?$j:array();
        if ($r['status']>=200 && $r['status']<300 && !empty($j['access_token'])) { dmd_mail_save_token($id,$j); unset($_SESSION['dmd_mail_ms_device'][$id]); return array('connected'=>true); }
        $err=(string)($j['error']??''); if ($err==='authorization_pending' || $err==='slow_down') return array('connected'=>false,'pending'=>true,'slow_down'=>$err==='slow_down');
        $msg=(string)($j['error_description']??$j['error']??('HTTP '.$r['status'])); throw new RuntimeException($msg);
    }
}
if (!function_exists('dmd_mail_b64url_decode')) {
    function dmd_mail_b64url_decode(string $v): string {
        $v = strtr($v, '-_', '+/'); $v .= str_repeat('=', (4 - strlen($v)%4)%4);
        $r = base64_decode($v, true); return $r === false ? '' : $r;
    }
}
if (!function_exists('dmd_mail_b64url_encode')) {
    function dmd_mail_b64url_encode(string $v): string { return rtrim(strtr(base64_encode($v), '+/', '-_'), '='); }
}

if (!function_exists('dmd_mail_header_map')) {
    function dmd_mail_header_map(array $headers): array {
        $m = array(); foreach ($headers as $h) if (is_array($h) && isset($h['name'])) $m[strtolower((string)$h['name'])] = (string)($h['value'] ?? ''); return $m;
    }
}
if (!function_exists('dmd_mail_gmail_parts')) {
    function dmd_mail_gmail_parts(array $part, array &$attachments, string &$html, string &$text): void {
        $mime = strtolower((string)($part['mimeType'] ?? ''));
        $filename = (string)($part['filename'] ?? '');
        $body = isset($part['body']) && is_array($part['body']) ? $part['body'] : array();
        if ($filename !== '' && !empty($body['attachmentId'])) $attachments[] = array('id'=>(string)$body['attachmentId'],'name'=>$filename,'mime'=>$mime,'size'=>(int)($body['size'] ?? 0));
        if ($filename === '' && !empty($body['data'])) {
            $decoded = dmd_mail_b64url_decode((string)$body['data']);
            if ($mime === 'text/html' && $html === '') $html = $decoded;
            elseif ($mime === 'text/plain' && $text === '') $text = $decoded;
        }
        foreach ((array)($part['parts'] ?? array()) as $p) if (is_array($p)) dmd_mail_gmail_parts($p,$attachments,$html,$text);
    }
}
if (!function_exists('dmd_mail_gmail_folders')) {
    function dmd_mail_gmail_folders(array $a): array {
        $token = dmd_mail_access_token($a);
        $j = dmd_mail_http_json('GET','https://gmail.googleapis.com/gmail/v1/users/me/labels',array('Authorization: Bearer '.$token));
        $out = array(); foreach ((array)($j['labels'] ?? array()) as $l) {
            if (!is_array($l)) continue;
            $id=(string)($l['id']??''); $name=(string)($l['name']??$id);
            $show = !in_array($id,array('CHAT','CATEGORY_FORUMS','CATEGORY_PROMOTIONS','CATEGORY_SOCIAL','CATEGORY_UPDATES','CATEGORY_PERSONAL'),true);
            if ($show) $out[] = array('id'=>$id,'name'=>$name,'unread'=>null,'total'=>null);
        }
        return $out;
    }
}
if (!function_exists('dmd_mail_gmail_list')) {
    function dmd_mail_gmail_list(array $a, string $folder='INBOX', string $q='', int $limit=40): array {
        $token=dmd_mail_access_token($a); $params=array('maxResults'=>max(1,min(80,$limit)),'labelIds'=>$folder?:'INBOX'); if($q!=='')$params['q']=$q;
        $j=dmd_mail_http_json('GET','https://gmail.googleapis.com/gmail/v1/users/me/messages?'.http_build_query($params),array('Authorization: Bearer '.$token));
        $out=array();
        foreach((array)($j['messages']??array()) as $m){
            $id=(string)($m['id']??''); if($id==='')continue;
            $u='https://gmail.googleapis.com/gmail/v1/users/me/messages/'.rawurlencode($id).'?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Date';
            $d=dmd_mail_http_json('GET',$u,array('Authorization: Bearer '.$token)); $h=dmd_mail_header_map((array)($d['payload']['headers']??array()));
            $out[]=array('id'=>$id,'subject'=>$h['subject']??'(Sans objet)','from'=>$h['from']??'','to'=>$h['to']??'','date'=>$h['date']??'','timestamp'=>(int)floor(((int)($d['internalDate']??0))/1000),'unread'=>in_array('UNREAD',(array)($d['labelIds']??array()),true),'has_attachments'=>false,'preview'=>(string)($d['snippet']??''));
        }
        usort($out,fn($x,$y)=>($y['timestamp']??0)<=>($x['timestamp']??0)); return $out;
    }
}
if (!function_exists('dmd_mail_gmail_message')) {
    function dmd_mail_gmail_message(array $a,string $id): array {
        $token=dmd_mail_access_token($a); $d=dmd_mail_http_json('GET','https://gmail.googleapis.com/gmail/v1/users/me/messages/'.rawurlencode($id).'?format=full',array('Authorization: Bearer '.$token));
        $h=dmd_mail_header_map((array)($d['payload']['headers']??array())); $atts=array();$html='';$text=''; dmd_mail_gmail_parts((array)($d['payload']??array()),$atts,$html,$text);
        return array('id'=>$id,'subject'=>$h['subject']??'(Sans objet)','from'=>$h['from']??'','to'=>$h['to']??'','cc'=>$h['cc']??'','date'=>$h['date']??'','unread'=>in_array('UNREAD',(array)($d['labelIds']??array()),true),'html'=>$html,'text'=>$text,'attachments'=>$atts);
    }
}
if (!function_exists('dmd_mail_gmail_mark_read')) {
    function dmd_mail_gmail_mark_read(array $a,string $id,bool $read): void {
        $token=dmd_mail_access_token($a); $body=json_encode($read?array('removeLabelIds'=>array('UNREAD')):array('addLabelIds'=>array('UNREAD')));
        dmd_mail_http_json('POST','https://gmail.googleapis.com/gmail/v1/users/me/messages/'.rawurlencode($id).'/modify',array('Authorization: Bearer '.$token,'Content-Type: application/json'),$body);
    }
}
if (!function_exists('dmd_mail_gmail_delete')) {
    function dmd_mail_gmail_delete(array $a,string $id): void { $token=dmd_mail_access_token($a); dmd_mail_http_json('POST','https://gmail.googleapis.com/gmail/v1/users/me/messages/'.rawurlencode($id).'/trash',array('Authorization: Bearer '.$token,'Content-Type: application/json'),'{}'); }
}
if (!function_exists('dmd_mail_gmail_attachment')) {
    function dmd_mail_gmail_attachment(array $a,string $messageId,string $attachmentId): string { $token=dmd_mail_access_token($a);$j=dmd_mail_http_json('GET','https://gmail.googleapis.com/gmail/v1/users/me/messages/'.rawurlencode($messageId).'/attachments/'.rawurlencode($attachmentId),array('Authorization: Bearer '.$token));return dmd_mail_b64url_decode((string)($j['data']??'')); }
}

if (!function_exists('dmd_mail_graph_headers')) {
    function dmd_mail_graph_headers(array $a): array { return array('Authorization: Bearer '.dmd_mail_access_token($a),'Content-Type: application/json'); }
}
if (!function_exists('dmd_mail_graph_folders')) {
    function dmd_mail_graph_folders(array $a): array {
        $j=dmd_mail_http_json('GET','https://graph.microsoft.com/v1.0/me/mailFolders?$top=100&$select=id,displayName,unreadItemCount,totalItemCount,parentFolderId',dmd_mail_graph_headers($a));
        $out=array();foreach((array)($j['value']??array()) as $f)if(is_array($f))$out[]=array('id'=>(string)$f['id'],'name'=>(string)$f['displayName'],'unread'=>(int)($f['unreadItemCount']??0),'total'=>(int)($f['totalItemCount']??0));return $out;
    }
}
if (!function_exists('dmd_mail_graph_list')) {
    function dmd_mail_graph_list(array $a,string $folder='',string $q='',int $limit=40):array{
        $path=$folder!==''?'/me/mailFolders/'.rawurlencode($folder).'/messages':'/me/messages';
        $params=array('$top'=>max(1,min(80,$limit)),'$select'=>'id,subject,from,toRecipients,ccRecipients,receivedDateTime,isRead,hasAttachments,bodyPreview','$orderby'=>'receivedDateTime desc');
        $j=dmd_mail_http_json('GET','https://graph.microsoft.com/v1.0'.$path.'?'.http_build_query($params,'','&',PHP_QUERY_RFC3986),dmd_mail_graph_headers($a));$out=array();
        foreach((array)($j['value']??array()) as $m){if(!is_array($m))continue;$from=(string)($m['from']['emailAddress']['name']??'');$addr=(string)($m['from']['emailAddress']['address']??'');$from=trim($from.($addr!==''?' <'.$addr.'>':''));$item=array('id'=>(string)$m['id'],'subject'=>(string)($m['subject']??'(Sans objet)'),'from'=>$from,'date'=>(string)($m['receivedDateTime']??''),'timestamp'=>strtotime((string)($m['receivedDateTime']??''))?:0,'unread'=>empty($m['isRead']),'has_attachments'=>!empty($m['hasAttachments']),'preview'=>(string)($m['bodyPreview']??''));if($q!==''&&stripos($item['subject'].' '.$item['from'].' '.$item['preview'],$q)===false)continue;$out[]=$item;}return $out;
    }
}
if (!function_exists('dmd_mail_graph_message')) {
    function dmd_mail_graph_message(array $a,string $id):array{
        $sel='id,subject,from,toRecipients,ccRecipients,receivedDateTime,isRead,hasAttachments,body';$m=dmd_mail_http_json('GET','https://graph.microsoft.com/v1.0/me/messages/'.rawurlencode($id).'?'.http_build_query(array('$select'=>$sel)),dmd_mail_graph_headers($a));
        $fmt=function($r){$o=array();foreach((array)$r as $x){$n=(string)($x['emailAddress']['name']??'');$e=(string)($x['emailAddress']['address']??'');$o[]=trim($n.($e!==''?' <'.$e.'>':''));}return implode(', ',$o);};
        $from=$fmt(isset($m['from'])?array($m['from']):array());$atts=array();if(!empty($m['hasAttachments'])){$aj=dmd_mail_http_json('GET','https://graph.microsoft.com/v1.0/me/messages/'.rawurlencode($id).'/attachments?$top=50',dmd_mail_graph_headers($a));foreach((array)($aj['value']??array())as$x)if(is_array($x)&&($x['@odata.type']??'')==='#microsoft.graph.fileAttachment')$atts[]=array('id'=>(string)$x['id'],'name'=>(string)($x['name']??'piece-jointe'),'mime'=>(string)($x['contentType']??'application/octet-stream'),'size'=>(int)($x['size']??0));}
        $content=(string)($m['body']['content']??'');$type=strtolower((string)($m['body']['contentType']??'text'));return array('id'=>$id,'subject'=>(string)($m['subject']??'(Sans objet)'),'from'=>$from,'to'=>$fmt($m['toRecipients']??array()),'cc'=>$fmt($m['ccRecipients']??array()),'date'=>(string)($m['receivedDateTime']??''),'unread'=>empty($m['isRead']),'html'=>$type==='html'?$content:'','text'=>$type==='html'?'':$content,'attachments'=>$atts);
    }
}
if (!function_exists('dmd_mail_graph_mark_read')) { function dmd_mail_graph_mark_read(array $a,string $id,bool $read):void{dmd_mail_http_json('PATCH','https://graph.microsoft.com/v1.0/me/messages/'.rawurlencode($id),dmd_mail_graph_headers($a),json_encode(array('isRead'=>$read)));} }
if (!function_exists('dmd_mail_graph_delete')) { function dmd_mail_graph_delete(array $a,string $id):void{ $r=dmd_mail_http('DELETE','https://graph.microsoft.com/v1.0/me/messages/'.rawurlencode($id),array('Authorization: Bearer '.dmd_mail_access_token($a)));if($r['status']<200||$r['status']>=300)throw new RuntimeException('Suppression Microsoft refusée (HTTP '.$r['status'].').');} }
if (!function_exists('dmd_mail_graph_attachment')) {
    function dmd_mail_graph_attachment(array $a,string $messageId,string $attachmentId):array{$j=dmd_mail_http_json('GET','https://graph.microsoft.com/v1.0/me/messages/'.rawurlencode($messageId).'/attachments/'.rawurlencode($attachmentId),dmd_mail_graph_headers($a));return array('data'=>base64_decode((string)($j['contentBytes']??''),true)?:'','name'=>(string)($j['name']??'piece-jointe'),'mime'=>(string)($j['contentType']??'application/octet-stream'));}
}
if (!function_exists('dmd_mail_tls_context')) {
    function dmd_mail_tls_context(string $host, bool $allowSelfSigned = false) {
        return stream_context_create(array('ssl'=>array(
            'peer_name'=>$host,
            'SNI_enabled'=>true,
            'verify_peer'=>!$allowSelfSigned,
            'verify_peer_name'=>!$allowSelfSigned,
            'allow_self_signed'=>$allowSelfSigned,
            'disable_compression'=>true,
        )));
    }
}
if (!function_exists('dmd_mail_raw_imap_quote')) {
    function dmd_mail_raw_imap_quote(string $v): string { return '"'.str_replace(array('\\','"'),array('\\\\','\\"'),$v).'"'; }
}
if (!function_exists('dmd_mail_raw_imap_read')) {
    function dmd_mail_raw_imap_read($fp, ?string $tag = null): string {
        $out='';
        while (!feof($fp)) {
            $line=fgets($fp, 16384);
            if ($line===false) break;
            $out.=$line;
            if (preg_match('/\{(\d+)\}\r?\n$/', $line, $m)) {
                $need=(int)$m[1]; $buf='';
                while (strlen($buf)<$need && !feof($fp)) {
                    $chunk=fread($fp, $need-strlen($buf));
                    if ($chunk===false || $chunk==='') break;
                    $buf.=$chunk;
                }
                $out.=$buf;
            }
            if ($tag!==null && preg_match('/^'.preg_quote($tag,'/').'\s+(OK|NO|BAD)\b/i', $line, $m)) {
                if (strtoupper($m[1])!=='OK') {
                    $msg=trim(preg_replace('/^'.preg_quote($tag,'/').'\s+(?:NO|BAD)\s*/i','',$line));
                    throw new RuntimeException('IMAP : '.($msg!==''?$msg:'commande refusée'));
                }
                return $out;
            }
        }
        if ($tag!==null) throw new RuntimeException('Connexion IMAP interrompue.');
        return $out;
    }
}
if (!function_exists('dmd_mail_raw_imap_cmd')) {
    function dmd_mail_raw_imap_cmd(array &$c, string $cmd): string {
        $tag='DMD'.str_pad((string)$c['n']++,4,'0',STR_PAD_LEFT);
        if (@fwrite($c['fp'], $tag.' '.$cmd."\r\n")===false) throw new RuntimeException('Écriture IMAP impossible.');
        return dmd_mail_raw_imap_read($c['fp'],$tag);
    }
}
if (!function_exists('dmd_mail_raw_imap_pipeline')) {
    function dmd_mail_raw_imap_pipeline(array &$c, array $commands): string {
        if (!$commands) return '';
        $tags=array(); $wire='';
        foreach ($commands as $cmd) {
            $tag='DMD'.str_pad((string)$c['n']++,4,'0',STR_PAD_LEFT);
            $tags[$tag]=false;
            $wire.=$tag.' '.(string)$cmd."\r\n";
        }
        $len=strlen($wire); $off=0;
        while ($off<$len) {
            $n=@fwrite($c['fp'],substr($wire,$off));
            if ($n===false || $n===0) throw new RuntimeException('Écriture IMAP impossible.');
            $off+=$n;
        }
        $out=''; $remaining=count($tags);
        while ($remaining>0 && !feof($c['fp'])) {
            $line=fgets($c['fp'],16384);
            if ($line===false) break;
            $out.=$line;
            if (preg_match('/^(DMD\d+)\s+(OK|NO|BAD)\b/i',$line,$m) && array_key_exists($m[1],$tags) && !$tags[$m[1]]) {
                $tags[$m[1]]=true; $remaining--;
                if (strtoupper($m[2])!=='OK') {
                    $msg=trim(preg_replace('/^'.preg_quote($m[1],'/').'\s+(?:NO|BAD)\s*/i','',$line));
                    throw new RuntimeException('IMAP : '.($msg!==''?$msg:'commande refusée'));
                }
            }
        }
        if ($remaining>0) throw new RuntimeException('Connexion IMAP interrompue.');
        return $out;
    }
}
if (!function_exists('dmd_mail_raw_imap_connect')) {
    function dmd_mail_raw_imap_connect(array $a): array {
        $host=trim((string)($a['imap_host']??''));
        $port=(int)($a['imap_port']??993);
        $sec=strtolower((string)($a['imap_security']??'ssl'));
        if ($host==='') throw new RuntimeException('Serveur IMAP manquant.');
        $isProtonBridge=(($a['preset']??'')==='proton_bridge');
        $ctx=dmd_mail_tls_context($host,$isProtonBridge);
        $target=($sec==='ssl'?'tls://':'tcp://').$host.':'.$port;
        $fp=@stream_socket_client($target,$errno,$errstr,8,STREAM_CLIENT_CONNECT,$ctx);
        if (!$fp) throw new RuntimeException('Connexion IMAP impossible : '.($errstr?:('erreur '.$errno)));
        stream_set_timeout($fp,15);
        $hello=fgets($fp,16384); $hello=is_string($hello)?$hello:'';
        if ($hello==='' || !preg_match('/^\*\s+(OK|PREAUTH)\b/im',$hello,$m)) { @fclose($fp); throw new RuntimeException('Réponse IMAP invalide.'); }
        $c=array('fp'=>$fp,'n'=>1);
        if ($sec==='tls') {
            dmd_mail_raw_imap_cmd($c,'STARTTLS');
            if (!@stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)) { @fclose($fp); throw new RuntimeException('Échec STARTTLS IMAP.'); }
        }
        if (strtoupper($m[1])!=='PREAUTH') {
            $user=(string)($a['username']??$a['email']??'');
            $pass=dmd_mail_decrypt($a['password_enc']??array());
            if ($user==='' || $pass==='') { @fclose($fp); throw new RuntimeException('Identifiants IMAP manquants.'); }
            dmd_mail_raw_imap_cmd($c,'LOGIN '.dmd_mail_raw_imap_quote($user).' '.dmd_mail_raw_imap_quote($pass));
        }
        return $c;
    }
}
if (!function_exists('dmd_mail_raw_imap_close')) {
    function dmd_mail_raw_imap_close(array &$c): void { if (!empty($c['fp']) && is_resource($c['fp'])) { try { dmd_mail_raw_imap_cmd($c,'LOGOUT'); } catch (Throwable $e) {} @fclose($c['fp']); } }
}
if (!function_exists('dmd_mail_raw_imap_literals')) {
    function dmd_mail_raw_imap_literals(string $resp): array {
        $out=array(); $pos=0; $len=strlen($resp);
        while ($pos<$len && preg_match('/\{(\d+)\}\r\n/', $resp, $m, PREG_OFFSET_CAPTURE, $pos)) {
            $n=(int)$m[1][0]; $start=$m[0][1]+strlen($m[0][0]);
            $out[]=substr($resp,$start,$n); $pos=$start+$n;
        }
        return $out;
    }
}
if (!function_exists('dmd_mail_raw_decode_header')) {
    function dmd_mail_raw_decode_header(string $v): string {
        $v=trim($v);
        if ($v==='') return '';
        if (function_exists('iconv_mime_decode')) { $x=@iconv_mime_decode($v,ICONV_MIME_DECODE_CONTINUE_ON_ERROR,'UTF-8'); if (is_string($x) && $x!=='') return $x; }
        if (function_exists('mb_decode_mimeheader')) { $x=@mb_decode_mimeheader($v); if (is_string($x) && $x!=='') return $x; }
        return $v;
    }
}
if (!function_exists('dmd_mail_raw_headers')) {
    function dmd_mail_raw_headers(string $raw): array {
        $raw=str_replace("\r\n","\n",$raw); $lines=explode("\n",$raw); $unfold=array();
        foreach ($lines as $line) { if ($line!=='' && ($line[0]===' ' || $line[0]==="\t") && $unfold) $unfold[count($unfold)-1].=' '.trim($line); else $unfold[]=$line; }
        $h=array();
        foreach ($unfold as $line) { $p=strpos($line,':'); if ($p===false) continue; $k=strtolower(trim(substr($line,0,$p))); $v=trim(substr($line,$p+1)); if ($k==='') continue; if (isset($h[$k])) $h[$k].=', '.$v; else $h[$k]=$v; }
        return $h;
    }
}
if (!function_exists('dmd_mail_raw_param')) {
    function dmd_mail_raw_param(string $header, string $name): string {
        $name=preg_quote($name,'/');
        if (preg_match('/(?:^|;)\s*'.$name.'\*?\s*=\s*(?:"([^"]*)"|([^;\r\n]*))/i',$header,$m)) {
            $v=isset($m[1]) && $m[1]!=='' ? stripcslashes($m[1]) : trim((string)($m[2]??''));
            if (strpos($v,"''")!==false) { $v=substr($v,strpos($v,"''")+2); $v=rawurldecode($v); }
            return dmd_mail_raw_decode_header($v);
        }
        return '';
    }
}
if (!function_exists('dmd_mail_raw_mailbox_decode')) {
    function dmd_mail_raw_mailbox_decode(string $v): string {
        $decoded = preg_replace_callback('/&([A-Za-z0-9+,]*)-/', function($m) {
            if ($m[1] === '') return '&';
            $b64 = strtr($m[1], ',', '/');
            $b64 .= str_repeat('=', (4 - strlen($b64) % 4) % 4);
            $raw = base64_decode($b64, true);
            if ($raw === false) return $m[0];
            if (function_exists('iconv')) {
                $x = @iconv('UTF-16BE', 'UTF-8//IGNORE', $raw);
                if (is_string($x)) return $x;
            }
            if (function_exists('mb_convert_encoding')) {
                $x = @mb_convert_encoding($raw, 'UTF-8', 'UTF-16BE');
                if (is_string($x)) return $x;
            }
            return $m[0];
        }, $v);
        return is_string($decoded) ? $decoded : $v;
    }
}
if (!function_exists('dmd_mail_raw_mailbox_token')) {
    function dmd_mail_raw_mailbox_token(string $v): string {
        $v=trim($v);
        if (strlen($v)>=2 && $v[0]==='"' && substr($v,-1)==='"') return stripcslashes(substr($v,1,-1));
        return $v;
    }
}
if (!function_exists('dmd_mail_raw_imap_select')) {
    function dmd_mail_raw_imap_select(array &$c,string $folder,bool $write=false):string { if (preg_match('/[\r\n]/',$folder)) throw new RuntimeException('Dossier IMAP invalide.'); return dmd_mail_raw_imap_cmd($c,($write?'SELECT ':'EXAMINE ').dmd_mail_raw_imap_quote($folder)); }
}
if (!function_exists('dmd_mail_imap_folders')) {
    function dmd_mail_imap_folders(array $a): array {
        $c=dmd_mail_raw_imap_connect($a); $out=array();
        try {
            $r=dmd_mail_raw_imap_cmd($c,'LIST "" "*"');
            $ids=array();
            foreach (preg_split('/\r\n/',$r) as $line) {
                if (!preg_match('/^\*\s+LIST\s+\((.*?)\)\s+(?:"[^"]*"|NIL)\s+(.+)$/i',$line,$m)) continue;
                $flags=strtoupper($m[1]); if (strpos($flags,'\\NOSELECT')!==false) continue;
                $id=dmd_mail_raw_mailbox_token(trim($m[2])); if ($id==='') continue;
                $ids[]=$id;
                $out[$id]=array('id'=>$id,'name'=>dmd_mail_raw_mailbox_decode($id),'unread'=>null,'total'=>null);
            }
            // Avant : 1 STATUS = 1 aller/retour réseau par dossier. Avec 20 à 60 dossiers,
            // c'était l'un des principaux bouchons. On pipeline tous les STATUS en une fois.
            if ($ids) {
                $cmds=array(); foreach ($ids as $id) $cmds[]='STATUS '.dmd_mail_raw_imap_quote($id).' (MESSAGES UNSEEN)';
                try {
                    $st=dmd_mail_raw_imap_pipeline($c,$cmds);
                    foreach (preg_split('/\r\n/',$st) as $line) {
                        if (!preg_match('/^\*\s+STATUS\s+("(?:\\.|[^"])*"|[^\s]+)\s+\((.*?)\)\s*$/i',$line,$sm)) continue;
                        $id=dmd_mail_raw_mailbox_token($sm[1]); if (!isset($out[$id])) continue;
                        $attrs=$sm[2];
                        if (preg_match('/(?:^|\s)MESSAGES\s+(\d+)/i',$attrs,$mm)) $out[$id]['total']=(int)$mm[1];
                        if (preg_match('/(?:^|\s)UNSEEN\s+(\d+)/i',$attrs,$um)) $out[$id]['unread']=(int)$um[1];
                    }
                } catch (Throwable $e) {
                    // Un serveur IMAP exotique peut refuser le pipelining. Les dossiers
                    // restent utilisables ; seuls les compteurs seront inconnus.
                }
            }
        } finally { dmd_mail_raw_imap_close($c); }
        $out=array_values($out);
        usort($out,function($x,$y){ if (strcasecmp($x['id'],'INBOX')===0) return -1; if (strcasecmp($y['id'],'INBOX')===0) return 1; return strcasecmp($x['name'],$y['name']); });
        return $out;
    }
}
if (!function_exists('dmd_mail_imap_list')) {
    function dmd_mail_imap_list(array $a,string $folder='INBOX',string $q='',int $limit=40): array {
        $c=dmd_mail_raw_imap_connect($a); $out=array();
        try {
            dmd_mail_raw_imap_select($c,$folder,false);
            $sr=dmd_mail_raw_imap_cmd($c,'UID SEARCH ALL'); $uids=array();
            foreach (preg_split('/\r\n/',$sr) as $line) if (preg_match('/^\*\s+SEARCH\s*(.*)$/i',$line,$m)) { foreach (preg_split('/\s+/',trim($m[1])) as $u) if (ctype_digit($u)) $uids[]=(int)$u; }
            rsort($uids,SORT_NUMERIC);
            $want=max(1,min(100,$limit));
            // On prend un peu de marge lorsqu'une recherche locale est demandée.
            $uids=array_slice($uids,0,$q!==''?min(150,max($want*2,60)):$want);
            if ($uids) {
                // Avant : jusqu'à 75 UID FETCH séparés = jusqu'à 75 allers/retours réseau.
                // Un seul FETCH de jeu d'UID renvoie tous les en-têtes demandés.
                $set=implode(',',array_map('intval',$uids));
                $fr=dmd_mail_raw_imap_cmd($c,'UID FETCH '.$set.' (UID FLAGS INTERNALDATE RFC822.SIZE BODY.PEEK[HEADER.FIELDS (SUBJECT FROM TO CC DATE)])');
                $parts=preg_split('/(?=^\*\s+\d+\s+FETCH\s+\()/mi',$fr,-1,PREG_SPLIT_NO_EMPTY);
                foreach ($parts as $part) {
                    if (!preg_match('/^\*\s+\d+\s+FETCH\s+\(/i',$part)) continue;
                    if (!preg_match('/\bUID\s+(\d+)/i',$part,$um)) continue;
                    $uid=(int)$um[1];
                    $lits=dmd_mail_raw_imap_literals($part); $h=dmd_mail_raw_headers($lits[0]??'');
                    $subject=dmd_mail_raw_decode_header((string)($h['subject']??'(Sans objet)')); $from=dmd_mail_raw_decode_header((string)($h['from']??''));
                    if ($q!=='' && stripos($subject.' '.$from,$q)===false) continue;
                    $flags=''; if (preg_match('/FLAGS\s+\(([^)]*)\)/i',$part,$fm)) $flags=$fm[1];
                    $date=(string)($h['date']??''); $ts=strtotime($date)?:0;
                    if (!$ts && preg_match('/INTERNALDATE\s+"([^"]+)"/i',$part,$dm)) $ts=strtotime($dm[1])?:0;
                    $out[]=array('id'=>(string)$uid,'subject'=>$subject,'from'=>$from,'date'=>$date,'timestamp'=>$ts,'unread'=>stripos($flags,'\\Seen')===false,'has_attachments'=>false,'preview'=>'');
                    if (count($out)>=$want) break;
                }
                usort($out,fn($x,$y)=>(int)$y['id']<=>(int)$x['id']);
            }
        } finally { dmd_mail_raw_imap_close($c); }
        return $out;
    }
}
if (!function_exists('dmd_mail_raw_split_entity')) {
    function dmd_mail_raw_split_entity(string $raw): array { $p=strpos($raw,"\r\n\r\n"); $d=4; if ($p===false) { $p=strpos($raw,"\n\n"); $d=2; } return $p===false?array($raw,''):array(substr($raw,0,$p),substr($raw,$p+$d)); }
}
if (!function_exists('dmd_mail_raw_decode_body')) {
    function dmd_mail_raw_decode_body(string $body,string $cte,string $charset=''): string {
        $cte=strtolower(trim($cte)); if ($cte==='base64') { $x=base64_decode(preg_replace('/\s+/','',$body),true); if ($x!==false) $body=$x; } elseif ($cte==='quoted-printable') $body=quoted_printable_decode($body);
        $charset=trim($charset," \t\r\n\"'"); if ($charset!=='' && strcasecmp($charset,'UTF-8')!==0 && function_exists('iconv')) { $x=@iconv($charset,'UTF-8//IGNORE',$body); if ($x!==false) $body=$x; }
        return $body;
    }
}
if (!function_exists('dmd_mail_raw_mime_walk')) {
    function dmd_mail_raw_mime_walk(string $raw,string $path,array &$atts,string &$html,string &$text,bool $withData=false): void {
        list($hr,$body)=dmd_mail_raw_split_entity($raw); $h=dmd_mail_raw_headers($hr);
        $ct=(string)($h['content-type']??'text/plain'); $mime=strtolower(trim(explode(';',$ct,2)[0])); $boundary=dmd_mail_raw_param($ct,'boundary');
        $disp=(string)($h['content-disposition']??''); $filename=dmd_mail_raw_param($disp,'filename'); if ($filename==='') $filename=dmd_mail_raw_param($ct,'name');
        if (strpos($mime,'multipart/')===0 && $boundary!=='') {
            $chunks=explode('--'.$boundary,$body); $idx=0;
            foreach (array_slice($chunks,1) as $chunk) { $t=ltrim($chunk,"\r\n"); if (substr($t,0,2)==='--') break; $chunk=preg_replace('/^\r?\n/','',$chunk,1); $chunk=preg_replace('/\r?\n$/','',$chunk,1); if (trim((string)$chunk)==='') continue; $idx++; dmd_mail_raw_mime_walk((string)$chunk,$path===''?(string)$idx:$path.'.'.$idx,$atts,$html,$text,$withData); }
            return;
        }
        $decoded=dmd_mail_raw_decode_body($body,(string)($h['content-transfer-encoding']??''),dmd_mail_raw_param($ct,'charset'));
        $isAtt=$filename!=='' || stripos($disp,'attachment')!==false;
        if ($isAtt) { $item=array('id'=>$path===''?'1':$path,'name'=>$filename!==''?$filename:'piece-jointe','mime'=>$mime!==''?$mime:'application/octet-stream','size'=>strlen($decoded)); if ($withData) $item['data']=$decoded; $atts[]=$item; return; }
        if ($mime==='text/html' && $html==='') $html=$decoded; elseif ($mime==='text/plain' && $text==='') $text=$decoded; elseif ($mime==='message/rfc822') dmd_mail_raw_mime_walk($decoded,$path===''?'1':$path.'.1',$atts,$html,$text,$withData);
    }
}
if (!function_exists('dmd_mail_raw_imap_fetch_raw')) {
    function dmd_mail_raw_imap_fetch_raw(array &$c,string $folder,string $uid,bool $write=false): array {
        if (!ctype_digit($uid)) throw new RuntimeException('Message IMAP invalide.'); dmd_mail_raw_imap_select($c,$folder,$write);
        $r=dmd_mail_raw_imap_cmd($c,'UID FETCH '.(int)$uid.' (FLAGS BODY.PEEK[])'); $l=dmd_mail_raw_imap_literals($r); if (!$l) throw new RuntimeException('Message introuvable.');
        usort($l,fn($x,$y)=>strlen($y)<=>strlen($x)); $flags=''; if (preg_match('/FLAGS\s+\(([^)]*)\)/i',$r,$m)) $flags=$m[1]; return array('raw'=>$l[0],'flags'=>$flags);
    }
}
if (!function_exists('dmd_mail_imap_message')) {
    function dmd_mail_imap_message(array $a,string $folder,string $id): array {
        $c=dmd_mail_raw_imap_connect($a);
        try { $f=dmd_mail_raw_imap_fetch_raw($c,$folder,$id,false); } finally { dmd_mail_raw_imap_close($c); }
        list($hr,$body)=dmd_mail_raw_split_entity($f['raw']); $h=dmd_mail_raw_headers($hr); $atts=array(); $html=''; $text=''; dmd_mail_raw_mime_walk($f['raw'],'',$atts,$html,$text,false);
        return array('id'=>$id,'subject'=>dmd_mail_raw_decode_header((string)($h['subject']??'(Sans objet)')),'from'=>dmd_mail_raw_decode_header((string)($h['from']??'')),'to'=>dmd_mail_raw_decode_header((string)($h['to']??'')),'cc'=>dmd_mail_raw_decode_header((string)($h['cc']??'')),'date'=>(string)($h['date']??''),'unread'=>stripos((string)$f['flags'],'\\Seen')===false,'html'=>$html,'text'=>$text,'attachments'=>$atts);
    }
}
if (!function_exists('dmd_mail_imap_mark_read')) {
    function dmd_mail_imap_mark_read(array $a,string $folder,string $id,bool $read): void { if (!ctype_digit($id)) throw new RuntimeException('Message IMAP invalide.'); $c=dmd_mail_raw_imap_connect($a); try { dmd_mail_raw_imap_select($c,$folder,true); dmd_mail_raw_imap_cmd($c,'UID STORE '.(int)$id.' '.($read?'+FLAGS.SILENT':'-FLAGS.SILENT').' (\\Seen)'); } finally { dmd_mail_raw_imap_close($c); } }
}
if (!function_exists('dmd_mail_imap_delete')) {
    function dmd_mail_imap_delete(array $a,string $folder,string $id): void { if (!ctype_digit($id)) throw new RuntimeException('Message IMAP invalide.'); $c=dmd_mail_raw_imap_connect($a); try { dmd_mail_raw_imap_select($c,$folder,true); dmd_mail_raw_imap_cmd($c,'UID STORE '.(int)$id.' +FLAGS.SILENT (\\Deleted)'); dmd_mail_raw_imap_cmd($c,'EXPUNGE'); } finally { dmd_mail_raw_imap_close($c); } }
}
if (!function_exists('dmd_mail_imap_attachment')) {
    function dmd_mail_imap_attachment(array $a,string $folder,string $messageId,string $partNo): array { $c=dmd_mail_raw_imap_connect($a); try { $f=dmd_mail_raw_imap_fetch_raw($c,$folder,$messageId,false); } finally { dmd_mail_raw_imap_close($c); } $atts=array();$html='';$text='';dmd_mail_raw_mime_walk($f['raw'],'',$atts,$html,$text,true); foreach ($atts as $x) if ((string)$x['id']===$partNo) return array('data'=>(string)($x['data']??''),'name'=>(string)$x['name'],'mime'=>(string)$x['mime']); throw new RuntimeException('Pièce jointe introuvable.'); }
}
if (!function_exists('dmd_mail_send_imap')) {
    function dmd_mail_send_imap(array $a,array $to,array $cc,array $bcc,string $subject,string $body,array $files): void {
        $host=trim((string)($a['smtp_host']??'')); $port=(int)($a['smtp_port']??465); $sec=strtolower((string)($a['smtp_security']??'ssl')); if ($host==='') throw new RuntimeException('Serveur SMTP manquant.');
        $isProtonBridge=(($a['preset']??'')==='proton_bridge'); $ctx=dmd_mail_tls_context($host,$isProtonBridge); $target=($sec==='ssl'?'tls://':'tcp://').$host.':'.$port; $fp=@stream_socket_client($target,$errno,$errstr,8,STREAM_CLIENT_CONNECT,$ctx); if(!$fp) throw new RuntimeException('Connexion SMTP impossible : '.($errstr?:('erreur '.$errno))); stream_set_timeout($fp,15);
        dmd_mail_smtp_expect($fp,array(220)); dmd_mail_smtp_cmd($fp,'EHLO domydesk',array(250)); if($sec==='tls'){ dmd_mail_smtp_cmd($fp,'STARTTLS',array(220)); if(!@stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('Échec STARTTLS SMTP.'); dmd_mail_smtp_cmd($fp,'EHLO domydesk',array(250)); }
        $user=(string)($a['smtp_username']??$a['username']??$a['email']??''); $pass=dmd_mail_decrypt(!empty($a['smtp_password_enc'])?$a['smtp_password_enc']:($a['password_enc']??array())); if($user!==''){ dmd_mail_smtp_cmd($fp,'AUTH LOGIN',array(334)); dmd_mail_smtp_cmd($fp,base64_encode($user),array(334)); dmd_mail_smtp_cmd($fp,base64_encode($pass),array(235)); }
        $from=(string)($a['email']??$user); dmd_mail_smtp_cmd($fp,'MAIL FROM:<'.$from.'>',array(250)); foreach(array_merge($to,$cc,$bcc) as$rcpt)dmd_mail_smtp_cmd($fp,'RCPT TO:<'.$rcpt.'>',array(250,251)); dmd_mail_smtp_cmd($fp,'DATA',array(354)); $raw=dmd_mail_mime_message($from,$to,$cc,$bcc,$subject,$body,strip_tags($body),$files,false); $raw=preg_replace('/(?m)^\./','..',$raw); fwrite($fp,$raw."\r\n.\r\n"); dmd_mail_smtp_expect($fp,array(250)); try{dmd_mail_smtp_cmd($fp,'QUIT',array(221));}catch(Throwable $e){} fclose($fp);
    }
}

if (!function_exists('dmd_mail_imap_mailbox')) {
    function dmd_mail_imap_mailbox(array $a,string $folder='INBOX'):string{
        $host=trim((string)($a['imap_host']??''));$port=(int)($a['imap_port']??993);$sec=strtolower((string)($a['imap_security']??'ssl'));if($host==='')throw new RuntimeException('Serveur IMAP manquant.');
        if (preg_match('/[{}\r\n]/', $folder)) throw new RuntimeException('Dossier IMAP invalide.');
        $flags='/imap';if($sec==='ssl')$flags.='/ssl';elseif($sec==='tls')$flags.='/tls';elseif($sec==='none')$flags.='/notls';
        return '{'.$host.':'.$port.$flags.'}'.$folder;
    }
}
if (!function_exists('dmd_mail_imap_open')) {
    function dmd_mail_imap_open(array $a,string $folder='INBOX'){
        if(!function_exists('imap_open'))throw new RuntimeException('Extension PHP IMAP requise pour les comptes IMAP/OVH.');$user=(string)($a['username']??$a['email']??'');$pass=dmd_mail_decrypt($a['password_enc']??array());$im=@imap_open(dmd_mail_imap_mailbox($a,$folder),$user,$pass,0,1);if(!$im)throw new RuntimeException('Connexion IMAP impossible : '.(imap_last_error()?:'erreur inconnue'));return $im;
    }
}
if (!function_exists('dmd_mail_imap_decode')) {
    function dmd_mail_imap_decode(string $v):string{ if(function_exists('imap_mime_header_decode')){$parts=@imap_mime_header_decode($v);if(is_array($parts)){$s='';foreach($parts as$p){$t=(string)($p->text??'');$cs=strtoupper((string)($p->charset??''));if($cs!==''&&$cs!=='DEFAULT'&&$cs!=='UTF-8'&&function_exists('iconv')){$x=@iconv($cs,'UTF-8//IGNORE',$t);if($x!==false)$t=$x;}$s.=$t;}return $s;}}return $v; }
}
if (!function_exists('dmd_mail_imap_folders')) {
    function dmd_mail_imap_folders(array $a):array{$im=dmd_mail_imap_open($a,'INBOX');$root=preg_replace('/INBOX$/','',dmd_mail_imap_mailbox($a,'INBOX'));$boxes=@imap_getmailboxes($im,$root,'*');$out=array();if(is_array($boxes)){foreach($boxes as$b){$name=(string)($b->name??'');$folder=strpos($name,$root)===0?substr($name,strlen($root)):$name;if(function_exists('imap_utf7_decode'))$folder=@imap_utf7_decode($folder)?:$folder;$out[]=array('id'=>$folder,'name'=>$folder,'unread'=>null,'total'=>null);}}@imap_close($im);return $out;}
}
if (!function_exists('dmd_mail_imap_list')) {
    function dmd_mail_imap_list(array $a,string $folder='INBOX',string $q='',int $limit=40):array{$im=dmd_mail_imap_open($a,$folder);$n=(int)@imap_num_msg($im);if($n<1){@imap_close($im);return array();}$start=max(1,$n-max(1,min(100,$limit))+1);$ovs=@imap_fetch_overview($im,$start.':'.$n,0);$out=array();foreach((array)$ovs as$o){$subject=dmd_mail_imap_decode((string)($o->subject??'(Sans objet)'));$from=dmd_mail_imap_decode((string)($o->from??''));$preview='';if($q!==''&&stripos($subject.' '.$from,$q)===false)continue;$out[]=array('id'=>(string)($o->msgno??''),'subject'=>$subject,'from'=>$from,'date'=>(string)($o->date??''),'timestamp'=>(int)($o->udate??0),'unread'=>empty($o->seen),'has_attachments'=>false,'preview'=>$preview);}@imap_close($im);usort($out,fn($x,$y)=>($y['timestamp']??0)<=>($x['timestamp']??0));return $out;}
}
if (!function_exists('dmd_mail_imap_params')) {
    function dmd_mail_imap_params($part):array{$p=array();foreach((array)($part->parameters??array()) as$x)$p[strtolower((string)($x->attribute??''))]=(string)($x->value??'');foreach((array)($part->dparameters??array()) as$x)$p[strtolower((string)($x->attribute??''))]=(string)($x->value??'');return $p;}
}
if (!function_exists('dmd_mail_imap_part_data')) {
    function dmd_mail_imap_part_data($im,int $msgno,string $partNo,$part):string{$raw=$partNo===''?@imap_body($im,$msgno,FT_PEEK):@imap_fetchbody($im,$msgno,$partNo,FT_PEEK);$raw=is_string($raw)?$raw:'';$enc=(int)($part->encoding??0);if($enc===3)$raw=base64_decode($raw,true)?:'';elseif($enc===4)$raw=quoted_printable_decode($raw);$params=dmd_mail_imap_params($part);$cs=strtoupper((string)($params['charset']??''));if($cs!==''&&$cs!=='UTF-8'&&function_exists('iconv')){$x=@iconv($cs,'UTF-8//IGNORE',$raw);if($x!==false)$raw=$x;}return $raw;}
}
if (!function_exists('dmd_mail_imap_walk')) {
    function dmd_mail_imap_walk($im,int $msgno,$part,string $no,array &$atts,string &$html,string &$text):void{$params=dmd_mail_imap_params($part);$filename=(string)($params['filename']??$params['name']??'');$type=(int)($part->type??0);$sub=strtolower((string)($part->subtype??''));if($filename!==''){$atts[]=array('id'=>$no,'name'=>dmd_mail_imap_decode($filename),'mime'=>($type===0?'text/':($type===3?'application/':'application/')).$sub,'size'=>(int)($part->bytes??0));}elseif($type===0){$data=dmd_mail_imap_part_data($im,$msgno,$no,$part);if($sub==='html'&&$html==='')$html=$data;elseif($sub==='plain'&&$text==='')$text=$data;}if(!empty($part->parts)&&is_array($part->parts)){foreach($part->parts as$i=>$child)dmd_mail_imap_walk($im,$msgno,$child,$no===''?(string)($i+1):$no.'.'.($i+1),$atts,$html,$text);}}
}
if (!function_exists('dmd_mail_imap_message')) {
    function dmd_mail_imap_message(array $a,string $folder,string $id):array{$msg=(int)$id;if($msg<1)throw new RuntimeException('Message IMAP invalide.');$im=dmd_mail_imap_open($a,$folder);$ov=@imap_fetch_overview($im,(string)$msg,0);$o=is_array($ov)&&isset($ov[0])?$ov[0]:null;if(!$o){@imap_close($im);throw new RuntimeException('Message introuvable.');}$st=@imap_fetchstructure($im,$msg);$atts=array();$html='';$text='';if($st)dmd_mail_imap_walk($im,$msg,$st,'',$atts,$html,$text);@imap_close($im);return array('id'=>(string)$msg,'subject'=>dmd_mail_imap_decode((string)($o->subject??'(Sans objet)')),'from'=>dmd_mail_imap_decode((string)($o->from??'')),'to'=>dmd_mail_imap_decode((string)($o->to??'')),'cc'=>dmd_mail_imap_decode((string)($o->cc??'')),'date'=>(string)($o->date??''),'unread'=>empty($o->seen),'html'=>$html,'text'=>$text,'attachments'=>$atts);}
}
if (!function_exists('dmd_mail_imap_mark_read')) { function dmd_mail_imap_mark_read(array $a,string $folder,string $id,bool $read):void{$im=dmd_mail_imap_open($a,$folder);if($read)@imap_setflag_full($im,(string)(int)$id,'\\Seen');else@imap_clearflag_full($im,(string)(int)$id,'\\Seen');@imap_close($im);} }
if (!function_exists('dmd_mail_imap_delete')) { function dmd_mail_imap_delete(array $a,string $folder,string $id):void{$im=dmd_mail_imap_open($a,$folder);@imap_delete($im,(string)(int)$id);@imap_expunge($im);@imap_close($im);} }
if (!function_exists('dmd_mail_imap_attachment')) {
    function dmd_mail_imap_attachment(array $a,string $folder,string $messageId,string $partNo):array{$im=dmd_mail_imap_open($a,$folder);$st=@imap_fetchstructure($im,(int)$messageId);if(!$st){@imap_close($im);throw new RuntimeException('Pièce jointe introuvable.');}$parts=explode('.',$partNo);$p=$st;foreach($parts as$idx){$i=(int)$idx-1;if(!isset($p->parts[$i])){@imap_close($im);throw new RuntimeException('Pièce jointe introuvable.');}$p=$p->parts[$i];}$params=dmd_mail_imap_params($p);$name=dmd_mail_imap_decode((string)($params['filename']??$params['name']??'piece-jointe'));$data=dmd_mail_imap_part_data($im,(int)$messageId,$partNo,$p);@imap_close($im);return array('data'=>$data,'name'=>$name,'mime'=>'application/octet-stream');}
}

if (!function_exists('dmd_mail_parse_recipients')) {
    function dmd_mail_parse_recipients(string $v):array{$parts=preg_split('/[;,]+/',$v)?:array();$out=array();foreach($parts as$p){$p=trim($p);if($p==='')continue;if(preg_match('/<([^>]+)>/',$p,$m))$p=trim($m[1]);if(filter_var($p,FILTER_VALIDATE_EMAIL)&&!in_array($p,$out,true))$out[]=$p;}return $out;}
}
if (!function_exists('dmd_mail_extract_inline_images')) {
    function dmd_mail_extract_inline_images(string $html,array &$files): string {
        return preg_replace_callback('#src\\s*=\\s*(["\\\'])data:(image/[a-zA-Z0-9.+-]+);base64,([^"\\\']+)\\1#i',function($m)use(&$files){$data=base64_decode($m[3],true);if($data===false||strlen($data)>5*1024*1024)return $m[0];$ext=strtolower(substr(strrchr($m[2],'/')?:'/png',1));if($ext==='jpeg')$ext='jpg';$cid='dmd-inline-'.bin2hex(random_bytes(8));$files[]=array('name'=>$cid.'.'.$ext,'type'=>$m[2],'data'=>$data,'inline'=>true,'cid'=>$cid);return 'src='.$m[1].'cid:'.$cid.$m[1];},$html)??$html;
    }
}
if (!function_exists('dmd_mail_mime_message')) {
    function dmd_mail_mime_message(string $from,array $to,array $cc,array $bcc,string $subject,string $html,string $text,array $files=array(),bool $includeBccHeader=false):string{
        $boundary='=_DMDMAIL_'.bin2hex(random_bytes(12));$headers=array('MIME-Version: 1.0','From: '.$from,'To: '.implode(', ',$to));if($cc)$headers[]='Cc: '.implode(', ',$cc);if($includeBccHeader&&$bcc)$headers[]='Bcc: '.implode(', ',$bcc);$headers[]='Subject: =?UTF-8?B?'.base64_encode($subject).'?=';$headers[]='Date: '.date(DATE_RFC2822);$headers[]='Message-ID: <'.bin2hex(random_bytes(12)).'@dmd-mail>';
        if($files){$headers[]='Content-Type: multipart/mixed; boundary="'.$boundary.'"';$body="--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n".quoted_printable_encode($html!==''?$html:nl2br(htmlspecialchars($text,ENT_QUOTES,'UTF-8')))."\r\n";foreach($files as$f){$name=preg_replace('/[\r\n\"]+/','_',basename((string)$f['name']));$mime=(string)($f['type']?:'application/octet-stream');$disp=!empty($f['inline'])?'inline':'attachment';$cid=!empty($f['cid'])?"Content-ID: <".preg_replace('/[^a-zA-Z0-9_.@-]/','_',(string)$f['cid']).">\r\n":'';$body.="--$boundary\r\nContent-Type: $mime; name=\"$name\"\r\nContent-Disposition: $disp; filename=\"$name\"\r\n".$cid."Content-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode((string)$f['data']))."\r\n";}$body.="--$boundary--\r\n";return implode("\r\n",$headers)."\r\n\r\n".$body;}
        $headers[]='Content-Type: text/html; charset=UTF-8';$headers[]='Content-Transfer-Encoding: quoted-printable';$body=$html!==''?$html:nl2br(htmlspecialchars($text,ENT_QUOTES,'UTF-8'));return implode("\r\n",$headers)."\r\n\r\n".quoted_printable_encode($body);
    }
}
if (!function_exists('dmd_mail_send_google')) {
    function dmd_mail_send_google(array $a,array $to,array $cc,array $bcc,string $subject,string $body,array $files):void{$raw=dmd_mail_mime_message((string)($a['email']??''),$to,$cc,$bcc,$subject,$body,strip_tags($body),$files,true);$token=dmd_mail_access_token($a);dmd_mail_http_json('POST','https://gmail.googleapis.com/gmail/v1/users/me/messages/send',array('Authorization: Bearer '.$token,'Content-Type: application/json'),json_encode(array('raw'=>dmd_mail_b64url_encode($raw))));}
}
if (!function_exists('dmd_mail_send_graph')) {
    function dmd_mail_send_graph(array $a,array $to,array $cc,array $bcc,string $subject,string $body,array $files):void{$r=function(array$xs){return array_map(fn($e)=>array('emailAddress'=>array('address'=>$e)),$xs);};$msg=array('subject'=>$subject,'body'=>array('contentType'=>'HTML','content'=>$body),'toRecipients'=>$r($to),'ccRecipients'=>$r($cc),'bccRecipients'=>$r($bcc));if($files){$msg['attachments']=array();foreach($files as$f){$att=array('@odata.type'=>'#microsoft.graph.fileAttachment','name'=>basename((string)$f['name']),'contentType'=>(string)($f['type']?:'application/octet-stream'),'contentBytes'=>base64_encode((string)$f['data']));if(!empty($f['inline'])){$att['isInline']=true;$att['contentId']=(string)($f['cid']??'');}$msg['attachments'][]=$att;}}dmd_mail_http_json('POST','https://graph.microsoft.com/v1.0/me/sendMail',dmd_mail_graph_headers($a),json_encode(array('message'=>$msg,'saveToSentItems'=>true)));}
}
if (!function_exists('dmd_mail_smtp_read')) {
    function dmd_mail_smtp_read($fp):string{$s='';while(!feof($fp)){ $l=fgets($fp,4096); if($l===false)break;$s.=$l;if(strlen($l)<4||$l[3]===' ')break;}return $s;}
}
if (!function_exists('dmd_mail_smtp_expect')) {
    function dmd_mail_smtp_expect($fp,array $codes):string{$s=dmd_mail_smtp_read($fp);$c=(int)substr($s,0,3);if(!in_array($c,$codes,true))throw new RuntimeException('SMTP : '.trim($s));return $s;}
}
if (!function_exists('dmd_mail_smtp_cmd')) { function dmd_mail_smtp_cmd($fp,string $cmd,array $codes):string{fwrite($fp,$cmd."\r\n");return dmd_mail_smtp_expect($fp,$codes);} }
if (!function_exists('dmd_mail_send_imap')) {
    function dmd_mail_send_imap(array $a,array $to,array $cc,array $bcc,string $subject,string $body,array $files):void{
        $host=trim((string)($a['smtp_host']??''));$port=(int)($a['smtp_port']??465);$sec=strtolower((string)($a['smtp_security']??'ssl'));if($host==='')throw new RuntimeException('Serveur SMTP manquant.');$target=($sec==='ssl'?'ssl://':'tcp://').$host.':'.$port;$fp=@stream_socket_client($target,$errno,$errstr,20,STREAM_CLIENT_CONNECT);if(!$fp)throw new RuntimeException('Connexion SMTP impossible : '.$errstr);stream_set_timeout($fp,15);dmd_mail_smtp_expect($fp,array(220));dmd_mail_smtp_cmd($fp,'EHLO domydesk',array(250));if($sec==='tls'){dmd_mail_smtp_cmd($fp,'STARTTLS',array(220));if(!@stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT))throw new RuntimeException('Échec STARTTLS SMTP.');dmd_mail_smtp_cmd($fp,'EHLO domydesk',array(250));}
        $user=(string)($a['smtp_username']??$a['username']??$a['email']??'');$pass=dmd_mail_decrypt(!empty($a['smtp_password_enc'])?$a['smtp_password_enc']:($a['password_enc']??array()));if($user!==''){dmd_mail_smtp_cmd($fp,'AUTH LOGIN',array(334));dmd_mail_smtp_cmd($fp,base64_encode($user),array(334));dmd_mail_smtp_cmd($fp,base64_encode($pass),array(235));}
        $from=(string)($a['email']??$user);dmd_mail_smtp_cmd($fp,'MAIL FROM:<'.$from.'>',array(250));foreach(array_merge($to,$cc,$bcc) as$rcpt)dmd_mail_smtp_cmd($fp,'RCPT TO:<'.$rcpt.'>',array(250,251));dmd_mail_smtp_cmd($fp,'DATA',array(354));$raw=dmd_mail_mime_message($from,$to,$cc,$bcc,$subject,$body,strip_tags($body),$files,false);$raw=preg_replace('/(?m)^\./','..',$raw);fwrite($fp,$raw."\r\n.\r\n");dmd_mail_smtp_expect($fp,array(250));@dmd_mail_smtp_cmd($fp,'QUIT',array(221));fclose($fp);
    }
}
if (!function_exists('dmd_mail_send')) {
    function dmd_mail_send(array $a,string $toRaw,string $ccRaw,string $bccRaw,string $subject,string $body,array $files=array()):void{$to=dmd_mail_parse_recipients($toRaw);$cc=dmd_mail_parse_recipients($ccRaw);$bcc=dmd_mail_parse_recipients($bccRaw);if(!$to)throw new RuntimeException('Destinataire invalide.');$body=dmd_mail_extract_inline_images($body,$files);$p=(string)($a['provider']??'imap');if($p==='google')dmd_mail_send_google($a,$to,$cc,$bcc,$subject,$body,$files);elseif($p==='microsoft')dmd_mail_send_graph($a,$to,$cc,$bcc,$subject,$body,$files);else dmd_mail_send_imap($a,$to,$cc,$bcc,$subject,$body,$files);}
}
if (!function_exists('dmd_mail_provider_folders')) { function dmd_mail_provider_folders(array $a):array{$p=(string)($a['provider']??'imap');return $p==='google'?dmd_mail_gmail_folders($a):($p==='microsoft'?dmd_mail_graph_folders($a):dmd_mail_imap_folders($a));} }
if (!function_exists('dmd_mail_provider_list')) { function dmd_mail_provider_list(array $a,string $folder,string $q='',int $limit=40):array{$p=(string)($a['provider']??'imap');return $p==='google'?dmd_mail_gmail_list($a,$folder?:'INBOX',$q,$limit):($p==='microsoft'?dmd_mail_graph_list($a,$folder,$q,$limit):dmd_mail_imap_list($a,$folder?:'INBOX',$q,$limit));} }
if (!function_exists('dmd_mail_provider_message')) { function dmd_mail_provider_message(array $a,string $folder,string $id):array{$p=(string)($a['provider']??'imap');return $p==='google'?dmd_mail_gmail_message($a,$id):($p==='microsoft'?dmd_mail_graph_message($a,$id):dmd_mail_imap_message($a,$folder?:'INBOX',$id));} }
if (!function_exists('dmd_mail_provider_mark_read')) { function dmd_mail_provider_mark_read(array $a,string $folder,string $id,bool $read):void{$p=(string)($a['provider']??'imap');if($p==='google')dmd_mail_gmail_mark_read($a,$id,$read);elseif($p==='microsoft')dmd_mail_graph_mark_read($a,$id,$read);else dmd_mail_imap_mark_read($a,$folder?:'INBOX',$id,$read);} }
if (!function_exists('dmd_mail_provider_delete')) { function dmd_mail_provider_delete(array $a,string $folder,string $id):void{$p=(string)($a['provider']??'imap');if($p==='google')dmd_mail_gmail_delete($a,$id);elseif($p==='microsoft')dmd_mail_graph_delete($a,$id);else dmd_mail_imap_delete($a,$folder?:'INBOX',$id);} }
if (!function_exists('dmd_mail_backup_accounts_snapshot')) {
    function dmd_mail_backup_accounts_snapshot(array $accounts, ?string $email = null): void {
        $file = dmd_mail_user_dir($email) . '/accounts.previous.json';
        dmd_mail_json_write($file, array(
            'schema' => 1,
            'saved_at' => date(DATE_ATOM),
            'accounts' => array_values($accounts),
        ));
    }
}
if (!function_exists('dmd_mail_save_account_input')) {
    function dmd_mail_save_account_input(array $in): array {
        $accounts = dmd_mail_accounts();
        $beforeAccounts = $accounts;
        $saveMode = strtolower(trim((string)($in['save_mode'] ?? '')));
        if (!in_array($saveMode, array('create','update'), true)) $saveMode = 'legacy';

        $postedId = trim((string)($in['id'] ?? ''));
        $id = $postedId;
        $existing = null; $idx = -1;

        if ($saveMode === 'create') {
            $id = bin2hex(random_bytes(8));
        } else {
            foreach ($accounts as $i => $x) {
                if (is_array($x) && $id !== '' && hash_equals((string)($x['id'] ?? ''), $id)) {
                    $existing = $x; $idx = $i; break;
                }
            }
            if ($saveMode === 'update' && $existing === null) {
                throw new RuntimeException('Compte à modifier introuvable. Rechargez la fenêtre des comptes.');
            }
            if ($saveMode === 'legacy' && ($id === '' || !preg_match('/^[a-zA-Z0-9_-]{6,64}$/', $id))) {
                $id = bin2hex(random_bytes(8));
            }
        }
        if (!preg_match('/^[a-zA-Z0-9_-]{6,64}$/', $id)) $id = bin2hex(random_bytes(8));
        $preset = strtolower(trim((string)($in['preset'] ?? 'custom')));
        if ($preset === 'outlook_password') $preset = 'microsoft'; // compatibilité avec un ancien formulaire encore en cache
        $validPresets = array_merge(array('gmail_app','custom','google_oauth','microsoft','microsoft_personal','proton_bridge'), array_keys(dmd_mail_standard_presets()));
        if (!in_array($preset, $validPresets, true)) $preset = 'custom';
        $provider = $preset === 'google_oauth' ? 'google' : (in_array($preset,array('microsoft','microsoft_personal'),true) ? 'microsoft' : 'imap');
        $oldPreset = is_array($existing) ? dmd_mail_account_preset($existing) : '';
        $presetChanged = is_array($existing) && $oldPreset !== '' && $oldPreset !== $preset;
        $a = is_array($existing) ? $existing : array();
        if ($presetChanged) {
            foreach (array('password_enc','smtp_password_enc','client_secret_enc','client_id','tenant',
                           'imap_host','imap_port','imap_security','smtp_host','smtp_port','smtp_security',
                           'username','smtp_username') as $k) unset($a[$k]);
            dmd_mail_clear_token($id);
        }
        $a['id'] = $id;
        $a['preset'] = $preset;
        $a['provider'] = $provider;
        $a['name'] = trim((string)($in['name'] ?? ''));
        $a['email'] = trim((string)($in['email'] ?? ''));
        if (!filter_var($a['email'], FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Adresse e-mail invalide.');
        $a['enabled'] = !isset($in['enabled']) || filter_var($in['enabled'], FILTER_VALIDATE_BOOLEAN);
        if ($a['name'] === '') $a['name'] = $a['email'];
        if ($saveMode === 'create') {
            foreach ($accounts as $x) {
                if (!is_array($x)) continue;
                if (strcasecmp(trim((string)($x['email'] ?? '')), $a['email']) === 0) {
                    throw new RuntimeException('Cette adresse est déjà configurée. Sélectionnez-la dans la liste pour la modifier.');
                }
            }
        }
        if ($provider === 'imap') {
            if ($preset === 'gmail_app') {
                $a['imap_host'] = 'imap.gmail.com'; $a['imap_port'] = 993; $a['imap_security'] = 'ssl';
                $a['smtp_host'] = 'smtp.gmail.com'; $a['smtp_port'] = 465; $a['smtp_security'] = 'ssl';
                $a['username'] = $a['email']; $a['smtp_username'] = $a['email'];
            } elseif (isset(dmd_mail_standard_presets()[$preset])) {
                $cfg = dmd_mail_standard_presets()[$preset];
                foreach (array('imap_host','imap_port','imap_security','smtp_host','smtp_port','smtp_security') as $k) $a[$k] = $cfg[$k];
                $a['username'] = trim((string)($in['username'] ?? '')) ?: $a['email'];
                $a['smtp_username'] = trim((string)($in['smtp_username'] ?? '')) ?: $a['username'];
            } else {
                foreach (array('imap_host','imap_security','smtp_host','smtp_security','username','smtp_username') as $k) $a[$k] = trim((string)($in[$k] ?? ($a[$k] ?? '')));
                $a['imap_port'] = max(1, (int)($in['imap_port'] ?? ($a['imap_port'] ?? 993)));
                $a['smtp_port'] = max(1, (int)($in['smtp_port'] ?? ($a['smtp_port'] ?? 465)));
                if ($a['username'] === '') $a['username'] = $a['email'];
                if ($a['smtp_username'] === '') $a['smtp_username'] = $a['username'];
            }
            $pw = (string)($in['password'] ?? '');
            if ($preset === 'gmail_app') $pw = preg_replace('/\s+/', '', $pw);
            if ($pw !== '') $a['password_enc'] = dmd_mail_encrypt($pw);
            if (empty($a['password_enc'])) throw new RuntimeException($preset === 'gmail_app' ? 'Mot de passe d’application Gmail requis.' : 'Mot de passe requis.');
            $spw = (string)($in['smtp_password'] ?? '');
            if ($spw !== '') $a['smtp_password_enc'] = dmd_mail_encrypt($spw);
            if ($preset === 'gmail_app' || isset(dmd_mail_standard_presets()[$preset]) || !empty($in['smtp_same_password'])) unset($a['smtp_password_enc']);
            unset($a['client_id'], $a['tenant'], $a['client_secret_enc']);
        } else {
            if ($provider === 'microsoft') {
                unset($a['client_id'], $a['tenant'], $a['client_secret_enc']);
            } else {
                $a['client_id'] = trim((string)($in['client_id'] ?? ($a['client_id'] ?? '')));
                if ($a['client_id'] === '') throw new RuntimeException('Client ID OAuth requis.');
                $secret = (string)($in['client_secret'] ?? '');
                if ($secret !== '') $a['client_secret_enc'] = dmd_mail_encrypt($secret);
                if (empty($a['client_secret_enc'])) throw new RuntimeException('Client secret OAuth requis.');
            }
            foreach (array('imap_host','imap_security','imap_port','smtp_host','smtp_security','smtp_port','username','smtp_username','password_enc','smtp_password_enc') as $k) unset($a[$k]);
        }
        $a['updated_at'] = date(DATE_ATOM);
        if (!isset($a['created_at'])) $a['created_at'] = $a['updated_at'];
        if ($idx >= 0) $accounts[$idx] = $a; else $accounts[] = $a;
        if ($saveMode === 'create' && count($accounts) !== count($beforeAccounts) + 1) {
            throw new RuntimeException('Création du compte annulée : incohérence détectée.');
        }
        dmd_mail_backup_accounts_snapshot($beforeAccounts);
        if (!dmd_mail_save_accounts($accounts)) throw new RuntimeException('Impossible d’enregistrer le compte.');
        return dmd_mail_public_account($a);
    }
}
if (!function_exists('dmd_mail_save_test_account_input')) {
    function dmd_mail_save_test_account_input(array $in): array {
        $beforeAccounts = dmd_mail_accounts();
        $beforeTokens = dmd_mail_json_read(dmd_mail_tokens_file(), array());
        try {
            $saved = dmd_mail_save_account_input($in);
            $full = dmd_mail_account((string)$saved['id']);
            if (!$full) throw new RuntimeException('Compte enregistré introuvable.');
            $provider = (string)($full['provider'] ?? 'imap');
            if ($provider === 'google' || $provider === 'microsoft') {
                $connected = is_array(dmd_mail_token((string)$full['id']));
                if (!$connected) return array('account'=>$saved,'needs_oauth'=>true,'folders_count'=>0);
            }
            $folders = dmd_mail_provider_folders($full);
            return array('account'=>dmd_mail_public_account($full),'needs_oauth'=>false,'folders_count'=>count($folders));
        } catch (Throwable $e) {
            dmd_mail_save_accounts($beforeAccounts);
            dmd_mail_json_write(dmd_mail_tokens_file(), $beforeTokens);
            throw $e;
        }
    }
}
if (!function_exists('dmd_mail_signatures_file')) {
    function dmd_mail_signatures_file(?string $email = null): string { return dmd_mail_user_dir($email) . '/signatures.json'; }
}
if (!function_exists('dmd_mail_signatures')) {
    function dmd_mail_signatures(?string $email = null): array {
        $j=dmd_mail_json_read(dmd_mail_signatures_file($email),array('schema'=>1,'accounts'=>array()));
        return is_array($j['accounts']??null)?$j['accounts']:array();
    }
}
if (!function_exists('dmd_mail_signature')) {
    function dmd_mail_signature(string $accountId, ?string $email = null): array {
        $all=dmd_mail_signatures($email);$s=$all[$accountId]??array();
        return is_array($s)?array('enabled'=>!array_key_exists('enabled',$s)||!empty($s['enabled']),'html'=>(string)($s['html']??'')):array('enabled'=>true,'html'=>'');
    }
}
if (!function_exists('dmd_mail_save_signature')) {
    function dmd_mail_save_signature(string $accountId,string $html,bool $enabled=true,?string $email=null): array {
        if($accountId===''||dmd_mail_account($accountId,$email)===null)throw new RuntimeException('Compte mail introuvable.');
        if(strlen($html)>500000)throw new RuntimeException('Signature trop volumineuse.');
        // Bloque le contenu actif ; conserve la mise en forme et les images data:/https:.
        $html=preg_replace('#<\s*(script|iframe|object|embed|form|input|button|meta|link)[^>]*>.*?<\s*/\s*\1\s*>#is','',$html)??$html;
        $html=preg_replace('/\son[a-z]+\s*=\s*(["\']).*?\1/is','',$html)??$html;
        $html=preg_replace('/javascript\s*:/i','',$html)??$html;
        $all=dmd_mail_signatures($email);$all[$accountId]=array('enabled'=>$enabled,'html'=>$html,'updated_at'=>date(DATE_ATOM));
        dmd_mail_json_write(dmd_mail_signatures_file($email),array('schema'=>1,'accounts'=>$all));
        return array('enabled'=>$enabled,'html'=>$html);
    }
}
if (!function_exists('dmd_mail_gmail_create_folder')) {
    function dmd_mail_gmail_create_folder(array $a,string $name,string $parent=''): array {
        $full=trim($parent)!==''?rtrim($parent,'/').'/'.trim($name):trim($name);if($full==='')throw new RuntimeException('Nom de dossier requis.');
        $j=dmd_mail_http_json('POST','https://gmail.googleapis.com/gmail/v1/users/me/labels',array('Authorization: Bearer '.dmd_mail_access_token($a),'Content-Type: application/json'),json_encode(array('name'=>$full,'labelListVisibility'=>'labelShow','messageListVisibility'=>'show')));
        return array('id'=>(string)($j['id']??''),'name'=>(string)($j['name']??$full));
    }
}
if (!function_exists('dmd_mail_gmail_rename_folder')) {
    function dmd_mail_gmail_rename_folder(array $a,string $id,string $name): void {
        if($id===''||$name==='')throw new RuntimeException('Dossier invalide.');
        dmd_mail_http_json('PATCH','https://gmail.googleapis.com/gmail/v1/users/me/labels/'.rawurlencode($id),array('Authorization: Bearer '.dmd_mail_access_token($a),'Content-Type: application/json'),json_encode(array('name'=>$name)));
    }
}
if (!function_exists('dmd_mail_gmail_delete_folder')) {
    function dmd_mail_gmail_delete_folder(array $a,string $id): void {
        $r=dmd_mail_http('DELETE','https://gmail.googleapis.com/gmail/v1/users/me/labels/'.rawurlencode($id),array('Authorization: Bearer '.dmd_mail_access_token($a)));if($r['status']<200||$r['status']>=300)throw new RuntimeException('Suppression du dossier Gmail refusée.');
    }
}
if (!function_exists('dmd_mail_gmail_move')) {
    function dmd_mail_gmail_move(array $a,string $source,string $id,string $target): void {
        $body=array('addLabelIds'=>array($target));if($source!==''&&$source!==$target)$body['removeLabelIds']=array($source);
        dmd_mail_http_json('POST','https://gmail.googleapis.com/gmail/v1/users/me/messages/'.rawurlencode($id).'/modify',array('Authorization: Bearer '.dmd_mail_access_token($a),'Content-Type: application/json'),json_encode($body));
    }
}
if (!function_exists('dmd_mail_graph_create_folder')) {
    function dmd_mail_graph_create_folder(array $a,string $name,string $parent=''): array {
        if(trim($name)==='')throw new RuntimeException('Nom de dossier requis.');$path=$parent!==''?'/me/mailFolders/'.rawurlencode($parent).'/childFolders':'/me/mailFolders';
        $j=dmd_mail_http_json('POST','https://graph.microsoft.com/v1.0'.$path,dmd_mail_graph_headers($a),json_encode(array('displayName'=>$name)));
        return array('id'=>(string)($j['id']??''),'name'=>(string)($j['displayName']??$name));
    }
}
if (!function_exists('dmd_mail_graph_rename_folder')) {
    function dmd_mail_graph_rename_folder(array $a,string $id,string $name): void { dmd_mail_http_json('PATCH','https://graph.microsoft.com/v1.0/me/mailFolders/'.rawurlencode($id),dmd_mail_graph_headers($a),json_encode(array('displayName'=>$name))); }
}
if (!function_exists('dmd_mail_graph_delete_folder')) {
    function dmd_mail_graph_delete_folder(array $a,string $id): void { $r=dmd_mail_http('DELETE','https://graph.microsoft.com/v1.0/me/mailFolders/'.rawurlencode($id),array('Authorization: Bearer '.dmd_mail_access_token($a)));if($r['status']<200||$r['status']>=300)throw new RuntimeException('Suppression du dossier Microsoft refusée.'); }
}
if (!function_exists('dmd_mail_graph_move')) {
    function dmd_mail_graph_move(array $a,string $source,string $id,string $target): void { dmd_mail_http_json('POST','https://graph.microsoft.com/v1.0/me/messages/'.rawurlencode($id).'/move',dmd_mail_graph_headers($a),json_encode(array('destinationId'=>$target))); }
}
if (!function_exists('dmd_mail_imap_create_folder')) {
    function dmd_mail_imap_create_folder(array $a,string $name,string $parent=''): array {$sep='/';$full=trim($parent)!==''?rtrim($parent,$sep).$sep.trim($name):trim($name);if($full==='')throw new RuntimeException('Nom de dossier requis.');$c=dmd_mail_raw_imap_connect($a);try{dmd_mail_raw_imap_cmd($c,'CREATE '.dmd_mail_raw_imap_quote($full));}finally{dmd_mail_raw_imap_close($c);}return array('id'=>$full,'name'=>$full);}
}
if (!function_exists('dmd_mail_imap_rename_folder')) {
    function dmd_mail_imap_rename_folder(array $a,string $id,string $name): void {$c=dmd_mail_raw_imap_connect($a);try{dmd_mail_raw_imap_cmd($c,'RENAME '.dmd_mail_raw_imap_quote($id).' '.dmd_mail_raw_imap_quote($name));}finally{dmd_mail_raw_imap_close($c);}}
}
if (!function_exists('dmd_mail_imap_delete_folder')) {
    function dmd_mail_imap_delete_folder(array $a,string $id): void {$c=dmd_mail_raw_imap_connect($a);try{dmd_mail_raw_imap_cmd($c,'DELETE '.dmd_mail_raw_imap_quote($id));}finally{dmd_mail_raw_imap_close($c);}}
}
if (!function_exists('dmd_mail_imap_move')) {
    function dmd_mail_imap_move(array $a,string $source,string $id,string $target): void {if(!ctype_digit($id))throw new RuntimeException('Message IMAP invalide.');$c=dmd_mail_raw_imap_connect($a);try{dmd_mail_raw_imap_select($c,$source,true);try{dmd_mail_raw_imap_cmd($c,'UID MOVE '.(int)$id.' '.dmd_mail_raw_imap_quote($target));}catch(Throwable $e){dmd_mail_raw_imap_cmd($c,'UID COPY '.(int)$id.' '.dmd_mail_raw_imap_quote($target));dmd_mail_raw_imap_cmd($c,'UID STORE '.(int)$id.' +FLAGS.SILENT (\\Deleted)');dmd_mail_raw_imap_cmd($c,'EXPUNGE');}}finally{dmd_mail_raw_imap_close($c);}}
}
if (!function_exists('dmd_mail_provider_create_folder')) {function dmd_mail_provider_create_folder(array $a,string $name,string $parent=''):array{$p=(string)($a['provider']??'imap');return $p==='google'?dmd_mail_gmail_create_folder($a,$name,$parent):($p==='microsoft'?dmd_mail_graph_create_folder($a,$name,$parent):dmd_mail_imap_create_folder($a,$name,$parent));}}
if (!function_exists('dmd_mail_provider_rename_folder')) {function dmd_mail_provider_rename_folder(array $a,string $id,string $name):void{$p=(string)($a['provider']??'imap');if($p==='google')dmd_mail_gmail_rename_folder($a,$id,$name);elseif($p==='microsoft')dmd_mail_graph_rename_folder($a,$id,$name);else dmd_mail_imap_rename_folder($a,$id,$name);}}
if (!function_exists('dmd_mail_provider_delete_folder')) {function dmd_mail_provider_delete_folder(array $a,string $id):void{$p=(string)($a['provider']??'imap');if($p==='google')dmd_mail_gmail_delete_folder($a,$id);elseif($p==='microsoft')dmd_mail_graph_delete_folder($a,$id);else dmd_mail_imap_delete_folder($a,$id);}}
if (!function_exists('dmd_mail_provider_move')) {function dmd_mail_provider_move(array $a,string $source,string $id,string $target):void{$p=(string)($a['provider']??'imap');if($p==='google')dmd_mail_gmail_move($a,$source,$id,$target);elseif($p==='microsoft')dmd_mail_graph_move($a,$source,$id,$target);else dmd_mail_imap_move($a,$source?:'INBOX',$id,$target);}}


/* ---- DMD-Mail bulk mailbox operations: one network session/request per group ---- */
if (!function_exists('dmd_mail_imap_bulk')) {
    function dmd_mail_imap_bulk(array $a,string $folder,array $ids,string $op,string $target=''): int {
        $uids=array_values(array_unique(array_filter(array_map('strval',$ids),fn($v)=>ctype_digit($v))));
        if(!$uids)return 0;
        $set=implode(',',array_map('intval',$uids));
        $c=dmd_mail_raw_imap_connect($a);
        try {
            dmd_mail_raw_imap_select($c,$folder?:'INBOX',true);
            if($op==='read') dmd_mail_raw_imap_cmd($c,'UID STORE '.$set.' +FLAGS.SILENT (\Seen)');
            elseif($op==='unread') dmd_mail_raw_imap_cmd($c,'UID STORE '.$set.' -FLAGS.SILENT (\Seen)');
            elseif($op==='delete') { dmd_mail_raw_imap_cmd($c,'UID STORE '.$set.' +FLAGS.SILENT (\Deleted)'); dmd_mail_raw_imap_cmd($c,'EXPUNGE'); }
            elseif($op==='move') {
                if($target==='') throw new RuntimeException('Dossier de destination requis.');
                try { dmd_mail_raw_imap_cmd($c,'UID MOVE '.$set.' '.dmd_mail_raw_imap_quote($target)); }
                catch(Throwable $e) { dmd_mail_raw_imap_cmd($c,'UID COPY '.$set.' '.dmd_mail_raw_imap_quote($target)); dmd_mail_raw_imap_cmd($c,'UID STORE '.$set.' +FLAGS.SILENT (\Deleted)'); dmd_mail_raw_imap_cmd($c,'EXPUNGE'); }
            } else throw new RuntimeException('Action groupée IMAP invalide.');
        } finally { dmd_mail_raw_imap_close($c); }
        return count($uids);
    }
}
if (!function_exists('dmd_mail_gmail_bulk')) {
    function dmd_mail_gmail_bulk(array $a,string $source,array $ids,string $op,string $target=''): int {
        $ids=array_values(array_unique(array_filter(array_map('strval',$ids)))); if(!$ids)return 0;
        $headers=array('Authorization: Bearer '.dmd_mail_access_token($a),'Content-Type: application/json');
        if($op==='delete') {
            dmd_mail_http_json('POST','https://gmail.googleapis.com/gmail/v1/users/me/messages/batchDelete',$headers,json_encode(array('ids'=>$ids)));
        } else {
            $body=array('ids'=>$ids,'addLabelIds'=>array(),'removeLabelIds'=>array());
            if($op==='read') $body['removeLabelIds'][]='UNREAD';
            elseif($op==='unread') $body['addLabelIds'][]='UNREAD';
            elseif($op==='move') { if($target==='')throw new RuntimeException('Dossier de destination requis.'); $body['addLabelIds'][]=$target; if($source!==''&&$source!==$target)$body['removeLabelIds'][]=$source; }
            else throw new RuntimeException('Action groupée Gmail invalide.');
            dmd_mail_http_json('POST','https://gmail.googleapis.com/gmail/v1/users/me/messages/batchModify',$headers,json_encode($body));
        }
        return count($ids);
    }
}
if (!function_exists('dmd_mail_graph_bulk')) {
    function dmd_mail_graph_bulk(array $a,string $source,array $ids,string $op,string $target=''): int {
        $ids=array_values(array_unique(array_filter(array_map('strval',$ids)))); if(!$ids)return 0;
        $token=dmd_mail_access_token($a); $done=0;
        foreach(array_chunk($ids,20) as $chunk){
            $requests=[];
            foreach($chunk as $i=>$id){
                if($op==='read'||$op==='unread') $requests[]=array('id'=>(string)$i,'method'=>'PATCH','url'=>'/me/messages/'.rawurlencode($id),'headers'=>array('Content-Type'=>'application/json'),'body'=>array('isRead'=>$op==='read'));
                elseif($op==='delete') $requests[]=array('id'=>(string)$i,'method'=>'DELETE','url'=>'/me/messages/'.rawurlencode($id));
                elseif($op==='move') { if($target==='')throw new RuntimeException('Dossier de destination requis.'); $requests[]=array('id'=>(string)$i,'method'=>'POST','url'=>'/me/messages/'.rawurlencode($id).'/move','headers'=>array('Content-Type'=>'application/json'),'body'=>array('destinationId'=>$target)); }
                else throw new RuntimeException('Action groupée Microsoft invalide.');
            }
            $j=dmd_mail_http_json('POST','https://graph.microsoft.com/v1.0/$batch',array('Authorization: Bearer '.$token,'Content-Type: application/json'),json_encode(array('requests'=>$requests)));
            foreach((array)($j['responses']??array()) as $r){$st=(int)($r['status']??0);if($st>=200&&$st<300)$done++;}
        }
        return $done;
    }
}
if (!function_exists('dmd_mail_provider_bulk')) {
    function dmd_mail_provider_bulk(array $a,string $folder,array $ids,string $op,string $target=''): int {
        $p=(string)($a['provider']??'imap');
        if($p==='google')return dmd_mail_gmail_bulk($a,$folder,$ids,$op,$target);
        if($p==='microsoft')return dmd_mail_graph_bulk($a,$folder,$ids,$op,$target);
        return dmd_mail_imap_bulk($a,$folder?:'INBOX',$ids,$op,$target);
    }
}
if (!function_exists('dmd_mail_contact_module_available')) {
    function dmd_mail_contact_module_available(): bool {
        $root = dmd_mail_root();
        $mods = $root . '/modules';
        if (!is_dir($mods)) return false;
        foreach (glob($mods . '/*/dmd_module.json') ?: array() as $mf) {
            $j = dmd_mail_contact_read_json($mf, array());
            $id = strtolower(trim((string)($j['id'] ?? '')));
            $name = strtolower(trim((string)($j['name'] ?? '')));
            if ($id === 'dmd-contact' || $id === 'dmd_contact' || $name === 'dmd-contact') return true;
        }
        foreach (array('DMD-Contact','dmd-contact','dmd_contact') as $n) if (is_dir($mods.'/'.$n)) return true;
        return false;
    }
}
if (!function_exists('dmd_mail_contact_clean_email')) {
    function dmd_mail_contact_clean_email(string $v): string {
        $v = trim($v);
        return function_exists('mb_strtolower') ? mb_strtolower($v, 'UTF-8') : strtolower($v);
    }
}
if (!function_exists('dmd_mail_contact_read_json')) {
    function dmd_mail_contact_read_json(string $file, $fallback = array()) {
        if (!is_file($file)) return $fallback;
        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') return $fallback;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $fallback;
    }
}
if (!function_exists('dmd_mail_contact_role')) {
    function dmd_mail_contact_role(string $email): string {
        $profile = dmd_mail_contact_read_json(dmd_mail_root().'/users/profiles/'.dmd_mail_safe_user_key($email).'/profile.json', array());
        return trim((string)($profile['role_metier'] ?? $profile['role'] ?? ''));
    }
}
if (!function_exists('dmd_mail_contact_accessible')) {
    function dmd_mail_contact_accessible(array $c, string $ownerEmail, string $viewerEmail, string $viewerRole): bool {
        if (dmd_mail_contact_clean_email($ownerEmail) === dmd_mail_contact_clean_email($viewerEmail)) return true;
        $sharedWith = array_map('dmd_mail_contact_clean_email', array_map('strval', $c['shared_with'] ?? array()));
        if (in_array(dmd_mail_contact_clean_email($viewerEmail), $sharedWith, true)) return true;
        $sharedRoles = array_map('strval', $c['shared_roles'] ?? array());
        if ($viewerRole !== '' && in_array($viewerRole, $sharedRoles, true)) return true;
        if (!empty($c['share_same_role']) && $viewerRole !== '') {
            $ownerRole = dmd_mail_contact_role($ownerEmail);
            if ($ownerRole !== '') {
                $a = function_exists('mb_strtolower') ? mb_strtolower($ownerRole, 'UTF-8') : strtolower($ownerRole);
                $b = function_exists('mb_strtolower') ? mb_strtolower($viewerRole, 'UTF-8') : strtolower($viewerRole);
                if ($a === $b) return true;
            }
        }
        return false;
    }
}
if (!function_exists('dmd_mail_contact_display_name')) {
    function dmd_mail_contact_display_name(array $c): string {
        $name = trim((string)($c['prenom'] ?? '').' '.(string)($c['nom'] ?? ''));
        if ($name === '') $name = trim((string)($c['surnom'] ?? ''));
        if ($name === '') $name = trim((string)($c['entreprise'] ?? ''));
        return $name !== '' ? $name : '(Sans nom)';
    }
}
if (!function_exists('dmd_mail_contacts')) {
    function dmd_mail_contacts(?string $viewerEmail = null): array {
        $viewerEmail = trim((string)($viewerEmail ?: dmd_mail_require_user()));
        $profilesBase = dmd_mail_root().'/users/profiles';
        if (!is_dir($profilesBase)) return array();
        $viewerRole = dmd_mail_contact_role($viewerEmail);
        $out = array();
        foreach (glob($profilesBase.'/*/contact/contacts.json') ?: array() as $file) {
            $profileDir = dirname(dirname($file));
            $profile = dmd_mail_contact_read_json($profileDir.'/profile.json', array());
            $ownerEmail = trim((string)($profile['email'] ?? $profile['mail'] ?? ''));
            if ($ownerEmail === '') {
                $folderKey = basename($profileDir);
                $ownerEmail = $folderKey;
                if (filter_var($folderKey, FILTER_VALIDATE_EMAIL) === false && dmd_mail_safe_user_key($viewerEmail) === $folderKey) $ownerEmail = $viewerEmail;
            }
            foreach (dmd_mail_contact_read_json($file, array()) as $c) {
                if (!is_array($c) || !dmd_mail_contact_accessible($c, $ownerEmail, $viewerEmail, $viewerRole)) continue;
                $id = (string)($c['id'] ?? '');
                $emails = array_values(array_unique(array_filter(array_map('trim', array((string)($c['mail'] ?? ''),(string)($c['mail2'] ?? ''))), fn($v)=>filter_var($v,FILTER_VALIDATE_EMAIL)!==false)));
                if (!$emails) continue;
                $out[] = array(
                    'uid'=>hash('sha256', dmd_mail_contact_clean_email($ownerEmail).'|'.$id),
                    'id'=>$id,
                    'owner_email'=>$ownerEmail,
                    'is_owner'=>dmd_mail_contact_clean_email($ownerEmail)===dmd_mail_contact_clean_email($viewerEmail),
                    'name'=>dmd_mail_contact_display_name($c),
                    'company'=>trim((string)($c['entreprise'] ?? '')),
                    'job'=>trim((string)($c['poste'] ?? '')),
                    'emails'=>$emails,
                    'mail'=>$emails[0] ?? '',
                    'mail2'=>$emails[1] ?? '',
                    'phone'=>trim((string)($c['tel'] ?? '')),
                    'phone2'=>trim((string)($c['tel2'] ?? '')),
                    'tags'=>trim((string)($c['tags'] ?? '')),
                );
            }
        }
        usort($out, static function($a,$b){ return strnatcasecmp((string)($a['name']??''),(string)($b['name']??'')); });
        return $out;
    }
}
if (!function_exists('dmd_mail_contact_find_by_email')) {
    function dmd_mail_contact_find_by_email(string $email, ?string $viewerEmail = null): ?array {
        $needle = dmd_mail_contact_clean_email($email);
        foreach (dmd_mail_contacts($viewerEmail) as $c) {
            foreach ((array)($c['emails'] ?? array()) as $e) if (dmd_mail_contact_clean_email((string)$e) === $needle) return $c;
        }
        return null;
    }
}
if (!function_exists('dmd_mail_contact_create')) {
    function dmd_mail_contact_create(array $input, ?string $viewerEmail = null): array {
        $viewerEmail = trim((string)($viewerEmail ?: dmd_mail_require_user()));
        $email = trim((string)($input['mail'] ?? $input['email'] ?? ''));
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) throw new RuntimeException('Adresse e-mail du contact invalide.');
        $existing = dmd_mail_contact_find_by_email($email, $viewerEmail);
        if ($existing) return $existing;
        $dir = dmd_mail_root().'/users/profiles/'.dmd_mail_safe_user_key($viewerEmail).'/contact';
        if (!is_dir($dir) && !@mkdir($dir, 0775, true)) throw new RuntimeException('Impossible de créer le dossier DMD-Contact.');
        $file = $dir.'/contacts.json';
        $rows = dmd_mail_contact_read_json($file, array());
        $name = trim((string)($input['name'] ?? ''));
        $prenom=''; $nom='';
        if ($name !== '') {
            $parts = preg_split('/\s+/', $name, 2);
            $prenom = (string)($parts[0] ?? '');
            $nom = (string)($parts[1] ?? '');
        }
        $id = 'c_'.date('YmdHis').'_'.substr(bin2hex(random_bytes(4)),0,8);
        $record = array(
            'id'=>$id,'civilite'=>'','prenom'=>$prenom,'nom'=>$nom,'surnom'=>'',
            'is_private'=>true,'is_pro'=>false,'relation_private'=>'','relation_pro'=>'',
            'entreprise'=>trim((string)($input['company'] ?? '')),'poste'=>'','service'=>'','siret'=>'',
            'mail'=>$email,'mail2'=>'','tel'=>'','tel2'=>'','adresse'=>'','code_postal'=>'','ville'=>'','pays'=>'',
            'date_naissance'=>'','statut_familial'=>'','site_web'=>'','linkedin'=>'','tags'=>'','notes'=>'',
            'shared_with'=>array(),'shared_roles'=>array(),'share_same_role'=>false,
            'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM)
        );
        $rows[] = $record;
        $json = json_encode($rows, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|(defined('JSON_INVALID_UTF8_SUBSTITUTE')?JSON_INVALID_UTF8_SUBSTITUTE:0));
        if (!is_string($json) || @file_put_contents($file,$json,LOCK_EX)===false) throw new RuntimeException('Impossible d’enregistrer le contact dans DMD-Contact.');
        @chmod($file,0640);
        return array(
            'uid'=>hash('sha256',dmd_mail_contact_clean_email($viewerEmail).'|'.$id),'id'=>$id,'owner_email'=>$viewerEmail,'is_owner'=>true,
            'name'=>dmd_mail_contact_display_name($record),'company'=>(string)$record['entreprise'],'job'=>'','emails'=>array($email),'mail'=>$email,'mail2'=>'',
            'phone'=>'','phone2'=>'','tags'=>''
        );
    }
}
