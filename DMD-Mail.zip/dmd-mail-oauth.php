<?php
require_once __DIR__ . '/dmd-mail-lib.php';
header('Cache-Control: no-store');

function dmd_mail_oauth_page(bool $ok, string $message): void {
    $payload = json_encode(array('type'=>'dmd-mail-oauth','ok'=>$ok,'message'=>$message), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $title = $ok ? 'Connexion réussie' : 'Connexion impossible';
    $safeTitle = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
    $safeMsg = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.$safeTitle.'</title><style>body{font-family:system-ui,sans-serif;margin:0;padding:28px;background:#111827;color:#f9fafb}.box{max-width:620px;margin:12vh auto;padding:24px;border:1px solid #374151;border-radius:14px;background:#1f2937}h1{font-size:20px;margin:0 0 8px}p{opacity:.85}</style></head><body><div class="box"><h1>'.$safeTitle.'</h1><p>'.$safeMsg.'</p><p>Cette fenêtre peut être fermée.</p></div><script>try{if(window.opener){window.opener.postMessage('.$payload.',location.origin);}}catch(e){}setTimeout(function(){window.close();},900);</script></body></html>';
    exit;
}

try {
    dmd_mail_require_user();
    dmd_mail_require_permission(array('accounts.connect','config.edit'));
    if (isset($_GET['start'])) {
        $id = trim((string)$_GET['start']);
        $a = dmd_mail_account($id);
        if (!$a || !in_array((string)($a['provider'] ?? ''), array('google','microsoft'), true)) throw new RuntimeException('Compte OAuth introuvable.');
        $state = bin2hex(random_bytes(24));
        if (!isset($_SESSION['dmd_mail_oauth_states']) || !is_array($_SESSION['dmd_mail_oauth_states'])) $_SESSION['dmd_mail_oauth_states'] = array();
        $_SESSION['dmd_mail_oauth_states'][$state] = array('account'=>$id,'created_at'=>time());
        header('Location: ' . dmd_mail_oauth_authorize_url($a, $state));
        exit;
    }

    if (isset($_GET['callback'])) {
        if (!empty($_GET['error'])) dmd_mail_oauth_page(false, (string)($_GET['error_description'] ?? $_GET['error']));
        $state = trim((string)($_GET['state'] ?? ''));
        $code = trim((string)($_GET['code'] ?? ''));
        $states = isset($_SESSION['dmd_mail_oauth_states']) && is_array($_SESSION['dmd_mail_oauth_states']) ? $_SESSION['dmd_mail_oauth_states'] : array();
        $st = $states[$state] ?? null;
        unset($_SESSION['dmd_mail_oauth_states'][$state]);
        if (!is_array($st) || time() - (int)($st['created_at'] ?? 0) > 900 || $code === '') throw new RuntimeException('Retour OAuth invalide ou expiré.');
        $a = dmd_mail_account((string)$st['account']);
        if (!$a) throw new RuntimeException('Compte OAuth introuvable.');
        dmd_mail_oauth_exchange($a, $code);
        dmd_mail_oauth_page(true, 'Le compte est maintenant connecté à DMD-Mail.');
    }
    dmd_mail_oauth_page(false, 'Requête OAuth invalide.');
} catch (Throwable $e) {
    dmd_mail_oauth_page(false, $e->getMessage());
}
