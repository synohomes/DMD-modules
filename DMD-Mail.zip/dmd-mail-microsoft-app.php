<?php
return array(
    // Optionnel : l'éditeur peut publier ici un Client ID Microsoft commun au module.
    // Si vide, chaque utilisateur peut enregistrer son Client ID depuis la procédure
    // intégrée à DMD-Mail. Aucun secret client n'est utilisé avec le Device Code Flow.
    'client_id' => '',
);
