<?php
require_once __DIR__ . '/dmd-mail-lib.php';
try { dmd_mail_require_user(); dmd_mail_require_permission('module.view'); } catch (Throwable $e) { echo '<div class="dmd-mail-empty">Accès DMD-Mail refusé.</div>'; return; }
$base = dmd_mail_web_base();
$accounts = array_map('dmd_mail_public_account', dmd_mail_accounts());
$csrf = dmd_mail_csrf();
$permissions = dmd_mail_permissions_snapshot();
$uid = 'dmdMail_' . substr(md5(__DIR__ . microtime(true)),0,10);
?>
<link rel="stylesheet" href="<?= htmlspecialchars($base.'dmd-mail.css?v=1.0.0-ui30',ENT_QUOTES,'UTF-8') ?>">
<div class="dmd-mail" id="<?= htmlspecialchars($uid,ENT_QUOTES,'UTF-8') ?>" data-api="<?= htmlspecialchars($base.'dmd-mail-api.php',ENT_QUOTES,'UTF-8') ?>" data-cfg="<?= htmlspecialchars($base.'DMD-Mailcfg.php',ENT_QUOTES,'UTF-8') ?>">
  <header class="dmd-mail-top">
    <div class="dmd-mail-brand"><img src="<?= htmlspecialchars($base.'icon.png',ENT_QUOTES,'UTF-8') ?>" alt=""><span>DMD-Mail</span></div>
    <div class="dmd-mail-search-wrap"><span class="dmd-mail-search-icon">⌕</span><input class="dmd-mail-search" type="search" placeholder="Rechercher dans les messages" data-search></div>
    <div class="dmd-mail-toolbar">
      <button class="dmd-mail-btn icon" type="button" data-refresh title="Actualiser">↻</button>
      <span class="dmd-mail-contact-status" data-contact-status hidden title="Carnet DMD-Contact utilisé pour les destinataires"><span class="dmd-mail-contact-status-dot"></span><span>DMD-Contact</span><b data-contact-total></b></span><button class="dmd-mail-btn primary" type="button" data-compose>✉ <span>Nouveau mail</span></button>
      <button class="dmd-mail-btn icon" type="button" data-config title="Configurer les comptes">⚙</button>
    </div>
  </header>

  <div class="dmd-mail-shell">
    <aside class="dmd-mail-nav">
      <div class="dmd-mail-nav-head"><strong>Messageries</strong><button class="dmd-mail-mini-btn" type="button" data-config-new title="Ajouter une messagerie">＋</button></div>
      <div class="dmd-mail-accounts" data-accounts></div>
      <div class="dmd-mail-nav-sep"></div>
      <div class="dmd-mail-folder-head"><strong data-folder-group-title>Dossiers</strong><span class="dmd-mail-folder-tools"><button class="dmd-mail-mini-btn" type="button" data-folder-add title="Créer un dossier">＋</button><button class="dmd-mail-mini-btn" type="button" data-folder-rename title="Renommer le dossier">✎</button><button class="dmd-mail-mini-btn danger" type="button" data-folder-delete title="Supprimer le dossier">⌫</button></span></div>
      <div class="dmd-mail-folders" data-folders></div>
      <div class="dmd-mail-side-foot" data-side-status></div>
    </aside>

    <div class="dmd-mail-splitter" data-splitter="nav" role="separator" aria-orientation="vertical" aria-label="Redimensionner la colonne des messageries" title="Glisser pour redimensionner · Double-clic pour réinitialiser"><span></span></div>

    <section class="dmd-mail-list">
      <div class="dmd-mail-list-head">
        <div class="dmd-mail-list-title"><strong data-folder-title>Boîte de réception</strong><span data-count></span></div>
        <div class="dmd-mail-list-filters"><button class="active" type="button" data-filter="all">Tous</button><button type="button" data-filter="unread">Non lus</button></div>
      </div>
      <div class="dmd-mail-selection-bar" data-selection-bar hidden>
        <label title="Tout sélectionner"><input type="checkbox" data-select-all></label><strong data-selected-count>0 sélectionné</strong>
        <button type="button" data-bulk-read>Lu</button><button type="button" data-bulk-unread>Non lu</button>
        <select data-bulk-folder title="Déplacer vers"><option value="">Déplacer vers…</option></select><button type="button" data-bulk-move>Classer</button>
        <button class="danger" type="button" data-bulk-delete>Supprimer</button><button type="button" data-clear-selection>×</button>
      </div>
      <div class="dmd-mail-items" data-items></div>
    </section>

    <div class="dmd-mail-splitter" data-splitter="list" role="separator" aria-orientation="vertical" aria-label="Redimensionner la liste des messages" title="Glisser pour redimensionner · Double-clic pour réinitialiser"><span></span></div>

    <section class="dmd-mail-preview" data-preview>
      <div class="dmd-mail-preview-placeholder"><div class="dmd-mail-preview-icon">✉</div><strong>Aucun message sélectionné</strong><span>Choisissez un message dans la liste.</span></div>
    </section>
  </div>

  <footer class="dmd-mail-status"><span class="dmd-mail-status-dot"></span><span data-status>Prêt.</span></footer>

  <div class="dmd-mail-modal" data-compose-modal hidden>
    <form class="dmd-mail-dialog" data-compose-form>
      <div class="dmd-mail-dialog-head"><div><strong>Nouveau message</strong><span>Rédaction</span></div><button class="dmd-mail-btn icon" type="button" data-compose-close>×</button></div>
      <div class="dmd-mail-dialog-body">
        <div class="dmd-mail-compose-contact-info" data-compose-contact-info><div><strong data-contact-info-title>DMD-Contact</strong><span data-contact-info-text>Chargement du carnet de contacts…</span></div><button class="dmd-mail-btn" type="button" data-contact-browser>Contacts</button></div><label class="dmd-mail-field"><span>De</span><select name="account" data-compose-account></select></label>
        <label class="dmd-mail-field dmd-mail-recipient"><span>À</span><input name="to" autocomplete="off" required><div class="dmd-mail-contact-suggest" data-contact-suggest="to" hidden></div></label>
        <label class="dmd-mail-field dmd-mail-recipient"><span>Cc</span><input name="cc" autocomplete="off"><div class="dmd-mail-contact-suggest" data-contact-suggest="cc" hidden></div></label>
        <label class="dmd-mail-field dmd-mail-recipient"><span>Cci</span><input name="bcc" autocomplete="off"><div class="dmd-mail-contact-suggest" data-contact-suggest="bcc" hidden></div></label>
        <label class="dmd-mail-field"><span>Objet</span><input name="subject" autocomplete="off"></label>
        <div class="dmd-mail-field body rich"><span>Message</span><div class="dmd-mail-rich-wrap"><div class="dmd-mail-richbar" data-richbar><button type="button" data-cmd="bold"><b>B</b></button><button type="button" data-cmd="italic"><i>I</i></button><button type="button" data-cmd="underline"><u>U</u></button><button type="button" data-cmd="insertUnorderedList">• Liste</button><button type="button" data-cmd="insertOrderedList">1. Liste</button><button type="button" data-link>🔗</button><button type="button" data-inline-image>🖼</button><button type="button" data-signature-edit>Signature</button><select data-font-size><option value="">Taille</option><option value="2">Petit</option><option value="3">Normal</option><option value="4">Grand</option><option value="5">Très grand</option></select><input type="file" accept="image/*" data-inline-file hidden></div><div class="dmd-mail-editor" data-editor contenteditable="true" role="textbox" aria-multiline="true"></div><input type="hidden" name="body" data-body-html></div></div>
        <label class="dmd-mail-field"><span>Fichiers</span><input type="file" name="attachments[]" multiple></label>
      </div>
      <div class="dmd-mail-dialog-actions"><button class="dmd-mail-btn" type="button" data-compose-close>Annuler</button><button class="dmd-mail-btn primary" type="submit">Envoyer</button></div>
      <aside class="dmd-mail-contact-browser" data-contact-browser-panel hidden><div class="dmd-mail-contact-browser-head"><strong>DMD-Contact</strong><button class="dmd-mail-btn icon" type="button" data-contact-browser-close>×</button></div><input type="search" placeholder="Rechercher nom, société, e-mail…" data-contact-browser-search><div class="dmd-mail-contact-browser-list" data-contact-browser-list></div></aside>
    </form>
  </div>
  <div class="dmd-mail-modal" data-signature-modal hidden>
    <div class="dmd-mail-dialog dmd-mail-signature-dialog">
      <div class="dmd-mail-dialog-head"><div><strong>Signature</strong><span>Signature du compte sélectionné</span></div><button class="dmd-mail-btn icon" type="button" data-signature-close>×</button></div>
      <div class="dmd-mail-dialog-body"><label class="dmd-mail-signature-enable"><input type="checkbox" data-signature-enabled checked> Ajouter automatiquement cette signature</label><div class="dmd-mail-richbar" data-signature-richbar><button type="button" data-sig-cmd="bold"><b>B</b></button><button type="button" data-sig-cmd="italic"><i>I</i></button><button type="button" data-sig-cmd="underline"><u>U</u></button><button type="button" data-sig-cmd="insertUnorderedList">• Liste</button><button type="button" data-sig-link>🔗</button><button type="button" data-sig-image>🖼 Image</button><input type="file" accept="image/*" data-sig-file hidden></div><div class="dmd-mail-editor signature" data-signature-editor contenteditable="true"></div></div>
      <div class="dmd-mail-dialog-actions"><button class="dmd-mail-btn" type="button" data-signature-close>Annuler</button><button class="dmd-mail-btn primary" type="button" data-signature-save>Enregistrer</button></div>
    </div>
  </div>
</div>
<script>
(function(){
  const root=document.getElementById(<?= json_encode($uid) ?>); if(!root||root.dataset.ready==='1') return; root.dataset.ready='1';
  const api=root.dataset.api,cfg=root.dataset.cfg,csrf=<?= json_encode($csrf) ?>;
  const permissions=<?= json_encode($permissions,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
  const can=(...ids)=>ids.some(id=>permissions[id]===true);
  let accounts=<?= json_encode($accounts,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
  let account=null, allMode=false, folder='', folderName='', folders=[], messages=[], selected=null, searchTimer=null, messageFilter='all', badgeCache={}, checked=new Set();
  const $=s=>root.querySelector(s), $$=s=>Array.from(root.querySelectorAll(s));
  const esc=s=>String(s??'').replace(/[&<>'\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','\"':'&quot;'}[c]));
  const extractEmail=v=>{const s=String(v||'');const a=s.match(/<([^>]+)>/);if(a&&a[1])return a[1].trim();const b=s.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);return b?b[0]:'';};
  const els={accounts:$('[data-accounts]'),folders:$('[data-folders]'),items:$('[data-items]'),preview:$('[data-preview]'),status:$('[data-status]'),side:$('[data-side-status]'),title:$('[data-folder-title]'),count:$('[data-count]'),search:$('[data-search]'),compose:$('[data-compose-modal]'),composeAcc:$('[data-compose-account]'),folderGroup:$('[data-folder-group-title]'),selectionBar:$('[data-selection-bar]'),selectedCount:$('[data-selected-count]'),selectAll:$('[data-select-all]'),bulkFolder:$('[data-bulk-folder]'),editor:$('[data-editor]'),bodyHtml:$('[data-body-html]'),signatureModal:$('[data-signature-modal]'),signatureEditor:$('[data-signature-editor]'),signatureEnabled:$('[data-signature-enabled]')};

  function enabledAccounts(){return accounts.filter(a=>a.enabled!==false)}
  function initials(a){const s=(a&&((a.name||'').trim()||(a.email||'').trim()))||'?'; const p=s.split(/[\s@._-]+/).filter(Boolean); return ((p[0]||'?')[0]+(p[1]?p[1][0]:'')).toUpperCase().slice(0,2)}
  function accountType(a){const p=a&&a.preset;return p==='gmail_app'?'Gmail':p==='ovh'?'OVH':p==='outlook_password'?'Outlook.com':p==='google_oauth'?'Google':p==='microsoft'?'Microsoft 365':(a&&a.provider==='microsoft'?'Microsoft 365':a&&a.provider==='google'?'Google':'IMAP / SMTP')}
  function status(t,err=false){els.status.textContent=t||'';root.classList.toggle('has-error',!!err)}
  async function req(action,params={},method='GET',form=null){let url=api+'?action='+encodeURIComponent(action);let opt={method,credentials:'same-origin',cache:'no-store'};if(method==='GET'){for(const[k,v]of Object.entries(params))url+='&'+encodeURIComponent(k)+'='+encodeURIComponent(v??'');}else if(form){form.set('csrf',csrf);opt.body=form;}else{opt.headers={'Content-Type':'application/json','X-DMD-CSRF':csrf};opt.body=JSON.stringify({...params,csrf});}const r=await fetch(url,opt);const tx=await r.text();let j;try{j=JSON.parse(tx)}catch(e){const clean=tx.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim().slice(0,180);throw new Error(clean?('Serveur DMD-Mail : '+clean):('Réponse serveur vide ou invalide ('+r.status+').'))}if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));return j}
  function dateLabel(v,ts){const d=ts?new Date(ts*1000):new Date(v);if(Number.isNaN(d.getTime()))return String(v||'');const now=new Date(),y=new Date(now);y.setDate(now.getDate()-1);if(d.toDateString()===now.toDateString())return d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});if(d.toDateString()===y.toDateString())return 'Hier';return d.toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit'});}
  function cleanFolderName(v){let s=String(v||'').replace(/^\[Gmail\]\/?/i,'').replace(/^INBOX$/i,'Boîte de réception'); if(/^Sent( Mail)?$/i.test(s))s='Messages envoyés'; if(/^Drafts$/i.test(s))s='Brouillons'; if(/^Trash$/i.test(s))s='Corbeille'; if(/^Spam|Junk$/i.test(s))s='Indésirables'; return s;}
  function folderIcon(name){const s=cleanFolderName(name).toLowerCase();if(/réception|inbox/.test(s))return '▣';if(/brouillon|draft/.test(s))return '✎';if(/envoy|sent/.test(s))return '➤';if(/corbeille|trash|supprim/.test(s))return '⌫';if(/spam|indésirable|junk/.test(s))return '⊘';if(/important/.test(s))return '★';if(/suivi|flag/.test(s))return '⚑';if(/tous les|all mail/.test(s))return '▤';return '▱'}
  function folderRank(f){const s=cleanFolderName(f.name||f.id).toLowerCase();if(/réception|inbox/.test(s))return 1;if(/brouillon|draft/.test(s))return 2;if(/envoy|sent/.test(s))return 3;if(/important/.test(s))return 4;if(/spam|indésirable|junk/.test(s))return 5;if(/corbeille|trash|supprim/.test(s))return 6;if(/tous les|all mail/.test(s))return 7;return 50}
  function isInbox(f){return /^(inbox|bo[iî]te de r[eé]ception)$/i.test(String(f.name||f.id||'')) || /réception/i.test(cleanFolderName(f.name||f.id))}
  function messageKey(m){return (m._account||account?.id||'')+'::'+(m._folder||folder||'')+'::'+m.id}
  function senderName(v){const s=String(v||'Expéditeur inconnu');const m=s.match(/^\s*"?([^"<]+)"?\s*<[^>]+>/);return (m?m[1]:s).trim()||'Expéditeur inconnu'}

  function renderAccounts(){
    const enabled=enabledAccounts();
    els.composeAcc.innerHTML=enabled.length?enabled.map(a=>`<option value="${esc(a.id)}">${esc(a.name||a.email)}</option>`).join(''):'<option value="">Aucun compte</option>';
    if(!enabled.length){account=null;allMode=false;els.accounts.innerHTML='<div class="dmd-mail-small-empty">Aucun compte configuré.</div>';els.folders.innerHTML='<div class="dmd-mail-small-empty">Ajoutez une messagerie avec ＋.</div>';els.items.innerHTML='<div class="dmd-mail-empty">Aucun compte configuré.</div>';return;}
    if(!account||!enabled.some(a=>a.id===account.id))account=enabled[0];
    const all=`<button class="dmd-mail-account all ${allMode?'active':''}" type="button" data-account-all><span class="dmd-mail-account-avatar">◎</span><span class="dmd-mail-account-copy"><strong>Toutes les boîtes</strong><small>${enabled.length} compte${enabled.length>1?'s':''}</small></span><b data-all-badge>${esc(Object.values(badgeCache).reduce((n,v)=>n+(Number(v)||0),0)||'')}</b></button>`;
    els.accounts.innerHTML=(enabled.length>1?all:'')+enabled.map(a=>`<button class="dmd-mail-account ${!allMode&&account&&a.id===account.id?'active':''}" type="button" data-account="${esc(a.id)}"><span class="dmd-mail-account-avatar">${esc(initials(a))}</span><span class="dmd-mail-account-copy"><strong>${esc(a.name||a.email)}</strong><small>${esc(a.email||accountType(a))}</small></span><b data-badge="${esc(a.id)}">${esc(badgeCache[a.id]||'')}</b></button>`).join('');
    els.composeAcc.value=account.id;
  }

  function renderFolders(){
    if(allMode){els.folderGroup.textContent='Vue unifiée';els.folders.innerHTML='<button class="dmd-mail-folder active" type="button"><span class="dmd-mail-folder-icon">▣</span><span class="dmd-mail-folder-label">Boîte de réception</span><b>'+esc(Object.values(badgeCache).reduce((n,v)=>n+(Number(v)||0),0)||'')+'</b></button>';return;}
    els.folderGroup.textContent='Dossiers';
    const sorted=[...folders].sort((a,b)=>folderRank(a)-folderRank(b));const primary=sorted.filter(f=>folderRank(f)<50),other=sorted.filter(f=>folderRank(f)>=50);
    const button=f=>`<button class="dmd-mail-folder ${f.id===folder?'active':''}" type="button" data-folder="${esc(f.id)}" data-name="${esc(f.name||f.id)}"><span class="dmd-mail-folder-icon">${folderIcon(f.name||f.id)}</span><span class="dmd-mail-folder-label">${esc(cleanFolderName(f.name||f.id))}</span>${f.unread!==null&&f.unread!==undefined&&Number(f.unread)>0?`<b>${esc(f.unread)}</b>`:''}</button>`;
    els.folders.innerHTML=primary.map(button).join('')+(other.length?`<details class="dmd-mail-more-folders"><summary>Autres dossiers <span>${other.length}</span></summary>${other.map(button).join('')}</details>`:'');
  }

  async function refreshBadges(){
    const enabled=enabledAccounts(); if(!enabled.length)return;
    await Promise.all(enabled.map(async a=>{try{const j=await req('folders',{account:a.id});const fs=j.folders||[];const inbox=fs.find(isInbox)||fs[0];badgeCache[a.id]=inbox&&inbox.unread!=null?Number(inbox.unread)||0:0;}catch(e){badgeCache[a.id]=0;}}));
    renderAccounts(); if(allMode)renderFolders();
  }

  async function loadFolders(){
    if(!account)return;allMode=false;status('Chargement des dossiers…');els.folders.innerHTML='<div class="dmd-mail-spinner">Chargement…</div>';
    try{const j=await req('folders',{account:account.id});folders=j.folders||[];if(!folders.length)throw new Error('Aucun dossier trouvé.');let chosen=folders.find(isInbox)||folders[0];if(folder&&folders.some(f=>f.id===folder))chosen=folders.find(f=>f.id===folder);folder=chosen.id;folderName=cleanFolderName(chosen.name||chosen.id);badgeCache[account.id]=Number(chosen.unread)||badgeCache[account.id]||0;renderAccounts();renderFolders();els.title.textContent=folderName;els.side.textContent=accountType(account)+' · '+(account.email||'');await loadMessages();}catch(e){els.folders.innerHTML='<div class="dmd-mail-small-empty">'+esc(e.message)+'</div>';status(e.message,true);}
  }

  async function loadUnifiedInbox(){
    const enabled=enabledAccounts();if(enabled.length<2){allMode=false;return loadFolders();}
    allMode=true;folder='';folderName='Boîte de réception';folders=[];checked.clear();renderAccounts();renderFolders();els.title.textContent='Toutes les boîtes';els.side.textContent=enabled.length+' messageries';selected=null;renderEmptyPreview();els.items.innerHTML='<div class="dmd-mail-spinner">Synchronisation des boîtes…</div>';status('Synchronisation des messageries…');
    try{
      const chunks=await Promise.all(enabled.map(async a=>{const fj=await req('folders',{account:a.id});const fs=fj.folders||[];const inbox=fs.find(isInbox)||fs[0];if(!inbox)return[];badgeCache[a.id]=Number(inbox.unread)||0;const mj=await req('messages',{account:a.id,folder:inbox.id,q:els.search.value.trim(),limit:35});return (mj.messages||[]).map(m=>({...m,_account:a.id,_folder:inbox.id,_accountName:a.name||a.email}));}));
      messages=chunks.flat().sort((a,b)=>(Number(b.timestamp)||0)-(Number(a.timestamp)||0)).slice(0,100);renderAccounts();renderFolders();renderMessageList();status('À jour.');
    }catch(e){els.items.innerHTML='<div class="dmd-mail-empty">'+esc(e.message)+'</div>';status(e.message,true);}
  }

  function renderEmptyPreview(){els.preview.classList.remove('open');els.preview.innerHTML='<div class="dmd-mail-preview-placeholder"><div class="dmd-mail-preview-icon">✉</div><strong>Aucun message sélectionné</strong><span>Choisissez un message dans la liste.</span></div>'}
  function updateSelectionUi(){
    const n=checked.size;els.selectionBar.hidden=n===0;els.selectedCount.textContent=n+' sélectionné'+(n>1?'s':'');
    const visible=(messageFilter==='unread'?messages.filter(m=>m.unread):messages);els.selectAll.checked=visible.length>0&&visible.every(m=>checked.has(messageKey(m)));els.selectAll.indeterminate=n>0&&!els.selectAll.checked;
    const canMove=!allMode&&can('mail.move','mail.modify');els.bulkFolder.disabled=!canMove;root.querySelector('[data-bulk-move]').disabled=!canMove;
  }
  function renderMessageList(){
    const view=messageFilter==='unread'?messages.filter(m=>m.unread):messages;els.count.textContent=view.length+' message'+(view.length>1?'s':'');
    els.items.innerHTML=view.length?view.map(m=>{const from=senderName(m.from);const key=messageKey(m);const acct=allMode?`<span class="dmd-mail-item-account">${esc(m._accountName||'')}</span>`:'';return `<div class="dmd-mail-item ${m.unread?'unread':''} ${checked.has(key)?'checked':''}" data-message-key="${esc(key)}"><label class="dmd-mail-check" title="Sélectionner"><input type="checkbox" data-message-check ${checked.has(key)?'checked':''}></label><button class="dmd-mail-item-open" type="button" data-message-open><span class="dmd-mail-sender-avatar">${esc(from.slice(0,1).toUpperCase())}</span><span class="dmd-mail-item-main"><span class="dmd-mail-item-line"><strong>${esc(from)}</strong><time>${esc(dateLabel(m.date,m.timestamp))}</time></span><span class="dmd-mail-item-subject">${esc(m.subject||'(Sans objet)')}</span><span class="dmd-mail-item-bottom"><span class="dmd-mail-item-preview">${esc(m.preview||'')}</span>${acct}</span></span>${m.unread?'<span class="dmd-mail-unread-dot"></span>':''}</button></div>`}).join(''):'<div class="dmd-mail-empty">Aucun message'+(messageFilter==='unread'?' non lu':'')+'.</div>';
    els.bulkFolder.innerHTML='<option value="">Déplacer vers…</option>'+folders.filter(f=>f.id!==folder).map(f=>`<option value="${esc(f.id)}">${esc(cleanFolderName(f.name||f.id))}</option>`).join('');updateSelectionUi();
  }

  async function loadMessages(){
    if(allMode)return loadUnifiedInbox(); if(!account||!folder)return;selected=null;checked.clear();renderEmptyPreview();els.items.innerHTML='<div class="dmd-mail-spinner">Chargement…</div>';status('Synchronisation…');
    try{const j=await req('messages',{account:account.id,folder,q:els.search.value.trim(),limit:75});messages=(j.messages||[]).map(m=>({...m,_account:account.id,_folder:folder,_accountName:account.name||account.email}));renderMessageList();status('À jour.');}catch(e){els.items.innerHTML='<div class="dmd-mail-empty">'+esc(e.message)+'</div>';status(e.message,true);}
  }
  function bodyDoc(html){return '<!doctype html><html><head><meta charset="utf-8"><base target="_blank"><style>html,body{margin:0;padding:0;background:#fff;color:#161616;font:14px/1.5 Arial,sans-serif}body{padding:18px;overflow-wrap:anywhere}img{max-width:100%;height:auto}pre{white-space:pre-wrap}table{max-width:100%}</style></head><body>'+html+'</body></html>'}

  async function openMessage(key){
    const m0=messages.find(m=>messageKey(m)===key);if(!m0)return;const srcAccount=accounts.find(a=>a.id===m0._account);if(!srcAccount)return;const srcFolder=m0._folder;selected=key;$$('[data-message-key]').forEach(b=>b.classList.toggle('active',b.dataset.messageKey===key));els.preview.classList.add('open');els.preview.innerHTML='<div class="dmd-mail-spinner">Ouverture…</div>';
    try{const j=await req('message',{account:srcAccount.id,folder:srcFolder,id:m0.id});const m=j.message,from=senderName(m.from);const atts=can('mail.attachments')?(m.attachments||[]).map(a=>{const u=api+'?action=attachment&account='+encodeURIComponent(srcAccount.id)+'&folder='+encodeURIComponent(srcFolder)+'&message='+encodeURIComponent(m0.id)+'&attachment='+encodeURIComponent(a.id)+'&name='+encodeURIComponent(a.name||'piece-jointe');return `<a class="dmd-mail-attachment" href="${esc(u)}">📎 <span>${esc(a.name||'Pièce jointe')}</span></a>`}).join(''):'';
      els.preview.innerHTML=`<div class="dmd-mail-message-head"><div class="dmd-mail-message-title-row"><h3 class="dmd-mail-message-title">${esc(m.subject||'(Sans objet)')}</h3><span class="dmd-mail-message-account">${esc(srcAccount.name||srcAccount.email)}</span></div><div class="dmd-mail-message-person"><span class="dmd-mail-message-avatar">${esc(from.slice(0,1).toUpperCase())}</span><div class="dmd-mail-message-who"><strong>${esc(from)}</strong><span>${esc(m.from||'')}</span><small>À ${esc(m.to||'')} ${m.cc?' · Cc '+esc(m.cc):''}</small></div><time>${esc(m.date||'')}</time></div><div class="dmd-mail-message-actions"><button class="dmd-mail-btn" type="button" data-reply>↩ Répondre</button><button class="dmd-mail-btn" type="button" data-reply-all>↩↩ Répondre à tous</button><button class="dmd-mail-btn" type="button" data-forward>↪ Transférer</button><button class="dmd-mail-btn" type="button" data-contact>＋ Contact</button><button class="dmd-mail-btn" type="button" data-unread>${m.unread?'✓ Marquer lu':'● Marquer non lu'}</button><button class="dmd-mail-btn danger" type="button" data-delete>⌫ Supprimer</button><button class="dmd-mail-btn list-return" type="button" data-preview-close>← Liste</button></div></div><div class="dmd-mail-message-body">${m.html?'<iframe class="dmd-mail-message-frame" sandbox="allow-popups allow-popups-to-escape-sandbox" referrerpolicy="no-referrer"></iframe>':`<div class="dmd-mail-textbody">${esc(m.text||'')}</div>`}</div>${atts?`<div class="dmd-mail-attachments">${atts}</div>`:''}`;
      const frame=els.preview.querySelector('iframe');if(frame)frame.srcdoc=bodyDoc(m.html);
      const canMark=can('mail.mark','mail.modify'),canDelete=can('mail.delete','mail.modify');
      const replyBtn=els.preview.querySelector('[data-reply]'), replyAllBtn=els.preview.querySelector('[data-reply-all]'), forwardBtn=els.preview.querySelector('[data-forward]'), contactBtn=els.preview.querySelector('[data-contact]'), unreadBtn=els.preview.querySelector('[data-unread]'), deleteBtn=els.preview.querySelector('[data-delete]');
      if(replyBtn&&!can('mail.send'))replyBtn.hidden=true;if(replyAllBtn&&!can('mail.send'))replyAllBtn.hidden=true;if(forwardBtn&&!can('mail.send'))forwardBtn.hidden=true;if(unreadBtn&&!canMark)unreadBtn.hidden=true;if(deleteBtn&&!canDelete)deleteBtn.hidden=true;
      if(contactBtn){
        const senderEmail=extractEmail(m.from||'');
        if(!senderEmail){contactBtn.hidden=true;}else{
          req('contacts',{q:senderEmail}).then(r=>{const hit=(r.contacts||[]).find(c=>(c.emails||[]).some(x=>String(x).toLowerCase()===senderEmail.toLowerCase()));if(hit){contactBtn.textContent='✓ DMD-Contact';contactBtn.disabled=true;contactBtn.title=hit.name+(hit.company?' · '+hit.company:'');}}).catch(()=>{});
          contactBtn.onclick=async()=>{if(contactBtn.disabled)return;contactBtn.disabled=true;try{const r=await req('contact_create',{email:senderEmail,name:from},'POST');contactBtn.textContent='✓ DMD-Contact';contactBtn.title=(r.contact&&r.contact.name)||senderEmail;status('Contact ajouté à DMD-Contact.');}catch(err){contactBtn.disabled=false;status(err.message,true);}};
        }
      }
      if(m.unread&&canMark){await req('mark_read',{account:srcAccount.id,folder:srcFolder,id:m0.id,read:true},'POST').catch(()=>{});m0.unread=false;renderMessageList();const current=els.items.querySelector('[data-message-key="'+CSS.escape(key)+'"]');if(current)current.classList.add('active');}
      if(replyBtn)replyBtn.onclick=()=>openCompose({account:srcAccount.id,to:m.from,subject:/^re:/i.test(m.subject||'')?m.subject:'RE: '+(m.subject||''),body:'<br><br><hr><div><b>De :</b> '+esc(m.from||'')+'<br><b>Date :</b> '+esc(m.date||'')+'<br><b>Objet :</b> '+esc(m.subject||'')+'</div>'});if(replyAllBtn)replyAllBtn.onclick=()=>openCompose({account:srcAccount.id,to:[m.from,m.to].filter(Boolean).join(', '),cc:m.cc||'',subject:/^re:/i.test(m.subject||'')?m.subject:'RE: '+(m.subject||''),body:'<br><br><hr><div><b>De :</b> '+esc(m.from||'')+'<br><b>Date :</b> '+esc(m.date||'')+'<br><b>Objet :</b> '+esc(m.subject||'')+'</div>'});if(forwardBtn)forwardBtn.onclick=()=>openCompose({account:srcAccount.id,to:'',subject:/^tr:|^fwd:/i.test(m.subject||'')?m.subject:'TR: '+(m.subject||''),body:'<br><br><hr><div><b>Message transféré</b><br><b>De :</b> '+esc(m.from||'')+'<br><b>À :</b> '+esc(m.to||'')+'<br><b>Date :</b> '+esc(m.date||'')+'<br><b>Objet :</b> '+esc(m.subject||'')+'</div><br>'+(m.html||esc(m.text||''))});
      if(unreadBtn)unreadBtn.onclick=async()=>{await req('mark_read',{account:srcAccount.id,folder:srcFolder,id:m0.id,read:m.unread},'POST');await (allMode?loadUnifiedInbox():loadMessages());};
      if(deleteBtn)deleteBtn.onclick=async()=>{if(!confirm('Supprimer ce message ?'))return;await req('delete_message',{account:srcAccount.id,folder:srcFolder,id:m0.id},'POST');await (allMode?loadUnifiedInbox():loadMessages());};
      els.preview.querySelector('[data-preview-close]').onclick=()=>els.preview.classList.remove('open');status('Message ouvert.');
    }catch(e){els.preview.innerHTML='<div class="dmd-mail-empty">'+esc(e.message)+'</div>';status(e.message,true);}
  }

  function setupSplitters(){
    const shell=$('.dmd-mail-shell'), navSplit=$('[data-splitter="nav"]'), listSplit=$('[data-splitter="list"]');
    if(!shell||!navSplit||!listSplit)return;
    const defaults={nav:220,list:380};
    const key='dmd-mail-layout-v1';
    let saved={};
    try{saved=JSON.parse(localStorage.getItem(key)||'{}')||{}}catch(_){saved={}}
    const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
    const sizes={nav:Number(saved.nav)||defaults.nav,list:Number(saved.list)||defaults.list};
    function limits(){
      const w=shell.getBoundingClientRect().width;
      return {w,navMin:160,navMax:Math.max(160,Math.min(390,w-560)),listMin:260,previewMin:300,split:10};
    }
    function apply(save=false){
      if(matchMedia('(max-width:900px)').matches){shell.style.removeProperty('--dm-nav-width');shell.style.removeProperty('--dm-list-width');return;}
      const l=limits();
      sizes.nav=clamp(sizes.nav,l.navMin,l.navMax);
      const listMax=Math.max(l.listMin,l.w-sizes.nav-l.previewMin-l.split);
      sizes.list=clamp(sizes.list,l.listMin,listMax);
      shell.style.setProperty('--dm-nav-width',Math.round(sizes.nav)+'px');
      shell.style.setProperty('--dm-list-width',Math.round(sizes.list)+'px');
      if(save){try{localStorage.setItem(key,JSON.stringify({nav:Math.round(sizes.nav),list:Math.round(sizes.list)}))}catch(_){}}
    }
    function drag(split,type,e){
      if(e.button!==0)return;
      e.preventDefault();
      const startX=e.clientX,startNav=sizes.nav,startList=sizes.list;
      split.classList.add('dragging');root.classList.add('is-splitting');
      try{split.setPointerCapture(e.pointerId)}catch(_){}
      const move=ev=>{
        const dx=ev.clientX-startX,l=limits();
        if(type==='nav'){
          const oldNav=sizes.nav;
          sizes.nav=clamp(startNav+dx,l.navMin,l.navMax);
          const listMax=Math.max(l.listMin,l.w-sizes.nav-l.previewMin-l.split);
          sizes.list=clamp(startList,l.listMin,listMax);
          if(oldNav!==sizes.nav)apply(false);
        }else{
          const listMax=Math.max(l.listMin,l.w-sizes.nav-l.previewMin-l.split);
          sizes.list=clamp(startList+dx,l.listMin,listMax);apply(false);
        }
      };
      const end=()=>{split.classList.remove('dragging');root.classList.remove('is-splitting');split.removeEventListener('pointermove',move);split.removeEventListener('pointerup',end);split.removeEventListener('pointercancel',end);apply(true)};
      split.addEventListener('pointermove',move);split.addEventListener('pointerup',end);split.addEventListener('pointercancel',end);
    }
    navSplit.addEventListener('pointerdown',e=>drag(navSplit,'nav',e));
    listSplit.addEventListener('pointerdown',e=>drag(listSplit,'list',e));
    navSplit.addEventListener('dblclick',()=>{sizes.nav=defaults.nav;apply(true)});
    listSplit.addEventListener('dblclick',()=>{sizes.list=defaults.list;apply(true)});
    let rt=0;
    const ro=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>{clearTimeout(rt);rt=setTimeout(()=>apply(false),30)}):null;
    if(ro)ro.observe(shell);else window.addEventListener('resize',()=>apply(false),{passive:true});
    apply(false);
  }

  async function loadSignatureIntoEditor(accountId,force=false){try{const j=await req('signature',{account:accountId});const sig=j.signature||{};if(sig.enabled&&sig.html){if(force||!els.editor.dataset.signatureLoaded){els.editor.innerHTML+=(els.editor.innerHTML.trim()?'<br><br>':'')+'<div data-dmd-signature>'+sig.html+'</div>';els.editor.dataset.signatureLoaded=accountId;}}}catch(_){}}
  function openCompose(seed={}){const enabled=enabledAccounts();if(!enabled.length){status('Configurez d’abord un compte.',true);return;}const f=$('[data-compose-form]');els.compose.hidden=false;const aid=seed.account||(account?account.id:enabled[0].id);els.composeAcc.value=aid;f.elements.to.value=seed.to||'';f.elements.cc.value=seed.cc||'';f.elements.bcc.value=seed.bcc||'';f.elements.subject.value=seed.subject||'';els.editor.innerHTML=seed.body||'';delete els.editor.dataset.signatureLoaded;loadSignatureIntoEditor(aid);setTimeout(()=>f.elements.to.focus(),20)}
  function closeCompose(){els.compose.hidden=true}

  els.accounts.onclick=e=>{const all=e.target.closest('[data-account-all]');if(all){folder='';loadUnifiedInbox();return;}const b=e.target.closest('[data-account]');if(!b)return;account=accounts.find(a=>a.id===b.dataset.account)||null;folder='';allMode=false;if(account)els.composeAcc.value=account.id;loadFolders();};
  els.folders.onclick=e=>{const b=e.target.closest('[data-folder]');if(!b||allMode)return;folder=b.dataset.folder;folderName=cleanFolderName(b.dataset.name);els.title.textContent=folderName;$$('[data-folder]').forEach(x=>x.classList.toggle('active',x===b));loadMessages();};
  els.items.onclick=e=>{const row=e.target.closest('[data-message-key]');if(!row)return;const key=row.dataset.messageKey;if(e.target.closest('[data-message-check]')){const cb=row.querySelector('[data-message-check]');if(!cb)return;cb.checked?checked.add(key):checked.delete(key);row.classList.toggle('checked',cb.checked);updateSelectionUi();return;}openMessage(key)};
  $$('[data-refresh]').forEach(b=>b.onclick=()=>allMode?loadUnifiedInbox():loadFolders());
  $('[data-compose]').onclick=()=>openCompose();$$('[data-compose-close]').forEach(b=>b.onclick=closeCompose);
  $$('[data-config]').forEach(b=>b.onclick=()=>{const w=window.open(cfg+'?standalone=1','DMDMailConfig','width=960,height=760,resizable=yes,scrollbars=yes');if(!w)status('Le navigateur a bloqué la fenêtre de configuration.',true)});$('[data-config-new]').onclick=()=>{const w=window.open(cfg+'?standalone=1&mode=new','DMDMailConfig','width=960,height=760,resizable=yes,scrollbars=yes');if(!w)status('Le navigateur a bloqué la fenêtre de configuration.',true)};
  els.composeAcc.onchange=()=>{els.editor.querySelectorAll('[data-dmd-signature]').forEach(x=>x.remove());delete els.editor.dataset.signatureLoaded;loadSignatureIntoEditor(els.composeAcc.value)};
    els.search.oninput=()=>{clearTimeout(searchTimer);searchTimer=setTimeout(()=>allMode?loadUnifiedInbox():loadMessages(),350)};
  $$('[data-filter]').forEach(b=>b.onclick=()=>{messageFilter=b.dataset.filter;$$('[data-filter]').forEach(x=>x.classList.toggle('active',x===b));renderMessageList()});
  function recipientToken(input){const v=input.value||'';const start=Math.max(v.lastIndexOf(','),v.lastIndexOf(';'))+1;return {start,query:v.slice(start).trim()};}
  function recipientInsert(input,contact,email){const t=recipientToken(input);const before=input.value.slice(0,t.start);const label=(contact.name&&contact.name!=='(Sans nom)')?contact.name+' <'+email+'>':email;input.value=before+(before&& !/[;,]\s*$/.test(before)?', ':'')+label+', ';input.focus();input.setSelectionRange(input.value.length,input.value.length);}
  function bindContactSuggest(input){
    if(!input)return;const box=root.querySelector('[data-contact-suggest="'+input.name+'"]');if(!box)return;let timer=0,seq=0,active=-1,rows=[];
    const hide=()=>{box.hidden=true;box.innerHTML='';active=-1;rows=[];};
    const paint=()=>{box.querySelectorAll('[data-contact-choice]').forEach((el,i)=>el.classList.toggle('active',i===active));};
    input.addEventListener('input',()=>{clearTimeout(timer);const token=recipientToken(input);if(token.query.length<1){hide();return;}timer=setTimeout(async()=>{const n=++seq;try{const j=await req('contacts',{q:token.query});if(n!==seq)return;rows=[];(j.contacts||[]).slice(0,10).forEach(c=>(c.emails||[]).forEach(email=>rows.push({contact:c,email})));if(!rows.length){hide();return;}box.innerHTML=rows.map((x,i)=>'<button type="button" class="dmd-mail-contact-choice" data-contact-choice="'+i+'"><span class="dmd-mail-contact-avatar">'+esc((x.contact.name||x.email).slice(0,1).toUpperCase())+'</span><span><strong>'+esc(x.contact.name||x.email)+'</strong><small>'+esc(x.email)+(x.contact.company?' · '+esc(x.contact.company):'')+(x.contact.is_owner?'':' · partagé')+'</small></span></button>').join('');box.hidden=false;active=-1;}catch(_){hide();}},140);});
    input.addEventListener('keydown',e=>{if(box.hidden||!rows.length)return;if(e.key==='ArrowDown'){e.preventDefault();active=(active+1)%rows.length;paint();}else if(e.key==='ArrowUp'){e.preventDefault();active=(active-1+rows.length)%rows.length;paint();}else if(e.key==='Enter'&&active>=0){e.preventDefault();recipientInsert(input,rows[active].contact,rows[active].email);hide();}else if(e.key==='Escape'){hide();}});
    box.addEventListener('mousedown',e=>{const b=e.target.closest('[data-contact-choice]');if(!b)return;e.preventDefault();const x=rows[Number(b.dataset.contactChoice)];if(x){recipientInsert(input,x.contact,x.email);hide();}});
    input.addEventListener('blur',()=>setTimeout(hide,180));
  }
  ['to','cc','bcc'].forEach(n=>bindContactSuggest($('[data-compose-form]').elements[n]));
  let dmdContactState={available:false,total:0,contacts:[]};
  async function refreshContactState(q=''){
    const badge=$('[data-contact-status]'), total=$('[data-contact-total]'), title=$('[data-contact-info-title]'), text=$('[data-contact-info-text]');
    try{
      const j=await req('contacts',{q});
      dmdContactState={available:!!j.dmd_contact_available,total:Number(j.contacts_total||0),contacts:j.contacts||[]};
      if(badge){badge.hidden=false;badge.classList.toggle('unavailable',!dmdContactState.available);badge.title=dmdContactState.available?'DMD-Contact connecté · '+dmdContactState.total+' contact(s) accessible(s)':'DMD-Contact non détecté';}
      if(total) total.textContent=String(dmdContactState.total);
      if(title) title.textContent=dmdContactState.available?'DMD-Contact connecté':'DMD-Contact non détecté';
      if(text) text.textContent=dmdContactState.available?(dmdContactState.total+' contact(s) accessible(s). Tapez un nom dans À / Cc / Cci ou ouvrez Contacts.'):'Le module DMD-Contact est absent ou inaccessible pour cet utilisateur.';
      return j;
    }catch(e){
      if(badge){badge.hidden=false;badge.classList.add('unavailable');badge.title='DMD-Contact inaccessible';}
      if(title) title.textContent='DMD-Contact inaccessible';
      if(text) text.textContent=e.message||'Impossible de lire DMD-Contact.';
      return {contacts:[],contacts_total:0,dmd_contact_available:false};
    }
  }
  refreshContactState();
  const contactPanel=$('[data-contact-browser-panel]'), contactList=$('[data-contact-browser-list]'), contactSearch=$('[data-contact-browser-search]');
  function renderContactBrowser(rows){
    if(!contactList)return;
    contactList.innerHTML=rows.length?rows.map((c,i)=>{const mails=(c.emails||[]);return '<div class="dmd-mail-contact-browser-row"><span class="dmd-mail-contact-avatar">'+esc((c.name||c.mail||'?').slice(0,1).toUpperCase())+'</span><div><strong>'+esc(c.name||c.mail||'(Sans nom)')+'</strong><small>'+esc(c.company||'')+'</small>'+mails.map((m,mi)=>'<button type="button" data-contact-browser-pick="'+i+'" data-mail-index="'+mi+'">'+esc(m)+'</button>').join('')+'</div></div>'}).join(''):'<div class="dmd-mail-contact-browser-empty">Aucun contact correspondant.</div>';
    contactList._rows=rows;
  }
  async function openContactBrowser(){
    if(!contactPanel)return;contactPanel.hidden=false;contactSearch.value='';const j=await refreshContactState('');renderContactBrowser(j.contacts||[]);setTimeout(()=>contactSearch.focus(),20);
  }
  const cb=$('[data-contact-browser]');if(cb)cb.onclick=openContactBrowser;
  const cbc=$('[data-contact-browser-close]');if(cbc)cbc.onclick=()=>contactPanel.hidden=true;
  if(contactSearch){let ct=0;contactSearch.oninput=()=>{clearTimeout(ct);ct=setTimeout(async()=>{const j=await refreshContactState(contactSearch.value.trim());renderContactBrowser(j.contacts||[])},120)};}
  if(contactList)contactList.onclick=e=>{const b=e.target.closest('[data-contact-browser-pick]');if(!b)return;const rows=contactList._rows||[];const c=rows[Number(b.dataset.contactBrowserPick)];if(!c)return;const mail=(c.emails||[])[Number(b.dataset.mailIndex)]||c.mail||'';const input=$('[data-compose-form]').elements.to;recipientInsert(input,c,mail);contactPanel.hidden=true;};
  $('[data-compose-form]').onsubmit=async e=>{e.preventDefault();els.bodyHtml.value=els.editor.innerHTML;const form=new FormData(e.currentTarget);form.set('action','send');status('Envoi du message…');try{const j=await req('send',{},'POST',form);closeCompose();e.currentTarget.reset();els.composeAcc.value=account?account.id:'';status(j.message||'Message envoyé.');setTimeout(()=>allMode?loadUnifiedInbox():loadMessages(),500)}catch(err){status(err.message,true)}};
  els.selectAll.onchange=()=>{const view=messageFilter==='unread'?messages.filter(m=>m.unread):messages;view.forEach(m=>els.selectAll.checked?checked.add(messageKey(m)):checked.delete(messageKey(m)));renderMessageList()};
  root.querySelector('[data-clear-selection]').onclick=()=>{checked.clear();renderMessageList()};
  let bulkBusy=false;
  async function bulk(op){
    if(bulkBusy)return;
    const chosen=messages.filter(m=>checked.has(messageKey(m)));
    const items=chosen.map(m=>({account:m._account||(account&&account.id)||'',folder:m._folder||folder,id:m.id}));
    if(!items.length)return;
    const target=op==='move'?els.bulkFolder.value:'';
    if(op==='move'&&!target){status('Choisissez un dossier de destination.',true);return;}
    if(op==='delete'&&!confirm('Supprimer '+items.length+' message(s) ?'))return;
    bulkBusy=true;
    const buttons=[root.querySelector('[data-bulk-read]'),root.querySelector('[data-bulk-unread]'),root.querySelector('[data-bulk-delete]'),root.querySelector('[data-bulk-move]')];
    buttons.forEach(b=>{if(b)b.disabled=true});
    status('Traitement de '+items.length+' message(s)…');
    try{
      const j=await req('bulk_action',{op,items,target},'POST');
      // Mise à jour locale immédiate : pas de rechargement complet des dossiers après Lu/Non lu.
      if(op==='read'||op==='unread'){
        const unread=op==='unread';
        chosen.forEach(m=>m.unread=unread);
        checked.clear();renderMessageList();
        status(j.message||'Messages mis à jour.');
        // Les compteurs sont rafraîchis séparément, sans bloquer l'affichage de la liste.
        setTimeout(()=>refreshBadges(),50);
      } else {
        checked.clear();
        await (allMode?loadUnifiedInbox():loadMessages());
        setTimeout(()=>refreshBadges(),50);
      }
    }catch(e){status(e.message,true)}finally{bulkBusy=false;buttons.forEach(b=>{if(b)b.disabled=false});updateSelectionUi()}
  }
  root.querySelector('[data-bulk-read]').onclick=()=>bulk('read');root.querySelector('[data-bulk-unread]').onclick=()=>bulk('unread');root.querySelector('[data-bulk-delete]').onclick=()=>bulk('delete');root.querySelector('[data-bulk-move]').onclick=()=>bulk('move');
  root.querySelector('[data-folder-add]').onclick=async()=>{if(!account||allMode)return;const under=folder&&confirm('Créer comme sous-dossier du dossier actuel ?');const name=prompt('Nom du '+(under?'sous-dossier':'dossier')+' :');if(!name)return;try{await req('create_folder',{account:account.id,name,parent:under?folder:''},'POST');await loadFolders()}catch(e){status(e.message,true)}};
  root.querySelector('[data-folder-rename]').onclick=async()=>{if(!account||allMode||!folder)return;const name=prompt('Nouveau nom du dossier :',folderName);if(!name||name===folderName)return;try{await req('rename_folder',{account:account.id,folder,name},'POST');folder='';await loadFolders()}catch(e){status(e.message,true)}};
  root.querySelector('[data-folder-delete]').onclick=async()=>{if(!account||allMode||!folder)return;if(isInbox({id:folder,name:folderName})){status('La boîte de réception ne peut pas être supprimée.',true);return;}if(!confirm('Supprimer le dossier « '+folderName+' » ?'))return;try{await req('delete_folder',{account:account.id,folder},'POST');folder='';await loadFolders()}catch(e){status(e.message,true)}};
  root.querySelectorAll('[data-cmd]').forEach(b=>b.onclick=()=>{els.editor.focus();document.execCommand(b.dataset.cmd,false,null)});root.querySelector('[data-font-size]').onchange=e=>{if(e.target.value){els.editor.focus();document.execCommand('fontSize',false,e.target.value);e.target.value=''}};root.querySelector('[data-link]').onclick=()=>{const u=prompt('Adresse du lien :','https://');if(u){els.editor.focus();document.execCommand('createLink',false,u)}};
  const inlineFile=root.querySelector('[data-inline-file]');root.querySelector('[data-inline-image]').onclick=()=>inlineFile.click();inlineFile.onchange=()=>{const f=inlineFile.files&&inlineFile.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{els.editor.focus();document.execCommand('insertImage',false,String(r.result));inlineFile.value=''};r.readAsDataURL(f)};
  async function openSignature(){const aid=els.composeAcc.value||(account&&account.id);if(!aid)return;els.signatureModal.hidden=false;els.signatureModal.dataset.account=aid;try{const j=await req('signature',{account:aid});els.signatureEditor.innerHTML=(j.signature&&j.signature.html)||'';els.signatureEnabled.checked=!(j.signature&&j.signature.enabled===false)}catch(e){status(e.message,true)}}
  root.querySelector('[data-signature-edit]').onclick=openSignature;root.querySelectorAll('[data-signature-close]').forEach(b=>b.onclick=()=>els.signatureModal.hidden=true);root.querySelectorAll('[data-sig-cmd]').forEach(b=>b.onclick=()=>{els.signatureEditor.focus();document.execCommand(b.dataset.sigCmd,false,null)});root.querySelector('[data-sig-link]').onclick=()=>{const u=prompt('Adresse du lien :','https://');if(u){els.signatureEditor.focus();document.execCommand('createLink',false,u)}};const sigFile=root.querySelector('[data-sig-file]');root.querySelector('[data-sig-image]').onclick=()=>sigFile.click();sigFile.onchange=()=>{const f=sigFile.files&&sigFile.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{els.signatureEditor.focus();document.execCommand('insertImage',false,String(r.result));sigFile.value=''};r.readAsDataURL(f)};root.querySelector('[data-signature-save]').onclick=async()=>{try{await req('save_signature',{account:els.signatureModal.dataset.account,html:els.signatureEditor.innerHTML,enabled:els.signatureEnabled.checked},'POST');els.signatureModal.hidden=true;els.editor.querySelectorAll('[data-dmd-signature]').forEach(x=>x.remove());delete els.editor.dataset.signatureLoaded;await loadSignatureIntoEditor(els.composeAcc.value,true);status('Signature enregistrée.')}catch(e){status(e.message,true)}};

  function initFloatingDialog(modal, storageKey){
    if(!modal)return;const dialog=modal.querySelector('.dmd-mail-dialog'),head=modal.querySelector('.dmd-mail-dialog-head');if(!dialog||!head)return;
    dialog.classList.add('dmd-mail-dialog-floating');
    const key='dmd-mail-dialog-'+storageKey;
    function clamp(){const r=modal.getBoundingClientRect(),d=dialog.getBoundingClientRect();let left=parseFloat(dialog.style.left)||Math.max(8,(r.width-d.width)/2),top=parseFloat(dialog.style.top)||24;left=Math.max(6,Math.min(left,Math.max(6,r.width-d.width-6)));top=Math.max(6,Math.min(top,Math.max(6,r.height-d.height-6)));dialog.style.left=left+'px';dialog.style.top=top+'px';}
    function restore(){try{const v=JSON.parse(localStorage.getItem(key)||'{}');if(v.w)dialog.style.width=v.w+'px';if(v.h)dialog.style.height=v.h+'px';if(Number.isFinite(v.x))dialog.style.left=v.x+'px';if(Number.isFinite(v.y))dialog.style.top=v.y+'px';}catch(_){}clamp();}
    function save(){try{localStorage.setItem(key,JSON.stringify({x:parseFloat(dialog.style.left)||0,y:parseFloat(dialog.style.top)||0,w:dialog.offsetWidth,h:dialog.offsetHeight}))}catch(_){}}
    new ResizeObserver(()=>{clamp();save()}).observe(dialog);
    head.style.cursor='move';head.addEventListener('pointerdown',e=>{if(e.button!==0||e.target.closest('button,input,select,a'))return;e.preventDefault();const r=dialog.getBoundingClientRect(),mr=modal.getBoundingClientRect(),sx=e.clientX,sy=e.clientY,x=r.left-mr.left,y=r.top-mr.top;head.setPointerCapture&&head.setPointerCapture(e.pointerId);const move=ev=>{dialog.style.left=(x+ev.clientX-sx)+'px';dialog.style.top=(y+ev.clientY-sy)+'px';clamp()};const end=()=>{head.removeEventListener('pointermove',move);head.removeEventListener('pointerup',end);head.removeEventListener('pointercancel',end);save()};head.addEventListener('pointermove',move);head.addEventListener('pointerup',end);head.addEventListener('pointercancel',end)});
    const obs=new MutationObserver(()=>{if(!modal.hidden)requestAnimationFrame(restore)});obs.observe(modal,{attributes:true,attributeFilter:['hidden']});restore();
  }
  initFloatingDialog(els.compose,'compose');
  initFloatingDialog(els.signatureModal,'signature');

  window.addEventListener('message',ev=>{if(ev.origin!==location.origin||!ev.data)return;if(ev.data.type==='dmd-mail-accounts-changed'){const keep=account&&account.id;fetch(api+'?action=bootstrap',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(j=>{if(!j.ok)return;accounts=j.accounts||[];account=(keep&&accounts.find(a=>a.id===keep))||accounts.find(a=>a.id===ev.data.account)||accounts[0]||null;allMode=accounts.filter(a=>a.enabled!==false).length>1&&allMode;renderAccounts();refreshBadges();if(account&&!allMode)loadFolders();else if(allMode)loadUnifiedInbox();});return;}if(ev.data.type!=='dmd-mail-oauth')return;status(ev.data.message||'Connexion terminée.',!ev.data.ok);fetch(api+'?action=bootstrap',{credentials:'same-origin',cache:'no-store'}).then(r=>r.json()).then(j=>{if(j.ok){accounts=j.accounts||[];renderAccounts();refreshBadges();if(account){account=accounts.find(a=>a.id===account.id)||accounts[0];loadFolders();}}})});

  async function applyActionHubUi(ui){
    if(!ui||typeof ui!=='object')return;
    const type=String(ui.type||'');
    const accountId=String(ui.account_id||'');
    const target=accountId?accounts.find(a=>a.id===accountId):null;
    if(type==='dmd-mail.compose'){
      openCompose({account:accountId||(account&&account.id)||'',to:ui.to||'',cc:ui.cc||'',bcc:ui.bcc||'',subject:ui.subject||'',body:ui.body||''});
      return;
    }
    if(target){account=target;allMode=false;folder='';renderAccounts();els.composeAcc.value=target.id;}
    if(type==='dmd-mail.search'){
      els.search.value=String(ui.query||'');
      messageFilter='all';$$('[data-filter]').forEach(x=>x.classList.toggle('active',x.dataset.filter==='all'));
      if(account)await loadFolders();
      return;
    }
    if(type==='dmd-mail.open-unread'){
      messageFilter='unread';$$('[data-filter]').forEach(x=>x.classList.toggle('active',x.dataset.filter==='unread'));
      if(account)await loadFolders();
      return;
    }
    if(type==='dmd-mail.open-inbox'){
      messageFilter='all';$$('[data-filter]').forEach(x=>x.classList.toggle('active',x.dataset.filter==='all'));
      if(account)await loadFolders();
    }
  }
  document.addEventListener('dmd:actionhub-ui-action',ev=>{
    const detail=ev&&ev.detail&&typeof ev.detail==='object'?ev.detail:{};
    if(String(detail.module||'').toLowerCase()!=='dmd-mail')return;
    applyActionHubUi(detail.ui||{}).catch(err=>status(err&&err.message?err.message:String(err),true));
  });

  // Les droits restent contrôlés côté serveur ; l'UI masque aussi les commandes non autorisées.
  const composeBtn=$('[data-compose]');if(composeBtn&&!can('mail.send'))composeBtn.hidden=true;
  $$('[data-config]').forEach(b=>{if(!can('config.view','config.edit'))b.hidden=true;});
  const configNew=$('[data-config-new]');if(configNew&&!can('accounts.create','config.edit'))configNew.hidden=true;
  if(els.search&&!can('mail.search'))els.search.disabled=true;

  setupSplitters(); renderAccounts(); if(account)loadFolders();
})();
</script>
