<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
$token=(string)($_POST['t']??$_GET['t']??'');$share=dmdphotos_share_lookup($token);if(!$share||!dmdphotos_share_authorized($share,$token,'')||empty($share['allow_upload'])){http_response_code(403);exit('Dépôt invité non autorisé.');}if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST'||empty($_FILES['files'])){header('Location: DMD-Photos_share.php?t='.rawurlencode($token));exit;}$cfg=dmdphotos_config();$f=$_FILES['files'];$names=is_array($f['name'])?$f['name']:array($f['name']);$tmps=is_array($f['tmp_name'])?$f['tmp_name']:array($f['tmp_name']);$errs=is_array($f['error'])?$f['error']:array($f['error']);$max=(int)(dmdphotos_db_one('SELECT COALESCE(MAX(position),0) p FROM album_items WHERE album_id=?',array($share['album_id']))['p']??0);foreach($names as $i=>$name){if((int)($errs[$i]??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)continue;$size=(int)(@filesize($tmps[$i])?:0);if($size>$cfg['guest_upload_max_mb']*1024*1024)continue;$ext=dmdphotos_safe_ext((string)$name);$mime=dmdphotos_detect_mime((string)$tmps[$i]);$type=dmdphotos_media_type($mime,$ext);if($type==='video'&&!dmdphotos_can((string)$share['album_owner'],'library.video_upload'))continue;$r=dmdphotos_add_file((string)$tmps[$i],(string)$name,(string)$share['album_owner'],true);if(!empty($r['ok'])&&!empty($r['id'])){$max++;dmdphotos_db_exec('INSERT OR IGNORE INTO album_items(album_id,media_id,position,added_by,added_at) VALUES(?,?,?,?,?)',array($share['album_id'],$r['id'],$max,'guest-share:'.$share['id'],dmdphotos_now()));}}dmdphotos_run_jobs(4);header('Location: DMD-Photos_share.php?t='.rawurlencode($token));exit;
