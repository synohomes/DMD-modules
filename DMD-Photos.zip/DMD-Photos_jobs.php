<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



function dmdphotos_job_enqueue($type,$owner='',$mediaId='',$payload=array()){
    $id=dmdphotos_id('JB');$ok=dmdphotos_db_exec('INSERT INTO jobs(id,type,owner_email,media_id,payload_json,status,progress,attempts,error,created_at,started_at,finished_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',array($id,(string)$type,(string)$owner,(string)$mediaId,json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'pending',0,0,'',dmdphotos_now(),'',''));return$ok?$id:'';
}
function dmdphotos_job_exists($type,$mediaId){$r=dmdphotos_db_one('SELECT id FROM jobs WHERE type=? AND media_id=? AND status IN ("pending","running") LIMIT 1',array($type,$mediaId));return(bool)$r;}
function dmdphotos_enqueue_media_jobs($mediaId,$owner,$type){foreach(array('thumbnail','preview','phash') as $t){if($t==='preview'&&$type==='video')continue;if(!dmdphotos_job_exists($t,$mediaId))dmdphotos_job_enqueue($t,$owner,$mediaId);}if($type==='video'&&!dmdphotos_job_exists('video_transcode',$mediaId))dmdphotos_job_enqueue('video_transcode',$owner,$mediaId);$cfg=dmdphotos_config();if(!empty($cfg['ml_enabled'])&&!dmdphotos_job_exists('ai_index',$mediaId))dmdphotos_job_enqueue('ai_index',$owner,$mediaId);}
function dmdphotos_ml_request($path,$payload){$cfg=dmdphotos_config();if(empty($cfg['ml_enabled'])||!function_exists('curl_init'))return array('ok'=>false,'error'=>'Moteur IA inactif.');$url=rtrim((string)$cfg['ml_endpoint'],'/').'/'.ltrim($path,'/');$ch=curl_init($url);$headers=array('Content-Type: application/json');if(trim((string)$cfg['ml_token'])!=='')$headers[]='Authorization: Bearer '.trim((string)$cfg['ml_token']);curl_setopt_array($ch,array(CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_HTTPHEADER=>$headers,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>3,CURLOPT_TIMEOUT=>120));$raw=@curl_exec($ch);$err=curl_error($ch);$code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);if($raw===false||$code<200||$code>=300)return array('ok'=>false,'error'=>$err!==''?$err:'HTTP '.$code);$j=json_decode($raw,true);return is_array($j)?array_merge(array('ok'=>true),$j):array('ok'=>false,'error'=>'Réponse IA invalide.');}
function dmdphotos_cosine_similarity($a,$b){if(!is_array($a)||!is_array($b)||count($a)!==count($b)||!$a)return-1;$dot=0.0;$na=0.0;$nb=0.0;for($i=0;$i<count($a);$i++){$x=(float)$a[$i];$y=(float)$b[$i];$dot+=$x*$y;$na+=$x*$x;$nb+=$y*$y;}return($na>0&&$nb>0)?$dot/(sqrt($na)*sqrt($nb)):-1;}
function dmdphotos_face_person_for_embedding($owner,$embedding){if(!is_array($embedding)||count($embedding)<8)return'';$rows=dmdphotos_db_all('SELECT f.person_id,f.embedding_json FROM faces f JOIN media m ON m.id=f.media_id WHERE m.owner_email=? AND f.person_id<>"" AND f.embedding_json<>"" ORDER BY f.created_at DESC LIMIT 5000',array($owner));$best='';$score=-1;foreach($rows as $r){$v=json_decode((string)$r['embedding_json'],true);$s=dmdphotos_cosine_similarity($embedding,$v);if($s>$score){$score=$s;$best=(string)$r['person_id'];}}$threshold=(float)(dmdphotos_config()['face_match_threshold']??0.72);if($best!==''&&$score>=$threshold)return$best;$count=(int)(dmdphotos_db_one('SELECT COUNT(*) c FROM people WHERE owner_email=? AND name LIKE "Personne %"',array($owner))['c']??0);$pid=dmdphotos_id('PE');dmdphotos_db_exec('INSERT INTO people(id,owner_email,name,cover_media_id,created_at,updated_at) VALUES(?,?,?,?,?,?)',array($pid,$owner,'Personne '.($count+1),'',dmdphotos_now(),dmdphotos_now()));return$pid;}
function dmdphotos_ai_store($m,$analysis){$caption=(string)($analysis['caption']??'');$keywords=array_values(array_filter(array_map('strval',(array)($analysis['keywords']??array()))));$emb=$analysis['embedding']??array();$keywordsJson=json_encode($keywords,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);dmdphotos_db_exec('INSERT INTO media_ai(media_id,caption,keywords_json,embedding_json,indexed_at) VALUES(?,?,?,?,?) ON CONFLICT(media_id) DO UPDATE SET caption=excluded.caption,keywords_json=excluded.keywords_json,embedding_json=excluded.embedding_json,indexed_at=excluded.indexed_at',array($m['id'],$caption,$keywordsJson,json_encode($emb),dmdphotos_now()));if(dmdphotos_fts_available())dmdphotos_db_exec('UPDATE media_search SET caption=?,keywords=? WHERE media_id=?',array($caption,$keywordsJson,$m['id']));dmdphotos_db_exec('DELETE FROM faces WHERE media_id=? AND person_id=""',array($m['id']));foreach((array)($analysis['faces']??array()) as $f){$bbox=$f['bbox']??array();$embedding=$f['embedding']??array();$person=dmdphotos_face_person_for_embedding((string)$m['owner_email'],$embedding);dmdphotos_db_exec('INSERT INTO faces(id,media_id,person_id,bbox_json,confidence,embedding_json,created_at) VALUES(?,?,?,?,?,?,?)',array(dmdphotos_id('FC'),$m['id'],$person,json_encode($bbox),(float)($f['confidence']??0),json_encode($embedding),dmdphotos_now()));if($person!=='')dmdphotos_db_exec('UPDATE people SET cover_media_id=CASE WHEN cover_media_id="" THEN ? ELSE cover_media_id END,updated_at=? WHERE id=?',array($m['id'],dmdphotos_now(),$person));}}
function dmdphotos_job_process($job){$id=(string)$job['id'];$type=(string)$job['type'];$m=$job['media_id']!==''?dmdphotos_media_row((string)$job['media_id']):null;$payload=json_decode((string)$job['payload_json'],true);if(!is_array($payload))$payload=array();$ok=false;$err='';$progress=100;try{
        if($type==='thumbnail'){$ok=$m?dmdphotos_make_thumb($m):false;$err=$ok?'':'Miniature impossible.';}
        elseif($type==='preview'){$ok=$m?dmdphotos_make_preview($m):false;$err=$ok?'':'Aperçu impossible.';}
        elseif($type==='phash'){$ph=$m?dmdphotos_phash($m):'';$ok=$ph!=='';$err=$ok?'':'Empreinte visuelle impossible.';if($ok)dmdphotos_db_exec('UPDATE media SET phash=?,updated_at=? WHERE id=?',array($ph,dmdphotos_now(),$m['id']));}
        elseif($type==='video_transcode'){$cfg=dmdphotos_config();if(empty($cfg['video_transcode'])){$ok=true;}else{$ok=$m?dmdphotos_make_transcode($m):false;$err=$ok?'':'Transcodage impossible ou FFmpeg indisponible.';}}
        elseif($type==='ai_index'){$r=$m?dmdphotos_ml_request('/analyze',array('path'=>$m['absolute_path'],'media_id'=>$m['id'],'mime'=>$m['mime'])):array('ok'=>false,'error'=>'Média introuvable.');$ok=!empty($r['ok']);$err=$ok?'':(string)($r['error']??'Analyse IA impossible.');if($ok)dmdphotos_ai_store($m,$r);}
        elseif($type==='import_source'){$sid=(string)($payload['source_id']??'');$src=dmdphotos_db_one('SELECT * FROM import_sources WHERE id=?',array($sid));if(!$src)throw new RuntimeException('Source introuvable.');$owner=(string)($src['owner_email']??'');if($owner==='')$owner=(string)($job['owner_email']??'');$started=dmdphotos_now();$r=dmdphotos_scan_path((string)$src['path'],$owner,(int)($payload['limit']??dmdphotos_config()['scan_batch']),!empty($src['recursive']));dmdphotos_db_exec('UPDATE import_sources SET last_scan_at=?,updated_at=? WHERE id=?',array(dmdphotos_now(),dmdphotos_now(),$sid));dmdphotos_db_exec('INSERT INTO import_history(id,source_id,owner_email,checked,imported,duplicates,errors,started_at,finished_at,details_json) VALUES(?,?,?,?,?,?,?,?,?,?)',array(dmdphotos_id('IH'),$sid,$owner,$r['checked'],$r['imported'],$r['duplicates'],$r['errors'],$started,dmdphotos_now(),json_encode($r)));$ok=true;}
        elseif($type==='rebuild_media'){$mid=(string)($payload['media_id']??$job['media_id']);$m=dmdphotos_media_row($mid);if(!$m)throw new RuntimeException('Média introuvable.');foreach(array(dmdphotos_thumb_file($mid),dmdphotos_preview_file($mid)) as $f)if(is_file($f))@unlink($f);dmdphotos_enqueue_media_jobs($mid,(string)$m['owner_email'],(string)$m['media_type']);$ok=true;}
        else{$err='Type de job inconnu.';}
    }catch(Throwable $e){$ok=false;$err=$e->getMessage();}
    dmdphotos_db_exec('UPDATE jobs SET status=?,progress=?,error=?,finished_at=? WHERE id=?',array($ok?'done':'failed',$ok?$progress:0,$err,dmdphotos_now(),$id));return array('ok'=>$ok,'error'=>$err,'id'=>$id,'type'=>$type);
}
function dmdphotos_run_jobs($limit=3){$limit=max(1,min(50,(int)$limit));$out=array();for($i=0;$i<$limit;$i++){$pdo=dmdphotos_db();if(!$pdo)break;try{$pdo->beginTransaction();$job=dmdphotos_db_one('SELECT * FROM jobs WHERE status="pending" ORDER BY created_at LIMIT 1');if(!$job){$pdo->commit();break;}$changed=dmdphotos_db_exec('UPDATE jobs SET status="running",attempts=attempts+1,started_at=?,error="" WHERE id=? AND status="pending"',array(dmdphotos_now(),$job['id']));$pdo->commit();if(!$changed)continue;$job=dmdphotos_db_one('SELECT * FROM jobs WHERE id=?',array($job['id']));$out[]=dmdphotos_job_process($job);}catch(Throwable $e){if($pdo&&$pdo->inTransaction())$pdo->rollBack();break;}}return$out;}
function dmdphotos_jobs_summary($limit=100){$rows=dmdphotos_db_all('SELECT * FROM jobs ORDER BY created_at DESC LIMIT '.max(1,min(500,(int)$limit)));return$rows;}
function dmdphotos_smart_search($email,$query,$limit=120){
    $cfg=dmdphotos_config();if(empty($cfg['ml_enabled']))return array('available'=>false,'items'=>array(),'error'=>'Le moteur IA n’est pas activé.');
    $r=dmdphotos_ml_request('/embed_text',array('text'=>(string)$query));if(empty($r['ok'])||empty($r['embedding'])||!is_array($r['embedding']))return array('available'=>false,'items'=>array(),'error'=>(string)($r['error']??'Embedding texte impossible.'));
    $qv=array_map('floatval',$r['embedding']);list($access,$params)=dmdphotos_access_sql($email,'m');
    $sql='SELECT m.*,a.embedding_json,a.caption,a.keywords_json FROM media m JOIN media_ai a ON a.media_id=m.id WHERE '.$access.' AND m.trashed_at="" LIMIT '.max(100,min(50000,(int)$cfg['smart_search_limit']));
    $rows=dmdphotos_db_all($sql,$params);$scored=array();foreach($rows as $m){$v=json_decode((string)$m['embedding_json'],true);if(!is_array($v)||count($v)!==count($qv))continue;$score=dmdphotos_cosine_similarity($qv,$v);if($score<0)continue;$m['_score']=$score;$scored[]=$m;}
    usort($scored,function($a,$b){if($a['_score']==$b['_score'])return 0;return$a['_score']>$b['_score']?-1:1;});$items=array();foreach(array_slice($scored,0,max(1,min(300,(int)$limit))) as $m)$items[]=dmdphotos_media_public($m,$email);return array('available'=>true,'items'=>$items);
}
