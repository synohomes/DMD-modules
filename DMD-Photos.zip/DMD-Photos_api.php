<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
header('X-Content-Type-Options: nosniff');
$email=dmdphotos_email();
if($email===''||!dmdphotos_can($email,'module.view'))dmdphotos_json_response(false,array('error'=>'Accès refusé.'),403);
$method=(string)($_SERVER['REQUEST_METHOD']??'GET');$input=array();
if($method==='POST'){$raw=@file_get_contents('php://input');$json=is_string($raw)?json_decode($raw,true):null;$input=is_array($json)?$json:$_POST;}else$input=$_GET;
$action=strtolower(trim((string)($input['action']??'bootstrap')));
$mutations=array('favorite','trash','restore','delete_permanent','photo_update','bulk_trash','bulk_restore','bulk_delete_permanent','album_create','album_update','album_delete','album_add','album_remove','album_bulk_add','album_bulk_remove','album_cover_set','frame_save','config_save','scan');
if(in_array($action,$mutations,true)){$token=(string)($input['csrf']??($_SERVER['HTTP_X_CSRF_TOKEN']??''));if(!dmdphotos_csrf_valid($token))dmdphotos_json_response(false,array('error'=>'Jeton de sécurité expiré.'),403);}

function dmdphotos_api_ids($value){$ids=is_array($value)?$value:array($value);$out=array();foreach($ids as $id){$id=trim((string)$id);if($id!=='')$out[$id]=true;}return array_keys($out);}
function dmdphotos_api_album_cleanup_deleted($ids){$ids=array_values(array_unique(array_map('strval',(array)$ids)));if(!$ids)return true;list($ok)=dmdphotos_mutate_json(dmdphotos_albums_file(),array('schema'=>1,'items'=>array()),function(&$a)use($ids){foreach($a['items'] as &$album){if(!is_array($album))continue;$album['items']=array_values(array_diff(array_map('strval',(array)($album['items']??array())),$ids));if(in_array((string)($album['cover_id']??''),$ids,true))$album['cover_id']='';$album['updated_at']=date('c');}unset($album);return true;});return $ok;}

if($action==='bootstrap'){
    $perms=dmdphotos_permissions($email);$albums=array();foreach(dmdphotos_accessible_albums($email) as $id=>$a){$a['id']=$id;$albums[]=dmdphotos_album_public($a,$email);}usort($albums,function($a,$b){return strcasecmp((string)$a['name'],(string)$b['name']);});
    $data=array('csrf'=>dmdphotos_csrf(),'permissions'=>$perms,'stats'=>dmdphotos_stats($email),'albums'=>$albums,'prefs'=>dmdphotos_user_prefs($email),'version'=>DMDPHOTOS_VERSION);
    if(!empty($perms['albums.share'])||!empty($perms['admin.configure']))$data['directory']=dmdphotos_users_roles();
    dmdphotos_json_response(true,$data);
}
if($action==='list')dmdphotos_json_response(true,dmdphotos_list($email,$input));

if($action==='favorite'){
    $id=(string)($input['id']??'');$db=dmdphotos_load_photos();
    if(empty($db['items'][$id])||!dmdphotos_photo_accessible($db['items'][$id],$email))dmdphotos_json_response(false,array('error'=>'Photo introuvable.'),404);
    $prefs=dmdphotos_user_prefs($email);$f=array_values(array_unique(array_map('strval',$prefs['favorites'])));
    if(in_array($id,$f,true))$f=array_values(array_diff($f,array($id)));else$f[]=$id;
    $prefs['favorites']=$f;dmdphotos_save_user_prefs($email,$prefs);dmdphotos_json_response(true,array('favorite'=>in_array($id,$f,true)));
}

if(in_array($action,array('bulk_trash','bulk_restore','bulk_delete_permanent'),true)){
    $ids=dmdphotos_api_ids($input['ids']??array());if(!$ids)dmdphotos_json_response(false,array('error'=>'Aucun média sélectionné.'),400);
    $db=dmdphotos_load_photos();$allowed=array();$paths=array();$thumbs=array();
    foreach($ids as $id){$p=$db['items'][$id]??null;if(!is_array($p)||!dmdphotos_can_manage_photo($p,$email,true))continue;$allowed[]=$id;if($action==='bulk_delete_permanent'){$paths[$id]=(string)($p['absolute_path']??'');$thumbs[$id]=dmdphotos_thumb_file($id);}}
    if(!$allowed)dmdphotos_json_response(false,array('error'=>'Aucun des médias sélectionnés ne peut être modifié.'),403);
    list($ok)=dmdphotos_mutate_json(dmdphotos_photos_file(),array('schema'=>1,'items'=>array()),function(&$x)use($allowed,$action){foreach($allowed as $id){if(empty($x['items'][$id]))continue;if($action==='bulk_delete_permanent')unset($x['items'][$id]);else{$x['items'][$id]['trashed_at']=$action==='bulk_trash'?date('c'):'';$x['items'][$id]['updated_at']=date('c');}}$x['updated_at']=date('c');return true;});
    if(!$ok)dmdphotos_json_response(false,array('error'=>'Action groupée impossible.'),500);
    if($action==='bulk_delete_permanent'){foreach($allowed as $id){if(!empty($paths[$id])&&is_file($paths[$id]))@unlink($paths[$id]);if(!empty($thumbs[$id])&&is_file($thumbs[$id]))@unlink($thumbs[$id]);}dmdphotos_api_album_cleanup_deleted($allowed);}
    dmdphotos_json_response(true,array('processed'=>count($allowed),'skipped'=>count($ids)-count($allowed)));
}

if(in_array($action,array('trash','restore','delete_permanent','photo_update'),true)){
    $id=(string)($input['id']??'');$db=dmdphotos_load_photos();$p=$db['items'][$id]??null;if(!is_array($p))dmdphotos_json_response(false,array('error'=>'Photo introuvable.'),404);
    if($action==='photo_update'){
        if(!dmdphotos_can_manage_photo($p,$email,false))dmdphotos_json_response(false,array('error'=>'Modification non autorisée.'),403);
        $title=trim((string)($input['title']??''));$description=trim((string)($input['description']??''));$tags=$input['tags']??array();if(is_string($tags))$tags=preg_split('/[,;]+/',$tags);$tags=array_values(array_unique(array_filter(array_map('trim',(array)$tags))));$captured=trim((string)($input['captured_at']??''));
        list($ok)=dmdphotos_mutate_json(dmdphotos_photos_file(),array('schema'=>1,'items'=>array()),function(&$x)use($id,$title,$description,$tags,$captured){if(empty($x['items'][$id]))return false;$x['items'][$id]['title']=$title;$x['items'][$id]['description']=$description;$x['items'][$id]['tags']=$tags;if($captured!=='')$x['items'][$id]['captured_at']=$captured;$x['items'][$id]['updated_at']=date('c');return true;});
        if(!$ok)dmdphotos_json_response(false,array('error'=>'Enregistrement impossible.'),500);dmdphotos_json_response(true,array());
    }
    if(!dmdphotos_can_manage_photo($p,$email,true))dmdphotos_json_response(false,array('error'=>'Suppression non autorisée.'),403);
    if($action==='delete_permanent'){
        $path=(string)($p['absolute_path']??'');$thumb=dmdphotos_thumb_file($id);
        list($ok)=dmdphotos_mutate_json(dmdphotos_photos_file(),array('schema'=>1,'items'=>array()),function(&$x)use($id){unset($x['items'][$id]);$x['updated_at']=date('c');return true;});
        if(!$ok)dmdphotos_json_response(false,array('error'=>'Suppression impossible.'),500);if(is_file($path))@unlink($path);if(is_file($thumb))@unlink($thumb);dmdphotos_api_album_cleanup_deleted(array($id));dmdphotos_json_response(true,array());
    }
    $stamp=$action==='trash'?date('c'):'';list($ok)=dmdphotos_mutate_json(dmdphotos_photos_file(),array('schema'=>1,'items'=>array()),function(&$x)use($id,$stamp){if(empty($x['items'][$id]))return false;$x['items'][$id]['trashed_at']=$stamp;$x['items'][$id]['updated_at']=date('c');return true;});if(!$ok)dmdphotos_json_response(false,array('error'=>'Action impossible.'),500);dmdphotos_json_response(true,array());
}

if(strpos($action,'album_')===0){
    if($action==='album_create'){
        if(!dmdphotos_can($email,'albums.create'))dmdphotos_json_response(false,array('error'=>'Création d’album non autorisée.'),403);
        $name=trim((string)($input['name']??''));if($name==='')dmdphotos_json_response(false,array('error'=>'Nom obligatoire.'),400);
        $visibility=(string)($input['visibility']??'private');if(!in_array($visibility,array('private','everyone','selected'),true))$visibility='private';$users=array_values(array_unique(array_filter(array_map('trim',(array)($input['shared_users']??array())))));$roles=array_values(array_unique(array_filter(array_map('trim',(array)($input['shared_roles']??array())))));
        if(($visibility!=='private'||$users||$roles)&&!dmdphotos_can($email,'albums.share'))dmdphotos_json_response(false,array('error'=>'Partage non autorisé.'),403);
        $id=dmdphotos_id('AL');$row=array('id'=>$id,'owner_email'=>$email,'name'=>substr($name,0,120),'description'=>trim((string)($input['description']??'')),'visibility'=>$visibility,'shared_users'=>$users,'shared_roles'=>$roles,'items'=>array(),'cover_id'=>'','created_at'=>date('c'),'updated_at'=>date('c'));
        list($ok)=dmdphotos_mutate_json(dmdphotos_albums_file(),array('schema'=>1,'items'=>array()),function(&$x)use($id,$row){$x['items'][$id]=$row;return true;});dmdphotos_json_response($ok,array('album'=>$row,'error'=>$ok?'':'Création impossible.'),$ok?200:500);
    }
    $aid=(string)($input['album_id']??($input['id']??''));$db=dmdphotos_load_albums();$album=$db['items'][$aid]??null;
    if(!is_array($album)||!dmdphotos_album_visible($album,$email))dmdphotos_json_response(false,array('error'=>'Album introuvable.'),404);
    if($action==='album_delete'){if(!dmdphotos_can_delete_album($album,$email))dmdphotos_json_response(false,array('error'=>'Suppression de cet album non autorisée.'),403);list($ok)=dmdphotos_mutate_json(dmdphotos_albums_file(),array('schema'=>1,'items'=>array()),function(&$x)use($aid){unset($x['items'][$aid]);return true;});dmdphotos_json_response($ok,array('error'=>$ok?'':'Suppression impossible.'),$ok?200:500);}
    if(!dmdphotos_can_manage_album($album,$email))dmdphotos_json_response(false,array('error'=>'Gestion de cet album non autorisée.'),403);
    if($action==='album_update'){
        $name=trim((string)($input['name']??$album['name']));$description=trim((string)($input['description']??($album['description']??'')));$visibility=(string)($input['visibility']??($album['visibility']??'private'));if(!in_array($visibility,array('private','everyone','selected'),true))$visibility='private';$users=array_values(array_unique(array_filter(array_map('trim',(array)($input['shared_users']??array())))));$roles=array_values(array_unique(array_filter(array_map('trim',(array)($input['shared_roles']??array())))));if(($visibility!=='private'||$users||$roles)&&!dmdphotos_can($email,'albums.share'))dmdphotos_json_response(false,array('error'=>'Partage non autorisé.'),403);
        list($ok)=dmdphotos_mutate_json(dmdphotos_albums_file(),array('schema'=>1,'items'=>array()),function(&$x)use($aid,$name,$description,$visibility,$users,$roles){$a=&$x['items'][$aid];$a['name']=substr($name,0,120);$a['description']=$description;$a['visibility']=$visibility;$a['shared_users']=$users;$a['shared_roles']=$roles;$a['updated_at']=date('c');return true;});dmdphotos_json_response($ok,array('error'=>$ok?'':'Enregistrement impossible.'),$ok?200:500);
    }
    if(in_array($action,array('album_add','album_remove','album_bulk_add','album_bulk_remove','album_cover_set'),true)){
        $photos=dmdphotos_load_photos()['items'];
        $ids=in_array($action,array('album_bulk_add','album_bulk_remove'),true)?dmdphotos_api_ids($input['photo_ids']??array()):dmdphotos_api_ids($input['photo_id']??'');
        if(!$ids)dmdphotos_json_response(false,array('error'=>'Aucun média sélectionné.'),400);
        $valid=array();foreach($ids as $pid){$p=$photos[$pid]??null;if(is_array($p)&&dmdphotos_photo_accessible($p,$email)&&empty($p['trashed_at']))$valid[]=$pid;}
        if(!$valid)dmdphotos_json_response(false,array('error'=>'Aucun média accessible dans la sélection.'),404);
        if($action==='album_cover_set'){
            $pid=$valid[0];$p=$photos[$pid];if(($p['media_type']??'image')!=='image')dmdphotos_json_response(false,array('error'=>'La pochette doit être une image.'),400);
            list($ok)=dmdphotos_mutate_json(dmdphotos_albums_file(),array('schema'=>1,'items'=>array()),function(&$x)use($aid,$pid){$items=array_values(array_unique(array_map('strval',(array)($x['items'][$aid]['items']??array()))));if(!in_array($pid,$items,true))$items[]=$pid;$x['items'][$aid]['items']=$items;$x['items'][$aid]['cover_id']=$pid;$x['items'][$aid]['updated_at']=date('c');return true;});dmdphotos_json_response($ok,array('cover_id'=>$pid,'error'=>$ok?'':'Pochette impossible.'),$ok?200:500);
        }
        $remove=in_array($action,array('album_remove','album_bulk_remove'),true);
        list($ok,$processed)=dmdphotos_mutate_json(dmdphotos_albums_file(),array('schema'=>1,'items'=>array()),function(&$x)use($aid,$valid,$remove,$photos){$a=&$x['items'][$aid];$items=array_values(array_unique(array_map('strval',(array)($a['items']??array()))));$before=count($items);if($remove)$items=array_values(array_diff($items,$valid));else foreach($valid as $pid)if(!in_array($pid,$items,true))$items[]=$pid;$a['items']=$items;if($remove&&in_array((string)($a['cover_id']??''),$valid,true))$a['cover_id']='';if(!$remove&&(string)($a['cover_id']??'')===''){foreach($items as $pid){$p=$photos[$pid]??null;if(is_array($p)&&(($p['media_type']??'image')==='image')&&empty($p['trashed_at'])){$a['cover_id']=$pid;break;}}}$a['updated_at']=date('c');return $remove?($before-count($items)):(count($items)-$before);});
        if(!$ok)dmdphotos_json_response(false,array('error'=>'Action impossible.'),500);dmdphotos_json_response(true,array('processed'=>(int)$processed));
    }
}

if($action==='frame_save'){$prefs=dmdphotos_user_prefs($email);$source=(string)($input['source']??'all');if(!in_array($source,array('all','favorites','album'),true))$source='all';$aid=trim((string)($input['album_id']??''));if($source==='album'&&$aid!==''&&!isset(dmdphotos_accessible_albums($email)[$aid]))$aid='';$prefs['frame']=array('source'=>$source,'album_id'=>$aid,'interval'=>max(3,min(3600,(int)($input['interval']??12))),'shuffle'=>!empty($input['shuffle']));dmdphotos_save_user_prefs($email,$prefs);dmdphotos_json_response(true,array('frame'=>$prefs['frame']));}
if($action==='config_get'){if(!dmdphotos_can($email,'admin.configure'))dmdphotos_json_response(false,array('error'=>'Configuration non autorisée.'),403);$cfg=dmdphotos_config();$userRoot=dmdphotos_user_storage_root($email,true);$cfg['storage_ok']=$userRoot!==''&&is_dir($userRoot)&&is_writable($userRoot);$cfg['user_storage_root']=$userRoot;$cfg['storage_pattern']='users/profiles/[email]/DMD-Photos/originals/';$cfg['data_dir']=dmdphotos_data_dir(false);dmdphotos_json_response(true,array('csrf'=>dmdphotos_csrf(),'config'=>$cfg,'stats'=>dmdphotos_stats($email)));}
if($action==='config_save'){if(!dmdphotos_can($email,'admin.configure'))dmdphotos_json_response(false,array('error'=>'Configuration non autorisée.'),403);$cfg=dmdphotos_config();$cfg['max_upload_mb']=max(1,min(4096,(int)($input['max_upload_mb']??$cfg['max_upload_mb'])));$cfg['duplicate_policy']=(string)($input['duplicate_policy']??'reject')==='allow'?'allow':'reject';$cfg['jpeg_quality']=max(40,min(95,(int)($input['jpeg_quality']??$cfg['jpeg_quality'])));$cfg['thumb_size']=max(160,min(2048,(int)($input['thumb_size']??$cfg['thumb_size'])));$cfg['ffmpeg_path']=trim((string)($input['ffmpeg_path']??''));$cfg['frame_interval']=max(3,min(3600,(int)($input['frame_interval']??$cfg['frame_interval'])));$cfg['frame_shuffle']=!empty($input['frame_shuffle']);$cfg['scan_batch']=max(10,min(5000,(int)($input['scan_batch']??$cfg['scan_batch'])));$cfg['updated_at']=date('c');if(!dmdphotos_json_write(dmdphotos_config_file(),$cfg))dmdphotos_json_response(false,array('error'=>'Écriture impossible.'),500);$userRoot=dmdphotos_user_storage_root($email,true);if($userRoot==='')dmdphotos_json_response(false,array('error'=>'Configuration enregistrée mais le dossier DMD-Photos de l’utilisateur ne peut pas être créé.'),500);$cfg['storage_ok']=is_writable($userRoot);$cfg['user_storage_root']=$userRoot;$cfg['storage_pattern']='users/profiles/[email]/DMD-Photos/originals/';$cfg['data_dir']=dmdphotos_data_dir(false);dmdphotos_json_response(true,array('config'=>$cfg));}
if($action==='scan'){if(!dmdphotos_can($email,'admin.configure'))dmdphotos_json_response(false,array('error'=>'Indexation non autorisée.'),403);$r=dmdphotos_scan_storage($email,dmdphotos_config()['scan_batch']);dmdphotos_json_response(true,array('result'=>$r,'stats'=>dmdphotos_stats($email)));}
dmdphotos_json_response(false,array('error'=>'Action inconnue.'),400);
