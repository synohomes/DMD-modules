<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
$email=dmdphotos_email();
if($email===''||!dmdphotos_can($email,'library.upload'))dmdphotos_json_response(false,array('error'=>'Import non autorisé.'),403);
dmdphotos_require_engine();
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')dmdphotos_json_response(false,array('error'=>'Méthode invalide.'),405);
$token=(string)($_POST['csrf']??($_SERVER['HTTP_X_CSRF_TOKEN']??''));if(!dmdphotos_csrf_valid($token))dmdphotos_json_response(false,array('error'=>'Jeton de sécurité expiré.'),403);
if(empty($_FILES['files']))dmdphotos_json_response(false,array('error'=>'Aucun fichier reçu. Vérifie upload_max_filesize/post_max_size de PHP.'),400);
$albumId=trim((string)($_POST['album_id']??''));$setCover=!empty($_POST['set_cover']);$album=null;
if($albumId!==''){$album=dmdphotos_album_row($albumId);if(!$album||!dmdphotos_album_visible($album,$email))dmdphotos_json_response(false,array('error'=>'Album introuvable.'),404);if(!dmdphotos_album_contribute($album,$email)&&!dmdphotos_can_manage_album($album,$email))dmdphotos_json_response(false,array('error'=>'Tu ne peux pas ajouter de médias dans cet album.'),403);}
$f=$_FILES['files'];$names=is_array($f['name'])?$f['name']:array($f['name']);$tmps=is_array($f['tmp_name'])?$f['tmp_name']:array($f['tmp_name']);$errs=is_array($f['error'])?$f['error']:array($f['error']);$out=array();$imported=0;$duplicates=0;$ids=array();
foreach($names as $i=>$name){$err=(int)($errs[$i]??UPLOAD_ERR_NO_FILE);if($err!==UPLOAD_ERR_OK){$out[]=array('name'=>$name,'ok'=>false,'error'=>'Erreur upload PHP '.$err);continue;}$ext=dmdphotos_safe_ext((string)$name);$mime=dmdphotos_detect_mime((string)$tmps[$i]);$type=dmdphotos_media_type($mime,$ext);if($type==='video'&&!dmdphotos_can($email,'library.video_upload')){$out[]=array('name'=>$name,'ok'=>false,'error'=>'Import vidéo non autorisé.');continue;}$res=dmdphotos_add_file((string)$tmps[$i],(string)$name,$email,true);$res['name']=(string)$name;$out[]=$res;if(!empty($res['duplicate']))$duplicates++;elseif(!empty($res['ok']))$imported++;if(!empty($res['ok'])&&!empty($res['id']))$ids[]=(string)$res['id'];}
$albumAdded=0;$cover='';if($albumId!==''&&$ids){$max=(int)(dmdphotos_db_one('SELECT COALESCE(MAX(position),0) p FROM album_items WHERE album_id=?',array($albumId))['p']??0);foreach(array_values(array_unique($ids)) as $mid){$m=dmdphotos_media_row($mid);if(!$m||!dmdphotos_photo_accessible($m,$email))continue;$max++;if(dmdphotos_db_exec('INSERT OR IGNORE INTO album_items(album_id,media_id,position,added_by,added_at) VALUES(?,?,?,?,?)',array($albumId,$mid,$max,$email,dmdphotos_now())))$albumAdded++;if($cover===''&&($m['media_type']??'')==='image')$cover=$mid;}if($cover!==''&&($setCover||(string)($album['cover_id']??'')===''))dmdphotos_db_exec('UPDATE albums SET cover_id=?,updated_at=? WHERE id=?',array($cover,dmdphotos_now(),$albumId));}
dmdphotos_run_jobs(min(4,max(1,count($ids))));
dmdphotos_json_response(true,array('files'=>$out,'imported'=>$imported,'duplicates'=>$duplicates,'album_added'=>$albumAdded,'album_id'=>$albumId,'cover_id'=>$cover,'stats'=>dmdphotos_stats($email)));
