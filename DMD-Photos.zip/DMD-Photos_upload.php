<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Photos_lib.php';
$email=dmdphotos_email();
if($email===''||!dmdphotos_can($email,'photos.upload'))dmdphotos_json_response(false,array('error'=>'Upload non autorisé.'),403);
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')dmdphotos_json_response(false,array('error'=>'Méthode invalide.'),405);
$token=(string)($_POST['csrf']??($_SERVER['HTTP_X_CSRF_TOKEN']??''));
if(!dmdphotos_csrf_valid($token))dmdphotos_json_response(false,array('error'=>'Jeton de sécurité expiré.'),403);
if(empty($_FILES['files']))dmdphotos_json_response(false,array('error'=>'Aucun fichier reçu. Vérifie aussi upload_max_filesize et post_max_size de PHP.'),400);

$albumId=trim((string)($_POST['album_id']??''));
$setCover=!empty($_POST['set_cover']);
$album=null;
if($albumId!==''){
    $adb=dmdphotos_load_albums();
    $album=$adb['items'][$albumId]??null;
    if(!is_array($album)||!dmdphotos_album_visible($album,$email))dmdphotos_json_response(false,array('error'=>'Album introuvable.'),404);
    if(!dmdphotos_can_manage_album($album,$email))dmdphotos_json_response(false,array('error'=>'Tu ne peux pas ajouter de médias dans cet album.'),403);
}

$f=$_FILES['files'];
$names=is_array($f['name'])?$f['name']:array($f['name']);
$tmps=is_array($f['tmp_name'])?$f['tmp_name']:array($f['tmp_name']);
$errs=is_array($f['error'])?$f['error']:array($f['error']);
$out=array();$imported=0;$duplicates=0;$candidateIds=array();
foreach($names as $i=>$name){
    $err=(int)($errs[$i]??UPLOAD_ERR_NO_FILE);
    if($err!==UPLOAD_ERR_OK){$out[]=array('name'=>$name,'ok'=>false,'error'=>'Erreur upload PHP '.$err);continue;}
    $res=dmdphotos_add_file((string)$tmps[$i],(string)$name,$email,true);
    $res['name']=(string)$name;$out[]=$res;
    if(!empty($res['duplicate']))$duplicates++;elseif(!empty($res['ok']))$imported++;
    if(!empty($res['ok'])&&!empty($res['id']))$candidateIds[]=(string)$res['id'];
}

$albumAdded=0;$coverId='';
if($albumId!==''&&$candidateIds){
    $photos=dmdphotos_load_photos()['items'];
    $allowed=array();
    foreach(array_values(array_unique($candidateIds)) as $id){
        $p=$photos[$id]??null;
        if(is_array($p)&&empty($p['trashed_at'])&&dmdphotos_photo_accessible($p,$email))$allowed[]=$id;
    }
    if($allowed){
        list($saved,$result)=dmdphotos_mutate_json(dmdphotos_albums_file(),array('schema'=>1,'items'=>array()),function(&$db)use($albumId,$allowed,$photos,$setCover){
            if(empty($db['items'][$albumId])||!is_array($db['items'][$albumId]))return array('added'=>0,'cover'=>'');
            $a=&$db['items'][$albumId];
            $items=array_values(array_unique(array_map('strval',(array)($a['items']??array()))));
            $before=count($items);
            foreach($allowed as $id)if(!in_array($id,$items,true))$items[]=$id;
            $a['items']=$items;
            $cover=(string)($a['cover_id']??'');
            if($setCover||$cover===''){
                foreach($allowed as $id){$p=$photos[$id]??null;if(is_array($p)&&(($p['media_type']??'image')==='image')&&empty($p['trashed_at'])){$cover=$id;break;}}
                if($cover!=='')$a['cover_id']=$cover;
            }
            $a['updated_at']=date('c');
            return array('added'=>count($items)-$before,'cover'=>$cover);
        });
        if(!$saved)dmdphotos_json_response(false,array('error'=>'Les fichiers ont été importés mais l’ajout à l’album a échoué.'),500);
        $albumAdded=(int)($result['added']??0);$coverId=(string)($result['cover']??'');
    }
}

dmdphotos_json_response(true,array('files'=>$out,'imported'=>$imported,'duplicates'=>$duplicates,'album_added'=>$albumAdded,'album_id'=>$albumId,'cover_id'=>$coverId,'stats'=>dmdphotos_stats($email)));
