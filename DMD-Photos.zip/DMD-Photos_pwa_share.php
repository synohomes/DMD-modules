<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if(session_status()===PHP_SESSION_NONE)session_start();require_once __DIR__.'/DMD-Photos_lib.php';$email=dmdphotos_email();if($email===''||!dmdphotos_can($email,'module.view')||!dmdphotos_can($email,'pwa.use')||!dmdphotos_can($email,'library.upload')){header('Location: DMD-Photos_app.php?share=denied');exit;}$site=strtolower((string)($_SERVER['HTTP_SEC_FETCH_SITE']??''));if($site!==''&&!in_array($site,array('same-origin','none'),true)){header('Location: DMD-Photos_app.php?share=blocked');exit;}if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'&&!empty($_FILES['media'])){$f=$_FILES['media'];$names=is_array($f['name'])?$f['name']:array($f['name']);$tmps=is_array($f['tmp_name'])?$f['tmp_name']:array($f['tmp_name']);$errs=is_array($f['error'])?$f['error']:array($f['error']);foreach($names as $i=>$name){if((int)($errs[$i]??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)continue;$ext=dmdphotos_safe_ext((string)$name);$mime=dmdphotos_detect_mime((string)$tmps[$i]);$type=dmdphotos_media_type($mime,$ext);if($type==='video'&&!dmdphotos_can($email,'library.video_upload'))continue;dmdphotos_add_file((string)$tmps[$i],(string)$name,$email,true);}dmdphotos_run_jobs(3);}header('Location: DMD-Photos_app.php?shared=1');exit;
