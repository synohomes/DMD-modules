<?php
define('DMDPHOTOS_STANDALONE',true);
require_once __DIR__.'/DMD-Photos_lib.php';
dmdphotos_require('module.view');
dmdphotos_require('pwa.use');
require __DIR__.'/DMD-Photos.php';
