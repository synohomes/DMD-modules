<?php
require_once __DIR__.'/DMD-Photos_lib.php';

$token=(string)($_GET['q']??'');
$payload=dmdphotos_quick_share_parse($token);

if(!$payload){
    http_response_code(404);
    exit;
}

$id=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['id']??''));
$type=(string)$payload['type'];
$sourceId=preg_replace('/[^A-Za-z0-9_-]/','',(string)$payload['id']);

if($type==='photo'){
    if($id!==$sourceId){
        http_response_code(404);
        exit;
    }
}else{
    $ok=dmdphotos_db_one('SELECT 1 x FROM album_items WHERE album_id=? AND media_id=?',array($sourceId,$id));
    if(!$ok){
        http_response_code(404);
        exit;
    }
}

$m=dmdphotos_media_row($id);
if(!$m||($m['media_type']??'')!=='image'||($m['trashed_at']??'')!==''){
    http_response_code(404);
    exit;
}

$kind=(string)($_GET['kind']??'preview');
$file='';
$mime='image/jpeg';

if($kind==='thumb'){
    $file=dmdphotos_thumb_file($id);
    if(!is_file($file))dmdphotos_make_thumb($m);
}elseif($kind==='preview'){
    $file=dmdphotos_preview_file($id);
    if(!is_file($file))dmdphotos_make_preview($m);
}else{
    $file=(string)$m['absolute_path'];
    $mime=(string)($m['mime']??dmdphotos_detect_mime($file));
}

if($file===''||!is_file($file)){
    $file=(string)$m['absolute_path'];
    $mime=(string)($m['mime']??dmdphotos_detect_mime($file));
}

if(!is_file($file)){
    http_response_code(404);
    exit;
}

header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=60');
header('Content-Type: '.$mime);
header('Content-Disposition: inline');
header('Content-Length: '.(string)(@filesize($file)?:0));
readfile($file);
