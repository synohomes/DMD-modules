<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (!defined('DMD_ROOT')) define('DMD_ROOT', dirname(__DIR__, 2));
require_once DMD_ROOT . '/core/dmd_permissions.php';
if (is_file(DMD_ROOT . '/core/dmd_module_logs.php')) require_once DMD_ROOT . '/core/dmd_module_logs.php';

if (!defined('DMDPHOTOS_ID')) define('DMDPHOTOS_ID', 'DMD-Photos');
if (!defined('DMDPHOTOS_VERSION')) define('DMDPHOTOS_VERSION', '1.0.4');

function dmdphotos_email() { return trim((string)($_SESSION['user']['email'] ?? '')); }
function dmdphotos_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmdphotos_lower($v) { $v=(string)$v; return function_exists('mb_strtolower') ? mb_strtolower($v,'UTF-8') : strtolower($v); }
function dmdphotos_json_read($file, $fallback=array()) {
    if (!is_file($file)) return $fallback;
    $raw=@file_get_contents($file); if (!is_string($raw) || trim($raw)==='') return $fallback;
    $data=json_decode($raw,true); return is_array($data)?$data:$fallback;
}
function dmdphotos_json_write($file, $data) {
    $dir=dirname($file); if (!is_dir($dir) && !@mkdir($dir,0750,true) && !is_dir($dir)) return false;
    $json=json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json===false) return false;
    try { $suffix=bin2hex(random_bytes(5)); } catch (Throwable $e) { $suffix=(string)mt_rand(); }
    $tmp=$file.'.tmp.'.$suffix;
    if (@file_put_contents($tmp,$json,LOCK_EX)===false) return false;
    @chmod($tmp,0640); if (!@rename($tmp,$file)) { @unlink($tmp); return false; } @chmod($file,0640); return true;
}
function dmdphotos_mutate_json($file, $fallback, $callback) {
    $lock=$file.'.lock'; $dir=dirname($file); if (!is_dir($dir)) @mkdir($dir,0750,true);
    $fp=@fopen($lock,'c+'); if (!$fp) return array(false,null,'lock_failed');
    @flock($fp,LOCK_EX); $data=dmdphotos_json_read($file,$fallback);
    try { $result=call_user_func_array($callback,array(&$data)); $ok=dmdphotos_json_write($file,$data); }
    catch (Throwable $e) { $result=null; $ok=false; }
    @flock($fp,LOCK_UN); @fclose($fp); return array($ok,$result,$ok?'':'write_failed');
}
function dmdphotos_data_dir($create=true) {
    $dir=dmd_module_system_data_dir(DMDPHOTOS_ID,$create); if ($dir==='') return '';
    if ($create) {
        foreach (array('thumbs','users','tmp') as $sub) { if (!is_dir($dir.$sub)) @mkdir($dir.$sub,0750,true); }
    }
    return $dir;
}
function dmdphotos_photos_file() { return dmdphotos_data_dir(true).'photos.json'; }
function dmdphotos_albums_file() { return dmdphotos_data_dir(true).'albums.json'; }
function dmdphotos_config_file() { return dmdphotos_data_dir(true).'config.json'; }
function dmdphotos_user_file($email) { return dmdphotos_data_dir(true).'users/'.hash('sha256',dmdphotos_lower(trim((string)$email))).'.json'; }
function dmdphotos_thumb_file($id) {
    $id=preg_replace('/[^A-Za-z0-9_-]/','',(string)$id);
    $dir=dmdphotos_data_dir(true).'thumbs/v2/';
    if(!is_dir($dir)) @mkdir($dir,0750,true);
    return $dir.$id.'.jpg';
}
function dmdphotos_user_storage_root($email,$create=true) {
    $email=trim((string)$email); if($email==='') return '';
    $dir=dmd_user_module_data_dir($email,DMDPHOTOS_ID,$create); if($dir==='') return '';
    $root=rtrim($dir,"/\\").DIRECTORY_SEPARATOR.'originals';
    if($create && !dmd_ensure_denied_directory($root)) return '';
    return $root;
}
function dmdphotos_storage_root($create=true) { return dmdphotos_user_storage_root(dmdphotos_email(),$create); }
function dmdphotos_default_config() {
    return array(
        'max_upload_mb'=>512,
        'duplicate_policy'=>'reject',
        'jpeg_quality'=>84,
        'thumb_size'=>640,
        'ffmpeg_path'=>is_file('/usr/bin/ffmpeg')?'/usr/bin/ffmpeg':'',
        'frame_interval'=>12,
        'frame_shuffle'=>true,
        'scan_batch'=>500,
        'updated_at'=>''
    );
}
function dmdphotos_config() {
    $cfg=array_merge(dmdphotos_default_config(),dmdphotos_json_read(dmdphotos_config_file(),array()));
    unset($cfg['storage_root']);
    $cfg['max_upload_mb']=max(1,min(4096,(int)$cfg['max_upload_mb']));
    $cfg['jpeg_quality']=max(40,min(95,(int)$cfg['jpeg_quality']));
    $cfg['thumb_size']=max(160,min(2048,(int)$cfg['thumb_size']));
    $cfg['frame_interval']=max(3,min(3600,(int)$cfg['frame_interval']));
    $cfg['scan_batch']=max(10,min(5000,(int)$cfg['scan_batch']));
    $cfg['duplicate_policy']=($cfg['duplicate_policy']==='allow')?'allow':'reject';
    return $cfg;
}
function dmdphotos_can($email,$permission) { return $email!=='' && dmd_user_has_module_permission($email,DMDPHOTOS_ID,$permission); }
function dmdphotos_require($permission='module.view') {
    $email=dmdphotos_email(); if ($email==='' || !dmdphotos_can($email,$permission)) { http_response_code(403); exit('Accès DMD-Photos refusé.'); }
}
function dmdphotos_permissions($email) {
    $ids=array('module.view','photos.upload','photos.download','photos.edit_own','photos.delete_own','photos.view_shared','albums.create','albums.manage_own','albums.delete_own','albums.share','admin.view_all','admin.manage_all','admin.configure','admin.delete_any','admin.delete_any_album');
    $out=array(); foreach($ids as $id)$out[$id]=dmdphotos_can($email,$id); return $out;
}
function dmdphotos_csrf() {
    if (empty($_SESSION['csrf_dmd_photos'])) { try { $_SESSION['csrf_dmd_photos']=bin2hex(random_bytes(32)); } catch(Throwable $e) { $_SESSION['csrf_dmd_photos']=hash('sha256',session_id().'|'.microtime(true).'|'.mt_rand()); } }
    return (string)$_SESSION['csrf_dmd_photos'];
}
function dmdphotos_csrf_valid($token) { $stored=(string)($_SESSION['csrf_dmd_photos']??''); return $stored!=='' && is_string($token) && hash_equals($stored,$token); }
function dmdphotos_id($prefix='P') { try{$r=strtoupper(bin2hex(random_bytes(8)));}catch(Throwable $e){$r=strtoupper(substr(hash('sha256',uniqid('',true).mt_rand()),0,16));} return $prefix.'-'.gmdate('YmdHis').'-'.$r; }
function dmdphotos_load_photos(){ $d=dmdphotos_json_read(dmdphotos_photos_file(),array('schema'=>1,'items'=>array())); if(!isset($d['items'])||!is_array($d['items']))$d['items']=array(); return $d; }
function dmdphotos_load_albums(){ $d=dmdphotos_json_read(dmdphotos_albums_file(),array('schema'=>1,'items'=>array())); if(!isset($d['items'])||!is_array($d['items']))$d['items']=array(); return $d; }
function dmdphotos_user_prefs($email){ $d=dmdphotos_json_read(dmdphotos_user_file($email),array()); if(!isset($d['favorites'])||!is_array($d['favorites']))$d['favorites']=array(); if(!isset($d['frame'])||!is_array($d['frame']))$d['frame']=array('source'=>'all','album_id'=>'','interval'=>(int)dmdphotos_config()['frame_interval'],'shuffle'=>(bool)dmdphotos_config()['frame_shuffle']); return $d; }
function dmdphotos_save_user_prefs($email,$data){ return dmdphotos_json_write(dmdphotos_user_file($email),$data); }
function dmdphotos_profile_role($email){ $p=dmd_read_profile($email); return trim((string)($p['role_metier']??'')); }
function dmdphotos_display_name($email){ $p=dmd_read_profile($email); $name=trim((string)($p['display_name']??($p['name']??''))); if($name==='')$name=trim((string)($p['prenom']??'').' '.(string)($p['nom']??'')); return $name!==''?$name:$email; }
function dmdphotos_users_roles(){
    $users=array();$roles=array();$base=DMD_ROOT.'/users/profiles/';
    foreach(glob($base.'*',GLOB_ONLYDIR)?:array() as $dir){$email=basename($dir);$p=dmd_read_profile($email);if(!$p)continue;$role=trim((string)($p['role_metier']??''));if($role!=='')$roles[$role]=true;$users[]=array('email'=>$email,'name'=>dmdphotos_display_name($email),'role'=>$role);}
    usort($users,function($a,$b){return strcasecmp($a['name'],$b['name']);});$roleNames=array_keys($roles);natcasesort($roleNames);return array('users'=>$users,'roles'=>array_values($roleNames));
}
function dmdphotos_album_visible($album,$email){
    if(!is_array($album)||$email==='')return false;$owner=(string)($album['owner_email']??'');if(strcasecmp($owner,$email)===0)return true;if(dmdphotos_can($email,'admin.view_all'))return true;if(!dmdphotos_can($email,'photos.view_shared'))return false;
    $vis=(string)($album['visibility']??'private');if($vis==='everyone')return true;
    foreach((array)($album['shared_users']??array()) as $u)if(strcasecmp((string)$u,$email)===0)return true;
    $role=dmdphotos_profile_role($email);if($role!=='')foreach((array)($album['shared_roles']??array()) as $r)if(strcasecmp((string)$r,$role)===0)return true;
    return false;
}
function dmdphotos_accessible_albums($email){$out=array();foreach(dmdphotos_load_albums()['items'] as $id=>$a){if(!is_array($a)||!dmdphotos_album_visible($a,$email))continue;$a['id']=$id;$a['is_owner']=strcasecmp((string)($a['owner_email']??''),$email)===0;$out[$id]=$a;}return $out;}
function dmdphotos_accessible_photo_ids($email){
    $ids=array();$photos=dmdphotos_load_photos()['items'];$admin=dmdphotos_can($email,'admin.view_all');
    foreach($photos as $id=>$p){if(!is_array($p))continue;if($admin||strcasecmp((string)($p['owner_email']??''),$email)===0)$ids[$id]=true;}
    foreach(dmdphotos_accessible_albums($email) as $a){foreach((array)($a['items']??array()) as $id){$id=(string)$id;if(!isset($photos[$id])||!is_array($photos[$id]))continue;if(!empty($photos[$id]['trashed_at'])&&strcasecmp((string)($photos[$id]['owner_email']??''),$email)!==0&&!$admin)continue;$ids[$id]=true;}}
    return $ids;
}
function dmdphotos_photo_accessible($photo,$email){if(!is_array($photo)||$email==='')return false;$id=(string)($photo['id']??'');if($id==='')return false;if(strcasecmp((string)($photo['owner_email']??''),$email)===0||dmdphotos_can($email,'admin.view_all'))return true;if(!empty($photo['trashed_at'])||!dmdphotos_can($email,'photos.view_shared'))return false;foreach(dmdphotos_accessible_albums($email) as $a){if(in_array($id,array_map('strval',(array)($a['items']??array())),true))return true;}return false;}
function dmdphotos_can_manage_photo($photo,$email,$delete=false){
    $owner=strcasecmp((string)($photo['owner_email']??''),$email)===0;
    if($delete && dmdphotos_can($email,'admin.delete_any'))return true;
    if(!$delete && dmdphotos_can($email,'admin.manage_all'))return true;
    return $owner && dmdphotos_can($email,$delete?'photos.delete_own':'photos.edit_own');
}
function dmdphotos_can_manage_album($album,$email){return dmdphotos_can($email,'admin.manage_all') || (strcasecmp((string)($album['owner_email']??''),$email)===0 && dmdphotos_can($email,'albums.manage_own'));}
function dmdphotos_can_delete_album($album,$email){return dmdphotos_can($email,'admin.delete_any_album') || (strcasecmp((string)($album['owner_email']??''),$email)===0 && dmdphotos_can($email,'albums.delete_own'));}
function dmdphotos_safe_ext($name){$ext=dmdphotos_lower(pathinfo((string)$name,PATHINFO_EXTENSION));$allowed=array('jpg','jpeg','png','gif','webp','bmp','tif','tiff','heic','heif','avif','mp4','mov','m4v','webm','avi','mkv');return in_array($ext,$allowed,true)?$ext:'';}
function dmdphotos_detect_mime($file){if(function_exists('finfo_open')){$f=@finfo_open(FILEINFO_MIME_TYPE);if($f){$m=@finfo_file($f,$file);@finfo_close($f);if(is_string($m)&&$m!=='')return $m;}}return 'application/octet-stream';}
function dmdphotos_media_type($mime,$ext){if(strpos($mime,'image/')===0)return'image';if(strpos($mime,'video/')===0)return'video';if(in_array($ext,array('mp4','mov','m4v','webm','avi','mkv'),true))return'video';return'image';}
function dmdphotos_rational($v){if(is_numeric($v))return(float)$v;if(is_string($v)&&strpos($v,'/')!==false){list($a,$b)=array_pad(explode('/',$v,2),2,1);$b=(float)$b;return$b!=0?(float)$a/$b:0;}return 0;}
function dmdphotos_gps_decimal($coord,$ref){if(!is_array($coord)||count($coord)<3)return null;$v=dmdphotos_rational($coord[0])+dmdphotos_rational($coord[1])/60+dmdphotos_rational($coord[2])/3600;if(in_array(strtoupper((string)$ref),array('S','W'),true))$v=-$v;return round($v,7);}
function dmdphotos_extract_meta($file,$mime){
    $out=array('captured_at'=>'','width'=>0,'height'=>0,'camera'=>'','lens'=>'','iso'=>'','focal'=>'','lat'=>null,'lon'=>null);
    $sz=@getimagesize($file);if(is_array($sz)){$out['width']=(int)$sz[0];$out['height']=(int)$sz[1];}
    if(strpos($mime,'image/jpeg')===0 && function_exists('exif_read_data')){
        $e=@exif_read_data($file,null,true,false);if(is_array($e)){
            $d=(string)($e['EXIF']['DateTimeOriginal']??($e['IFD0']['DateTime']??''));if($d!==''&&preg_match('/^(\d{4}):(\d{2}):(\d{2}) (\d{2}):(\d{2}):(\d{2})$/',$d,$m))$out['captured_at']=$m[1].'-'.$m[2].'-'.$m[3].'T'.$m[4].':'.$m[5].':'.$m[6];
            $out['camera']=trim((string)($e['IFD0']['Make']??'').' '.(string)($e['IFD0']['Model']??''));$out['lens']=trim((string)($e['EXIF']['UndefinedTag:0xA434']??($e['EXIF']['LensModel']??'')));$out['iso']=(string)($e['EXIF']['ISOSpeedRatings']??'');$out['focal']=isset($e['EXIF']['FocalLength'])?(string)$e['EXIF']['FocalLength']:'';
            if(isset($e['GPS']['GPSLatitude'],$e['GPS']['GPSLatitudeRef']))$out['lat']=dmdphotos_gps_decimal($e['GPS']['GPSLatitude'],$e['GPS']['GPSLatitudeRef']);if(isset($e['GPS']['GPSLongitude'],$e['GPS']['GPSLongitudeRef']))$out['lon']=dmdphotos_gps_decimal($e['GPS']['GPSLongitude'],$e['GPS']['GPSLongitudeRef']);
        }
    }
    return $out;
}
function dmdphotos_imagick_uniform_border($im){
    try{
        $w=(int)$im->getImageWidth();$h=(int)$im->getImageHeight();if($w<2||$h<2)return false;
        $pts=array(array(0,0),array($w-1,0),array(0,$h-1),array($w-1,$h-1));$light=true;$dark=true;$transparent=true;
        foreach($pts as $pt){$px=$im->getImagePixelColor($pt[0],$pt[1]);$r=(float)$px->getColorValue(Imagick::COLOR_RED);$g=(float)$px->getColorValue(Imagick::COLOR_GREEN);$b=(float)$px->getColorValue(Imagick::COLOR_BLUE);$a=method_exists($px,'getColorValue')?(float)$px->getColorValue(Imagick::COLOR_ALPHA):1.0;$light=$light&&$r>=0.92&&$g>=0.92&&$b>=0.92;$dark=$dark&&$r<=0.08&&$g<=0.08&&$b<=0.08;$transparent=$transparent&&$a<=0.08;}
        return $light||$dark||$transparent;
    }catch(Throwable $e){return false;}
}
function dmdphotos_gd_trim_bounds($im,$w,$h){
    if($w<4||$h<4)return array(0,0,$w,$h);
    $sample=192;$scale=min(1,$sample/max($w,$h));$sw=max(2,(int)round($w*$scale));$sh=max(2,(int)round($h*$scale));
    $sm=imagecreatetruecolor($sw,$sh);if(!$sm)return array(0,0,$w,$h);imagecopyresampled($sm,$im,0,0,0,0,$sw,$sh,$w,$h);
    $corners=array(imagecolorat($sm,0,0),imagecolorat($sm,$sw-1,0),imagecolorat($sm,0,$sh-1),imagecolorat($sm,$sw-1,$sh-1));$light=true;$dark=true;
    foreach($corners as $c){$r=($c>>16)&255;$g=($c>>8)&255;$b=$c&255;$light=$light&&$r>=235&&$g>=235&&$b>=235;$dark=$dark&&$r<=20&&$g<=20&&$b<=20;}
    if(!$light&&!$dark){imagedestroy($sm);return array(0,0,$w,$h);}
    $minx=$sw;$miny=$sh;$maxx=-1;$maxy=-1;
    for($y=0;$y<$sh;$y++){for($x=0;$x<$sw;$x++){$c=imagecolorat($sm,$x,$y);$r=($c>>16)&255;$g=($c>>8)&255;$b=$c&255;$content=$light?($r<225||$g<225||$b<225):($r>30||$g>30||$b>30);if($content){if($x<$minx)$minx=$x;if($x>$maxx)$maxx=$x;if($y<$miny)$miny=$y;if($y>$maxy)$maxy=$y;}}}
    imagedestroy($sm);if($maxx<$minx||$maxy<$miny)return array(0,0,$w,$h);
    $pad=max(1,(int)round(min($sw,$sh)*0.015));$minx=max(0,$minx-$pad);$miny=max(0,$miny-$pad);$maxx=min($sw-1,$maxx+$pad);$maxy=min($sh-1,$maxy+$pad);
    $removed=($minx/max(1,$sw))+(($sw-1-$maxx)/max(1,$sw))+($miny/max(1,$sh))+(($sh-1-$maxy)/max(1,$sh));if($removed<0.055)return array(0,0,$w,$h);
    $x=(int)floor($minx/$sw*$w);$y=(int)floor($miny/$sh*$h);$cw=(int)ceil(($maxx-$minx+1)/$sw*$w);$ch=(int)ceil(($maxy-$miny+1)/$sh*$h);
    $cw=max(1,min($w-$x,$cw));$ch=max(1,min($h-$y,$ch));return array($x,$y,$cw,$ch);
}
function dmdphotos_make_thumb_image($src,$dst,$size,$quality){
    if(class_exists('Imagick')){try{
        $im=new Imagick($src);if(method_exists($im,'autoOrientImage'))@$im->autoOrientImage();$im->setIteratorIndex(0);
        if(dmdphotos_imagick_uniform_border($im)){try{$corner=$im->getImagePixelColor(0,0);$im->setImageBackgroundColor($corner);$qr=method_exists('Imagick','getQuantumRange')?Imagick::getQuantumRange():array('quantumRangeLong'=>65535);$q=(float)($qr['quantumRangeLong']??65535);@$im->trimImage($q*0.055);@$im->setImagePage(0,0,0,0);}catch(Throwable $e){}}
        $im->thumbnailImage($size,$size,true);$im->setImageFormat('jpeg');$im->setImageCompressionQuality($quality);$ok=$im->writeImage($dst);$im->clear();$im->destroy();if($ok){@chmod($dst,0640);return true;}
    }catch(Throwable $e){}}
    $info=@getimagesize($src);if(!is_array($info))return false;$mime=(string)($info['mime']??'');$im=false;
    if($mime==='image/jpeg'&&function_exists('imagecreatefromjpeg'))$im=@imagecreatefromjpeg($src);elseif($mime==='image/png'&&function_exists('imagecreatefrompng'))$im=@imagecreatefrompng($src);elseif($mime==='image/gif'&&function_exists('imagecreatefromgif'))$im=@imagecreatefromgif($src);elseif($mime==='image/webp'&&function_exists('imagecreatefromwebp'))$im=@imagecreatefromwebp($src);if(!$im)return false;
    $w=imagesx($im);$h=imagesy($im);if($w<1||$h<1){imagedestroy($im);return false;}list($sx,$sy,$cw,$ch)=dmdphotos_gd_trim_bounds($im,$w,$h);$scale=min($size/$cw,$size/$ch,1);$nw=max(1,(int)round($cw*$scale));$nh=max(1,(int)round($ch*$scale));$out=imagecreatetruecolor($nw,$nh);imagecopyresampled($out,$im,0,0,$sx,$sy,$nw,$nh,$cw,$ch);$ok=@imagejpeg($out,$dst,$quality);imagedestroy($out);imagedestroy($im);if($ok)@chmod($dst,0640);return(bool)$ok;
}
function dmdphotos_make_thumb_video($src,$dst,$size,$quality,$ffmpeg){
    $ffmpeg=trim((string)$ffmpeg);if($ffmpeg===''||!is_file($ffmpeg)||!is_executable($ffmpeg)||!function_exists('exec'))return false;
    $cmd=escapeshellarg($ffmpeg).' -hide_banner -loglevel error -y -ss 00:00:01 -i '.escapeshellarg($src).' -frames:v 1 -vf '.escapeshellarg('scale='.$size.':'.$size.':force_original_aspect_ratio=decrease').' -q:v 4 '.escapeshellarg($dst).' 2>&1';$out=array();$code=1;@exec($cmd,$out,$code);if($code===0&&is_file($dst)){@chmod($dst,0640);return true;}@unlink($dst);return false;
}
function dmdphotos_make_thumb($photo){$cfg=dmdphotos_config();$src=(string)($photo['absolute_path']??'');$dst=dmdphotos_thumb_file((string)($photo['id']??''));if($src===''||!is_file($src))return false;if(($photo['media_type']??'image')==='video')return dmdphotos_make_thumb_video($src,$dst,$cfg['thumb_size'],$cfg['jpeg_quality'],$cfg['ffmpeg_path']);return dmdphotos_make_thumb_image($src,$dst,$cfg['thumb_size'],$cfg['jpeg_quality']);}
function dmdphotos_find_duplicate($hash,$photos){foreach($photos as $id=>$p)if(is_array($p)&&!empty($p['sha256'])&&hash_equals((string)$p['sha256'],(string)$hash)&&empty($p['deleted_permanently']))return(string)$id;return'';}
function dmdphotos_add_file($source,$originalName,$owner,$move=false){
    $cfg=dmdphotos_config();$ext=dmdphotos_safe_ext($originalName);if($ext==='')return array('ok'=>false,'error'=>'Format non autorisé.');if(!is_file($source))return array('ok'=>false,'error'=>'Fichier introuvable.');$size=@filesize($source);if($size===false||$size<1)return array('ok'=>false,'error'=>'Fichier vide.');if($size>$cfg['max_upload_mb']*1024*1024)return array('ok'=>false,'error'=>'Fichier trop volumineux.');
    $mime=dmdphotos_detect_mime($source);$type=dmdphotos_media_type($mime,$ext);$hash=@hash_file('sha256',$source);if(!$hash)return array('ok'=>false,'error'=>'Empreinte impossible.');$all=dmdphotos_load_photos()['items'];$dup=dmdphotos_find_duplicate($hash,$all);if($dup!==''&&$cfg['duplicate_policy']==='reject')return array('ok'=>true,'duplicate'=>true,'id'=>$dup);
    $id=dmdphotos_id('PH');$root=dmdphotos_user_storage_root($owner,true);if($root==='')return array('ok'=>false,'error'=>'Stockage utilisateur indisponible.');$folder=$root;$ym=date('Y').DIRECTORY_SEPARATOR.date('m');$folder.=DIRECTORY_SEPARATOR.$ym;if(!is_dir($folder)&&!@mkdir($folder,0750,true)&&!is_dir($folder))return array('ok'=>false,'error'=>'Impossible de créer le dossier de stockage.');$dest=$folder.DIRECTORY_SEPARATOR.$id.'.'.$ext;
    $ok=$move?@move_uploaded_file($source,$dest):@copy($source,$dest);if(!$ok)return array('ok'=>false,'error'=>'Copie du fichier impossible.');@chmod($dest,0640);
    $meta=dmdphotos_extract_meta($dest,$mime);$captured=$meta['captured_at']!==''?$meta['captured_at']:date('c',@filemtime($dest)?:time());
    $row=array('id'=>$id,'owner_email'=>$owner,'original_name'=>basename((string)$originalName),'extension'=>$ext,'mime'=>$mime,'media_type'=>$type,'size'=>(int)$size,'sha256'=>$hash,'absolute_path'=>$dest,'captured_at'=>$captured,'imported_at'=>date('c'),'updated_at'=>date('c'),'width'=>(int)$meta['width'],'height'=>(int)$meta['height'],'camera'=>$meta['camera'],'lens'=>$meta['lens'],'iso'=>$meta['iso'],'focal'=>$meta['focal'],'lat'=>$meta['lat'],'lon'=>$meta['lon'],'title'=>'','description'=>'','tags'=>array(),'trashed_at'=>'');
    list($saved)=dmdphotos_mutate_json(dmdphotos_photos_file(),array('schema'=>1,'items'=>array()),function(&$db)use($id,$row){if(!isset($db['items'])||!is_array($db['items']))$db['items']=array();$db['items'][$id]=$row;$db['updated_at']=date('c');return true;});if(!$saved){@unlink($dest);return array('ok'=>false,'error'=>'Index photo impossible.');}dmdphotos_make_thumb($row);if(function_exists('dmd_module_log')){try{dmd_module_log(DMDPHOTOS_ID,'photo.import',array('id'=>$id,'name'=>$row['original_name']),array('scope'=>'system'));}catch(Throwable $e){}}
    return array('ok'=>true,'id'=>$id,'duplicate'=>false);
}
function dmdphotos_import_existing_file($path,$owner){
    $ext=dmdphotos_safe_ext($path);if($ext==='')return array('ok'=>false,'skip'=>true);$hash=@hash_file('sha256',$path);if(!$hash)return array('ok'=>false,'skip'=>true);$all=dmdphotos_load_photos()['items'];$dup=dmdphotos_find_duplicate($hash,$all);if($dup!=='')return array('ok'=>true,'duplicate'=>true,'id'=>$dup);
    $mime=dmdphotos_detect_mime($path);$id=dmdphotos_id('PH');$meta=dmdphotos_extract_meta($path,$mime);$row=array('id'=>$id,'owner_email'=>$owner,'original_name'=>basename($path),'extension'=>$ext,'mime'=>$mime,'media_type'=>dmdphotos_media_type($mime,$ext),'size'=>(int)(@filesize($path)?:0),'sha256'=>$hash,'absolute_path'=>$path,'captured_at'=>$meta['captured_at']!==''?$meta['captured_at']:date('c',@filemtime($path)?:time()),'imported_at'=>date('c'),'updated_at'=>date('c'),'width'=>(int)$meta['width'],'height'=>(int)$meta['height'],'camera'=>$meta['camera'],'lens'=>$meta['lens'],'iso'=>$meta['iso'],'focal'=>$meta['focal'],'lat'=>$meta['lat'],'lon'=>$meta['lon'],'title'=>'','description'=>'','tags'=>array(),'trashed_at'=>'');
    list($saved)=dmdphotos_mutate_json(dmdphotos_photos_file(),array('schema'=>1,'items'=>array()),function(&$db)use($id,$row){if(!isset($db['items'])||!is_array($db['items']))$db['items']=array();$db['items'][$id]=$row;$db['updated_at']=date('c');return true;});if(!$saved)return array('ok'=>false,'error'=>'index_failed');dmdphotos_make_thumb($row);return array('ok'=>true,'id'=>$id,'duplicate'=>false);
}
function dmdphotos_scan_storage($owner,$limit){$root=dmdphotos_user_storage_root($owner,false);if($root===''||!is_dir($root))return array('imported'=>0,'duplicates'=>0,'errors'=>0,'checked'=>0);$limit=max(1,(int)$limit);$r=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));$imported=0;$duplicates=0;$errors=0;$checked=0;foreach($r as $f){if(!$f->isFile())continue;$path=$f->getPathname();if(basename($path)==='.htaccess')continue;if(dmdphotos_safe_ext($path)==='')continue;$checked++;$res=dmdphotos_import_existing_file($path,$owner);if(!empty($res['duplicate']))$duplicates++;elseif(!empty($res['ok']))$imported++;else$errors++;if($imported+$errors>=$limit)break;}return compact('imported','duplicates','errors','checked');}
function dmdphotos_public_photo($p,$email,$favorites){
    $id=(string)($p['id']??'');return array('id'=>$id,'owner_email'=>(string)($p['owner_email']??''),'owner_name'=>dmdphotos_display_name((string)($p['owner_email']??'')),'original_name'=>(string)($p['original_name']??''),'mime'=>(string)($p['mime']??''),'media_type'=>(string)($p['media_type']??'image'),'size'=>(int)($p['size']??0),'captured_at'=>(string)($p['captured_at']??''),'imported_at'=>(string)($p['imported_at']??''),'width'=>(int)($p['width']??0),'height'=>(int)($p['height']??0),'camera'=>(string)($p['camera']??''),'lens'=>(string)($p['lens']??''),'iso'=>(string)($p['iso']??''),'focal'=>(string)($p['focal']??''),'lat'=>$p['lat']??null,'lon'=>$p['lon']??null,'title'=>(string)($p['title']??''),'description'=>(string)($p['description']??''),'tags'=>array_values((array)($p['tags']??array())),'trashed_at'=>(string)($p['trashed_at']??''),'favorite'=>in_array($id,$favorites,true),'is_owner'=>strcasecmp((string)($p['owner_email']??''),$email)===0,'can_edit'=>dmdphotos_can_manage_photo($p,$email,false),'can_delete'=>dmdphotos_can_manage_photo($p,$email,true),'has_thumb'=>is_file(dmdphotos_thumb_file($id)));
}
function dmdphotos_list($email,$opts=array()){
    $q=dmdphotos_lower(trim((string)($opts['q']??'')));$filter=(string)($opts['filter']??'all');$offset=max(0,(int)($opts['offset']??0));$limit=max(1,min(250,(int)($opts['limit']??100)));$prefs=dmdphotos_user_prefs($email);$favorites=array_values(array_map('strval',$prefs['favorites']));$favMap=array_fill_keys($favorites,true);$photos=dmdphotos_load_photos()['items'];$accessible=dmdphotos_accessible_photo_ids($email);$albumIds=null;
    if(strpos($filter,'album:')===0){$aid=substr($filter,6);$albums=dmdphotos_accessible_albums($email);$albumIds=isset($albums[$aid])?array_fill_keys(array_map('strval',(array)($albums[$aid]['items']??array())),true):array();}
    $rows=array();foreach($photos as $id=>$p){if(!is_array($p)||empty($accessible[$id]))continue;$trashed=!empty($p['trashed_at']);if($filter==='trash'){if(!$trashed)continue;}else{if($trashed)continue;}if($filter==='favorites'&&empty($favMap[$id]))continue;if(is_array($albumIds)&&empty($albumIds[$id]))continue;if($filter==='mine'&&strcasecmp((string)($p['owner_email']??''),$email)!==0)continue;
        if($q!==''){$hay=dmdphotos_lower(implode(' ',array((string)($p['original_name']??''),(string)($p['title']??''),(string)($p['description']??''),(string)($p['camera']??''),(string)($p['lens']??''),implode(' ',(array)($p['tags']??array())))));if(strpos($hay,$q)===false)continue;}$rows[]=dmdphotos_public_photo($p,$email,$favorites);
    }
    usort($rows,function($a,$b){return strcmp((string)$b['captured_at'],(string)$a['captured_at']);});$total=count($rows);$rows=array_slice($rows,$offset,$limit);return array('items'=>$rows,'total'=>$total,'offset'=>$offset,'limit'=>$limit);
}
function dmdphotos_stats($email){$photos=dmdphotos_load_photos()['items'];$ids=dmdphotos_accessible_photo_ids($email);$count=0;$images=0;$videos=0;$bytes=0;$trash=0;foreach($photos as $id=>$p){if(!is_array($p)||empty($ids[$id]))continue;if(!empty($p['trashed_at'])){$trash++;continue;}$count++;$bytes+=(int)($p['size']??0);if(($p['media_type']??'image')==='video')$videos++;else$images++;}return compact('count','images','videos','bytes','trash');}
function dmdphotos_album_effective_cover_id($a){
    static $photos=null;
    if($photos===null)$photos=dmdphotos_load_photos()['items'];
    $items=array_values(array_unique(array_map('strval',(array)($a['items']??array()))));
    $cover=(string)($a['cover_id']??'');
    if($cover!=='' && in_array($cover,$items,true) && !empty($photos[$cover]) && is_array($photos[$cover]) && empty($photos[$cover]['trashed_at']) && (($photos[$cover]['media_type']??'image')==='image')) return $cover;
    foreach($items as $id){if(!empty($photos[$id])&&is_array($photos[$id])&&empty($photos[$id]['trashed_at'])&&(($photos[$id]['media_type']??'image')==='image'))return $id;}
    return '';
}
function dmdphotos_album_public($a,$email){$a['id']=(string)($a['id']??'');$a['is_owner']=strcasecmp((string)($a['owner_email']??''),$email)===0;$a['can_manage']=dmdphotos_can_manage_album($a,$email);$a['can_delete']=dmdphotos_can_delete_album($a,$email);$a['can_share']=$a['can_manage']&&dmdphotos_can($email,'albums.share');$a['count']=count((array)($a['items']??array()));$a['cover_id']=dmdphotos_album_effective_cover_id($a);unset($a['internal']);return $a;}
function dmdphotos_theme_url($email){$theme='default';$file=DMD_ROOT.'/users/profiles/'.basename($email).'/theme.json';$d=dmdphotos_json_read($file,array());$cand=basename((string)($d['theme']??''));if($cand!==''&&is_file(DMD_ROOT.'/theme/'.$cand.'/style.css'))$theme=$cand;$script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));$base=preg_replace('~/modules/DMD-Photos/.*$~','',$script);if(!is_string($base))$base='/domydesk';return rtrim($base,'/').'/theme/'.rawurlencode($theme).'/style.css';}
function dmdphotos_module_base_url(){ $script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??'')); if(strpos($script,'/modules/DMD-Photos/')!==false)return substr($script,0,strpos($script,'/modules/DMD-Photos/')).'/modules/DMD-Photos'; return 'modules/DMD-Photos'; }
function dmdphotos_json_response($ok,$data=array(),$status=200){http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode(array_merge(array('ok'=>(bool)$ok),$data),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
