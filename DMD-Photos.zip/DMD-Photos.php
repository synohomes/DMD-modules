<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */


if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Photos_lib.php';
dmdphotos_require('module.view');
$email = dmdphotos_email();
$standalone = !empty($_GET['pwa']) || !empty($_GET['standalone']);
$base = dmdphotos_module_base_url();
$theme = dmdphotos_theme_url($email);
$uid = 'dmdphotos_' . substr(hash('sha256', session_id() . '|' . microtime(true)), 0, 10);
$cssv = is_file(__DIR__ . '/DMD-Photos.css') ? filemtime(__DIR__ . '/DMD-Photos.css') : 100;
$jsv = is_file(__DIR__ . '/DMD-Photos.js') ? filemtime(__DIR__ . '/DMD-Photos.js') : 100;
if ($standalone) {
?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#111111"><title>DMD-Photos</title><link rel="manifest" href="<?=dmdphotos_h($base)?>/manifest.webmanifest"><link rel="stylesheet" href="<?=dmdphotos_h($theme)?>"><link rel="stylesheet" href="<?=dmdphotos_h($base)?>/DMD-Photos.css?v=<?=$cssv?>"></head><body class="dmdphotos-standalone"><?php
} else {
?><link rel="stylesheet" href="<?=dmdphotos_h($base)?>/DMD-Photos.css?v=<?=$cssv?>"><?php
}
?>
<section id="<?=dmdphotos_h($uid)?>" class="dmdphotos" data-api="<?=dmdphotos_h($base)?>/DMD-Photos_api.php" data-upload="<?=dmdphotos_h($base)?>/DMD-Photos_upload.php" data-media="<?=dmdphotos_h($base)?>/DMD-Photos_media.php" data-pwa="<?=dmdphotos_h($base)?>/DMD-Photos.php?pwa=1" data-manifest="<?=dmdphotos_h($base)?>/manifest.webmanifest" data-sw="<?=dmdphotos_h($base)?>/sw.js" data-css="<?=dmdphotos_h($base)?>/DMD-Photos.css?v=<?=$cssv?>">
  <header class="dp-head">
    <div><h2>DMD-Photos</h2><p>Photothèque privée DoMyDesk</p></div>
    <div class="dp-head-actions"><button type="button" class="dp-btn" data-action="refresh">↻ Actualiser</button><button type="button" class="dp-btn" data-action="upload" hidden>＋ Ajouter</button><a class="dp-btn" href="<?=dmdphotos_h($base)?>/DMD-Photos.php?pwa=1" target="_blank" rel="noopener">↗ PWA</a></div>
  </header>

  <div class="dp-stats" data-role="stats"></div>

  <div class="dp-toolbar">
    <nav class="dp-tabs"><button class="is-active" data-tab="library">Photos</button><button data-tab="albums">Albums</button><button data-tab="frame">Cadre</button><button data-tab="trash">Corbeille</button></nav>
    <div class="dp-search"><input type="search" data-role="search" placeholder="Rechercher fichier, titre, tag, appareil…"><select data-role="filter"><option value="all">Toute la photothèque</option><option value="mine">Mes médias</option><option value="favorites">Favoris</option></select></div>
  </div>

  <div class="dp-message" data-role="message" hidden></div>

  <div class="dp-bulkbar" data-role="bulkbar">
    <button type="button" class="dp-btn" data-action="selection-start">☑ Sélectionner</button>
    <div class="dp-bulk-active" data-role="bulk-active" hidden>
      <strong data-role="bulk-count">0 sélectionné</strong>
      <button type="button" class="dp-btn" data-action="selection-all">Tout sélectionner</button>
      <select class="dp-select" data-role="bulk-album"><option value="">Ajouter à un album…</option></select>
      <button type="button" class="dp-btn" data-action="bulk-remove-album" hidden>Retirer de l’album</button>
      <button type="button" class="dp-btn dp-danger" data-action="bulk-trash">Corbeille</button>
      <button type="button" class="dp-btn" data-action="bulk-restore" hidden>Restaurer</button>
      <button type="button" class="dp-btn dp-danger" data-action="bulk-delete" hidden>Supprimer définitivement</button>
      <button type="button" class="dp-btn" data-action="selection-cancel">Annuler</button>
    </div>
  </div>

  <section class="dp-panel is-active" data-panel="library">
    <div class="dp-album-context" data-role="album-context" hidden>
      <div><strong>Album : <span data-role="album-context-name"></span></strong><small data-role="album-context-meta"></small></div>
      <div class="dp-album-context-actions"><button type="button" class="dp-btn" data-action="album-context-upload">＋ Importer dans l’album</button><button type="button" class="dp-btn" data-action="album-context-edit">✎ Modifier l’album</button><button type="button" class="dp-btn" data-action="album-context-close">← Toutes les photos</button></div>
    </div>
    <div class="dp-grid" data-role="grid"><div class="dp-empty">Chargement…</div></div><button type="button" class="dp-more" data-action="more" hidden>Afficher plus</button>
  </section>

  <section class="dp-panel" data-panel="albums"><div class="dp-panel-head"><h3>Albums</h3><button type="button" class="dp-btn" data-action="album-create" hidden>＋ Nouvel album</button></div><div class="dp-albums" data-role="albums"></div></section>

  <section class="dp-panel" data-panel="frame">
    <div class="dp-frame-layout">
      <div class="dp-frame" data-role="frame"><div class="dp-empty">Choisissez ce que le cadre doit afficher.</div></div>
      <form class="dp-frame-settings" data-role="frame-form"><h3>Cadre photo</h3><label>Source<select name="source"><option value="all">Toute ma photothèque</option><option value="favorites">Mes favoris</option><option value="album">Un album</option></select></label><label>Album<select name="album_id" data-role="frame-album"></select></label><label>Changement (secondes)<input name="interval" type="number" min="3" max="3600" value="12"></label><label class="dp-check"><input name="shuffle" type="checkbox" checked> Mélanger les photos</label><div class="dp-frame-form-actions"><button class="dp-btn dp-primary" type="submit">Enregistrer</button><button class="dp-btn" type="button" data-action="frame-detach">↗ Détacher le cadre</button></div><small class="dp-help">Le cadre détaché reste ouvert dans le bureau DoMyDesk et peut être déplacé/redimensionné indépendamment du module.</small></form>
    </div>
  </section>

  <section class="dp-panel" data-panel="trash"><div class="dp-grid" data-role="trash-grid"></div></section>

  <input type="file" data-role="file" accept="image/*,video/*,.heic,.heif,.avif,.mkv" multiple hidden>

  <div class="dp-sheet dmd-popup-overlay" data-role="viewer" hidden>
    <section class="dp-sheet-card dp-viewer" role="dialog" aria-modal="true" aria-label="Aperçu du média">
      <div class="dp-sheet-head"><div><strong data-role="viewer-title">Média</strong><small data-role="viewer-meta"></small></div><div class="dp-viewer-nav"><button type="button" class="dp-iconbtn" data-action="viewer-prev" title="Média précédent">‹</button><button type="button" class="dp-iconbtn" data-action="viewer-next" title="Média suivant">›</button><button type="button" class="dp-iconbtn" data-action="viewer-close" title="Fermer">×</button></div></div>
      <div class="dp-viewer-stage" data-role="viewer-stage"></div>
      <div class="dp-viewer-actions"><button class="dp-btn" data-action="favorite">♡ Favori</button><button class="dp-btn" data-action="download">↓ Télécharger</button><select class="dp-select" data-role="album-select"><option value="">Ajouter à un album…</option></select><button class="dp-btn" data-action="album-cover-current" hidden>▣ Définir comme pochette</button><button class="dp-btn" data-action="album-remove-current" hidden>Retirer de l’album</button><button class="dp-btn" data-action="edit">✎ Modifier</button><button class="dp-btn" data-action="viewer-info">ⓘ Infos</button><button class="dp-btn" data-action="viewer-expand">⛶ Agrandir</button><button class="dp-btn dp-danger" data-action="trash">Mettre à la corbeille</button><button class="dp-btn" data-action="restore-viewer" hidden>Restaurer</button><button class="dp-btn dp-danger" data-action="delete-permanent-viewer" hidden>Supprimer définitivement</button></div>
      <div class="dp-details" data-role="viewer-details" hidden></div>
    </section>
  </div>

  <div class="dp-sheet dmd-popup-overlay" data-role="edit-dialog" hidden>
    <form class="dp-sheet-card dp-edit-sheet" data-role="edit-form">
      <div class="dp-sheet-head"><strong>Modifier le média</strong><button type="button" class="dp-iconbtn" data-action="edit-close">×</button></div>
      <label>Titre<input name="title" maxlength="180"></label><label>Description<textarea name="description" rows="4"></textarea></label><label>Tags<input name="tags" placeholder="famille, vacances, montagne"></label><label>Date de prise de vue<input name="captured_at" type="datetime-local"></label>
      <div class="dp-sheet-actions"><button type="button" class="dp-btn" data-action="edit-close">Annuler</button><button type="submit" class="dp-btn dp-primary">Enregistrer</button></div>
    </form>
  </div>

  <div class="dp-sheet dmd-popup-overlay" data-role="album-dialog" hidden>
    <form class="dp-sheet-card dp-album-sheet" data-role="album-form">
      <div class="dp-sheet-head"><strong data-role="album-dialog-title">Album</strong><button type="button" class="dp-iconbtn" data-action="album-close">×</button></div>
      <input type="hidden" name="album_id">
      <label>Nom<input name="name" maxlength="120" required></label>
      <label>Description<textarea name="description" rows="3"></textarea></label>
      <label class="dp-album-cover-field">Pochette de l’album<div class="dp-album-cover-preview" data-role="album-cover-preview"><span>Aucune pochette</span></div><input name="cover_file" type="file" accept="image/*,.heic,.heif,.avif"><small>Optionnel : l’image choisie sera importée dans l’album et utilisée comme pochette. Tu peux aussi définir comme pochette une photo déjà présente dans l’album.</small></label>
      <label>Visibilité<select name="visibility"><option value="private">Privé</option><option value="everyone">Tous les utilisateurs autorisés à DMD-Photos</option><option value="selected">Utilisateurs / rôles sélectionnés</option></select></label>
      <div class="dp-share-grid"><label>Utilisateurs<select name="shared_users" multiple size="5" data-role="share-users"></select></label><label>Rôles métier<select name="shared_roles" multiple size="5" data-role="share-roles"></select></label></div>
      <div class="dp-sheet-actions"><button type="button" class="dp-btn dp-danger" data-action="album-delete" hidden>Supprimer l’album</button><span class="dp-spacer"></span><button type="button" class="dp-btn" data-action="album-close">Annuler</button><button type="submit" class="dp-btn dp-primary">Enregistrer</button></div>
    </form>
  </div>
</section>
<script src="<?=dmdphotos_h($base)?>/DMD-Photos.js?v=<?=$jsv?>"></script>
<script>(function boot(){if(window.DMDPhotosMount){window.DMDPhotosMount(document.getElementById(<?=json_encode($uid)?>));}else{setTimeout(boot,25);}})();</script>
<?php if ($standalone) { ?><script>if('serviceWorker' in navigator){navigator.serviceWorker.register(<?=json_encode($base.'/sw.js')?>).catch(()=>{});}</script></body></html><?php } ?>
