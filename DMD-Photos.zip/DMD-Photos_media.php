<?php
if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
$email=dmdphotos_email();if($email===''||!dmdphotos_can($email,'module.view')){http_response_code(403);exit;}
if(!dmdphotos_db()){http_response_code(503);exit;}
$id=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['id']??''));$kind=(string)($_GET['kind']??'preview');$download=!empty($_GET['download']);$m=dmdphotos_media_row($id);if(!$m||!dmdphotos_photo_accessible($m,$email)){http_response_code(404);exit;}
if($download&&!dmdphotos_can($email,'library.download')){http_response_code(403);exit;}
$file='';$mime='';
if($kind==='thumb'){$file=dmdphotos_thumb_file($id);if(!is_file($file))dmdphotos_make_thumb($m);$mime='image/jpeg';}
elseif($kind==='preview'&&($m['media_type']??'image')==='image'){$file=dmdphotos_preview_file($id);if(!is_file($file))dmdphotos_make_preview($m);$mime='image/jpeg';}
elseif($kind==='transcode'&&($m['media_type']??'')==='video'){$file=dmdphotos_transcode_file($id);if(!is_file($file)&&!empty(dmdphotos_config()['video_transcode']))dmdphotos_make_transcode($m);$mime='video/mp4';}
if($file===''||!is_file($file)){$file=(string)$m['absolute_path'];$mime=(string)($m['mime']??dmdphotos_detect_mime($file));$kind='original';}
if(!is_file($file)){http_response_code(404);exit;}
$size=(int)(@filesize($file)?:0);header('X-Content-Type-Options: nosniff');header('Cache-Control: private, max-age=300');header('Accept-Ranges: bytes');header('Content-Type: '.$mime);
if($download){$name=preg_replace('/[\r\n"]+/','_',basename((string)($m['original_name']??('media.'.$m['extension']))));header('Content-Disposition: attachment; filename="'.$name.'"');}else header('Content-Disposition: inline');
$start=0;$end=max(0,$size-1);$partial=false;$range=(string)($_SERVER['HTTP_RANGE']??'');if(!$download&&$kind!=='thumb'&&$size>0&&preg_match('/bytes=(\d*)-(\d*)/',$range,$mm)){if($mm[1]!==''||$mm[2]!==''){$partial=true;if($mm[1]===''){$len=(int)$mm[2];$start=max(0,$size-$len);}else$start=max(0,(int)$mm[1]);if($mm[2]!=='')$end=min($end,(int)$mm[2]);if($start>$end||$start>=$size){header('Content-Range: bytes */'.$size);http_response_code(416);exit;}}}
$length=max(0,$end-$start+1);if($partial){http_response_code(206);header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);}if($size>0)header('Content-Length: '.$length);if(($_SERVER['REQUEST_METHOD']??'GET')==='HEAD')exit;$fp=@fopen($file,'rb');if(!$fp){http_response_code(404);exit;}if($start>0)fseek($fp,$start);$left=$length;$chunk=1024*1024;while(!feof($fp)&&$left>0){$read=min($chunk,$left);$buf=fread($fp,$read);if($buf===false||$buf==='')break;echo$buf;$left-=strlen($buf);if(connection_aborted())break;}fclose($fp);
