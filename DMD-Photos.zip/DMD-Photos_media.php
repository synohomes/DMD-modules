<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
$email=dmdphotos_email();if($email===''||!dmdphotos_can($email,'module.view')){http_response_code(403);exit;}
$id=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['id']??''));$kind=(string)($_GET['kind']??'original');$download=!empty($_GET['download']);$db=dmdphotos_load_photos();$p=$db['items'][$id]??null;if(!is_array($p)||!dmdphotos_photo_accessible($p,$email)){http_response_code(404);exit;}
if($download&&!dmdphotos_can($email,'photos.download')){http_response_code(403);exit;}
$file=$kind==='thumb'?dmdphotos_thumb_file($id):(string)($p['absolute_path']??'');if($kind==='thumb'&&!is_file($file))dmdphotos_make_thumb($p);if($kind==='thumb'&&!is_file($file)){$file=(string)($p['absolute_path']??'');$kind='original';}if(!is_file($file)){http_response_code(404);exit;}
$mime=$kind==='thumb'?'image/jpeg':(string)($p['mime']??dmdphotos_detect_mime($file));$size=(int)(@filesize($file)?:0);header('X-Content-Type-Options: nosniff');header('Cache-Control: private, max-age=300');header('Accept-Ranges: bytes');header('Content-Type: '.$mime);
if($download){$name=preg_replace('/[\r\n"]+/','_',basename((string)($p['original_name']??('media.'.$p['extension']))));header('Content-Disposition: attachment; filename="'.$name.'"');}else header('Content-Disposition: inline');
$start=0;$end=max(0,$size-1);$partial=false;$range=(string)($_SERVER['HTTP_RANGE']??'');if(!$download&&$kind!=='thumb'&&$size>0&&preg_match('/bytes=(\d*)-(\d*)/',$range,$m)){if($m[1]!==''||$m[2]!==''){$partial=true;if($m[1]===''){$len=(int)$m[2];$start=max(0,$size-$len);}else{$start=max(0,(int)$m[1]);}if($m[2]!=='')$end=min($end,(int)$m[2]);if($start>$end||$start>=$size){header('Content-Range: bytes */'.$size);http_response_code(416);exit;}}}
$length=max(0,$end-$start+1);if($partial){http_response_code(206);header('Content-Range: bytes '.$start.'-'.$end.'/'.$size);}if($size>0)header('Content-Length: '.$length);if(($_SERVER['REQUEST_METHOD']??'GET')==='HEAD')exit;$fp=@fopen($file,'rb');if(!$fp){http_response_code(404);exit;}if($start>0)fseek($fp,$start);$left=$length;$chunk=1024*1024;while(!feof($fp)&&$left>0){$read=min($chunk,$left);$buf=fread($fp,$read);if($buf===false||$buf==='')break;echo $buf;$left-=strlen($buf);if(connection_aborted())break;}fclose($fp);
