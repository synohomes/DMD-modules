const CACHE='dmd-photos-shell-v200';
const SHELL=['./DMD-Photos_app.php','./DMD-Photos.css','./DMD-Photos.js','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>Promise.all(SHELL.map(x=>c.add(x).catch(()=>null)))).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||/DMD-Photos_(api|media|upload|export|share|pwa_share)/.test(u.pathname))return;e.respondWith(fetch(e.request).then(r=>{const clone=r.clone();caches.open(CACHE).then(c=>c.put(e.request,clone)).catch(()=>{});return r;}).catch(()=>caches.match(e.request).then(r=>r||caches.match('./DMD-Photos_app.php'))));});
