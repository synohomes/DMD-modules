<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
$token=(string)($_GET['t']??($_POST['t']??''));$share=$token!==''?dmdphotos_share_lookup($token):null;if(!$share){http_response_code(404);exit('Partage DMD-Photos introuvable ou expiré.');}
$error='';if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'&&isset($_POST['password'])){if(!dmdphotos_share_authorized($share,$token,(string)$_POST['password']))$error='Mot de passe incorrect.';}
$auth=dmdphotos_share_authorized($share,$token,'');
if($auth){dmdphotos_db_exec('UPDATE shares SET last_access_at=?,access_count=access_count+1 WHERE id=?',array(dmdphotos_now(),$share['id']));}
if($auth&&!empty($_GET['zip'])){if(empty($share['allow_download'])){http_response_code(403);exit('Téléchargement interdit.');}if(!class_exists('ZipArchive')){http_response_code(503);exit('ZipArchive indisponible.');}$rows=dmdphotos_db_all('SELECT m.* FROM album_items i JOIN media m ON m.id=i.media_id WHERE i.album_id=? AND m.trashed_at="" ORDER BY i.position',array($share['album_id']));$tmp=dmdphotos_data_dir(true).'tmp/share-'.dmdphotos_id('Z').'.zip';$z=new ZipArchive();$z->open($tmp,ZipArchive::CREATE|ZipArchive::OVERWRITE);$seen=array();foreach($rows as $m){$p=(string)$m['absolute_path'];if(!is_file($p))continue;$n=preg_replace('/[^A-Za-z0-9._ -]+/u','_',basename((string)$m['original_name']));if(isset($seen[dmdphotos_lower($n)]))$n=$m['id'].'-'.$n;$seen[dmdphotos_lower($n)]=true;$z->addFile($p,$n);}$z->close();header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="DMD-Photos-Album.zip"');header('Content-Length: '.filesize($tmp));readfile($tmp);@unlink($tmp);exit;}
$base=dmdphotos_module_base_url();
?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="color-scheme" content="dark light"><title><?=dmdphotos_h($share['album_name'])?> — DMD-Photos</title><link rel="stylesheet" href="<?=dmdphotos_h($base)?>/DMD-Photos.css?v=200"></head><body class="dp-public"><main class="dp-share-page"><header class="dp-share-head"><div><strong>DMD-Photos</strong><h1><?=dmdphotos_h($share['album_name'])?></h1><p><?=dmdphotos_h($share['album_description'])?></p></div><small>Partage externe protégé · expiration <?=dmdphotos_h(date('d/m/Y H:i',strtotime($share['expires_at'])))?></small></header><?php if(!$auth):?><section class="dp-share-login"><h2>Album protégé</h2><p>Saisis le mot de passe transmis avec le QR code.</p><?php if($error!==''):?><div class="dp-message is-error"><?=dmdphotos_h($error)?></div><?php endif;?><form method="post"><input type="hidden" name="t" value="<?=dmdphotos_h($token)?>"><label>Mot de passe<input type="password" name="password" required autofocus autocomplete="current-password"></label><button class="dp-btn dp-primary" type="submit">Ouvrir l’album</button></form></section><?php else:$rows=dmdphotos_db_all('SELECT m.* FROM album_items i JOIN media m ON m.id=i.media_id WHERE i.album_id=? AND m.trashed_at="" ORDER BY i.position,i.added_at',array($share['album_id']));?><div class="dp-share-actions"><?php if(!empty($share['allow_download'])):?><a class="dp-btn" href="?t=<?=rawurlencode($token)?>&zip=1">↓ Télécharger l’album</a><?php endif;?><?php if(!empty($share['allow_upload'])):?><form class="dp-guest-upload" method="post" enctype="multipart/form-data" action="<?=dmdphotos_h($base)?>/DMD-Photos_share_target.php"><input type="hidden" name="t" value="<?=dmdphotos_h($token)?>"><label class="dp-btn">＋ Ajouter des photos<input type="file" name="files[]" accept="image/*,video/*" multiple hidden onchange="this.form.submit()"></label></form><?php endif;?></div><section class="dp-public-grid"><?php foreach($rows as $m):$kind=($m['media_type']==='video')?'transcode':'preview';?><a class="dp-public-card" href="<?=dmdphotos_h($base)?>/DMD-Photos_share_media.php?t=<?=rawurlencode($token)?>&id=<?=rawurlencode($m['id'])?>&kind=<?=$kind?>" target="_blank"><img loading="lazy" src="<?=dmdphotos_h($base)?>/DMD-Photos_share_media.php?t=<?=rawurlencode($token)?>&id=<?=rawurlencode($m['id'])?>&kind=thumb" alt=""><span><?=dmdphotos_h($m['title']?:$m['original_name'])?></span></a><?php endforeach;?></section><?php if(!$rows):?><div class="dp-empty">Cet album est vide.</div><?php endif;endif;?></main></body></html>
