<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if(PHP_SAPI!=='cli'){http_response_code(403);exit('CLI uniquement.');}
require_once __DIR__.'/DMD-Photos_lib.php';
if(!dmdphotos_db()){fwrite(STDERR,"DMD-Photos: pdo_sqlite indisponible.\n");exit(2);}
$loop=in_array('--loop',$argv,true);$once=in_array('--once',$argv,true)||!$loop;$limit=(int)(dmdphotos_config()['job_batch']??3);$sleep=2;
foreach($argv as $arg){if(strpos($arg,'--limit=')===0)$limit=max(1,min(50,(int)substr($arg,8)));if(strpos($arg,'--sleep=')===0)$sleep=max(1,min(60,(int)substr($arg,8)));}
$lastPurge=0;
do{
    $n=dmdphotos_run_jobs($limit);
    if(time()-$lastPurge>=3600){$cfg=dmdphotos_config();if(!empty($cfg['auto_purge'])&&(int)$cfg['trash_days']>0)dmdphotos_purge_trash(false);$lastPurge=time();}
    if($n>0)fwrite(STDOUT,date('c')." - $n job(s) traité(s).\n");
    if($once)break;
    if($n===0)sleep($sleep);
}while(true);
