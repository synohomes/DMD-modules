<?php
require_once __DIR__.'/DMD-Photos_lib.php';

$token=(string)($_GET['q']??'');
$payload=dmdphotos_quick_share_parse($token);

if(!$payload){
    http_response_code(404);
    exit('Partage expiré ou invalide.');
}

$type=(string)$payload['type'];
$id=preg_replace('/[^A-Za-z0-9_-]/','',(string)$payload['id']);
$items=array();
$title='DMD-Photos';

if($type==='album'){
    $album=dmdphotos_album_row($id);
    if(!$album){
        http_response_code(404);
        exit('Album introuvable.');
    }
    $title=(string)$album['name'];
    $rows=dmdphotos_db_all('SELECT m.* FROM album_items i JOIN media m ON m.id=i.media_id WHERE i.album_id=? AND m.trashed_at="" AND m.media_type="image" ORDER BY i.position,i.added_at',array($id));
    foreach($rows as $m)$items[]=$m;
}else{
    $m=dmdphotos_media_row($id);
    if(!$m||($m['media_type']??'')!=='image'||($m['trashed_at']??'')!==''){
        http_response_code(404);
        exit('Photo introuvable.');
    }
    $title=(string)($m['title']?:$m['original_name']);
    $items[]=$m;
}

$base=dmdphotos_module_base_url();
$expires=(int)$payload['exp'];
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?=dmdphotos_h($title)?> — DMD-Photos</title>
<style>
:root{color-scheme:dark light}*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:Canvas;color:CanvasText}.qs{width:min(1100px,100%);margin:auto;padding:14px}.qs-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:12px}.qs-head div{min-width:0}.qs-head strong{display:block;font-size:12px;opacity:.7}.qs-head h1{margin:3px 0 0;font-size:18px;overflow-wrap:anywhere}.qs-head small{font-size:11px;opacity:.7;text-align:right}.qs-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:8px}.qs-card{display:block;overflow:hidden;border:1px solid color-mix(in srgb,CanvasText 22%,transparent);border-radius:12px;background:color-mix(in srgb,Canvas 94%,CanvasText 6%);text-decoration:none;color:inherit}.qs-card img{display:block;width:100%;aspect-ratio:1/1;object-fit:cover}.qs-card span{display:block;padding:8px;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.qs-one{display:grid;place-items:center;min-height:calc(100vh - 100px)}.qs-one img{display:block;max-width:100%;max-height:calc(100vh - 120px);object-fit:contain;border-radius:12px}.qs-empty{padding:40px;text-align:center;opacity:.7}@media(max-width:520px){.qs{padding:9px}.qs-head{display:block}.qs-head small{display:block;text-align:left;margin-top:4px}.qs-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:5px}.qs-card{border-radius:8px}.qs-card span{padding:6px;font-size:10px}}
</style>
</head>
<body>
<main class="qs">
<header class="qs-head">
<div><strong>DMD-Photos · partage rapide</strong><h1><?=dmdphotos_h($title)?></h1></div>
<small>Disponible jusqu’au <?=dmdphotos_h(date('d/m/Y H:i',$expires))?></small>
</header>
<?php if(!$items):?>
<div class="qs-empty">Aucune photo à afficher.</div>
<?php elseif($type==='photo'): $m=$items[0]; ?>
<div class="qs-one"><img src="<?=dmdphotos_h($base)?>/DMD-Photos_quick_share_media.php?q=<?=rawurlencode($token)?>&id=<?=rawurlencode($m['id'])?>&kind=preview" alt=""></div>
<?php else:?>
<section class="qs-grid">
<?php foreach($items as $m):?>
<a class="qs-card" href="<?=dmdphotos_h($base)?>/DMD-Photos_quick_share_media.php?q=<?=rawurlencode($token)?>&id=<?=rawurlencode($m['id'])?>&kind=preview" target="_blank">
<img loading="lazy" src="<?=dmdphotos_h($base)?>/DMD-Photos_quick_share_media.php?q=<?=rawurlencode($token)?>&id=<?=rawurlencode($m['id'])?>&kind=thumb" alt="">
<span><?=dmdphotos_h($m['title']?:$m['original_name'])?></span>
</a>
<?php endforeach;?>
</section>
<?php endif;?>
</main>
</body>
</html>
