<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
dmdphotos_require('module.view');$email=dmdphotos_email();if(!dmdphotos_can($email,'mydesk.frame')){http_response_code(403);exit('Cadre DMD-Photos non autorisé.');}
dmdphotos_require_engine();dmdphotos_ensure_default_frame($email);$frames=dmdphotos_frames($email);$frameId=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['frame']??''));$frame=null;foreach($frames as $f)if((string)$f['id']===$frameId){$frame=$f;break;}if(!$frame)$frame=$frames[0]??null;$items=$frame?dmdphotos_frame_items($frame,$email,250):array();$base=dmdphotos_module_base_url();$theme=dmdphotos_theme_url($email);$uid='dpmd_'.substr(hash('sha256',session_id().'|'.microtime(true)),0,10);
?>
<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DMD-Photos</title><link rel="stylesheet" href="<?=dmdphotos_h($theme)?>"><link rel="stylesheet" href="<?=dmdphotos_h($base)?>/DMD-Photos-mydesk.css?v=<?=is_file(__DIR__.'/DMD-Photos-mydesk.css')?filemtime(__DIR__.'/DMD-Photos-mydesk.css'):1?>"></head><body>
<section id="<?=dmdphotos_h($uid)?>" class="dpmd dpmd-<?=dmdphotos_h((string)($frame['transition']??'fade'))?>" data-media="<?=dmdphotos_h($base)?>/DMD-Photos_media.php" data-interval="<?=max(3,(int)($frame['interval_seconds']??12))?>" data-layout="<?=dmdphotos_h((string)($frame['layout']??'single'))?>" data-caption="<?=!empty($frame['show_caption'])?'1':'0'?>" data-kiosk="<?=!empty($frame['kiosk'])?'1':'0'?>">
 <div class="dpmd-stage" data-stage><div class="dpmd-empty">Aucune photo dans cette sélection.</div></div>
 <header class="dpmd-bar"><div class="dpmd-ident"><strong><?=dmdphotos_h((string)($frame['name']??'DMD-Photos'))?></strong><small data-caption>Cadre photo</small></div><div class="dpmd-actions"><select data-frame-select title="Cadre"><?php foreach($frames as $f):?><option value="<?=dmdphotos_h($f['id'])?>" <?=$frame&&$f['id']===$frame['id']?'selected':''?>><?=dmdphotos_h($f['name'])?></option><?php endforeach;?></select><button data-action="prev" title="Précédente">‹</button><button data-action="pause" title="Pause">Ⅱ</button><button data-action="next" title="Suivante">›</button><?php if(dmdphotos_can($email,'mydesk.kiosk')):?><button data-action="fullscreen" title="Plein écran">⛶</button><?php endif;?></div></header>
</section>
<script>window.DP_MYDESK_ITEMS=<?=json_encode($items,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)?>;</script>
<script>(()=>{const r=document.getElementById(<?=json_encode($uid)?>),stage=r.querySelector('[data-stage]'),cap=r.querySelector('[data-caption]'),base=r.dataset.media,items=window.DP_MYDESK_ITEMS||[],layout=r.dataset.layout||'single';let i=0,paused=false,timer=null;const url=x=>base+'?id='+encodeURIComponent(x.id)+'&kind=preview';const date=x=>{if(!x.captured_at)return'';const d=new Date(String(x.captured_at).replace(' ','T'));return isNaN(d)?'':d.toLocaleDateString('fr-FR')};function draw(){if(!items.length){stage.innerHTML='<div class="dpmd-empty">Aucune photo dans cette sélection.</div>';cap.textContent='Cadre photo';return}stage.className='dpmd-stage dpmd-layout-'+layout;if(layout==='mosaic'){const arr=[];for(let k=0;k<4;k++)arr.push(items[(i+k)%items.length]);stage.innerHTML=arr.map(x=>'<img src="'+url(x)+'" alt="">').join('');cap.textContent=items.length+' photos'}else{const x=items[i%items.length];stage.innerHTML='<img src="'+url(x)+'" alt="">';cap.textContent=(x.title||x.original_name||'Photo')+(date(x)?' · '+date(x):'')}stage.classList.remove('dpmd-anim');requestAnimationFrame(()=>stage.classList.add('dpmd-anim'))}function restart(){clearInterval(timer);timer=setInterval(()=>{if(!paused&&items.length){i=(i+1)%items.length;draw()}},Math.max(3,Number(r.dataset.interval||12))*1000)}r.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(!b)return;const a=b.dataset.action;if(a==='prev'&&items.length){i=(i-1+items.length)%items.length;draw()}else if(a==='next'&&items.length){i=(i+1)%items.length;draw()}else if(a==='pause'){paused=!paused;b.textContent=paused?'▶':'Ⅱ'}else if(a==='fullscreen'){if(document.fullscreenElement)document.exitFullscreen?.();else document.documentElement.requestFullscreen?.()}});r.querySelector('[data-frame-select]')?.addEventListener('change',e=>{const u=new URL(location.href);u.searchParams.set('frame',e.target.value);location.replace(u.toString())});draw();restart();})();</script>
</body></html>
