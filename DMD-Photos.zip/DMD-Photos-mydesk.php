<?php
if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';

dmdphotos_require('module.view');
$email=dmdphotos_email();

if(!dmdphotos_can($email,'mydesk.frame')){
    http_response_code(403);
    exit('Cadre DMD-Photos non autorisé.');
}

dmdphotos_require_engine();
dmdphotos_ensure_default_frame($email);

$frames=dmdphotos_frames($email);
$frameId=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['frame']??''));
$frame=null;

foreach($frames as $f){
    if((string)$f['id']===$frameId){
        $frame=$f;
        break;
    }
}

if(!$frame)$frame=$frames[0]??null;

$items=$frame?dmdphotos_frame_items($frame,$email,250):array();
$base=dmdphotos_module_base_url();
$theme=dmdphotos_theme_url($email);
$uid='dpmd_'.substr(hash('sha256',session_id().'|'.microtime(true)),0,10);
$canManage=dmdphotos_can($email,'mydesk.manage_frames');
$canShare=dmdphotos_can($email,'sharing.external')&&!empty(dmdphotos_config()['external_shares']);
$csrf=dmdphotos_csrf();
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DMD-Photos</title>
<link rel="stylesheet" href="<?=dmdphotos_h($theme)?>">
<link rel="stylesheet" href="<?=dmdphotos_h($base)?>/DMD-Photos-mydesk.css?v=<?=is_file(__DIR__.'/DMD-Photos-mydesk.css')?filemtime(__DIR__.'/DMD-Photos-mydesk.css'):1?>">
</head>
<body>
<section
 id="<?=dmdphotos_h($uid)?>"
 class="dpmd dpmd-<?=dmdphotos_h((string)($frame['transition']??'fade'))?>"
 data-api="<?=dmdphotos_h($base)?>/DMD-Photos_api.php"
 data-media="<?=dmdphotos_h($base)?>/DMD-Photos_media.php"
 data-interval="<?=max(3,(int)($frame['interval_seconds']??12))?>"
 data-layout="<?=dmdphotos_h((string)($frame['layout']??'single'))?>"
 data-caption="<?=!empty($frame['show_caption'])?'1':'0'?>"
 data-kiosk="<?=!empty($frame['kiosk'])?'1':'0'?>"
 data-frame-id="<?=dmdphotos_h((string)($frame['id']??''))?>"
 data-source-type="<?=dmdphotos_h((string)($frame['source_type']??'all'))?>"
 data-source-id="<?=dmdphotos_h((string)($frame['source_id']??''))?>"
 data-csrf="<?=dmdphotos_h($csrf)?>"
>
 <div class="dpmd-stage" data-stage><div class="dpmd-empty">Choisissez un album ou une photo pour votre cadre.</div></div>

 <header class="dpmd-bar">
  <div class="dpmd-ident">
   <strong><?=dmdphotos_h((string)($frame['name']??'DMD-Photos'))?></strong>
   <small data-caption>Cadre photo</small>
  </div>
  <div class="dpmd-actions">
   <select data-frame-select title="Cadre">
    <?php foreach($frames as $f):?>
    <option value="<?=dmdphotos_h($f['id'])?>" <?=$frame&&$f['id']===$frame['id']?'selected':''?>><?=dmdphotos_h($f['name'])?></option>
    <?php endforeach;?>
   </select>
   <?php if($canManage):?><button data-action="source" title="Choisir un album ou une photo">▣</button><?php endif;?>
   <?php if($canShare):?><button data-action="qr" title="Partage rapide par QR code">QR</button><?php endif;?>
   <button data-action="prev" title="Précédente">‹</button>
   <button data-action="pause" title="Pause">Ⅱ</button>
   <button data-action="next" title="Suivante">›</button>
   <?php if(dmdphotos_can($email,'mydesk.kiosk')):?><button data-action="fullscreen" title="Plein écran">⛶</button><?php endif;?>
  </div>
 </header>

 <?php if($canManage):?>
 <div class="dpmd-overlay" data-source-overlay hidden>
  <section class="dpmd-sheet">
   <header><div><strong>Contenu du cadre</strong><small>Choisissez un album ou une photo.</small></div><button data-action="source-close">×</button></header>
   <nav class="dpmd-tabs">
    <button class="is-active" data-source-tab="album">Albums</button>
    <button data-source-tab="photo">Photo</button>
   </nav>
   <div class="dpmd-source-pane" data-pane="album">
    <label>Album<select data-album-select><option value="">Choisir un album…</option></select></label>
    <button class="dpmd-primary" data-action="album-use">Afficher cet album</button>
   </div>
   <div class="dpmd-source-pane" data-pane="photo" hidden>
    <div class="dpmd-photo-search"><input type="search" data-photo-search placeholder="Rechercher une photo…"><button data-action="photo-search">Rechercher</button></div>
    <div class="dpmd-photo-grid" data-photo-grid><div class="dpmd-mini-empty">Chargement…</div></div>
   </div>
  </section>
 </div>
 <?php endif;?>

 <?php if($canShare):?>
 <div class="dpmd-overlay" data-qr-overlay hidden>
  <section class="dpmd-sheet dpmd-qr-sheet">
   <header><div><strong>Partage rapide</strong><small data-qr-meta>QR code temporaire</small></div><button data-action="qr-close">×</button></header>
   <div class="dpmd-qr" data-qrcode></div>
   <input class="dpmd-share-url" data-share-url readonly>
   <div class="dpmd-qr-actions">
    <select data-share-duration>
     <option value="15">15 minutes</option>
     <option value="60" selected>1 heure</option>
     <option value="360">6 heures</option>
     <option value="1440">24 heures</option>
    </select>
    <button data-action="qr-copy">Copier le lien</button>
    <button class="dpmd-primary" data-action="qr-refresh">Nouveau QR</button>
   </div>
  </section>
 </div>
 <?php endif;?>
</section>

<script>
window.DP_MYDESK_ITEMS=<?=json_encode($items,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)?>;
</script>
<script>
(()=>{
const r=document.getElementById(<?=json_encode($uid)?>);
const stage=r.querySelector('[data-stage]');
const cap=r.querySelector('[data-caption]');
const mediaBase=r.dataset.media;
const api=r.dataset.api;
const csrf=r.dataset.csrf;
let items=window.DP_MYDESK_ITEMS||[];
let layout=r.dataset.layout||'single';
let i=0;
let paused=false;
let timer=null;
let pickerLoaded=false;
let currentSourceType=r.dataset.sourceType||'all';
let currentSourceId=r.dataset.sourceId||'';

const esc=v=>String(v??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]));
const url=x=>mediaBase+'?id='+encodeURIComponent(x.id)+'&kind=preview';
const thumb=x=>mediaBase+'?id='+encodeURIComponent(x.id)+'&kind=thumb';

function date(x){
 if(!x.captured_at)return'';
 const d=new Date(String(x.captured_at).replace(' ','T'));
 return isNaN(d)?'':d.toLocaleDateString('fr-FR');
}

function draw(){
 if(!items.length){
  stage.innerHTML='<div class="dpmd-empty">Choisissez un album ou une photo pour votre cadre.</div>';
  cap.textContent='Cadre photo';
  return;
 }
 stage.className='dpmd-stage dpmd-layout-'+layout;
 if(layout==='mosaic'&&items.length>1){
  const arr=[];
  for(let k=0;k<Math.min(4,items.length);k++)arr.push(items[(i+k)%items.length]);
  stage.innerHTML=arr.map(x=>'<img src="'+url(x)+'" alt="">').join('');
  cap.textContent=items.length+' photos';
 }else{
  const x=items[i%items.length];
  stage.innerHTML='<img src="'+url(x)+'" alt="">';
  cap.textContent=(x.title||x.original_name||'Photo')+(date(x)?' · '+date(x):'');
 }
 stage.classList.remove('dpmd-anim');
 requestAnimationFrame(()=>stage.classList.add('dpmd-anim'));
}

function restart(){
 clearInterval(timer);
 timer=setInterval(()=>{
  if(!paused&&items.length>1){
   i=(i+1)%items.length;
   draw();
  }
 },Math.max(3,Number(r.dataset.interval||12))*1000);
}

async function get(action,params={}){
 const u=new URL(api,location.href);
 u.searchParams.set('action',action);
 Object.entries(params).forEach(([k,v])=>u.searchParams.set(k,v));
 const res=await fetch(u,{credentials:'same-origin',cache:'no-store'});
 const data=await res.json().catch(()=>({ok:false,error:'Réponse invalide.'}));
 if(!res.ok||!data.ok)throw new Error(data.error||'Erreur.');
 return data;
}

async function post(action,data={}){
 const res=await fetch(api,{
  method:'POST',
  credentials:'same-origin',
  cache:'no-store',
  headers:{'Content-Type':'application/json'},
  body:JSON.stringify({...data,action,csrf})
 });
 const body=await res.json().catch(()=>({ok:false,error:'Réponse invalide.'}));
 if(!res.ok||!body.ok)throw new Error(body.error||'Erreur.');
 return body;
}

function setBusy(el,busy){
 if(!el)return;
 el.disabled=busy;
 el.classList.toggle('is-busy',busy);
}

async function loadPicker(q=''){
 const albumSelect=r.querySelector('[data-album-select]');
 const grid=r.querySelector('[data-photo-grid]');
 if(grid)grid.innerHTML='<div class="dpmd-mini-empty">Chargement…</div>';
 const data=await get('mydesk_picker',{q});
 if(albumSelect){
  albumSelect.innerHTML='<option value="">Choisir un album…</option>'+data.albums.map(a=>'<option value="'+esc(a.id)+'">'+esc(a.name)+' · '+Number(a.count||0)+' photo(s)</option>').join('');
  if(currentSourceType==='album')albumSelect.value=currentSourceId;
 }
 if(grid){
  if(!data.photos.length)grid.innerHTML='<div class="dpmd-mini-empty">Aucune photo.</div>';
  else grid.innerHTML=data.photos.map(p=>'<button class="dpmd-photo-choice '+(currentSourceType==='photo'&&currentSourceId===p.id?'is-active':'')+'" data-photo-id="'+esc(p.id)+'" title="'+esc(p.title||p.original_name||'Photo')+'"><img loading="lazy" src="'+thumb(p)+'" alt=""><span>'+esc(p.title||p.original_name||'Photo')+'</span></button>').join('');
 }
 pickerLoaded=true;
}

async function useSource(type,id,button){
 if(!id)return;
 setBusy(button,true);
 try{
  const data=await post('mydesk_frame_source',{frame_id:r.dataset.frameId,source_type:type,source_id:id});
  currentSourceType=type;
  currentSourceId=id;
  r.dataset.sourceType=type;
  r.dataset.sourceId=id;
  items=Array.isArray(data.items)?data.items:[];
  i=0;
  r.querySelector('[data-source-overlay]')?.setAttribute('hidden','');
  draw();
  restart();
 }catch(e){
  alert(e.message);
 }finally{
  setBusy(button,false);
 }
}

async function makeQR(target){
 const box=r.querySelector('[data-qrcode]');
 if(!box)return;
 box.innerHTML='';
 try{
  if(!window.QRCode){
   await new Promise((resolve,reject)=>{
    const s=document.createElement('script');
    s.src='https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
    s.onload=resolve;
    s.onerror=reject;
    document.head.appendChild(s);
   });
  }
  if(!window.QRCode)throw new Error();
  new QRCode(box,{text:target,width:190,height:190,correctLevel:QRCode.CorrectLevel.M});
 }catch(e){
  box.innerHTML='<div class="dpmd-qr-fallback">QR indisponible.<br>'+esc(target)+'</div>';
 }
}

async function createQR(button){
 const duration=Number(r.querySelector('[data-share-duration]')?.value||60);
 setBusy(button,true);
 const overlay=r.querySelector('[data-qr-overlay]');
 const box=r.querySelector('[data-qrcode]');
 if(overlay)overlay.hidden=false;
 if(box)box.innerHTML='<div class="dpmd-mini-empty">Création du QR…</div>';
 try{
  const data=await post('mydesk_quick_share',{frame_id:r.dataset.frameId,minutes:duration});
  currentSourceType=data.source_type||currentSourceType;
  currentSourceId=data.source_id||currentSourceId;
  r.dataset.sourceType=currentSourceType;
  r.dataset.sourceId=currentSourceId;
  const input=r.querySelector('[data-share-url]');
  const meta=r.querySelector('[data-qr-meta]');
  if(input)input.value=data.url;
  if(meta)meta.textContent=(data.label||'Partage')+' · expire '+new Date(data.expires_at).toLocaleString('fr-FR');
  await makeQR(data.url);
 }catch(e){
  if(box)box.innerHTML='<div class="dpmd-mini-empty">'+esc(e.message)+'</div>';
 }finally{
  setBusy(button,false);
 }
}

r.addEventListener('click',async e=>{
 const b=e.target.closest('[data-action]');
 if(!b)return;
 const a=b.dataset.action;

 if(a==='prev'&&items.length){
  i=(i-1+items.length)%items.length;
  draw();
 }else if(a==='next'&&items.length){
  i=(i+1)%items.length;
  draw();
 }else if(a==='pause'){
  paused=!paused;
  b.textContent=paused?'▶':'Ⅱ';
 }else if(a==='fullscreen'){
  if(document.fullscreenElement)document.exitFullscreen?.();
  else document.documentElement.requestFullscreen?.();
 }else if(a==='source'){
  const o=r.querySelector('[data-source-overlay]');
  if(o)o.hidden=false;
  if(!pickerLoaded){
   try{await loadPicker('');}catch(err){alert(err.message);}
  }
 }else if(a==='source-close'){
  const o=r.querySelector('[data-source-overlay]');
  if(o)o.hidden=true;
 }else if(a==='album-use'){
  const select=r.querySelector('[data-album-select]');
  await useSource('album',select?.value||'',b);
 }else if(a==='photo-search'){
  try{await loadPicker(r.querySelector('[data-photo-search]')?.value||'');}catch(err){alert(err.message);}
 }else if(a==='qr'){
  await createQR(b);
 }else if(a==='qr-refresh'){
  await createQR(b);
 }else if(a==='qr-close'){
  const o=r.querySelector('[data-qr-overlay]');
  if(o)o.hidden=true;
 }else if(a==='qr-copy'){
  const input=r.querySelector('[data-share-url]');
  if(!input?.value)return;
  try{await navigator.clipboard.writeText(input.value);}catch(err){input.select();document.execCommand('copy');}
 }
});

r.querySelector('[data-photo-grid]')?.addEventListener('click',async e=>{
 const b=e.target.closest('[data-photo-id]');
 if(!b)return;
 await useSource('photo',b.dataset.photoId,b);
});

r.querySelector('[data-source-overlay]')?.addEventListener('click',e=>{
 if(e.target===e.currentTarget)e.currentTarget.hidden=true;
});

r.querySelector('[data-qr-overlay]')?.addEventListener('click',e=>{
 if(e.target===e.currentTarget)e.currentTarget.hidden=true;
});

r.querySelectorAll('[data-source-tab]').forEach(tab=>{
 tab.addEventListener('click',()=>{
  r.querySelectorAll('[data-source-tab]').forEach(x=>x.classList.toggle('is-active',x===tab));
  r.querySelectorAll('[data-pane]').forEach(p=>p.hidden=p.dataset.pane!==tab.dataset.sourceTab);
 });
});

r.querySelector('[data-photo-search]')?.addEventListener('keydown',e=>{
 if(e.key==='Enter'){
  e.preventDefault();
  r.querySelector('[data-action="photo-search"]')?.click();
 }
});

r.querySelector('[data-frame-select]')?.addEventListener('change',e=>{
 const u=new URL(location.href);
 u.searchParams.set('frame',e.target.value);
 location.replace(u.toString());
});

draw();
restart();
})();
</script>
</body>
</html>
