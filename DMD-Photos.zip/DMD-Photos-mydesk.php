<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if(session_status()===PHP_SESSION_NONE)session_start();require_once __DIR__.'/DMD-Photos_lib.php';dmdphotos_require('module.view');$email=dmdphotos_email();$base=dmdphotos_module_base_url();$theme=dmdphotos_theme_url($email);$prefs=dmdphotos_user_prefs($email);$frame=$prefs['frame']??array();$filter='all';if(($frame['source']??'')==='favorites')$filter='favorites';elseif(($frame['source']??'')==='album'&&!empty($frame['album_id']))$filter='album:'.$frame['album_id'];$list=dmdphotos_list($email,array('filter'=>$filter,'limit'=>250));$items=array_values(array_filter($list['items'],function($p){return($p['media_type']??'image')==='image';}));if(!empty($frame['shuffle']))shuffle($items);$uid='dpmd_'.substr(hash('sha256',session_id().'|'.microtime(true)),0,10);$full=$base.'/DMD-Photos.php?pwa=1';?>
<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DMD-Photos</title><link rel="stylesheet" href="<?=dmdphotos_h($theme)?>"><link rel="stylesheet" href="<?=dmdphotos_h($base)?>/DMD-Photos-mydesk.css?v=<?=is_file(__DIR__.'/DMD-Photos-mydesk.css')?filemtime(__DIR__.'/DMD-Photos-mydesk.css'):1?>"></head><body><section id="<?=dmdphotos_h($uid)?>" class="dpmd" data-media="<?=dmdphotos_h($base)?>/DMD-Photos_media.php" data-full="<?=dmdphotos_h($full)?>" data-interval="<?=max(3,(int)($frame['interval']??12))?>"><div class="dpmd-stage" data-stage><div class="dpmd-empty">Aucune photo dans cette sélection.</div></div><header class="dpmd-bar"><div><strong>DMD-Photos</strong><small data-caption>Cadre photo</small></div><div class="dpmd-actions"><button data-action="prev" title="Précédente">‹</button><button data-action="pause" title="Pause">Ⅱ</button><button data-action="next" title="Suivante">›</button><button data-action="full" title="Ouvrir DMD-Photos">↗</button></div></header></section><script>const DP_ITEMS=<?=json_encode($items,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)?>;</script><script>(()=>{const r=document.getElementById(<?=json_encode($uid)?>),stage=r.querySelector('[data-stage]'),cap=r.querySelector('[data-caption]'),base=r.dataset.media;let i=0,p=false,t=null;const url=x=>base+'?id='+encodeURIComponent(x.id)+'&kind=original';function draw(){const x=DP_ITEMS[i];if(!x){stage.innerHTML='<div class="dpmd-empty">Aucune photo dans cette sélection.</div>';cap.textContent='Cadre photo';return;}stage.innerHTML='<img src="'+url(x)+'" alt="">';cap.textContent=(x.title||x.original_name||'Photo')+(x.captured_at?' · '+new Date(x.captured_at).toLocaleDateString():'');}function tick(){clearInterval(t);t=setInterval(()=>{if(!p&&DP_ITEMS.length){i=(i+1)%DP_ITEMS.length;draw()}},Math.max(3,Number(r.dataset.interval||12))*1000)}r.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(!b)return;if(b.dataset.action==='prev'&&DP_ITEMS.length){i=(i-1+DP_ITEMS.length)%DP_ITEMS.length;draw()}if(b.dataset.action==='next'&&DP_ITEMS.length){i=(i+1)%DP_ITEMS.length;draw()}if(b.dataset.action==='pause'){p=!p;b.textContent=p?'▶':'Ⅱ'}if(b.dataset.action==='full')window.open(r.dataset.full,'_blank','noopener')});draw();tick()})();</script></body></html>
