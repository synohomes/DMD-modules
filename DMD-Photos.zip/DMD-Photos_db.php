<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */


if (!function_exists('dmdphotos_db_available')) {
    function dmdphotos_db_available() {
        if (!class_exists('PDO')) return false;
        try { return in_array('sqlite', PDO::getAvailableDrivers(), true); }
        catch (Throwable $e) { return false; }
    }
}
if (!function_exists('dmdphotos_db_path')) {
    function dmdphotos_db_path() {
        $dir = dmdphotos_data_dir(true) . 'db';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        if (function_exists('dmd_ensure_denied_directory')) @dmd_ensure_denied_directory($dir);
        return rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . 'catalog.sqlite';
    }
}
if (!function_exists('dmdphotos_db')) {
    function dmdphotos_db() {
        static $pdo = null;
        static $failed = false;
        if ($pdo instanceof PDO) return $pdo;
        if ($failed || !dmdphotos_db_available()) return null;
        try {
            $pdo = new PDO('sqlite:' . dmdphotos_db_path());
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA busy_timeout = 5000');
            try { $pdo->exec('PRAGMA journal_mode = WAL'); } catch (Throwable $e) {}
            try { $pdo->exec('PRAGMA synchronous = NORMAL'); } catch (Throwable $e) {}
            dmdphotos_db_schema($pdo);
            dmdphotos_db_migrate_legacy($pdo);
            dmdphotos_db_rehome_originals($pdo);
            return $pdo;
        } catch (Throwable $e) {
            $failed = true;
            $pdo = null;
            return null;
        }
    }
}
if (!function_exists('dmdphotos_db_schema')) {
    function dmdphotos_db_schema(PDO $pdo) {
        $sql = array(
            "CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL DEFAULT '')",
            "CREATE TABLE IF NOT EXISTS media (
                id TEXT PRIMARY KEY,
                owner_email TEXT NOT NULL,
                original_name TEXT NOT NULL DEFAULT '',
                extension TEXT NOT NULL DEFAULT '',
                mime TEXT NOT NULL DEFAULT '',
                media_type TEXT NOT NULL DEFAULT 'image',
                size INTEGER NOT NULL DEFAULT 0,
                sha256 TEXT NOT NULL DEFAULT '',
                phash TEXT NOT NULL DEFAULT '',
                absolute_path TEXT NOT NULL,
                captured_at TEXT NOT NULL DEFAULT '',
                imported_at TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL DEFAULT '',
                width INTEGER NOT NULL DEFAULT 0,
                height INTEGER NOT NULL DEFAULT 0,
                duration REAL NOT NULL DEFAULT 0,
                codec TEXT NOT NULL DEFAULT '',
                camera TEXT NOT NULL DEFAULT '',
                lens TEXT NOT NULL DEFAULT '',
                iso TEXT NOT NULL DEFAULT '',
                focal TEXT NOT NULL DEFAULT '',
                lat REAL NULL,
                lon REAL NULL,
                title TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                tags_json TEXT NOT NULL DEFAULT '[]',
                rotation INTEGER NOT NULL DEFAULT 0,
                crop_json TEXT NOT NULL DEFAULT '',
                live_pair_id TEXT NOT NULL DEFAULT '',
                preview_status TEXT NOT NULL DEFAULT 'pending',
                transcode_path TEXT NOT NULL DEFAULT '',
                error TEXT NOT NULL DEFAULT '',
                trashed_at TEXT NOT NULL DEFAULT ''
            )",
            "CREATE INDEX IF NOT EXISTS idx_media_owner ON media(owner_email)",
            "CREATE INDEX IF NOT EXISTS idx_media_captured ON media(captured_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_media_imported ON media(imported_at DESC)",
            "CREATE INDEX IF NOT EXISTS idx_media_sha ON media(sha256)",
            "CREATE INDEX IF NOT EXISTS idx_media_phash ON media(phash)",
            "CREATE INDEX IF NOT EXISTS idx_media_type ON media(media_type)",
            "CREATE INDEX IF NOT EXISTS idx_media_trash ON media(trashed_at)",
            "CREATE INDEX IF NOT EXISTS idx_media_geo ON media(lat, lon)",

            "CREATE TABLE IF NOT EXISTS favorites (
                user_email TEXT NOT NULL,
                media_id TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT '',
                PRIMARY KEY(user_email, media_id),
                FOREIGN KEY(media_id) REFERENCES media(id) ON DELETE CASCADE
            )",

            "CREATE TABLE IF NOT EXISTS albums (
                id TEXT PRIMARY KEY,
                owner_email TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                visibility TEXT NOT NULL DEFAULT 'private',
                collaborative INTEGER NOT NULL DEFAULT 0,
                cover_id TEXT NOT NULL DEFAULT '',
                cover_position TEXT NOT NULL DEFAULT '50% 50%',
                sort_mode TEXT NOT NULL DEFAULT 'manual',
                created_at TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL DEFAULT ''
            )",
            "CREATE INDEX IF NOT EXISTS idx_albums_owner ON albums(owner_email)",
            "CREATE INDEX IF NOT EXISTS idx_albums_visibility ON albums(visibility)",

            "CREATE TABLE IF NOT EXISTS album_items (
                album_id TEXT NOT NULL,
                media_id TEXT NOT NULL,
                position INTEGER NOT NULL DEFAULT 0,
                added_by TEXT NOT NULL DEFAULT '',
                added_at TEXT NOT NULL DEFAULT '',
                PRIMARY KEY(album_id, media_id),
                FOREIGN KEY(album_id) REFERENCES albums(id) ON DELETE CASCADE,
                FOREIGN KEY(media_id) REFERENCES media(id) ON DELETE CASCADE
            )",
            "CREATE INDEX IF NOT EXISTS idx_album_items_media ON album_items(media_id)",
            "CREATE INDEX IF NOT EXISTS idx_album_items_position ON album_items(album_id, position)",

            "CREATE TABLE IF NOT EXISTS album_acl (
                album_id TEXT NOT NULL,
                subject_type TEXT NOT NULL,
                subject_value TEXT NOT NULL,
                effect TEXT NOT NULL DEFAULT 'allow',
                can_contribute INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY(album_id, subject_type, subject_value, effect),
                FOREIGN KEY(album_id) REFERENCES albums(id) ON DELETE CASCADE
            )",
            "CREATE INDEX IF NOT EXISTS idx_album_acl_subject ON album_acl(subject_type, subject_value)",

            "CREATE TABLE IF NOT EXISTS people (
                id TEXT PRIMARY KEY,
                owner_email TEXT NOT NULL,
                name TEXT NOT NULL,
                cover_media_id TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL DEFAULT ''
            )",
            "CREATE INDEX IF NOT EXISTS idx_people_owner ON people(owner_email)",

            "CREATE TABLE IF NOT EXISTS faces (
                id TEXT PRIMARY KEY,
                media_id TEXT NOT NULL,
                person_id TEXT NOT NULL DEFAULT '',
                bbox_json TEXT NOT NULL DEFAULT '',
                confidence REAL NOT NULL DEFAULT 0,
                embedding_json TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(media_id) REFERENCES media(id) ON DELETE CASCADE
            )",
            "CREATE INDEX IF NOT EXISTS idx_faces_media ON faces(media_id)",
            "CREATE INDEX IF NOT EXISTS idx_faces_person ON faces(person_id)",

            "CREATE TABLE IF NOT EXISTS media_ai (
                media_id TEXT PRIMARY KEY,
                caption TEXT NOT NULL DEFAULT '',
                keywords_json TEXT NOT NULL DEFAULT '[]',
                embedding_json TEXT NOT NULL DEFAULT '',
                indexed_at TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(media_id) REFERENCES media(id) ON DELETE CASCADE
            )",

            "CREATE TABLE IF NOT EXISTS shares (
                id TEXT PRIMARY KEY,
                album_id TEXT NOT NULL,
                owner_email TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                token_value TEXT NOT NULL DEFAULT '',
                label TEXT NOT NULL DEFAULT '',
                password_hash TEXT NOT NULL DEFAULT '',
                expires_at TEXT NOT NULL DEFAULT '',
                allow_download INTEGER NOT NULL DEFAULT 0,
                allow_upload INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT '',
                revoked_at TEXT NOT NULL DEFAULT '',
                last_access_at TEXT NOT NULL DEFAULT '',
                access_count INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY(album_id) REFERENCES albums(id) ON DELETE CASCADE
            )",
            "CREATE INDEX IF NOT EXISTS idx_shares_owner ON shares(owner_email)",
            "CREATE INDEX IF NOT EXISTS idx_shares_album ON shares(album_id)",

            "CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                type TEXT NOT NULL,
                owner_email TEXT NOT NULL DEFAULT '',
                media_id TEXT NOT NULL DEFAULT '',
                payload_json TEXT NOT NULL DEFAULT '{}',
                status TEXT NOT NULL DEFAULT 'pending',
                progress INTEGER NOT NULL DEFAULT 0,
                attempts INTEGER NOT NULL DEFAULT 0,
                error TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL DEFAULT '',
                started_at TEXT NOT NULL DEFAULT '',
                finished_at TEXT NOT NULL DEFAULT ''
            )",
            "CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status, created_at)",
            "CREATE INDEX IF NOT EXISTS idx_jobs_media ON jobs(media_id)",

            "CREATE TABLE IF NOT EXISTS import_sources (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                path TEXT NOT NULL,
                owner_email TEXT NOT NULL DEFAULT '',
                recursive INTEGER NOT NULL DEFAULT 1,
                enabled INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL DEFAULT '',
                last_scan_at TEXT NOT NULL DEFAULT ''
            )",
            "CREATE TABLE IF NOT EXISTS import_history (
                id TEXT PRIMARY KEY,
                source_id TEXT NOT NULL,
                owner_email TEXT NOT NULL DEFAULT '',
                checked INTEGER NOT NULL DEFAULT 0,
                imported INTEGER NOT NULL DEFAULT 0,
                duplicates INTEGER NOT NULL DEFAULT 0,
                errors INTEGER NOT NULL DEFAULT 0,
                started_at TEXT NOT NULL DEFAULT '',
                finished_at TEXT NOT NULL DEFAULT '',
                details_json TEXT NOT NULL DEFAULT '{}'
            )",

            "CREATE TABLE IF NOT EXISTS frames (
                id TEXT PRIMARY KEY,
                owner_email TEXT NOT NULL,
                name TEXT NOT NULL,
                source_type TEXT NOT NULL DEFAULT 'all',
                source_id TEXT NOT NULL DEFAULT '',
                layout TEXT NOT NULL DEFAULT 'single',
                interval_seconds INTEGER NOT NULL DEFAULT 12,
                shuffle INTEGER NOT NULL DEFAULT 1,
                show_caption INTEGER NOT NULL DEFAULT 1,
                transition TEXT NOT NULL DEFAULT 'fade',
                kiosk INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL DEFAULT ''
            )",
            "CREATE INDEX IF NOT EXISTS idx_frames_owner ON frames(owner_email)"
        );
        foreach ($sql as $q) $pdo->exec($q);
        $st=$pdo->prepare("INSERT OR IGNORE INTO meta(k,v) VALUES('schema_version','2')");$st->execute();
        /* FTS5 est utilisé quand la bibliothèque SQLite du serveur le propose. Le module reste fonctionnel sans FTS5. */
        try {
            $pdo->exec("CREATE VIRTUAL TABLE IF NOT EXISTS media_search USING fts5(media_id UNINDEXED, original_name, title, description, tags, camera, lens, caption, keywords)");
            $pdo->exec("CREATE TRIGGER IF NOT EXISTS trg_media_search_insert AFTER INSERT ON media BEGIN INSERT INTO media_search(media_id,original_name,title,description,tags,camera,lens,caption,keywords) VALUES(new.id,new.original_name,new.title,new.description,new.tags_json,new.camera,new.lens,'',''); END");
            $pdo->exec("CREATE TRIGGER IF NOT EXISTS trg_media_search_delete AFTER DELETE ON media BEGIN DELETE FROM media_search WHERE media_id=old.id; END");
            $pdo->exec("CREATE TRIGGER IF NOT EXISTS trg_media_search_update AFTER UPDATE OF original_name,title,description,tags_json,camera,lens ON media BEGIN DELETE FROM media_search WHERE media_id=old.id; INSERT INTO media_search(media_id,original_name,title,description,tags,camera,lens,caption,keywords) VALUES(new.id,new.original_name,new.title,new.description,new.tags_json,new.camera,new.lens,COALESCE((SELECT caption FROM media_ai WHERE media_id=new.id),''),COALESCE((SELECT keywords_json FROM media_ai WHERE media_id=new.id),'')); END");
            $has=$pdo->query("SELECT v FROM meta WHERE k='fts_backfilled'")->fetchColumn();
            if($has!=='1'){
                $pdo->exec("DELETE FROM media_search");
                $pdo->exec("INSERT INTO media_search(media_id,original_name,title,description,tags,camera,lens,caption,keywords) SELECT m.id,m.original_name,m.title,m.description,m.tags_json,m.camera,m.lens,COALESCE(a.caption,''),COALESCE(a.keywords_json,'') FROM media m LEFT JOIN media_ai a ON a.media_id=m.id");
                $pdo->exec("INSERT INTO meta(k,v) VALUES('fts_backfilled','1') ON CONFLICT(k) DO UPDATE SET v='1'");
            }
            $pdo->exec("INSERT INTO meta(k,v) VALUES('fts_available','1') ON CONFLICT(k) DO UPDATE SET v='1'");
        } catch (Throwable $e) {
            try {$pdo->exec("INSERT INTO meta(k,v) VALUES('fts_available','0') ON CONFLICT(k) DO UPDATE SET v='0'");} catch (Throwable $ignore) {}
        }
    }
}
if (!function_exists('dmdphotos_db_meta_get')) {
    function dmdphotos_db_meta_get(PDO $pdo, $key, $fallback='') {
        $st=$pdo->prepare('SELECT v FROM meta WHERE k=?');$st->execute(array((string)$key));$v=$st->fetchColumn();return $v===false?$fallback:(string)$v;
    }
}
if (!function_exists('dmdphotos_db_meta_set')) {
    function dmdphotos_db_meta_set(PDO $pdo, $key, $value) {
        $st=$pdo->prepare('INSERT INTO meta(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v');return $st->execute(array((string)$key,(string)$value));
    }
}
if (!function_exists('dmdphotos_db_migrate_legacy')) {
    function dmdphotos_db_migrate_legacy(PDO $pdo) {
        if (dmdphotos_db_meta_get($pdo,'legacy_json_migrated','')==='1') return;
        $dataDir=dmdphotos_data_dir(true);
        $photosFile=$dataDir.'photos.json';
        $albumsFile=$dataDir.'albums.json';
        $photos=dmdphotos_json_read($photosFile,array('items'=>array()));
        $albums=dmdphotos_json_read($albumsFile,array('items'=>array()));
        try {
            $pdo->beginTransaction();
            $mi=$pdo->prepare('INSERT OR IGNORE INTO media(id,owner_email,original_name,extension,mime,media_type,size,sha256,absolute_path,captured_at,imported_at,updated_at,width,height,camera,lens,iso,focal,lat,lon,title,description,tags_json,trashed_at,preview_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            foreach ((array)($photos['items']??array()) as $id=>$p) {
                if (!is_array($p)) continue;
                $mi->execute(array(
                    (string)($p['id']??$id),(string)($p['owner_email']??''),(string)($p['original_name']??''),(string)($p['extension']??''),(string)($p['mime']??''),(string)($p['media_type']??'image'),(int)($p['size']??0),(string)($p['sha256']??''),(string)($p['absolute_path']??''),(string)($p['captured_at']??''),(string)($p['imported_at']??''),(string)($p['updated_at']??''),(int)($p['width']??0),(int)($p['height']??0),(string)($p['camera']??''),(string)($p['lens']??''),(string)($p['iso']??''),(string)($p['focal']??''),isset($p['lat'])&&$p['lat']!==null?(float)$p['lat']:null,isset($p['lon'])&&$p['lon']!==null?(float)$p['lon']:null,(string)($p['title']??''),(string)($p['description']??''),json_encode(array_values((array)($p['tags']??array())),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),(string)($p['trashed_at']??''),'pending'
                ));
            }
            $ai=$pdo->prepare('INSERT OR IGNORE INTO albums(id,owner_email,name,description,visibility,collaborative,cover_id,cover_position,sort_mode,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
            $ii=$pdo->prepare('INSERT OR IGNORE INTO album_items(album_id,media_id,position,added_by,added_at) VALUES(?,?,?,?,?)');
            $acl=$pdo->prepare('INSERT OR IGNORE INTO album_acl(album_id,subject_type,subject_value,effect,can_contribute) VALUES(?,?,?,?,?)');
            foreach ((array)($albums['items']??array()) as $id=>$a) {
                if (!is_array($a)) continue;
                $oldVis=(string)($a['visibility']??'private');$vis=$oldVis==='everyone'?'public':'private';
                $owner=(string)($a['owner_email']??'');
                $ai->execute(array((string)($a['id']??$id),$owner,(string)($a['name']??'Album'),(string)($a['description']??''),$vis,0,(string)($a['cover_id']??''),'50% 50%','manual',(string)($a['created_at']??date('c')),(string)($a['updated_at']??date('c'))));
                $pos=0; foreach ((array)($a['items']??array()) as $mid) { $pos++; $ii->execute(array((string)($a['id']??$id),(string)$mid,$pos,$owner,(string)($a['created_at']??date('c')))); }
                foreach ((array)($a['shared_users']??array()) as $u) if(trim((string)$u)!=='') $acl->execute(array((string)($a['id']??$id),'user',trim((string)$u),'allow',0));
                foreach ((array)($a['shared_roles']??array()) as $r) if(trim((string)$r)!=='') $acl->execute(array((string)($a['id']??$id),'role',trim((string)$r),'allow',0));
            }
            /* Favoris et ancien cadre : le nom du fichier utilisateur est un hash de l'email. */
            $base=defined('DMD_ROOT')?DMD_ROOT.'/users/profiles/':'';
            foreach (($base!==''?(glob($base.'*',GLOB_ONLYDIR)?:array()):array()) as $dir) {
                $email=basename($dir);$uf=$dataDir.'users/'.hash('sha256',dmdphotos_lower($email)).'.json';$prefs=dmdphotos_json_read($uf,array());
                $fi=$pdo->prepare('INSERT OR IGNORE INTO favorites(user_email,media_id,created_at) VALUES(?,?,?)');
                foreach ((array)($prefs['favorites']??array()) as $mid) $fi->execute(array($email,(string)$mid,date('c')));
                $fr=$prefs['frame']??array();
                if(is_array($fr)&&$fr){$fid='FR-'.strtoupper(substr(hash('sha256',$email.'|legacy'),0,20));$source=(string)($fr['source']??'all');$sourceId=$source==='album'?(string)($fr['album_id']??''):'';$fs=$pdo->prepare('INSERT OR IGNORE INTO frames(id,owner_email,name,source_type,source_id,layout,interval_seconds,shuffle,show_caption,transition,kiosk,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)');$fs->execute(array($fid,$email,'Cadre principal',$source,$sourceId,'single',max(3,(int)($fr['interval']??12)),!empty($fr['shuffle'])?1:0,1,'fade',0,date('c'),date('c')));}
            }
            dmdphotos_db_meta_set($pdo,'legacy_json_migrated','1');
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            /* On ne marque pas la migration comme terminée : elle sera retentée. */
        }
    }
}

if (!function_exists('dmdphotos_db_rehome_originals')) {
    function dmdphotos_db_rehome_originals(PDO $pdo) {
        if (dmdphotos_db_meta_get($pdo,'originals_rehomed_v2','')==='1') return;
        $rows=$pdo->query('SELECT id,owner_email,original_name,extension,absolute_path,captured_at,imported_at FROM media')->fetchAll(PDO::FETCH_ASSOC);
        $allOk=true;
        $upd=$pdo->prepare('UPDATE media SET absolute_path=?,updated_at=? WHERE id=?');
        foreach ((array)$rows as $m) {
            $id=(string)($m['id']??'');$owner=trim((string)($m['owner_email']??''));$src=(string)($m['absolute_path']??'');
            if($id===''||$owner===''||$src==='')continue;
            $root=dmdphotos_user_storage_root($owner,true);
            if($root===''){ $allOk=false; continue; }
            $rootNorm=str_replace('\\','/',rtrim($root,'/\\')).'/';
            $srcNorm=str_replace('\\','/',$src);
            if(strpos($srcNorm,$rootNorm)===0)continue;
            if(!is_file($src)){ $allOk=false; continue; }

            $stamp=(string)($m['captured_at']??'');
            if(!preg_match('/^(\d{4})-(\d{2})/',$stamp,$mm)){
                $stamp=(string)($m['imported_at']??'');
            }
            if(preg_match('/^(\d{4})-(\d{2})/',$stamp,$mm)){$year=$mm[1];$month=$mm[2];}
            else{$year=date('Y');$month=date('m');}
            $folder=rtrim($root,'/\\').DIRECTORY_SEPARATOR.$year.DIRECTORY_SEPARATOR.$month;
            if(!is_dir($folder)&&!@mkdir($folder,0750,true)&&!is_dir($folder)){ $allOk=false; continue; }
            if(function_exists('dmd_ensure_denied_directory')) @dmd_ensure_denied_directory($folder);
            $ext=dmdphotos_safe_ext((string)($m['extension']??''));
            if($ext==='')$ext=dmdphotos_safe_ext((string)($m['original_name']??''));
            if($ext==='')$ext=dmdphotos_safe_ext($src);
            $dest=$folder.DIRECTORY_SEPARATOR.preg_replace('/[^A-Za-z0-9_-]/','',$id).($ext!==''?'.'.$ext:'');
            if($dest===$src)continue;

            $moved=false;
            if(is_file($dest)){
                $same=((int)@filesize($dest)===(int)@filesize($src));
                if($same){$h1=@hash_file('sha256',$dest);$h2=@hash_file('sha256',$src);$same=$h1!==false&&$h2!==false&&hash_equals($h1,$h2);}
                if($same){@unlink($src);$moved=true;}
            }else{
                $moved=@rename($src,$dest);
                if(!$moved&&@copy($src,$dest)){$moved=true;@unlink($src);}
            }
            if(!$moved){$allOk=false;continue;}
            @chmod($dest,0640);
            if(!$upd->execute(array($dest,date('c'),$id)))$allOk=false;
        }
        if($allOk)dmdphotos_db_meta_set($pdo,'originals_rehomed_v2','1');
    }
}

if (!function_exists('dmdphotos_db_one')) {
    function dmdphotos_db_one($sql,$params=array()) { $pdo=dmdphotos_db();if(!$pdo)return null;$st=$pdo->prepare($sql);$st->execute(array_values($params));$r=$st->fetch();return is_array($r)?$r:null; }
}
if (!function_exists('dmdphotos_db_all')) {
    function dmdphotos_db_all($sql,$params=array()) { $pdo=dmdphotos_db();if(!$pdo)return array();$st=$pdo->prepare($sql);$st->execute(array_values($params));$r=$st->fetchAll();return is_array($r)?$r:array(); }
}
if (!function_exists('dmdphotos_db_exec')) {
    function dmdphotos_db_exec($sql,$params=array()) { $pdo=dmdphotos_db();if(!$pdo)return false;$st=$pdo->prepare($sql);return $st->execute(array_values($params)); }
}
