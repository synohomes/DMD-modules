<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if(session_status()===PHP_SESSION_NONE)session_start();require_once __DIR__.'/DMD-Photos_lib.php';dmdphotos_require('admin.configure');$base=dmdphotos_module_base_url();$uid='dpcfg_'.substr(hash('sha256',session_id().'|'.microtime(true)),0,10);?>
<link rel="stylesheet" href="<?=dmdphotos_h($base)?>/DMD-Photos.css?v=<?=is_file(__DIR__.'/DMD-Photos.css')?filemtime(__DIR__.'/DMD-Photos.css'):1?>">
<section id="<?=dmdphotos_h($uid)?>" class="dmdphotos dp-config" data-api="<?=dmdphotos_h($base)?>/DMD-Photos_api.php">
<header class="dp-head"><div><h2>DMD-Photos — Configuration</h2><p>Miniatures, vidéos, doublons et indexation. Les originaux sont rangés automatiquement dans le dossier de chaque utilisateur.</p></div><button class="dp-btn" type="button" data-action="cfg-refresh">↻ Actualiser</button></header>
<div class="dp-message" data-role="message" hidden></div><form data-role="cfg-form" class="dp-cfg-form"><div class="dp-cfg-grid"><label class="dp-cfg-wide">Stockage des originaux<div class="dp-storage-path" data-role="storage-path">users/profiles/[email]/DMD-Photos/originals/</div><small>Automatique : chaque utilisateur possède ses propres originaux dans son dossier DoMyDesk. Ce chemin n’est pas configurable.</small></label><label>Taille max / fichier (Mo)<input name="max_upload_mb" type="number" min="1" max="4096"></label><label>Doublons<select name="duplicate_policy"><option value="reject">Ignorer le même SHA-256</option><option value="allow">Autoriser</option></select></label><label>Taille miniature (px)<input name="thumb_size" type="number" min="160" max="2048"></label><label>Qualité JPEG miniature<input name="jpeg_quality" type="number" min="40" max="95"></label><label class="dp-cfg-wide">FFmpeg<input name="ffmpeg_path" placeholder="/usr/bin/ffmpeg"><small>Optionnel. Sert à générer les aperçus des vidéos.</small></label><label>Cadre : intervalle défaut (s)<input name="frame_interval" type="number" min="3" max="3600"></label><label class="dp-check"><input name="frame_shuffle" type="checkbox"> Mélanger par défaut</label><label>Indexation max par passage<input name="scan_batch" type="number" min="10" max="5000"></label></div><div class="dp-dialog-actions"><button class="dp-btn dp-primary" type="submit">Enregistrer</button><button class="dp-btn" type="button" data-action="scan">Indexer mon dossier utilisateur</button></div></form><div class="dp-cfg-status" data-role="cfg-status"></div></section>

<script>(()=>{const r=document.getElementById(<?=json_encode($uid)?>);if(!r||r.dataset.ready)return;r.dataset.ready='1';const api=r.dataset.api,f=r.querySelector('[data-role="cfg-form"]'),m=r.querySelector('[data-role="message"]'),s=r.querySelector('[data-role="cfg-status"]'),sp=r.querySelector('[data-role="storage-path"]');let csrf='';const msg=(t,e=false)=>{m.textContent=t||'';m.hidden=!t;m.classList.toggle('is-error',e)};async function call(a,p={},method='POST'){let u=api,o={credentials:'same-origin',cache:'no-store'};if(method==='GET'){u+='?'+new URLSearchParams(Object.assign({action:a},p));o.method='GET'}else{o.method='POST';o.headers={'Content-Type':'application/json','X-CSRF-Token':csrf};o.body=JSON.stringify(Object.assign({action:a,csrf},p))}const x=await fetch(u,o),j=await x.json();if(!x.ok||!j.ok)throw new Error(j.error||'Erreur');return j}function fill(c){Object.keys(c).forEach(k=>{const e=f.elements[k];if(!e)return;if(e.type==='checkbox')e.checked=!!c[k];else e.value=c[k]==null?'':c[k]});if(sp)sp.textContent=c.storage_pattern||'users/profiles/[email]/DMD-Photos/originals/';s.textContent='Stockage utilisateur : '+(c.storage_ok?'accessible et inscriptible':'à vérifier')+' · Dossier courant : '+(c.user_storage_root||'—')+' · Index partagé : '+(c.data_dir||'—')}async function load(){try{const j=await call('config_get',{},'GET');csrf=j.csrf;fill(j.config);msg('')}catch(e){msg(e.message,true)}}f.addEventListener('submit',async e=>{e.preventDefault();const p={};new FormData(f).forEach((v,k)=>p[k]=v);p.frame_shuffle=f.elements.frame_shuffle.checked;try{const j=await call('config_save',p);fill(j.config);msg('Configuration enregistrée.')}catch(e){msg(e.message,true)}});r.addEventListener('click',async e=>{const a=e.target.closest('[data-action]');if(!a)return;try{if(a.dataset.action==='cfg-refresh')await load();if(a.dataset.action==='scan'){msg('Indexation en cours…');const j=await call('scan');msg(`${j.result.imported} média(s) indexé(s), ${j.result.duplicates} déjà connu(s), ${j.result.errors} erreur(s).`);await load();}}catch(x){msg(x.message,true)}});load()})();</script>
