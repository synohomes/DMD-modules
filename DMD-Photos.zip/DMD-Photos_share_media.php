<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
$token=(string)($_GET['t']??'');$share=dmdphotos_share_lookup($token);if(!$share||!dmdphotos_share_authorized($share,$token,'')){http_response_code(403);exit;}$id=preg_replace('/[^A-Za-z0-9_-]/','',(string)($_GET['id']??''));$m=dmdphotos_media_row($id);$in=dmdphotos_db_one('SELECT 1 x FROM album_items WHERE album_id=? AND media_id=?',array($share['album_id'],$id));if(!$m||!$in||$m['trashed_at']!==''){http_response_code(404);exit;}$download=!empty($_GET['download']);if($download&&empty($share['allow_download'])){http_response_code(403);exit;}$kind=(string)($_GET['kind']??'preview');$file='';$mime='';if($kind==='thumb'){$file=dmdphotos_thumb_file($id);if(!is_file($file))dmdphotos_make_thumb($m);$mime='image/jpeg';}elseif($kind==='preview'&&$m['media_type']==='image'){$file=dmdphotos_preview_file($id);if(!is_file($file))dmdphotos_make_preview($m);$mime='image/jpeg';}elseif($kind==='transcode'&&$m['media_type']==='video'){$file=dmdphotos_transcode_file($id);if(!is_file($file))dmdphotos_make_transcode($m);$mime='video/mp4';}if($file===''||!is_file($file)){$file=(string)$m['absolute_path'];$mime=(string)$m['mime'];}if(!is_file($file)){http_response_code(404);exit;}header('X-Content-Type-Options: nosniff');header('Cache-Control: private, max-age=120');header('Content-Type: '.$mime);if($download){$name=preg_replace('/[\r\n"]+/','_',basename($m['original_name']));header('Content-Disposition: attachment; filename="'.$name.'"');}else header('Content-Disposition: inline');header('Content-Length: '.filesize($file));readfile($file);
