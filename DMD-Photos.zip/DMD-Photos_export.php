<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if(session_status()===PHP_SESSION_NONE)session_start();
require_once __DIR__.'/DMD-Photos_lib.php';
$email=dmdphotos_email();if($email===''||!dmdphotos_can($email,'module.view')){http_response_code(403);exit('Accès refusé.');}
if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST'){http_response_code(405);exit('POST requis.');}
if(!dmdphotos_csrf_valid((string)($_POST['csrf']??''))){http_response_code(403);exit('Jeton expiré.');}
if(!class_exists('ZipArchive')){http_response_code(503);exit('Extension PHP ZipArchive requise pour les exports ZIP.');}
$type=(string)($_POST['type']??'selection');$rows=array();$label='DMD-Photos';
if($type==='album'){$aid=(string)($_POST['album_id']??'');$a=dmdphotos_album_row($aid);if(!$a||!dmdphotos_album_visible($a,$email)){http_response_code(404);exit('Album introuvable.');}if(!dmdphotos_can($email,'albums.export')&&!dmdphotos_can($email,'admin.exports_all')){http_response_code(403);exit('Export non autorisé.');}$rows=dmdphotos_db_all('SELECT m.* FROM album_items i JOIN media m ON m.id=i.media_id WHERE i.album_id=? AND m.trashed_at="" ORDER BY i.position,i.added_at',array($aid));$label=(string)$a['name'];}
elseif($type==='full') {if(!dmdphotos_can($email,'exports.full_own')&&!dmdphotos_can($email,'admin.exports_all')){http_response_code(403);exit('Export complet non autorisé.');}$owner=(string)($_POST['owner_email']??$email);if(strcasecmp($owner,$email)!==0&&!dmdphotos_can($email,'admin.exports_all'))$owner=$email;$rows=dmdphotos_db_all('SELECT * FROM media WHERE owner_email=? AND trashed_at="" ORDER BY captured_at',array($owner));$label='Phototheque-'.$owner;}
else{if(!dmdphotos_can($email,'exports.selection')){http_response_code(403);exit('Export de sélection non autorisé.');}$ids=json_decode((string)($_POST['ids']??'[]'),true);if(!is_array($ids))$ids=array();foreach($ids as $id){$m=dmdphotos_media_row((string)$id);if($m&&dmdphotos_photo_accessible($m,$email)&&empty($m['trashed_at']))$rows[]=$m;}$label='Selection';}
if(!$rows){http_response_code(400);exit('Aucun média à exporter.');}
$tmp=dmdphotos_data_dir(true).'tmp/export-'.dmdphotos_id('ZIP').'.zip';$zip=new ZipArchive();if($zip->open($tmp,ZipArchive::CREATE|ZipArchive::OVERWRITE)!==true){http_response_code(500);exit('Création ZIP impossible.');}$meta=array();$seen=array();foreach($rows as $m){$path=(string)$m['absolute_path'];if(!is_file($path))continue;$name=preg_replace('/[^A-Za-z0-9._ -]+/u','_',basename((string)$m['original_name']));if($name==='')$name=$m['id'].'.'.$m['extension'];$base=$name;$n=1;while(isset($seen[dmdphotos_lower($name)])){$pi=pathinfo($base);$name=($pi['filename']??'media').'-'.(++$n).(isset($pi['extension'])?'.'.$pi['extension']:'');}$seen[dmdphotos_lower($name)]=true;$zip->addFile($path,'medias/'.$name);$tags=json_decode((string)$m['tags_json'],true);$meta[]=array('id'=>$m['id'],'file'=>$name,'captured_at'=>$m['captured_at'],'title'=>$m['title'],'description'=>$m['description'],'tags'=>is_array($tags)?$tags:array(),'lat'=>$m['lat'],'lon'=>$m['lon'],'camera'=>$m['camera'],'lens'=>$m['lens'],'sha256'=>$m['sha256']);}
$zip->addFromString('DMD-Photos-metadata.json',json_encode(array('exported_at'=>dmdphotos_now(),'label'=>$label,'media'=>$meta),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));$zip->close();
$filename=preg_replace('/[^A-Za-z0-9._-]+/','-',dmdphotos_lower($label));$filename=trim($filename,'-');if($filename==='')$filename='dmd-photos';header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="'.$filename.'-'.date('Ymd-His').'.zip"');header('Content-Length: '.filesize($tmp));header('Cache-Control: no-store');readfile($tmp);@unlink($tmp);
