<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */

if (!function_exists('dmd_proxmox_boot_core')) {
    function dmd_proxmox_boot_core() {
        $root = dmd_proxmox_root();
        $files = array(
            $root . '/core/dmd_permissions.php',
            $root . '/core/dmd_system_services.php',
            $root . '/core/dmd_activity.php',
            $root . '/core/dmd_module_logs.php',
            $root . '/core/dmd_module_events.php',
            $root . '/Quick-Session/dmd_quick_session.php',
            $root . '/core/dmd_quick_session.php'
        );
        foreach ($files as $file) {
            if (is_file($file)) require_once $file;
        }
    }
}

dmd_proxmox_boot_core();

if (!function_exists('dmd_proxmox_profile_for_email')) {
    function dmd_proxmox_profile_for_email($email) {
        $email = trim((string)$email);
        if ($email === '' || basename($email) !== $email || strpos($email, '/') !== false || strpos($email, '\\') !== false) return array();

        if (function_exists('dmd_read_profile')) {
            try {
                $profile = dmd_read_profile($email);
                if (is_array($profile) && $profile) return $profile;
            } catch (Throwable $e) { }
        }

        $base = dmd_proxmox_root() . '/users/profiles/' . $email;
        foreach (array($base . '/profile.json', $base . '/profile/profile.json') as $file) {
            if (!is_file($file)) continue;
            $data = json_decode((string)@file_get_contents($file), true);
            if (is_array($data)) return $data;
        }

        if ($email === dmd_proxmox_user_email() && isset($_SESSION['user']) && is_array($_SESSION['user'])) return $_SESSION['user'];
        return array();
    }
}

if (!function_exists('dmd_proxmox_user_has_module_access_email')) {
    function dmd_proxmox_user_has_module_access_email($email) {
        $email = trim((string)$email);
        if ($email === '') return false;
        if ($email === dmd_proxmox_user_email()) {
            return dmd_proxmox_has_module_access();
        }

        if (!function_exists('dmd_user_can_use_module')) return false;
        try { return (bool)dmd_user_can_use_module($email, 'DMD-Proxmox'); }
        catch (Throwable $e) { return false; }
    }
}

if (!function_exists('dmd_proxmox_user_can_email')) {
    function dmd_proxmox_user_can_email($email, $capability) {
        $email = trim((string)$email);
        $capability = trim((string)$capability);
        if ($email === '' || $capability === '') return false;
        if ($email === dmd_proxmox_user_email()) {
            return dmd_proxmox_user_can($capability);
        }

        if (!dmd_proxmox_user_has_module_access_email($email)) return false;
        if (!function_exists('dmd_user_has_module_permission')) return false;
        try { return (bool)dmd_user_has_module_permission($email, 'DMD-Proxmox', $capability); }
        catch (Throwable $e) { return false; }
    }
}

if (!function_exists('dmd_proxmox_email_is_admin')) {
    function dmd_proxmox_email_is_admin($email) {
        $profile = dmd_proxmox_profile_for_email($email);
        $role = strtolower(trim((string)(isset($profile['role_system']) ? $profile['role_system'] : '')));
        return in_array($role, array('admin', 'administrator', 'superadmin'), true);
    }
}

if (!function_exists('dmd_proxmox_role_metier_for_email')) {
    function dmd_proxmox_role_metier_for_email($email) {
        $profile = dmd_proxmox_profile_for_email($email);
        if (!isset($profile['role_metier'])) return '';
        $value = $profile['role_metier'];
        if (is_array($value)) {
            foreach ($value as $candidate) {
                if (is_scalar($candidate) && trim((string)$candidate) !== '') return trim((string)$candidate);
            }
            return '';
        }
        return trim((string)$value);
    }
}

if (!function_exists('dmd_proxmox_acl_capabilities')) {
    function dmd_proxmox_acl_capabilities() {
        return array(
            'console' => 'Ouvrir le Remote',
            'vm.files' => 'Fichiers réseau / transfert',
            'vm.start' => 'Démarrer',
            'vm.shutdown' => 'Arrêter proprement',
            'vm.reboot' => 'Redémarrer',
            'vm.stop' => 'Stop forcé',
            'vm.reset' => 'Reset matériel',
            'vm.delete' => 'Supprimer'
        );
    }
}

if (!function_exists('dmd_proxmox_acl_dir')) {
    function dmd_proxmox_acl_dir() {
        $paths = dmd_proxmox_storage_paths();
        $dir = rtrim($paths['root'], '/\\') . DIRECTORY_SEPARATOR . 'acl';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        if (is_dir($dir)) {
            @chmod($dir, 0750);
            $ht = $dir . DIRECTORY_SEPARATOR . '.htaccess';
            if (!is_file($ht)) {
                @file_put_contents($ht, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n", LOCK_EX);
                @chmod($ht, 0640);
            }
        }
        return $dir;
    }
}

if (!function_exists('dmd_proxmox_acl_file')) {
    function dmd_proxmox_acl_file() {
        return dmd_proxmox_acl_dir() . DIRECTORY_SEPARATOR . 'vm_acl.json';
    }
}

if (!function_exists('dmd_proxmox_acl_read')) {
    function dmd_proxmox_acl_read() {
        $fallback = array('version' => 1, 'updated_at' => null, 'rules' => array());
        $file = dmd_proxmox_acl_file();
        if (!is_file($file)) return $fallback;
        $data = json_decode((string)@file_get_contents($file), true);
        if (!is_array($data)) return $fallback;
        if (!isset($data['rules']) || !is_array($data['rules'])) $data['rules'] = array();
        $data['version'] = 1;
        return $data;
    }
}

if (!function_exists('dmd_proxmox_acl_write')) {
    function dmd_proxmox_acl_write($data) {
        if (!is_array($data)) return false;
        $data['version'] = 1;
        $data['updated_at'] = date('c');
        if (!isset($data['rules']) || !is_array($data['rules'])) $data['rules'] = array();
        $file = dmd_proxmox_acl_file();
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;
        $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000, 9999);
        if (@file_put_contents($tmp, $json . "\n", LOCK_EX) === false) return false;
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmd_proxmox_acl_clean_rule')) {
    function dmd_proxmox_acl_clean_rule($rule) {
        if (!is_array($rule)) return null;
        $subjectType = strtolower(trim((string)(isset($rule['subject_type']) ? $rule['subject_type'] : 'user')));
        if ($subjectType === 'group') $subjectType = 'role';
        if (!in_array($subjectType, array('user', 'role'), true)) return null;
        $subject = trim((string)(isset($rule['subject']) ? $rule['subject'] : ''));
        $serverId = trim((string)(isset($rule['server_id']) ? $rule['server_id'] : ''));
        $vmid = (int)(isset($rule['vmid']) ? $rule['vmid'] : 0);
        $type = strtolower(trim((string)(isset($rule['type']) ? $rule['type'] : 'qemu')));
        if ($type !== 'lxc') $type = 'qemu';
        $mode = strtolower(trim((string)(isset($rule['mode']) ? $rule['mode'] : 'restrict')));
        if (!in_array($mode, array('restrict', 'deny'), true)) $mode = 'restrict';
        if ($subject === '' || $serverId === '' || $vmid <= 0) return null;
        if ($subjectType === 'user' && (basename($subject) !== $subject || strpos($subject, '/') !== false || strpos($subject, '\\') !== false)) return null;

        $allowed = array_keys(dmd_proxmox_acl_capabilities());
        $permissions = array();
        foreach ((array)(isset($rule['permissions']) ? $rule['permissions'] : array()) as $permission) {
            $permission = trim((string)$permission);
            if (in_array($permission, $allowed, true) && !in_array($permission, $permissions, true)) $permissions[] = $permission;
        }
        if ($mode === 'deny') $permissions = array();
        sort($permissions, SORT_STRING);

        return array(
            'id' => sha1(strtolower($subjectType . '|' . $subject . '|' . $serverId . '|' . $type . '|' . $vmid)),
            'subject_type' => $subjectType,
            'subject' => $subject,
            'server_id' => $serverId,
            'vmid' => $vmid,
            'type' => $type,
            'mode' => $mode,
            'permissions' => $permissions,
            'updated_at' => date('c')
        );
    }
}

if (!function_exists('dmd_proxmox_acl_upsert_rule')) {
    function dmd_proxmox_acl_upsert_rule($rule) {
        $clean = dmd_proxmox_acl_clean_rule($rule);
        if (!is_array($clean)) return array(false, 'Règle de droits invalide.', null);
        $acl = dmd_proxmox_acl_read();
        $rules = isset($acl['rules']) && is_array($acl['rules']) ? $acl['rules'] : array();
        $replaced = false;
        foreach ($rules as $i => $existing) {
            if (is_array($existing) && isset($existing['id']) && (string)$existing['id'] === $clean['id']) {
                $rules[$i] = $clean;
                $replaced = true;
                break;
            }
        }
        if (!$replaced) $rules[] = $clean;
        $acl['rules'] = array_values($rules);
        if (!dmd_proxmox_acl_write($acl)) return array(false, 'Impossible d’enregistrer la règle de droits.', null);
        return array(true, 'Règle enregistrée.', $clean);
    }
}

if (!function_exists('dmd_proxmox_acl_delete_rule')) {
    function dmd_proxmox_acl_delete_rule($id) {
        $id = trim((string)$id);
        if ($id === '') return false;
        $acl = dmd_proxmox_acl_read();
        $rules = isset($acl['rules']) && is_array($acl['rules']) ? $acl['rules'] : array();
        $before = count($rules);
        $rules = array_values(array_filter($rules, function($rule) use ($id) {
            return !is_array($rule) || !isset($rule['id']) || (string)$rule['id'] !== $id;
        }));
        if (count($rules) === $before) return false;
        $acl['rules'] = $rules;
        return dmd_proxmox_acl_write($acl);
    }
}

if (!function_exists('dmd_proxmox_acl_effective_rule')) {
    function dmd_proxmox_acl_effective_rule($email, $serverId, $type, $vmid) {
        $email = trim((string)$email);
        $serverId = trim((string)$serverId);
        $type = strtolower(trim((string)$type));
        if ($type !== 'lxc') $type = 'qemu';
        $vmid = (int)$vmid;
        if ($email === '' || $serverId === '' || $vmid <= 0) return null;

        $role = dmd_proxmox_role_metier_for_email($email);
        $userRule = null;
        $roleRule = null;
        $acl = dmd_proxmox_acl_read();
        foreach ((array)$acl['rules'] as $rule) {
            if (!is_array($rule)) continue;
            if (strcasecmp((string)(isset($rule['server_id']) ? $rule['server_id'] : ''), $serverId) !== 0) continue;
            if ((int)(isset($rule['vmid']) ? $rule['vmid'] : 0) !== $vmid) continue;
            if (strcasecmp((string)(isset($rule['type']) ? $rule['type'] : 'qemu'), $type) !== 0) continue;
            $subjectType = strtolower(trim((string)(isset($rule['subject_type']) ? $rule['subject_type'] : '')));
            $subject = trim((string)(isset($rule['subject']) ? $rule['subject'] : ''));
            if ($subjectType === 'user' && strcasecmp($subject, $email) === 0) $userRule = $rule;
            if (($subjectType === 'role' || $subjectType === 'group') && $role !== '' && strcasecmp($subject, $role) === 0) $roleRule = $rule;
        }
        return is_array($userRule) ? $userRule : (is_array($roleRule) ? $roleRule : null);
    }
}

if (!function_exists('dmd_proxmox_acl_can')) {
    function dmd_proxmox_acl_can($email, $serverId, $type, $vmid, $capability) {
        $email = trim((string)$email);
        $capability = trim((string)$capability);
        if ($email === '' || $capability === '') return false;
        if (!dmd_proxmox_user_can_email($email, $capability)) return false;
        if (dmd_proxmox_email_is_admin($email)) return true;

        $rule = dmd_proxmox_acl_effective_rule($email, $serverId, $type, $vmid);
        if (!is_array($rule)) return true;
        if (strtolower((string)(isset($rule['mode']) ? $rule['mode'] : 'restrict')) === 'deny') return false;
        $permissions = isset($rule['permissions']) && is_array($rule['permissions']) ? $rule['permissions'] : array();
        return in_array($capability, $permissions, true);
    }
}

if (!function_exists('dmd_proxmox_user_can_vm')) {
    function dmd_proxmox_user_can_vm($capability, $serverId, $vmid, $type, $email = null) {
        if ($email === null || trim((string)$email) === '') $email = dmd_proxmox_user_email();
        return dmd_proxmox_acl_can($email, $serverId, $type, $vmid, $capability);
    }
}

if (!function_exists('dmd_proxmox_vm_permissions_snapshot')) {
    function dmd_proxmox_vm_permissions_snapshot($serverId, $vmid, $type, $email = null) {
        if ($email === null || trim((string)$email) === '') $email = dmd_proxmox_user_email();
        $out = array();
        foreach (dmd_proxmox_acl_capabilities() as $permission => $label) {
            $out[$permission] = dmd_proxmox_acl_can($email, $serverId, $type, $vmid, $permission);
        }
        return $out;
    }
}

if (!function_exists('dmd_proxmox_acl_subjects')) {
    function dmd_proxmox_acl_subjects() {
        $users = array();
        $roles = array();
        $root = dmd_proxmox_root() . '/users/profiles';
        foreach ((array)glob($root . '/*', GLOB_ONLYDIR) as $dir) {
            $email = basename($dir);
            $profile = dmd_proxmox_profile_for_email($email);
            $realEmail = trim((string)(isset($profile['email']) ? $profile['email'] : $email));
            if ($realEmail === '') continue;
            $first = trim((string)(isset($profile['prenom']) ? $profile['prenom'] : (isset($profile['first_name']) ? $profile['first_name'] : '')));
            $last = trim((string)(isset($profile['nom']) ? $profile['nom'] : (isset($profile['last_name']) ? $profile['last_name'] : '')));
            $name = trim($first . ' ' . $last);
            if ($name === '') $name = trim((string)(isset($profile['pseudo']) ? $profile['pseudo'] : $realEmail));
            $role = dmd_proxmox_role_metier_for_email($realEmail);
            $users[] = array('email' => $realEmail, 'name' => $name, 'role_metier' => $role);
            if ($role !== '') $roles[strtolower($role)] = array('id' => $role, 'label' => $role);
        }
        usort($users, function($a, $b) { return strcasecmp((string)$a['name'], (string)$b['name']); });
        $roles = array_values($roles);
        usort($roles, function($a, $b) { return strcasecmp((string)$a['label'], (string)$b['label']); });
        return array('users' => $users, 'roles' => $roles, 'groups' => $roles);
    }
}

if (!function_exists('dmd_proxmox_vm_resource')) {
    function dmd_proxmox_vm_resource($serverId, $vmid, $type, $name, $node) {
        $serverId = trim((string)$serverId);
        $type = strtolower(trim((string)$type));
        if ($type !== 'lxc') $type = 'qemu';
        $label = trim((string)$name);
        if ($label === '') $label = strtoupper($type) . ' #' . (int)$vmid;
        $tags = array('proxmox', 'server:' . $serverId, 'type:' . $type);
        if (trim((string)$node) !== '') $tags[] = 'node:' . trim((string)$node);
        return array(
            'type' => 'proxmox_vm',
            'id' => 'DMD-Proxmox:vm:' . $serverId . ':' . $type . ':' . (int)$vmid,
            'name' => $label,
            'label' => $label,
            'source' => 'DMD-Proxmox',
            'tags' => $tags
        );
    }
}

if (!function_exists('dmd_proxmox_parse_vm_resource_id')) {
    function dmd_proxmox_parse_vm_resource_id($id) {
        $id = trim((string)$id);
        if (!preg_match('/^DMD-Proxmox:vm:([^:]+):(qemu|lxc):(\d+)$/i', $id, $m)) return null;
        return array('server_id' => $m[1], 'type' => strtolower($m[2]), 'vmid' => (int)$m[3]);
    }
}

if (!function_exists('dmd_proxmox_emit_core_event')) {
    function dmd_proxmox_emit_core_event($entry) {
        if (!is_array($entry)) return false;
        dmd_proxmox_boot_core();
        if (!function_exists('dmd_module_event')) return false;
        $extra = isset($entry['extra']) && is_array($entry['extra']) ? $entry['extra'] : array();
        if (!empty($extra['server_id']) && !empty($extra['vmid'])) {
            $resource = dmd_proxmox_vm_resource(
                $extra['server_id'],
                (int)$extra['vmid'],
                isset($extra['type']) ? $extra['type'] : 'qemu',
                isset($extra['name']) ? $extra['name'] : (isset($entry['target']) ? $entry['target'] : ''),
                isset($extra['node']) ? $extra['node'] : ''
            );
        } else {
            $target = isset($entry['target']) ? (string)$entry['target'] : 'DMD-Proxmox';
            $resource = array(
                'type' => 'proxmox',
                'id' => 'DMD-Proxmox:' . sha1($target),
                'name' => $target,
                'source' => 'DMD-Proxmox',
                'tags' => array('proxmox')
            );
        }
        $rawAction = isset($entry['action']) ? (string)$entry['action'] : 'action';
        $actionMap = array(
            'vm_start' => 'vm.start',
            'vm_shutdown' => 'vm.shutdown',
            'vm_reboot' => 'vm.reboot',
            'vm_stop' => 'vm.stop',
            'vm_reset' => 'vm.reset',
            'vm_create' => 'vm.create',
            'vm_delete' => 'vm.delete',
            'remote_control' => 'remote.open',
            'acl_change' => 'acl.change',
            'server_save' => 'server.change',
            'server_bootstrap' => 'server.change',
            'server_delete' => 'server.change',
            'iso_upload' => 'iso.upload'
        );
        $coreAction = isset($actionMap[$rawAction]) ? $actionMap[$rawAction] : str_replace('_', '.', $rawAction);
        $meta = $extra;
        $meta['source'] = isset($extra['source']) && trim((string)$extra['source']) !== ''
            ? trim((string)$extra['source'])
            : (in_array($rawAction, array('acl_change','server_save','server_bootstrap','server_delete','iso_upload'), true) ? 'cfg' : 'module');

        if (isset($extra['vmid']) && (int)$extra['vmid'] > 0) {
            $meta['vmid'] = (string)(int)$extra['vmid'];
        }

        $vmName = trim((string)(isset($extra['vm_name']) ? $extra['vm_name'] : (isset($extra['name']) ? $extra['name'] : '')));
        if ($vmName === '' && isset($entry['target'])) {
            $targetForName = trim((string)$entry['target']);
            if (preg_match('/^(?:QEMU|LXC)\s+#\d+\s+(.+)$/i', $targetForName, $m)) {
                $vmName = trim((string)$m[1]);
            }
        }
        if ($vmName !== '') {
            $meta['vm_name'] = $vmName;
        }

        $node = trim((string)(isset($extra['node']) ? $extra['node'] : ''));
        if ($node !== '') {
            $meta['node'] = $node;
        }

        $serverId = trim((string)(isset($extra['server_id']) ? $extra['server_id'] : ''));
        if ($serverId !== '') {
            $meta['server_id'] = $serverId;
            $serverForEvent = dmd_proxmox_load_server($serverId);
            $serverName = is_array($serverForEvent) ? trim((string)(isset($serverForEvent['name']) ? $serverForEvent['name'] : '')) : '';
            $meta['server'] = $serverName !== '' ? $serverName : $serverId;
        } elseif (isset($extra['server']) && is_scalar($extra['server'])) {
            $serverName = trim((string)$extra['server']);
            if ($serverName !== '') $meta['server'] = $serverName;
        }

        if (isset($extra['preset']) && is_scalar($extra['preset'])) {
            $presetName = trim((string)$extra['preset']);
            if ($presetName !== '') $meta['preset'] = $presetName;
        }
        if (isset($extra['preset_id']) && is_scalar($extra['preset_id'])) {
            $presetId = trim((string)$extra['preset_id']);
            if ($presetId !== '') $meta['preset_id'] = $presetId;
        }
        if (isset($extra['vlan']) && is_scalar($extra['vlan'])) {
            $meta['vlan'] = trim((string)$extra['vlan']);
        }
        if (isset($extra['type']) && is_scalar($extra['type'])) {
            $meta['type'] = trim((string)$extra['type']);
        }

        if ($rawAction === 'iso_upload' && empty($meta['iso']) && !empty($entry['target'])) {
            $meta['iso'] = basename(trim((string)$entry['target']));
        }

        try {
            $result = dmd_module_event('DMD-Proxmox', $coreAction, $resource, array(
                'email' => isset($entry['user']) ? (string)$entry['user'] : dmd_proxmox_user_email(),
                'label' => dmd_proxmox_log_action_label(isset($entry['action']) ? $entry['action'] : ''),
                'target' => isset($entry['target']) ? (string)$entry['target'] : '',
                'status' => isset($entry['status']) ? (string)$entry['status'] : 'info',
                'details' => isset($entry['details']) ? (string)$entry['details'] : '',
                'meta' => $meta,
                /* Le module conserve son journal visuel propre : pas de doublon dans le log Core. */
                'log' => false
            ));
            return is_array($result) ? !empty($result['ok']) : (bool)$result;
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('dmd_proxmox_notify_internal')) {
    function dmd_proxmox_notify_internal($email, $title, $message, $level, $meta) {
        dmd_proxmox_boot_core();
        if (!function_exists('dmd_notify_user')) return false;
        $email = trim((string)$email);
        if ($email === '') return false;
        try {
            return (bool)dmd_notify_user($email, 'DMD-Proxmox', (string)$title, (string)$message, array(
                'level' => (string)$level,
                'meta' => is_array($meta) ? $meta : array()
            ));
        } catch (Throwable $e) {
            return false;
        }
    }
}
if (!function_exists('dmd_proxmox_vm_action_execute')) {
    function dmd_proxmox_vm_action_execute($serverId, $vmid, $preferredType, $action, $email, $source) {
        $serverId = trim((string)$serverId);
        $vmid = (int)$vmid;
        $preferredType = strtolower(trim((string)$preferredType));
        $action = strtolower(trim((string)$action));
        $email = trim((string)$email);
        if ($preferredType !== 'lxc') $preferredType = 'qemu';
        if ($email === '' || $email !== dmd_proxmox_user_email()) return array('ok'=>false,'error'=>'invalid_user','message'=>'Utilisateur ActionHub invalide.','http'=>403);
        if ($serverId === '' || $vmid <= 0 || !in_array($action, array('start','shutdown','stop','reboot','reset'), true)) {
            return array('ok'=>false,'error'=>'invalid_request','message'=>'Requête Proxmox incomplète ou action invalide.','http'=>400);
        }
        $capability = 'vm.' . $action;
        if (!dmd_proxmox_user_can_email($email, $capability)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit DoMyDesk refusé.','http'=>403);

        $server = dmd_proxmox_load_server($serverId);
        if (!is_array($server)) return array('ok'=>false,'error'=>'server_not_found','message'=>'Serveur Proxmox introuvable.','http'=>404);
        $vm = dmd_proxmox_resolve_vm($server, $vmid, $preferredType);
        if (!is_array($vm)) return array('ok'=>false,'error'=>'vm_not_found','message'=>'VM/CT #' . $vmid . ' introuvable.','http'=>404);
        $node = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
        $type = strtolower(trim((string)(isset($vm['type']) ? $vm['type'] : 'qemu')));
        if ($type !== 'lxc') $type = 'qemu';
        $resolvedServerId = !empty($server['id']) ? (string)$server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : $serverId);
        if ($node === '') return array('ok'=>false,'error'=>'node_not_found','message'=>'Node propriétaire introuvable.','http'=>409);
        if ($action === 'reset' && $type !== 'qemu') return array('ok'=>false,'error'=>'reset_qemu_only','message'=>'Le reset matériel est réservé aux VM QEMU.','http'=>400);
        if (!dmd_proxmox_acl_can($email, $resolvedServerId, $type, $vmid, $capability)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Action interdite par les droits de cette VM/CT.','http'=>403);

        $res = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/' . $type . '/' . $vmid . '/status/' . rawurlencode($action), 'POST', array(), 15);
        $name = trim((string)(isset($vm['name']) ? $vm['name'] : ''));
        $target = strtoupper($type) . ' #' . $vmid . ($name !== '' ? ' ' . $name : '');
        $extra = array(
            'server_id' => $resolvedServerId,
            'server_name' => isset($server['name']) ? $server['name'] : '',
            'server_ip' => isset($server['ip']) ? $server['ip'] : '',
            'node' => $node,
            'vmid' => $vmid,
            'type' => $type,
            'name' => $name,
            'action' => $action,
            'http_code' => isset($res['http']) ? $res['http'] : 0,
            'source' => trim((string)$source) !== '' ? trim((string)$source) : 'actionhub'
        );
        if (empty($res['ok'])) {
            $extra['error'] = isset($res['error']) ? $res['error'] : 'Erreur Proxmox';
            dmd_proxmox_log('vm_' . $action, $target, 'error', 'Action Proxmox refusée ou en erreur', $extra);
            return array('ok'=>false,'error'=>'proxmox_api_error','message'=>$extra['error'],'http'=>isset($res['http']) && $res['http'] >= 400 ? $res['http'] : 502);
        }
        dmd_proxmox_log('vm_' . $action, $target, 'success', 'Action Proxmox exécutée', $extra);
        $cacheFile = dmd_proxmox_cache_file($server);
        if (is_file($cacheFile)) @unlink($cacheFile);
        return array('ok'=>true,'message'=>'Action envoyée à Proxmox.','http'=>200,'data'=>isset($res['data']) ? $res['data'] : null);
    }
}
