<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */

if (!function_exists('dmd_proxmox_storage_copy_tree')) {
    function dmd_proxmox_storage_copy_tree($source, $target) {
        if (!is_dir($source)) {
            return true;
        }

        if (!is_dir($target) && !@mkdir($target, 0775, true) && !is_dir($target)) {
            return false;
        }

        $ok = true;

        foreach (array_diff(scandir($source), array('.', '..')) as $item) {
            $src = rtrim($source, '/\\') . DIRECTORY_SEPARATOR . $item;
            $dst = rtrim($target, '/\\') . DIRECTORY_SEPARATOR . $item;

            if (is_dir($src)) {
                if (!dmd_proxmox_storage_copy_tree($src, $dst)) {
                    $ok = false;
                }

                if (is_dir($src) && count(array_diff(scandir($src), array('.', '..'))) === 0) {
                    @rmdir($src);
                }

                continue;
            }

            if (is_file($dst)) {
                $same = @filesize($src) === @filesize($dst)
                    && @sha1_file($src) === @sha1_file($dst);

                if ($same) {
                    @unlink($src);
                } else {
                    $ok = false;
                }

                continue;
            }

            if (!@rename($src, $dst)) {
                if (@copy($src, $dst)) {
                    @chmod($dst, basename($dst) === '.dmd-proxmox.key' ? 0640 : 0640);
                    @unlink($src);
                } else {
                    $ok = false;
                }
            }
        }

        if (is_dir($source) && count(array_diff(scandir($source), array('.', '..'))) === 0) {
            @rmdir($source);
        }

        return $ok;
    }
}

if (!function_exists('dmd_proxmox_storage_move_tree')) {
    function dmd_proxmox_storage_move_tree($source, $target) {
        if (!is_dir($source)) {
            return true;
        }

        if (!file_exists($target)) {
            @mkdir(dirname($target), 0775, true);

            if (@rename($source, $target)) {
                return true;
            }
        }

        return dmd_proxmox_storage_copy_tree($source, $target);
    }
}

if (!function_exists('dmd_proxmox_storage_paths')) {
    function dmd_proxmox_storage_paths() {
        static $paths = null;

        if (is_array($paths)) {
            return $paths;
        }

        if (!function_exists('dmd_module_system_data_dir')) {
            $root = dirname(__DIR__, 2) . '/data/modules/DMD-Proxmox/';
        } else {
            $root = dmd_module_system_data_dir('DMD-Proxmox', true);
        }

        if ($root === '') {
            $root = dirname(__DIR__, 2) . '/data/modules/DMD-Proxmox/';
        }

        $root = rtrim($root, '/\\') . DIRECTORY_SEPARATOR;
        @mkdir($root, 0775, true);
        $legacyRoots = array(
            dirname(__DIR__, 2) . '/data/modules/proxv2',
            dirname(__DIR__, 2) . '/data/modules/DMD-ProxV2',
            dirname(__DIR__) . '/proxv2',
            dirname(__DIR__) . '/DMD-ProxV2'
        );
        foreach ($legacyRoots as $legacySystemRoot) {
            if (!is_dir($legacySystemRoot) || realpath($legacySystemRoot) === realpath(rtrim($root, '/\\'))) continue;
            foreach (array('cfg', 'cache', 'logs', 'remote') as $legacyPart) {
                dmd_proxmox_storage_move_tree(
                    $legacySystemRoot . DIRECTORY_SEPARATOR . $legacyPart,
                    $root . $legacyPart
                );
            }
        }
        dmd_proxmox_storage_move_tree(__DIR__ . '/cfg', $root . 'cfg');
        dmd_proxmox_storage_move_tree(__DIR__ . '/cache', $root . 'cache');
        dmd_proxmox_storage_move_tree(__DIR__ . '/logs', $root . 'logs');

        $cfg = $root . 'cfg';
        $legacyKey = $cfg . DIRECTORY_SEPARATOR . '.proxv2.key';
        $newKey = $cfg . DIRECTORY_SEPARATOR . '.dmd-proxmox.key';
        if (!is_file($newKey) && is_file($legacyKey)) {
            @rename($legacyKey, $newKey);
        }
        $servers = $cfg . DIRECTORY_SEPARATOR . 'serveurs';
        $cache = $root . 'cache';
        $logs = $root . 'logs';
        $remote = $root . 'remote';
        $notificationOutbox = $root . 'notification-outbox';

        foreach (array($cfg, $servers, $cache, $logs, $remote, $notificationOutbox) as $dir) {
            if (!is_dir($dir)) {
                @mkdir($dir, 0750, true);
            }
            @chmod($dir, 0750);
            $ht = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . '.htaccess';
            if (!is_file($ht)) {
                @file_put_contents($ht, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
                @chmod($ht, 0640);
            }
        }
        @chmod($root, 0750);
        if (is_file($cfg . DIRECTORY_SEPARATOR . '.dmd-proxmox.key')) @chmod($cfg . DIRECTORY_SEPARATOR . '.dmd-proxmox.key', 0640);
        foreach ((array)glob($servers . DIRECTORY_SEPARATOR . '*.json') as $serverFile) @chmod($serverFile, 0640);
        foreach ((array)glob($cache . DIRECTORY_SEPARATOR . '*.json') as $cacheFile) @chmod($cacheFile, 0640);
        foreach ((array)glob($logs . DIRECTORY_SEPARATOR . '*.json') as $logFile) @chmod($logFile, 0640);

        $paths = array(
            'root' => $root,
            'cfg' => $cfg,
            'servers' => $servers,
            'cache' => $cache,
            'logs' => $logs,
            'remote' => $remote,
            'notification_outbox' => $notificationOutbox,
            'acl' => $cfg . DIRECTORY_SEPARATOR . 'acl.json',
            'key' => $cfg . DIRECTORY_SEPARATOR . '.dmd-proxmox.key',
        );

        return $paths;
    }
}
