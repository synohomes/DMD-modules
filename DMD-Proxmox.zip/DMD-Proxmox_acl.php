<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';

if (!dmd_proxmox_has_module_access() || !dmd_proxmox_user_can('acl.manage')) {
    dmd_proxmox_json(false, 'Droit de gestion des droits fins Proxmox refusé.', array(), 403);
}

$action = strtolower(trim((string)(isset($_REQUEST['action']) ? $_REQUEST['action'] : 'bootstrap')));

if ($action === 'bootstrap') {
    $servers = array();
    foreach (dmd_proxmox_list_servers(false) as $server) {
        if (!is_array($server)) continue;
        $serverId = !empty($server['id']) ? (string)$server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : '');
        if ($serverId === '') continue;
        $row = array(
            'id' => $serverId,
            'name' => isset($server['name']) ? (string)$server['name'] : $serverId,
            'vms' => array()
        );
        $cache = dmd_proxmox_read_cache($server);
        $vms = is_array($cache) && isset($cache['vms']) && is_array($cache['vms']) ? $cache['vms'] : array();
        foreach ($vms as $vm) {
            if (!is_array($vm) || empty($vm['vmid'])) continue;
            $type = strtolower(trim((string)(isset($vm['type']) ? $vm['type'] : 'qemu')));
            if ($type !== 'lxc') $type = 'qemu';
            $row['vms'][] = array(
                'vmid' => (int)$vm['vmid'],
                'type' => $type,
                'name' => trim((string)(isset($vm['name']) ? $vm['name'] : '')),
                'node' => trim((string)(isset($vm['node']) ? $vm['node'] : '')),
                'status' => trim((string)(isset($vm['status']) ? $vm['status'] : ''))
            );
        }
        usort($row['vms'], function($a, $b) { return (int)$a['vmid'] <=> (int)$b['vmid']; });
        $servers[] = $row;
    }

    $acl = dmd_proxmox_acl_read();
    dmd_proxmox_json(true, '', array(
        'subjects' => dmd_proxmox_acl_subjects(),
        'servers' => $servers,
        'capabilities' => dmd_proxmox_acl_capabilities(),
        'rules' => isset($acl['rules']) && is_array($acl['rules']) ? $acl['rules'] : array(),
        'csrf' => dmd_proxmox_csrf_token()
    ), 200);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dmd_proxmox_json(false, 'Méthode refusée.', array(), 405);
}
if (!dmd_proxmox_csrf_valid(isset($_POST['csrf']) ? $_POST['csrf'] : '')) {
    dmd_proxmox_json(false, 'Jeton de sécurité expiré.', array(), 403);
}

if ($action === 'save') {
    $permissions = isset($_POST['permissions']) && is_array($_POST['permissions']) ? $_POST['permissions'] : array();
    $input = array(
        'subject_type' => isset($_POST['subject_type']) ? $_POST['subject_type'] : 'user',
        'subject' => isset($_POST['subject']) ? $_POST['subject'] : '',
        'server_id' => isset($_POST['server_id']) ? $_POST['server_id'] : '',
        'vmid' => isset($_POST['vmid']) ? $_POST['vmid'] : 0,
        'type' => isset($_POST['type']) ? $_POST['type'] : 'qemu',
        'mode' => isset($_POST['mode']) ? $_POST['mode'] : 'restrict',
        'permissions' => $permissions
    );

    /* On refuse une règle pointant vers un serveur inexistant. */
    $server = dmd_proxmox_load_server(isset($input['server_id']) ? $input['server_id'] : '');
    if (!is_array($server)) dmd_proxmox_json(false, 'Serveur Proxmox introuvable.', array(), 404);

    list($ok, $message, $rule) = dmd_proxmox_acl_upsert_rule($input);
    if (!$ok || !is_array($rule)) dmd_proxmox_json(false, $message, array(), 400);

    $target = strtoupper($rule['type']) . ' #' . (int)$rule['vmid'];
    $extra = array(
        'subject_type' => $rule['subject_type'],
        'subject' => $rule['subject'],
        'server_id' => $rule['server_id'],
        'vmid' => $rule['vmid'],
        'type' => $rule['type'],
        'mode' => $rule['mode'],
        'permissions' => $rule['permissions'],
        'source' => 'cfg'
    );
    if ($rule['subject_type'] === 'user') $extra['target_user'] = $rule['subject'];
    dmd_proxmox_log('acl_change', $target, 'success', 'Droits fins VM/CT modifiés', $extra);

    $acl = dmd_proxmox_acl_read();
    dmd_proxmox_json(true, $message, array('rule'=>$rule, 'rules'=>$acl['rules']), 200);
}

if ($action === 'delete') {
    $id = trim((string)(isset($_POST['id']) ? $_POST['id'] : ''));
    $acl = dmd_proxmox_acl_read();
    $removed = null;
    foreach ((array)$acl['rules'] as $rule) {
        if (is_array($rule) && isset($rule['id']) && (string)$rule['id'] === $id) { $removed = $rule; break; }
    }
    if (!dmd_proxmox_acl_delete_rule($id)) {
        dmd_proxmox_json(false, 'Règle introuvable ou suppression impossible.', array(), 404);
    }

    $extra = array('rule_id'=>$id, 'source'=>'cfg');
    $target = $id;

    $acl = dmd_proxmox_acl_read();
    dmd_proxmox_json(true, 'Règle supprimée.', array('rules'=>$acl['rules']), 200);
}

dmd_proxmox_json(false, 'Action de droits inconnue.', array(), 400);
