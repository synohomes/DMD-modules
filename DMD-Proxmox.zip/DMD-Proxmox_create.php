<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */

if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';
require_once __DIR__ . '/DMD-Proxmox_provision.php';
header('Content-Type: application/json; charset=UTF-8');

if (!dmd_proxmox_has_module_access()) dmd_proxmox_json(false, 'Module DMD-Proxmox non autorisé.', array(), 403);
$op = strtolower(trim((string)(isset($_REQUEST['op']) ? $_REQUEST['op'] : '')));
$serverId = trim((string)(isset($_REQUEST['server_id']) ? $_REQUEST['server_id'] : (isset($_REQUEST['srv']) ? $_REQUEST['srv'] : '')));
$server = dmd_proxmox_load_server($serverId);
if (!is_array($server)) dmd_proxmox_json(false, 'Serveur introuvable.', array(), 404);

$nodes = dmd_proxmox_api($server, 'nodes', 'GET', null, 12);
$node = trim((string)(isset($_REQUEST['node']) ? $_REQUEST['node'] : ''));
if ($node === '' && $nodes['ok'] && is_array($nodes['data']) && !empty($nodes['data'][0]['node'])) $node = (string)$nodes['data'][0]['node'];
if ($node === '') dmd_proxmox_json(false, 'Impossible de déterminer le node Proxmox.', array(), 400);


if ($op === 'meta') {
    if (!dmd_proxmox_user_can('vm.create')) {
        dmd_proxmox_json(false, 'Droit de création VM refusé.', array(), 403);
    }

    $nodeRows = array();
    if ($nodes['ok'] && is_array($nodes['data'])) {
        foreach ($nodes['data'] as $row) {
            if (!is_array($row) || empty($row['node'])) continue;
            $nodeRows[] = array(
                'node' => (string)$row['node'],
                'status' => isset($row['status']) ? (string)$row['status'] : 'unknown'
            );
        }
    }

    $selectedNode = $node;
    $storages = array();
    $isos = array();
    $bridges = array();

    $storageRes = dmd_proxmox_api(
        $server,
        'nodes/' . rawurlencode($selectedNode) . '/storage',
        'GET',
        null,
        12
    );

    if ($storageRes['ok'] && is_array($storageRes['data'])) {
        foreach ($storageRes['data'] as $st) {
            if (!is_array($st) || empty($st['storage'])) continue;

            $sid = (string)$st['storage'];
            $content = strtolower((string)(isset($st['content']) ? $st['content'] : ''));

            if (strpos($content, 'images') !== false) {
                $storages[] = array(
                    'id' => $sid,
                    'type' => isset($st['type']) ? (string)$st['type'] : '',
                    'avail' => isset($st['avail']) ? (float)$st['avail'] : 0,
                    'total' => isset($st['total']) ? (float)$st['total'] : 0
                );
            }

            if (strpos($content, 'iso') !== false) {
                $contentRes = dmd_proxmox_api(
                    $server,
                    'nodes/' . rawurlencode($selectedNode) . '/storage/' . rawurlencode($sid) . '/content',
                    'GET',
                    null,
                    12
                );

                if ($contentRes['ok'] && is_array($contentRes['data'])) {
                    foreach ($contentRes['data'] as $item) {
                        if (!is_array($item) || (string)(isset($item['content']) ? $item['content'] : '') !== 'iso') continue;
                        if (!empty($item['volid'])) {
                            $isos[] = array(
                                'volid' => (string)$item['volid'],
                                'storage' => $sid,
                                'size' => isset($item['size']) ? (float)$item['size'] : 0
                            );
                        }
                    }
                }
            }
        }
    }

    $netRes = dmd_proxmox_api(
        $server,
        'nodes/' . rawurlencode($selectedNode) . '/network',
        'GET',
        null,
        12
    );
    if ($netRes['ok'] && is_array($netRes['data'])) {
        foreach ($netRes['data'] as $net) {
            if (!is_array($net)) continue;
            if ((string)(isset($net['type']) ? $net['type'] : '') !== 'bridge') continue;
            $iface = trim((string)(isset($net['iface']) ? $net['iface'] : ''));
            if ($iface !== '') $bridges[] = $iface;
        }
    }

    $bridges = array_values(array_unique($bridges));
    sort($bridges, SORT_NATURAL);

    dmd_proxmox_json(true, '', array(
        'server_id' => $serverId,
        'nodes' => $nodeRows,
        'node' => $selectedNode,
        'next_vmid' => dmd_proxmox_next_vmid($server),
        'storages' => $storages,
        'isos' => $isos,
        'bridges' => $bridges
    ), 200);
}

if ($op === 'listiso') {
    $out = array();
    $storages = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/storage', 'GET', null, 12);
    if ($storages['ok'] && is_array($storages['data'])) {
        foreach ($storages['data'] as $st) {
            $sid = isset($st['storage']) ? (string)$st['storage'] : '';
            if ($sid === '' || strpos((string)(isset($st['content']) ? $st['content'] : ''), 'iso') === false) continue;
            $r = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/storage/' . rawurlencode($sid) . '/content', 'GET', null, 12);
            if (!$r['ok'] || !is_array($r['data'])) continue;
            foreach ($r['data'] as $item) if (is_array($item) && (isset($item['content']) ? $item['content'] : '') === 'iso') $out[] = isset($item['volid']) ? $item['volid'] : '';
        }
    }
    echo json_encode(array_values(array_unique(array_filter($out))), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
}

if ($op === 'listbridges' || $op === 'listvlans') {
    $r = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/network', 'GET', null, 12);
    $out = array();
    if ($r['ok'] && is_array($r['data'])) foreach ($r['data'] as $net) {
        if (!is_array($net)) continue;
        if ($op === 'listbridges' && (isset($net['type']) ? $net['type'] : '') === 'bridge' && !empty($net['iface'])) $out[] = $net['iface'];
        if ($op === 'listvlans') {
            if (isset($net['tag']) && is_numeric($net['tag'])) $out[] = (int)$net['tag'];
            $iface = isset($net['iface']) ? (string)$net['iface'] : '';
            if (preg_match('/vlan(\d+)/i', $iface, $m)) $out[] = (int)$m[1];
        }
    }
    $out = array_values(array_unique($out)); sort($out, SORT_NATURAL); echo json_encode($out); exit;
}

if ($op === 'createvm') {
    if (!dmd_proxmox_user_can('vm.create')) dmd_proxmox_json(false, 'Droit de création VM refusé.', array(), 403);
    if (!dmd_proxmox_csrf_valid(isset($_POST['csrf']) ? $_POST['csrf'] : '')) dmd_proxmox_json(false, 'Jeton de sécurité expiré.', array(), 403);
    $vmidRaw = trim((string)(isset($_POST['vmid']) ? $_POST['vmid'] : ''));
    $vmid = $vmidRaw === '' ? dmd_proxmox_next_vmid($server) : (int)$vmidRaw;
    if ($vmid < 100) dmd_proxmox_json(false, 'VMID invalide.', array(), 400);
    if (dmd_proxmox_resolve_vm($server, $vmid, '') !== null) dmd_proxmox_json(false, 'VMID déjà utilisé : ' . $vmid, array(), 409);
    $name = trim((string)(isset($_POST['vmname']) ? $_POST['vmname'] : ''));
    $storageVm = trim((string)(isset($_POST['storage_vm']) ? $_POST['storage_vm'] : 'local-lvm'));
    $bridge = trim((string)(isset($_POST['bridge']) ? $_POST['bridge'] : 'vmbr0'));
    if ($name === '') dmd_proxmox_json(false, 'Nom VM obligatoire.', array(), 400);
    $vlan = (int)(isset($_POST['vlan']) ? $_POST['vlan'] : 0);
    $payload = array(
        'vmid' => $vmid,
        'name' => $name,
        'sockets' => 1,
        'cores' => max(1, (int)(isset($_POST['cpu']) ? $_POST['cpu'] : 2)),
        'memory' => max(128, (int)(isset($_POST['ram']) ? $_POST['ram'] : 2048)),
        'scsihw' => 'virtio-scsi-pci',
        'scsi0' => $storageVm . ':' . max(1, (int)(isset($_POST['disk']) ? $_POST['disk'] : 20)),
        'net0' => 'virtio,bridge=' . $bridge . ($vlan > 0 ? ',tag=' . $vlan : ''),
        'ostype' => trim((string)(isset($_POST['ostype']) ? $_POST['ostype'] : 'l26')),
        'agent' => 1
    );
    $iso = trim((string)(isset($_POST['iso']) ? $_POST['iso'] : ''));
    if ($iso !== '') $payload['ide2'] = $iso . ',media=cdrom';
    $r = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/qemu', 'POST', $payload, 30);
    if (!$r['ok']) {
        dmd_proxmox_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'error', 'Création VM refusée ou en erreur', array(
            'source'=>'module','server_id'=>$serverId,'node'=>$node,'vmid'=>$vmid,'type'=>'qemu',
            'name'=>$name,'vm_name'=>$name,'storage'=>$storageVm,'iso'=>$iso,'bridge'=>$bridge,'vlan'=>$vlan,
            'error'=>$r['error']
        ));
        dmd_proxmox_json(false, $r['error'], array('vmid' => $vmid), $r['http'] >= 400 ? $r['http'] : 502);
    }

    $task = dmd_proxmox_wait_task($server, $node, (string)$r['data'], 60);
    if (empty($task['ok'])) {
        dmd_proxmox_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'error', 'Création soumise mais tâche Proxmox non terminée correctement', array(
            'source'=>'module','server_id'=>$serverId,'node'=>$node,'vmid'=>$vmid,'type'=>'qemu',
            'name'=>$name,'vm_name'=>$name,'storage'=>$storageVm,'iso'=>$iso,'bridge'=>$bridge,'vlan'=>$vlan,
            'upid'=>$r['data'],'exitstatus'=>isset($task['exitstatus']) ? $task['exitstatus'] : ''
        ));
        dmd_proxmox_json(false, 'La tâche de création n’a pas terminé correctement.', array(
            'vmid'=>$vmid,
            'node'=>$node,
            'upid'=>$r['data'],
            'exitstatus'=>isset($task['exitstatus']) ? $task['exitstatus'] : ''
        ), 502);
    }

    $started = false;
    $startAfter = !empty($_POST['start_after']) && (string)$_POST['start_after'] !== '0';
    if ($startAfter) {
        $startRes = dmd_proxmox_api(
            $server,
            'nodes/' . rawurlencode($node) . '/qemu/' . $vmid . '/status/start',
            'POST',
            array(),
            20
        );

        if ($startRes['ok']) {
            $startTask = dmd_proxmox_wait_task($server, $node, (string)$startRes['data'], 40);
            $started = !empty($startTask['ok']);
        }
    }

    dmd_proxmox_refresh_server_vm_cache($server);

    dmd_proxmox_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'success', 'VM créée depuis le module', array(
        'source'=>'module','server_id'=>$serverId,'server'=>isset($server['name'])?(string)$server['name']:$serverId,
        'node'=>$node,'vmid'=>$vmid,'type'=>'qemu','name'=>$name,'vm_name'=>$name,
        'storage'=>$storageVm,'iso'=>$iso,'bridge'=>$bridge,'vlan'=>$vlan,'started'=>$started,
        'upid'=>$r['data']
    ));

    dmd_proxmox_json(true, $started ? 'VM créée et démarrée.' : 'VM créée.', array(
        'vmid' => $vmid,
        'node' => $node,
        'type' => 'qemu',
        'name' => $name,
        'started' => $started,
        'upid' => $r['data']
    ), 200);
}

dmd_proxmox_json(false, 'Opération inconnue.', array(), 400);
