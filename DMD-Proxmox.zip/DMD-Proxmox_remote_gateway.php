<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */


if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

function gw_write_all($s, $data) {
    $data=(string)$data;
    $off=0;
    $len=strlen($data);
    $noProgressSince=microtime(true);

    while ($off<$len) {
        $n=@fwrite($s, substr($data,$off));

        if ($n===false) return false;

        if ($n>0) {
            $off += $n;
            $noProgressSince=microtime(true);
            continue;
        }
        $read=null;
        $write=array($s);
        $except=null;

        $ready=@stream_select($read,$write,$except,0,250000);

        if ($ready===false) return false;
        if ((microtime(true)-$noProgressSince)>=8.0) return false;
    }

    return true;
}
function gw_read_headers($s,$limit=65536,$timeout=5) {
    stream_set_blocking($s,true); stream_set_timeout($s,$timeout); $buf='';
    while (strpos($buf,"\r\n\r\n")===false && strlen($buf)<$limit && !feof($s)) {
        $c=@fread($s,8192); if ($c===false||$c==='') { $m=stream_get_meta_data($s); if(!empty($m['timed_out'])) break; usleep(1000); continue; } $buf.=$c;
    }
    return strpos($buf,"\r\n\r\n")===false ? '' : $buf;
}
function gw_status($file,$data) { if($file!==''){@file_put_contents($file,json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),LOCK_EX);@chmod($file,0600);} }
function gw_close_pair(&$pairs,$id) {
    if (!isset($pairs[$id])) return;
    foreach (array('client','upstream') as $k) if (isset($pairs[$id][$k]) && is_resource($pairs[$id][$k])) @fclose($pairs[$id][$k]);
    unset($pairs[$id]);
}

$configFile = isset($argv[1]) ? (string)$argv[1] : '';
$cfg = $configFile!=='' && is_file($configFile) ? json_decode((string)@file_get_contents($configFile),true) : null;
if (!is_array($cfg)) { fwrite(STDERR,"Config Gateway invalide\n"); exit(1); }
$host=trim((string)($cfg['listen_host']??'127.0.0.1')); $port=(int)($cfg['listen_port']??6079);
$ready=(string)($cfg['ready_file']??''); $status=(string)($cfg['status_file']??''); $pid=(string)($cfg['pid_file']??'');
$maxRuntime=max(600,min(604800,(int)($cfg['max_runtime']??86400)));
if($host===''||$port<1024||$port>65535){gw_status($status,array('ok'=>false,'error'=>'Bind Gateway invalide.'));exit(1);}
$errno=0;$errstr=''; $server=@stream_socket_server('tcp://'.$host.':'.$port,$errno,$errstr,STREAM_SERVER_BIND|STREAM_SERVER_LISTEN);
if(!is_resource($server)){gw_status($status,array('ok'=>false,'error'=>'Impossible d’écouter '.$host.':'.$port.' : '.$errstr));exit(1);}
stream_set_blocking($server,false);
if($pid!==''){@file_put_contents($pid,(string)getmypid(),LOCK_EX);@chmod($pid,0600);} if($ready!==''){@file_put_contents($ready,(string)getmypid(),LOCK_EX);@chmod($ready,0600);}
gw_status($status,array('ok'=>true,'state'=>'listening','host'=>$host,'port'=>$port,'pid'=>getmypid(),'time'=>date('c')));
@unlink($configFile);

$pairs=array(); $nextId=1; $deadline=time()+$maxRuntime;
while(time()<$deadline){
    $read=array($server); $map=array();
    foreach($pairs as $id=>$p){
        if(is_resource($p['client'])){$read[]=$p['client'];$map[(int)$p['client']]=array($id,'client');}
        if(is_resource($p['upstream'])){$read[]=$p['upstream'];$map[(int)$p['upstream']]=array($id,'upstream');}
    }
    $write=null;$except=null; $n=@stream_select($read,$write,$except,1,0); if($n===false)continue;
    foreach($read as $s){
        if($s===$server){
            $client=@stream_socket_accept($server,0); if(!is_resource($client))continue;
            $request=gw_read_headers($client); if($request===''){@fclose($client);continue;}
            $first=strtok($request,"\r\n");
            if(preg_match('~^GET\\s+([^\\s]+)\\s+HTTP/~',(string)$first,$m)!==1){gw_write_all($client,"HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n");@fclose($client);continue;}
            $target=$m[1]; $path=parse_url($target,PHP_URL_PATH);
            if($path==='/__dmdpx_health') {$body="DMDPX-GATEWAY-OK\n";gw_write_all($client,"HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nX-DMDPX-Gateway-Version: 2.6.9\r\nContent-Length: ".strlen($body)."\r\nConnection: close\r\n\r\n".$body);@fclose($client);continue;}
            if(!is_string($path)||preg_match('~/(60(?:8[0-9]|9[0-9])|61(?:0[0-9]|1[0-9]|2[0-9]))/([a-fA-F0-9]{48})/?$~',$path,$mm)!==1){gw_write_all($client,"HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n");@fclose($client);continue;}
            $bridgePort=(int)$mm[1];$token=strtolower($mm[2]);
            $errno=0;$errstr='';$up=@stream_socket_client('tcp://127.0.0.1:'.$bridgePort,$errno,$errstr,3,STREAM_CLIENT_CONNECT);
            if(!is_resource($up)){gw_write_all($client,"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n");@fclose($client);continue;}
            $request=preg_replace('~^GET\\s+[^\\s]+\\s+HTTP/~','GET /'.$token.' HTTP/',$request,1);
            if(!gw_write_all($up,$request)){@fclose($up);@fclose($client);continue;}
            stream_set_blocking($client,false);stream_set_blocking($up,false);
            $id=$nextId++;$pairs[$id]=array('client'=>$client,'upstream'=>$up,'started'=>time());
            continue;
        }
        $key=(int)$s; if(!isset($map[$key]))continue; [$id,$side]=$map[$key]; if(!isset($pairs[$id]))continue;
        $dest=$side==='client'?$pairs[$id]['upstream']:$pairs[$id]['client'];
        $chunk=@fread($s,65536);
        if($chunk===false||$chunk===''){if(feof($s)){gw_close_pair($pairs,$id);}continue;}
        if(!is_resource($dest)||!gw_write_all($dest,$chunk)){gw_close_pair($pairs,$id);continue;}
    }
}
foreach(array_keys($pairs) as $id)gw_close_pair($pairs,$id);
@fclose($server);@unlink($ready);@unlink($pid);gw_status($status,array('ok'=>true,'state'=>'stopped','time'=>date('c')));
