<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */

if (!function_exists('dmd_proxmox_preset_file')) {
    function dmd_proxmox_preset_file() {
        $paths = dmd_proxmox_storage_paths();
        return rtrim($paths['cfg'], '/\\') . DIRECTORY_SEPARATOR . 'vm-presets.json';
    }
}

if (!function_exists('dmd_proxmox_presets_read')) {
    function dmd_proxmox_presets_read() {
        $file = dmd_proxmox_preset_file();
        $fallback = array('version' => 1, 'updated_at' => null, 'presets' => array());
        if (!is_file($file)) return $fallback;
        $data = json_decode((string)@file_get_contents($file), true);
        if (!is_array($data)) return $fallback;
        if (!isset($data['presets']) || !is_array($data['presets'])) $data['presets'] = array();
        return $data;
    }
}

if (!function_exists('dmd_proxmox_presets_write')) {
    function dmd_proxmox_presets_write($data) {
        if (!is_array($data)) return false;
        $file = dmd_proxmox_preset_file();
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $data['version'] = 1;
        $data['updated_at'] = date('c');
        if (!isset($data['presets']) || !is_array($data['presets'])) $data['presets'] = array();
        $tmp = $file . '.tmp-' . bin2hex(random_bytes(4));
        if (@file_put_contents($tmp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) === false) return false;
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmd_proxmox_preset_clean')) {
    function dmd_proxmox_preset_clean($preset) {
        if (!is_array($preset)) return null;
        $label = trim((string)(isset($preset['label']) ? $preset['label'] : ''));
        $serverId = trim((string)(isset($preset['server_id']) ? $preset['server_id'] : ''));
        $node = trim((string)(isset($preset['node']) ? $preset['node'] : ''));
        $storage = trim((string)(isset($preset['storage_vm']) ? $preset['storage_vm'] : ''));
        $bridge = trim((string)(isset($preset['bridge']) ? $preset['bridge'] : ''));
        if ($label === '' || $serverId === '' || $node === '' || $storage === '' || $bridge === '') return null;

        $id = trim((string)(isset($preset['id']) ? $preset['id'] : ''));
        if ($id === '') $id = dmd_proxmox_slug($label) . '-' . substr(bin2hex(random_bytes(4)), 0, 8);
        $id = preg_replace('/[^a-zA-Z0-9._-]+/', '-', $id);
        $id = trim((string)$id, '.-_');
        if ($id === '') return null;

        $ostype = strtolower(trim((string)(isset($preset['ostype']) ? $preset['ostype'] : 'l26')));
        if (!in_array($ostype, array('l26', 'win11', 'win10', 'other'), true)) $ostype = 'l26';

        $after = strtolower(trim((string)(isset($preset['after_create']) ? $preset['after_create'] : 'vm')));
        if (!in_array($after, array('none', 'vm', 'remote'), true)) $after = 'vm';
        $openCount = strtolower(trim((string)(isset($preset['open_count']) ? $preset['open_count'] : 'first')));
        if (!in_array($openCount, array('first', 'all'), true)) $openCount = 'first';

        $prefix = strtoupper(trim((string)(isset($preset['name_prefix']) ? $preset['name_prefix'] : '')));
        $prefix = preg_replace('/[^A-Z0-9-]+/', '-', $prefix);
        $prefix = trim((string)$prefix, '-');
        if ($prefix === '') $prefix = strpos($ostype, 'win') === 0 ? 'WIN' : ($ostype === 'l26' ? 'LINUX' : 'VM');
        $prefix = substr($prefix, 0, 24);

        $vlan = (int)(isset($preset['vlan']) ? $preset['vlan'] : 0);
        if ($vlan < 0 || $vlan > 4094) $vlan = 0;

        $maxQty = max(1, min(20, (int)(isset($preset['max_quantity']) ? $preset['max_quantity'] : 10)));

        return array(
            'id' => $id,
            'label' => substr($label, 0, 100),
            'server_id' => $serverId,
            'node' => $node,
            'name_prefix' => $prefix,
            'ostype' => $ostype,
            'cpu' => max(1, min(128, (int)(isset($preset['cpu']) ? $preset['cpu'] : 2))),
            'ram' => max(128, min(1048576, (int)(isset($preset['ram']) ? $preset['ram'] : 2048))),
            'disk' => max(1, min(65536, (int)(isset($preset['disk']) ? $preset['disk'] : 20))),
            'storage_vm' => substr($storage, 0, 128),
            'iso' => substr(trim((string)(isset($preset['iso']) ? $preset['iso'] : '')), 0, 512),
            'bridge' => substr($bridge, 0, 64),
            'vlan' => $vlan,
            'auto_start' => !empty($preset['auto_start']),
            'after_create' => $after,
            'open_count' => $openCount,
            'max_quantity' => $maxQty,
            'enabled' => !array_key_exists('enabled', $preset) || !empty($preset['enabled']),
            'updated_at' => date('c')
        );
    }
}

if (!function_exists('dmd_proxmox_presets_list')) {
    function dmd_proxmox_presets_list($enabledOnly) {
        $data = dmd_proxmox_presets_read();
        $out = array();
        foreach ((array)$data['presets'] as $preset) {
            $clean = dmd_proxmox_preset_clean($preset);
            if (!is_array($clean)) continue;
            if ($enabledOnly && empty($clean['enabled'])) continue;
            $out[] = $clean;
        }
        usort($out, function($a, $b) { return strcasecmp((string)$a['label'], (string)$b['label']); });
        return $out;
    }
}

if (!function_exists('dmd_proxmox_preset_get')) {
    function dmd_proxmox_preset_get($id) {
        $id = trim((string)$id);
        if ($id === '') return null;
        foreach (dmd_proxmox_presets_list(false) as $preset) {
            if ((string)$preset['id'] === $id) return $preset;
        }
        return null;
    }
}

if (!function_exists('dmd_proxmox_preset_save')) {
    function dmd_proxmox_preset_save($preset) {
        $clean = dmd_proxmox_preset_clean($preset);
        if (!is_array($clean)) return array(false, 'Preset VM invalide.', null);
        $data = dmd_proxmox_presets_read();
        $found = false;
        foreach ($data['presets'] as $i => $existing) {
            if (is_array($existing) && isset($existing['id']) && (string)$existing['id'] === (string)$clean['id']) {
                $data['presets'][$i] = $clean;
                $found = true;
                break;
            }
        }
        if (!$found) $data['presets'][] = $clean;
        if (!dmd_proxmox_presets_write($data)) return array(false, 'Impossible d’enregistrer le preset.', null);
        return array(true, 'Preset VM enregistré.', $clean);
    }
}

if (!function_exists('dmd_proxmox_preset_delete')) {
    function dmd_proxmox_preset_delete($id) {
        $id = trim((string)$id);
        if ($id === '') return false;
        $data = dmd_proxmox_presets_read();
        $before = count($data['presets']);
        $data['presets'] = array_values(array_filter($data['presets'], function($preset) use ($id) {
            return !is_array($preset) || !isset($preset['id']) || (string)$preset['id'] !== $id;
        }));
        if (count($data['presets']) === $before) return false;
        return dmd_proxmox_presets_write($data);
    }
}

if (!function_exists('dmd_proxmox_random_vm_name')) {
    function dmd_proxmox_random_vm_name($server, $prefix) {
        $prefix = strtoupper(trim((string)$prefix));
        $prefix = preg_replace('/[^A-Z0-9-]+/', '-', $prefix);
        $prefix = trim((string)$prefix, '-');
        if ($prefix === '') $prefix = 'VM';
        $prefix = substr($prefix, 0, 24);

        $used = array();
        $all = dmd_proxmox_cluster_vms($server);
        if (!empty($all['ok']) && is_array($all['data'])) {
            foreach ($all['data'] as $vm) {
                if (is_array($vm) && !empty($vm['name'])) $used[strtoupper((string)$vm['name'])] = true;
            }
        }
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $max = strlen($alphabet) - 1;
        for ($attempt = 0; $attempt < 100; $attempt++) {
            $suffix = '';
            for ($i = 0; $i < 5; $i++) $suffix .= $alphabet[random_int(0, $max)];
            $name = $prefix . '-' . $suffix;
            if (!isset($used[strtoupper($name)])) return $name;
        }
        return $prefix . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    }
}

if (!function_exists('dmd_proxmox_wait_task')) {
    function dmd_proxmox_wait_task($server, $node, $upid, $timeoutSeconds) {
        $upid = trim((string)$upid);
        if ($upid === '') return array('ok' => true, 'exitstatus' => 'UNKNOWN');
        $deadline = microtime(true) + max(2, (int)$timeoutSeconds);
        $last = null;
        while (microtime(true) < $deadline) {
            $r = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/tasks/' . rawurlencode($upid) . '/status', 'GET', null, 10);
            if ($r['ok'] && is_array($r['data'])) {
                $last = $r['data'];
                $status = strtolower(trim((string)(isset($last['status']) ? $last['status'] : '')));
                if ($status === 'stopped') {
                    $exit = strtoupper(trim((string)(isset($last['exitstatus']) ? $last['exitstatus'] : '')));
                    return array('ok' => ($exit === '' || $exit === 'OK'), 'exitstatus' => $exit, 'data' => $last);
                }
            }
            usleep(400000);
        }
        return array('ok' => false, 'exitstatus' => 'TIMEOUT', 'data' => $last);
    }
}

if (!function_exists('dmd_proxmox_refresh_server_vm_cache')) {
    function dmd_proxmox_refresh_server_vm_cache($server) {
        $cache = dmd_proxmox_read_cache($server);
        if (!is_array($cache)) {
            $cache = array(
                'server_id' => isset($server['id']) ? $server['id'] : '',
                'server_name' => isset($server['name']) ? $server['name'] : '',
                'version' => null,
                'nodes' => array(),
                'cluster' => array('nodes_total'=>0,'nodes_online'=>0,'cpu'=>0,'mem'=>0,'maxmem'=>0,'disk'=>0,'maxdisk'=>0),
                'vms' => array(),
                'error' => null
            );
        }
        $vms = dmd_proxmox_cluster_vms($server);
        if (!$vms['ok'] || !is_array($vms['data'])) return false;
        $clean = array();
        foreach ($vms['data'] as $vm) {
            if (!is_array($vm)) continue;
            $type = strtolower(trim((string)(isset($vm['type']) ? $vm['type'] : 'qemu')));
            if ($type !== 'lxc') $type = 'qemu';
            $vm['type'] = $type;
            $clean[] = $vm;
        }
        $cache['vms'] = $clean;
        $cache['error'] = null;
        return dmd_proxmox_write_cache($server, $cache);
    }
}

if (!function_exists('dmd_proxmox_create_from_preset')) {
    function dmd_proxmox_create_from_preset($presetId, $quantity, $email, $afterOverride, $openCountOverride) {
        $email = trim((string)$email);
        if ($email === '' || !function_exists('dmd_proxmox_user_can_email') || !dmd_proxmox_user_can_email($email, 'vm.create')) {
            return array('ok'=>false, 'error'=>'permission_denied', 'message'=>'Droit de création VM refusé.', 'created'=>array());
        }

        $preset = dmd_proxmox_preset_get($presetId);
        if (!is_array($preset) || empty($preset['enabled'])) {
            return array('ok'=>false, 'error'=>'preset_not_found', 'message'=>'Preset VM introuvable ou désactivé.', 'created'=>array());
        }

        $server = dmd_proxmox_load_server($preset['server_id']);
        if (!is_array($server)) return array('ok'=>false, 'error'=>'server_not_found', 'message'=>'Serveur Proxmox du preset introuvable.', 'created'=>array());

        $quantity = max(1, (int)$quantity);
        if ($quantity > (int)$preset['max_quantity']) {
            return array('ok'=>false, 'error'=>'quantity_limit', 'message'=>'Ce preset autorise au maximum ' . (int)$preset['max_quantity'] . ' VM par exécution.', 'created'=>array());
        }

        $after = strtolower(trim((string)$afterOverride));
        if ($after === '' || $after === 'preset') $after = $preset['after_create'];
        if (!in_array($after, array('none','vm','remote'), true)) $after = $preset['after_create'];
        $openCount = strtolower(trim((string)$openCountOverride));
        if ($openCount === '' || $openCount === 'preset') $openCount = $preset['open_count'];
        if (!in_array($openCount, array('first','all'), true)) $openCount = $preset['open_count'];

        $nodes = dmd_proxmox_api($server, 'nodes', 'GET', null, 12);
        $nodeOk = false;
        if ($nodes['ok'] && is_array($nodes['data'])) {
            foreach ($nodes['data'] as $nodeRow) {
                if (is_array($nodeRow) && (string)(isset($nodeRow['node']) ? $nodeRow['node'] : '') === (string)$preset['node']) { $nodeOk = true; break; }
            }
        }
        if (!$nodeOk) return array('ok'=>false, 'error'=>'node_unavailable', 'message'=>'Node Proxmox du preset indisponible.', 'created'=>array());

        $created = array();
        for ($index = 0; $index < $quantity; $index++) {
            $vmid = dmd_proxmox_next_vmid($server);
            if ($vmid < 100) {
                return array('ok'=>false, 'error'=>'nextid_failed', 'message'=>'Impossible d’obtenir un VMID libre.', 'created'=>$created);
            }
            $name = dmd_proxmox_random_vm_name($server, $preset['name_prefix']);
            $net0 = 'virtio,bridge=' . $preset['bridge'] . ((int)$preset['vlan'] > 0 ? ',tag=' . (int)$preset['vlan'] : '');
            $payload = array(
                'vmid' => $vmid,
                'name' => $name,
                'sockets' => 1,
                'cores' => (int)$preset['cpu'],
                'memory' => (int)$preset['ram'],
                'scsihw' => 'virtio-scsi-pci',
                'scsi0' => $preset['storage_vm'] . ':' . (int)$preset['disk'],
                'net0' => $net0,
                'ostype' => $preset['ostype'],
                'agent' => 1
            );
            if ($preset['iso'] !== '') {
                $payload['ide2'] = $preset['iso'] . ',media=cdrom';
                $payload['boot'] = 'order=ide2;scsi0;net0';
            }

            $create = dmd_proxmox_api($server, 'nodes/' . rawurlencode($preset['node']) . '/qemu', 'POST', $payload, 30);
            if (!$create['ok']) {
                dmd_proxmox_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'error', 'Création VM ActionHub en erreur', array(
                    'source'=>'scenario','server_id'=>$preset['server_id'],'server'=>isset($server['name'])?(string)$server['name']:$preset['server_id'],'node'=>$preset['node'],'vmid'=>$vmid,'type'=>'qemu','name'=>$name,'vm_name'=>$name,'preset'=>$preset['label'],'preset_id'=>$preset['id'],'vlan'=>$preset['vlan'],'error'=>$create['error']
                ));
                return array('ok'=>false, 'error'=>'create_failed', 'message'=>'Création de #' . $vmid . ' impossible : ' . $create['error'], 'created'=>$created);
            }

            $task = dmd_proxmox_wait_task($server, $preset['node'], (string)$create['data'], 45);
            if (empty($task['ok'])) {
                dmd_proxmox_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'error', 'Création soumise mais tâche non terminée correctement', array(
                    'source'=>'scenario','server_id'=>$preset['server_id'],'server'=>isset($server['name'])?(string)$server['name']:$preset['server_id'],'node'=>$preset['node'],'vmid'=>$vmid,'type'=>'qemu','name'=>$name,'vm_name'=>$name,'preset'=>$preset['label'],'preset_id'=>$preset['id'],'vlan'=>$preset['vlan'],'upid'=>$create['data'],'exitstatus'=>$task['exitstatus']
                ));
                return array('ok'=>false, 'error'=>'create_task_failed', 'message'=>'La tâche de création de #' . $vmid . ' n’a pas terminé correctement (' . $task['exitstatus'] . ').', 'created'=>$created);
            }

            $started = false;
            if (!empty($preset['auto_start']) || $after === 'remote') {
                $start = dmd_proxmox_api($server, 'nodes/' . rawurlencode($preset['node']) . '/qemu/' . (int)$vmid . '/status/start', 'POST', array(), 20);
                if ($start['ok']) {
                    $startTask = dmd_proxmox_wait_task($server, $preset['node'], (string)$start['data'], 30);
                    $started = !empty($startTask['ok']);
                }
            }

            $entry = array(
                'server' => isset($server['name']) ? (string)$server['name'] : $preset['server_id'],
                'server_id' => $preset['server_id'],
                'server_ip' => isset($server['ip']) ? (string)$server['ip'] : '',
                'node' => $preset['server_id'],
                'real_node' => $preset['node'],
                'vmid' => $vmid,
                'name' => $name,
                'status' => $started ? 'running' : 'stopped',
                'running' => $started,
                'type' => 'qemu',
                'cpu' => 0,
                'ram_used' => 0,
                'ram_total' => (int)$preset['ram'],
                'ram_pct' => 0,
                'disk_used' => 0,
                'disk_total' => (int)$preset['disk'],
                'disk_pct' => 0
            );
            $created[] = $entry;

            dmd_proxmox_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'success', 'VM créée depuis le preset ActionHub « ' . $preset['label'] . ' »', array(
                'source'=>'scenario','server_id'=>$preset['server_id'],'server'=>isset($server['name'])?(string)$server['name']:$preset['server_id'],'node'=>$preset['node'],'vmid'=>$vmid,'type'=>'qemu','name'=>$name,'vm_name'=>$name,'preset'=>$preset['label'],'preset_id'=>$preset['id'],
                'storage'=>$preset['storage_vm'],'iso'=>$preset['iso'],'bridge'=>$preset['bridge'],'vlan'=>$preset['vlan'],'started'=>$started
            ));
        }

        dmd_proxmox_refresh_server_vm_cache($server);

        $createdLabels = array();
        foreach ($created as $createdVm) {
            $createdLabels[] = '#' . (int)$createdVm['vmid'] . ' ' . (string)$createdVm['name'];
        }
        $message = count($created) . ' VM créée' . (count($created) > 1 ? 's' : '') . ' depuis « ' . $preset['label'] . ' »';
        if ($createdLabels) $message .= ' : ' . implode(', ', $createdLabels);
        $message .= '.';
        return array(
            'ok'=>true,
            'message'=>$message,
            'created'=>$created,
            'after_create'=>$after,
            'open_count'=>$openCount,
            'preset'=>$preset
        );
    }
}
