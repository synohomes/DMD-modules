<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



require_once __DIR__ . '/DMD-Proxmox_storage.php';

if (!function_exists('dmd_proxmox_gateway_settings_file')) {
    function dmd_proxmox_gateway_settings_file() {
        $p = dmd_proxmox_storage_paths();
        return rtrim($p['cfg'], '/\\') . DIRECTORY_SEPARATOR . 'remote_gateway.json';
    }
}

if (!function_exists('dmd_proxmox_gateway_defaults')) {
    function dmd_proxmox_gateway_defaults() {
        return array(
            'listen_host' => '127.0.0.1',
            'listen_port' => 6079,
            'public_mode' => 'same_origin',
            'public_wss_url' => '',
            'max_runtime' => 86400
        );
    }
}

if (!function_exists('dmd_proxmox_gateway_load_settings')) {
    function dmd_proxmox_gateway_load_settings() {
        $cfg = dmd_proxmox_gateway_defaults();
        $file = dmd_proxmox_gateway_settings_file();
        if (is_file($file)) {
            $raw = @file_get_contents($file);
            $j = json_decode((string)$raw, true);
            if (is_array($j)) $cfg = array_merge($cfg, $j);
        }
        $host = trim((string)$cfg['listen_host']);
        if ($host === '' || strlen($host) > 255 || preg_match('/[\\s\\/\\\\]/', $host)) $host = '127.0.0.1';
        $port = (int)$cfg['listen_port'];
        if ($port < 1024 || $port > 65535) $port = 6079;
        $mode = $cfg['public_mode'] === 'custom' ? 'custom' : 'same_origin';
        $url = trim((string)$cfg['public_wss_url']);
        if ($url !== '' && stripos($url, 'wss://') !== 0) $url = '';
        return array(
            'listen_host'=>$host,
            'listen_port'=>$port,
            'public_mode'=>$mode,
            'public_wss_url'=>rtrim($url, '/'),
            'max_runtime'=>max(600, min(604800, (int)$cfg['max_runtime']))
        );
    }
}

if (!function_exists('dmd_proxmox_gateway_write_apache_htaccess')) {
    function dmd_proxmox_gateway_write_apache_htaccess($port) {
        $port = (int)$port;
        if ($port < 1024 || $port > 65535) $port = 6079;
        $file = __DIR__ . DIRECTORY_SEPARATOR . '.htaccess';
        $content = "# DMD-Proxmox 2.6.0 - Remote HTTPS/WSS via Gateway fixe.\n"
            . "RewriteEngine On\n"
            . "RewriteCond %{HTTP:Upgrade} =websocket [NC]\n"
            . "RewriteCond %{HTTP:Connection} upgrade [NC]\n"
            . "RewriteRule ^ws/(60(?:8[0-9]|9[0-9])|61(?:0[0-9]|1[0-9]|2[0-9]))/([A-Fa-f0-9]{48})/?$ ws://127.0.0.1:" . $port . "/$1/$2 [P,L,NE]\n";
        if (@file_put_contents($file, $content, LOCK_EX) === false) return false;
        @chmod($file, 0644);
        return true;
    }
}

if (!function_exists('dmd_proxmox_gateway_save_settings')) {
    function dmd_proxmox_gateway_save_settings($input, &$error) {
        $error = '';
        $host = trim((string)(isset($input['listen_host']) ? $input['listen_host'] : '127.0.0.1'));
        if ($host === '' || strlen($host) > 255 || preg_match('/[\\s\\/\\\\]/', $host)) {
            $error = 'Adresse d’écoute Gateway invalide.';
            return false;
        }
        $port = (int)(isset($input['listen_port']) ? $input['listen_port'] : 6079);
        if ($port < 1024 || $port > 65535) {
            $error = 'Port Gateway invalide.';
            return false;
        }
        $mode = (isset($input['public_mode']) && $input['public_mode'] === 'custom') ? 'custom' : 'same_origin';
        $url = trim((string)(isset($input['public_wss_url']) ? $input['public_wss_url'] : ''));
        if ($mode === 'custom') {
            if ($url === '' || stripos($url, 'wss://') !== 0 || filter_var(str_replace('wss://', 'https://', $url), FILTER_VALIDATE_URL) === false) {
                $error = 'L’URL WSS publique doit commencer par wss:// et être valide.';
                return false;
            }
            $url = rtrim($url, '/');
        } else {
            $url = '';
        }
        $cfg = array(
            'listen_host'=>$host,
            'listen_port'=>$port,
            'public_mode'=>$mode,
            'public_wss_url'=>$url,
            'max_runtime'=>86400,
            'updated_at'=>date('c')
        );
        $file = dmd_proxmox_gateway_settings_file();
        if (@file_put_contents($file, json_encode($cfg, JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE), LOCK_EX) === false) {
            $error = 'Écriture de la configuration Gateway impossible.';
            return false;
        }
        @chmod($file, 0640);
        /* Si Apache utilise le .htaccess du module, garder sa destination synchronisée. */
        dmd_proxmox_gateway_write_apache_htaccess($port);
        return true;
    }
}

if (!function_exists('dmd_proxmox_gateway_php_cli_candidates')) {
    function dmd_proxmox_gateway_php_cli_candidates() {
        $candidates = array();
        foreach (array(
            '/usr/local/bin/php',
            '/usr/bin/php',
            '/bin/php',
            '/usr/local/bin/php74',
            '/usr/local/bin/php80',
            '/usr/local/bin/php81',
            '/usr/local/bin/php82',
            '/usr/local/bin/php83',
            '/usr/local/bin/php84',
            '/opt/bin/php',
            '/opt/local/bin/php'
        ) as $c) {
            $candidates[] = $c;
        }

        foreach (array(
            '/var/packages/PHP*/target/usr/local/bin/php*',
            '/var/packages/PHP*/target/usr/bin/php*',
            '/volume*/@appstore/PHP*/usr/local/bin/php*',
            '/volume*/@appstore/PHP*/usr/bin/php*'
        ) as $pattern) {
            foreach ((array)glob($pattern) as $c) $candidates[] = $c;
        }

        if (defined('PHP_BINARY') && PHP_BINARY) $candidates[] = PHP_BINARY;

        $unique = array();
        foreach ($candidates as $c) {
            $c = trim((string)$c);
            if ($c === '' || isset($unique[$c])) continue;
            $unique[$c] = true;
        }
        return array_keys($unique);
    }
}

if (!function_exists('dmd_proxmox_gateway_php_cli_is_valid')) {
    function dmd_proxmox_gateway_php_cli_is_valid($binary) {
        $binary = trim((string)$binary);
        if ($binary === '' || !is_file($binary) || !is_executable($binary)) return false;

        $base = strtolower(basename($binary));
        if (strpos($base, 'fpm') !== false || strpos($base, 'cgi') !== false) return false;
        $cmd = escapeshellarg($binary) . ' -r ' . escapeshellarg('echo PHP_SAPI;');
        $out = '';

        if (function_exists('exec') && !in_array('exec', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true)) {
            $lines = array(); $rc = 1;
            @exec($cmd . ' 2>/dev/null', $lines, $rc);
            $out = trim(implode("\n", $lines));
            if ($rc === 0) return $out === 'cli';
        } elseif (function_exists('shell_exec') && !in_array('shell_exec', array_map('trim', explode(',', (string)ini_get('disable_functions'))), true)) {
            $out = trim((string)@shell_exec($cmd . ' 2>/dev/null'));
            if ($out !== '') return $out === 'cli';
        }

        return preg_match('/^php(?:[0-9.]*)?$/i', $base) === 1;
    }
}

if (!function_exists('dmd_proxmox_gateway_php_cli')) {
    function dmd_proxmox_gateway_php_cli() {
        foreach (dmd_proxmox_gateway_php_cli_candidates() as $c) {
            if (dmd_proxmox_gateway_php_cli_is_valid($c)) return $c;
        }
        return '';
    }
}

if (!function_exists('dmd_proxmox_gateway_function_enabled')) {
    function dmd_proxmox_gateway_function_enabled($name) {
        if (!function_exists($name)) return false;
        $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
        return !in_array($name, $disabled, true);
    }
}

if (!function_exists('dmd_proxmox_gateway_probe_host')) {
    function dmd_proxmox_gateway_probe_host($host) {
        $host = trim((string)$host);
        if ($host === '' || $host === '0.0.0.0' || $host === '::') return '127.0.0.1';
        return $host;
    }
}

if (!function_exists('dmd_proxmox_gateway_expected_version')) {
    function dmd_proxmox_gateway_expected_version() {
        return '2.6.9';
    }
}

if (!function_exists('dmd_proxmox_gateway_probe')) {
    function dmd_proxmox_gateway_probe($settings = null, &$error = '', &$version = '') {
        $error = '';
        $version = '';

        if (!is_array($settings)) $settings = dmd_proxmox_gateway_load_settings();

        $host = dmd_proxmox_gateway_probe_host($settings['listen_host']);
        $port = (int)$settings['listen_port'];
        $errno = 0;
        $errstr = '';

        $fp = @fsockopen($host, $port, $errno, $errstr, 0.35);
        if (!is_resource($fp)) {
            $error = $errstr !== '' ? $errstr : 'Gateway non joignable.';
            return false;
        }

        stream_set_timeout($fp, 1);
        @fwrite(
            $fp,
            "GET /__dmdpx_health HTTP/1.1\r\n"
            . "Host: gateway\r\n"
            . "Connection: close\r\n\r\n"
        );

        $raw = '';
        while (!feof($fp) && strlen($raw) < 8192) {
            $chunk = @fread($fp, 2048);
            if ($chunk === false) break;
            if ($chunk === '') {
                $meta = @stream_get_meta_data($fp);
                if (!empty($meta['timed_out'])) break;
                usleep(1000);
                continue;
            }
            $raw .= $chunk;
        }
        @fclose($fp);

        if (!preg_match('~^HTTP/1\.[01]\s+200\b~i', $raw)) {
            $error = 'Le port répond mais ce n’est pas la Gateway DMD-Proxmox.';
            return false;
        }

        if (preg_match('~^X-DMDPX-Gateway-Version:\s*([^\r\n]+)~mi', $raw, $m)) {
            $version = trim((string)$m[1]);
        }

        return strpos($raw, 'DMDPX-GATEWAY-OK') !== false;
    }
}

if (!function_exists('dmd_proxmox_gateway_runtime_paths')) {
    function dmd_proxmox_gateway_runtime_paths() {
        $p = dmd_proxmox_storage_paths();
        $dir = rtrim($p['remote'], '/\\');
        return array(
            'config'=>$dir . DIRECTORY_SEPARATOR . 'gateway-runtime.json',
            'ready'=>$dir . DIRECTORY_SEPARATOR . 'gateway.ready',
            'status'=>$dir . DIRECTORY_SEPARATOR . 'gateway.status.json',
            'pid'=>$dir . DIRECTORY_SEPARATOR . 'gateway.pid',
            'log'=>$dir . DIRECTORY_SEPARATOR . 'gateway.log'
        );
    }
}


if (!function_exists('dmd_proxmox_gateway_log_tail')) {
    function dmd_proxmox_gateway_log_tail($file, $maxLines = 30) {
        if (!is_file($file)) return '';
        $raw = @file($file, FILE_IGNORE_NEW_LINES);
        if (!is_array($raw)) return '';
        $raw = array_slice($raw, -max(1, (int)$maxLines));
        return trim(implode("\n", $raw));
    }
}

if (!function_exists('dmd_proxmox_gateway_process_alive')) {
    function dmd_proxmox_gateway_process_alive($pid) {
        $pid = (int)$pid;
        if ($pid <= 1) return false;
        if (function_exists('posix_kill')) return @posix_kill($pid, 0);
        if (is_dir('/proc/' . $pid)) return true;
        return false;
    }
}


if (!function_exists('dmd_proxmox_gateway_process_command')) {
    function dmd_proxmox_gateway_process_command($pid) {
        $pid = (int)$pid;
        if ($pid <= 1) return '';

        $proc = '/proc/' . $pid . '/cmdline';
        if (is_file($proc)) {
            $raw = @file_get_contents($proc);
            if (is_string($raw) && $raw !== '') {
                return trim(str_replace("\0", ' ', $raw));
            }
        }

        if (dmd_proxmox_gateway_function_enabled('exec')) {
            $lines=array(); $rc=1;
            @exec('ps -p ' . $pid . ' -o args= 2>/dev/null', $lines, $rc);
            if ($rc===0) return trim(implode(' ', $lines));
        }

        return '';
    }
}

if (!function_exists('dmd_proxmox_gateway_stop_old_process')) {
    function dmd_proxmox_gateway_stop_old_process(&$error = '') {
        $error = '';
        $rt = dmd_proxmox_gateway_runtime_paths();
        $pid = is_file($rt['pid'])
            ? (int)trim((string)@file_get_contents($rt['pid']))
            : 0;

        if ($pid <= 1 || !dmd_proxmox_gateway_process_alive($pid)) {
            @unlink($rt['pid']);
            @unlink($rt['ready']);
            return true;
        }
        $cmd = dmd_proxmox_gateway_process_command($pid);
        if ($cmd === '' || strpos($cmd, 'DMD-Proxmox_remote_gateway.php') === false) {
            $error = 'Ancienne Gateway détectée mais PID non reconnu : arrêt automatique refusé.';
            return false;
        }

        $sent = false;

        if (function_exists('posix_kill')) {
            $sent = @posix_kill($pid, 15);
        }

        if (!$sent && dmd_proxmox_gateway_function_enabled('exec')) {
            $lines=array(); $rc=1;
            @exec('kill -TERM ' . $pid . ' 2>/dev/null', $lines, $rc);
            $sent = ($rc===0);
        }

        if (!$sent) {
            $error = 'Impossible d’arrêter l’ancienne Gateway.';
            return false;
        }

        for ($i=0; $i<50; $i++) {
            usleep(50000);
            if (!dmd_proxmox_gateway_process_alive($pid)) break;
        }

        if (dmd_proxmox_gateway_process_alive($pid)) {
            $error = 'L’ancienne Gateway ne s’est pas arrêtée.';
            return false;
        }

        @unlink($rt['pid']);
        @unlink($rt['ready']);
        return true;
    }
}

if (!function_exists('dmd_proxmox_gateway_start')) {
    function dmd_proxmox_gateway_start(&$error = '') {
        $error = '';
        $settings = dmd_proxmox_gateway_load_settings();

        $probeError = '';
        $runningVersion = '';

        if (dmd_proxmox_gateway_probe($settings, $probeError, $runningVersion)) {
            if ($runningVersion === dmd_proxmox_gateway_expected_version()) {
                $rt = dmd_proxmox_gateway_runtime_paths();
                @file_put_contents($rt['ready'], (string)time(), LOCK_EX);
                @file_put_contents($rt['status'], json_encode(array(
                    'ok'=>true,
                    'state'=>'running',
                    'listen_host'=>$settings['listen_host'],
                    'listen_port'=>$settings['listen_port'],
                    'gateway_version'=>$runningVersion,
                    'detected_existing'=>true,
                    'updated_at'=>date('c')
                ), JSON_UNESCAPED_SLASHES), LOCK_EX);
                return true;
            }
            $stopError = '';
            if (!dmd_proxmox_gateway_stop_old_process($stopError)) {
                $error = $stopError;
                return false;
            }

            usleep(100000);
        }

        $php = dmd_proxmox_gateway_php_cli();
        $script = __DIR__ . '/DMD-Proxmox_remote_gateway.php';
        if ($php === '') {
            $error = 'PHP CLI introuvable. Sous Synology, installe/active un paquet PHP Web Station comportant le binaire CLI.';
            return false;
        }
        if (!is_file($script)) {
            $error = 'Fichier DMD-Proxmox_remote_gateway.php absent.';
            return false;
        }

        $rt = dmd_proxmox_gateway_runtime_paths();
        @unlink($rt['ready']);
        @unlink($rt['status']);
        @unlink($rt['pid']);
        @file_put_contents(
            $rt['log'],
            '[' . date('c') . "] START requested\n"
                . "PHP=" . $php . "\n"
                . "LISTEN=" . $settings['listen_host'] . ':' . $settings['listen_port'] . "\n",
            LOCK_EX
        );
        @chmod($rt['log'], 0600);

        $payload = array(
            'listen_host'=>$settings['listen_host'],
            'listen_port'=>$settings['listen_port'],
            'ready_file'=>$rt['ready'],
            'status_file'=>$rt['status'],
            'pid_file'=>$rt['pid'],
            'max_runtime'=>$settings['max_runtime']
        );
        if (@file_put_contents($rt['config'], json_encode($payload, JSON_UNESCAPED_SLASHES), LOCK_EX) === false) {
            $error = 'Création du runtime Gateway impossible.';
            return false;
        }
        @chmod($rt['config'], 0600);

        $cmd = 'nohup '
            . escapeshellarg($php) . ' '
            . escapeshellarg($script) . ' '
            . escapeshellarg($rt['config'])
            . ' >> ' . escapeshellarg($rt['log'])
            . ' 2>&1 < /dev/null & echo $!';

        $started = false;
        $spawnPid = 0;

        if (dmd_proxmox_gateway_function_enabled('exec')) {
            $lines = array(); $rc = 1;
            @exec($cmd, $lines, $rc);
            $spawnPid = isset($lines[0]) ? (int)trim((string)$lines[0]) : 0;
            $started = ($rc === 0 || $spawnPid > 1);
        } elseif (dmd_proxmox_gateway_function_enabled('shell_exec')) {
            $spawnPid = (int)trim((string)@shell_exec($cmd));
            $started = $spawnPid > 1;
        } elseif (dmd_proxmox_gateway_function_enabled('proc_open')) {
            $d = array(
                0=>array('file','/dev/null','r'),
                1=>array('pipe','w'),
                2=>array('file',$rt['log'],'a')
            );
            $proc = @proc_open('/bin/sh -c ' . escapeshellarg($cmd), $d, $pipes, __DIR__);
            if (is_resource($proc)) {
                $pidText = isset($pipes[1]) && is_resource($pipes[1]) ? trim((string)stream_get_contents($pipes[1])) : '';
                foreach ($pipes as $pipe) if (is_resource($pipe)) fclose($pipe);
                @proc_close($proc);
                $spawnPid = (int)$pidText;
                $started = $spawnPid > 1;
            }
        }

        if (!$started) {
            $tail = dmd_proxmox_gateway_log_tail($rt['log']);
            $error = 'Impossible de lancer le processus Gateway.';
            if ($tail !== '') $error .= ' Log : ' . str_replace("\n", ' | ', $tail);
            return false;
        }

        @file_put_contents($rt['log'], '[' . date('c') . '] SPAWN_PID=' . $spawnPid . "\n", FILE_APPEND | LOCK_EX);
        $lastProbeError = '';
        for ($i=0; $i<120; $i++) {
            usleep(50000);
            if (is_file($rt['ready']) && dmd_proxmox_gateway_probe($settings, $lastProbeError)) return true;

            $status = is_file($rt['status'])
                ? json_decode((string)@file_get_contents($rt['status']), true)
                : null;

            if (is_array($status) && isset($status['ok']) && !$status['ok'] && !empty($status['error'])) {
                $error = (string)$status['error'];
                $tail = dmd_proxmox_gateway_log_tail($rt['log']);
                if ($tail !== '') $error .= ' | Log : ' . str_replace("\n", ' | ', $tail);
                return false;
            }
        }

        $status = is_file($rt['status'])
            ? json_decode((string)@file_get_contents($rt['status']), true)
            : null;

        $tail = dmd_proxmox_gateway_log_tail($rt['log']);

        if (is_array($status) && !empty($status['error'])) {
            $error = (string)$status['error'];
        } elseif ($spawnPid > 1 && !dmd_proxmox_gateway_process_alive($spawnPid)) {
            $error = 'Le processus Gateway a quitté immédiatement après son lancement.';
        } else {
            $error = $lastProbeError !== ''
                ? $lastProbeError
                : 'La Gateway a été lancée mais son endpoint de santé ne répond pas.';
        }

        if ($tail !== '') $error .= ' | Log : ' . str_replace("\n", ' | ', $tail);
        return false;
    }
}

if (!function_exists('dmd_proxmox_gateway_status')) {
    function dmd_proxmox_gateway_status() {
        $settings = dmd_proxmox_gateway_load_settings();
        $err = '';
        $running = dmd_proxmox_gateway_probe($settings, $err);
        $rt = dmd_proxmox_gateway_runtime_paths();

        $runtimeStatus = is_file($rt['status'])
            ? json_decode((string)@file_get_contents($rt['status']), true)
            : null;

        if ($running) {
            $runtimeStatus = array(
                'ok'=>true,
                'state'=>'running',
                'listen_host'=>$settings['listen_host'],
                'listen_port'=>$settings['listen_port']
            );
        }

        $pid = is_file($rt['pid']) ? (int)trim((string)@file_get_contents($rt['pid'])) : 0;

        return array(
            'running'=>$running,
            'error'=>$running ? '' : $err,
            'settings'=>$settings,
            'php_cli'=>dmd_proxmox_gateway_php_cli(),
            'can_spawn'=>dmd_proxmox_gateway_function_enabled('exec')
                || dmd_proxmox_gateway_function_enabled('shell_exec')
                || dmd_proxmox_gateway_function_enabled('proc_open'),
            'pid'=>$pid,
            'pid_alive'=>$pid > 1 ? dmd_proxmox_gateway_process_alive($pid) : false,
            'runtime_status'=>is_array($runtimeStatus) ? $runtimeStatus : array(),
            'log_tail'=>dmd_proxmox_gateway_log_tail($rt['log'])
        );
    }
}

