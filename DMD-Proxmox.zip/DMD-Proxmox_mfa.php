<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */

if (session_status() === PHP_SESSION_NONE) session_start();

require_once __DIR__ . '/DMD-Proxmox_lib.php';

if (!headers_sent()) {
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

if (!dmd_proxmox_has_module_assignment()) {
    dmd_proxmox_json(false, 'Module DMD-Proxmox non autorisé pour cet utilisateur.', array(), 403);
}

$action = strtolower(trim((string)(isset($_POST['action']) ? $_POST['action'] : 'status')));

if ($action === 'status') {
    $required = dmd_proxmox_mfa_required();
    $unlocked = dmd_proxmox_mfa_unlocked(false);
    $settings = dmd_proxmox_mfa_security_settings();

    dmd_proxmox_json(true, '', array(
        'mfa_required'=>$required,
        'unlocked'=>$unlocked,
        'ttl'=>dmd_proxmox_mfa_ttl(),
        'lock_minutes'=>(int)$settings['lock_minutes'],
        'remaining_seconds'=>$required && $unlocked ? dmd_proxmox_mfa_remaining() : 0
    ), 200);
}

if ($action === 'lock') {
    if (!dmd_proxmox_csrf_valid(isset($_POST['csrf']) ? $_POST['csrf'] : '')) {
        dmd_proxmox_json(false, 'Jeton de sécurité expiré.', array(), 403);
    }
    dmd_proxmox_mfa_lock();
    dmd_proxmox_json(true, 'DMD-Proxmox verrouillé.', array(), 200);
}

if ($action !== 'unlock') {
    dmd_proxmox_json(false, 'Action MFA inconnue.', array(), 400);
}

if (!dmd_proxmox_csrf_valid(isset($_POST['csrf']) ? $_POST['csrf'] : '')) {
    dmd_proxmox_json(false, 'Jeton de sécurité expiré. Recharge la page.', array(), 403);
}

if (!dmd_proxmox_mfa_required()) {
    dmd_proxmox_json(true, 'Aucun MFA actif : DMD-Proxmox est utilisable normalement.', array(
        'mfa_required'=>false,
        'unlocked'=>true
    ), 200);
}

$password = (string)(isset($_POST['password']) ? $_POST['password'] : '');
$code = trim((string)(isset($_POST['mfa_code']) ? $_POST['mfa_code'] : ''));

$message = '';
if (!dmd_proxmox_mfa_unlock($password, $code, $message)) {
    if (function_exists('dmd_system_log')) {
        try {
            dmd_system_log(
                'dmd_proxmox_stepup_failed',
                dmd_proxmox_user_email(),
                'denied',
                'Échec du déverrouillage MFA DMD-Proxmox.'
            );
        } catch (Throwable $e) {}
    }

    usleep(random_int(180000, 360000));
    dmd_proxmox_json(false, $message !== '' ? $message : 'Authentification refusée.', array(), 403);
}

dmd_proxmox_json(true, $message, array(
    'mfa_required'=>true,
    'unlocked'=>true,
    'expires_after'=>dmd_proxmox_mfa_ttl(),
    'remaining_seconds'=>dmd_proxmox_mfa_remaining()
), 200);
