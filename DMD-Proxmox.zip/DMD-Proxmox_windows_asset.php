<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';

header('Cache-Control: private, max-age=3600');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');

function dmdpxwa_fail($message, $status) {
    http_response_code((int)$status);
    header('Content-Type: text/plain; charset=utf-8');
    echo (string)$message;
    exit;
}

if (!dmd_proxmox_has_module_access() || !dmd_proxmox_user_can('console')) {
    dmdpxwa_fail('Droit Remote refusé.', 403);
}
if (!dmd_proxmox_csrf_valid(isset($_GET['csrf']) ? $_GET['csrf'] : '')) {
    dmdpxwa_fail('Jeton de sécurité invalide.', 403);
}

$serverId = trim((string)(isset($_GET['server_id']) ? $_GET['server_id'] : ''));
$file = str_replace('\\', '/', trim((string)(isset($_GET['file']) ? $_GET['file'] : '')));
if ($serverId === '' || $file === '') dmdpxwa_fail('Paramètres incomplets.', 400);

$file = ltrim($file, '/');
if (strpos($file, "\0") !== false || preg_match('~(^|/)\.\.?(/|$)~', $file)) {
    dmdpxwa_fail('Chemin interdit.', 400);
}
if (!preg_match('~^[A-Za-z0-9_./-]+\.(?:js|json)$~', $file)) {
    dmdpxwa_fail('Type de fichier interdit.', 400);
}

$server = dmd_proxmox_load_server($serverId);
if (!is_array($server)) dmdpxwa_fail('Serveur Proxmox introuvable.', 404);
$ip = trim((string)(isset($server['ip']) ? $server['ip'] : ''));
$port = (int)(isset($server['port']) ? $server['port'] : 8006);
if ($port <= 0 || $port > 65535) $port = 8006;
if ($ip === '') dmdpxwa_fail('Adresse Proxmox absente.', 500);

$paths = dmd_proxmox_storage_paths();
$cacheBase = rtrim((string)$paths['cache'], '/\\') . DIRECTORY_SEPARATOR . 'novnc-pve';
$cacheKey = preg_replace('~[^A-Za-z0-9_.-]+~', '_', $serverId);
$cacheRoot = $cacheBase . DIRECTORY_SEPARATOR . $cacheKey;
$cacheFile = $cacheRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $file);
$ttl = 21600; // 6 h : permet de suivre les mises à jour du noVNC Proxmox.

function dmdpxwa_fetch($url, $cookie) {
    if (!function_exists('curl_init')) return array('ok' => false, 'http' => 0, 'body' => '', 'type' => '', 'error' => 'cURL absent');
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CONNECTTIMEOUT => 4,
        CURLOPT_TIMEOUT => 12,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_HTTPHEADER => $cookie !== '' ? array('Cookie: PVEAuthCookie=' . $cookie) : array(),
        CURLOPT_USERAGENT => 'DoMyDesk-DMD-Proxmox/2.3.6'
    ));
    $body = curl_exec($ch);
    $error = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $type = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);
    return array('ok' => $body !== false && $error === '' && $http >= 200 && $http < 300, 'http' => $http, 'body' => $body === false ? '' : (string)$body, 'type' => $type, 'error' => $error);
}

function dmdpxwa_norm($baseFile, $relative) {
    $relative = str_replace('\\', '/', (string)$relative);
    $base = explode('/', str_replace('\\', '/', dirname((string)$baseFile)));
    $parts = array_merge($base, explode('/', $relative));
    $out = array();
    foreach ($parts as $part) {
        if ($part === '' || $part === '.') continue;
        if ($part === '..') { array_pop($out); continue; }
        $out[] = $part;
    }
    return implode('/', $out);
}

function dmdpxwa_rewrite_js($source, $currentFile, $serverId, $csrf) {
    $endpoint = basename(__FILE__);
    $build = function($relative) use ($currentFile, $serverId, $csrf, $endpoint) {
        $target = dmdpxwa_norm($currentFile, $relative);
        return $endpoint . '?server_id=' . rawurlencode($serverId) . '&file=' . rawurlencode($target) . '&csrf=' . rawurlencode($csrf);
    };

    // import ... from './x.js' / export ... from '../x.js'
    $source = preg_replace_callback(
        '~\\b(from\\s*)([\"\'])(\\.{1,2}/[^\"\']+\\.js)\\2~',
        function($m) use ($build) { return $m[1] . $m[2] . $build($m[3]) . $m[2]; },
        $source
    );
    // import './x.js'
    $source = preg_replace_callback(
        '~\\b(import\\s*)([\"\'])(\\.{1,2}/[^\"\']+\\.js)\\2~',
        function($m) use ($build) { return $m[1] . $m[2] . $build($m[3]) . $m[2]; },
        $source
    );
    // import('./x.js')
    $source = preg_replace_callback(
        '~\\bimport\\(\\s*([\"\'])(\\.{1,2}/[^\"\']+\\.js)\\1\\s*\\)~',
        function($m) use ($build) { return 'import(' . $m[1] . $build($m[2]) . $m[1] . ')'; },
        $source
    );
    return $source;
}

$body = '';
if (is_file($cacheFile) && (time() - (int)@filemtime($cacheFile)) < $ttl) {
    $body = (string)@file_get_contents($cacheFile);
}

if ($body === '') {
    $ticket = '';
    if (isset($_SESSION['dmd_proxmox_windows_asset_auth'][$serverId]) && is_array($_SESSION['dmd_proxmox_windows_asset_auth'][$serverId])) {
        $saved = $_SESSION['dmd_proxmox_windows_asset_auth'][$serverId];
        if ((int)(isset($saved['expires']) ? $saved['expires'] : 0) >= time()) {
            $ticket = (string)(isset($saved['ticket']) ? $saved['ticket'] : '');
        }
    }
    $candidates = array('/novnc/' . $file, '/novnc-pve/' . $file);
    $last = null;
    foreach ($candidates as $candidate) {
        $url = 'https://' . $ip . ':' . $port . $candidate;
        $res = dmdpxwa_fetch($url, '');
        if (!$res['ok'] && ($res['http'] === 401 || $res['http'] === 403) && $ticket !== '') {
            $res = dmdpxwa_fetch($url, $ticket);
        }
        $last = $res;
        if ($res['ok'] && trim((string)$res['body']) !== '') {
            $body = (string)$res['body'];
            break;
        }
    }

    if ($body === '') {
        $detail = is_array($last) ? (' HTTP ' . (int)$last['http'] . ($last['error'] !== '' ? ' - ' . $last['error'] : '')) : '';
        dmdpxwa_fail('Impossible de charger le client noVNC patché depuis Proxmox.' . $detail, 502);
    }

    if (substr($file, -3) === '.js') {
        $body = dmdpxwa_rewrite_js($body, $file, $serverId, (string)$_GET['csrf']);
    }

    @mkdir(dirname($cacheFile), 0750, true);
    @file_put_contents($cacheFile, $body, LOCK_EX);
    @chmod($cacheFile, 0640);
}

if (substr($file, -3) === '.js') {
    header('Content-Type: text/javascript; charset=utf-8');
} else {
    header('Content-Type: application/json; charset=utf-8');
}
echo $body;
