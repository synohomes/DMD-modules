<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
require_once __DIR__ . '/DMD-Proxmox_lib.php';
$DMD_PROXMOX_BASE_URL = '/domydesk/modules/DMD-Proxmox';
$documentRoot = realpath(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '');
$moduleRealDir = realpath(__DIR__);
if ($documentRoot !== false && $moduleRealDir !== false && strpos($moduleRealDir, $documentRoot) === 0) {
  $rel = str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot)));
  $DMD_PROXMOX_BASE_URL = '/' . trim($rel, '/');
} else {
  $scriptName = str_replace('\\', '/', (string)(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : ''));
  if (strpos($scriptName, '/modules/DMD-Proxmox/') !== false) {
    $DMD_PROXMOX_BASE_URL = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
  }
}

if (!dmd_proxmox_has_module_assignment()) {
  echo "<div class='dmd-proxmox-empty'>⛔ Ce module ne vous a pas été attribué.</div>";
  return;
}
if (dmd_proxmox_mfa_required() && !dmd_proxmox_mfa_unlocked(false)) {
  echo "<link rel='stylesheet' href='" . dmd_proxmox_e($DMD_PROXMOX_BASE_URL . '/DMD-Proxmox.css?v=275interface') . "'>";
  echo dmd_proxmox_mfa_gate_html($DMD_PROXMOX_BASE_URL, 'module');
  return;
}

if (!dmd_proxmox_has_module_access() || !dmd_proxmox_user_can('view')) {
  echo "<div class='dmd-proxmox-empty'>⛔ Accès DMD-Proxmox refusé.</div>";
  return;
}

$ENABLE_CONSOLE = is_file(__DIR__ . '/novnc/core/rfb.js') && is_file(__DIR__ . '/DMD-Proxmox_remote_bridge.php') && dmd_proxmox_user_can('console');
$CACHE_TTL = 120;
$CSRF_DMD_PROXMOX = dmd_proxmox_csrf_token();
$CAN_REFRESH = dmd_proxmox_user_can('refresh');
$CAN_START = dmd_proxmox_user_can('vm.start');
$CAN_SHUTDOWN = dmd_proxmox_user_can('vm.shutdown');
$CAN_STOP = dmd_proxmox_user_can('vm.stop');
$CAN_REBOOT = dmd_proxmox_user_can('vm.reboot');
$CAN_RESET = dmd_proxmox_user_can('vm.reset');
$CAN_CREATE = dmd_proxmox_user_can('vm.create');
$CAN_DELETE = dmd_proxmox_user_can('vm.delete');
$CAN_FILES = dmd_proxmox_user_can('vm.files');
$CAN_LOG_VIEW = dmd_proxmox_user_can('logs.view');
$CAN_LOG_EXPORT = dmd_proxmox_user_can('logs.export');
$CAN_LOG_DELETE = dmd_proxmox_user_can('logs.delete');

$servers = dmd_proxmox_list_servers(false);

function dmd_proxmox_e($value) {
  return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_proxmox_ago($ts) {
  $d = time() - (int)$ts;
  if ($d < 60) return $d . 's';
  if ($d < 3600) return floor($d / 60) . 'm';
  if ($d < 86400) return floor($d / 3600) . 'h';
  return floor($d / 86400) . 'j';
}

function dmd_proxmox_bytes_to_gb($bytes, $decimals = 1) {
  $bytes = (float)$bytes;
  if ($bytes <= 0) return '0';
  return number_format($bytes / (1024 * 1024 * 1024), $decimals, '.', ' ');
}

function dmd_proxmox_bytes_to_mb($bytes, $decimals = 1) {
  $bytes = (float)$bytes;
  if ($bytes <= 0) return '0';
  return number_format($bytes / (1024 * 1024), $decimals, '.', ' ');
}

function dmd_proxmox_pct($value, $decimals = 1) {
  return round(((float)$value) * 100, $decimals);
}

function dmd_proxmox_json_attr($data) {
  return htmlspecialchars(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
}

if (empty($servers)) {
  echo "<link rel='stylesheet' href='" . dmd_proxmox_e($DMD_PROXMOX_BASE_URL . '/DMD-Proxmox.css?v=275interface') . "'>";
  echo "<div class='dmd-proxmox-empty'>Aucun serveur Proxmox configuré.</div>";
  return;
}

echo "<link rel='stylesheet' href='" . dmd_proxmox_e($DMD_PROXMOX_BASE_URL . '/DMD-Proxmox.css?v=275interface') . "'>";

$needUpdate = false;
?>

<div class="dmd-proxmox-root" data-dmd-proxmox-root>
<?php foreach ($servers as $srv): ?>
  <?php
    $srvName = isset($srv['name']) ? $srv['name'] : (isset($srv['ip']) ? $srv['ip'] : 'pve');
    $srvId = isset($srv['id']) ? $srv['id'] : dmd_proxmox_slug($srvName);
    $srvIp = $srv['ip'] ?? '-';
    $cache = dmd_proxmox_read_cache($srv);

    $stale = true;
    if ($cache && isset($cache['ts'])) {
      $stale = (time() - (int)$cache['ts'] > $CACHE_TTL);
    }

    if (!$cache || $stale) {
      $needUpdate = true;
    }

    $cluster = (isset($cache['cluster']) && is_array($cache['cluster'])) ? $cache['cluster'] : array();
    $cpuUsage = isset($cluster['cpu']) ? dmd_proxmox_pct($cluster['cpu']) : 0;
    $memUsedGb = isset($cluster['mem']) ? dmd_proxmox_bytes_to_gb($cluster['mem'], 1) : '0';
    $memTotalGb = isset($cluster['maxmem']) ? dmd_proxmox_bytes_to_gb($cluster['maxmem'], 1) : '0';
    $nodesOnline = (int)(isset($cluster['nodes_online']) ? $cluster['nodes_online'] : 0);
    $nodesTotal = (int)(isset($cluster['nodes_total']) ? $cluster['nodes_total'] : 0);

    $vmsArr = $cache['vms'] ?? [];
    if (is_array($vmsArr)) {
      usort($vmsArr, function($a, $b) {
        if (($a['status'] ?? '') !== ($b['status'] ?? '')) {
          return (($a['status'] ?? '') === 'running') ? -1 : 1;
        }

        return ((int)($a['vmid'] ?? 0)) <=> ((int)($b['vmid'] ?? 0));
      });
    } else {
      $vmsArr = [];
    }

    $runningCount = 0;
    foreach ($vmsArr as $vmCount) {
      if (($vmCount['status'] ?? '') === 'running') {
        $runningCount++;
      }
    }
  ?>

  <section class="dmd-proxmox-server-card" data-server-card data-server="<?= dmd_proxmox_e($srvId) ?>">
    <header class="dmd-proxmox-server-head">
      <button type="button" class="dmd-proxmox-server-title" data-server-toggle aria-label="Afficher ou masquer les machines virtuelles">
        <span class="dmd-proxmox-server-icon">▣</span>
        <span class="dmd-proxmox-server-name"><?= dmd_proxmox_e($srvName) ?></span>
        <span class="dmd-proxmox-server-ip"><?= dmd_proxmox_e($srvIp) ?></span>
      </button>

      <div class="dmd-proxmox-server-tools">
        <?php if ($cache && isset($cache['ts'])): ?>
          <span class="dmd-proxmox-cache-badge <?= $stale ? 'is-stale' : 'is-fresh' ?>">
            cache <?= dmd_proxmox_e(dmd_proxmox_ago($cache['ts'])) ?>
          </span>
        <?php else: ?>
          <span class="dmd-proxmox-cache-badge is-stale">initialisation</span>
        <?php endif; ?>

        <?php if (dmd_proxmox_can_manage_backups()): ?><button type="button" class="dmd-proxmox-backup-launch" data-prox-backup-open title="Gérer les sauvegardes">▣ Sauvegardes</button><?php endif; ?>
        <?php if (dmd_proxmox_is_admin()): ?><button type="button" class="dmd-proxmox-backup-launch" data-prox-manage-open="maintenance">Redémarrer</button><?php endif; ?>
        <?php if ($CAN_CREATE): ?><button type="button" class="dmd-proxmox-create-btn" data-dmd-proxmox-create-vm title="Créer une VM sur ce serveur">＋ VM</button><?php endif; ?>
        <?php if ($CAN_REFRESH): ?><button type="button" class="dmd-proxmox-refresh-btn" data-dmd-proxmox-refresh>↻ maj</button><?php endif; ?>
        <span class="dmd-proxmox-server-chevron">⌄</span>
      </div>
    </header>

    <div class="dmd-proxmox-server-body">
      <?php if (!empty($cache['error'])): ?>
        <div class="dmd-proxmox-api-warning">
          ⚠️ Erreur API <?= dmd_proxmox_e($cache['error']['where'] ?? '?') ?> — <?= dmd_proxmox_e($cache['error']['code'] ?? '?') ?>.
          Affichage basé sur le dernier cache disponible.
        </div>
      <?php endif; ?>

      <?php if (!$cache): ?>
        <div class="dmd-proxmox-loading">Chargement des données…</div>
        <div class="dmd-proxmox-vm-grid">
          <div class="dmd-proxmox-skeleton"></div>
          <div class="dmd-proxmox-skeleton"></div>
          <div class="dmd-proxmox-skeleton"></div>
        </div>
      <?php else: ?>
        <div class="dmd-proxmox-server-metrics">
          <div class="dmd-proxmox-metric">
            <span class="dmd-proxmox-metric-label">RAM utilisée</span>
            <strong><?= dmd_proxmox_e($memUsedGb) ?> / <?= dmd_proxmox_e($memTotalGb) ?> Go</strong>
          </div>
          <div class="dmd-proxmox-metric">
            <span class="dmd-proxmox-metric-label">CPU utilisé</span>
            <strong><?= dmd_proxmox_e($cpuUsage) ?>%</strong>
          </div>
          <div class="dmd-proxmox-metric">
            <span class="dmd-proxmox-metric-label">VM / CT · Nodes</span>
            <strong><?= count($vmsArr) ?> dont <?= $runningCount ?> actifs · <?= $nodesOnline ?>/<?= $nodesTotal ?> nodes</strong>
          </div>
        </div>

        <?php if (empty($vmsArr)): ?>
          <div class="dmd-proxmox-empty">Aucune machine virtuelle dans le cache.</div>
        <?php else: ?>
          <div class="dmd-proxmox-vm-grid">
            <?php foreach ($vmsArr as $vm): ?>
              <?php
                $vmid = (int)($vm['vmid'] ?? 0);
                $name = trim((string)($vm['name'] ?? ('VM-' . ($vmid ?: '?'))));
                $running = (($vm['status'] ?? '') === 'running');
                $statusText = $running ? 'running' : (($vm['status'] ?? '') ?: 'stopped');

                $typeForVm = strtolower((string)($vm['type'] ?? 'qemu'));
                if ($typeForVm !== 'lxc') {
                  $typeForVm = 'qemu';
                }

                $nodeForAction = $srvId;
                $realNode = isset($vm['node']) ? $vm['node'] : '-';

                $cpu = isset($vm['cpu']) ? dmd_proxmox_pct($vm['cpu']) : 0;
                $ramUsedMb = isset($vm['mem']) ? dmd_proxmox_bytes_to_mb($vm['mem'], 1) : '0';
                $ramMaxMb = (isset($vm['maxmem']) && (float)$vm['maxmem'] > 0) ? dmd_proxmox_bytes_to_mb($vm['maxmem'], 1) : '0';
                $ramPct = ((float)($vm['maxmem'] ?? 0) > 0) ? round(((float)($vm['mem'] ?? 0) / (float)$vm['maxmem']) * 100, 1) : 0;

                $diskUsedGb = isset($vm['disk']) ? dmd_proxmox_bytes_to_gb($vm['disk'], 1) : '0';
                $diskMaxGb = (isset($vm['maxdisk']) && (float)$vm['maxdisk'] > 0) ? dmd_proxmox_bytes_to_gb($vm['maxdisk'], 1) : '0';
                $diskPct = ((float)($vm['maxdisk'] ?? 0) > 0) ? round(((float)($vm['disk'] ?? 0) / (float)$vm['maxdisk']) * 100, 1) : 0;

                $vmPayload = [
                  'server' => $srvName,
                  'server_id' => $srvId,
                  'server_ip' => $srvIp,
                  'node' => $nodeForAction,
                  'real_node' => $realNode,
                  'vmid' => $vmid,
                  'name' => $name,
                  'status' => $statusText,
                  'running' => $running,
                  'type' => $typeForVm,
                  'cpu' => $cpu,
                  'ram_used' => $ramUsedMb,
                  'ram_total' => $ramMaxMb,
                  'ram_pct' => $ramPct,
                  'disk_used' => $diskUsedGb,
                  'disk_total' => $diskMaxGb,
                  'disk_pct' => $diskPct
                ];
              ?>

              <button
                type="button"
                class="dmd-proxmox-vm-tile <?= $running ? 'is-running' : 'is-stopped' ?>"
                data-vm-card
                data-vm="<?= dmd_proxmox_json_attr($vmPayload) ?>"
                title="Ouvrir les options de <?= dmd_proxmox_e($name) ?>"
              >
                <span class="dmd-proxmox-vm-topline">
                  <span class="dmd-proxmox-vm-status-dot"></span>
                  <span class="dmd-proxmox-vm-id">#<?= $vmid ?></span>
                  <span class="dmd-proxmox-vm-state"><?= dmd_proxmox_e($statusText) ?></span>
                </span>

                <span class="dmd-proxmox-vm-name"><?= dmd_proxmox_e($name) ?></span>

                <span class="dmd-proxmox-vm-mini-metrics">
                  <span>CPU <?= dmd_proxmox_e($cpu) ?>%</span>
                  <span>RAM <?= dmd_proxmox_e($ramPct) ?>%</span>
                </span>
              </button>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </section>
<?php endforeach; ?>

<?php if ($CAN_LOG_VIEW): ?>
  <section class="dmd-proxmox-task-panel" data-dmd-proxmox-task-panel>
    <header class="dmd-proxmox-task-head">
      <div>
        <span class="dmd-proxmox-task-kicker">Historique DMD-Proxmox</span>
        <h4>Journal des tâches</h4>
      </div>
      <div class="dmd-proxmox-task-tools">
        <button type="button" data-dmd-proxmox-log-refresh>↻ Actualiser</button>
        <?php if ($CAN_LOG_EXPORT): ?>
          <a href="<?= dmd_proxmox_e($DMD_PROXMOX_BASE_URL . '/DMD-Proxmox_logs.php?mode=pdf') ?>" data-dmd-proxmox-log-pdf>PDF</a>
          <button type="button" data-dmd-proxmox-log-print>Imprimer</button>
        <?php endif; ?>
        <?php if ($CAN_LOG_DELETE): ?>
          <button type="button" class="danger" data-dmd-proxmox-log-clear>Supprimer les logs</button>
        <?php endif; ?>
      </div>
    </header>

    <div class="dmd-proxmox-task-table-wrap">
      <table class="dmd-proxmox-task-table">
        <thead>
          <tr>
            <th>Date / heure</th>
            <th>Utilisateur</th>
            <th>Action</th>
            <th>Cible</th>
            <th>État</th>
            <th>Serveur / node</th>
            <th>Détails</th>
          </tr>
        </thead>
        <tbody data-dmd-proxmox-log-rows>
          <tr><td colspan="7" class="dmd-proxmox-task-empty">Chargement du journal…</td></tr>
        </tbody>
      </table>
    </div>

    <footer class="dmd-proxmox-task-foot">
      <span data-dmd-proxmox-log-count>0 tâche</span>
      <span>Stockage persistant : /data/modules/DMD-Proxmox/logs</span>
    </footer>
  </section>
<?php endif; ?>

  <div class="dmd-proxmox-toast" data-dmd-proxmox-toast></div>
</div>


<template id="dmd-proxmox-create-template">
  <section class="dmd-proxmox-vm-window dmd-proxmox-create-window" data-dmd-proxmox-create-window role="dialog" aria-modal="false">
    <header class="dmd-proxmox-modal-head" data-create-drag-handle>
      <div>
        <span class="dmd-proxmox-modal-kicker">Provisionnement</span>
        <h3>Créer une VM</h3>
      </div>
      <button type="button" class="dmd-proxmox-modal-close" data-create-close aria-label="Fermer">×</button>
    </header>

    <form class="dmd-proxmox-modal-body dmd-proxmox-create-form" data-create-form autocomplete="off">
      <input type="hidden" name="csrf" value="<?= dmd_proxmox_e($CSRF_DMD_PROXMOX) ?>">
      <input type="hidden" name="op" value="createvm">
      <input type="hidden" name="server_id" data-create-server-id>

      <div class="dmd-proxmox-create-grid">
        <label>
          <span>Serveur</span>
          <strong data-create-server-name>-</strong>
        </label>

        <label>
          <span>Node</span>
          <select name="node" data-create-node required></select>
        </label>

        <label>
          <span>VMID</span>
          <input type="number" name="vmid" data-create-vmid min="100" placeholder="Automatique">
        </label>

        <label class="is-wide">
          <span>Nom de la VM</span>
          <input type="text" name="vmname" maxlength="63" required placeholder="ex. SRV-TEST">
        </label>

        <label>
          <span>CPU</span>
          <input type="number" name="cpu" min="1" max="128" value="2" required>
        </label>

        <label>
          <span>RAM (Mo)</span>
          <input type="number" name="ram" min="128" step="128" value="2048" required>
        </label>

        <label>
          <span>Disque (Go)</span>
          <input type="number" name="disk" min="1" value="32" required>
        </label>

        <label>
          <span>Stockage VM</span>
          <select name="storage_vm" data-create-storage required></select>
        </label>

        <label>
          <span>Bridge</span>
          <select name="bridge" data-create-bridge required></select>
        </label>

        <label>
          <span>VLAN</span>
          <input type="number" name="vlan" min="0" max="4094" value="0">
        </label>

        <label>
          <span>Type d'OS</span>
          <select name="ostype">
            <option value="l26">Linux 2.6+ / moderne</option>
            <option value="win11">Windows 11 / Server récent</option>
            <option value="win10">Windows 10 / Server 2016-2022</option>
            <option value="win8">Windows 8 / Server 2012</option>
            <option value="win7">Windows 7 / Server 2008 R2</option>
            <option value="other">Autre</option>
          </select>
        </label>

        <label class="is-wide">
          <span>ISO</span>
          <select name="iso" data-create-iso>
            <option value="">Aucune ISO</option>
          </select>
        </label>
      </div>

      <label class="dmd-proxmox-create-check">
        <input type="checkbox" name="start_after" value="1">
        <span>Démarrer la VM après création</span>
      </label>

      <div class="dmd-proxmox-create-message" data-create-message></div>

      <div class="dmd-proxmox-create-actions">
        <button type="button" data-create-cancel>Annuler</button>
        <button type="submit" class="primary" data-create-submit>Créer la VM</button>
      </div>
    </form>

    <div class="dmd-proxmox-vm-resize" data-create-resize title="Redimensionner"></div>
  </section>
</template>

<template id="dmd-proxmox-vm-window-template">
  <section class="dmd-proxmox-modal-window dmd-proxmox-vm-window" data-dmd-proxmox-vm-window role="dialog" aria-modal="false">
    <header class="dmd-proxmox-modal-head" data-dmd-proxmox-drag-handle>
      <div>
        <span class="dmd-proxmox-modal-kicker">Machine virtuelle</span>
        <h3 data-dmd-proxmox-window-title>VM</h3>
      </div>
      <button type="button" class="dmd-proxmox-modal-close" data-dmd-proxmox-window-close aria-label="Fermer">×</button>
    </header>

    <div class="dmd-proxmox-modal-body">
      <div class="dmd-proxmox-modal-summary">
        <div>
          <span class="dmd-proxmox-detail-label">Serveur</span>
          <strong data-window-server>-</strong>
        </div>
        <div>
          <span class="dmd-proxmox-detail-label">Node Proxmox</span>
          <strong data-window-real-node>-</strong>
        </div>
        <div>
          <span class="dmd-proxmox-detail-label">Type</span>
          <strong data-window-type>-</strong>
        </div>
        <div>
          <span class="dmd-proxmox-detail-label">Statut</span>
          <strong data-window-status>-</strong>
        </div>
      </div>

      <div class="dmd-proxmox-resource-grid">
        <div class="dmd-proxmox-resource-card">
          <span class="dmd-proxmox-detail-label">CPU</span>
          <strong data-window-cpu>0%</strong>
          <div class="dmd-proxmox-progress"><span data-window-cpu-bar></span></div>
        </div>

        <div class="dmd-proxmox-resource-card">
          <span class="dmd-proxmox-detail-label">RAM</span>
          <strong data-window-ram>0 / 0 Mo</strong>
          <div class="dmd-proxmox-progress"><span data-window-ram-bar></span></div>
        </div>

        <div class="dmd-proxmox-resource-card">
          <span class="dmd-proxmox-detail-label">Disque</span>
          <strong data-window-disk>0 / 0 Go</strong>
          <div class="dmd-proxmox-progress"><span data-window-disk-bar></span></div>
        </div>
      </div>

      <div class="dmd-proxmox-actions">
        <?php if ($CAN_START): ?><button type="button" data-window-action="start">Démarrer</button><?php endif; ?>
        <?php if ($CAN_SHUTDOWN): ?><button type="button" data-window-action="shutdown">Éteindre proprement</button><?php endif; ?>
        <?php if ($CAN_STOP): ?><button type="button" data-window-action="stop">Stop forcé</button><?php endif; ?>
        <?php if ($CAN_REBOOT): ?><button type="button" data-window-action="reboot">Redémarrer</button><?php endif; ?>
        <?php if ($CAN_RESET): ?><button type="button" data-window-action="reset">Reset</button><?php endif; ?>
        <?php if ($CAN_FILES): ?><button type="button" data-window-files>Fichiers réseau</button><?php endif; ?>
        <?php if ($ENABLE_CONSOLE): ?><button type="button" data-window-remote>Remote</button><?php endif; ?>
        <?php if ($CAN_DELETE): ?><button type="button" class="danger" data-window-delete>Supprimer la VM / CT</button><?php endif; ?>
      </div>

      <?php if (dmd_proxmox_is_admin()): ?>
      <div class="dmd-proxmox-vm-admin" aria-label="Administration VM / CT">
        <button type="button" data-vm-manage="snapshots">Snapshots</button>
        <button type="button" data-vm-manage="migration">Migration</button>
        <button type="button" data-vm-manage="clone">Clonage / Template</button>
        <button type="button" data-vm-manage="vmhistory">Supervision VM/CT</button>
        <button type="button" data-vm-manage="storage">Stockage</button>
        <button type="button" data-vm-manage="replication">Réplication</button>
        <button type="button" data-vm-manage="maintenance">Maintenance</button>
        <button type="button" data-vm-manage="history">Supervision serveur</button>
        <button type="button" data-vm-manage="alerts">Alertes</button>
        <button type="button" data-vm-manage="pbs">PBS</button>
      </div>
      <?php endif; ?>
      <section data-window-details style="margin-top:10px;min-width:0;overflow-wrap:anywhere">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px"><strong>Informations détaillées</strong><button type="button" data-window-details-refresh>Actualiser</button></div>
        <div data-window-details-content aria-live="polite">Chargement…</div>
      </section>

      <?php if (!$ENABLE_CONSOLE): ?>
      <div class="dmd-proxmox-premium-note">
        Remote noVNC indisponible : composants locaux absents.
      </div>
      <?php endif; ?>
    </div>

    <div class="dmd-proxmox-vm-resize" data-dmd-proxmox-resize title="Redimensionner"></div>
  </section>
</template>

<div id="pv1-desktop"></div>
<template id="pv1-console-template">
  <div id="pv1-console" data-dmd-proxmox-console-window aria-modal="false" role="dialog">
    <div class="title">
      <span data-dmd-proxmox-console-cap>Console</span>
      <div class="dmd-proxmox-console-tools">
        <button
          class="dmd-proxmox-console-restart"
          type="button"
          data-dmd-proxmox-console-restart
          title="Relancer complètement le Remote"
        >↻ Relancer Remote</button>
        <button class="close" type="button">×</button>
      </div>
    </div>
    <div class="body">
      <iframe data-dmd-proxmox-console-frame src="about:blank" referrerpolicy="no-referrer"></iframe>
    </div>
    <div class="grip" title="Redimensionner"></div>
  </div>
</template>

<script>
(function(){
  const root = document.querySelector('[data-dmd-proxmox-root]');
  const CSRF_DMD_PROXMOX = <?= json_encode($CSRF_DMD_PROXMOX) ?>;
  const CAN_LOG_VIEW = <?= $CAN_LOG_VIEW ? 'true' : 'false' ?>;
  const CAN_LOG_EXPORT = <?= $CAN_LOG_EXPORT ? 'true' : 'false' ?>;
  const CAN_LOG_DELETE = <?= $CAN_LOG_DELETE ? 'true' : 'false' ?>;
  const DMD_PROXMOX_BASE_URL = <?= json_encode($DMD_PROXMOX_BASE_URL, JSON_UNESCAPED_SLASHES) ?>;
  const DMD_PROXMOX_LOGS_URL = DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_logs.php';
  const ENABLE_CONSOLE = <?= $ENABLE_CONSOLE ? 'true' : 'false' ?>;
  const CAN_FILES = <?= $CAN_FILES ? 'true' : 'false' ?>;
  const CAN_CREATE = <?= $CAN_CREATE ? 'true' : 'false' ?>;
  const CAN_DELETE = <?= $CAN_DELETE ? 'true' : 'false' ?>;
  const DMD_PROXMOX_FILES_URL = DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_files.php';
  (function ensurePersistentProxmoxCss(){
    const styleId = 'dmd-proxmox-persistent-css';
    const href = DMD_PROXMOX_BASE_URL + '/DMD-Proxmox.css?v=275interface';
    let link = document.getElementById(styleId);
    if (!link) {
      link = document.createElement('link');
      link.id = styleId;
      link.rel = 'stylesheet';
      link.dataset.dmdProxmoxPersistent = '1';
      document.head.appendChild(link);
    }
    if (link.getAttribute('href') !== href) link.setAttribute('href', href);
  })();

  if (!root) return;

  const vmTemplate = document.getElementById('dmd-proxmox-vm-window-template');
  const createTemplate = document.getElementById('dmd-proxmox-create-template');
  const toastBox = document.querySelector('[data-dmd-proxmox-toast]');
  const desktop = document.getElementById('pv1-desktop');
  const consoleTemplate = document.getElementById('pv1-console-template');
  const logRows = root.querySelector('[data-dmd-proxmox-log-rows]');
  const logCount = root.querySelector('[data-dmd-proxmox-log-count]');
  let lastLogItems = [];

  let vmWindowSequence = 0;
  let consoleWindowSequence = 0;
  let topZ = 10080;


  async function fetchFreshModuleHtml() {
    const response = await fetch(
      DMD_PROXMOX_BASE_URL + '/DMD-Proxmox.php?_dmd_module_refresh=' + Date.now(),
      {
        method: 'GET',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: {'X-Requested-With': 'XMLHttpRequest'}
      }
    );

    if (!response.ok) {
      throw new Error('Impossible de recharger le contenu DMD-Proxmox (' + response.status + ').');
    }

    return await response.text();
  }

  function findServerCardById(scope, serverId) {
    if (!scope) return null;
    const cards = scope.querySelectorAll('[data-server-card]');
    for (const card of cards) {
      if ((card.getAttribute('data-server') || '') === String(serverId || '')) {
        return card;
      }
    }
    return null;
  }

  function replaceServerCardFromHtml(serverId, html) {
    const currentCard = findServerCardById(root, serverId);
    if (!currentCard) {
      throw new Error('Carte serveur actuelle introuvable.');
    }

    const parser = new DOMParser();
    const doc = parser.parseFromString(String(html || ''), 'text/html');
    const freshRoot = doc.querySelector('[data-dmd-proxmox-root]');
    const freshCard = findServerCardById(freshRoot, serverId);

    if (!freshCard) {
      throw new Error('Carte serveur mise à jour introuvable.');
    }
    const wasCollapsed = currentCard.classList.contains('is-collapsed');
    const imported = document.importNode(freshCard, true);

    if (wasCollapsed) imported.classList.add('is-collapsed');
    else imported.classList.remove('is-collapsed');

    currentCard.replaceWith(imported);
    return imported;
  }

  async function refreshServerModuleOnly(serverId, button = null) {
    if (!serverId) throw new Error('Serveur Proxmox indéterminé.');

    const oldText = button ? button.textContent : '';
    if (button) {
      button.disabled = true;
      button.textContent = '↻ ...';
    }

    try {
      const refreshUrl = new URL(
        DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_fetch.php',
        window.location.origin
      );
      refreshUrl.searchParams.set('csrf', CSRF_DMD_PROXMOX);
      refreshUrl.searchParams.set('server_id', String(serverId));
      refreshUrl.searchParams.set('t', String(Date.now()));

      const refreshResponse = await fetch(refreshUrl.pathname + refreshUrl.search, {
        method: 'GET',
        credentials: 'same-origin',
        cache: 'no-store'
      });

      const refreshPayload = await refreshResponse.json().catch(() => null);
      if (!refreshResponse.ok || !refreshPayload || refreshPayload.ok === false) {
        throw new Error(
          refreshPayload && refreshPayload.message
            ? refreshPayload.message
            : 'Échec de la mise à jour Proxmox.'
        );
      }

      const html = await fetchFreshModuleHtml();
      const freshCard = replaceServerCardFromHtml(serverId, html);

      toast('✅ DMD-Proxmox actualisé');
      return freshCard;
    } finally {

      if (button && button.isConnected) {
        button.disabled = false;
        button.textContent = oldText || '↻ maj';
      }
    }
  }

  async function refreshAllServerCardsModuleOnly() {
    const serverIds = Array.from(root.querySelectorAll('[data-server-card]'))
      .map(card => card.getAttribute('data-server') || '')
      .filter(Boolean);

    if (!serverIds.length) return;

    const refreshUrl = new URL(
      DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_fetch.php',
      window.location.origin
    );
    refreshUrl.searchParams.set('csrf', CSRF_DMD_PROXMOX);
    refreshUrl.searchParams.set('t', String(Date.now()));

    const refreshResponse = await fetch(refreshUrl.pathname + refreshUrl.search, {
      method: 'GET',
      credentials: 'same-origin',
      cache: 'no-store'
    });

    if (!refreshResponse.ok) {
      throw new Error('Actualisation automatique Proxmox impossible.');
    }

    const html = await fetchFreshModuleHtml();

    for (const serverId of serverIds) {
      try {
        replaceServerCardFromHtml(serverId, html);
      } catch (_) {
      }
    }
  }

  function toast(message) {
    if (!toastBox) return;
    toastBox.textContent = message;
    toastBox.classList.add('is-visible');
    clearTimeout(window.__dmd_proxmox_toast);
    window.__dmd_proxmox_toast = setTimeout(() => {
      toastBox.classList.remove('is-visible');
    }, 2200);
  }

  function escHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function formatLogDate(item) {
    const ts = Number(item && item.timestamp ? item.timestamp : 0);
    if (ts > 0) {
      const d = new Date(ts * 1000);
      return d.toLocaleString('fr-FR', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit'});
    }
    return item && item.date ? String(item.date) : '-';
  }

  function logStatusMeta(status) {
    const value = String(status || '').toLowerCase();
    if (['success', 'ok', 'done'].includes(value)) return {label:'OK', cls:'is-success'};
    if (['error', 'failed', 'danger'].includes(value)) return {label:'Erreur', cls:'is-error'};
    return {label: value || 'Info', cls:'is-info'};
  }

  function renderTaskLogs(items) {
    if (!logRows) return;
    lastLogItems = Array.isArray(items) ? items : [];

    if (!lastLogItems.length) {
      logRows.innerHTML = '<tr><td colspan="7" class="dmd-proxmox-task-empty">Aucune tâche enregistrée.</td></tr>';
      if (logCount) logCount.textContent = '0 tâche';
      return;
    }

    logRows.innerHTML = lastLogItems.map((item) => {
      const meta = logStatusMeta(item.status);
      return `<tr>
        <td class="dmd-proxmox-task-nowrap">${escHtml(formatLogDate(item))}</td>
        <td>${escHtml(item.user || '-')}</td>
        <td><strong>${escHtml(item.action_label || item.action || '-')}</strong></td>
        <td data-label="Cible">${escHtml(item.target || '-')}</td>
        <td><span class="dmd-proxmox-task-status ${meta.cls}"><span></span>${escHtml(meta.label)}</span></td>
        <td data-label="Serveur / nœud">${escHtml(item.where || '-')}</td>
        <td class="dmd-proxmox-task-details">${escHtml(item.details || '-')}</td>
      </tr>`;
    }).join('');

    if (logCount) logCount.textContent = `${lastLogItems.length} tâche${lastLogItems.length > 1 ? 's' : ''} affichée${lastLogItems.length > 1 ? 's' : ''}`;
  }

  async function loadTaskLogs() {
    if (!CAN_LOG_VIEW || !logRows) return;
    try {
      const response = await fetch(DMD_PROXMOX_LOGS_URL + '?mode=list&limit=200&t=' + Date.now(), {cache:'no-store'});
      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload || !payload.ok) throw new Error(payload && payload.message ? payload.message : `HTTP ${response.status}`);
      renderTaskLogs(payload.items || []);
    } catch (error) {
      logRows.innerHTML = `<tr><td colspan="7" class="dmd-proxmox-task-empty">Impossible de charger le journal : ${escHtml(error.message)}</td></tr>`;
    }
  }

  function printTaskLogs() {
    if (!CAN_LOG_EXPORT || !lastLogItems.length) {
      toast('ℹ️ Aucun log à imprimer.');
      return;
    }

    const rows = lastLogItems.map((item) => {
      const meta = logStatusMeta(item.status);
      return `<tr><td>${escHtml(formatLogDate(item))}</td><td>${escHtml(item.user || '-')}</td><td>${escHtml(item.action_label || item.action || '-')}</td><td>${escHtml(item.target || '-')}</td><td>${escHtml(meta.label)}</td><td>${escHtml(item.where || '-')}</td><td>${escHtml(item.details || '-')}</td></tr>`;
    }).join('');

    const iframe = document.createElement('iframe');
    iframe.setAttribute('aria-hidden', 'true');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '1px';
    iframe.style.height = '1px';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    iframe.onload = () => {
      setTimeout(() => {
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } finally {
          setTimeout(() => iframe.remove(), 1200);
        }
      }, 80);
    };

    iframe.srcdoc = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>DMD-Proxmox - Journal des tâches</title><style>
      body{font-family:Arial,sans-serif;margin:18px;color:#111}h1{font-size:18px;margin:0 0 4px}p{font-size:11px;margin:0 0 14px;color:#555}table{width:100%;border-collapse:collapse;font-size:9px}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#eee}tr{break-inside:avoid}@page{size:landscape;margin:10mm}
    </style></head><body><h1>DMD-Proxmox — Journal des tâches</h1><p>Imprimé le ${escHtml(new Date().toLocaleString('fr-FR'))}</p><table><thead><tr><th>Date / heure</th><th>Utilisateur</th><th>Action</th><th>Cible</th><th>État</th><th>Serveur / node</th><th>Détails</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  }

  async function clearTaskLogs() {
    if (!CAN_LOG_DELETE) return;
    if (!confirm('Supprimer définitivement tous les logs DMD-Proxmox ?')) return;
    try {
      const response = await fetch(DMD_PROXMOX_LOGS_URL, {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({csrf:CSRF_DMD_PROXMOX, action:'clear'})
      });
      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload || !payload.ok) throw new Error(payload && payload.message ? payload.message : `HTTP ${response.status}`);
      renderTaskLogs([]);
      toast(`✅ ${Number(payload.removed || 0)} log(s) supprimé(s)`);
    } catch (error) {
      toast('❌ ' + error.message);
    }
  }

  function clampPct(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, Math.min(100, n));
  }

  function openManagement(serverId, serverName, initial='snapshots', selectedVm=null) {
    const old=Array.from(document.querySelectorAll('[data-prox-management]')).find(w=>w.dataset.server===serverId);if(old){old.remove();recomputeDesktopBounds();}
    const win=document.createElement('section');win.className='dmd-proxmox-vm-window dmd-proxmox-backup-window';win.dataset.proxManagement='1';win.dataset.server=serverId;
    win.innerHTML=`<header class="dmd-proxmox-modal-head"><div><span class="dmd-proxmox-modal-kicker">Administration Proxmox</span><h3 data-title></h3></div><button class="dmd-proxmox-modal-close" type="button">×</button></header><div class="dmd-proxmox-modal-body"><div class="pb-grid"><label>Nœud<select data-node></select></label><label data-vm-label>VM / CT<select data-vm></select></label></div><div class="pb-tabs" data-tabs></div><p data-msg role="status"></p><div data-tools></div><div data-results></div></div><div class="dmd-proxmox-vm-resize"></div>`;
    const q=s=>win.querySelector(s),node=q('[data-node]'),vm=q('[data-vm]'),tools=q('[data-tools]'),results=q('[data-results]'),msg=q('[data-msg]');q('[data-title]').textContent=serverName;
    win.style.left=(window.scrollX+Math.max(8,(window.innerWidth-Math.min(620,window.innerWidth-16))/2))+'px';win.style.top=(window.scrollY+48)+'px';document.body.appendChild(win);bringToFront(win);installSimpleWindowDrag(win,q('header'),q('.dmd-proxmox-vm-resize'));q('.dmd-proxmox-modal-close').onclick=()=>{win.remove();recomputeDesktopBounds();};
    let context={},tab=initial,busy=false;
    const tabs={snapshots:'Snapshots',migration:'Migration',storage:'Stockage',replication:'Réplication',maintenance:'Maintenance',history:'Supervision serveur',vmhistory:'Supervision VM/CT',alerts:'Alertes',clone:'Clonage',pbs:'PBS',schedule:'Planification'};
    async function api(action,extra={}){const r=await fetch(DMD_PROXMOX_BASE_URL+'/DMD-Proxmox_manage.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({csrf:CSRF_DMD_PROXMOX,server_id:serverId,node:node.value,vmid:vm.value,action,...extra})});const j=await r.json();if(!r.ok||!j.ok)throw Error(j.message||'Erreur Proxmox');return j.data;}
    function opts(el,rows,key,label){el.replaceChildren();for(const r of rows||[]){const o=document.createElement('option');o.value=r[key];o.textContent=label(r);el.append(o);}}
    function button(parent,label,fn){const b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=()=>run(fn);parent.append(b);return b;}
    async function run(fn){if(busy)return;busy=true;msg.textContent='Chargement…';try{await fn();msg.textContent='';}catch(e){msg.textContent=e.message;}finally{busy=false;}}
    function field(label,choices=null,type='text',value=''){const l=document.createElement('label');l.textContent=label;const e=document.createElement(choices?'select':'input');if(choices)opts(e,choices,'value',r=>r.label);else{e.type=type;e.value=value;}l.append(e);tools.append(l);return e;}
    function confirmValue(){return new Promise(resolve=>{const panel=document.createElement('div');panel.className='pb-grid';const label=document.createElement('label');label.textContent='Saisir Confirmer pour valider cette opération.';const input=document.createElement('input');input.autocomplete='off';label.append(input);panel.append(label);const yes=document.createElement('button'),no=document.createElement('button');yes.textContent='Confirmer';yes.disabled=true;no.textContent='Annuler';input.oninput=()=>yes.disabled=input.value!=='Confirmer';function done(v){panel.remove();resolve(v);}yes.onclick=()=>done(input.value);no.onclick=()=>done('');panel.append(yes,no);tools.append(panel);input.focus();});}
    async function mutate(a,d={}){const c=await confirmValue();if(c!=='Confirmer')return;const r=await api(a,{...d,confirm:c});if(typeof r==='string'&&r.startsWith('UPID:')){results.textContent='Tâche acceptée : '+r;return;}await render();}
    function rows(data,columns,actions){results.replaceChildren();if(!Array.isArray(data)||!data.length){results.textContent='Aucun résultat.';return;}const t=document.createElement('table');t.style.width='100%';const h=t.createTHead().insertRow();for(const [label] of columns){const th=document.createElement('th');th.textContent=label;h.append(th);}if(actions)h.append(document.createElement('th'));const body=t.createTBody();for(const r of data){const tr=body.insertRow();for(const [,key] of columns){const td=tr.insertCell();td.textContent=typeof key==='function'?key(r):String(r[key]??'—');}if(actions)actions(tr.insertCell(),r);}results.append(t);}
    const bytes=n=>n==null?'—':(Number(n)/1073741824).toFixed(2)+' Gio';const targets=()=>context.nodes.filter(n=>n.node!==node.value&&n.status==='online').map(n=>({value:n.node,label:n.node}));
    function refreshVM(){opts(vm,(context.vms||[]).filter(v=>v.node===node.value&&['qemu','lxc'].includes(v.type)),'vmid',v=>v.vmid+' · '+(v.name||v.type));}
    async function render(){tools.replaceChildren();results.replaceChildren();q('[data-vm-label]').hidden=!['snapshots','migration','clone','vmhistory'].includes(tab);for(const b of q('[data-tabs]').children)b.setAttribute('aria-pressed',String(b.dataset.tab===tab));
      if(!node.value)throw Error('Aucun nœud disponible.');
      if(tab==='snapshots'){if(!vm.value)return;const sn=field('Nom du snapshot'),desc=field('Description');button(tools,'Créer',async()=>{await api('snapshot_create',{snapshot:sn.value,description:desc.value});await render();});rows(await api('snapshots'),[['Nom','name'],['Description','description']],(c,r)=>{if(r.name==='current')return;button(c,'Restaurer',()=>mutate('snapshot_restore',{snapshot:r.name}));button(c,'Supprimer',()=>mutate('snapshot_delete',{snapshot:r.name}));});}
      if(tab==='migration'){const target=field('Nœud destination',targets()),online=field('Migration QEMU',[{value:'0',label:'Hors ligne'},{value:'1',label:'En ligne'}]);button(tools,'Migrer',()=>mutate('migrate',{target:target.value,online:online.value==='1'}));results.textContent='Migration dans le même cluster. Les conteneurs doivent être arrêtés.';}
      if(tab==='clone'){const id=field('Nouveau VMID',null,'number'),name=field('Nom');button(tools,'Cloner',()=>mutate('clone',{newid:id.value,name:name.value}));button(tools,'Convertir en template',()=>mutate('template'));}
      if(tab==='storage'||tab==='pbs'){const list=await api(tab);rows(list,[['Stockage','storage'],['Type','type'],['Utilisé',r=>bytes(r.used)],['Disponible',r=>bytes(r.avail)]],(c,r)=>button(c,'Contenu',async()=>{const data=await api('content',{storage:r.storage});rows(data,[['Volume','volid'],['Type','content'],['Taille',x=>bytes(x.size)]],(cell,v)=>{if(v.content==='iso')button(cell,'Supprimer',()=>mutate('volume_delete',{storage:r.storage,volume:v.volid}));});}));if(tab==='storage')button(tools,'Disques physiques',async()=>rows(await api('disks'),[['Disque','devpath'],['Modèle','model'],['Taille',r=>bytes(r.size)],['Santé','health']]));}
      if(tab==='replication'){const job=field('ID (VMID-numéro)'),target=field('Destination',targets()),schedule=field('Horaire',null,'text','*/15'),disabled=field('État',[{value:'0',label:'Actif'},{value:'1',label:'Désactivé'}]);let existing=false;button(tools,'Enregistrer',()=>mutate('replication_save',{job:job.value,target:target.value,schedule:schedule.value,disabled:disabled.value==='1',existing}));rows(await api('replication'),[['ID','id'],['Destination','target'],['Horaire','schedule']],(c,r)=>{button(c,'Modifier',async()=>{job.value=r.id;target.value=r.target;schedule.value=r.schedule||'*/15';disabled.value=r.disable?'1':'0';existing=true;});button(c,'Supprimer',()=>mutate('replication_delete',{job:r.id}));});}
      if(tab==='maintenance'){button(tools,'Redémarrer',()=>mutate('reboot'));button(tools,'Arrêter',()=>mutate('shutdown'));button(tools,'Actualiser les paquets',()=>mutate('refresh_updates'));button(tools,'Mises à jour disponibles',async()=>rows(await api('updates'),[['Paquet','Package'],['Installé','OldVersion'],['Disponible','Version']]));}
      if(tab==='history'||tab==='vmhistory'){const tf=field('Période',['hour','day','week','month','year'].map((v,i)=>({value:v,label:['Heure','Jour','Semaine','Mois','Année'][i]})));const show=async()=>rows(await api(tab,{timeframe:tf.value}),[['Date',r=>new Date(r.time*1000).toLocaleString('fr-FR')],['CPU',r=>r.cpu==null?'—':(r.cpu*100).toFixed(1)+' %'],['RAM',r=>bytes(r.memused??r.mem)],['Stockage',r=>bytes(r.rootused??r.disk)],['Entrée/s',r=>bytes(r.netin)],['Sortie/s',r=>bytes(r.netout)]]);button(tools,'Afficher',show);await show();}
      if(tab==='alerts')rows(await api('alerts'),[['Incident','message']]);
      if(tab==='schedule'){const job=field('ID tâche (vide = nouvelle)'),schedule=field('Horaire Proxmox',null,'text','daily'),store=field('Stockage', (await api('storage')).filter(s=>String(s.content||'').includes('backup')).map(s=>({value:s.storage,label:s.storage}))),ids=field('VMID séparés par des virgules'),enabled=field('État',[{value:'1',label:'Actif'},{value:'0',label:'Inactif'}]);button(tools,'Enregistrer',()=>mutate('schedule_save',{job:job.value,schedule:schedule.value,storage:store.value,vmids:ids.value,enabled:enabled.value}));rows(await api('schedule'),[['ID','id'],['Horaire','schedule'],['VMID','vmid'],['Stockage','storage']],(c,r)=>{button(c,'Modifier',async()=>{job.value=r.id;schedule.value=r.schedule;store.value=r.storage;ids.value=r.vmid||'';enabled.value=r.enabled===0?'0':'1';});button(c,'Supprimer',()=>mutate('schedule_delete',{job:r.id}));});}
    }
    for(const [key,label] of Object.entries(tabs)){const b=button(q('[data-tabs]'),label,async()=>{tab=key;await render();});b.dataset.tab=key;}
    node.onchange=()=>run(async()=>{refreshVM();await render();});vm.onchange=()=>run(render);run(async()=>{context=await api('context');opts(node,context.nodes,'node',n=>n.node);if(node.options.length===1){const label=node.parentElement;node.style.display='none';label.append(document.createTextNode(' : '+node.value));}if(selectedVm && Array.from(node.options).some(o=>o.value===selectedVm.real_node))node.value=selectedVm.real_node;refreshVM();if(selectedVm){if(node.value!==selectedVm.real_node||!Array.from(vm.options).some(o=>o.value===String(selectedVm.vmid)))throw Error('VM / CT introuvable sur son nœud.');vm.value=String(selectedVm.vmid);node.disabled=true;vm.disabled=true;}await render();});
  }
  root.addEventListener('click',e=>{const b=e.target.closest('[data-prox-manage-open]');if(!b)return;e.preventDefault();e.stopPropagation();const c=b.closest('[data-server-card]');if(c)openManagement(c.dataset.server,c.querySelector('.dmd-proxmox-server-name').textContent,b.dataset.proxManageOpen||'snapshots');});

  function openBackupWindow(serverId, serverName) {
    const existing = Array.from(document.querySelectorAll('[data-prox-backup]')).find(w=>w.dataset.server===serverId);
    if(existing){bringToFront(existing);return;}
    const win=document.createElement('section');
    win.className='dmd-proxmox-vm-window dmd-proxmox-backup-window'; win.dataset.proxBackup='1'; win.dataset.server=serverId;
    win.setAttribute('role','dialog'); win.setAttribute('aria-label','Sauvegardes Proxmox');
    win.innerHTML=`<header class="dmd-proxmox-modal-head"><div><span class="dmd-proxmox-modal-kicker">Sauvegardes · Administration</span><h3 data-b-title></h3></div><button type="button" class="dmd-proxmox-modal-close">×</button></header>
    <div class="dmd-proxmox-modal-body"><div class="pb-grid"><label>Node<select data-b-node></select></label><label>Stockage des sauvegardes<select data-b-store></select></label></div>
    <div class="pb-tabs"><button data-b-tab="list">Sauvegardes</button><button data-b-tab="create">Créer</button><button data-b-tab="task">Tâche</button><?php if(dmd_proxmox_is_admin()): ?><button data-b-plan>Planification</button><?php endif; ?><button data-b-refresh>Actualiser</button></div>
    <p data-b-msg role="status"></p>
    <section data-b-panel="list"><div data-b-list></div><form data-b-restore hidden><h4>Restaurer une sauvegarde</h4><p data-b-selected></p><div class="pb-grid"><label>VMID libre<input name="vmid" type="number" min="100" max="999999999" required></label><label>Stockage de destination<select name="destination" required></select></label></div><p>Restauration vers un nouvel ID, sans écraser une machine existante.</p><button type="submit">Restaurer</button> <button type="button" data-b-cancel>Annuler</button></form></section>
    <section data-b-panel="create" hidden><form data-b-create><div class="pb-grid"><label>Machine virtuelle / conteneur<select name="vmid" required></select></label><label>Mode<select name="mode"><option value="snapshot">Snapshot</option><option value="suspend">Suspendre</option><option value="stop">Arrêter</option></select></label><label>Compression<select name="compress"><option value="zstd">ZSTD</option><option value="lzo">LZO</option><option value="gzip">GZIP</option><option value="0">Aucune</option></select></label></div><button type="submit">Lancer la sauvegarde</button></form></section>
    <section data-b-panel="task" hidden><p data-b-status>Aucune tâche lancée depuis cette fenêtre.</p><pre data-b-log></pre><button data-b-check>Actualiser la tâche</button></section></div><div class="dmd-proxmox-vm-resize" data-b-grip></div>`;
    const rights = <?= json_encode(array_combine(array('view','create','restore','delete'), array_map(function($a){return dmd_proxmox_backup_can('backup.'.$a);},array('view','create','restore','delete')))) ?>;
    const q=s=>win.querySelector(s), node=q('[data-b-node]'), store=q('[data-b-store]'), msg=q('[data-b-msg]'), restore=q('[data-b-restore]'), create=q('[data-b-create]');
    q('[data-b-title]').textContent=serverName;
    win.style.left=(window.scrollX+Math.max(8,(window.innerWidth-Math.min(620,window.innerWidth-16))/2))+'px'; win.style.top=(window.scrollY+48)+'px';
    document.body.appendChild(win); bringToFront(win); installSimpleWindowDrag(win,q('header'),q('[data-b-grip]'));
    let context={}, selected=null, task=null, busy=false, timer=null;
    function tab(name){win.querySelectorAll('[data-b-panel]').forEach(p=>p.hidden=p.dataset.bPanel!==name);win.querySelectorAll('[data-b-tab]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.bTab===name)));}
    function options(el, rows, key, label){el.replaceChildren();for(const r of rows||[]){const o=document.createElement('option');o.value=r[key];o.textContent=label(r);el.append(o);}}
    async function api(action, extra={}){const response=await fetch(DMD_PROXMOX_BASE_URL+'/DMD-Proxmox_backup.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({csrf:CSRF_DMD_PROXMOX,server_id:serverId,node:node.value,storage:store.value,action,...extra})});const r=await response.json();if(!response.ok||!r.ok)throw new Error(r.message||'Erreur Proxmox');return r.data;}
    async function run(fn){if(busy)return;busy=true;win.setAttribute('aria-busy','true');win.querySelectorAll('button,select,input').forEach(e=>{if(!e.matches('.dmd-proxmox-modal-close'))e.disabled=true;});msg.textContent='Chargement…';try{await fn();msg.textContent='';}catch(e){msg.textContent=e.message;}finally{busy=false;win.removeAttribute('aria-busy');win.querySelectorAll('button,select,input').forEach(e=>e.disabled=false);}}
    function clearSelection(){selected=null;restore.hidden=true;}
    async function list(){clearSelection();if(!rights.view && !rights.restore && !rights.delete)return;const box=q('[data-b-list]');box.replaceChildren();if(!store.value){box.textContent='Aucun stockage de sauvegarde disponible.';return;}const rows=await api('list');if(!rows.length){box.textContent='Aucune sauvegarde.';return;}rows.sort((a,b)=>(b.ctime||0)-(a.ctime||0));for(const r of rows){const line=document.createElement('div');line.className='pb-row';const info=document.createElement('div'), title=document.createElement('strong'), sub=document.createElement('small');title.textContent=r.volid;sub.textContent=(r.ctime?new Date(r.ctime*1000).toLocaleString('fr-FR'):'Date inconnue')+' · '+(Number(r.size||0)/1073741824).toFixed(2)+' Gio'+(r.protected?' · Protégée':'');info.append(title,sub);const rb=document.createElement('button');rb.textContent='Restaurer';rb.hidden=!r.can_restore;rb.onclick=()=>{selected=r;restore.hidden=false;q('[data-b-selected]').textContent=r.volid;restore.elements.vmid.value=context.nextid||'';const ct=(r.subtype==='lxc'||r.subtype==='ct')||/vzdump-lxc-|\/ct\//.test(r.volid);options(restore.elements.destination,ct?context.rootdir:context.images,'storage',s=>s.storage);restore.scrollIntoView({block:'nearest'});};const db=document.createElement('button');db.textContent='Supprimer';db.hidden=!!r.protected||!r.can_delete;db.onclick=()=>{if(confirm('Supprimer définitivement '+r.volid+' ?'))run(async()=>{await launch('delete',{volume:r.volid,confirm:true});});};line.append(info,rb,db);box.append(line);}}
    async function load(){clearSelection();store.replaceChildren();q('[data-b-list]').replaceChildren();create.elements.vmid.replaceChildren();if(!node.value)return;context=await api('context');options(store,context.stores,'storage',s=>s.storage);options(create.elements.vmid,context.vms,'vmid',v=>v.vmid+' — '+(v.name||v.type));await list();}
    async function check(){if(!task)return;const r=await api('task',task);q('[data-b-status]').textContent=r.status.status==='stopped'?'Terminée : '+(r.status.exitstatus||'état inconnu'):'En cours';q('[data-b-log]').textContent=(r.log||[]).map(l=>l.t).join('\n');if(r.status.status==='stopped'){clearInterval(timer);timer=null;}}
    async function launch(action, extra){const r=await api(action,extra);if(typeof r.upid==='string'&&r.upid.startsWith('UPID:')){task={upid:r.upid,node:r.node};tab('task');clearInterval(timer);timer=setInterval(()=>{if(!win.isConnected){clearInterval(timer);return;}if(!busy)run(check);},5000);await check();}else{await list();tab('list');}}
    q('.dmd-proxmox-modal-close').onclick=()=>{clearInterval(timer);win.remove();recomputeDesktopBounds();};
    win.querySelectorAll('[data-b-tab]').forEach(b=>b.onclick=()=>tab(b.dataset.bTab));node.onchange=()=>run(load);store.onchange=()=>run(list);q('[data-b-refresh]').onclick=()=>run(list);q('[data-b-check]').onclick=()=>run(check);q('[data-b-cancel]').onclick=clearSelection;
    create.onsubmit=e=>{e.preventDefault();if(!store.value)return;const data=Object.fromEntries(new FormData(create));if(data.mode!=='snapshot'&&!confirm('Ce mode peut interrompre la machine. Continuer ?'))return;run(()=>launch('create',data));};
    restore.onsubmit=e=>{e.preventDefault();if(!selected)return;const data=Object.fromEntries(new FormData(restore));if(confirm('Restaurer vers le VMID '+data.vmid+' ?'))run(()=>launch('restore',{...data,volume:selected.volid,confirm:true}));};
    if(q('[data-b-plan]'))q('[data-b-plan]').onclick=()=>openManagement(serverId,serverName,'schedule');
    q('[data-b-tab="create"]').hidden=!rights.create; q('[data-b-tab="list"]').hidden=!(rights.view||rights.restore||rights.delete);tab(rights.view||rights.restore||rights.delete?'list':'create');run(async()=>{options(node,(await api('nodes')).filter(n=>n.status==='online'),'node',n=>n.node);await load();});
  }
  root.addEventListener('click',event=>{const b=event.target.closest('[data-prox-backup-open]');if(!b)return;event.preventDefault();event.stopPropagation();const c=b.closest('[data-server-card]');if(c)openBackupWindow(c.dataset.server,c.querySelector('.dmd-proxmox-server-name').textContent);});

  function setText(win, selector, value) {
    const el = win.querySelector(selector);
    if (el) el.textContent = value;
  }

  function setBar(win, selector, value) {
    const el = win.querySelector(selector);
    if (el) el.style.width = clampPct(value) + '%';
  }

  function bringToFront(win) {
    if (!win) return;
    topZ += 1;
    win.style.zIndex = String(topZ);
  }

  function updateActionState(win, vm) {
    const running = !!vm.running;

    win.querySelectorAll('[data-window-action]').forEach((button) => {
      const action = button.getAttribute('data-window-action');

      if (action === 'start') {
        button.disabled = running;
      } else if (action === 'reset' && (vm.type || 'qemu') !== 'qemu') {
        button.disabled = true;
      } else {
        button.disabled = !running;
      }
    });

    const deleteButton = win.querySelector('[data-window-delete]');
    if (deleteButton) {
      deleteButton.disabled = running || String(vm.status || '').toLowerCase() !== 'stopped';
      deleteButton.title = deleteButton.disabled
        ? 'Arrête la VM/CT avant de la supprimer'
        : 'Supprimer définitivement cette VM/CT';
    }
  }

  function syncWindowStatus(win, vm) {
    setText(win, '[data-window-status]', vm.status || '-');
    updateActionState(win, vm);
  }

  function defaultWindowPosition() {
    const offset = (vmWindowSequence % 8) * 28;
    const width = Math.min(760, Math.max(320, window.innerWidth - 32));
    const left = window.scrollX + Math.max(16, Math.round((window.innerWidth - width) / 2)) + offset;
    const top = window.scrollY + 72 + offset;
    return {left, top};
  }


  function createSelectOptions(select, items, valueKey, labelFn, emptyLabel = '') {
    if (!select) return;
    select.innerHTML = '';

    if (emptyLabel !== '') {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = emptyLabel;
      select.appendChild(opt);
    }

    (items || []).forEach((item) => {
      const opt = document.createElement('option');
      const value = typeof item === 'object' ? item[valueKey] : item;
      opt.value = value == null ? '' : String(value);
      opt.textContent = labelFn ? labelFn(item) : String(value || '');
      select.appendChild(opt);
    });
  }

  async function loadCreateMeta(win, serverId, node = '') {
    const url = new URL(DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_create.php', window.location.origin);
    url.searchParams.set('op', 'meta');
    url.searchParams.set('server_id', serverId);
    if (node) url.searchParams.set('node', node);
    url.searchParams.set('t', String(Date.now()));

    const response = await fetch(url.pathname + url.search, {
      method: 'GET',
      credentials: 'same-origin',
      cache: 'no-store'
    });
    const payload = await response.json().catch(() => null);

    if (!response.ok || !payload || !payload.ok) {
      throw new Error(payload && payload.message ? payload.message : `HTTP ${response.status}`);
    }

    const nodeSelect = win.querySelector('[data-create-node]');
    const storageSelect = win.querySelector('[data-create-storage]');
    const bridgeSelect = win.querySelector('[data-create-bridge]');
    const isoSelect = win.querySelector('[data-create-iso]');
    const vmid = win.querySelector('[data-create-vmid]');

    if (!node) {
      createSelectOptions(
        nodeSelect,
        payload.nodes || [],
        'node',
        (row) => `${row.node}${row.status ? ' · ' + row.status : ''}`
      );
      if (payload.node) nodeSelect.value = payload.node;
    }

    createSelectOptions(
      storageSelect,
      payload.storages || [],
      'id',
      (row) => row.id + (row.type ? ` · ${row.type}` : '')
    );

    createSelectOptions(
      bridgeSelect,
      payload.bridges || [],
      null,
      (value) => String(value)
    );

    createSelectOptions(
      isoSelect,
      payload.isos || [],
      'volid',
      (row) => row.volid,
      'Aucune ISO'
    );

    if (vmid && (!vmid.value || vmid.dataset.auto === '1')) {
      vmid.value = payload.next_vmid && Number(payload.next_vmid) >= 100
        ? String(payload.next_vmid)
        : '';
      vmid.dataset.auto = '1';
    }

    if (!storageSelect.value && storageSelect.options.length) storageSelect.selectedIndex = 0;
    if (!bridgeSelect.value && bridgeSelect.options.length) bridgeSelect.selectedIndex = 0;

    return payload;
  }

  function installSimpleWindowDrag(win, handle, grip) {
    if (!win) return;

    win.addEventListener('pointerdown', () => bringToFront(win));

    if (handle) {
      handle.addEventListener('pointerdown', (event) => {
        if (event.target.closest('button, a, input, select, textarea')) return;

        bringToFront(win);
        const rect = win.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;
        const startLeft = rect.left + window.scrollX;
        const startTop = rect.top + window.scrollY;

        event.preventDefault();

        const move = (e) => {
          win.style.left = Math.max(0, startLeft + e.clientX - startX) + 'px';
          win.style.top = Math.max(0, startTop + e.clientY - startY) + 'px';
        };
        const end = () => {
          window.removeEventListener('pointermove', move);
          window.removeEventListener('pointerup', end);
          window.removeEventListener('pointercancel', end);
        };

        window.addEventListener('pointermove', move);
        window.addEventListener('pointerup', end);
        window.addEventListener('pointercancel', end);
      });
    }

    if (grip) {
      grip.addEventListener('pointerdown', (event) => {
        bringToFront(win);
        const rect = win.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;
        const startWidth = rect.width;
        const startHeight = rect.height;

        event.preventDefault();
        event.stopPropagation();

        const move = (e) => {
          win.style.width = Math.max(360, startWidth + e.clientX - startX) + 'px';
          win.style.height = Math.max(360, startHeight + e.clientY - startY) + 'px';
          win.style.maxHeight = 'none';
        };
        const end = () => {
          window.removeEventListener('pointermove', move);
          window.removeEventListener('pointerup', end);
          window.removeEventListener('pointercancel', end);
        };

        window.addEventListener('pointermove', move);
        window.addEventListener('pointerup', end);
        window.addEventListener('pointercancel', end);
      });
    }
  }

  async function openCreateVmWindow(serverId, serverName) {
    if (!CAN_CREATE || !createTemplate) return;

    const fragment = createTemplate.content.cloneNode(true);
    const win = fragment.querySelector('[data-dmd-proxmox-create-window]');
    if (!win) return;

    vmWindowSequence += 1;
    const offset = (vmWindowSequence % 8) * 26;
    const width = Math.min(720, Math.max(360, window.innerWidth - 36));

    Object.assign(win.style, {
      position: 'absolute',
      width: width + 'px',
      maxWidth: 'calc(100vw - 32px)',
      maxHeight: 'calc(100vh - 36px)',
      overflow: 'auto',
      left: (window.scrollX + Math.max(16, Math.round((window.innerWidth - width) / 2)) + offset) + 'px',
      top: (window.scrollY + 58 + offset) + 'px',
      pointerEvents: 'auto'
    });

    const serverInput = win.querySelector('[data-create-server-id]');
    const serverLabel = win.querySelector('[data-create-server-name]');
    const nodeSelect = win.querySelector('[data-create-node]');
    const vmidInput = win.querySelector('[data-create-vmid]');
    const form = win.querySelector('[data-create-form]');
    const message = win.querySelector('[data-create-message]');
    const submit = win.querySelector('[data-create-submit]');

    if (serverInput) serverInput.value = serverId;
    if (serverLabel) serverLabel.textContent = serverName || serverId;

    document.body.appendChild(win);
    bringToFront(win);

    const close = () => {
      win.remove();
      recomputeDesktopBounds();
    };

    win.querySelector('[data-create-close]')?.addEventListener('click', close);
    win.querySelector('[data-create-cancel]')?.addEventListener('click', close);

    installSimpleWindowDrag(
      win,
      win.querySelector('[data-create-drag-handle]'),
      win.querySelector('[data-create-resize]')
    );

    if (vmidInput) {
      vmidInput.addEventListener('input', () => {
        vmidInput.dataset.auto = '0';
      });
    }

    if (nodeSelect) {
      nodeSelect.addEventListener('change', async () => {
        if (message) message.textContent = 'Chargement du node…';
        try {
          await loadCreateMeta(win, serverId, nodeSelect.value);
          if (message) message.textContent = '';
        } catch (error) {
          if (message) message.textContent = '⛔ ' + error.message;
        }
      });
    }

    try {
      if (message) message.textContent = 'Chargement des ressources Proxmox…';
      await loadCreateMeta(win, serverId);
      if (message) message.textContent = '';
    } catch (error) {
      if (message) message.textContent = '⛔ ' + error.message;
    }

    if (form) {
      form.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (submit) submit.disabled = true;
        if (message) message.textContent = 'Création de la VM en cours…';

        try {
          const body = new FormData(form);
          const response = await fetch(DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_create.php', {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            body
          });
          const payload = await response.json().catch(() => null);

          if (!response.ok || !payload || !payload.ok) {
            throw new Error(payload && payload.message ? payload.message : `HTTP ${response.status}`);
          }

          if (message) message.textContent = '✅ ' + payload.message;
          toast(`✅ VM #${payload.vmid} créée`);

          await refreshServerModuleOnly(serverId).catch(() => {});
          loadTaskLogs();

          window.setTimeout(close, 600);
        } catch (error) {
          if (message) message.textContent = '⛔ ' + error.message;
          toast('❌ ' + error.message);
        } finally {
          if (submit && submit.isConnected) submit.disabled = false;
        }
      });
    }

    recomputeDesktopBounds();
  }

  async function deleteVmFromWindow(win) {
    const vm = win && win.__dmdProxmoxVm;
    if (!vm || !CAN_DELETE) return;

    if (vm.running || String(vm.status || '').toLowerCase() !== 'stopped') {
      toast('⛔ Arrête d’abord la VM/CT avant de la supprimer.');
      return;
    }

    const label = `${String(vm.type || 'qemu').toUpperCase()} #${vm.vmid} — ${vm.name || ''}`.trim();
    if (!confirm(
      `SUPPRESSION DÉFINITIVE\n\n${label}\n\nLa VM/CT doit être arrêtée. Cette action ne peut pas être annulée.\n\nConfirmer la suppression ?`
    )) return;

    const deleteButton = win.querySelector('[data-window-delete]');
    if (deleteButton) deleteButton.disabled = true;

    try {
      const response = await fetch(DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_action.php', {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          csrf: CSRF_DMD_PROXMOX,
          server_id: vm.server_id || vm.node,
          vmid: vm.vmid,
          type: vm.type || 'qemu',
          action: 'delete'
        })
      });

      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload || !payload.ok) {
        throw new Error(payload && payload.message ? payload.message : `HTTP ${response.status}`);
      }

      toast(`✅ ${label} supprimée`);
      closeVmWindow(win);
      await refreshServerModuleOnly(vm.server_id || vm.node).catch(() => {});
      loadTaskLogs();
    } catch (error) {
      toast('❌ ' + error.message);
      if (deleteButton && deleteButton.isConnected) deleteButton.disabled = false;
    }
  }

  async function loadVmDetails(win) {
    const box=win.querySelector('[data-window-details-content]'), button=win.querySelector('[data-window-details-refresh]');
    const vm=win.__dmdProxmoxVm; if(!box||!button||button.disabled)return;
    button.disabled=true; box.textContent='Chargement des informations…';
    const bytes=v=>v===null||v===undefined?'Non communiqué':(Number(v)/1073741824).toLocaleString('fr-FR',{maximumFractionDigits:2})+' Gio';
    const val=v=>v===null||v===undefined||v===''?'—':String(v);
    function group(title, rows) {
      const block=document.createElement('div');block.className='dmd-proxmox-detail-group';
      const heading=document.createElement('strong');heading.textContent=title;block.append(heading);
      for(const [label,value] of rows){const line=document.createElement('div');line.className='dmd-proxmox-detail-line';const l=document.createElement('span'),v=document.createElement('span');l.textContent=label;v.textContent=val(value);line.append(l,v);block.append(line);}
      box.append(block);
    }
    try {
      const r=await fetch(DMD_PROXMOX_BASE_URL+'/DMD-Proxmox_action.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({csrf:CSRF_DMD_PROXMOX,server_id:vm.server_id||vm.node,vmid:vm.vmid,type:vm.type,action:'details'})});
      const j=await r.json();if(!r.ok||!j.ok)throw Error(j.message||'Informations indisponibles');const d=j.data;
      box.replaceChildren();group('Matériel et démarrage',Object.entries(d.hardware));
      for(const disk of d.disks)group(disk.slot+' · '+disk.role,[['Volume / stockage',disk.volume],['Capacité provisionnée',disk.size||'Non communiquée'],['Occupation interne', 'Voir systèmes de fichiers invités ci-dessous (si disponibles)']]);
      if(!d.disks.length)group('Disques',[['Information','Aucun disque communiqué']]);
      if(!d.net.length)group('Réseau configuré',[['MAC','Aucune interface configurée communiquée'],['IP','Non communiquée']]);
      for(const n of d.net)group('Réseau · '+n.slot,[['MAC',n.mac],['Bridge',n.bridge],['Modèle',n.model],['VLAN',n.vlan],['IP configurée',n.ip]]);
      for(const n of d.interfaces)group('Interface invitée · '+n.name,[['MAC',n.mac],['IP réelle',n.ips.join(' / ')||'Non communiquée']]);
      if(!d.interfaces.length)group('Réseau invité',[['IP réelle','Non disponible']]);
      if(!d.fs.length)group('Occupation interne',[['Utilisé / Disponible','Non disponible']]);
      for(const f of d.fs)group('Système de fichiers · '+(f.mount||f.name),[['Type',f.type],['Disques associés', (f.devices||[]).join(' / ')||'Non communiqué'],['Capacité',bytes(f.total)],['Utilisé',bytes(f.used)],['Disponible',f.total!=null&&f.used!=null?bytes(Math.max(0,f.total-f.used)):'Non communiqué']]);
      for(const note of d.notes){const line=document.createElement('p');line.textContent=note;box.append(line);}
    } catch(e){box.textContent=e.message||'Informations indisponibles';} finally{button.disabled=false;}
  }

  function openVmWindow(vm) {
    if (!vmTemplate) {
      toast('❌ Gabarit de fenêtre VM introuvable');
      return;
    }

    vmWindowSequence += 1;
    const fragment = vmTemplate.content.cloneNode(true);
    const win = fragment.querySelector('[data-dmd-proxmox-vm-window]');
    if (!win) return;

    win.__dmdProxmoxVm = Object.assign({}, vm);
    win.style.position = 'absolute';
    win.style.boxSizing = 'border-box';
    win.style.width = Math.min(760, Math.max(320, window.innerWidth - 32)) + 'px';
    win.style.maxWidth = 'calc(100vw - 32px)';
    win.style.maxHeight = 'calc(100vh - 36px)';
    win.style.overflow = 'auto';
    win.style.pointerEvents = 'auto';

    setText(win, '[data-dmd-proxmox-window-title]', `#${vm.vmid} — ${vm.name}`);
    setText(win, '[data-window-server]', vm.server || '-');
    setText(win, '[data-window-real-node]', vm.real_node || '-');
    setText(win, '[data-window-type]', vm.type || 'qemu');
    setText(win, '[data-window-status]', vm.status || '-');
    setText(win, '[data-window-cpu]', `${vm.cpu || 0}%`);
    setText(win, '[data-window-ram]', `${vm.ram_used || 0} / ${vm.ram_total || 0} Mo`);
    setText(win, '[data-window-disk]', `${vm.disk_used || 0} / ${vm.disk_total || 0} Go`);

    setBar(win, '[data-window-cpu-bar]', vm.cpu || 0);
    setBar(win, '[data-window-ram-bar]', vm.ram_pct || 0);
    setBar(win, '[data-window-disk-bar]', vm.disk_pct || 0);
    updateActionState(win, win.__dmdProxmoxVm);

    const pos = defaultWindowPosition();
    win.style.left = pos.left + 'px';
    win.style.top = pos.top + 'px';

    document.body.appendChild(win);
    bringToFront(win);
    installVmWindowInteractions(win);
    win.querySelector('[data-window-details-refresh]').addEventListener('click',()=>loadVmDetails(win));
    win.querySelectorAll('[data-vm-manage]').forEach(b=>b.addEventListener('click',()=>openManagement(vm.server_id||vm.node,vm.server||vm.node,b.dataset.vmManage,vm)));
    loadVmDetails(win);
    recomputeDesktopBounds();
  }

  function closeVmWindow(win) {
    if (!win) return;
    win.remove();
    recomputeDesktopBounds();
  }

  function installVmWindowInteractions(win) {
    const bar = win.querySelector('[data-dmd-proxmox-drag-handle]');
    const grip = win.querySelector('[data-dmd-proxmox-resize]');
    const closeButton = win.querySelector('[data-dmd-proxmox-window-close]');

    win.addEventListener('pointerdown', () => bringToFront(win));

    if (closeButton) {
      closeButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        closeVmWindow(win);
      });
    }

    win.addEventListener('click', (event) => {
      const actionButton = event.target.closest('[data-window-action]');
      if (actionButton && !actionButton.disabled) {
        runVmAction(win, actionButton.getAttribute('data-window-action'));
        return;
      }

      const filesButton = event.target.closest('[data-window-files]');
      if (filesButton && win.__dmdProxmoxVm) {
        event.preventDefault();
        event.stopPropagation();
        toast('⏳ Ouverture des fichiers réseau…');
        Promise.resolve(openNetworkBrowser(win.__dmdProxmoxVm)).catch((error) => {
          console.error('[DMD-Proxmox] Fichiers réseau', error);
          toast('❌ Fichiers réseau : ' + (error && error.message ? error.message : 'erreur inconnue'));
        });
        return;
      }

      const remoteButton = event.target.closest('[data-window-remote]');
      if (remoteButton && win.__dmdProxmoxVm) {
        openConsole(win.__dmdProxmoxVm);
        return;
      }

      const deleteButton = event.target.closest('[data-window-delete]');
      if (deleteButton && !deleteButton.disabled && win.__dmdProxmoxVm) {
        event.preventDefault();
        event.stopPropagation();
        deleteVmFromWindow(win);
      }
    });

    if (bar) {
      bar.addEventListener('pointerdown', (event) => {
        if (event.target.closest('button, a, input, select, textarea')) return;

        bringToFront(win);
        const r = win.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;
        const startLeft = r.left + window.scrollX;
        const startTop = r.top + window.scrollY;

        bar.setPointerCapture?.(event.pointerId);
        win.classList.add('is-dragging');
        event.preventDefault();

        const onMove = (moveEvent) => {
          const nextLeft = Math.max(0, startLeft + moveEvent.clientX - startX);
          const nextTop = Math.max(0, startTop + moveEvent.clientY - startY);
          win.style.left = nextLeft + 'px';
          win.style.top = nextTop + 'px';
          recomputeDesktopBounds();
        };

        const onEnd = () => {
          win.classList.remove('is-dragging');
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', onEnd);
          window.removeEventListener('pointercancel', onEnd);
          recomputeDesktopBounds();
        };

        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', onEnd);
        window.addEventListener('pointercancel', onEnd);
      });
    }

    if (grip) {
      grip.addEventListener('pointerdown', (event) => {
        bringToFront(win);
        const r = win.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;
        const startWidth = r.width;
        const startHeight = r.height;
        const minWidth = Math.min(420, Math.max(280, window.innerWidth - 20));
        const minHeight = 270;

        grip.setPointerCapture?.(event.pointerId);
        win.classList.add('is-resizing');
        event.preventDefault();
        event.stopPropagation();

        const onMove = (moveEvent) => {
          win.style.width = Math.max(minWidth, startWidth + moveEvent.clientX - startX) + 'px';
          win.style.height = Math.max(minHeight, startHeight + moveEvent.clientY - startY) + 'px';
          win.style.maxHeight = 'none';
          recomputeDesktopBounds();
        };

        const onEnd = () => {
          win.classList.remove('is-resizing');
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', onEnd);
          window.removeEventListener('pointercancel', onEnd);
          recomputeDesktopBounds();
        };

        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', onEnd);
        window.addEventListener('pointercancel', onEnd);
      });
    }
  }

  async function runVmAction(win, action) {
    const vm = win && win.__dmdProxmoxVm;
    if (!vm) return;

    if (['stop', 'reset'].includes(action)) {
      if (!confirm(`Confirmer ${action.toUpperCase()} sur la VM #${vm.vmid} ?`)) {
        return;
      }
    }

    const buttons = Array.from(win.querySelectorAll('[data-window-action]'));
    buttons.forEach((button) => button.disabled = true);

    try {
      const response = await fetch(DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_action.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          csrf: CSRF_DMD_PROXMOX,
          server_id: vm.server_id || vm.node,
          vmid: vm.vmid,
          type: vm.type || 'qemu',
          action
        })
      });

      const payload = await response.json().catch(() => null);

      if (!response.ok || !payload || !payload.ok) {
        throw new Error((payload && (payload.message || payload.error)) ? (payload.message || payload.error) : `HTTP ${response.status}`);
      }

      if (action === 'start') {
        vm.running = true;
        vm.status = 'running';
      } else if (action === 'stop' || action === 'shutdown') {
        vm.running = false;
        vm.status = 'stopped';
      }

      syncWindowStatus(win, vm);
      toast(`✅ ${action} lancé sur VM #${vm.vmid}`);
      loadTaskLogs();
      fetch(DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_fetch.php?csrf=' + encodeURIComponent(CSRF_DMD_PROXMOX) + '&t=' + Date.now(), {cache:'no-store'})
        .catch(() => {});
    } catch (error) {
      toast(`❌ ${error.message}`);
      updateActionState(win, vm);
      loadTaskLogs();
    }
  }

  function defaultConsolePosition() {
    const existing = document.querySelectorAll('[data-dmd-proxmox-console-window]').length;
    const stepX = 72;
    const stepY = 58;
    const slot = existing % 6;
    const width = Math.min(860, Math.max(560, window.innerWidth - 80));
    const baseLeft = window.scrollX + Math.max(16, Math.round((window.innerWidth - width) / 2));
    const baseTop = window.scrollY + 54;
    return {
      left: Math.max(8, baseLeft + (slot * stepX)),
      top: Math.max(8, baseTop + (slot * stepY))
    };
  }


  function buildRemoteUrl(vm, instanceId, restartNonce = '') {
    const remoteUrl = new URL(DMD_PROXMOX_BASE_URL + '/DMD-Proxmox_console.php', window.location.origin);
    remoteUrl.searchParams.set('server_id', vm.server_id || vm.node);
    remoteUrl.searchParams.set('vmid', String(vm.vmid));
    remoteUrl.searchParams.set('type', vm.type || 'qemu');
    remoteUrl.searchParams.set('csrf', CSRF_DMD_PROXMOX);
    remoteUrl.searchParams.set('_remote_instance', instanceId);
    if (restartNonce) {
      remoteUrl.searchParams.set('_remote_restart', restartNonce);
    }
    return remoteUrl.pathname + remoteUrl.search;
  }

  function restartConsoleFrame(win, frame) {
    if (!win || !frame || !win.__dmdProxmoxVm) return;

    const vm = win.__dmdProxmoxVm;
    const restartButton = win.querySelector('[data-dmd-proxmox-console-restart]');
    const cap = win.querySelector('[data-dmd-proxmox-console-cap]');
    if (restartButton) restartButton.disabled = true;
    if (cap) cap.textContent = `Remote · VM #${vm.vmid} · relance…`;

    consoleWindowSequence += 1;
    const instanceId = `dmdpx-remote-${Date.now()}-${consoleWindowSequence}-${Math.random().toString(16).slice(2)}`;
    try {
      frame.src = 'about:blank';
    } catch (_) {}

    frame.name = instanceId;
    frame.dataset.remoteInstance = instanceId;

    const newSrc = buildRemoteUrl(vm, instanceId, String(Date.now()));
    window.setTimeout(() => {
      frame.src = newSrc;
    }, 120);

    const onLoad = () => {
      if (frame.src && frame.src !== 'about:blank') {
        if (cap) cap.textContent = `Remote · VM #${vm.vmid} (${vm.server})`;
        if (restartButton) restartButton.disabled = false;
        frame.removeEventListener('load', onLoad);
      }
    };
    frame.addEventListener('load', onLoad);
    window.setTimeout(() => {
      if (restartButton) restartButton.disabled = false;
      if (cap && cap.textContent.includes('relance…')) {
        cap.textContent = `Remote · VM #${vm.vmid} (${vm.server})`;
      }
    }, 5000);

    toast(`↻ Remote VM #${vm.vmid} relancé`);
  }

  function installConsoleWindowInteractions(win, frame) {
    if (!win || !frame) return;

    const closeButton = win.querySelector('.close');
    const restartButton = win.querySelector('[data-dmd-proxmox-console-restart]');
    const bar = win.querySelector('.title');
    const grip = win.querySelector('.grip');

    win.addEventListener('pointerdown', () => bringToFront(win));

    if (restartButton) {
      restartButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        bringToFront(win);
        restartConsoleFrame(win, frame);
      });
    }

    if (closeButton) {
      closeButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        frame.src = 'about:blank';
        win.remove();
        recomputeDesktopBounds();
      });
    }

    if (bar) {
      bar.addEventListener('pointerdown', (event) => {
        if (event.target.closest('button, a, input, select, textarea')) return;

        const r = win.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;
        const startLeft = r.left + window.scrollX;
        const startTop = r.top + window.scrollY;

        bringToFront(win);
        bar.setPointerCapture?.(event.pointerId);
        event.preventDefault();

        const onMove = (moveEvent) => {
          win.style.left = Math.max(0, startLeft + moveEvent.clientX - startX) + 'px';
          win.style.top = Math.max(0, startTop + moveEvent.clientY - startY) + 'px';
          recomputeDesktopBounds();
        };

        const onEnd = () => {
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', onEnd);
          window.removeEventListener('pointercancel', onEnd);
          recomputeDesktopBounds();
        };

        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', onEnd);
        window.addEventListener('pointercancel', onEnd);
      });
    }

    if (grip) {
      grip.addEventListener('pointerdown', (event) => {
        const r = win.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;
        const startWidth = r.width;
        const startHeight = r.height;

        bringToFront(win);
        grip.setPointerCapture?.(event.pointerId);
        event.preventDefault();
        event.stopPropagation();

        const onMove = (moveEvent) => {
          win.style.width = Math.max(520, startWidth + moveEvent.clientX - startX) + 'px';
          win.style.height = Math.max(320, startHeight + moveEvent.clientY - startY) + 'px';
          recomputeDesktopBounds();
        };

        const onEnd = () => {
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', onEnd);
          window.removeEventListener('pointercancel', onEnd);
          recomputeDesktopBounds();
        };

        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', onEnd);
        window.addEventListener('pointercancel', onEnd);
      });
    }
  }


  function formatFileSize(bytes) {
    const n = Number(bytes || 0);
    if (n < 1024) return n + ' o';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' Ko';
    if (n < 1024 * 1024 * 1024) return (n / (1024 * 1024)).toFixed(1) + ' Mo';
    return (n / (1024 * 1024 * 1024)).toFixed(1) + ' Go';
  }

  async function openNetworkBrowser(vm) {
    if (!CAN_FILES) { toast('⛔ Droit fichiers réseau refusé.'); return; }

    const existing = Array.from(document.querySelectorAll('[data-dmd-proxmox-files-window]')).find(
      w => w.dataset.serverId === String(vm.server_id || vm.node || '') && w.dataset.vmid === String(vm.vmid)
    );
    if (existing) { bringToFront(existing); return; }

    const win = document.createElement('section');
    win.className = 'dmd-proxmox-files-window dmd-managed-window dmd-workspace-positioned';
    win.dataset.dmdProxmoxFilesWindow = '1';
    win.dataset.serverId = String(vm.server_id || vm.node || '');
    win.dataset.vmid = String(vm.vmid || '');

    win.innerHTML = `
      <header class="dmd-proxmox-files-head" data-files-drag>
        <div>
          <span>Fichiers réseau</span>
          <strong>#${escHtml(vm.vmid)} · ${escHtml(vm.name || '')}</strong>
        </div>
        <button type="button" data-files-close aria-label="Fermer">×</button>
      </header>

      <div class="dmd-proxmox-files-msg" data-files-msg>Initialisation PC ↔ VM…</div>

      <div class="dmd-proxmox-files-panes">
        <section class="dmd-proxmox-files-pane" data-pc-pane>
          <header>
            <div>
              <strong>PC · DMD-Agent</strong>
              <small data-pc-path>Ce PC</small>
            </div>
            <div class="dmd-proxmox-files-pane-tools">
              <button type="button" data-pc-up disabled title="Remonter">↑</button>
              <button type="button" data-pc-refresh title="Actualiser">↻</button>
            </div>
          </header>

          <div class="dmd-proxmox-files-list" data-pc-list>
            <p>Connexion à DMD-Agent…</p>
          </div>

          <footer>
            <button type="button" data-pc-copy disabled>Copier la sélection → VM</button>
            <button type="button" data-pc-mkdir disabled>Nouveau dossier</button>
          </footer>
        </section>

        <section class="dmd-proxmox-files-pane" data-vm-pane>
          <header>
            <div>
              <strong>VM · réseau</strong>
              <small data-vm-path>\\VM\</small>
            </div>
            <div class="dmd-proxmox-files-pane-tools">
              <button type="button" data-vm-auth-toggle>Identifiants</button>
              <button type="button" data-vm-up disabled title="Remonter">↑</button>
              <button type="button" data-vm-refresh title="Actualiser">↻</button>
            </div>
          </header>

          <div class="dmd-proxmox-files-auth" data-vm-auth hidden>
            <input data-vm-user placeholder="Utilisateur SMB">
            <input data-vm-password type="password" placeholder="Mot de passe SMB" autocomplete="new-password">
            <input data-vm-domain placeholder="Domaine (optionnel)">
            <button type="button" data-vm-connect>Se connecter</button>
          </div>

          <div class="dmd-proxmox-vm-host-advanced" data-vm-host-advanced hidden>
            <span>Auto-détection IP impossible.</span>
            <button type="button" data-vm-host-toggle>Forcer une adresse</button>
            <div data-vm-host-manual-box hidden>
              <input data-vm-host-manual placeholder="IP ou DNS de la VM">
              <button type="button" data-vm-host-save>Mémoriser</button>
            </div>
          </div>

          <div class="dmd-proxmox-files-list" data-vm-list>
            <p>Détection de la VM…</p>
          </div>

          <footer>
            <button type="button" data-vm-copy disabled>Copier la sélection → PC</button>
            <button type="button" data-vm-mkdir disabled>Nouveau dossier</button>
          </footer>
        </section>
      </div>

      <div class="dmd-proxmox-files-grip" data-files-grip></div>`;

    win.style.position = 'absolute';
    win.style.display = 'grid';
    win.style.gridTemplateRows = 'auto auto minmax(0,1fr)';
    win.style.boxSizing = 'border-box';
    win.style.width = Math.min(1180, Math.max(760, window.innerWidth - 42)) + 'px';
    win.style.height = Math.min(760, Math.max(500, window.innerHeight - 70)) + 'px';
    win.style.minWidth = '720px';
    win.style.minHeight = '460px';
    win.style.overflow = 'hidden';
    win.style.pointerEvents = 'auto';

    const workspace = document.getElementById('dashboard');
    const workspaceHost = workspace || document.body;
    const scrollLeft = workspace ? workspace.scrollLeft : window.scrollX;
    const scrollTop = workspace ? workspace.scrollTop : window.scrollY;
    const clientWidth = workspace ? workspace.clientWidth : window.innerWidth;
    const initialWidth = parseFloat(win.style.width) || 1000;

    win.style.left = Math.max(0, scrollLeft + Math.max(16, Math.round((clientWidth - initialWidth) / 2))) + 'px';
    win.style.top = Math.max(0, scrollTop + 24) + 'px';

    workspaceHost.appendChild(win);
    bringToFront(win);
    recomputeDesktopBounds();

    const msg = (text, ok=true) => {
      const el = win.querySelector('[data-files-msg]');
      if (!el) return;
      el.textContent = text || '';
      el.dataset.ok = ok ? '1' : '0';
    };

    const pc = {
      host: '',
      hostname: '',
      version: '',
      roots: [],
      path: '',
      root: '',
      selected: new Map()
    };

    const vmState = {
      host: '',
      share: '',
      path: '',
      selected: new Map()
    };

    async function api(action, extra={}) {
      const fd = new FormData();
      fd.set('csrf', CSRF_DMD_PROXMOX);
      fd.set('action', action);
      fd.set('server_id', vm.server_id || vm.node || '');
      fd.set('vmid', String(vm.vmid));
      fd.set('type', vm.type || 'qemu');
      Object.entries(extra).forEach(([k,v]) => fd.set(k, v == null ? '' : String(v)));

      const r = await fetch(DMD_PROXMOX_FILES_URL, {
        method:'POST',
        credentials:'same-origin',
        cache:'no-store',
        body:fd
      });

      const text = await r.text();
      let data = null;
      try { data = JSON.parse(text); }
      catch (_) { throw new Error('Réponse fichiers invalide : ' + text.slice(0,180)); }

      if (!r.ok || !data.ok) {
        const e = new Error(data.message || `HTTP ${r.status}`);
        e.payload = data || {};
        throw e;
      }
      return data;
    }

    function vmCreds() {
      return {
        username: win.querySelector('[data-vm-user]').value,
        password: win.querySelector('[data-vm-password]').value,
        domain: win.querySelector('[data-vm-domain]').value
      };
    }

    function vmPayload(extra={}) {
      return Object.assign({
        host:vmState.host,
        share:vmState.share,
        path:vmState.path
      }, vmCreds(), extra);
    }

    function vmRootLabel() {
      return '\\\\' + (vmState.host || 'VM') + '\\';
    }

    function vmFullLabel() {
      let value = vmRootLabel();
      if (vmState.share) value += vmState.share + '\\';
      if (vmState.path) value += vmState.path.replace(/\//g, '\\');
      return value;
    }

    function pcLabel() {
      if (!pc.path) return pc.hostname ? `Ce PC · ${pc.hostname}` : 'Ce PC';
      return pc.path;
    }

    function showVmAuth(show=true) {
      const box = win.querySelector('[data-vm-auth]');
      if (box) box.hidden = !show;
      const b = win.querySelector('[data-vm-auth-toggle]');
      if (b) b.textContent = show ? 'Masquer' : 'Identifiants';
      if (show) win.querySelector('[data-vm-user]')?.focus();
    }

    function updateControls() {
      win.querySelector('[data-pc-path]').textContent = pcLabel();
      win.querySelector('[data-pc-up]').disabled = !pc.path;
      win.querySelector('[data-pc-mkdir]').disabled = !pc.path;
      win.querySelector('[data-pc-copy]').disabled =
        pc.selected.size === 0 || !vmState.host || !vmState.share;

      win.querySelector('[data-vm-path]').textContent = vmFullLabel();
      win.querySelector('[data-vm-up]').disabled = !vmState.share;
      win.querySelector('[data-vm-mkdir]').disabled = !vmState.share;
      win.querySelector('[data-vm-copy]').disabled =
        vmState.selected.size === 0 || !pc.path;
    }

    function renderPcRoots() {
      pc.path = '';
      pc.root = '';
      pc.selected.clear();

      const rows = Array.isArray(pc.roots) ? pc.roots : [];
      win.querySelector('[data-pc-list]').innerHTML = rows.length
        ? rows.map(root => `
            <button type="button"
                    class="dmd-proxmox-file-row is-dir"
                    data-pc-root="${escHtml(root.path || root.name || '')}">
              <span>💽 ${escHtml(root.name || root.path || 'Disque')}</span>
              <small>${escHtml(root.path || '')}</small>
            </button>`).join('')
        : '<p>Aucun disque retourné par DMD-Agent.</p>';

      updateControls();
    }

    function renderPcEntries(entries) {
      pc.selected.clear();
      const rows = Array.isArray(entries) ? entries : [];

      win.querySelector('[data-pc-list]').innerHTML = rows.length
        ? rows.map(x => `
            <div class="dmd-proxmox-file-row ${x.directory ? 'is-dir' : ''}">
              <label class="dmd-proxmox-file-select">
                <input type="checkbox"
                       data-pc-select="${escHtml(x.path || '')}"
                       data-pc-name="${escHtml(x.name || '')}"
                       data-pc-dir="${x.directory ? '1':'0'}">
              </label>
              <button type="button"
                      class="dmd-proxmox-file-open"
                      data-pc-open="${escHtml(x.path || '')}"
                      data-pc-open-dir="${x.directory ? '1':'0'}">
                <span>${x.directory ? '📁':'📄'} ${escHtml(x.name || '')}</span>
                <small>${x.directory ? 'Dossier' : formatFileSize(x.size)}</small>
              </button>
            </div>`).join('')
        : '<p>Dossier vide.</p>';

      updateControls();
    }

    async function loadPcRoots() {
      try {
        const j = await api('pc_roots');
        pc.roots = Array.isArray(j.roots) ? j.roots : [];
        renderPcRoots();
        msg(`✅ PC ${pc.hostname || pc.host} · DMD-Agent ${pc.version || ''}`, true);
      } catch (e) {
        win.querySelector('[data-pc-list]').innerHTML = `<p>${escHtml(e.message)}</p>`;
        msg('⛔ ' + e.message, false);
      }
    }

    async function loadPcPath(path) {
      if (!path) { renderPcRoots(); return; }

      try {
        const j = await api('pc_list',{pc_path:path});
        pc.path = String(j.path || path);
        if (!pc.root && /^[A-Za-z]:[\\/]?$/.test(pc.path)) pc.root = pc.path.slice(0,2) + '\\';
        renderPcEntries(j.entries || []);
        msg(`✅ PC · ${pc.path}`, true);
      } catch (e) {
        win.querySelector('[data-pc-list]').innerHTML = `<p>${escHtml(e.message)}</p>`;
        msg('⛔ ' + e.message, false);
      }
    }

    function pcParent(path) {
      path = String(path || '').replace(/\//g,'\\').replace(/\\+$/,'');
      if (!path) return '';
      if (/^[A-Za-z]:$/.test(path)) return '';
      const idx = path.lastIndexOf('\\');
      if (idx <= 2) return path.slice(0,2) + '\\';
      return path.slice(0,idx);
    }

    async function pcMkdir() {
      if (!pc.path) return;
      const name = prompt('Nom du nouveau dossier :', 'Nouveau dossier');
      if (!name) return;
      try {
        await api('pc_mkdir',{pc_path:pc.path,name});
        await loadPcPath(pc.path);
      } catch (e) {
        msg('⛔ ' + e.message, false);
      }
    }

    function renderVmShares(shares) {
      vmState.share = '';
      vmState.path = '';
      vmState.selected.clear();

      const rows = Array.isArray(shares) ? shares : [];
      win.querySelector('[data-vm-list]').innerHTML = rows.length
        ? rows.map(x => `
            <button type="button"
                    class="dmd-proxmox-file-row is-dir"
                    data-vm-share="${escHtml(x.name)}">
              <span>🗂️ ${escHtml(x.name)}</span>
              <small>${escHtml(x.comment || 'Partage réseau')}</small>
            </button>`).join('')
        : '<p>Aucun partage de fichiers visible.</p>';

      updateControls();
    }

    function renderVmEntries(entries) {
      vmState.selected.clear();
      const rows = Array.isArray(entries) ? entries : [];

      win.querySelector('[data-vm-list]').innerHTML = rows.length
        ? rows.map(x => `
            <div class="dmd-proxmox-file-row ${x.directory ? 'is-dir' : ''}">
              <label class="dmd-proxmox-file-select">
                <input type="checkbox"
                       data-vm-select="${escHtml(x.name)}"
                       data-vm-dir="${x.directory ? '1':'0'}">
              </label>
              <button type="button"
                      class="dmd-proxmox-file-open"
                      data-vm-open="${escHtml(x.name)}"
                      data-vm-open-dir="${x.directory ? '1':'0'}">
                <span>${x.directory ? '📁':'📄'} ${escHtml(x.name)}</span>
                <small>${x.directory ? 'Dossier' : formatFileSize(x.size)}</small>
              </button>
            </div>`).join('')
        : '<p>Dossier vide.</p>';

      updateControls();
    }

    async function loadVmShares() {
      if (!vmState.host) {
        win.querySelector('[data-vm-list]').innerHTML =
          '<p>Adresse VM non déterminée automatiquement. Utilise « Forcer une adresse » uniquement en dernier recours.</p>';
        updateControls();
        return;
      }

      try {
        const j = await api('shares', vmPayload({side:'vm',share:'',path:''}));
        renderVmShares(j.shares || []);
        if (vmCreds().username || vmCreds().password || vmCreds().domain) showVmAuth(false);
        msg(`✅ VM #${vm.vmid} · ${vmState.host} · racine réseau ouverte`, true);
      } catch (e) {
        const p = e.payload || {};
        if (p.auth_required) {
          showVmAuth(true);
          win.querySelector('[data-vm-list]').innerHTML = '<p>Authentification SMB requise pour cette VM.</p>';
        } else {
          win.querySelector('[data-vm-list]').innerHTML = `<p>${escHtml(e.message)}</p>`;
        }
        msg('⛔ ' + e.message, false);
      }
      updateControls();
    }

    async function loadVmDir(path=vmState.path) {
      if (!vmState.host || !vmState.share) {
        await loadVmShares();
        return;
      }

      try {
        const j = await api('list', vmPayload({side:'vm',path}));
        vmState.path = String(j.path || '');
        renderVmEntries(j.entries || []);
        msg(`✅ VM · ${vmFullLabel()}`, true);
      } catch (e) {
        if (e.payload && e.payload.auth_required) showVmAuth(true);
        win.querySelector('[data-vm-list]').innerHTML = `<p>${escHtml(e.message)}</p>`;
        msg('⛔ ' + e.message, false);
      }
      updateControls();
    }

    async function copyPcToVm() {
      if (!vmState.share || !pc.selected.size) return;
      const items = Array.from(pc.selected.values());
      const button = win.querySelector('[data-pc-copy]');
      button.disabled = true;
      msg(`⏳ Copie PC → VM · ${items.length} sélection(s)…`, true);

      try {
        const j = await api('pc_to_vm', vmPayload({
          items:JSON.stringify(items)
        }));
        const s = j.stats || {};
        msg(`✅ PC → VM terminé · ${s.files || 0} fichier(s), ${s.dirs || 0} dossier(s)`, true);
        await loadVmDir(vmState.path);
      } catch (e) {
        msg('⛔ ' + e.message, false);
      } finally {
        updateControls();
      }
    }

    async function copyVmToPc() {
      if (!pc.path || !vmState.selected.size) return;
      const items = Array.from(vmState.selected.values());
      const button = win.querySelector('[data-vm-copy]');
      button.disabled = true;
      msg(`⏳ Copie VM → PC · ${items.length} sélection(s)…`, true);

      try {
        const j = await api('vm_to_pc', vmPayload({
          pc_path:pc.path,
          items:JSON.stringify(items)
        }));
        const s = j.stats || {};
        msg(`✅ VM → PC terminé · ${s.files || 0} fichier(s), ${s.dirs || 0} dossier(s)`, true);
        await loadPcPath(pc.path);
      } catch (e) {
        msg('⛔ ' + e.message, false);
      } finally {
        updateControls();
      }
    }

    async function initialDiagnostics() {
      msg('Connexion DMD-Agent + détection VM…', true);

      const pcPromise = api('pc_status').then(j => {
        pc.host = String(j.client_host || '');
        pc.hostname = String(j.hostname || '');
        pc.version = String(j.version || '');
        pc.roots = Array.isArray(j.roots) ? j.roots : [];
        renderPcRoots();
        return true;
      }).catch(e => {
        win.querySelector('[data-pc-list]').innerHTML =
          `<p>DMD-Agent du PC non joignable : ${escHtml(e.message)}</p>`;
        msg('⛔ ' + e.message, false);
        return false;
      });

      const vmPromise = api('status').then(async j => {
        vmState.host = String(j.host || '');

        if (!j.smbclient) {
          win.querySelector('[data-vm-list]').innerHTML =
            '<p>smbclient est absent sur le serveur DoMyDesk.</p>';
          throw new Error('smbclient absent sur le serveur DoMyDesk.');
        }

        const advanced = win.querySelector('[data-vm-host-advanced]');
        if (!vmState.host) {
          advanced.hidden = false;
          win.querySelector('[data-vm-list]').innerHTML =
            '<p>IP VM non retrouvée automatiquement. « Forcer une adresse » reste disponible en secours.</p>';
          return false;
        }

        advanced.hidden = true;
        await loadVmShares();
        return true;
      }).catch(e => {
        msg('⛔ ' + e.message, false);
        return false;
      });

      const [pcOk, vmOk] = await Promise.all([pcPromise, vmPromise]);
      if (pcOk && vmOk) {
        msg(`✅ PC ${pc.hostname || pc.host} ↔ VM #${vm.vmid} ${vmState.host} prêts`, true);
      }
      updateControls();
    }

    win.querySelector('[data-pc-list]').addEventListener('click', event => {
      const root = event.target.closest('[data-pc-root]');
      if (root) {
        pc.root = root.dataset.pcRoot || '';
        loadPcPath(pc.root);
        return;
      }

      const open = event.target.closest('[data-pc-open]');
      if (!open) return;
      const path = open.dataset.pcOpen || '';
      if (open.dataset.pcOpenDir === '1') loadPcPath(path);
    });

    win.querySelector('[data-pc-list]').addEventListener('change', event => {
      const check = event.target.closest('[data-pc-select]');
      if (!check) return;

      const path = check.dataset.pcSelect || '';
      if (!path) return;

      if (check.checked) {
        pc.selected.set(path,{
          path,
          name:check.dataset.pcName || '',
          directory:check.dataset.pcDir === '1'
        });
      } else {
        pc.selected.delete(path);
      }
      updateControls();
    });

    win.querySelector('[data-pc-up]').addEventListener('click', () => {
      const parent = pcParent(pc.path);
      if (!parent) renderPcRoots();
      else loadPcPath(parent);
    });
    win.querySelector('[data-pc-refresh]').addEventListener('click', () => pc.path ? loadPcPath(pc.path) : loadPcRoots());
    win.querySelector('[data-pc-mkdir]').addEventListener('click', pcMkdir);
    win.querySelector('[data-pc-copy]').addEventListener('click', copyPcToVm);

    win.querySelector('[data-vm-auth-toggle]').addEventListener('click', () => {
      const auth = win.querySelector('[data-vm-auth]');
      showVmAuth(auth ? auth.hidden : true);
    });
    win.querySelector('[data-vm-connect]').addEventListener('click', loadVmShares);
    win.querySelector('[data-vm-refresh]').addEventListener('click', () => vmState.share ? loadVmDir(vmState.path) : loadVmShares());

    win.querySelector('[data-vm-up]').addEventListener('click', () => {
      if (!vmState.share) return;
      if (vmState.path) {
        const parts = vmState.path.split('/').filter(Boolean);
        parts.pop();
        loadVmDir(parts.join('/'));
      } else {
        loadVmShares();
      }
    });

    win.querySelector('[data-vm-mkdir]').addEventListener('click', async () => {
      if (!vmState.share) return;
      const name = prompt('Nom du nouveau dossier :', 'Nouveau dossier');
      if (!name) return;
      try {
        await api('mkdir', vmPayload({side:'vm',path:vmState.path,name}));
        await loadVmDir(vmState.path);
      } catch (e) {
        msg('⛔ ' + e.message, false);
      }
    });

    win.querySelector('[data-vm-list]').addEventListener('click', event => {
      const share = event.target.closest('[data-vm-share]');
      if (share) {
        vmState.share = share.dataset.vmShare || '';
        vmState.path = '';
        loadVmDir('');
        return;
      }

      const open = event.target.closest('[data-vm-open]');
      if (!open) return;

      const name = open.dataset.vmOpen || '';
      if (open.dataset.vmOpenDir === '1') {
        loadVmDir([vmState.path,name].filter(Boolean).join('/'));
      }
    });

    win.querySelector('[data-vm-list]').addEventListener('change', event => {
      const check = event.target.closest('[data-vm-select]');
      if (!check) return;

      const name = check.dataset.vmSelect || '';
      if (!name) return;

      if (check.checked) {
        vmState.selected.set(name,{
          name,
          directory:check.dataset.vmDir === '1'
        });
      } else {
        vmState.selected.delete(name);
      }
      updateControls();
    });

    win.querySelector('[data-vm-copy]').addEventListener('click', copyVmToPc);

    win.querySelector('[data-vm-host-toggle]').addEventListener('click', () => {
      const box = win.querySelector('[data-vm-host-manual-box]');
      box.hidden = !box.hidden;
      if (!box.hidden) win.querySelector('[data-vm-host-manual]')?.focus();
    });

    win.querySelector('[data-vm-host-save]').addEventListener('click', async () => {
      const input = win.querySelector('[data-vm-host-manual]');
      const host = String(input.value || '').trim();
      if (!host) return;

      try {
        const j = await api('save_vm_host',{host});
        vmState.host = String(j.host || host);
        win.querySelector('[data-vm-host-advanced]').hidden = true;
        await loadVmShares();
      } catch (e) {
        msg('⛔ ' + e.message, false);
      }
    });

    win.querySelector('[data-files-close]').addEventListener('click', () => {
      win.remove();
      recomputeDesktopBounds();
    });

    const drag = win.querySelector('[data-files-drag]');
    if (drag) {
      drag.addEventListener('pointerdown', event => {
        if (event.target.closest('button,input')) return;
        bringToFront(win);

        const sx = event.clientX;
        const sy = event.clientY;
        const sl = parseFloat(win.style.left) || 0;
        const st = parseFloat(win.style.top) || 0;
        event.preventDefault();

        const move = e => {
          win.style.left = Math.max(0, sl + e.clientX - sx) + 'px';
          win.style.top = Math.max(0, st + e.clientY - sy) + 'px';
          recomputeDesktopBounds();
        };
        const done = () => {
          removeEventListener('pointermove', move);
          removeEventListener('pointerup', done);
          recomputeDesktopBounds();
        };

        addEventListener('pointermove', move);
        addEventListener('pointerup', done);
      });
    }

    const grip = win.querySelector('[data-files-grip]');
    if (grip) {
      grip.addEventListener('pointerdown', event => {
        bringToFront(win);

        const r = win.getBoundingClientRect();
        const sx = event.clientX;
        const sy = event.clientY;
        const sw = r.width;
        const sh = r.height;
        event.preventDefault();
        event.stopPropagation();

        const move = e => {
          win.style.width = Math.max(720, sw + e.clientX - sx) + 'px';
          win.style.height = Math.max(460, sh + e.clientY - sy) + 'px';
          recomputeDesktopBounds();
        };
        const done = () => {
          removeEventListener('pointermove', move);
          removeEventListener('pointerup', done);
          recomputeDesktopBounds();
        };

        addEventListener('pointermove', move);
        addEventListener('pointerup', done);
      });
    }

    win.addEventListener('pointerdown', () => bringToFront(win));
    updateControls();
    initialDiagnostics();
  }

  function openConsole(vm) {
    if (!ENABLE_CONSOLE) {
      toast('ℹ️ Remote noVNC n’est pas disponible.');
      return;
    }
    if (!consoleTemplate) {
      toast('❌ Gabarit Remote introuvable.');
      return;
    }

    consoleWindowSequence += 1;

    const fragment = consoleTemplate.content.cloneNode(true);
    const win = fragment.querySelector('[data-dmd-proxmox-console-window]');
    if (!win) return;

    const cap = win.querySelector('[data-dmd-proxmox-console-cap]');
    const frame = win.querySelector('[data-dmd-proxmox-console-frame]');
    if (!frame) return;

    if (cap) {
      cap.textContent = `Remote · VM #${vm.vmid} (${vm.server})`;
    }

    win.__dmdProxmoxVm = Object.assign({}, vm);

    const instanceId = `dmdpx-remote-${Date.now()}-${consoleWindowSequence}-${Math.random().toString(16).slice(2)}`;
    win.dataset.dmdProxmoxConsoleSeq = String(consoleWindowSequence);
    win.dataset.dmdProxmoxConsoleInstance = instanceId;
    win.dataset.vmid = String(vm.vmid);
    win.dataset.serverId = String(vm.server_id || vm.node || '');
    win.setAttribute('aria-label', `Remote VM ${vm.vmid} ${vm.server || ''}`);

    frame.name = instanceId;
    frame.dataset.remoteInstance = instanceId;

    const pos = defaultConsolePosition();
    win.style.left = pos.left + 'px';
    win.style.top = pos.top + 'px';
    win.style.display = 'block';

    frame.src = buildRemoteUrl(vm, instanceId);

    document.body.appendChild(win);
    bringToFront(win);
    installConsoleWindowInteractions(win, frame);
    recomputeDesktopBounds();
  }

  root.addEventListener('click', (event) => {
    const refreshLogs = event.target.closest('[data-dmd-proxmox-log-refresh]');
    if (refreshLogs) {
      event.preventDefault();
      loadTaskLogs();
      return;
    }

    const printLogs = event.target.closest('[data-dmd-proxmox-log-print]');
    if (printLogs) {
      event.preventDefault();
      printTaskLogs();
      return;
    }

    const clearLogs = event.target.closest('[data-dmd-proxmox-log-clear]');
    if (clearLogs) {
      event.preventDefault();
      clearTaskLogs();
    }
  });


  root.addEventListener('click', (event) => {
    const createButton = event.target.closest('[data-dmd-proxmox-create-vm]');
    if (!createButton) return;

    event.preventDefault();
    event.stopPropagation();

    const card = createButton.closest('[data-server-card]');
    if (!card) return;

    const serverId = card.getAttribute('data-server') || '';
    const serverName = card.querySelector('.dmd-proxmox-server-name')?.textContent?.trim() || serverId;

    openCreateVmWindow(serverId, serverName)
      .catch((error) => toast('❌ ' + error.message));
  });

  root.addEventListener('click', (event) => {
    const refresh = event.target.closest('[data-dmd-proxmox-refresh]');
    if (!refresh) return;

    event.preventDefault();
    event.stopPropagation();

    const card = refresh.closest('[data-server-card]');
    const serverId = card ? (card.getAttribute('data-server') || '') : '';

    toast('⏳ Mise à jour du serveur Proxmox…');
    refreshServerModuleOnly(serverId, refresh)
      .catch((error) => toast('❌ ' + error.message));
  });

  root.addEventListener('click', (event) => {
    const toggle = event.target.closest('[data-server-toggle]');
    if (!toggle) return;

    const card = toggle.closest('[data-server-card]');
    if (!card) return;

    card.classList.toggle('is-collapsed');
  });

  root.addEventListener('click', (event) => {
    const tile = event.target.closest('[data-vm-card]');
    if (!tile) return;

    try {
      const vm = JSON.parse(tile.getAttribute('data-vm') || '{}');
      openVmWindow(vm);
    } catch (error) {
      toast('❌ Données VM illisibles');
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;

    const windows = Array.from(document.querySelectorAll('[data-dmd-proxmox-vm-window]'));
    if (!windows.length) return;

    windows.sort((a, b) => (parseInt(b.style.zIndex || '0', 10) - parseInt(a.style.zIndex || '0', 10)));
    closeVmWindow(windows[0]);
  });

  if (desktop && desktop.parentElement !== document.body) {
    document.body.appendChild(desktop);
  }


  function recomputeDesktopBounds() {
    const workspace = document.getElementById('dashboard');

    if (workspace) {
      const windows = Array.from(workspace.querySelectorAll(
        '[data-dmd-proxmox-vm-window],[data-dmd-proxmox-console-window],[data-dmd-proxmox-files-window]'
      )).filter(win => win.isConnected && win.style.display !== 'none');

      let maxRight = workspace.clientWidth;
      let maxBottom = workspace.clientHeight;

      windows.forEach(win => {
        const left = parseFloat(win.style.left) || 0;
        const top = parseFloat(win.style.top) || 0;
        const width = win.offsetWidth || parseFloat(win.style.width) || 0;
        const height = win.offsetHeight || parseFloat(win.style.height) || 0;
        maxRight = Math.max(maxRight, left + width + 56);
        maxBottom = Math.max(maxBottom, top + height + 56);
      });

      let extent = workspace.querySelector(':scope > [data-dmd-proxmox-workspace-extent]');

      if (windows.length) {
        if (!extent) {
          extent = document.createElement('div');
          extent.dataset.dmdProxmoxWorkspaceExtent = '1';
          extent.setAttribute('aria-hidden', 'true');
          Object.assign(extent.style, {
            position: 'absolute',
            left: '0',
            top: '0',
            display: 'block',
            pointerEvents: 'none',
            opacity: '0',
            margin: '0',
            padding: '0',
            border: '0',
            zIndex: '-1'
          });
          workspace.prepend(extent);
        }

        extent.style.width = Math.ceil(maxRight) + 'px';
        extent.style.height = Math.ceil(maxBottom) + 'px';
        workspace.style.overflow = 'auto';
        workspace.style.overflowX = 'auto';
        workspace.style.overflowY = 'auto';
        workspace.style.position = workspace.style.position || 'relative';
      } else if (extent) {
        extent.remove();
      }

      if (typeof window.DMDExpandDashboardCanvas === 'function') {
        window.DMDExpandDashboardCanvas();
      }
      return;
    }

    if (desktop) {
      desktop.style.width = '100%';
      desktop.style.height = '100%';
    }
  }
  document.addEventListener('dmd:actionhub-ui-action', (event) => {
    const detail = event && event.detail && typeof event.detail === 'object' ? event.detail : {};
    if (String(detail.module || '') !== 'DMD-Proxmox') return;
    const ui = detail.ui && typeof detail.ui === 'object' ? detail.ui : {};
    if (String(ui.type || '') !== 'proxmox-created-vms') return;
    let vms = Array.isArray(ui.vms) ? ui.vms.filter(v => v && Number(v.vmid || 0) > 0) : [];
    if (String(ui.open_count || 'first') !== 'all') vms = vms.slice(0, 1);
    const mode = String(ui.mode || 'none');
    if (mode === 'vm') {
      vms.forEach((vm, index) => window.setTimeout(() => openVmWindow(vm), index * 90));
    } else if (mode === 'remote') {
      vms.forEach((vm, index) => window.setTimeout(() => {
        if (vm.running) openConsole(vm);
        else { openVmWindow(vm); toast(`⚠️ VM #${vm.vmid} créée mais non démarrée : fiche ouverte à la place du Remote.`); }
      }, index * 140));
    }
    document.dispatchEvent(new CustomEvent('dmd:actionhub-ui-action-handled', {detail:{module:'DMD-Proxmox',ui_type:'proxmox-created-vms'}}));
  });
  (function registerProxmoxActionHubProvider(){
    const provider = {
      id: 'DMD-Proxmox',
      getResources() {
        const resources = [];
        root.querySelectorAll('[data-vm-card]').forEach((tile) => {
          try {
            const vm = JSON.parse(tile.getAttribute('data-vm') || '{}');
            const serverId = String(vm.server_id || vm.node || '').trim();
            const type = String(vm.type || 'qemu').toLowerCase() === 'lxc' ? 'lxc' : 'qemu';
            const vmid = Number(vm.vmid || 0);
            if (!serverId || !vmid) return;
            const label = String(vm.name || `${type.toUpperCase()} #${vmid}`);
            resources.push({
              type: 'proxmox_vm',
              id: `DMD-Proxmox:vm:${serverId}:${type}:${vmid}`,
              name: label,
              label,
              source: 'DMD-Proxmox',
              tags: ['proxmox', `server:${serverId}`, `type:${type}`, vm.real_node ? `node:${vm.real_node}` : ''].filter(Boolean)
            });
          } catch (_) {}
        });
        return resources;
      }
    };

    let tries = 0;
    const install = () => {
      tries += 1;
      if (window.DMDActionHub && typeof window.DMDActionHub.registerProvider === 'function') {
        window.DMDActionHub.registerProvider(provider);
        return;
      }
      if (tries < 30) window.setTimeout(install, 250);
    };
    install();
  })();

  loadTaskLogs();

  const NEED_UPDATE = <?= $needUpdate ? 'true' : 'false'; ?>;
  if (NEED_UPDATE) {
    const key = 'dmd_proxmox_last_bg_refresh';
    const now = Date.now();
    const ttl = 15000;
    const last = parseInt(sessionStorage.getItem(key) || '0', 10);

    if (now - last >= ttl) {
      sessionStorage.setItem(key, String(now));
      refreshAllServerCardsModuleOnly()
        .catch(() => {});
    }
  }
})();
</script>
<?php echo dmd_proxmox_mfa_autolock_script($DMD_PROXMOX_BASE_URL); ?>

