<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';

if (!dmd_proxmox_has_module_access()) {
    dmd_proxmox_json(false, 'Module DMD-Proxmox non autorisé pour cet utilisateur.', array(), 403);
}

function dmd_proxmox_logs_public_entry($entry) {
    $extra = isset($entry['extra']) && is_array($entry['extra']) ? $entry['extra'] : array();
    $server = trim((string)(isset($extra['server_name']) ? $extra['server_name'] : ''));
    $node = trim((string)(isset($extra['node']) ? $extra['node'] : ''));
    if ($server === '' && isset($extra['server_id'])) $server = (string)$extra['server_id'];
    $where = trim($server . ($server !== '' && $node !== '' ? ' / ' : '') . $node);

    return array(
        'id' => isset($entry['id']) ? (string)$entry['id'] : dmd_proxmox_log_signature($entry),
        'timestamp' => isset($entry['timestamp']) ? (int)$entry['timestamp'] : 0,
        'date' => isset($entry['date']) ? (string)$entry['date'] : '',
        'user' => isset($entry['user']) ? (string)$entry['user'] : '',
        'role_system' => isset($entry['role_system']) ? (string)$entry['role_system'] : '',
        'action' => isset($entry['action']) ? (string)$entry['action'] : '',
        'action_label' => dmd_proxmox_log_action_label(isset($entry['action']) ? $entry['action'] : ''),
        'target' => isset($entry['target']) ? (string)$entry['target'] : '',
        'status' => isset($entry['status']) ? (string)$entry['status'] : '',
        'details' => isset($entry['details']) ? (string)$entry['details'] : '',
        'where' => $where,
    );
}

function dmd_proxmox_pdf_text($text) {
    $text = str_replace(array("\r", "\n", "\t"), ' ', (string)$text);
    $text = preg_replace('/\s+/', ' ', $text);
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);
        if ($converted !== false) $text = $converted;
    }
    $text = str_replace(array('\\', '(', ')'), array('\\\\', '\\(', '\\)'), $text);
    return $text;
}

function dmd_proxmox_pdf_build($rows) {
    $pageWidth = 842;
    $pageHeight = 595;
    $marginX = 34;
    $topY = 556;
    $lineHeight = 10;
    $maxLines = 45;

    $lines = array();
    $lines[] = 'DMD-Proxmox - Journal des taches';
    $lines[] = 'Exporte le ' . date('d/m/Y H:i:s') . ' - ' . count($rows) . ' entree(s)';
    $lines[] = str_repeat('-', 132);
    $lines[] = sprintf('%-16s %-24s %-20s %-30s %-9s %-24s', 'Date / heure', 'Utilisateur', 'Action', 'Cible', 'Etat', 'Serveur / node');
    $lines[] = str_repeat('-', 132);

    foreach ($rows as $entry) {
        $date = isset($entry['timestamp']) && (int)$entry['timestamp'] > 0 ? date('d/m/Y H:i:s', (int)$entry['timestamp']) : (isset($entry['date']) ? $entry['date'] : '');
        $status = strtolower((string)(isset($entry['status']) ? $entry['status'] : ''));
        $statusText = in_array($status, array('success', 'ok', 'done'), true) ? 'OK' : (in_array($status, array('error', 'failed', 'danger'), true) ? 'ERREUR' : strtoupper($status));
        $public = dmd_proxmox_logs_public_entry($entry);
        $main = sprintf(
            '%-16s %-24s %-20s %-30s %-9s %-24s',
            substr($date, 0, 16),
            substr((string)$public['user'], 0, 24),
            substr((string)$public['action_label'], 0, 20),
            substr((string)$public['target'], 0, 30),
            substr($statusText, 0, 9),
            substr((string)$public['where'], 0, 24)
        );
        $lines[] = rtrim($main);
        $detail = trim((string)$public['details']);
        if ($detail !== '') {
            foreach (explode("\n", wordwrap('  > ' . $detail, 126, "\n", true)) as $wrapped) $lines[] = $wrapped;
        }
    }

    $pages = array_chunk($lines, $maxLines);
    $objects = array();
    $objects[1] = '<< /Type /Catalog /Pages 2 0 R >>';
    $pageRefs = array();
    $nextObj = 4;
    $fontObj = 3;
    $objects[$fontObj] = '<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>';

    foreach ($pages as $pageLines) {
        $pageObj = $nextObj++;
        $contentObj = $nextObj++;
        $pageRefs[] = $pageObj . ' 0 R';

        $content = "BT\n/F1 7 Tf\n" . $marginX . ' ' . $topY . " Td\n";
        foreach ($pageLines as $idx => $line) {
            if ($idx > 0) $content .= '0 -' . $lineHeight . " Td\n";
            $content .= '(' . dmd_proxmox_pdf_text($line) . ") Tj\n";
        }
        $content .= "ET\n";

        $objects[$contentObj] = "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "endstream";
        $objects[$pageObj] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . $pageWidth . ' ' . $pageHeight . '] /Resources << /Font << /F1 ' . $fontObj . ' 0 R >> >> /Contents ' . $contentObj . ' 0 R >>';
    }

    $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $pageRefs) . '] /Count ' . count($pageRefs) . ' >>';
    ksort($objects);

    $pdf = "%PDF-1.4\n";
    $offsets = array(0 => 0);
    $maxObj = max(array_keys($objects));
    for ($i = 1; $i <= $maxObj; $i++) {
        if (!isset($objects[$i])) continue;
        $offsets[$i] = strlen($pdf);
        $pdf .= $i . " 0 obj\n" . $objects[$i] . "\nendobj\n";
    }

    $xref = strlen($pdf);
    $pdf .= "xref\n0 " . ($maxObj + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    for ($i = 1; $i <= $maxObj; $i++) {
        $off = isset($offsets[$i]) ? $offsets[$i] : 0;
        $pdf .= sprintf("%010d 00000 n \n", $off);
    }
    $pdf .= "trailer\n<< /Size " . ($maxObj + 1) . " /Root 1 0 R >>\nstartxref\n" . $xref . "\n%%EOF";
    return $pdf;
}

$mode = strtolower(trim((string)(isset($_GET['mode']) ? $_GET['mode'] : 'list')));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = (string)file_get_contents('php://input');
    $input = json_decode($raw, true);
    if (!is_array($input)) $input = $_POST;

    if (!dmd_proxmox_csrf_valid(isset($input['csrf']) ? $input['csrf'] : '')) {
        dmd_proxmox_json(false, 'Jeton de sécurité expiré. Recharge la page.', array(), 403);
    }

    $action = strtolower(trim((string)(isset($input['action']) ? $input['action'] : '')));
    if ($action !== 'clear') dmd_proxmox_json(false, 'Action de journal invalide.', array(), 400);
    if (!dmd_proxmox_user_can('logs.delete')) dmd_proxmox_json(false, 'Suppression des logs DMD-Proxmox non autorisée.', array(), 403);

    $removed = dmd_proxmox_logs_clear();
    dmd_proxmox_json(true, 'Journal DMD-Proxmox supprimé.', array('removed' => $removed), 200);
}

if ($mode === 'pdf') {
    if (!dmd_proxmox_user_can('logs.export')) {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Export des logs DMD-Proxmox non autorisé.';
        exit;
    }
    $rows = dmd_proxmox_logs_read(5000);
    $pdf = dmd_proxmox_pdf_build($rows);
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="dmd-proxmox_logs_' . date('Ymd_His') . '.pdf"');
    header('Content-Length: ' . strlen($pdf));
    header('Cache-Control: no-store, no-cache, must-revalidate');
    echo $pdf;
    exit;
}

if (!dmd_proxmox_user_can('logs.view')) {
    dmd_proxmox_json(false, 'Lecture des logs DMD-Proxmox non autorisée.', array(), 403);
}

$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 200;
$rows = dmd_proxmox_logs_read($limit);
$public = array();
foreach ($rows as $entry) $public[] = dmd_proxmox_logs_public_entry($entry);

dmd_proxmox_json(true, 'Journal DMD-Proxmox chargé.', array(
    'items' => $public,
    'count' => count($public),
    'storage' => '/data/modules/DMD-Proxmox/logs'
), 200);
