<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}


function dmdpxwin_fail($message, $configFile = '', $readyFile = '') {
    if ($configFile !== '' && is_file($configFile)) @unlink($configFile);
    if ($readyFile !== '' && is_file($readyFile)) @unlink($readyFile);
    fwrite(STDERR, (string)$message . PHP_EOL);
    exit(1);
}

function dmdpxwin_read_request($stream, $maxHeader = 65536, $timeout = 10) {
    stream_set_timeout($stream, $timeout);
    $buffer = '';

    while (strpos($buffer, "\r\n\r\n") === false && strlen($buffer) < $maxHeader && !feof($stream)) {
        $chunk = @fread($stream, 8192);
        if ($chunk === false || $chunk === '') {
            $meta = stream_get_meta_data($stream);
            if (!empty($meta['timed_out'])) break;
            usleep(10000);
            continue;
        }
        $buffer .= $chunk;
    }

    $pos = strpos($buffer, "\r\n\r\n");
    if ($pos === false) return null;

    $headerText = substr($buffer, 0, $pos + 4);
    $body = substr($buffer, $pos + 4);

    $lines = preg_split('/\r\n/', trim($headerText));
    $requestLine = array_shift($lines);
    $headers = array();

    foreach ($lines as $line) {
        $colon = strpos($line, ':');
        if ($colon === false) continue;
        $name = trim(substr($line, 0, $colon));
        $value = trim(substr($line, $colon + 1));
        if ($name === '') continue;
        $headers[strtolower($name)] = array($name, $value);
    }

    $contentLength = 0;
    if (isset($headers['content-length'])) {
        $contentLength = max(0, (int)$headers['content-length'][1]);
    }

    while (strlen($body) < $contentLength && !feof($stream)) {
        $chunk = @fread($stream, min(65536, $contentLength - strlen($body)));
        if ($chunk === false || $chunk === '') break;
        $body .= $chunk;
    }

    return array(
        'request_line' => (string)$requestLine,
        'headers' => $headers,
        'body' => $body
    );
}

function dmdpxwin_read_response_headers($stream, $maxHeader = 65536, $timeout = 15) {
    stream_set_timeout($stream, $timeout);
    $buffer = '';

    while (strpos($buffer, "\r\n\r\n") === false && strlen($buffer) < $maxHeader && !feof($stream)) {
        $chunk = @fread($stream, 8192);
        if ($chunk === false || $chunk === '') {
            $meta = stream_get_meta_data($stream);
            if (!empty($meta['timed_out'])) break;
            usleep(10000);
            continue;
        }
        $buffer .= $chunk;
    }

    $pos = strpos($buffer, "\r\n\r\n");
    if ($pos === false) return null;

    return array(
        'headers' => substr($buffer, 0, $pos + 4),
        'body_start' => substr($buffer, $pos + 4)
    );
}

function dmdpxwin_write_all($stream, $data) {
    $data = (string)$data;
    $length = strlen($data);
    $offset = 0;

    while ($offset < $length) {
        $written = @fwrite($stream, substr($data, $offset));
        if ($written === false || $written === 0) return false;
        $offset += $written;
    }

    return true;
}

function dmdpxwin_header_value($headers, $name) {
    $key = strtolower((string)$name);
    return isset($headers[$key]) ? (string)$headers[$key][1] : '';
}

function dmdpxwin_has_session_token($target, $headers, $token) {
    $target = (string)$target;
    $token = (string)$token;

    $query = parse_url($target, PHP_URL_QUERY);
    if (is_string($query) && $query !== '') {
        parse_str($query, $params);
        if (isset($params['dmdtoken']) && hash_equals($token, (string)$params['dmdtoken'])) {
            return true;
        }
    }

    $cookie = dmdpxwin_header_value($headers, 'cookie');
    if ($cookie !== '') {
        foreach (explode(';', $cookie) as $part) {
            $part = trim($part);
            if (strpos($part, 'DMDPXWIN=') !== 0) continue;
            $value = substr($part, strlen('DMDPXWIN='));
            if (hash_equals($token, rawurldecode($value))) return true;
        }
    }

    return false;
}

function dmdpxwin_strip_token_from_target($target) {
    $parts = parse_url((string)$target);
    if (!is_array($parts)) return (string)$target;

    $path = isset($parts['path']) ? (string)$parts['path'] : '/';
    $query = array();

    if (!empty($parts['query'])) {
        parse_str((string)$parts['query'], $query);
        unset($query['dmdtoken']);
    }

    $result = $path !== '' ? $path : '/';
    if ($query) $result .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);

    return $result;
}

function dmdpxwin_rewrite_response_headers($rawHeaders, $clientHost, $upHost, $upPort, $token, $isWebSocket) {
    $lines = preg_split('/\r\n/', trim((string)$rawHeaders));
    if (!$lines) return (string)$rawHeaders;

    $status = array_shift($lines);
    $out = array($status);

    foreach ($lines as $line) {
        $colon = strpos($line, ':');
        if ($colon === false) continue;

        $name = trim(substr($line, 0, $colon));
        $value = trim(substr($line, $colon + 1));
        $lname = strtolower($name);

        if (in_array($lname, array(
            'x-frame-options',
            'content-security-policy',
            'content-security-policy-report-only',
            'strict-transport-security'
        ), true)) {
            continue;
        }

        if ($lname === 'set-cookie' && stripos($value, 'PVEAuthCookie=') !== false) {
            continue;
        }

        if ($lname === 'location') {
            $needle = 'https://' . $upHost . ':' . $upPort;
            if (stripos($value, $needle) === 0) {
                $value = 'http://' . $clientHost . substr($value, strlen($needle));
            }
        }

        if ($lname === 'connection' && !$isWebSocket) {
            continue;
        }

        $out[] = $name . ': ' . $value;
    }

    $out[] = 'Set-Cookie: DMDPXWIN=' . rawurlencode((string)$token) . '; Path=/; HttpOnly; SameSite=Lax';

    if (!$isWebSocket) {
        $out[] = 'Connection: close';
    }

    return implode("\r\n", $out) . "\r\n\r\n";
}

function dmdpxwin_proxy_connection($client, $cfg) {
    $request = dmdpxwin_read_request($client);
    if (!is_array($request)) return;

    if (!preg_match('~^([A-Z]+)\s+([^\s]+)\s+HTTP/1\.[01]$~', $request['request_line'], $m)) {
        dmdpxwin_write_all($client, "HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n");
        return;
    }

    $method = strtoupper($m[1]);
    $target = $m[2];
    $headers = $request['headers'];

    if (!dmdpxwin_has_session_token($target, $headers, $cfg['session_token'])) {
        dmdpxwin_write_all($client, "HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n");
        return;
    }

    $target = dmdpxwin_strip_token_from_target($target);

    $upgrade = strtolower(dmdpxwin_header_value($headers, 'upgrade'));
    $isWebSocket = ($upgrade === 'websocket');

    $upHost = (string)$cfg['upstream_host'];
    $upPort = (int)$cfg['upstream_port'];
    $hostHeader = $upHost . ':' . $upPort;

    $ssl = stream_context_create(array('ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true,
        'SNI_enabled' => true,
        'peer_name' => $upHost
    )));

    $errno = 0;
    $errstr = '';
    $upstream = @stream_socket_client(
        'tls://' . $upHost . ':' . $upPort,
        $errno,
        $errstr,
        10,
        STREAM_CLIENT_CONNECT,
        $ssl
    );

    if (!is_resource($upstream)) {
        dmdpxwin_write_all($client, "HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n");
        return;
    }

    $forwardHeaders = array();
    $forwardHeaders[] = $method . ' ' . $target . ' HTTP/1.1';
    $forwardHeaders[] = 'Host: ' . $hostHeader;

    foreach ($headers as $lname => $pair) {
        $name = $pair[0];
        $value = $pair[1];

        if (in_array($lname, array(
            'host',
            'cookie',
            'connection',
            'csrfpreventiontoken'
        ), true)) {
            continue;
        }

        if ($lname === 'origin') continue;

        $forwardHeaders[] = $name . ': ' . $value;
    }

    $forwardHeaders[] = 'Cookie: PVEAuthCookie=' . (string)$cfg['pve_auth_cookie'];
    $forwardHeaders[] = 'CSRFPreventionToken: ' . (string)$cfg['csrf_token'];
    $forwardHeaders[] = 'Origin: https://' . $hostHeader;

    if ($isWebSocket) {
        $forwardHeaders[] = 'Connection: Upgrade';
    } else {
        $forwardHeaders[] = 'Connection: close';
    }

    $forward = implode("\r\n", $forwardHeaders) . "\r\n\r\n" . (string)$request['body'];

    if (!dmdpxwin_write_all($upstream, $forward)) {
        @fclose($upstream);
        return;
    }

    $response = dmdpxwin_read_response_headers($upstream);
    if (!is_array($response)) {
        @fclose($upstream);
        return;
    }

    $firstLine = strtok($response['headers'], "\r\n");
    $is101 = $isWebSocket && preg_match('~^HTTP/1\.[01]\s+101\b~i', (string)$firstLine);

    $clientHost = dmdpxwin_header_value($headers, 'host');
    if ($clientHost === '') $clientHost = '127.0.0.1:' . (int)$cfg['listen_port'];

    $rewritten = dmdpxwin_rewrite_response_headers(
        $response['headers'],
        $clientHost,
        $upHost,
        $upPort,
        $cfg['session_token'],
        (bool)$is101
    );

    if (!dmdpxwin_write_all($client, $rewritten)) {
        @fclose($upstream);
        return;
    }

    if ($response['body_start'] !== '') {
        if (!dmdpxwin_write_all($client, $response['body_start'])) {
            @fclose($upstream);
            return;
        }
    }

    if ($is101) {
        stream_set_blocking($client, false);
        stream_set_blocking($upstream, false);

        $endAt = time() + max(60, min(14400, (int)$cfg['max_runtime']));

        while (time() < $endAt && !feof($client) && !feof($upstream)) {
            $read = array($client, $upstream);
            $write = null;
            $except = null;

            $n = @stream_select($read, $write, $except, 1, 0);
            if ($n === false) break;
            if ($n === 0) continue;

            foreach ($read as $src) {
                $dst = ($src === $client) ? $upstream : $client;
                $buf = @fread($src, 65536);
                if ($buf === false || $buf === '') continue;
                if (!dmdpxwin_write_all($dst, $buf)) break 2;
            }
        }

        @fclose($upstream);
        return;
    }

    stream_set_timeout($upstream, 20);

    while (!feof($upstream)) {
        $buf = @fread($upstream, 65536);
        if ($buf === false || $buf === '') {
            $meta = stream_get_meta_data($upstream);
            if (!empty($meta['timed_out'])) break;
            usleep(10000);
            continue;
        }

        if (!dmdpxwin_write_all($client, $buf)) break;
    }

    @fclose($upstream);
}

function dmdpxwin_proxy_main($configFile) {
    if ($configFile === '' || !is_file($configFile)) {
        dmdpxwin_fail('Configuration Windows Remote absente.', $configFile);
    }

    $cfg = json_decode((string)@file_get_contents($configFile), true);
    if (!is_array($cfg)) {
        dmdpxwin_fail('Configuration Windows Remote invalide.', $configFile);
    }

    $readyFile = isset($cfg['ready_file']) ? (string)$cfg['ready_file'] : '';

    if ((int)($cfg['expires_at'] ?? 0) < time()) {
        dmdpxwin_fail('Configuration Windows Remote expirée.', $configFile, $readyFile);
    }

    $listenPort = (int)($cfg['listen_port'] ?? 0);
    if ($listenPort < 1) {
        dmdpxwin_fail('Port Windows Remote invalide.', $configFile, $readyFile);
    }

    @unlink($configFile);

    $errno = 0;
    $errstr = '';
    $server = @stream_socket_server(
        'tcp://0.0.0.0:' . $listenPort,
        $errno,
        $errstr,
        STREAM_SERVER_BIND | STREAM_SERVER_LISTEN
    );

    if (!is_resource($server)) {
        dmdpxwin_fail('Écoute Windows Remote impossible : ' . $errstr, '', $readyFile);
    }

    stream_set_blocking($server, false);

    if (@file_put_contents($readyFile, (string)getmypid(), LOCK_EX) === false) {
        @fclose($server);
        dmdpxwin_fail('Impossible de signaler Windows Remote.', '', $readyFile);
    }
    @chmod($readyFile, 0600);

    $endAt = time() + max(60, min(14400, (int)($cfg['max_runtime'] ?? 14400)));

    while (time() < $endAt) {
        $peer = '';
        $client = @stream_socket_accept($server, 0, $peer);

        if (!is_resource($client)) {
            usleep(20000);
            continue;
        }
        dmdpxwin_proxy_connection($client, $cfg);
        @fclose($client);
    }

    @unlink($readyFile);
    @fclose($server);
    exit(0);
}

if (PHP_SAPI === 'cli' && isset($argv[1]) && $argv[1] === '--windows-native-proxy') {
    dmdpxwin_proxy_main(isset($argv[2]) ? (string)$argv[2] : '');
    exit;
}


if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');

function dmd_proxmox_remote_error($message, $status) {
    http_response_code((int)$status);
    $safe = htmlspecialchars((string)$message, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<style>html,body{height:100%;margin:0;background:#080b12;color:#e8edf7;font-family:system-ui,sans-serif}.e{height:100%;display:grid;place-items:center;padding:20px;box-sizing:border-box}.c{max-width:620px;padding:18px;border:1px solid rgba(255,255,255,.14);border-radius:12px;background:#111827}.c strong{display:block;margin-bottom:8px}.c p{margin:0;color:#aeb9cc;line-height:1.5}</style></head><body><div class="e"><div class="c"><strong>Remote DMD-Proxmox indisponible</strong><p>' . $safe . '</p></div></div></body></html>';
    exit;
}

function dmd_proxmox_remote_is_https_request() {
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') return true;
    $proto = strtolower(trim((string)(isset($_SERVER['HTTP_X_FORWARDED_PROTO']) ? $_SERVER['HTTP_X_FORWARDED_PROTO'] : '')));
    return $proto === 'https';
}

function dmd_proxmox_remote_php_cli() {
    $candidates = array();
    if (defined('PHP_BINDIR')) $candidates[] = rtrim((string)PHP_BINDIR, '/\\') . DIRECTORY_SEPARATOR . 'php';
    $candidates[] = '/usr/bin/php';
    $candidates[] = '/usr/local/bin/php';
    $candidates[] = '/opt/bin/php';
    if (defined('PHP_BINARY')) $candidates[] = (string)PHP_BINARY;
    foreach (array_unique($candidates) as $candidate) {
        if ($candidate === '' || !is_file($candidate) || !is_executable($candidate)) continue;
        $base = strtolower(basename($candidate));
        if (strpos($base, 'php-fpm') !== false || strpos($base, 'php-cgi') !== false) continue;
        return $candidate;
    }
    return '';
}

function dmd_proxmox_remote_function_enabled($name) {
    if (!function_exists($name)) return false;
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    return !in_array($name, $disabled, true);
}

function dmd_proxmox_remote_port_is_free($port) {
    $fp = @fsockopen('127.0.0.1', (int)$port, $errno, $errstr, 0.08);
    if (is_resource($fp)) {
        fclose($fp);
        return false;
    }
    return true;
}

function dmd_proxmox_remote_pick_port() {
    $ports = range(6080, 6129);
    shuffle($ports);
    foreach ($ports as $port) {
        if (dmd_proxmox_remote_port_is_free($port)) return (int)$port;
    }
    return 0;
}

function dmd_proxmox_windows_remote_pick_port() {
    $ports = range(6130, 6179);
    shuffle($ports);
    foreach ($ports as $port) {
        if (dmd_proxmox_remote_port_is_free($port)) return (int)$port;
    }
    return 0;
}

function dmd_proxmox_windows_remote_start_proxy($phpCli, $configFile) {
    $cmd = escapeshellarg($phpCli) . ' ' . escapeshellarg(__FILE__) . ' --windows-native-proxy ' . escapeshellarg($configFile);

    if (dmd_proxmox_remote_function_enabled('exec')) {
        @exec($cmd . ' > /dev/null 2>&1 &');
        return true;
    }

    if (dmd_proxmox_remote_function_enabled('shell_exec')) {
        @shell_exec($cmd . ' > /dev/null 2>&1 &');
        return true;
    }

    if (dmd_proxmox_remote_function_enabled('proc_open')) {
        $desc = array(
            0 => array('file', '/dev/null', 'r'),
            1 => array('file', '/dev/null', 'a'),
            2 => array('file', '/dev/null', 'a')
        );
        $proc = @proc_open($cmd . ' > /dev/null 2>&1 &', $desc, $pipes, __DIR__);
        if (is_resource($proc)) {
            foreach ($pipes as $pipe) if (is_resource($pipe)) fclose($pipe);
            return true;
        }
    }

    return false;
}

function dmd_proxmox_is_windows_ostype($ostype) {
    return in_array(strtolower(trim((string)$ostype)), array(
        'win11', 'win10', 'win8', 'win7', 'w2k8', 'wxp', 'w2k'
    ), true);
}

function dmd_proxmox_remote_start_bridge($phpCli, $configFile) {
    $script = __DIR__ . '/DMD-Proxmox_remote_bridge.php';
    if (!is_file($script)) return false;
    $cmd = escapeshellarg($phpCli) . ' ' . escapeshellarg($script) . ' ' . escapeshellarg($configFile);
    if (dmd_proxmox_remote_function_enabled('exec')) {
        @exec($cmd . ' > /dev/null 2>&1 &');
        return true;
    }
    if (dmd_proxmox_remote_function_enabled('shell_exec')) {
        @shell_exec($cmd . ' > /dev/null 2>&1 &');
        return true;
    }
    if (dmd_proxmox_remote_function_enabled('proc_open')) {
        $desc = array(0 => array('file', '/dev/null', 'r'), 1 => array('file', '/dev/null', 'a'), 2 => array('file', '/dev/null', 'a'));
        $proc = @proc_open($cmd . ' > /dev/null 2>&1 &', $desc, $pipes, __DIR__);
        if (is_resource($proc)) {
            foreach ($pipes as $pipe) if (is_resource($pipe)) fclose($pipe);
            return true;
        }
    }
    return false;
}

require_once __DIR__ . '/DMD-Proxmox_remote_gateway_lib.php';

if (!dmd_proxmox_has_module_access() || !dmd_proxmox_user_can('console')) {
    dmd_proxmox_remote_error('Droit Remote refusé.', 403);
}
if (!dmd_proxmox_csrf_valid(isset($_GET['csrf']) ? $_GET['csrf'] : '')) {
    dmd_proxmox_remote_error('Jeton de sécurité invalide.', 403);
}
if (!is_file(__DIR__ . '/novnc/core/rfb.js')) {
    dmd_proxmox_remote_error('Le composant noVNC local est absent du module.', 501);
}

$serverId = trim((string)(isset($_GET['server_id']) ? $_GET['server_id'] : ''));
$vmid = (int)(isset($_GET['vmid']) ? $_GET['vmid'] : 0);
$type = strtolower(trim((string)(isset($_GET['type']) ? $_GET['type'] : '')));
if ($serverId === '' || $vmid <= 0) dmd_proxmox_remote_error('Paramètres Remote incomplets.', 400);

$server = dmd_proxmox_load_server($serverId);
if (!is_array($server)) dmd_proxmox_remote_error('Serveur Proxmox introuvable.', 404);
$vm = dmd_proxmox_resolve_vm($server, $vmid, $type);
if (!is_array($vm)) dmd_proxmox_remote_error('VM/CT introuvable.', 404);

$node = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
$type = strtolower((string)(isset($vm['type']) ? $vm['type'] : 'qemu'));
if (!in_array($type, array('qemu', 'lxc'), true)) $type = 'qemu';
if ($node === '') dmd_proxmox_remote_error('Node Proxmox introuvable.', 404);

$resolvedServerId = !empty($server['id']) ? (string)$server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : $serverId);
if (!dmd_proxmox_acl_can(dmd_proxmox_user_email(), $resolvedServerId, $type, $vmid, 'console')) {
    dmd_proxmox_remote_error('Droit Remote refusé pour cette VM/CT.', 403);
}

$serviceUser = trim((string)(isset($server['proxmox_user']) ? $server['proxmox_user'] : 'domydesk@pve'));
if ($serviceUser === '') $serviceUser = 'domydesk@pve';
$remotePassword = dmd_proxmox_decrypt_remote_password($server);
if ($remotePassword === '') {
    dmd_proxmox_remote_error('Ce serveur a été configuré avant l’activation du Remote. Dans le CFG DMD-Proxmox, renouvelle une fois la configuration automatique avec le compte administrateur Proxmox : le mot de passe root ne sera toujours pas conservé.', 409);
}

$ip = trim((string)(isset($server['ip']) ? $server['ip'] : ''));
$port = (int)(isset($server['port']) ? $server['port'] : 8006);
if ($port <= 0 || $port > 65535) $port = 8006;
if ($ip === '') dmd_proxmox_remote_error('Adresse Proxmox manquante.', 500);

$login = dmd_proxmox_password_login($ip, $port, $serviceUser, $remotePassword, 12);
$remotePassword = null;
if (empty($login['ok']) || !is_array($login['data'])) {
    dmd_proxmox_remote_error('Impossible d’obtenir le ticket utilisateur Remote : ' . (isset($login['error']) ? $login['error'] : 'erreur inconnue'), 502);
}
$auth = $login['data'];

$endpoint = 'nodes/' . rawurlencode($node) . '/' . $type . '/' . $vmid . '/vncproxy';
$res = dmd_proxmox_ticket_api($ip, $port, $auth, $endpoint, 'POST', array('websocket' => 1), 15);
if (empty($res['ok']) || !is_array($res['data'])) {
    dmd_proxmox_remote_error('Impossible d’ouvrir le proxy Remote Proxmox : ' . (isset($res['error']) ? $res['error'] : 'erreur inconnue'), 502);
}
$d = $res['data'];
if (empty($d['port']) || empty($d['ticket'])) dmd_proxmox_remote_error('Réponse Remote Proxmox incomplète.', 502);

$bridgePort = dmd_proxmox_remote_pick_port();
if ($bridgePort <= 0) dmd_proxmox_remote_error('Aucun port Remote local libre entre 6080 et 6129.', 503);
$phpCli = dmd_proxmox_remote_php_cli();
if ($phpCli === '') dmd_proxmox_remote_error('PHP CLI est nécessaire pour le tunnel Remote V2 et n’a pas été trouvé sur ce serveur.', 501);
$gatewayError = '';
$gatewayReady = dmd_proxmox_gateway_start($gatewayError);
$gatewaySettings = dmd_proxmox_gateway_load_settings();

$paths = dmd_proxmox_storage_paths();
$remoteDir = isset($paths['remote']) ? $paths['remote'] : '';
if ($remoteDir === '' || (!is_dir($remoteDir) && !@mkdir($remoteDir, 0750, true))) {
    dmd_proxmox_remote_error('Le dossier persistant Remote DMD-Proxmox est inaccessible.', 500);
}

$sessionToken = bin2hex(random_bytes(24));
$wsPath = '/api2/json/nodes/' . rawurlencode($node) . '/' . $type . '/' . $vmid . '/vncwebsocket?port=' . rawurlencode((string)$d['port']) . '&vncticket=' . rawurlencode((string)$d['ticket']);
$configFile = rtrim($remoteDir, '/\\') . DIRECTORY_SEPARATOR . $sessionToken . '.json';
$readyFile = rtrim($remoteDir, '/\\') . DIRECTORY_SEPARATOR . $sessionToken . '.ready';
@unlink($readyFile);
$config = array(
    'listen_port' => $bridgePort,
    'session_token' => $sessionToken,
    'ready_file' => $readyFile,
    'upstream_host' => $ip,
    'upstream_port' => $port,
    'upstream_path' => $wsPath,
    'pve_auth_cookie' => (string)$auth['ticket'],
    'expires_at' => time() + 30,
    'max_runtime' => 14400
);
if (@file_put_contents($configFile, json_encode($config, JSON_UNESCAPED_SLASHES), LOCK_EX) === false) {
    dmd_proxmox_remote_error('Impossible de préparer le tunnel Remote.', 500);
}
@chmod($configFile, 0600);

if (!dmd_proxmox_remote_start_bridge($phpCli, $configFile)) {
    @unlink($configFile);
    dmd_proxmox_remote_error('Impossible de démarrer le tunnel Remote local. Vérifie que exec/shell_exec/proc_open est disponible pour PHP.', 501);
}
$ready = false;
for ($i = 0; $i < 40; $i++) {
    usleep(50000);
    if (is_file($readyFile)) {
        $ready = true;
        break;
    }
}
if (!$ready) {
    @unlink($configFile);
    @unlink($readyFile);
    dmd_proxmox_remote_error('Le tunnel Remote ne s’est pas lancé sur le serveur DoMyDesk.', 502);
}

dmd_proxmox_log('remote_control', strtoupper($type) . ' #' . $vmid, 'success', 'Remote DMD-Proxmox ouvert avec contrôle clavier/souris', array(
    'server_id' => $serverId,
    'node' => $node,
    'vmid' => $vmid,
    'type' => $type,
    'mode' => 'full-control'
));
$bridgeClientPort = (int)$bridgePort;
$bridgeClientToken = (string)$sessionToken;
$gatewayClientReady = $gatewayReady;
$gatewayPublicMode = (string)$gatewaySettings['public_mode'];
$gatewayPublicWssUrl = (string)$gatewaySettings['public_wss_url'];
$vncPassword = (string)$d['ticket'];
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="referrer" content="no-referrer">
<title>Remote #<?= htmlspecialchars((string)$vmid, ENT_QUOTES, 'UTF-8') ?></title>
<style>
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#05070a;color:#e7edf6;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
#bar{position:absolute;z-index:5;left:0;right:0;top:0;height:42px;box-sizing:border-box;padding:5px 7px;display:flex;align-items:center;gap:7px;pointer-events:none;background:#05070a;border-bottom:1px solid rgba(255,255,255,.12)}
#screen{position:absolute;left:0;right:0;top:42px;bottom:0;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#000;pointer-events:auto;user-select:none}
#screen canvas{max-width:100%!important;max-height:100%!important}
.badge{height:28px;box-sizing:border-box;display:inline-flex;align-items:center;padding:0 9px;border-radius:4px;background:rgba(8,13,22,.92);border:1px solid rgba(255,255,255,.16);font-size:11px;font-weight:800;white-space:nowrap}
.remote-btn{height:28px;pointer-events:auto;border:1px solid rgba(255,255,255,.18);border-radius:4px;background:rgba(8,13,22,.92);color:#e7edf6;padding:0 10px;font:inherit;font-size:11px;font-weight:800;cursor:pointer;white-space:nowrap}
.remote-btn:hover:not(:disabled){background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.34)}
.remote-btn:disabled{opacity:.45;cursor:not-allowed}
.pve-key-wrap{position:relative;pointer-events:auto}
.pve-key-trigger{height:28px;display:inline-grid;grid-template-columns:20px auto 18px;align-items:center;padding:0;border:1px solid rgba(255,255,255,.22);border-radius:4px;background:rgba(8,13,22,.96);color:inherit;font:inherit;font-size:11px;font-weight:750;cursor:pointer;overflow:hidden}
.pve-key-trigger:hover,.pve-key-trigger[aria-expanded="true"]{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.34)}
.pve-key-trigger .kbd-icon{display:grid;place-items:center;height:100%;border-right:1px solid rgba(255,255,255,.12);font-size:12px}
.pve-key-trigger .kbd-label{padding:0 8px;white-space:nowrap}
.pve-key-trigger .arrow{display:grid;place-items:center;height:100%;border-left:1px solid rgba(255,255,255,.12);font-size:8px;opacity:.8}
.pve-key-panel{position:absolute;top:32px;left:0;width:220px;padding:3px;border:1px solid rgba(255,255,255,.22);border-radius:4px;background:#0b111b;box-shadow:0 14px 34px rgba(0,0,0,.55);z-index:1000}
.pve-key-panel[hidden]{display:none}
.pve-key-item{width:100%;min-height:28px;display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 8px;border:0;border-radius:3px;background:transparent;color:inherit;font:inherit;font-size:11px;text-align:left;cursor:pointer}
.pve-key-item:hover,.pve-key-item:focus-visible{background:rgba(255,255,255,.09);outline:none}
.pve-key-item .hint{opacity:.58;font-size:9px}
.pve-key-sep{height:1px;margin:3px 2px;background:rgba(255,255,255,.12)}
.pve-key-label{padding:4px 8px 2px;font-size:9px;font-weight:800;letter-spacing:.05em;text-transform:uppercase;opacity:.55}
.pve-fkeys{display:grid;grid-template-columns:repeat(4,1fr);gap:3px;padding:2px 4px 4px}
.pve-fkeys .pve-key-item{min-height:26px;justify-content:center;padding:0;border:1px solid rgba(255,255,255,.11)}
.dmd-paste-panel{position:absolute;z-index:1200;top:38px;left:8px;width:min(420px,calc(100vw - 16px));box-sizing:border-box;padding:8px;border:1px solid rgba(255,255,255,.22);border-radius:6px;background:#0b111b;box-shadow:0 16px 40px rgba(0,0,0,.62);pointer-events:auto}
.dmd-paste-panel[hidden]{display:none}
.dmd-paste-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px;font-size:11px;font-weight:800}
.dmd-paste-close{border:0;background:transparent;color:inherit;font:inherit;font-size:17px;line-height:1;cursor:pointer;opacity:.75}
.dmd-paste-close:hover{opacity:1}
.dmd-paste-input{display:block;width:100%;height:72px;box-sizing:border-box;resize:vertical;padding:7px 8px;border:1px solid rgba(255,255,255,.18);border-radius:4px;background:#05070a;color:inherit;font:12px/1.35 ui-monospace,SFMono-Regular,Consolas,monospace;outline:none}
.dmd-paste-input:focus{border-color:rgba(255,255,255,.4)}
.dmd-paste-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:6px}
.dmd-paste-help{font-size:10px;opacity:.65}
.dmd-paste-send{border:1px solid rgba(255,255,255,.2);border-radius:4px;background:rgba(255,255,255,.07);color:inherit;padding:5px 9px;font:inherit;font-size:11px;font-weight:800;cursor:pointer}
.dmd-paste-send:hover{background:rgba(255,255,255,.12)}
#state{margin-left:auto;color:#aab7c8;font-weight:650}
</style>
</head>
<body tabindex="-1">
<div id="screen"></div>
<div id="bar">
  <div class="badge">🖥️ Remote DMD-Proxmox · contrôle actif</div>
  <div class="pve-key-wrap" id="keyMenu">
    <button type="button" class="pve-key-trigger" id="keyMenuTrigger" aria-expanded="false" aria-haspopup="menu" aria-controls="keyMenuPanel">
      <span class="kbd-icon">⌨</span><span class="kbd-label">Envoyer touche</span><span class="arrow">▼</span>
    </button>
    <div class="pve-key-panel" id="keyMenuPanel" role="menu" hidden>
      <button type="button" class="pve-key-item" role="menuitem" data-keycombo="cad"><span>Ctrl + Alt + Suppr</span><span class="hint">Windows</span></button>
      <button type="button" class="pve-key-item" role="menuitem" data-keycombo="cab"><span>Ctrl + Alt + Retour arrière</span></button>
      <div class="pve-key-sep"></div>
      <button type="button" class="pve-key-item" role="menuitem" data-keycombo="alttab"><span>Alt + Tab</span></button>
      <button type="button" class="pve-key-item" role="menuitem" data-keycombo="altf4"><span>Alt + F4</span></button>
      <button type="button" class="pve-key-item" role="menuitem" data-keycombo="ctrlesc"><span>Ctrl + Échap</span></button>
      <button type="button" class="pve-key-item" role="menuitem" data-keycombo="win"><span>Touche Windows</span></button>
      <div class="pve-key-sep"></div>
      <button type="button" class="pve-key-item" role="menuitem" data-keycombo="ctrlc"><span>Ctrl + C</span><span class="hint">dans la VM</span></button>
      <button type="button" class="pve-key-item" role="menuitem" data-keycombo="ctrlv"><span>Ctrl + V</span><span class="hint">dans la VM</span></button>
      <div class="pve-key-sep"></div>
      <div class="pve-key-label">Ctrl + Alt + F1…F12</div>
      <div class="pve-fkeys">
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf1">F1</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf2">F2</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf3">F3</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf4">F4</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf5">F5</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf6">F6</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf7">F7</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf8">F8</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf9">F9</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf10">F10</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf11">F11</button>
        <button type="button" class="pve-key-item" role="menuitem" data-keycombo="caf12">F12</button>
      </div>
    </div>
  </div>
  <button type="button" class="remote-btn" id="pasteBtn">Coller PC → VM</button>
  <button type="button" class="remote-btn" id="copyBtn" disabled>Copier VM → PC</button>
  <div class="badge" id="state">Connexion…</div>
</div>

<div class="dmd-paste-panel" id="pastePanel" hidden>
  <div class="dmd-paste-head">
    <span>Coller PC → VM</span>
    <button type="button" class="dmd-paste-close" id="pasteClose" aria-label="Fermer">×</button>
  </div>
  <textarea class="dmd-paste-input" id="pasteCapture" spellcheck="false" autocomplete="off" placeholder="Ctrl+V ici : le texte sera envoyé à la VM"></textarea>
  <div class="dmd-paste-foot">
    <span class="dmd-paste-help">PC → VM : colle ici avec Ctrl+V, puis le texte est envoyé à la VM. Les Ctrl+C/Ctrl+V normaux restent gérés par noVNC dans la VM.</span>
    <button type="button" class="dmd-paste-send" id="pasteSend">Envoyer</button>
  </div>
</div>

<script type="module">
import RFB from './novnc/core/rfb.js';
import KeyTable from './novnc/core/input/keysym.js';
import Keysyms from './novnc/core/input/keysymdef.js';
import { initLogging } from './novnc/core/util/logging.js';
initLogging('warn');


const screen = document.getElementById('screen');
const state = document.getElementById('state');
const dmdBridgePort = <?= json_encode((int)$bridgeClientPort) ?>;
const dmdBridgeToken = <?= json_encode((string)$bridgeClientToken, JSON_UNESCAPED_SLASHES) ?>;

const dmdGatewayReady = <?= $gatewayClientReady ? 'true' : 'false' ?>;
const dmdGatewayPublicMode = <?= json_encode($gatewayPublicMode, JSON_UNESCAPED_SLASHES) ?>;
const dmdGatewayPublicUrl = <?= json_encode($gatewayPublicWssUrl, JSON_UNESCAPED_SLASHES) ?>;
let url;
if (window.location.protocol === 'https:') {
  if (!dmdGatewayReady) {
    throw new Error('Gateway Remote HTTPS/WSS indisponible côté serveur. Ouvre DMD-Proxmox > CFG > Diagnostic Remote HTTPS/WSS.');
  }
  if (dmdGatewayPublicMode === 'custom' && dmdGatewayPublicUrl) {
    url = `${dmdGatewayPublicUrl.replace(/\/$/, '')}/${dmdBridgePort}/${encodeURIComponent(dmdBridgeToken)}`;
  } else {
    const wsUrl = new URL(`./ws/${dmdBridgePort}/${encodeURIComponent(dmdBridgeToken)}`, window.location.href);
    wsUrl.protocol = 'wss:';
    url = wsUrl.toString();
  }
} else {
  const h = window.location.hostname;
  url = `ws://${h}:${dmdBridgePort}/${encodeURIComponent(dmdBridgeToken)}`;
}
console.log('[DMD-Proxmox Remote] transport navigateur =', url);
console.log('[DMD-Proxmox Remote] gateway fixe =', <?= json_encode($gatewaySettings['listen_host'] . ':' . $gatewaySettings['listen_port']) ?>);
const password = <?= json_encode($vncPassword) ?>;

const pasteBtn = document.getElementById('pasteBtn');
const copyBtn = document.getElementById('copyBtn');
const pastePanel = document.getElementById('pastePanel');
const pasteCapture = document.getElementById('pasteCapture');
const pasteSend = document.getElementById('pasteSend');
const pasteClose = document.getElementById('pasteClose');
let vmClipboard = '';
let typingPaste = false;

const rfb = new RFB(screen, url, { credentials: { password } });
rfb.viewOnly = false;
rfb.scaleViewport = true;
rfb.resizeSession = false;
rfb.clipViewport = false;
rfb.showDotCursor = true;

function sendKeys(keys) {
  for (const key of keys) rfb.sendKey(key.keysym, key.code, true);
  for (const key of [...keys].reverse()) rfb.sendKey(key.keysym, key.code, false);
  rfb.focus();
}

const keyCombos = {
  cab: [
    { keysym: KeyTable.XK_Control_L, code: 'ControlLeft' },
    { keysym: KeyTable.XK_Alt_L, code: 'AltLeft' },
    { keysym: KeyTable.XK_BackSpace, code: 'Backspace' }
  ],
  alttab: [
    { keysym: KeyTable.XK_Alt_L, code: 'AltLeft' },
    { keysym: KeyTable.XK_Tab, code: 'Tab' }
  ],
  altf4: [
    { keysym: KeyTable.XK_Alt_L, code: 'AltLeft' },
    { keysym: KeyTable.XK_F4, code: 'F4' }
  ],
  ctrlesc: [
    { keysym: KeyTable.XK_Control_L, code: 'ControlLeft' },
    { keysym: KeyTable.XK_Escape, code: 'Escape' }
  ],
  win: [
    { keysym: KeyTable.XK_Super_L, code: 'MetaLeft' }
  ],
  ctrlc: [
    { keysym: KeyTable.XK_Control_L, code: 'ControlLeft' },
    { keysym: 0x0063, code: 'KeyC' }
  ],
  ctrlv: [
    { keysym: KeyTable.XK_Control_L, code: 'ControlLeft' },
    { keysym: 0x0076, code: 'KeyV' }
  ]
};

const keyMenu = document.getElementById('keyMenu');
const keyMenuTrigger = document.getElementById('keyMenuTrigger');
const keyMenuPanel = document.getElementById('keyMenuPanel');

function closeKeyMenu() {
  if (!keyMenuPanel || !keyMenuTrigger) return;
  keyMenuPanel.hidden = true;
  keyMenuTrigger.setAttribute('aria-expanded', 'false');
}

function toggleKeyMenu() {
  if (!keyMenuPanel || !keyMenuTrigger) return;
  const willOpen = keyMenuPanel.hidden;
  keyMenuPanel.hidden = !willOpen;
  keyMenuTrigger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
}

if (keyMenuTrigger) {
  keyMenuTrigger.addEventListener('click', (event) => {
    event.stopPropagation();
    toggleKeyMenu();
  });
}

document.addEventListener('pointerdown', (event) => {
  if (keyMenu && !keyMenu.contains(event.target)) closeKeyMenu();
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && keyMenuPanel && !keyMenuPanel.hidden) {
    event.preventDefault();
    closeKeyMenu();
  }
});

document.querySelectorAll('[data-keycombo]').forEach((button) => {
  button.addEventListener('click', () => {
    const combo = button.dataset.keycombo;
    if (combo === 'cad') {
      rfb.sendCtrlAltDel();
    } else if (/^caf([1-9]|1[0-2])$/.test(combo)) {
      const number = combo.replace('caf', '');
      const keysym = KeyTable['XK_F' + number];
      if (keysym) {
        sendKeys([
          { keysym: KeyTable.XK_Control_L, code: 'ControlLeft' },
          { keysym: KeyTable.XK_Alt_L, code: 'AltLeft' },
          { keysym, code: 'F' + number }
        ]);
      }
    } else if (keyCombos[combo]) {
      sendKeys(keyCombos[combo]);
    }
    closeKeyMenu();
  });
});

function openPastePanel() {
  if (!pastePanel || !pasteCapture) return;
  closeKeyMenu();
  pastePanel.hidden = false;
  pasteCapture.value = '';
  state.textContent = 'Ctrl+V dans la zone de collage';
  setTimeout(() => pasteCapture.focus(), 0);
}

function closePastePanel(refocus = true) {
  if (!pastePanel) return;
  pastePanel.hidden = true;
  if (pasteCapture) pasteCapture.value = '';
  if (refocus) rfb.focus();
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const AZERTY_STROKES = {
  'a': [['KeyQ']], 'b': [['KeyB']], 'c': [['KeyC']], 'd': [['KeyD']],
  'e': [['KeyE']], 'f': [['KeyF']], 'g': [['KeyG']], 'h': [['KeyH']],
  'i': [['KeyI']], 'j': [['KeyJ']], 'k': [['KeyK']], 'l': [['KeyL']],
  'm': [['Semicolon']], 'n': [['KeyN']], 'o': [['KeyO']], 'p': [['KeyP']],
  'q': [['KeyA']], 'r': [['KeyR']], 's': [['KeyS']], 't': [['KeyT']],
  'u': [['KeyU']], 'v': [['KeyV']], 'w': [['KeyZ']], 'x': [['KeyX']],
  'y': [['KeyY']], 'z': [['KeyW']],

  '0': [['ShiftLeft','Digit0']], '1': [['ShiftLeft','Digit1']],
  '2': [['ShiftLeft','Digit2']], '3': [['ShiftLeft','Digit3']],
  '4': [['ShiftLeft','Digit4']], '5': [['ShiftLeft','Digit5']],
  '6': [['ShiftLeft','Digit6']], '7': [['ShiftLeft','Digit7']],
  '8': [['ShiftLeft','Digit8']], '9': [['ShiftLeft','Digit9']],

  ' ': [['Space']], '\t': [['Tab']], '\n': [['Enter']],

  '²': [['Backquote']],
  '&': [['Digit1']], 'é': [['Digit2']], '"': [['Digit3']], "'": [['Digit4']],
  '(': [['Digit5']], '-': [['Digit6']], 'è': [['Digit7']], '_': [['Digit8']],
  'ç': [['Digit9']], 'à': [['Digit0']], ')': [['Minus']], '=': [['Equal']],
  '$': [['BracketRight']], 'ù': [['Quote']], '*': [['Backslash']],
  ',': [['KeyM']], ';': [['Comma']], ':': [['Period']], '!': [['Slash']],

  '.': [['ShiftLeft','Comma']], '/': [['ShiftLeft','Period']],
  '?': [['ShiftLeft','KeyM']], '%': [['ShiftLeft','Quote']],
  '£': [['ShiftLeft','BracketRight']], 'µ': [['ShiftLeft','Backslash']],
  '§': [['ShiftLeft','Slash']], '°': [['ShiftLeft','Minus']],
  '+': [['ShiftLeft','Equal']], '<': [['IntlBackslash']],
  '>': [['ShiftLeft','IntlBackslash']],

  '@': [['AltRight','Digit0']], '#': [['AltRight','Digit3']],
  '{': [['AltRight','Digit4']], '[': [['AltRight','Digit5']],
  '|': [['AltRight','Digit6']], '\\': [['AltRight','Digit8']],
  ']': [['AltRight','Minus']], '}': [['AltRight','Equal']],
  '€': [['AltRight','KeyE']],
  '^': [['BracketLeft'], ['Space']],
  '¨': [['ShiftLeft','BracketLeft'], ['Space']],
  '~': [['AltRight','Digit2'], ['Space']],
  '`': [['AltRight','Digit7'], ['Space']]
};

function dmdSendPhysicalStroke(parts) {
  const pressed = [];

  for (const code of parts) {
    rfb.sendKey(0, code, true);
    pressed.push(code);
  }

  for (const code of pressed.reverse()) {
    rfb.sendKey(0, code, false);
  }
}

function dmdSendAzertyChar(ch) {
  const lower = ch.toLocaleLowerCase('fr-FR');
  let strokes = AZERTY_STROKES[ch] || AZERTY_STROKES[lower] || null;

  if (ch >= 'A' && ch <= 'Z') {
    const base = AZERTY_STROKES[lower];
    if (base && base.length === 1) {
      strokes = [['ShiftLeft', ...base[0]]];
    }
  }

  if (!strokes) return false;

  for (const stroke of strokes) {
    dmdSendPhysicalStroke(stroke);
  }
  return true;
}
async function typeTextIntoVm(text) {
  text = String(text || '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  if (!text || typingPaste) return;

  typingPaste = true;
  const chars = Array.from(text);
  state.textContent = `Collage AZERTY vers la VM… ${chars.length} caractère${chars.length > 1 ? 's' : ''}`;
  rfb.focus();

  try {
    for (let i = 0; i < chars.length; i++) {
      const ch = chars[i];

      if (!dmdSendAzertyChar(ch)) {
        const cp = ch.codePointAt(0);
        const keysym = Keysyms.lookup(cp);
        rfb.sendKey(keysym, null, true);
        rfb.sendKey(keysym, null, false);
      }

      if ((i + 1) % 20 === 0) {
        await sleep(6);
      }
    }

    state.textContent = 'Texte PC envoyé à la VM · AZERTY';
  } catch (error) {
    console.error('[DMD-Proxmox] collage AZERTY impossible', error);
    state.textContent = 'Échec du collage PC → VM';
  } finally {
    typingPaste = false;
    rfb.focus();
  }
}

if (pasteBtn) {
  pasteBtn.addEventListener('click', () => openPastePanel());
}

if (pasteClose) {
  pasteClose.addEventListener('click', () => closePastePanel());
}

if (pasteCapture) {
  pasteCapture.addEventListener('paste', async (event) => {
    const text = event.clipboardData ? event.clipboardData.getData('text/plain') : '';
    if (!text) return;
    event.preventDefault();
    closePastePanel(false);
    await typeTextIntoVm(text);
  });

  pasteCapture.addEventListener('keydown', async (event) => {
    if (event.key === 'Escape') {
      event.preventDefault();
      closePastePanel();
      return;
    }
    if (event.key === 'Enter' && event.ctrlKey) {
      event.preventDefault();
      const text = pasteCapture.value;
      closePastePanel(false);
      await typeTextIntoVm(text);
    }
  });
}

if (pasteSend) {
  pasteSend.addEventListener('click', async () => {
    const text = pasteCapture ? pasteCapture.value : '';
    if (!text) {
      if (pasteCapture) pasteCapture.focus();
      return;
    }
    closePastePanel(false);
    await typeTextIntoVm(text);
  });
}

copyBtn.addEventListener('click', async () => {
  if (!vmClipboard) return;
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(vmClipboard);
    } else {
      const helper = document.createElement('textarea');
      helper.value = vmClipboard;
      helper.setAttribute('readonly', 'readonly');
      helper.style.position = 'fixed';
      helper.style.opacity = '0';
      document.body.appendChild(helper);
      helper.select();
      const copied = document.execCommand('copy');
      helper.remove();
      if (!copied) throw new Error('Copie refusée');
    }
    state.textContent = 'Presse-papiers VM copié sur le PC';
    rfb.focus();
  } catch (error) {
    state.textContent = 'Copie navigateur refusée';
  }
});

rfb.addEventListener('clipboard', (event) => {
  vmClipboard = event.detail && typeof event.detail.text === 'string' ? event.detail.text : '';
  copyBtn.disabled = vmClipboard === '';
  if (vmClipboard !== '') state.textContent = 'Presse-papiers VM disponible';
});

rfb.addEventListener('connect', () => {
  state.textContent = 'Connecté · clavier / souris actifs';
  rfb.focus();
});
rfb.addEventListener('disconnect', (event) => {
  
  state.textContent = event.detail && event.detail.clean ? 'Déconnecté' : 'Connexion interrompue';
});
rfb.addEventListener('credentialsrequired', (event) => {
  
  rfb.sendCredentials({ password });
});
rfb.addEventListener('securityfailure', (event) => {
  
  state.textContent = 'Authentification Remote refusée';
});
</script>
</body>
</html>
