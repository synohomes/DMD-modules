<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
require_once __DIR__ . '/DMD-Proxmox_lib.php';
require_once __DIR__ . '/DMD-Proxmox_provision.php';

if (!function_exists('dmd_proxmox_actionhub_operation')) {
    function dmd_proxmox_actionhub_operation($actionId) {
        $map = array(
            'vm.start' => 'start',
            'vm.shutdown' => 'shutdown',
            'vm.reboot' => 'reboot',
            'vm.stop' => 'stop',
            'vm.reset' => 'reset',
            'vm.create' => 'create'
        );
        return isset($map[$actionId]) ? $map[$actionId] : '';
    }
}

if (!function_exists('dmd_proxmox_actionhub_cached_vms')) {
    function dmd_proxmox_actionhub_cached_vms($server) {
        $cache = dmd_proxmox_read_cache($server);
        if (!is_array($cache) || !isset($cache['vms']) || !is_array($cache['vms'])) return array();
        return $cache['vms'];
    }
}

if (!function_exists('dmd_proxmox_actionhub_target_options')) {
    function dmd_proxmox_actionhub_target_options($email, $capability) {
        $email = trim((string)$email);
        $capability = trim((string)$capability);
        if ($email === '' || $capability === '') return array();

        $options = array();
        foreach (dmd_proxmox_list_servers(false) as $server) {
            if (!is_array($server)) continue;

            $serverId = !empty($server['id'])
                ? trim((string)$server['id'])
                : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : '');
            if ($serverId === '') continue;

            $serverName = trim((string)(isset($server['name']) ? $server['name'] : $serverId));
            if ($serverName === '') $serverName = $serverId;

            foreach (dmd_proxmox_actionhub_cached_vms($server) as $vm) {
                if (!is_array($vm)) continue;
                $vmid = (int)(isset($vm['vmid']) ? $vm['vmid'] : 0);
                if ($vmid <= 0) continue;

                $type = strtolower(trim((string)(isset($vm['type']) ? $vm['type'] : 'qemu')));
                if ($type !== 'lxc') $type = 'qemu';
                if ($capability === 'vm.reset' && $type !== 'qemu') continue;

                if (!dmd_proxmox_acl_can($email, $serverId, $type, $vmid, $capability)) continue;

                $name = trim((string)(isset($vm['name']) ? $vm['name'] : ''));
                $node = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
                $resource = dmd_proxmox_vm_resource($serverId, $vmid, $type, $name, $node);

                $label = $serverName . ' · ' . strtoupper($type) . ' #' . $vmid;
                if ($name !== '') $label .= ' · ' . $name;
                if ($node !== '') $label .= ' [' . $node . ']';

                $options[] = array(
                    'value' => $resource['id'],
                    'label' => $label
                );
            }
        }

        usort($options, function($a, $b) {
            return strcasecmp((string)$a['label'], (string)$b['label']);
        });
        return $options;
    }
}

if (!function_exists('dmd_proxmox_actionhub_catalog')) {

    function dmd_proxmox_actionhub_catalog($context) {
        if (!is_array($context)) return array('replace' => true, 'actions' => array());

        $email = trim((string)(isset($context['email']) ? $context['email'] : ''));
        $resource = isset($context['resource']) && is_array($context['resource']) ? $context['resource'] : null;
        $baseActions = isset($context['actions']) && is_array($context['actions']) ? $context['actions'] : array();
        $out = array();

        if (is_array($resource)) {
            $resourceId = trim((string)(isset($resource['id']) ? $resource['id'] : ''));
            $resourceType = strtolower(trim((string)(isset($resource['type']) ? $resource['type'] : '')));
            $parsed = $resourceType === 'proxmox_vm' ? dmd_proxmox_parse_vm_resource_id($resourceId) : null;
            if (!is_array($parsed)) return array('replace' => true, 'actions' => array());

            foreach ($baseActions as $action) {
                if (!is_array($action)) continue;
                $actionId = trim((string)(isset($action['id']) ? $action['id'] : ''));
                $operation = dmd_proxmox_actionhub_operation($actionId);
                if ($operation === '') continue;

                if ($operation === 'create') continue;
                $capability = 'vm.' . $operation;
                if (!dmd_proxmox_acl_can($email, $parsed['server_id'], $parsed['type'], $parsed['vmid'], $capability)) continue;
                if ($operation === 'reset' && $parsed['type'] !== 'qemu') continue;

                $dynamic = $action;
                $dynamic['scope'] = 'resource';
                $dynamic['scenario'] = false;
                $dynamic['resource_types'] = array('proxmox_vm');
                $dynamic['inputs'] = array();
                $out[] = $dynamic;
            }

            return array('replace' => true, 'actions' => $out);
        }

        foreach ($baseActions as $action) {
            if (!is_array($action)) continue;
            $actionId = trim((string)(isset($action['id']) ? $action['id'] : ''));
            $operation = dmd_proxmox_actionhub_operation($actionId);
            if ($operation === '') continue;

            $permission = trim((string)(isset($action['permission']) ? $action['permission'] : ('vm.' . $operation)));
            $dynamic = $action;
            $dynamic['scope'] = 'module';
            $dynamic['scenario'] = true;
            unset($dynamic['resource_types']);

            if ($operation === 'create') {
                $presetOptions = array();
                foreach (dmd_proxmox_presets_list(true) as $preset) {
                    $presetOptions[] = array(
                        'value' => $preset['id'],
                        'label' => $preset['label'] . ' · ' . $preset['cpu'] . ' CPU · ' . $preset['ram'] . ' Mo · ' . $preset['disk'] . ' Go'
                            . ((int)$preset['vlan'] > 0 ? ' · VLAN ' . (int)$preset['vlan'] : '')
                    );
                }
                $dynamic['group'] = 'Provisionnement';
                $dynamic['inputs'] = array(
                    array(
                        'id' => 'preset',
                        'label' => 'Preset VM',
                        'type' => 'select',
                        'required' => true,
                        'help' => 'Configuration préparée dans le CFG DMD-Proxmox : ISO, CPU, RAM, disque, stockage, bridge et VLAN.',
                        'options' => $presetOptions
                    ),
                    array(
                        'id' => 'quantity',
                        'label' => 'Quantité',
                        'type' => 'number',
                        'required' => true,
                        'default' => 1,
                        'help' => 'Chaque VM reçoit automatiquement un VMID libre et un nom unique.'
                    ),
                    array(
                        'id' => 'after_create',
                        'label' => 'Après création',
                        'type' => 'select',
                        'required' => true,
                        'default' => 'preset',
                        'options' => array(
                            array('value'=>'preset','label'=>'Utiliser le réglage du preset'),
                            array('value'=>'none','label'=>'Ne rien ouvrir'),
                            array('value'=>'vm','label'=>'Ouvrir la fiche VM'),
                            array('value'=>'remote','label'=>'Ouvrir directement le Remote')
                        )
                    ),
                    array(
                        'id' => 'open_count',
                        'label' => 'Si plusieurs VM',
                        'type' => 'select',
                        'required' => true,
                        'default' => 'preset',
                        'options' => array(
                            array('value'=>'preset','label'=>'Utiliser le réglage du preset'),
                            array('value'=>'first','label'=>'Ouvrir uniquement la première'),
                            array('value'=>'all','label'=>'Ouvrir toutes les VM créées')
                        )
                    )
                );
            } else {
                $dynamic['group'] = 'VM / CT';
                $dynamic['inputs'] = array(array(
                    'id' => 'target',
                    'label' => 'VM / CT',
                    'type' => 'select',
                    'required' => true,
                    'help' => 'VM/CT accessibles pour cette action selon tes droits DoMyDesk et les ACL fines DMD-Proxmox.',
                    'options' => dmd_proxmox_actionhub_target_options($email, $permission)
                ));
            }
            $out[] = $dynamic;
        }

        return array('replace' => true, 'actions' => $out);
    }
}

if (!function_exists('dmd_proxmox_actionhub_handle')) {
    function dmd_proxmox_actionhub_handle($context) {
        if (!is_array($context)) {
            return array('ok'=>false, 'error'=>'invalid_context', 'message'=>'Contexte ActionHub invalide.');
        }

        $email = trim((string)(isset($context['email']) ? $context['email'] : ''));
        $actionDef = isset($context['action']) && is_array($context['action']) ? $context['action'] : array();
        $resource = isset($context['resource']) && is_array($context['resource']) ? $context['resource'] : array();
        $payload = isset($context['payload']) && is_array($context['payload']) ? $context['payload'] : array();
        $actionId = trim((string)(isset($actionDef['id']) ? $actionDef['id'] : ''));
        $scope = strtolower(trim((string)(isset($actionDef['scope']) ? $actionDef['scope'] : 'resource')));
        $operation = dmd_proxmox_actionhub_operation($actionId);

        if ($operation === '') {
            return array('ok'=>false, 'error'=>'unknown_action', 'message'=>'Action DMD-Proxmox inconnue.');
        }

        if ($operation === 'create') {
            if ($scope !== 'module') {
                return array('ok'=>false, 'error'=>'invalid_scope', 'message'=>'La création de VM est une action de scénario/module.');
            }
            $presetId = trim((string)(isset($payload['preset']) ? $payload['preset'] : ''));
            $quantity = max(1, (int)(isset($payload['quantity']) ? $payload['quantity'] : 1));
            $after = trim((string)(isset($payload['after_create']) ? $payload['after_create'] : 'preset'));
            $openCount = trim((string)(isset($payload['open_count']) ? $payload['open_count'] : 'preset'));
            $created = dmd_proxmox_create_from_preset($presetId, $quantity, $email, $after, $openCount);
            if (empty($created['ok'])) {
                return array(
                    'ok'=>false,
                    'error'=>isset($created['error']) ? $created['error'] : 'create_failed',
                    'message'=>isset($created['message']) ? $created['message'] : 'Création VM impossible.',
                    'data'=>array('created'=>isset($created['created']) ? $created['created'] : array())
                );
            }

            $ui = array(
                'type' => 'proxmox-created-vms',
                'mode' => isset($created['after_create']) ? $created['after_create'] : 'none',
                'open_count' => isset($created['open_count']) ? $created['open_count'] : 'first',
                'vms' => isset($created['created']) ? $created['created'] : array()
            );
            return array(
                'ok'=>true,
                'message'=>$created['message'],
                'data'=>array(
                    'reload'=>true,
                    'created'=>$created['created'],
                    'ui'=>$ui
                ),
                'event_emitted'=>true
            );
        }

        $resourceId = '';
        if ($scope === 'module') {
            $resourceId = trim((string)(isset($payload['target']) ? $payload['target'] : ''));
        } else {
            $resourceId = trim((string)(isset($resource['id']) ? $resource['id'] : ''));
        }

        $parsed = dmd_proxmox_parse_vm_resource_id($resourceId);
        if (!is_array($parsed)) {
            return array(
                'ok'=>false,
                'error'=>'invalid_resource',
                'message'=>$scope === 'module'
                    ? 'Aucune VM/CT Proxmox valide n’a été sélectionnée dans le scénario.'
                    : 'Ressource VM/CT Proxmox invalide.'
            );
        }
        $capability = 'vm.' . $operation;
        if (!dmd_proxmox_acl_can($email, $parsed['server_id'], $parsed['type'], $parsed['vmid'], $capability)) {
            return array('ok'=>false, 'error'=>'permission_denied', 'message'=>'Action interdite par les droits de cette VM/CT.');
        }

        $result = dmd_proxmox_vm_action_execute(
            $parsed['server_id'],
            $parsed['vmid'],
            $parsed['type'],
            $operation,
            $email,
            $scope === 'module' ? 'scenario' : 'actionhub'
        );

        return array(
            'ok' => !empty($result['ok']),
            'error' => !empty($result['ok']) ? '' : (isset($result['error']) ? $result['error'] : 'action_failed'),
            'message' => isset($result['message']) ? $result['message'] : (!empty($result['ok']) ? 'Action envoyée.' : 'Action refusée.'),
            'data' => array(
                'reload' => !empty($result['ok']),
                'server_id' => $parsed['server_id'],
                'type' => $parsed['type'],
                'vmid' => $parsed['vmid']
            ),
            'event_emitted' => true
        );
    }
}
