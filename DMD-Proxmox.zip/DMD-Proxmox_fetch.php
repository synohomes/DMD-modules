<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';

if (!dmd_proxmox_has_module_access() || !dmd_proxmox_user_can('refresh')) {
    http_response_code(403);
    exit('Module DMD-Proxmox non autorisé pour cet utilisateur.');
}
if (!dmd_proxmox_csrf_valid(isset($_GET['csrf']) ? $_GET['csrf'] : (isset($_POST['csrf']) ? $_POST['csrf'] : ''))) {
    dmd_proxmox_json(false, 'Jeton de sécurité expiré.', array(), 403);
}

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$storage = dmd_proxmox_storage_paths();
$lockPath = rtrim($storage['cache'], '/\\') . DIRECTORY_SEPARATOR . '.refresh.lock';
$lockFp = @fopen($lockPath, 'c+');
if ($lockFp && !@flock($lockFp, LOCK_EX | LOCK_NB)) {
    echo json_encode(array('ok' => true, 'skipped' => true, 'message' => 'Actualisation DMD-Proxmox déjà en cours.'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    fclose($lockFp);
    exit;
}

$servers = dmd_proxmox_list_servers(false);

$requestedServerId = trim((string)(
    isset($_GET['server_id']) ? $_GET['server_id']
    : (isset($_POST['server_id']) ? $_POST['server_id'] : '')
));

if ($requestedServerId !== '') {
    $servers = array_values(array_filter($servers, function($server) use ($requestedServerId) {
        if (!is_array($server)) return false;
        $id = isset($server['id'])
            ? (string)$server['id']
            : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : 'server');
        return hash_equals($requestedServerId, $id);
    }));
}
if (!$servers) {
    echo json_encode(array(
        'ok' => $requestedServerId === '',
        'servers' => array(),
        'message' => $requestedServerId !== ''
            ? 'Serveur Proxmox demandé introuvable.'
            : 'Aucun serveur défini.'
    ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$report = array();
foreach ($servers as $server) {
    $id = isset($server['id']) ? $server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : 'server');
    $name = isset($server['name']) ? $server['name'] : $id;
    $cache = array(
        'server_id' => $id,
        'server_name' => $name,
        'version' => null,
        'nodes' => array(),
        'cluster' => array(
            'nodes_total' => 0,
            'nodes_online' => 0,
            'cpu' => 0,
            'mem' => 0,
            'maxmem' => 0,
            'disk' => 0,
            'maxdisk' => 0
        ),
        'vms' => array(),
        'error' => null
    );

    $version = dmd_proxmox_api($server, 'version', 'GET', null, 10);
    if ($version['ok']) {
        $cache['version'] = $version['data'];
    } else {
        $cache['error'] = array('where' => 'version', 'code' => $version['error']);
        dmd_proxmox_write_cache($server, $cache);
        $report[] = array('id' => $id, 'name' => $name, 'ok' => false, 'error' => $version['error']);
        continue;
    }

    $nodesRes = dmd_proxmox_api($server, 'nodes', 'GET', null, 12);
    if ($nodesRes['ok'] && is_array($nodesRes['data'])) {
        $cache['nodes'] = $nodesRes['data'];
        $weightedCpu = 0.0;
        $cpuWeight = 0.0;
        foreach ($nodesRes['data'] as $node) {
            if (!is_array($node)) continue;
            $cache['cluster']['nodes_total']++;
            if (strtolower((string)(isset($node['status']) ? $node['status'] : '')) === 'online') $cache['cluster']['nodes_online']++;
            $maxcpu = (float)(isset($node['maxcpu']) ? $node['maxcpu'] : 0);
            $cpu = (float)(isset($node['cpu']) ? $node['cpu'] : 0);
            if ($maxcpu > 0) {
                $weightedCpu += ($cpu * $maxcpu);
                $cpuWeight += $maxcpu;
            }
            $cache['cluster']['mem'] += (float)(isset($node['mem']) ? $node['mem'] : 0);
            $cache['cluster']['maxmem'] += (float)(isset($node['maxmem']) ? $node['maxmem'] : 0);
            $cache['cluster']['disk'] += (float)(isset($node['disk']) ? $node['disk'] : 0);
            $cache['cluster']['maxdisk'] += (float)(isset($node['maxdisk']) ? $node['maxdisk'] : 0);
        }
        $cache['cluster']['cpu'] = $cpuWeight > 0 ? ($weightedCpu / $cpuWeight) : 0;
    } else {
        $cache['error'] = array('where' => 'nodes', 'code' => $nodesRes['error']);
    }

    $vmsRes = dmd_proxmox_cluster_vms($server);
    if ($vmsRes['ok']) {
        $vms = array();
        foreach ($vmsRes['data'] as $vm) {
            if (!is_array($vm)) continue;
            $type = strtolower((string)(isset($vm['type']) ? $vm['type'] : 'qemu'));
            if ($type !== 'qemu' && $type !== 'lxc') $type = 'qemu';
            $vm['type'] = $type;
            $vms[] = $vm;
        }
        usort($vms, function($a, $b) {
            $na = (string)(isset($a['node']) ? $a['node'] : '');
            $nb = (string)(isset($b['node']) ? $b['node'] : '');
            if ($na !== $nb) return strcasecmp($na, $nb);
            return ((int)(isset($a['vmid']) ? $a['vmid'] : 0)) - ((int)(isset($b['vmid']) ? $b['vmid'] : 0));
        });
        $cache['vms'] = $vms;
    } else {
        $cache['error'] = array('where' => 'vms', 'code' => $vmsRes['error']);
    }

    dmd_proxmox_write_cache($server, $cache);
    $report[] = array(
        'id' => $id,
        'name' => $name,
        'ok' => empty($cache['error']),
        'nodes' => $cache['cluster']['nodes_total'],
        'vms' => count($cache['vms']),
        'error' => $cache['error']
    );
}

if ($lockFp) { @flock($lockFp, LOCK_UN); @fclose($lockFp); }
echo json_encode(array('ok' => true, 'servers' => $report, 'updated_at' => date('c')), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
