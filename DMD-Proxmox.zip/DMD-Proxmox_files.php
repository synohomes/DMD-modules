<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';

if (!dmd_proxmox_has_module_access()) {
    dmd_proxmox_json(false, 'Accès DMD-Proxmox refusé.', array(), 403);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dmd_proxmox_json(false, 'Méthode refusée.', array(), 405);
}
if (!dmd_proxmox_csrf_valid(isset($_POST['csrf']) ? $_POST['csrf'] : '')) {
    dmd_proxmox_json(false, 'Jeton de sécurité expiré.', array(), 403);
}

function dmdpx_files_binary() {
    $candidates = array('/usr/bin/smbclient', '/usr/local/bin/smbclient', '/opt/bin/smbclient', '/opt/local/bin/smbclient');
    $path = (string)getenv('PATH');
    foreach (explode(PATH_SEPARATOR, $path) as $dir) {
        $dir = rtrim(trim($dir), '/\\');
        if ($dir !== '') $candidates[] = $dir . DIRECTORY_SEPARATOR . 'smbclient';
    }
    foreach (array_unique($candidates) as $candidate) {
        if (is_file($candidate) && is_executable($candidate)) return $candidate;
    }
    return '';
}

function dmdpx_files_host($value) {
    $value = trim((string)$value);
    if ($value === '' || strlen($value) > 253) return '';
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]*$/', $value)) return '';
    return $value;
}

function dmdpx_files_share($value) {
    $value = trim((string)$value);
    if ($value === '' || strlen($value) > 128) return '';
    if (preg_match('/[\\\/\r\n\x00";]/', $value)) return '';
    return $value;
}

function dmdpx_files_credential($value, $max) {
    $value = (string)$value;
    if (strlen($value) > $max || preg_match('/[\r\n\x00]/', $value)) return null;
    return $value;
}

function dmdpx_files_path($value, $allowEmpty) {
    $value = str_replace('\\', '/', trim((string)$value));
    $value = trim($value, '/');
    if ($value === '') return $allowEmpty ? '' : null;
    if (strlen($value) > 2048 || preg_match('/[\r\n\x00";]/', $value)) return null;
    $parts = array();
    foreach (explode('/', $value) as $part) {
        $part = trim($part);
        if ($part === '' || $part === '.') continue;
        if ($part === '..') return null;
        if (strlen($part) > 255) return null;
        $parts[] = $part;
    }
    if (!$parts) return $allowEmpty ? '' : null;
    return implode('/', $parts);
}

function dmdpx_files_smb_quote($path) {
    return '"' . (string)$path . '"';
}

function dmdpx_files_auth_file($username, $password, $domain) {
    if ($username === '' && $password === '' && $domain === '') return '';
    $paths = dmd_proxmox_storage_paths();
    $dir = isset($paths['remote']) ? $paths['remote'] : (rtrim($paths['root'], '/\\') . DIRECTORY_SEPARATOR . 'remote');
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    $file = $dir . DIRECTORY_SEPARATOR . '.smb-auth-' . bin2hex(random_bytes(12));
    $body = 'username = ' . $username . "\n" . 'password = ' . $password . "\n";
    if ($domain !== '') $body .= 'domain = ' . $domain . "\n";
    if (@file_put_contents($file, $body, LOCK_EX) === false) return false;
    @chmod($file, 0600);
    return $file;
}

function dmdpx_files_run($host, $share, $username, $password, $domain, $smbCommand) {
    $bin = dmdpx_files_binary();
    if ($bin === '') return array(false, '', 'smbclient est absent sur l’hôte DoMyDesk.');
    $authFile = dmdpx_files_auth_file($username, $password, $domain);
    if ($authFile === false) return array(false, '', 'Impossible de préparer l’authentification SMB temporaire.');

    $service = '//' . $host . '/' . $share;
    $cmd = 'LC_ALL=C ' . escapeshellarg($bin) . ' ' . escapeshellarg($service) . ' -d 0 -t 15 -m SMB3 ';
    if ($authFile === '') $cmd .= '-N ';
    else $cmd .= '-A ' . escapeshellarg($authFile) . ' ';
    $cmd .= '-c ' . escapeshellarg($smbCommand);

    $spec = array(0=>array('pipe','r'), 1=>array('pipe','w'), 2=>array('pipe','w'));
    $pipes = array();
    $proc = @proc_open($cmd, $spec, $pipes);
    if (!is_resource($proc)) {
        if ($authFile !== '') @unlink($authFile);
        return array(false, '', 'Impossible de lancer smbclient.');
    }
    fclose($pipes[0]);
    $stdout = stream_get_contents($pipes[1]);
    $stderr = stream_get_contents($pipes[2]);
    fclose($pipes[1]); fclose($pipes[2]);
    $code = proc_close($proc);
    if ($authFile !== '') @unlink($authFile);
    $message = trim((string)$stderr);
    if ($message === '') $message = trim((string)$stdout);
    return array($code === 0, (string)$stdout, $message);
}


function dmdpx_files_run_shares($host, $username, $password, $domain) {
    $bin = dmdpx_files_binary();
    if ($bin === '') return array(false, '', 'smbclient est absent sur l’hôte DoMyDesk.');

    $authFile = dmdpx_files_auth_file($username, $password, $domain);
    if ($authFile === false) return array(false, '', 'Impossible de préparer l’authentification SMB temporaire.');
    $cmd = 'LC_ALL=C ' . escapeshellarg($bin)
         . ' -L ' . escapeshellarg($host)
         . ' -g -d 0 -t 15 -m SMB3 ';

    if ($authFile === '') $cmd .= '-N ';
    else $cmd .= '-A ' . escapeshellarg($authFile) . ' ';

    $spec = array(0=>array('pipe','r'), 1=>array('pipe','w'), 2=>array('pipe','w'));
    $pipes = array();
    $proc = @proc_open($cmd, $spec, $pipes);

    if (!is_resource($proc)) {
        if ($authFile !== '') @unlink($authFile);
        return array(false, '', 'Impossible de lancer smbclient.');
    }

    fclose($pipes[0]);
    $stdout = stream_get_contents($pipes[1]);
    $stderr = stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);

    $code = proc_close($proc);
    if ($authFile !== '') @unlink($authFile);

    $message = trim((string)$stderr);
    if ($message === '') $message = trim((string)$stdout);

    return array($code === 0, (string)$stdout, $message);
}

function dmdpx_files_parse_shares($stdout) {
    $out = array();

    foreach (preg_split('/\r?\n/', (string)$stdout) as $line) {
        $line = trim($line);
        if ($line === '') continue;

        $parts = explode('|', $line, 3);
        if (count($parts) < 2) continue;

        $type = strtolower(trim((string)$parts[0]));
        $name = trim((string)$parts[1]);
        $comment = isset($parts[2]) ? trim((string)$parts[2]) : '';
        if ($type !== 'disk') continue;
        if ($name === '' || dmdpx_files_share($name) === '') continue;

        $out[] = array(
            'name' => $name,
            'comment' => $comment,
            'hidden' => substr($name, -1) === '$'
        );
    }

    usort($out, function($a, $b) {
        if (!empty($a['hidden']) !== !empty($b['hidden'])) {
            return !empty($a['hidden']) ? 1 : -1;
        }
        return strcasecmp((string)$a['name'], (string)$b['name']);
    });

    return $out;
}

function dmdpx_files_has_credentials($username, $password, $domain) {
    return trim((string)$username) !== '' || (string)$password !== '' || trim((string)$domain) !== '';
}

function dmdpx_files_auth_failed($message) {
    $message = strtoupper((string)$message);
    foreach (array(
        'NT_STATUS_LOGON_FAILURE',
        'NT_STATUS_WRONG_PASSWORD',
        'NT_STATUS_PASSWORD_EXPIRED',
        'NT_STATUS_PASSWORD_MUST_CHANGE',
        'NT_STATUS_ACCOUNT_DISABLED',
        'NT_STATUS_ACCOUNT_EXPIRED',
        'NT_STATUS_ACCOUNT_LOCKED_OUT',
        'LOGON FAILURE',
        'WRONG PASSWORD'
    ) as $needle) {
        if (strpos($message, $needle) !== false) return true;
    }
    return false;
}

function dmdpx_files_access_denied($message) {
    $message = strtoupper((string)$message);
    return strpos($message, 'NT_STATUS_ACCESS_DENIED') !== false
        || strpos($message, 'ACCESS DENIED') !== false;
}

function dmdpx_files_probe_admin_shares($host, $username, $password, $domain) {
    $out = array();
    foreach (array('C$','D$','E$') as $share) {
        list($ok, $stdout, $error) = dmdpx_files_run(
            $host, $share, $username, $password, $domain, 'ls'
        );
        if ($ok) {
            $out[] = array(
                'name' => $share,
                'comment' => 'Disque administrateur',
                'hidden' => true
            );
        }
    }
    return $out;
}

function dmdpx_files_parse_list($stdout) {
    $out = array();
    foreach (preg_split('/\r?\n/', (string)$stdout) as $line) {
        $line = rtrim($line);
        if ($line === '') continue;
        if (!preg_match('/^\s*(.*?)\s{2,}([A-Z]+)\s+(\d+)\s{2,}(.+)$/', $line, $m)) continue;
        $name = rtrim((string)$m[1]);
        if ($name === '' || $name === '.' || $name === '..') continue;
        $attr = strtoupper((string)$m[2]);
        $out[] = array(
            'name' => $name,
            'directory' => strpos($attr, 'D') !== false,
            'size' => (int)$m[3],
            'attributes' => $attr,
            'date' => trim((string)$m[4])
        );
    }
    usort($out, function($a, $b) {
        if (!empty($a['directory']) !== !empty($b['directory'])) return !empty($a['directory']) ? -1 : 1;
        return strcasecmp((string)$a['name'], (string)$b['name']);
    });
    return $out;
}

function dmdpx_files_remote_command($path, $command) {
    $path = dmdpx_files_path($path, true);
    if ($path === null) return null;
    return ($path !== '' ? ('cd ' . dmdpx_files_smb_quote($path) . '; ') : '') . $command;
}

function dmdpx_files_list_remote($host, $share, $username, $password, $domain, $path, &$error) {
    $cmd = dmdpx_files_remote_command($path, 'ls');
    if ($cmd === null) { $error = 'Chemin SMB invalide.'; return false; }
    list($ok, $stdout, $err) = dmdpx_files_run($host, $share, $username, $password, $domain, $cmd);
    if (!$ok) { $error = $err; return false; }
    return dmdpx_files_parse_list($stdout);
}

function dmdpx_files_make_remote_dir($host, $share, $username, $password, $domain, $parent, $name, &$error) {
    $safeName = dmdpx_files_path($name, false);
    if ($safeName === null || strpos($safeName, '/') !== false) { $error = 'Nom de dossier invalide.'; return false; }
    $cmd = dmdpx_files_remote_command($parent, 'mkdir ' . dmdpx_files_smb_quote($safeName));
    if ($cmd === null) { $error = 'Chemin destination invalide.'; return false; }
    list($ok, $stdout, $err) = dmdpx_files_run($host, $share, $username, $password, $domain, $cmd);
    if (!$ok && stripos($err, 'NT_STATUS_OBJECT_NAME_COLLISION') === false) { $error = $err; return false; }
    return true;
}

function dmdpx_files_copy_one_file($src, $dst, $srcPath, $dstPath, $name, &$error) {
    $safeName = dmdpx_files_path($name, false);
    if ($safeName === null || strpos($safeName, '/') !== false) { $error = 'Nom de fichier invalide.'; return false; }

    $tmp = @tempnam(sys_get_temp_dir(), 'dmdpx-');
    if ($tmp === false) { $error = 'Fichier temporaire impossible.'; return false; }
    @chmod($tmp, 0600);

    $srcCmd = dmdpx_files_remote_command($srcPath, 'get ' . dmdpx_files_smb_quote($safeName) . ' ' . dmdpx_files_smb_quote($tmp));
    if ($srcCmd === null) { @unlink($tmp); $error = 'Chemin source invalide.'; return false; }
    list($okGet, $stdoutGet, $errGet) = dmdpx_files_run($src['host'], $src['share'], $src['username'], $src['password'], $src['domain'], $srcCmd);
    if (!$okGet) { @unlink($tmp); $error = $errGet; return false; }

    $dstCmd = dmdpx_files_remote_command($dstPath, 'put ' . dmdpx_files_smb_quote($tmp) . ' ' . dmdpx_files_smb_quote($safeName));
    if ($dstCmd === null) { @unlink($tmp); $error = 'Chemin destination invalide.'; return false; }
    list($okPut, $stdoutPut, $errPut) = dmdpx_files_run($dst['host'], $dst['share'], $dst['username'], $dst['password'], $dst['domain'], $dstCmd);
    @unlink($tmp);
    if (!$okPut) { $error = $errPut; return false; }
    return true;
}

function dmdpx_files_copy_tree($src, $dst, $srcParent, $dstParent, $name, &$stats, &$error, $depth = 0) {
    if ($depth > 32) { $error = 'Profondeur maximale de dossiers atteinte.'; return false; }
    if (($stats['files'] + $stats['dirs']) > 5000) { $error = 'Copie limitée à 5000 éléments par opération.'; return false; }

    $safeName = dmdpx_files_path($name, false);
    if ($safeName === null || strpos($safeName, '/') !== false) { $error = 'Nom invalide.'; return false; }

    $srcDir = implode('/', array_filter(array($srcParent, $safeName), 'strlen'));
    if (!dmdpx_files_make_remote_dir($dst['host'], $dst['share'], $dst['username'], $dst['password'], $dst['domain'], $dstParent, $safeName, $error)) return false;
    $stats['dirs']++;
    $dstDir = implode('/', array_filter(array($dstParent, $safeName), 'strlen'));

    $entries = dmdpx_files_list_remote($src['host'], $src['share'], $src['username'], $src['password'], $src['domain'], $srcDir, $error);
    if ($entries === false) return false;

    foreach ($entries as $entry) {
        if (!is_array($entry) || empty($entry['name'])) continue;
        if (!empty($entry['directory'])) {
            if (!dmdpx_files_copy_tree($src, $dst, $srcDir, $dstDir, $entry['name'], $stats, $error, $depth + 1)) return false;
        } else {
            if (!dmdpx_files_copy_one_file($src, $dst, $srcDir, $dstDir, $entry['name'], $error)) return false;
            $stats['files']++;
        }
    }
    return true;
}

function dmdpx_files_context() {
    $serverId = trim((string)(isset($_POST['server_id']) ? $_POST['server_id'] : ''));
    $vmid = (int)(isset($_POST['vmid']) ? $_POST['vmid'] : 0);
    $type = strtolower(trim((string)(isset($_POST['type']) ? $_POST['type'] : 'qemu')));
    if ($type !== 'lxc') $type = 'qemu';
    $server = dmd_proxmox_load_server($serverId);
    if (!is_array($server) || $vmid <= 0) dmd_proxmox_json(false, 'VM/CT invalide.', array(), 404);
    $email = dmd_proxmox_user_email();
    if (!dmd_proxmox_acl_can($email, $serverId, $type, $vmid, 'vm.files')) {
        dmd_proxmox_json(false, 'Droit fichiers réseau refusé pour cette VM/CT.', array(), 403);
    }
    $vm = dmd_proxmox_resolve_vm($server, $vmid, $type);
    if (!is_array($vm)) dmd_proxmox_json(false, 'VM/CT introuvable sur Proxmox.', array(), 404);
    return array($serverId, $server, $vmid, $type, $vm);
}

function dmdpx_files_ipv4_valid($value) {
    $value = trim((string)$value);
    if (!filter_var($value, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return '';
    if (strpos($value, '127.') === 0 || strpos($value, '169.254.') === 0) return '';
    return $value;
}

function dmdpx_files_hosts_file() {
    $paths = dmd_proxmox_storage_paths();
    $cfg = isset($paths['cfg']) ? $paths['cfg'] : (rtrim($paths['root'], '/\\') . DIRECTORY_SEPARATOR . 'cfg');
    if (!is_dir($cfg)) @mkdir($cfg, 0750, true);
    return rtrim($cfg, '/\\') . DIRECTORY_SEPARATOR . 'files_hosts.json';
}

function dmdpx_files_hosts_read() {
    $file = dmdpx_files_hosts_file();
    if (!is_file($file)) return array();
    $data = json_decode((string)@file_get_contents($file), true);
    return is_array($data) ? $data : array();
}

function dmdpx_files_hosts_write($data) {
    if (!is_array($data)) $data = array();
    $file = dmdpx_files_hosts_file();
    $ok = @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
    if ($ok) @chmod($file, 0640);
    return $ok;
}

function dmdpx_files_vm_host_key($serverId, $type, $vmid) {
    return strtolower(trim((string)$serverId)) . ':' . strtolower(trim((string)$type)) . ':' . (int)$vmid;
}

function dmdpx_files_saved_host($serverId, $type, $vmid) {
    $all = dmdpx_files_hosts_read();
    $key = dmdpx_files_vm_host_key($serverId, $type, $vmid);
    if (!isset($all[$key]) || !is_array($all[$key])) return '';
    return dmdpx_files_host(isset($all[$key]['host']) ? $all[$key]['host'] : '');
}

function dmdpx_files_save_host($serverId, $type, $vmid, $host, $source) {
    $host = dmdpx_files_host($host);
    if ($host === '') return false;
    $all = dmdpx_files_hosts_read();
    $key = dmdpx_files_vm_host_key($serverId, $type, $vmid);
    $all[$key] = array(
        'host' => $host,
        'source' => trim((string)$source),
        'updated_at' => date('c')
    );
    return dmdpx_files_hosts_write($all);
}

function dmdpx_files_ipv4_from_guest($server, $vmid, $type, $vm) {
    $node = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
    if ($node === '') return '';
    $candidates = array();

    if ($type === 'qemu') {
        $r = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/qemu/' . $vmid . '/agent/network-get-interfaces', 'GET', null, 10);
        if ($r['ok'] && is_array($r['data'])) {
            $rows = isset($r['data']['result']) && is_array($r['data']['result']) ? $r['data']['result'] : $r['data'];
            foreach ($rows as $iface) {
                if (!is_array($iface)) continue;
                $ips = isset($iface['ip-addresses']) && is_array($iface['ip-addresses']) ? $iface['ip-addresses'] : array();
                foreach ($ips as $ip) {
                    if (!is_array($ip)) continue;
                    $addr = dmdpx_files_ipv4_valid(isset($ip['ip-address']) ? $ip['ip-address'] : '');
                    if ($addr !== '') $candidates[] = $addr;
                }
            }
        }
    }

    return $candidates ? $candidates[0] : '';
}

function dmdpx_files_ipv4_from_vm_config($server, $vmid, $type, $vm) {
    $node = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
    if ($node === '') return '';

    $endpoint = 'nodes/' . rawurlencode($node) . '/' . ($type === 'lxc' ? 'lxc' : 'qemu') . '/' . (int)$vmid . '/config';
    $r = dmd_proxmox_api($server, $endpoint, 'GET', null, 10);
    if (!$r['ok'] || !is_array($r['data'])) return '';

    foreach ($r['data'] as $key => $value) {
        if (!is_scalar($value)) continue;
        $key = strtolower((string)$key);
        if (strpos($key, 'ipconfig') !== 0 && strpos($key, 'net') !== 0) continue;
        $value = (string)$value;
        if (preg_match('/(?:^|,)ip=([0-9.]+)(?:\\/\\d+)?(?:,|$)/i', $value, $m)) {
            $ip = dmdpx_files_ipv4_valid($m[1]);
            if ($ip !== '') return $ip;
        }
    }
    return '';
}


function dmdpx_files_mac_normalize($value) {
    $value = strtolower(trim((string)$value));
    $value = str_replace('-', ':', $value);
    if (!preg_match('/^[0-9a-f]{2}(?::[0-9a-f]{2}){5}$/', $value)) return '';
    return $value;
}

function dmdpx_files_vm_macs_from_config($server, $vmid, $type, $vm) {
    $node = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
    if ($node === '') return array();

    $endpoint = 'nodes/' . rawurlencode($node) . '/' . ($type === 'lxc' ? 'lxc' : 'qemu') . '/' . (int)$vmid . '/config';
    $r = dmd_proxmox_api($server, $endpoint, 'GET', null, 10);
    if (!$r['ok'] || !is_array($r['data'])) return array();

    $macs = array();
    foreach ($r['data'] as $key => $value) {
        if (!is_scalar($value)) continue;
        if (strpos(strtolower((string)$key), 'net') !== 0) continue;

        if (preg_match_all('/(?:^|[=,])([0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5})(?:,|$)/', (string)$value, $m)) {
            foreach ($m[1] as $raw) {
                $mac = dmdpx_files_mac_normalize($raw);
                if ($mac !== '') $macs[$mac] = true;
            }
        }
    }

    return array_keys($macs);
}

function dmdpx_files_hostname_variants($value) {
    $value = strtolower(trim((string)$value));
    if ($value === '') return array();

    $value = rtrim($value, '.');
    $out = array($value => true);

    if (strpos($value, '.') !== false) {
        $short = explode('.', $value, 2)[0];
        if ($short !== '') $out[$short] = true;
    }

    return array_keys($out);
}

function dmdpx_files_agent_candidate_ips($agent) {
    if (!is_array($agent)) return array();

    $candidates = array();
    $inv = isset($agent['inventory']) && is_array($agent['inventory']) ? $agent['inventory'] : array();
    $network = isset($inv['network']) && is_array($inv['network']) ? $inv['network'] : array();

    foreach ($network as $iface) {
        if (!is_array($iface)) continue;
        $ips = isset($iface['ips']) && is_array($iface['ips']) ? $iface['ips'] : array();

        foreach ($ips as $raw) {
            $raw = explode('/', trim((string)$raw), 2)[0];
            $ip = dmdpx_files_ipv4_valid($raw);
            if ($ip !== '') $candidates[$ip] = true;
        }
    }

    if (!empty($agent['ip'])) {
        $ip = dmdpx_files_ipv4_valid($agent['ip']);
        if ($ip !== '') $candidates[$ip] = true;
    }

    $ips = array_keys($candidates);

    usort($ips, function($a, $b) {
        $rank = function($ip) {
            if (preg_match('/^10\./', $ip)) return 0;
            if (preg_match('/^192\.168\./', $ip)) return 0;
            if (preg_match('/^172\.(1[6-9]|2[0-9]|3[01])\./', $ip)) return 0;
            if (preg_match('/^100\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\./', $ip)) return 3; // Tailscale/CGNAT
            return 1;
        };
        $ra = $rank($a);
        $rb = $rank($b);
        return $ra === $rb ? strcmp($a, $b) : ($ra < $rb ? -1 : 1);
    });

    return $ips;
}

function dmdpx_files_ipv4_from_agent_inventory($vmName, $vmMacs = array()) {
    $vmNames = dmdpx_files_hostname_variants($vmName);
    $vmMacSet = array();

    foreach ((array)$vmMacs as $mac) {
        $mac = dmdpx_files_mac_normalize($mac);
        if ($mac !== '') $vmMacSet[$mac] = true;
    }

    if (!$vmNames && !$vmMacSet) return '';

    $root = dirname(__DIR__, 2);
    $file = $root . '/data/agents/agents.json';
    if (!is_file($file)) return '';

    $agents = json_decode((string)@file_get_contents($file), true);
    if (!is_array($agents)) return '';

    foreach ($agents as $agent) {
        if (!is_array($agent)) continue;

        $inv = isset($agent['inventory']) && is_array($agent['inventory']) ? $agent['inventory'] : array();
        $hostname = isset($inv['hostname']) ? $inv['hostname'] : (isset($agent['hostname']) ? $agent['hostname'] : '');
        $agentNames = dmdpx_files_hostname_variants($hostname);

        $nameMatch = false;
        foreach ($agentNames as $agentName) {
            if (in_array($agentName, $vmNames, true)) {
                $nameMatch = true;
                break;
            }
        }

        $macMatch = false;
        $network = isset($inv['network']) && is_array($inv['network']) ? $inv['network'] : array();
        foreach ($network as $iface) {
            if (!is_array($iface)) continue;
            $mac = dmdpx_files_mac_normalize(isset($iface['mac']) ? $iface['mac'] : '');
            if ($mac !== '' && isset($vmMacSet[$mac])) {
                $macMatch = true;
                break;
            }
        }

        if (!$nameMatch && !$macMatch) continue;

        $ips = dmdpx_files_agent_candidate_ips($agent);
        if ($ips) return $ips[0];
    }

    return '';
}

function dmdpx_files_ipv4_from_dns($vmName) {
    foreach (dmdpx_files_hostname_variants($vmName) as $candidate) {
        $resolved = @gethostbyname($candidate);
        if (!is_string($resolved) || $resolved === '' || strcasecmp($resolved, $candidate) === 0) continue;
        $ip = dmdpx_files_ipv4_valid($resolved);
        if ($ip !== '') return $ip;
    }
    return '';
}

function dmdpx_files_resolve_vm_host($serverId, $server, $vmid, $type, $vm) {
    $direct = array('ip','ipv4','address');
    foreach ($direct as $field) {
        if (isset($vm[$field])) {
            $ip = dmdpx_files_ipv4_valid($vm[$field]);
            if ($ip !== '') return array($ip, 'cache_vm');
        }
    }

    $host = dmdpx_files_ipv4_from_guest($server, $vmid, $type, $vm);
    if ($host !== '') return array($host, 'guest_agent');

    $host = dmdpx_files_ipv4_from_vm_config($server, $vmid, $type, $vm);
    if ($host !== '') return array($host, 'proxmox_config');

    $name = trim((string)(isset($vm['name']) ? $vm['name'] : ''));
    $vmMacs = dmdpx_files_vm_macs_from_config($server, $vmid, $type, $vm);
    $host = dmdpx_files_ipv4_from_agent_inventory($name, $vmMacs);
    if ($host !== '') return array($host, 'dmd_agent_mac_or_name');

    $host = dmdpx_files_ipv4_from_dns($name);
    if ($host !== '') return array($host, 'dns');

    $host = dmdpx_files_saved_host($serverId, $type, $vmid);
    if ($host !== '') return array($host, 'saved');

    return array('', 'none');
}


function dmdpx_files_agent_base_url($clientHost) {
    $clientHost = dmdpx_files_ipv4_valid($clientHost);
    if ($clientHost === '') return '';
    return 'http://' . $clientHost . ':38742';
}

function dmdpx_files_agent_request($clientHost, $method, $endpoint, $query, $jsonBody, &$status, &$error) {
    $status = 0;
    $error = '';

    $base = dmdpx_files_agent_base_url($clientHost);
    if ($base === '') {
        $error = 'Adresse du PC invalide.';
        return null;
    }

    $endpoint = '/' . ltrim((string)$endpoint, '/');
    if (strpos($endpoint, '/v1/') !== 0) {
        $error = 'Endpoint DMD-Agent refusé.';
        return null;
    }

    $url = $base . $endpoint;
    if (is_array($query) && $query) {
        $url .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    }

    $method = strtoupper(trim((string)$method));
    if (!in_array($method, array('GET','POST','PUT'), true)) {
        $error = 'Méthode DMD-Agent refusée.';
        return null;
    }

    $body = $jsonBody === null ? null : json_encode($jsonBody, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json', 'Connection: close'));
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Accept: application/json',
                'Content-Type: application/json',
                'Content-Length: ' . strlen($body),
                'Connection: close'
            ));
        }
        $raw = curl_exec($ch);
        if ($raw === false) {
            $error = 'DMD-Agent : ' . curl_error($ch);
            curl_close($ch);
            return null;
        }
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
    } else {
        $headers = "Accept: application/json\r\nConnection: close\r\n";
        if ($body !== null) $headers .= "Content-Type: application/json\r\n";
        $context = stream_context_create(array(
            'http' => array(
                'method' => $method,
                'timeout' => 20,
                'ignore_errors' => true,
                'header' => $headers,
                'content' => $body === null ? '' : $body,
            )
        ));
        $raw = @file_get_contents($url, false, $context);
        if ($raw === false) {
            $error = 'DMD-Agent non joignable sur ' . $clientHost . ':38742.';
            return null;
        }
        if (isset($http_response_header) && is_array($http_response_header) && isset($http_response_header[0])) {
            if (preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) $status = (int)$m[1];
        }
    }

    $data = json_decode((string)$raw, true);
    if (!is_array($data)) {
        $error = 'Réponse JSON DMD-Agent invalide.';
        return null;
    }

    if ($status < 200 || $status >= 300 || empty($data['ok'])) {
        $error = trim((string)(isset($data['message']) ? $data['message'] : 'Erreur DMD-Agent.'));
        if ($error === '') $error = 'Erreur DMD-Agent HTTP ' . $status . '.';
        return null;
    }

    return isset($data['data']) ? $data['data'] : array();
}

function dmdpx_files_agent_download_to_file($clientHost, $pcPath, $targetFile, &$error) {
    $error = '';
    $base = dmdpx_files_agent_base_url($clientHost);
    if ($base === '') { $error = 'Adresse du PC invalide.'; return false; }

    $url = $base . '/v1/files/read?path=' . rawurlencode((string)$pcPath);
    $fp = @fopen($targetFile, 'wb');
    if (!$fp) { $error = 'Fichier temporaire DoMyDesk impossible.'; return false; }

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: close'));
        $ok = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($ok === false) $error = 'DMD-Agent : ' . curl_error($ch);
        curl_close($ch);
        fclose($fp);

        if (!$ok || $status < 200 || $status >= 300) {
            @unlink($targetFile);
            if ($error === '') $error = 'Lecture du fichier PC refusée (HTTP ' . $status . ').';
            return false;
        }
        return true;
    }

    fclose($fp);
    $ctx = stream_context_create(array('http'=>array('method'=>'GET','timeout'=>300,'ignore_errors'=>true)));
    $src = @fopen($url, 'rb', false, $ctx);
    $dst = @fopen($targetFile, 'wb');
    if (!$src || !$dst) {
        if (is_resource($src)) fclose($src);
        if (is_resource($dst)) fclose($dst);
        @unlink($targetFile);
        $error = 'Lecture DMD-Agent impossible.';
        return false;
    }
    stream_copy_to_stream($src, $dst);
    fclose($src);
    fclose($dst);
    return is_file($targetFile);
}

function dmdpx_files_agent_upload_from_file($clientHost, $pcPath, $sourceFile, &$error) {
    $error = '';
    $base = dmdpx_files_agent_base_url($clientHost);
    if ($base === '') { $error = 'Adresse du PC invalide.'; return false; }
    if (!is_file($sourceFile)) { $error = 'Fichier temporaire introuvable.'; return false; }

    if (!function_exists('curl_init')) {
        $error = 'L’extension PHP cURL est nécessaire pour écrire un fichier vers DMD-Agent.';
        return false;
    }

    $url = $base . '/v1/files/write?path=' . rawurlencode((string)$pcPath);
    $fp = fopen($sourceFile, 'rb');
    if (!$fp) { $error = 'Lecture du fichier temporaire impossible.'; return false; }

    $size = (int)filesize($sourceFile);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_UPLOAD, true);
    curl_setopt($ch, CURLOPT_INFILE, $fp);
    curl_setopt($ch, CURLOPT_INFILESIZE, $size);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);
    curl_setopt($ch, CURLOPT_TIMEOUT, 300);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/octet-stream',
        'Content-Length: ' . $size,
        'Connection: close'
    ));
    $raw = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($raw === false) $error = 'DMD-Agent : ' . curl_error($ch);
    curl_close($ch);
    fclose($fp);

    if ($status < 200 || $status >= 300) {
        if ($error === '') {
            $j = json_decode((string)$raw, true);
            $error = is_array($j) && !empty($j['message'])
                ? (string)$j['message']
                : 'Écriture PC refusée (HTTP ' . $status . ').';
        }
        return false;
    }

    return true;
}

function dmdpx_files_agent_join_path($parent, $name) {
    $parent = rtrim(str_replace('/', '\\', trim((string)$parent)), '\\');
    $name = trim(str_replace(array('/', '\\'), DIRECTORY_SEPARATOR, (string)$name), "\\/");
    if ($parent === '') return $name;
    return $parent . '\\' . $name;
}

function dmdpx_files_temp_file($prefix) {
    $paths = dmd_proxmox_storage_paths();
    $dir = isset($paths['remote']) ? $paths['remote'] : (rtrim($paths['root'], '/\\') . DIRECTORY_SEPARATOR . 'remote');
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return '';
    return $dir . DIRECTORY_SEPARATOR . '.' . $prefix . '-' . bin2hex(random_bytes(10));
}

function dmdpx_files_smb_put_local($host, $share, $username, $password, $domain, $localFile, $remotePath, &$error) {
    $error = '';
    list($ok, $stdout, $err) = dmdpx_files_run(
        $host, $share, $username, $password, $domain,
        'put ' . dmdpx_files_smb_quote($localFile) . ' ' . dmdpx_files_smb_quote($remotePath)
    );
    if (!$ok) {
        $error = $err !== '' ? $err : 'Envoi SMB impossible.';
        return false;
    }
    return true;
}

function dmdpx_files_smb_get_local($host, $share, $username, $password, $domain, $remotePath, $localFile, &$error) {
    $error = '';
    list($ok, $stdout, $err) = dmdpx_files_run(
        $host, $share, $username, $password, $domain,
        'get ' . dmdpx_files_smb_quote($remotePath) . ' ' . dmdpx_files_smb_quote($localFile)
    );
    if (!$ok || !is_file($localFile)) {
        @unlink($localFile);
        $error = $err !== '' ? $err : 'Lecture SMB impossible.';
        return false;
    }
    return true;
}

function dmdpx_files_pc_to_vm_item($clientHost, $item, $dst, $dstPath, &$stats, &$error, $depth = 0) {
    if ($depth > 24) { $error = 'Arborescence PC trop profonde.'; return false; }
    if (($stats['files'] + $stats['dirs']) > 5000) { $error = 'Trop d’éléments dans la copie.'; return false; }

    $pcPath = isset($item['path']) ? trim((string)$item['path']) : '';
    $name = isset($item['name']) ? trim((string)$item['name']) : '';
    $isDir = !empty($item['directory']);
    if ($pcPath === '' || $name === '') { $error = 'Élément PC invalide.'; return false; }

    $safeName = dmdpx_files_path($name, false);
    if ($safeName === null || strpos($safeName, '/') !== false) { $error = 'Nom PC invalide.'; return false; }

    $remote = ($dstPath !== '' ? $dstPath . '/' : '') . $safeName;

    if ($isDir) {
        dmdpx_files_run($dst['host'], $dst['share'], $dst['username'], $dst['password'], $dst['domain'], 'mkdir ' . dmdpx_files_smb_quote($remote));
        $stats['dirs']++;

        $status = 0; $agentError = '';
        $children = dmdpx_files_agent_request($clientHost, 'GET', '/v1/files/list', array('path'=>$pcPath), null, $status, $agentError);
        if ($children === null || !is_array($children)) {
            $error = $agentError !== '' ? $agentError : 'Lecture du dossier PC impossible.';
            return false;
        }

        foreach ($children as $child) {
            if (!is_array($child)) continue;
            if (!dmdpx_files_pc_to_vm_item($clientHost, $child, $dst, $remote, $stats, $error, $depth + 1)) return false;
        }
        return true;
    }

    $tmp = dmdpx_files_temp_file('agent-read');
    if ($tmp === '') { $error = 'Dossier temporaire indisponible.'; return false; }

    if (!dmdpx_files_agent_download_to_file($clientHost, $pcPath, $tmp, $error)) {
        @unlink($tmp);
        return false;
    }

    $ok = dmdpx_files_smb_put_local(
        $dst['host'], $dst['share'], $dst['username'], $dst['password'], $dst['domain'],
        $tmp, $remote, $error
    );
    @unlink($tmp);

    if (!$ok) return false;
    $stats['files']++;
    return true;
}

function dmdpx_files_vm_to_pc_item($clientHost, $src, $srcPath, $item, $pcDestPath, &$stats, &$error, $depth = 0) {
    if ($depth > 24) { $error = 'Arborescence VM trop profonde.'; return false; }
    if (($stats['files'] + $stats['dirs']) > 5000) { $error = 'Trop d’éléments dans la copie.'; return false; }

    $name = isset($item['name']) ? trim((string)$item['name']) : '';
    $isDir = !empty($item['directory']);
    $safeName = dmdpx_files_path($name, false);
    if ($safeName === null || strpos($safeName, '/') !== false) { $error = 'Nom VM invalide.'; return false; }

    $remote = ($srcPath !== '' ? $srcPath . '/' : '') . $safeName;
    $pcTarget = dmdpx_files_agent_join_path($pcDestPath, $safeName);

    if ($isDir) {
        $status = 0; $agentError = '';
        $created = dmdpx_files_agent_request($clientHost, 'POST', '/v1/files/mkdir', array(), array('path'=>$pcTarget), $status, $agentError);
        if ($created === null) {
            $error = $agentError !== '' ? $agentError : 'Création du dossier PC impossible.';
            return false;
        }
        $stats['dirs']++;

        $listError = '';
        $children = dmdpx_files_list_remote(
            $src['host'], $src['share'], $src['username'], $src['password'], $src['domain'],
            $remote, $listError
        );
        if ($children === false) {
            $error = $listError !== '' ? $listError : 'Lecture du dossier VM impossible.';
            return false;
        }

        foreach ($children as $child) {
            if (!is_array($child)) continue;
            if (!dmdpx_files_vm_to_pc_item($clientHost, $src, $remote, $child, $pcTarget, $stats, $error, $depth + 1)) return false;
        }
        return true;
    }

    $tmp = dmdpx_files_temp_file('smb-read');
    if ($tmp === '') { $error = 'Dossier temporaire indisponible.'; return false; }

    if (!dmdpx_files_smb_get_local(
        $src['host'], $src['share'], $src['username'], $src['password'], $src['domain'],
        $remote, $tmp, $error
    )) {
        @unlink($tmp);
        return false;
    }

    $ok = dmdpx_files_agent_upload_from_file($clientHost, $pcTarget, $tmp, $error);
    @unlink($tmp);

    if (!$ok) return false;
    $stats['files']++;
    return true;
}

function dmdpx_files_client_host() {
    $ip = trim((string)(isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''));
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) return $ip;
    return '';
}

list($serverId, $server, $vmid, $type, $vm) = dmdpx_files_context();
$action = strtolower(trim((string)(isset($_POST['action']) ? $_POST['action'] : 'status')));
if (in_array($action, array('pc_status','pc_roots','pc_list','pc_mkdir','pc_to_vm','vm_to_pc'), true)) {
    $clientHost = dmdpx_files_client_host();
    if ($clientHost === '') {
        dmd_proxmox_json(false, 'Adresse IP du PC navigateur introuvable.', array(), 400);
    }

    if ($action === 'pc_status') {
        $status = 0; $error = '';
        $health = dmdpx_files_agent_request($clientHost, 'GET', '/v1/health', array(), null, $status, $error);
        if ($health === null) {
            dmd_proxmox_json(false, $error !== '' ? $error : 'DMD-Agent non joignable.', array(
                'client_host'=>$clientHost,
                'agent_port'=>38742
            ), 502);
        }

        $rootsStatus = 0; $rootsError = '';
        $roots = dmdpx_files_agent_request($clientHost, 'GET', '/v1/files/roots', array(), null, $rootsStatus, $rootsError);
        if ($roots === null) $roots = array();

        dmd_proxmox_json(true, 'DMD-Agent fichiers disponible.', array(
            'client_host'=>$clientHost,
            'hostname'=>isset($health['hostname']) ? (string)$health['hostname'] : '',
            'version'=>isset($health['version']) ? (string)$health['version'] : '',
            'agent_port'=>isset($health['port']) ? (int)$health['port'] : 38742,
            'roots'=>$roots
        ), 200);
    }

    if ($action === 'pc_roots') {
        $status = 0; $error = '';
        $roots = dmdpx_files_agent_request($clientHost, 'GET', '/v1/files/roots', array(), null, $status, $error);
        if ($roots === null) dmd_proxmox_json(false, $error, array(), 502);
        dmd_proxmox_json(true, '', array('roots'=>$roots,'client_host'=>$clientHost), 200);
    }

    if ($action === 'pc_list') {
        $pcPath = trim((string)(isset($_POST['pc_path']) ? $_POST['pc_path'] : ''));
        if ($pcPath === '' || strlen($pcPath) > 4096 || strpos($pcPath, "\0") !== false) {
            dmd_proxmox_json(false, 'Chemin PC invalide.', array(), 400);
        }
        $status = 0; $error = '';
        $entries = dmdpx_files_agent_request($clientHost, 'GET', '/v1/files/list', array('path'=>$pcPath), null, $status, $error);
        if ($entries === null) dmd_proxmox_json(false, $error, array(), $status === 403 ? 403 : 502);
        dmd_proxmox_json(true, '', array('path'=>$pcPath,'entries'=>$entries), 200);
    }

    if ($action === 'pc_mkdir') {
        $pcPath = trim((string)(isset($_POST['pc_path']) ? $_POST['pc_path'] : ''));
        $name = trim((string)(isset($_POST['name']) ? $_POST['name'] : ''));
        if ($pcPath === '' || $name === '' || preg_match('/[\\\\\/:*?"<>|\r\n\x00]/', $name)) {
            dmd_proxmox_json(false, 'Nom de dossier PC invalide.', array(), 400);
        }
        $target = dmdpx_files_agent_join_path($pcPath, $name);
        $status = 0; $error = '';
        $created = dmdpx_files_agent_request($clientHost, 'POST', '/v1/files/mkdir', array(), array('path'=>$target), $status, $error);
        if ($created === null) dmd_proxmox_json(false, $error, array(), $status === 403 ? 403 : 502);
        dmd_proxmox_json(true, 'Dossier PC créé.', array('path'=>$target), 200);
    }

    if ($action === 'pc_to_vm' || $action === 'vm_to_pc') {
        list($vmHost, $vmHostSource) = dmdpx_files_resolve_vm_host($serverId, $server, $vmid, $type, $vm);
        $vmHostPosted = dmdpx_files_host(isset($_POST['host']) ? $_POST['host'] : '');
        if ($vmHostPosted !== '') $vmHost = $vmHostPosted;

        $share = dmdpx_files_share(isset($_POST['share']) ? $_POST['share'] : '');
        $username = dmdpx_files_credential(isset($_POST['username']) ? $_POST['username'] : '', 256);
        $password = dmdpx_files_credential(isset($_POST['password']) ? $_POST['password'] : '', 1024);
        $domain = dmdpx_files_credential(isset($_POST['domain']) ? $_POST['domain'] : '', 256);
        $vmPath = dmdpx_files_path(isset($_POST['path']) ? $_POST['path'] : '', true);

        if ($vmHost === '' || $share === '' || $username === null || $password === null || $domain === null || $vmPath === null) {
            dmd_proxmox_json(false, 'Destination/source VM incomplète.', array(), 400);
        }

        $items = json_decode((string)(isset($_POST['items']) ? $_POST['items'] : '[]'), true);
        if (!is_array($items) || !$items || count($items) > 200) {
            dmd_proxmox_json(false, 'Sélection invalide.', array(), 400);
        }

        $endpoint = array(
            'host'=>$vmHost,
            'share'=>$share,
            'username'=>$username,
            'password'=>$password,
            'domain'=>$domain,
        );

        $stats = array('files'=>0,'dirs'=>0);
        $error = '';

        if ($action === 'pc_to_vm') {
            foreach ($items as $item) {
                if (!is_array($item)) continue;
                if (!dmdpx_files_pc_to_vm_item($clientHost, $item, $endpoint, $vmPath, $stats, $error, 0)) {
                    dmd_proxmox_json(false, 'Copie PC → VM interrompue : ' . $error, array('stats'=>$stats), 502);
                }
            }

            dmdpx_files_save_host($serverId, $type, $vmid, $vmHost, 'agent_copy_success');
            dmd_proxmox_log('file_copy_pc_vm', strtoupper($type) . ' #' . $vmid, 'success', 'Copie PC vers VM via DMD-Agent', array(
                'source'=>'module','server_id'=>$serverId,'node'=>isset($vm['node'])?$vm['node']:'',
                'vmid'=>$vmid,'type'=>$type,'host'=>$vmHost,'share'=>$share,'path'=>$vmPath,'stats'=>$stats,
                'client_host'=>$clientHost
            ));
            dmd_proxmox_json(true, 'Copie PC → VM terminée.', array('stats'=>$stats), 200);
        }

        $pcDestPath = trim((string)(isset($_POST['pc_path']) ? $_POST['pc_path'] : ''));
        if ($pcDestPath === '' || strlen($pcDestPath) > 4096 || strpos($pcDestPath, "\0") !== false) {
            dmd_proxmox_json(false, 'Dossier de destination PC invalide.', array(), 400);
        }

        foreach ($items as $item) {
            if (!is_array($item)) continue;
            if (!dmdpx_files_vm_to_pc_item($clientHost, $endpoint, $vmPath, $item, $pcDestPath, $stats, $error, 0)) {
                dmd_proxmox_json(false, 'Copie VM → PC interrompue : ' . $error, array('stats'=>$stats), 502);
            }
        }

        dmdpx_files_save_host($serverId, $type, $vmid, $vmHost, 'agent_copy_success');
        dmd_proxmox_log('file_copy_vm_pc', strtoupper($type) . ' #' . $vmid, 'success', 'Copie VM vers PC via DMD-Agent', array(
            'source'=>'module','server_id'=>$serverId,'node'=>isset($vm['node'])?$vm['node']:'',
            'vmid'=>$vmid,'type'=>$type,'host'=>$vmHost,'share'=>$share,'path'=>$vmPath,'stats'=>$stats,
            'client_host'=>$clientHost,'pc_path'=>$pcDestPath
        ));
        dmd_proxmox_json(true, 'Copie VM → PC terminée.', array('stats'=>$stats), 200);
    }
}

if ($action === 'status') {
    $bin = dmdpx_files_binary();
    list($host, $hostSource) = dmdpx_files_resolve_vm_host($serverId, $server, $vmid, $type, $vm);
    if ($host !== '') dmdpx_files_save_host($serverId, $type, $vmid, $host, $hostSource);
    dmd_proxmox_json(true, $bin !== '' ? 'Passerelle fichiers disponible.' : 'smbclient absent sur l’hôte DoMyDesk.', array(
        'smbclient' => $bin !== '',
        'smbclient_path' => $bin,
        'host' => $host,
        'host_source' => $hostSource,
        'client_host' => dmdpx_files_client_host(),
        'node' => isset($vm['node']) ? (string)$vm['node'] : '',
        'vm_status' => isset($vm['status']) ? (string)$vm['status'] : '',
        'vm_name' => isset($vm['name']) ? (string)$vm['name'] : '',
        'vmid' => $vmid,
        'type' => $type
    ), 200);
}

if ($action === 'resolve') {
    list($host, $hostSource) = dmdpx_files_resolve_vm_host($serverId, $server, $vmid, $type, $vm);
    if ($host !== '') dmdpx_files_save_host($serverId, $type, $vmid, $host, $hostSource);
    dmd_proxmox_json(true, $host !== '' ? 'IP détectée.' : 'Aucune IPv4 détectée automatiquement.', array(
        'host'=>$host,
        'host_source'=>$hostSource,
        'client_host'=>dmdpx_files_client_host(),
        'node'=>isset($vm['node']) ? $vm['node'] : ''
    ), 200);
}

$side = strtolower(trim((string)(isset($_POST['side']) ? $_POST['side'] : 'vm')));
if (!in_array($side, array('vm','pc'), true)) $side = 'vm';

$postedHost = dmdpx_files_host(isset($_POST['host']) ? $_POST['host'] : '');
if ($side === 'pc') {
    $host = dmdpx_files_client_host();
} else {
    $host = $postedHost;
    if ($host === '') {
        list($host, $ignoredHostSource) = dmdpx_files_resolve_vm_host($serverId, $server, $vmid, $type, $vm);
    }
}

$username = dmdpx_files_credential(isset($_POST['username']) ? $_POST['username'] : '', 256);
$password = dmdpx_files_credential(isset($_POST['password']) ? $_POST['password'] : '', 1024);
$domain = dmdpx_files_credential(isset($_POST['domain']) ? $_POST['domain'] : '', 256);

if ($host === '' || $username === null || $password === null || $domain === null) {
    dmd_proxmox_json(false, 'Connexion SMB invalide.', array(), 400);
}

if ($action === 'save_vm_host') {
    $manual = dmdpx_files_host(isset($_POST['host']) ? $_POST['host'] : '');
    if ($manual === '') dmd_proxmox_json(false, 'IP/DNS invalide.', array(), 400);
    dmdpx_files_save_host($serverId, $type, $vmid, $manual, 'manual');
    dmd_proxmox_json(true, 'Adresse VM mémorisée.', array('host'=>$manual), 200);
}
if ($action === 'shares') {
    $hasCredentials = dmdpx_files_has_credentials($username, $password, $domain);
    list($ok, $stdout, $error) = dmdpx_files_run_shares($host, $username, $password, $domain);
    $shares = dmdpx_files_parse_shares($stdout);
    if ($shares) {
        if ($side === 'vm' && $host !== '') dmdpx_files_save_host($serverId, $type, $vmid, $host, 'smb_success');
        dmd_proxmox_json(true, 'Racine réseau ouverte.', array(
            'host'=>$host,
            'shares'=>$shares,
            'enumeration'=>'native'
        ), 200);
    }

    if (!$ok) {
        if ($hasCredentials && !dmdpx_files_auth_failed($error)) {
            $adminShares = dmdpx_files_probe_admin_shares($host, $username, $password, $domain);
            if ($adminShares) {
                if ($side === 'vm' && $host !== '') dmdpx_files_save_host($serverId, $type, $vmid, $host, 'smb_admin_success');
                dmd_proxmox_json(true, 'Accès administrateur SMB validé.', array(
                    'host'=>$host,
                    'shares'=>$adminShares,
                    'enumeration'=>'admin_probe'
                ), 200);
            }
        }

        if (!$hasCredentials) {
            dmd_proxmox_json(false,
                'La machine exige une authentification SMB.',
                array(
                    'auth_required'=>true,
                    'credentials_supplied'=>false,
                    'smb_error'=>$error
                ),
                401
            );
        }

        if (dmdpx_files_auth_failed($error)) {
            dmd_proxmox_json(false,
                'Identifiants SMB refusés par la machine.',
                array(
                    'auth_required'=>true,
                    'credentials_supplied'=>true,
                    'credentials_rejected'=>true,
                    'smb_error'=>$error
                ),
                401
            );
        }

        if (dmdpx_files_access_denied($error)) {
            dmd_proxmox_json(false,
                'Accès SMB refusé avec les identifiants fournis.',
                array(
                    'auth_required'=>false,
                    'credentials_supplied'=>true,
                    'access_denied'=>true,
                    'smb_error'=>$error
                ),
                403
            );
        }

        dmd_proxmox_json(false,
            $error !== '' ? $error : 'Impossible de lire la racine réseau de la VM.',
            array(
                'auth_required'=>false,
                'credentials_supplied'=>$hasCredentials,
                'smb_error'=>$error
            ),
            502
        );
    }

    dmd_proxmox_json(true, 'Racine réseau ouverte.', array(
        'host'=>$host,
        'shares'=>array(),
        'enumeration'=>'native'
    ), 200);
}

if ($action === 'copy_between') {
    $srcSide = strtolower(trim((string)(isset($_POST['src_side']) ? $_POST['src_side'] : 'pc')));
    $dstSide = strtolower(trim((string)(isset($_POST['dst_side']) ? $_POST['dst_side'] : 'vm')));
    if (!in_array($srcSide, array('pc','vm'), true) || !in_array($dstSide, array('pc','vm'), true) || $srcSide === $dstSide) {
        dmd_proxmox_json(false, 'Sens de copie invalide.', array(), 400);
    }

    $vmResolvedHost = '';
    list($vmResolvedHost, $ignoredSource) = dmdpx_files_resolve_vm_host($serverId, $server, $vmid, $type, $vm);
    $pcHost = dmdpx_files_client_host();

    $src = array(
        'host' => $srcSide === 'pc' ? $pcHost : dmdpx_files_host(isset($_POST['src_host']) ? $_POST['src_host'] : $vmResolvedHost),
        'share' => dmdpx_files_share(isset($_POST['src_share']) ? $_POST['src_share'] : ''),
        'username' => dmdpx_files_credential(isset($_POST['src_username']) ? $_POST['src_username'] : '', 256),
        'password' => dmdpx_files_credential(isset($_POST['src_password']) ? $_POST['src_password'] : '', 1024),
        'domain' => dmdpx_files_credential(isset($_POST['src_domain']) ? $_POST['src_domain'] : '', 256),
    );
    $dst = array(
        'host' => $dstSide === 'pc' ? $pcHost : dmdpx_files_host(isset($_POST['dst_host']) ? $_POST['dst_host'] : $vmResolvedHost),
        'share' => dmdpx_files_share(isset($_POST['dst_share']) ? $_POST['dst_share'] : ''),
        'username' => dmdpx_files_credential(isset($_POST['dst_username']) ? $_POST['dst_username'] : '', 256),
        'password' => dmdpx_files_credential(isset($_POST['dst_password']) ? $_POST['dst_password'] : '', 1024),
        'domain' => dmdpx_files_credential(isset($_POST['dst_domain']) ? $_POST['dst_domain'] : '', 256),
    );

    foreach (array($src, $dst) as $endpoint) {
        if ($endpoint['host'] === '' || $endpoint['share'] === '' || $endpoint['username'] === null || $endpoint['password'] === null || $endpoint['domain'] === null) {
            dmd_proxmox_json(false, 'Source ou destination SMB incomplète.', array(), 400);
        }
    }

    $srcPath = dmdpx_files_path(isset($_POST['src_path']) ? $_POST['src_path'] : '', true);
    $dstPath = dmdpx_files_path(isset($_POST['dst_path']) ? $_POST['dst_path'] : '', true);
    if ($srcPath === null || $dstPath === null) dmd_proxmox_json(false, 'Chemin de copie invalide.', array(), 400);

    $items = json_decode((string)(isset($_POST['items']) ? $_POST['items'] : '[]'), true);
    if (!is_array($items) || !$items || count($items) > 100) dmd_proxmox_json(false, 'Sélection de copie invalide.', array(), 400);

    $stats = array('files'=>0,'dirs'=>0);
    foreach ($items as $item) {
        if (!is_array($item)) continue;
        $name = isset($item['name']) ? (string)$item['name'] : '';
        $isDir = !empty($item['directory']);
        $error = '';
        if ($isDir) {
            if (!dmdpx_files_copy_tree($src, $dst, $srcPath, $dstPath, $name, $stats, $error, 0)) {
                dmd_proxmox_json(false, 'Copie interrompue : ' . ($error !== '' ? $error : 'erreur SMB'), array('stats'=>$stats), 502);
            }
        } else {
            if (!dmdpx_files_copy_one_file($src, $dst, $srcPath, $dstPath, $name, $error)) {
                dmd_proxmox_json(false, 'Copie interrompue : ' . ($error !== '' ? $error : 'erreur SMB'), array('stats'=>$stats), 502);
            }
            $stats['files']++;
        }
    }

    if ($dstSide === 'vm' && $dst['host'] !== '') dmdpx_files_save_host($serverId, $type, $vmid, $dst['host'], 'copy_success');
    if ($srcSide === 'vm' && $src['host'] !== '') dmdpx_files_save_host($serverId, $type, $vmid, $src['host'], 'copy_success');

    dmd_proxmox_json(true, 'Copie terminée.', array('stats'=>$stats), 200);
}


$share = dmdpx_files_share(isset($_POST['share']) ? $_POST['share'] : '');
if ($share === '') {
    dmd_proxmox_json(false, 'Partage SMB invalide.', array(), 400);
}

$path = dmdpx_files_path(isset($_POST['path']) ? $_POST['path'] : '', true);
if ($path === null) dmd_proxmox_json(false, 'Chemin SMB invalide.', array(), 400);


if ($action === 'list') {
    $command = $path !== '' ? ('cd ' . dmdpx_files_smb_quote($path) . '; ls') : 'ls';
    list($ok, $stdout, $error) = dmdpx_files_run($host, $share, $username, $password, $domain, $command);
    if (!$ok) {
        $hasCredentials = dmdpx_files_has_credentials($username, $password, $domain);
        if (!$hasCredentials) {
            dmd_proxmox_json(false, 'Authentification SMB requise.', array(
                'auth_required'=>true,
                'credentials_supplied'=>false,
                'smb_error'=>$error
            ), 401);
        }
        if (dmdpx_files_auth_failed($error)) {
            dmd_proxmox_json(false, 'Identifiants SMB refusés par la machine.', array(
                'auth_required'=>true,
                'credentials_supplied'=>true,
                'credentials_rejected'=>true,
                'smb_error'=>$error
            ), 401);
        }
        dmd_proxmox_json(false, $error !== '' ? $error : 'Lecture SMB impossible.', array(
            'auth_required'=>false,
            'credentials_supplied'=>true,
            'smb_error'=>$error
        ), dmdpx_files_access_denied($error) ? 403 : 502);
    }
    dmd_proxmox_json(true, '', array('path'=>$path, 'entries'=>dmdpx_files_parse_list($stdout)), 200);
}

if ($action === 'mkdir') {
    $name = dmdpx_files_path(isset($_POST['name']) ? $_POST['name'] : '', false);
    if ($name === null || strpos($name, '/') !== false) dmd_proxmox_json(false, 'Nom de dossier invalide.', array(), 400);
    $remote = ($path !== '' ? $path . '/' : '') . $name;
    list($ok, $stdout, $error) = dmdpx_files_run($host, $share, $username, $password, $domain, 'mkdir ' . dmdpx_files_smb_quote($remote));
    if (!$ok) dmd_proxmox_json(false, $error !== '' ? $error : 'Création du dossier impossible.', array(), 502);
    dmd_proxmox_log('file_mkdir', strtoupper($type) . ' #' . $vmid, 'success', 'Dossier SMB créé', array('source'=>'module','server_id'=>$serverId,'node'=>isset($vm['node'])?$vm['node']:'','vmid'=>$vmid,'type'=>$type,'host'=>$host,'share'=>$share,'path'=>$remote));
    dmd_proxmox_json(true, 'Dossier créé.', array('path'=>$remote), 200);
}

if ($action === 'upload') {
    if (!isset($_FILES['file']) || !is_array($_FILES['file']) || (int)$_FILES['file']['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($_FILES['file']['tmp_name'])) {
        dmd_proxmox_json(false, 'Fichier local invalide.', array(), 400);
    }
    $relative = dmdpx_files_path(isset($_POST['relative_path']) ? $_POST['relative_path'] : basename((string)$_FILES['file']['name']), false);
    if ($relative === null) dmd_proxmox_json(false, 'Chemin local relatif invalide.', array(), 400);
    $parts = explode('/', $relative);
    $filename = array_pop($parts);
    $remoteDir = $path;
    foreach ($parts as $part) {
        $remoteDir = ($remoteDir !== '' ? $remoteDir . '/' : '') . $part;
        dmdpx_files_run($host, $share, $username, $password, $domain, 'mkdir ' . dmdpx_files_smb_quote($remoteDir));
    }
    $remote = ($remoteDir !== '' ? $remoteDir . '/' : '') . $filename;
    $local = (string)$_FILES['file']['tmp_name'];
    $cmd = 'put ' . dmdpx_files_smb_quote($local) . ' ' . dmdpx_files_smb_quote($remote);
    list($ok, $stdout, $error) = dmdpx_files_run($host, $share, $username, $password, $domain, $cmd);
    if (!$ok) dmd_proxmox_json(false, $error !== '' ? $error : 'Envoi SMB impossible.', array(), 502);
    dmd_proxmox_log('file_upload', strtoupper($type) . ' #' . $vmid, 'success', 'Fichier envoyé vers le partage SMB', array('source'=>'module','server_id'=>$serverId,'node'=>isset($vm['node'])?$vm['node']:'','vmid'=>$vmid,'type'=>$type,'host'=>$host,'share'=>$share,'path'=>$remote,'size'=>(int)$_FILES['file']['size']));
    dmd_proxmox_json(true, 'Fichier envoyé.', array('path'=>$remote), 200);
}

if ($action === 'download') {
    $name = dmdpx_files_path(isset($_POST['name']) ? $_POST['name'] : '', false);
    if ($name === null || strpos($name, '/') !== false) dmd_proxmox_json(false, 'Nom de fichier invalide.', array(), 400);
    $remote = ($path !== '' ? $path . '/' : '') . $name;
    $paths = dmd_proxmox_storage_paths();
    $dir = isset($paths['remote']) ? $paths['remote'] : (rtrim($paths['root'], '/\\') . DIRECTORY_SEPARATOR . 'remote');
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) dmd_proxmox_json(false, 'Dossier temporaire indisponible.', array(), 500);
    $tmp = $dir . DIRECTORY_SEPARATOR . '.smb-download-' . bin2hex(random_bytes(10));
    list($ok, $stdout, $error) = dmdpx_files_run($host, $share, $username, $password, $domain, 'get ' . dmdpx_files_smb_quote($remote) . ' ' . dmdpx_files_smb_quote($tmp));
    if (!$ok || !is_file($tmp)) { @unlink($tmp); dmd_proxmox_json(false, $error !== '' ? $error : 'Téléchargement SMB impossible.', array(), 502); }
    $size = (int)@filesize($tmp);
    dmd_proxmox_log('file_download', strtoupper($type) . ' #' . $vmid, 'success', 'Fichier récupéré depuis le partage SMB', array('source'=>'module','server_id'=>$serverId,'node'=>isset($vm['node'])?$vm['node']:'','vmid'=>$vmid,'type'=>$type,'host'=>$host,'share'=>$share,'path'=>$remote,'size'=>$size));
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . $size);
    header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode($name));
    header('Cache-Control: no-store, private');
    $fp = fopen($tmp, 'rb');
    if ($fp) { fpassthru($fp); fclose($fp); }
    @unlink($tmp);
    exit;
}

dmd_proxmox_json(false, 'Action fichiers inconnue.', array(), 400);
