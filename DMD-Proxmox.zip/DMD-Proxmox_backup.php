<?php
/* DoMyDesk — SynoHomes — Gestion des sauvegardes Proxmox */
require_once __DIR__ . '/DMD-Proxmox_lib.php';
header('Cache-Control: no-store');
function pb_fail($message, $code = 400) { dmd_proxmox_json(false, $message, array(), $code); }
if (!dmd_proxmox_user_email() || !dmd_proxmox_can_manage_backups() || !dmd_proxmox_has_module_access()) pb_fail('Accès administrateur requis.', 403);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') pb_fail('Méthode non autorisée.', 405);
$i = json_decode(file_get_contents('php://input'), true);
if (!is_array($i) || !dmd_proxmox_csrf_valid($i['csrf'] ?? '')) pb_fail('Jeton de sécurité invalide.', 403);
$s = dmd_proxmox_load_server((string)($i['server_id'] ?? ''));
if (!$s) pb_fail('Serveur introuvable.', 404);
function pb_api($path, $method = 'GET', $data = null) {
    global $s;
    $r = dmd_proxmox_api($s, $path, $method, $data, 25);
    if (!$r['ok']) pb_fail($r['error'] ?: 'Erreur API Proxmox.', 502);
    return $r['data'];
}
function pb_ok($data) { dmd_proxmox_json(true, 'OK', array('data' => $data), 200); }
function pb_id($value) { if (!is_string($value) || !preg_match('/^[a-zA-Z0-9_.-]+$/D', $value)) pb_fail('Identifiant invalide.'); return rawurlencode($value); }
function pb_stores($node, $content) { return array_values(array_filter(pb_api("nodes/$node/storage?content=$content") ?: array(), function($r) { return !empty($r['active']) && !empty($r['enabled']); })); }
function pb_store($node, $id, $content) { foreach (pb_stores($node, $content) as $r) if ($r['storage'] === $id) return pb_id($id); pb_fail('Stockage indisponible ou incompatible.'); }
function pb_backups($node, $store) { return pb_api("nodes/$node/storage/$store/content?content=backup") ?: array(); }
function pb_vmid($id) { if (!is_scalar($id) || !preg_match('/^[0-9]{3,9}$/D', (string)$id) || (int)$id < 100) pb_fail('VMID invalide.'); return (int)$id; }
function pb_mutate($action, $path, $method, $data, $target, $node) {
    global $s;
    $r = dmd_proxmox_api($s, $path, $method, $data, 25);
    $extra = array('server_id'=>$s['id'] ?? '', 'server'=>$s['name'] ?? '', 'node'=>$node, 'upid'=>$r['ok'] ? $r['data'] : null);
    dmd_proxmox_log('backup_'.$action, $target, $r['ok'] ? 'pending' : 'error', $r['ok'] ? 'Requête acceptée par Proxmox' : $r['error'], $extra);
    if (!$r['ok']) pb_fail($r['error'], 502);
    if (is_string($r['data']) && strpos($r['data'],'UPID:')===0) $_SESSION['dmd_proxmox_backup_tasks'][$s['id']][$r['data']]=true;
    pb_ok(array('upid'=>$r['data'], 'node'=>$node));
}
function pb_allowed($cap, $id, $type) { global $s; return dmd_proxmox_backup_can('backup.'.$cap, $s['id'], (int)$id, $type); }
function pb_identity($row) {
    $type = $row['subtype'] ?? ''; $id = (int)($row['vmid'] ?? 0);
    if (preg_match('~(?:vzdump-|/)(qemu|lxc|vm|ct)[-/]([0-9]+)(?:[-/]|$)~', $row['volid'] ?? '', $m)) { $type=$m[1]; $id=(int)$m[2]; }
    if ($type==='vm') $type='qemu'; if ($type==='ct') $type='lxc';
    return array($id,$type);
}
$a = $i['action'] ?? '';
if (in_array($a,array('create','restore','delete'),true) && !dmd_proxmox_backup_can('backup.'.$a)) pb_fail('Droit sauvegarde refusé.',403);
if ($a === 'nodes') pb_ok(pb_api('nodes'));
$n = pb_id($i['node'] ?? '');
if ($a === 'context') {
    $vms = pb_api('cluster/resources?type=vm') ?: array();
    $vms = array_values(array_filter($vms, function($v) use ($i) { return ($v['node'] ?? '') === $i['node'] && in_array($v['type'] ?? '', array('qemu','lxc'), true) && empty($v['template']) && pb_allowed('create',$v['vmid'],$v['type']); }));
    pb_ok(array('vms'=>$vms, 'stores'=>pb_stores($n,'backup'), 'images'=>pb_stores($n,'images'), 'rootdir'=>pb_stores($n,'rootdir'), 'nextid'=>pb_api('cluster/nextid')));
}
if ($a === 'task') {
    $u = $i['upid'] ?? '';
    if (!is_string($u)) pb_fail('Tâche invalide.');
    if (!dmd_proxmox_is_admin() && empty($_SESSION['dmd_proxmox_backup_tasks'][$s['id']][$u])) pb_fail('Tâche non autorisée.',403);
    if (!is_string($u) || strpos($u, 'UPID:'.$i['node'].':') !== 0 || strlen($u)>512) pb_fail('Tâche invalide.');
    $p = 'nodes/'.$n.'/tasks/'.rawurlencode($u);
    pb_ok(array('status'=>pb_api($p.'/status'), 'log'=>pb_api($p.'/log?start=0&limit=500')));
}
$b = pb_store($n, $i['storage'] ?? '', 'backup');
if ($a === 'list') {
    $out=array(); foreach(pb_backups($n,$b) as $row) { list($id,$type)=pb_identity($row); $row['can_restore']=pb_allowed('restore',$id,$type); $row['can_delete']=pb_allowed('delete',$id,$type); if(pb_allowed('view',$id,$type)||$row['can_restore']||$row['can_delete']) $out[]=$row; } pb_ok($out);
}
if ($a === 'create') {
    $id = pb_vmid($i['vmid'] ?? '');
    $mode = $i['mode'] ?? 'snapshot'; $compress = $i['compress'] ?? 'zstd';
    if (!in_array($mode,array('snapshot','suspend','stop'),true) || !in_array($compress,array('zstd','lzo','gzip','0'),true)) pb_fail('Options invalides.');
    $found = false;
    foreach (pb_api('cluster/resources?type=vm') ?: array() as $v) if ((int)($v['vmid'] ?? 0)===$id && ($v['node'] ?? '')===$i['node'] && in_array($v['type'] ?? '',array('qemu','lxc'),true) && empty($v['template']) && pb_allowed('create',$id,$v['type'])) $found=true;
    if (!$found) pb_fail('VM/CT introuvable sur ce node.',404);
    pb_mutate('create',"nodes/$n/vzdump",'POST',array('vmid'=>$id,'storage'=>$i['storage'],'mode'=>$mode,'compress'=>$compress),'#'.$id,$i['node']);
}
if (!in_array($a,array('restore','delete'),true)) pb_fail('Action inconnue.');
$vol = $i['volume'] ?? ''; $backup = null;
foreach (pb_backups($n,$b) as $row) if (($row['volid'] ?? null) === $vol) { $backup=$row; break; }
if (!$backup) pb_fail('Sauvegarde introuvable.',404);
list($sourceId,$sourceType)=pb_identity($backup);
if (!pb_allowed($a,$sourceId,$sourceType)) pb_fail('Droit fin VM/CT refusé.',403);
if (($i['confirm'] ?? false) !== true) pb_fail('Confirmation requise.');
if ($a === 'delete') {
    if (!empty($backup['protected'])) pb_fail('Sauvegarde protégée.');
    pb_mutate('delete',"nodes/$n/storage/$b/content/".rawurlencode($vol),'DELETE',null,$vol,$i['node']);
}
$id = pb_vmid($i['vmid'] ?? '');
$type = $backup['subtype'] ?? '';
if ($type === 'vm') $type = 'qemu';
if ($type === 'ct') $type = 'lxc';
if (!in_array($type,array('qemu','lxc'),true)) {
    if (preg_match('~(?:vzdump-|/)(qemu|lxc|vm|ct)[-/]~',$vol,$m)) $type=in_array($m[1],array('vm','qemu'),true)?'qemu':'lxc';
}
if (!in_array($type,array('qemu','lxc'),true)) pb_fail('Type de sauvegarde non reconnu.');
$dest = $i['destination'] ?? '';
pb_store($n,$dest,$type==='qemu'?'images':'rootdir');
// Aucun écrasement : Proxmox vérifie aussi l'unicité du VMID au moment de la création.
pb_api('cluster/nextid?vmid='.$id);
$data = array('vmid'=>$id,'storage'=>$dest);
if ($type==='qemu') $data['archive']=$vol; else { $data['ostemplate']=$vol; $data['restore']=1; }
pb_mutate('restore',"nodes/$n/$type",'POST',$data,$vol.' → #'.$id,$i['node']);
