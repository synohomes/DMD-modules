<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */


if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

function dmdpxb_fail($message, $configFile = '', $readyFile = '', $statusFile = '') {
    if ($statusFile !== '') {
        @file_put_contents($statusFile, json_encode(array(
            'ok' => false,
            'time' => date('c'),
            'error' => (string)$message
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
        @chmod($statusFile, 0600);
    }
    if ($configFile !== '' && is_file($configFile)) @unlink($configFile);
    if ($readyFile !== '' && is_file($readyFile)) @unlink($readyFile);
    fwrite(STDERR, (string)$message . PHP_EOL);
    exit(1);
}

function dmdpxb_read_headers($stream, $maxBytes, $timeoutSeconds) {
    stream_set_timeout($stream, $timeoutSeconds);
    $buf = '';
    while (strpos($buf, "\r\n\r\n") === false && strlen($buf) < $maxBytes && !feof($stream)) {
        $chunk = fread($stream, 4096);
        if ($chunk === false || $chunk === '') {
            $meta = stream_get_meta_data($stream);
            if (!empty($meta['timed_out'])) break;
            usleep(10000);
            continue;
        }
        $buf .= $chunk;
    }
    return $buf;
}

function dmdpxb_header($headers, $name) {
    $name = strtolower((string)$name);
    foreach (preg_split('/\r\n/', (string)$headers) as $line) {
        $pos = strpos($line, ':');
        if ($pos === false) continue;
        if (strtolower(trim(substr($line, 0, $pos))) === $name) {
            return trim(substr($line, $pos + 1));
        }
    }
    return '';
}

function dmdpxb_ws_accept($key) {
    return base64_encode(sha1(trim((string)$key) . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11', true));
}

function dmdpxb_write_all($stream, $data) {
    $len = strlen((string)$data);
    $off = 0;
    while ($off < $len) {
        $written = @fwrite($stream, substr($data, $off));
        if ($written === false || $written === 0) return false;
        $off += $written;
    }
    return true;
}

$configFile = isset($argv[1]) ? (string)$argv[1] : '';
if ($configFile === '' || !is_file($configFile)) {
    dmdpxb_fail('Configuration Remote absente.', $configFile);
}

$cfg = json_decode((string)@file_get_contents($configFile), true);
if (!is_array($cfg)) dmdpxb_fail('Configuration Remote invalide.', $configFile);

$listenPort = (int)($cfg['listen_port'] ?? 0);
$token = (string)($cfg['session_token'] ?? '');
$readyFile = (string)($cfg['ready_file'] ?? '');
$upHost = (string)($cfg['upstream_host'] ?? '');
$upPort = (int)($cfg['upstream_port'] ?? 8006);
$upPath = (string)($cfg['upstream_path'] ?? '');
$authCookie = (string)($cfg['pve_auth_cookie'] ?? '');
$expiresAt = (int)($cfg['expires_at'] ?? 0);
$maxRuntime = max(60, min(14400, (int)($cfg['max_runtime'] ?? 14400)));

$statusFile = $configFile . '.status';

if ($expiresAt < time()) dmdpxb_fail('Configuration Remote expirée.', $configFile, $readyFile, $statusFile);
if ($listenPort < 1 || $token === '' || $upHost === '' || $upPath === '' || $authCookie === '' || $readyFile === '') {
    dmdpxb_fail('Configuration Remote incomplète.', $configFile, $readyFile, $statusFile);
}

$errno = 0; $errstr = '';
$server = @stream_socket_server(
    'tcp://0.0.0.0:' . $listenPort,
    $errno,
    $errstr,
    STREAM_SERVER_BIND | STREAM_SERVER_LISTEN
);
if (!$server) {
    dmdpxb_fail('Écoute Remote impossible : ' . $errstr, $configFile, $readyFile, $statusFile);
}
stream_set_blocking($server, false);
$upstream = null;
$upResp = '';
$upInitial = '';
$lastError = '';

for ($attempt = 0; $attempt < 12; $attempt++) {
    $ssl = stream_context_create(array('ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true,
        'SNI_enabled' => true,
        'peer_name' => $upHost
    )));

    $errno = 0; $errstr = '';
    $candidate = @stream_socket_client(
        'tls://' . $upHost . ':' . $upPort,
        $errno,
        $errstr,
        4,
        STREAM_CLIENT_CONNECT,
        $ssl
    );

    if (!is_resource($candidate)) {
        $lastError = 'Connexion Proxmox impossible : ' . $errstr;
        usleep(150000);
        continue;
    }

    $upKey = base64_encode(random_bytes(16));
    $hostHeader = $upHost . ':' . $upPort;
    $upReq = "GET " . $upPath . " HTTP/1.1\r\n";
    $upReq .= "Host: " . $hostHeader . "\r\n";
    $upReq .= "Upgrade: websocket\r\nConnection: Upgrade\r\n";
    $upReq .= "Sec-WebSocket-Key: " . $upKey . "\r\n";
    $upReq .= "Sec-WebSocket-Version: 13\r\n";
    $upReq .= "Sec-WebSocket-Protocol: binary\r\n";
    $upReq .= "Cookie: PVEAuthCookie=" . $authCookie . "\r\n";
    $upReq .= "Origin: https://" . $hostHeader . "\r\n\r\n";

    if (!dmdpxb_write_all($candidate, $upReq)) {
        @fclose($candidate);
        $lastError = 'Écriture du handshake Proxmox impossible.';
        usleep(150000);
        continue;
    }

    $candidateResp = dmdpxb_read_headers($candidate, 32768, 5);
    if (preg_match('~^HTTP/1\.[01]\s+101\b~i', $candidateResp)) {
        $headerEnd = strpos($candidateResp, "\r\n\r\n");
        if ($headerEnd === false) {
            @fclose($candidate);
            $lastError = 'Handshake WebSocket Proxmox incomplet.';
            usleep(150000);
            continue;
        }

        $upstream = $candidate;
        $upResp = substr($candidateResp, 0, $headerEnd + 4);
        $upInitial = substr($candidateResp, $headerEnd + 4);
        break;
    }

    $firstLine = strtok($candidateResp, "\r\n");
    $lastError = 'Proxmox a refusé le WebSocket Remote' . ($firstLine ? ' : ' . $firstLine : '.');
    @fclose($candidate);
    usleep(150000);
}

if (!is_resource($upstream)) {
    @fclose($server);
    dmdpxb_fail($lastError !== '' ? $lastError : 'WebSocket Proxmox indisponible.', $configFile, $readyFile, $statusFile);
}

@file_put_contents($statusFile, json_encode(array(
    'ok' => true,
    'time' => date('c'),
    'state' => 'upstream-ready'
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
@chmod($statusFile, 0600);

if (@file_put_contents($readyFile, (string)getmypid(), LOCK_EX) === false) {
    @fclose($upstream);
    @fclose($server);
    dmdpxb_fail('Impossible de signaler la disponibilité du tunnel Remote.', $configFile, $readyFile, $statusFile);
}
@chmod($readyFile, 0600);
$client = null;
$deadline = microtime(true) + 20.0;
while (microtime(true) < $deadline) {
    $client = @stream_socket_accept($server, 0);
    if (is_resource($client)) break;
    usleep(50000);
}

@fclose($server);
@unlink($readyFile);

if (!is_resource($client)) {
    @fclose($upstream);
    dmdpxb_fail('Aucun client Remote.', $configFile, $readyFile, $statusFile);
}
@unlink($configFile);

$request = dmdpxb_read_headers($client, 32768, 5);
if ($request === '' || stripos($request, 'upgrade: websocket') === false) {
    @fclose($client); @fclose($upstream);
    dmdpxb_fail('Handshake WebSocket client invalide.', '', '', $statusFile);
}

$first = strtok($request, "\r\n");
if (!preg_match('~^GET\s+([^\s]+)\s+HTTP/~', (string)$first, $m)) {
    @fclose($client); @fclose($upstream);
    dmdpxb_fail('Requête WebSocket invalide.', '', '', $statusFile);
}

$path = parse_url($m[1], PHP_URL_PATH);
if (!is_string($path) || trim($path, '/') !== $token) {
    @fclose($client); @fclose($upstream);
    dmdpxb_fail('Jeton Remote invalide.', '', '', $statusFile);
}

$clientKey = dmdpxb_header($request, 'Sec-WebSocket-Key');
if ($clientKey === '') {
    @fclose($client); @fclose($upstream);
    dmdpxb_fail('Clé WebSocket absente.', '', '', $statusFile);
}

$clientProtocol = dmdpxb_header($request, 'Sec-WebSocket-Protocol');

$response = "HTTP/1.1 101 Switching Protocols\r\n";
$response .= "Upgrade: websocket\r\nConnection: Upgrade\r\n";
$response .= "Sec-WebSocket-Accept: " . dmdpxb_ws_accept($clientKey) . "\r\n";
if ($clientProtocol !== '' && stripos($clientProtocol, 'binary') !== false) {
    $response .= "Sec-WebSocket-Protocol: binary\r\n";
}
$response .= "\r\n";

if (!dmdpxb_write_all($client, $response)) {
    @fclose($client); @fclose($upstream);
    dmdpxb_fail('Réponse WebSocket client impossible.', '', '', $statusFile);
}

if ($upInitial !== '' && !dmdpxb_write_all($client, $upInitial)) {
    @fclose($client); @fclose($upstream);
    dmdpxb_fail('Transmission du début de session RFB impossible.', '', '', $statusFile);
}
stream_set_blocking($client, false);
stream_set_blocking($upstream, false);

$toClient = '';
$toUpstream = '';
$bytesClientToProxmox = 0;
$bytesProxmoxToClient = 0;
$reason = 'max-runtime';
$startedAt = microtime(true);
$endAt = time() + $maxRuntime;
$highWater = 512 * 1024;
$lowWater = 128 * 1024;
$hardLimit = 2 * 1024 * 1024; 
$pauseClientRead = false;
$pauseUpstreamRead = false;
$zeroWriteClient = 0;
$zeroWriteUpstream = 0;
$lastActivityAt = microtime(true);
$lastStatusAt = 0.0;

@file_put_contents($statusFile, json_encode(array(
    'ok' => true,
    'time' => date('c'),
    'state' => 'connected',
    'listen_port' => $listenPort,
    'upstream' => $upHost . ':' . $upPort
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);

while (time() < $endAt) {
    $read = array();
    $write = array();
    $except = null;
    if ($pauseClientRead && strlen($toUpstream) <= $lowWater) {
        $pauseClientRead = false;
    }
    if ($pauseUpstreamRead && strlen($toClient) <= $lowWater) {
        $pauseUpstreamRead = false;
    }

    if (!$pauseClientRead && strlen($toUpstream) < $highWater && !feof($client)) {
        $read[] = $client;
    }
    if (!$pauseUpstreamRead && strlen($toClient) < $highWater && !feof($upstream)) {
        $read[] = $upstream;
    }

    if ($toUpstream !== '') $write[] = $upstream;
    if ($toClient !== '') $write[] = $client;

    if (feof($client) && $toUpstream === '') {
        $reason = 'client-eof';
        break;
    }
    if (feof($upstream) && $toClient === '') {
        $reason = 'upstream-eof';
        break;
    }

    if (!$read && !$write) {
        $reason = 'no-stream';
        break;
    }

    $n = @stream_select($read, $write, $except, 1, 0);
    if ($n === false) {
        $reason = 'stream-select-error';
        break;
    }
    if ($n === 0) continue;

    foreach ($read as $src) {
        $buf = @fread($src, 65536);

        if ($buf === false) {
            $reason = ($src === $client) ? 'client-read-error' : 'upstream-read-error';
            break 2;
        }

        if ($buf === '') continue;

        $lastActivityAt = microtime(true);

        if ($src === $client) {
            $toUpstream .= $buf;
            if (strlen($toUpstream) >= $highWater) {
                $pauseClientRead = true;
            }
        } else {
            $toClient .= $buf;
            if (strlen($toClient) >= $highWater) {
                $pauseUpstreamRead = true;
            }
        }
    }

    foreach ($write as $dst) {
        if ($dst === $upstream) {
            if ($toUpstream === '') continue;
            $written = @fwrite($upstream, $toUpstream);

            if ($written === false) {
                $reason = 'upstream-write-error';
                break 2;
            }

            if ($written > 0) {
                $toUpstream = (string)substr($toUpstream, $written);
                $bytesClientToProxmox += $written;
                $lastActivityAt = microtime(true);
            } elseif ($written === 0) {
                $zeroWriteUpstream++;
            }
        } else {
            if ($toClient === '') continue;
            $written = @fwrite($client, $toClient);

            if ($written === false) {
                $reason = 'client-write-error';
                break 2;
            }

            if ($written > 0) {
                $toClient = (string)substr($toClient, $written);
                $bytesProxmoxToClient += $written;
                $lastActivityAt = microtime(true);
            } elseif ($written === 0) {
                $zeroWriteClient++;
            }
        }
    }

    if (strlen($toUpstream) > $hardLimit) {
        $reason = 'client-to-proxmox-hard-limit';
        break;
    }
    if (strlen($toClient) > $hardLimit) {
        $reason = 'proxmox-to-client-hard-limit';
        break;
    }
    $nowStatus = microtime(true);
    if (($nowStatus - $lastStatusAt) >= 1.0) {
        $lastStatusAt = $nowStatus;
        @file_put_contents($statusFile, json_encode(array(
            'ok' => true,
            'time' => date('c'),
            'state' => 'connected',
            'runtime_ms' => (int)round(($nowStatus - $startedAt) * 1000),
            'listen_port' => $listenPort,
            'upstream' => $upHost . ':' . $upPort,
            'bytes_client_to_proxmox' => $bytesClientToProxmox,
            'bytes_proxmox_to_client' => $bytesProxmoxToClient,
            'pending_client_to_proxmox' => strlen($toUpstream),
            'pending_proxmox_to_client' => strlen($toClient),
            'pause_client_read' => $pauseClientRead,
            'pause_upstream_read' => $pauseUpstreamRead,
            'zero_write_client' => $zeroWriteClient,
            'zero_write_upstream' => $zeroWriteUpstream,
            'idle_ms' => (int)round(($nowStatus - $lastActivityAt) * 1000)
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    }
}

if (time() >= $endAt) {
    $reason = 'max-runtime';
}

$clientMeta = is_resource($client) ? @stream_get_meta_data($client) : array();
$upstreamMeta = is_resource($upstream) ? @stream_get_meta_data($upstream) : array();

@fclose($client);
@fclose($upstream);

@file_put_contents($statusFile, json_encode(array(
    'ok' => true,
    'time' => date('c'),
    'state' => 'closed',
    'reason' => $reason,
    'runtime_ms' => (int)round((microtime(true) - $startedAt) * 1000),
    'bytes_client_to_proxmox' => $bytesClientToProxmox,
    'bytes_proxmox_to_client' => $bytesProxmoxToClient,
    'pending_client_to_proxmox' => strlen($toUpstream),
    'pending_proxmox_to_client' => strlen($toClient),
    'pause_client_read' => $pauseClientRead,
    'pause_upstream_read' => $pauseUpstreamRead,
    'zero_write_client' => $zeroWriteClient,
    'zero_write_upstream' => $zeroWriteUpstream,
    'client_eof' => !empty($clientMeta['eof']),
    'upstream_eof' => !empty($upstreamMeta['eof']),
    'client_timed_out' => !empty($clientMeta['timed_out']),
    'upstream_timed_out' => !empty($upstreamMeta['timed_out'])
), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);

exit(0);
