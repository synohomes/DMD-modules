<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';
require_once __DIR__ . '/DMD-Proxmox_provision.php';
require_once __DIR__ . '/DMD-Proxmox_remote_gateway_lib.php';

$documentRoot = realpath(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '');
$moduleRealDir = realpath(__DIR__);
$dmdProxmoxBaseUrl = '/domydesk/modules/DMD-Proxmox';
if ($documentRoot !== false && $moduleRealDir !== false && strpos($moduleRealDir, $documentRoot) === 0) {
    $rel = str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot)));
    $dmdProxmoxBaseUrl = '/' . trim($rel, '/');
} else {
    $scriptName = str_replace('\\', '/', (string)(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : ''));
    if (strpos($scriptName, '/modules/DMD-Proxmox/') !== false) {
        $dmdProxmoxBaseUrl = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
    }
}
$dmdProxmoxCfgUrl = $dmdProxmoxBaseUrl . '/DMD-Proxmoxcfg.php';

if (!dmd_proxmox_has_module_assignment()) {
    http_response_code(403);
    echo "<div class='dmd-proxmoxcfg-empty'>⛔ DMD-Proxmox ne vous a pas été attribué.</div>";
    exit;
}

if (dmd_proxmox_mfa_required() && !dmd_proxmox_mfa_unlocked(false)) {
    echo "<link rel='stylesheet' href='" . htmlspecialchars($dmdProxmoxBaseUrl . '/DMD-Proxmox.css?v=263', ENT_QUOTES, 'UTF-8') . "'>";
    echo dmd_proxmox_mfa_gate_html($dmdProxmoxBaseUrl, 'cfg');
    exit;
}

$CAN_SERVER_MANAGE = dmd_proxmox_user_can('server.manage');
$CAN_VM_CREATE = dmd_proxmox_user_can('vm.create');
$CAN_ISO_UPLOAD = dmd_proxmox_user_can('iso.upload');
$CAN_NETWORK_MANAGE = dmd_proxmox_user_can('network.manage');
$CAN_ACL_MANAGE = dmd_proxmox_user_can('acl.manage');
$CAN_CFG_ACCESS = $CAN_SERVER_MANAGE || $CAN_VM_CREATE || $CAN_ISO_UPLOAD || $CAN_NETWORK_MANAGE || $CAN_ACL_MANAGE;

if (!dmd_proxmox_has_module_access() || !$CAN_CFG_ACCESS) {
    http_response_code(403);
    echo "<div class='dmd-proxmoxcfg-empty'>⛔ Aucune fonction de configuration DMD-Proxmox ne vous a été attribuée.</div>";
    exit;
}

$csrf = dmd_proxmox_csrf_token();

function dmd_proxmoxcfg_require_csrf() {
    $token = isset($_POST['csrf']) ? $_POST['csrf'] : (isset($_GET['csrf']) ? $_GET['csrf'] : '');
    if (!dmd_proxmox_csrf_valid($token)) dmd_proxmox_json(false, 'Jeton de sécurité expiré.', array(), 403);
}

function dmd_proxmoxcfg_public_server($server) {
    if (!is_array($server)) return array();
    unset($server['secret'], $server['secret_enc'], $server['remote_password_enc']);
    $fullServer = dmd_proxmox_load_server(isset($server['id']) ? $server['id'] : (isset($server['name']) ? $server['name'] : ''));
    $server['has_secret'] = dmd_proxmox_decrypt_secret($fullServer) !== '';
    $server['remote_ready'] = dmd_proxmox_decrypt_remote_password($fullServer) !== '';
    return $server;
}

function dmd_proxmoxcfg_nodes($server) {
    $r = dmd_proxmox_api($server, 'nodes', 'GET', null, 12);
    if (!$r['ok'] || !is_array($r['data'])) return array();
    $out = array();
    foreach ($r['data'] as $n) {
        if (!is_array($n) || empty($n['node'])) continue;
        $out[] = array(
            'node' => (string)$n['node'],
            'status' => isset($n['status']) ? (string)$n['status'] : 'unknown',
            'cpu' => isset($n['cpu']) ? (float)$n['cpu'] : 0,
            'maxcpu' => isset($n['maxcpu']) ? (float)$n['maxcpu'] : 0,
            'mem' => isset($n['mem']) ? (float)$n['mem'] : 0,
            'maxmem' => isset($n['maxmem']) ? (float)$n['maxmem'] : 0
        );
    }
    return $out;
}

function dmd_proxmoxcfg_node_exists($server, $node) {
    foreach (dmd_proxmoxcfg_nodes($server) as $n) {
        if (strcasecmp((string)$n['node'], (string)$node) === 0) return true;
    }
    return false;
}

function dmd_proxmoxcfg_upload_iso($server, $node, $storageId, $file) {
    if (!is_array($file) || (int)(isset($file['error']) ? $file['error'] : UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return array(false, 'Aucun fichier ISO valide reçu.');
    }
    $name = basename((string)$file['name']);
    if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'iso') return array(false, 'Seuls les fichiers .iso sont acceptés.');
    if (!is_uploaded_file($file['tmp_name'])) return array(false, 'Fichier temporaire invalide.');

    $ip = trim((string)(isset($server['ip']) ? $server['ip'] : ''));
    $port = (int)(isset($server['port']) ? $server['port'] : 8006);
    $token = trim((string)(isset($server['token_id']) ? $server['token_id'] : ''));
    $secret = dmd_proxmox_decrypt_secret($server);
    if ($ip === '' || $token === '' || $secret === '') return array(false, 'Configuration API incomplète.');

    $url = 'https://' . $ip . ':' . $port . '/api2/json/nodes/' . rawurlencode($node) . '/storage/' . rawurlencode($storageId) . '/upload';
    $mime = isset($file['type']) && $file['type'] !== '' ? $file['type'] : 'application/octet-stream';
    $cfile = new CURLFile($file['tmp_name'], $mime, $name);
    $post = array('content' => 'iso', 'filename' => $cfile);
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => array('Authorization: PVEAPIToken=' . $token . '=' . $secret),
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $post,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 0
    ));
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $err !== '') return array(false, $err !== '' ? $err : 'Erreur upload.');
    $json = json_decode($raw, true);
    if ($http < 200 || $http >= 300 || !is_array($json)) return array(false, 'HTTP ' . $http . ' - ' . $raw);
    return array(true, isset($json['data']) ? $json['data'] : 'Upload envoyé');
}


function dmd_proxmoxcfg_remote_platform() {
    $family = PHP_OS_FAMILY;
    $platform = 'generic';
    if (is_file('/etc/synoinfo.conf')) $platform='synology-dsm7';
    elseif (is_file('/etc/config/uLinux.conf') || is_dir('/share/CACHEDEV1_DATA/.qpkg')) $platform='qnap-qts';
    elseif (is_file('/.dockerenv')) $platform='docker-compose';
    elseif ($family === 'Windows') $platform='windows-iis';
    else {
        $os=''; if(is_file('/etc/os-release')) $os=strtolower((string)@file_get_contents('/etc/os-release'));
        $server=strtolower((string)(isset($_SERVER['SERVER_SOFTWARE'])?$_SERVER['SERVER_SOFTWARE']:''));
        if(strpos($os,'alpine')!==false) $platform='alpine-nginx';
        elseif(strpos($os,'arch')!==false) $platform='arch-nginx';
        elseif(strpos($os,'opensuse')!==false || strpos($os,'suse')!==false) $platform='opensuse-nginx';
        elseif(strpos($server,'nginx')!==false && (strpos($os,'debian')!==false||strpos($os,'ubuntu')!==false)) $platform='nginx-debian';
        elseif(strpos($server,'nginx')!==false) $platform='nginx-rhel';
        elseif(strpos($os,'debian')!==false||strpos($os,'ubuntu')!==false) $platform='apache-debian';
        elseif(strpos($os,'rhel')!==false||strpos($os,'rocky')!==false||strpos($os,'alma')!==false||strpos($os,'fedora')!==false) $platform='apache-rhel';
    }
    return array('id'=>$platform,'os_family'=>$family,'server_software'=>(string)(isset($_SERVER['SERVER_SOFTWARE'])?$_SERVER['SERVER_SOFTWARE']:''));
}
function dmd_proxmoxcfg_remote_manifest() {
    $file=__DIR__.'/procedures/remote-https/manifest.json'; $j=is_file($file)?json_decode((string)@file_get_contents($file),true):null;
    return is_array($j)?$j:array('procedures'=>array());
}
function dmd_proxmoxcfg_remote_procedure($id) {
    $id=preg_replace('/[^a-z0-9-]/','',strtolower((string)$id)); if($id==='')return null;
    $file=__DIR__.'/procedures/remote-https/'.$id.'.json'; $j=is_file($file)?json_decode((string)@file_get_contents($file),true):null;
    return is_array($j)?$j:null;
}

if (isset($_REQUEST['ajax'])) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    $ajax = strtolower(trim((string)$_REQUEST['ajax']));

    if ($ajax === 'mfa_security_save') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('server.manage')) {
            dmd_proxmox_json(false, 'Droit de configuration MFA refusé.', array(), 403);
        }

        $minutes = isset($_POST['lock_minutes']) ? (int)$_POST['lock_minutes'] : 0;
        $error = '';
        if (!dmd_proxmox_mfa_security_save($minutes, $error)) {
            dmd_proxmox_json(false, $error, array(), 400);
        }
        $stillUnlocked = dmd_proxmox_mfa_unlocked(false);

        dmd_proxmox_json(true, 'Timer MFA enregistré.', array(
            'settings'=>dmd_proxmox_mfa_security_settings(),
            'mfa_required'=>dmd_proxmox_mfa_required(),
            'unlocked'=>$stillUnlocked,
            'remaining_seconds'=>$stillUnlocked ? dmd_proxmox_mfa_remaining() : 0
        ), 200);
    }

    if ($ajax === 'remote_diag') {
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de diagnostic Remote refusé.', array(), 403);
        $manifest=dmd_proxmoxcfg_remote_manifest();
        dmd_proxmox_json(true, '', array(
            'gateway'=>dmd_proxmox_gateway_status(),
            'platform'=>dmd_proxmoxcfg_remote_platform(),
            'manifest'=>$manifest,
            'module_ws_path'=>$GLOBALS['dmdProxmoxBaseUrl'].'/ws/'
        ), 200);
    }
    if ($ajax === 'remote_gateway_save') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de configuration Remote refusé.', array(), 403);
        $error='';
        if(!dmd_proxmox_gateway_save_settings($_POST,$error)) dmd_proxmox_json(false,$error,array(),400);
        dmd_proxmox_json(true,'Configuration Gateway enregistrée.',array('gateway'=>dmd_proxmox_gateway_status()),200);
    }
    if ($ajax === 'remote_gateway_start') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de démarrage Remote refusé.', array(), 403);
        $error=''; $ok=dmd_proxmox_gateway_start($error);
        if(!$ok)dmd_proxmox_json(false,$error,array('gateway'=>dmd_proxmox_gateway_status()),502);
        dmd_proxmox_json(true,'Gateway Remote en ligne.',array('gateway'=>dmd_proxmox_gateway_status()),200);
    }
    if ($ajax === 'remote_procedure') {
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de consultation Remote refusé.', array(), 403);
        $p=dmd_proxmoxcfg_remote_procedure(isset($_GET['id'])?$_GET['id']:'');
        if(!is_array($p))dmd_proxmox_json(false,'Procédure introuvable.',array(),404);
        dmd_proxmox_json(true,'',array('procedure'=>$p,'gateway'=>dmd_proxmox_gateway_load_settings(),'module_ws_path'=>$GLOBALS['dmdProxmoxBaseUrl'].'/ws/'),200);
    }


    if ($ajax === 'servers') {
        $items = array();
        foreach (dmd_proxmox_list_servers(false) as $s) $items[] = dmd_proxmoxcfg_public_server($s);
        dmd_proxmox_json(true, '', array('servers' => $items), 200);
    }


    if ($ajax === 'preset_list') {
        if (!dmd_proxmox_user_can('vm.create') && !dmd_proxmox_user_can('server.manage')) {
            dmd_proxmox_json(false, 'Droit de consultation des presets refusé.', array(), 403);
        }
        $serverFilter = trim((string)(isset($_GET['server_id']) ? $_GET['server_id'] : ''));
        $items = array();
        foreach (dmd_proxmox_presets_list(false) as $preset) {
            if ($serverFilter !== '' && (string)$preset['server_id'] !== $serverFilter) continue;
            $items[] = $preset;
        }
        dmd_proxmox_json(true, '', array('presets'=>$items), 200);
    }

    if ($ajax === 'preset_save') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de gestion des presets refusé.', array(), 403);
        $input = array(
            'id' => isset($_POST['preset_id']) ? $_POST['preset_id'] : '',
            'label' => isset($_POST['label']) ? $_POST['label'] : '',
            'server_id' => isset($_POST['server_id']) ? $_POST['server_id'] : '',
            'node' => isset($_POST['node']) ? $_POST['node'] : '',
            'name_prefix' => isset($_POST['name_prefix']) ? $_POST['name_prefix'] : '',
            'ostype' => isset($_POST['ostype']) ? $_POST['ostype'] : 'l26',
            'cpu' => isset($_POST['cpu']) ? $_POST['cpu'] : 2,
            'ram' => isset($_POST['ram']) ? $_POST['ram'] : 2048,
            'disk' => isset($_POST['disk']) ? $_POST['disk'] : 20,
            'storage_vm' => isset($_POST['storage_vm']) ? $_POST['storage_vm'] : '',
            'iso' => isset($_POST['iso']) ? $_POST['iso'] : '',
            'bridge' => isset($_POST['bridge']) ? $_POST['bridge'] : '',
            'vlan' => isset($_POST['vlan']) ? $_POST['vlan'] : 0,
            'auto_start' => !empty($_POST['auto_start']),
            'after_create' => isset($_POST['after_create']) ? $_POST['after_create'] : 'vm',
            'open_count' => isset($_POST['open_count']) ? $_POST['open_count'] : 'first',
            'max_quantity' => isset($_POST['max_quantity']) ? $_POST['max_quantity'] : 10,
            'enabled' => !empty($_POST['enabled'])
        );
        $serverForPreset = dmd_proxmox_load_server($input['server_id']);
        if (!is_array($serverForPreset)) dmd_proxmox_json(false, 'Serveur du preset introuvable.', array(), 404);
        if (!dmd_proxmoxcfg_node_exists($serverForPreset, $input['node'])) dmd_proxmox_json(false, 'Node du preset invalide.', array(), 400);
        list($ok, $message, $preset) = dmd_proxmox_preset_save($input);
        if (!$ok || !is_array($preset)) dmd_proxmox_json(false, $message, array(), 400);
        dmd_proxmox_log('preset_save', 'Preset ' . $preset['label'], 'success', 'Preset de création rapide enregistré', array(
            'source'=>'cfg','preset_id'=>$preset['id'],'server_id'=>$preset['server_id'],'node'=>$preset['node'],'storage'=>$preset['storage_vm'],'iso'=>$preset['iso'],'bridge'=>$preset['bridge'],'vlan'=>$preset['vlan']
        ));
        dmd_proxmox_json(true, $message, array('preset'=>$preset), 200);
    }

    if ($ajax === 'preset_delete') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de gestion des presets refusé.', array(), 403);
        $id = trim((string)(isset($_POST['preset_id']) ? $_POST['preset_id'] : ''));
        $preset = dmd_proxmox_preset_get($id);
        if (!is_array($preset)) dmd_proxmox_json(false, 'Preset introuvable.', array(), 404);
        if (!dmd_proxmox_preset_delete($id)) dmd_proxmox_json(false, 'Suppression du preset impossible.', array(), 500);
        dmd_proxmox_log('preset_delete', 'Preset ' . $preset['label'], 'success', 'Preset de création rapide supprimé', array('source'=>'cfg','preset_id'=>$id,'server_id'=>$preset['server_id']));
        dmd_proxmox_json(true, 'Preset supprimé.', array(), 200);
    }

    if ($ajax === 'bootstrap_server') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de gestion serveur refusé.', array(), 403);

        $oldId = trim((string)(isset($_POST['old_id']) ? $_POST['old_id'] : ''));
        $name = trim((string)(isset($_POST['name']) ? $_POST['name'] : ''));
        $ip = trim((string)(isset($_POST['ip']) ? $_POST['ip'] : ''));
        $port = (int)(isset($_POST['port']) ? $_POST['port'] : 8006);
        $adminUser = trim((string)(isset($_POST['admin_user']) ? $_POST['admin_user'] : 'root@pam'));
        $adminPassword = (string)(isset($_POST['admin_password']) ? $_POST['admin_password'] : '');

        if ($name === '' || $ip === '' || $adminUser === '' || $adminPassword === '') {
            dmd_proxmox_json(false, 'Nom, IP/DNS, utilisateur administrateur et mot de passe sont obligatoires.', array(), 400);
        }
        if (strpos($adminUser, '@') === false) $adminUser .= '@pam';
        if ($port <= 0 || $port > 65535) $port = 8006;
        $id = dmd_proxmox_slug($name);
        if ($id === '') dmd_proxmox_json(false, 'Nom de serveur invalide.', array(), 400);

        $existing = $oldId !== '' ? dmd_proxmox_load_server($oldId) : dmd_proxmox_load_server($id);
        if ($oldId === '' && is_array($existing)) {
            dmd_proxmox_json(false, 'Un serveur portant ce nom existe déjà. Sélectionne-le pour renouveler son accès.', array(), 409);
        }
        $preferredServiceUser = is_array($existing) && !empty($existing['proxmox_user']) ? (string)$existing['proxmox_user'] : '';
        $preferredTokenName = is_array($existing) ? dmd_proxmox_token_name(isset($existing['token_id']) ? $existing['token_id'] : '') : '';
        $bootstrap = dmd_proxmox_bootstrap_api_access($ip, $port, $adminUser, $adminPassword, $preferredServiceUser, $preferredTokenName);
        $adminPassword = null;
        unset($_POST['admin_password']);

        if (empty($bootstrap['ok'])) {
            dmd_proxmox_log('server_bootstrap', $name, 'error', 'Création automatique de l’accès DMD-Proxmox en erreur', array(
                'server_id' => $id,
                'ip' => $ip,
                'port' => $port,
                'error' => isset($bootstrap['error']) ? $bootstrap['error'] : 'Erreur inconnue'
            ));
            dmd_proxmox_json(false, isset($bootstrap['error']) ? $bootstrap['error'] : 'Configuration automatique impossible.', array(), 502);
        }

        $secretEnc = dmd_proxmox_encrypt_secret((string)$bootstrap['secret']);
        if ($secretEnc === '') dmd_proxmox_json(false, 'Token créé sur Proxmox mais chiffrement local du secret impossible.', array(), 500);
        $remotePasswordEnc = dmd_proxmox_encrypt_secret((string)(isset($bootstrap['remote_password']) ? $bootstrap['remote_password'] : ''));
        if ($remotePasswordEnc === '') dmd_proxmox_json(false, 'Compte Remote créé sur Proxmox mais chiffrement local de son secret impossible.', array(), 500);

        $data = is_array($existing) ? $existing : array();
        $data['id'] = $id;
        $data['name'] = $name;
        $data['ip'] = $ip;
        $data['port'] = $port;
        $data['token_id'] = (string)$bootstrap['token_id'];
        $data['secret_enc'] = $secretEnc;
        $data['remote_password_enc'] = $remotePasswordEnc;
        $data['proxmox_user'] = (string)$bootstrap['user'];
        $data['proxmox_role'] = (string)$bootstrap['role'];
        $data['provisioning'] = 'automatic';
        unset($data['secret']);
        if (empty($data['created'])) $data['created'] = date('c');
        $data['updated'] = date('c');

        if (!dmd_proxmox_save_server($data, $oldId)) {
            dmd_proxmox_json(false, 'Accès créé sur Proxmox mais écriture de la configuration DoMyDesk impossible.', array(), 500);
        }
        $verify = dmd_proxmox_api($data, 'version', 'GET', null, 10);
        $verified = !empty($verify['ok']);
        dmd_proxmox_log('server_bootstrap', $name, $verified ? 'success' : 'warning', $verified ? 'Compte technique et API Token DMD-Proxmox uniques créés automatiquement' : 'Accès DMD-Proxmox créé, mais le test final du token a échoué', array(
            'server_id' => $id,
            'ip' => $ip,
            'port' => $port,
            'proxmox_user' => (string)$bootstrap['user'],
            'token_id' => (string)$bootstrap['token_id'],
            'role' => (string)$bootstrap['role'],
            'created_user' => !empty($bootstrap['created_user']),
            'renewed_token' => !empty($bootstrap['renewed_token']),
            'verified' => $verified,
            'verify_error' => $verified ? '' : (isset($verify['error']) ? $verify['error'] : '')
        ));

        $message = $verified
            ? 'Configuration terminée : ' . (string)$bootstrap['user'] . ' + ' . (string)$bootstrap['token_id'] . ' créés et connexion validée.'
            : 'Utilisateur et token uniques créés/enregistrés, mais le test final a échoué : ' . (isset($verify['error']) ? $verify['error'] : 'erreur inconnue');
        dmd_proxmox_json(true, $message, array(
            'server' => dmd_proxmoxcfg_public_server($data),
            'verified' => $verified,
            'proxmox_user' => (string)$bootstrap['user'],
            'token_id' => (string)$bootstrap['token_id'],
            'role' => (string)$bootstrap['role']
        ), 200);
    }

    if ($ajax === 'save_server') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de gestion serveur refusé.', array(), 403);
        $oldId = trim((string)(isset($_POST['old_id']) ? $_POST['old_id'] : ''));
        $name = trim((string)(isset($_POST['name']) ? $_POST['name'] : ''));
        $ip = trim((string)(isset($_POST['ip']) ? $_POST['ip'] : ''));
        $port = (int)(isset($_POST['port']) ? $_POST['port'] : 8006);
        $token = trim((string)(isset($_POST['token_id']) ? $_POST['token_id'] : ''));
        $secret = trim((string)(isset($_POST['secret']) ? $_POST['secret'] : ''));
        if ($name === '' || $ip === '' || $token === '') dmd_proxmox_json(false, 'Nom, IP/DNS et Token ID sont obligatoires.', array(), 400);
        if ($port <= 0 || $port > 65535) $port = 8006;
        $id = dmd_proxmox_slug($name);
        if ($id === '') dmd_proxmox_json(false, 'Nom de serveur invalide.', array(), 400);
        $existing = $oldId !== '' ? dmd_proxmox_load_server($oldId) : dmd_proxmox_load_server($id);
        if ($oldId === '' && is_array($existing)) dmd_proxmox_json(false, 'Un serveur portant ce nom existe déjà.', array(), 409);
        $data = is_array($existing) ? $existing : array();
        $data['id'] = $id;
        $data['name'] = $name;
        $data['ip'] = $ip;
        $data['port'] = $port;
        $data['token_id'] = $token;
        if ($secret !== '') {
            $enc = dmd_proxmox_encrypt_secret($secret);
            if ($enc === '') dmd_proxmox_json(false, 'Impossible de chiffrer le secret API.', array(), 500);
            $data['secret_enc'] = $enc;
            unset($data['secret']);
        } elseif (empty($data['secret_enc']) && empty($data['secret'])) {
            dmd_proxmox_json(false, 'Secret API obligatoire pour un nouveau serveur.', array(), 400);
        }
        if (empty($data['created'])) $data['created'] = date('c');
        $data['updated'] = date('c');
        if (!dmd_proxmox_save_server($data, $oldId)) dmd_proxmox_json(false, 'Écriture de la configuration impossible.', array(), 500);
        dmd_proxmox_log('server_save', $name, 'success', $existing ? 'Serveur Proxmox modifié' : 'Serveur Proxmox ajouté', array('source'=>'cfg','server_id' => $id, 'ip' => $ip, 'port' => $port, 'token_id' => $token, 'secret_changed' => $secret !== ''));
        dmd_proxmox_json(true, 'Serveur enregistré.', array('server' => dmd_proxmoxcfg_public_server($data)), 200);
    }

    if ($ajax === 'delete_server') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de gestion serveur refusé.', array(), 403);
        $id = trim((string)(isset($_POST['server_id']) ? $_POST['server_id'] : ''));
        $server = dmd_proxmox_load_server($id);
        if (!is_array($server)) dmd_proxmox_json(false, 'Serveur introuvable.', array(), 404);
        $cleanup = dmd_proxmox_cleanup_automatic_access($server);
        if (empty($cleanup['ok'])) {
            dmd_proxmox_log('server_delete', isset($server['name']) ? $server['name'] : $id, 'error', 'Suppression DMD-Proxmox annulée : révocation distante impossible', array(
                'server_id' => $id,
                'ip' => isset($server['ip']) ? $server['ip'] : '',
                'error' => isset($cleanup['error']) ? $cleanup['error'] : 'Erreur inconnue'
            ));
            dmd_proxmox_json(false, isset($cleanup['error']) ? $cleanup['error'] : 'Révocation distante impossible.', array(), 502);
        }

        $file = dmd_proxmox_server_file(isset($server['id']) ? $server['id'] : $id);
        $cache = dmd_proxmox_cache_file($server);
        $ok = is_file($file) ? @unlink($file) : false;
        if (is_file($cache)) @unlink($cache);
        if (!$ok) dmd_proxmox_json(false, 'Accès distant révoqué, mais suppression locale impossible.', array(), 500);

        $warning = isset($cleanup['warning']) ? trim((string)$cleanup['warning']) : '';
        $manual = !empty($cleanup['skipped']);
        $message = $manual
            ? 'Serveur supprimé de DoMyDesk. Le token manuel Proxmox n’a pas été touché.'
            : 'Serveur supprimé et accès DMD-Proxmox révoqué sur Proxmox.';
        if ($warning !== '') $message .= ' ' . $warning;

        dmd_proxmox_log('server_delete', isset($server['name']) ? $server['name'] : $id, 'success', 'Serveur Proxmox supprimé', array(
            'server_id' => $id,
            'ip' => isset($server['ip']) ? $server['ip'] : '',
            'remote_cleanup' => !$manual,
            'token_deleted' => !empty($cleanup['token_deleted']),
            'user_deleted' => !empty($cleanup['user_deleted']),
            'warning' => $warning
        ));
        dmd_proxmox_json(true, $message, array(
            'token_deleted' => !empty($cleanup['token_deleted']),
            'user_deleted' => !empty($cleanup['user_deleted']),
            'manual_token_untouched' => $manual
        ), 200);
    }

    $serverId = trim((string)(isset($_REQUEST['server_id']) ? $_REQUEST['server_id'] : (isset($_REQUEST['srv']) ? $_REQUEST['srv'] : '')));
    $server = dmd_proxmox_load_server($serverId);
    if (!is_array($server)) dmd_proxmox_json(false, 'Serveur Proxmox introuvable.', array(), 404);

    if ($ajax === 'test') {
        if (!dmd_proxmox_user_can('server.manage')) dmd_proxmox_json(false, 'Droit de gestion serveur refusé.', array(), 403);
        $v = dmd_proxmox_api($server, 'version', 'GET', null, 10);
        $nodes = dmd_proxmoxcfg_nodes($server);
        if (!$v['ok']) dmd_proxmox_json(false, $v['error'], array(), 502);
        dmd_proxmox_json(true, 'Connexion Proxmox OK.', array('version' => $v['data'], 'nodes' => $nodes), 200);
    }

    if ($ajax === 'context') {
        $nodes = dmd_proxmoxcfg_nodes($server);
        $vms = dmd_proxmox_cluster_vms($server);
        $nextid = dmd_proxmox_next_vmid($server);
        dmd_proxmox_json(true, '', array('nodes' => $nodes, 'vms' => $vms['ok'] ? $vms['data'] : array(), 'nextid' => $nextid), 200);
    }

    if ($ajax === 'node_data') {
        $node = trim((string)(isset($_GET['node']) ? $_GET['node'] : ''));
        if ($node === '' || !dmd_proxmoxcfg_node_exists($server, $node)) dmd_proxmox_json(false, 'Node Proxmox invalide.', array(), 400);
        $storagesRes = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/storage', 'GET', null, 12);
        $networkRes = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/network', 'GET', null, 12);
        $storages = $storagesRes['ok'] && is_array($storagesRes['data']) ? $storagesRes['data'] : array();
        $network = $networkRes['ok'] && is_array($networkRes['data']) ? $networkRes['data'] : array();
        $isos = array();
        foreach ($storages as $st) {
            $sid = isset($st['storage']) ? (string)$st['storage'] : '';
            if ($sid === '') continue;
            $content = isset($st['content']) ? (string)$st['content'] : '';
            if (strpos($content, 'iso') === false) continue;
            $r = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/storage/' . rawurlencode($sid) . '/content', 'GET', null, 12);
            if (!$r['ok'] || !is_array($r['data'])) continue;
            foreach ($r['data'] as $item) {
                if (!is_array($item) || (isset($item['content']) ? $item['content'] : '') !== 'iso') continue;
                $isos[] = array('volid' => isset($item['volid']) ? $item['volid'] : '', 'storage' => $sid, 'size' => isset($item['size']) ? $item['size'] : 0);
            }
        }
        $bridges = array();
        $vlans = array();
        foreach ($network as $net) {
            if (!is_array($net)) continue;
            if ((isset($net['type']) ? $net['type'] : '') === 'bridge' && !empty($net['iface'])) $bridges[] = $net['iface'];
            if (isset($net['tag']) && is_numeric($net['tag'])) $vlans[] = (int)$net['tag'];
            $iface = isset($net['iface']) ? (string)$net['iface'] : '';
            if (preg_match('/vlan(\d+)/i', $iface, $m)) $vlans[] = (int)$m[1];
            if (preg_match('/\.(\d{1,4})$/', $iface, $m)) $vlans[] = (int)$m[1];
        }
        $bridges = array_values(array_unique($bridges));
        $vlans = array_values(array_unique(array_filter($vlans, function($v) { return $v >= 1 && $v <= 4094; })));
        sort($vlans, SORT_NUMERIC);
        dmd_proxmox_json(true, '', array('storages' => $storages, 'isos' => $isos, 'bridges' => $bridges, 'vlans' => $vlans), 200);
    }

    if ($ajax === 'create_vm') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('vm.create')) dmd_proxmox_json(false, 'Droit de création VM refusé.', array(), 403);
        $node = trim((string)(isset($_POST['node']) ? $_POST['node'] : ''));
        if ($node === '' || !dmd_proxmoxcfg_node_exists($server, $node)) dmd_proxmox_json(false, 'Node Proxmox invalide.', array(), 400);
        $vmidRaw = trim((string)(isset($_POST['vmid']) ? $_POST['vmid'] : ''));
        $vmid = $vmidRaw === '' ? dmd_proxmox_next_vmid($server) : (int)$vmidRaw;
        if ($vmid < 100 || $vmid > 999999999) dmd_proxmox_json(false, 'VMID invalide.', array(), 400);
        if (dmd_proxmox_resolve_vm($server, $vmid, '') !== null) dmd_proxmox_json(false, 'Le VMID ' . $vmid . ' existe déjà sur ce Proxmox.', array(), 409);
        $name = trim((string)(isset($_POST['vmname']) ? $_POST['vmname'] : ''));
        $cpu = max(1, min(128, (int)(isset($_POST['cpu']) ? $_POST['cpu'] : 2)));
        $ram = max(128, (int)(isset($_POST['ram']) ? $_POST['ram'] : 2048));
        $disk = max(1, (int)(isset($_POST['disk']) ? $_POST['disk'] : 20));
        $iso = trim((string)(isset($_POST['iso']) ? $_POST['iso'] : ''));
        $bridge = trim((string)(isset($_POST['bridge']) ? $_POST['bridge'] : 'vmbr0'));
        $vlan = (int)(isset($_POST['vlan']) ? $_POST['vlan'] : 0);
        $ostype = trim((string)(isset($_POST['ostype']) ? $_POST['ostype'] : 'l26'));
        $storageVm = trim((string)(isset($_POST['storage_vm']) ? $_POST['storage_vm'] : 'local-lvm'));
        if ($name === '' || $storageVm === '' || $bridge === '') dmd_proxmox_json(false, 'Nom, stockage VM et bridge sont obligatoires.', array(), 400);
        if ($vlan < 0 || $vlan > 4094) dmd_proxmox_json(false, 'VLAN invalide.', array(), 400);
        $payload = array(
            'vmid' => $vmid,
            'name' => $name,
            'sockets' => 1,
            'cores' => $cpu,
            'memory' => $ram,
            'scsihw' => 'virtio-scsi-pci',
            'scsi0' => $storageVm . ':' . $disk,
            'net0' => 'virtio,bridge=' . $bridge . ($vlan > 0 ? ',tag=' . $vlan : ''),
            'ostype' => $ostype,
            'agent' => 1
        );
        if ($iso !== '') $payload['ide2'] = $iso . ',media=cdrom';
        $res = dmd_proxmox_api($server, 'nodes/' . rawurlencode($node) . '/qemu', 'POST', $payload, 30);
        if (!$res['ok']) {
            dmd_proxmox_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'error', 'Création VM en erreur', array(
                'source'=>'cfg','server_id'=>$serverId,'node'=>$node,'vmid'=>$vmid,'type'=>'qemu',
                'name'=>$name,'vm_name'=>$name,'storage'=>$storageVm,'iso'=>$iso,'bridge'=>$bridge,'vlan'=>$vlan,
                'started'=>false,'error'=>$res['error']
            ));
            dmd_proxmox_json(false, $res['error'], array('vmid' => $vmid), $res['http'] >= 400 ? $res['http'] : 502);
        }
        dmd_proxmox_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'success', 'VM créée sur Proxmox', array(
            'source'=>'cfg','server_id'=>$serverId,'node'=>$node,'vmid'=>$vmid,'type'=>'qemu',
            'name'=>$name,'vm_name'=>$name,'storage'=>$storageVm,'iso'=>$iso,'bridge'=>$bridge,'vlan'=>$vlan,
            'started'=>false,'upid'=>$res['data']
        ));
        dmd_proxmox_json(true, 'VM #' . $vmid . ' créée sur ' . $node . '.', array('vmid' => $vmid, 'node' => $node, 'upid' => $res['data']), 200);
    }

    if ($ajax === 'upload_iso') {
        dmd_proxmoxcfg_require_csrf();
        if (!dmd_proxmox_user_can('iso.upload')) dmd_proxmox_json(false, 'Droit d’upload ISO refusé.', array(), 403);
        $node = trim((string)(isset($_POST['node']) ? $_POST['node'] : ''));
        $storageId = trim((string)(isset($_POST['storage_id']) ? $_POST['storage_id'] : ''));
        if ($node === '' || $storageId === '' || !dmd_proxmoxcfg_node_exists($server, $node)) dmd_proxmox_json(false, 'Node ou stockage invalide.', array(), 400);
        list($ok, $msg) = dmd_proxmoxcfg_upload_iso($server, $node, $storageId, isset($_FILES['iso_file']) ? $_FILES['iso_file'] : null);
        if (!$ok) dmd_proxmox_json(false, $msg, array(), 502);
        dmd_proxmox_log('iso_upload', isset($_FILES['iso_file']['name']) ? basename($_FILES['iso_file']['name']) : 'ISO', 'success', 'ISO envoyée vers Proxmox', array('source'=>'cfg','server_id' => $serverId, 'node' => $node, 'storage' => $storageId, 'iso'=>isset($_FILES['iso_file']['name'])?basename($_FILES['iso_file']['name']):'ISO', 'upid' => $msg));
        dmd_proxmox_json(true, 'Upload ISO envoyé à Proxmox.', array('upid' => $msg), 200);
    }

    dmd_proxmox_json(false, 'Opération inconnue.', array(), 400);
}

$mfaSecuritySettings = dmd_proxmox_mfa_security_settings();
$serversPublic = array();
foreach (dmd_proxmox_list_servers(false) as $s) $serversPublic[] = dmd_proxmoxcfg_public_server($s);
?>
<link rel="stylesheet" href="<?= htmlspecialchars($dmdProxmoxBaseUrl . '/DMD-Proxmoxcfg.css?v=264', ENT_QUOTES, 'UTF-8') ?>">
<div class="dmd-proxmoxcfg" data-dmd-proxmoxcfg data-api="<?= htmlspecialchars($dmdProxmoxCfgUrl, ENT_QUOTES, 'UTF-8') ?>" data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" data-can-server-manage="<?= $CAN_SERVER_MANAGE ? '1' : '0' ?>" data-can-vm-create="<?= $CAN_VM_CREATE ? '1' : '0' ?>" data-can-iso-upload="<?= $CAN_ISO_UPLOAD ? '1' : '0' ?>" data-can-network-manage="<?= $CAN_NETWORK_MANAGE ? '1' : '0' ?>" data-mfa-lock-minutes="<?= (int)$mfaSecuritySettings['lock_minutes'] ?>">
  <header class="dmd-proxmoxcfg-head">
    <div>
      <span class="dmd-proxmoxcfg-kicker">Module système · DoMyDesk 1.2.x</span>
      <h3>DMD-Proxmox · Administration Proxmox</h3>
      <p>Serveurs, nodes, VMID, stockage, ISO et réseau sont maintenant traités comme des objets distincts.</p>
    </div>
    <?php if ($CAN_SERVER_MANAGE): ?><button type="button" class="dmd-proxmoxcfg-btn" data-new-server>+ Serveur</button><?php endif; ?>
  </header>

  <div class="dmd-proxmoxcfg-grid">
    <aside class="dmd-proxmoxcfg-side">
      <div class="dmd-proxmoxcfg-side-title"><strong>Serveurs Proxmox</strong><span data-server-count><?= count($serversPublic) ?></span></div>
      <div class="dmd-proxmoxcfg-server-list" data-server-list></div>
    </aside>

    <main class="dmd-proxmoxcfg-main">
      <section class="dmd-proxmoxcfg-panel"<?= $CAN_SERVER_MANAGE ? '' : ' hidden' ?>>
        <div class="dmd-proxmoxcfg-panel-head"><div><h4>Connexion API</h4><p>Pour un homelab, DMD-Proxmox crée automatiquement un compte technique unique et son API Token. Le mot de passe administrateur n’est jamais enregistré.</p></div><span data-api-state class="dmd-proxmoxcfg-badge">Non testé</span></div>
        <form data-server-form>
          <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="old_id" data-old-id>
          <div class="dmd-proxmoxcfg-fields">
            <label><span>Nom</span><input name="name" data-name required placeholder="PVE-PROD"></label>
            <label><span>IP / DNS</span><input name="ip" data-ip required placeholder="10.10.3.20"></label>
            <label><span>Port</span><input type="number" name="port" data-port value="8006" min="1" max="65535"></label>
          </div>

          <div class="dmd-proxmoxcfg-actions">
            <button class="dmd-proxmoxcfg-btn" type="button" data-mode-auto>Configuration automatique</button>
            <button class="dmd-proxmoxcfg-btn" type="button" data-mode-manual>J’ai déjà un API Token</button>
          </div>

          <div data-auto-fields>
            <div class="dmd-proxmoxcfg-fields">
              <label><span>Utilisateur administrateur Proxmox</span><input name="admin_user" data-admin-user value="root@pam" autocomplete="username" placeholder="root@pam"></label>
              <label><span>Mot de passe administrateur</span><input type="password" name="admin_password" data-admin-password autocomplete="current-password" placeholder="Utilisé une seule fois"></label>
            </div>
            <p class="dmd-proxmoxcfg-muted">DMD-Proxmox se connecte une seule fois avec ce compte, crée un utilisateur unique du type <strong>domydesk_xxxxxxxx@pve</strong>, lui attribue <strong>Administrator</strong>, crée un token unique <strong>dmd_proxmox_xxxxxxxx</strong>, puis n’utilise plus que cet accès technique.</p>
          </div>

          <div data-manual-fields hidden>
            <div class="dmd-proxmoxcfg-fields">
              <label><span>Token ID</span><input name="token_id" data-token placeholder="user@pve!domydesk"></label>
              <label><span>Secret API</span><input type="password" name="secret" data-secret autocomplete="new-password" placeholder="Vide = conserver le secret déjà enregistré"></label>
            </div>
          </div>

          <div class="dmd-proxmoxcfg-actions">
            <button class="dmd-proxmoxcfg-btn" type="button" data-bootstrap-server>Créer l’accès DMD-Proxmox</button>
            <button class="dmd-proxmoxcfg-btn" type="submit" data-manual-save hidden>Enregistrer le token</button>
            <button class="dmd-proxmoxcfg-btn" type="button" data-test-server>Tester</button>
            <button class="dmd-proxmoxcfg-btn danger" type="button" data-delete-server hidden>Supprimer</button>
          </div>
          <div class="dmd-proxmoxcfg-msg" data-server-msg></div>
        </form>
      </section>

      <?php if ($CAN_SERVER_MANAGE): ?>
      <section class="dmd-proxmoxcfg-panel dmd-proxmoxcfg-security" data-mfa-security-panel>
        <div class="dmd-proxmoxcfg-panel-head">
          <div>
            <h4>Sécurité MFA du module</h4>
            <p>Ce timer s’applique uniquement aux comptes qui ont activé le MFA DoMyDesk. Un compte sans MFA continue d’utiliser DMD-Proxmox normalement, sans verrouillage supplémentaire.</p>
          </div>
          <span class="dmd-proxmoxcfg-badge">MFA central DoMyDesk</span>
        </div>

        <form data-mfa-security-form>
          <div class="dmd-proxmoxcfg-fields">
            <label>
              <span>Verrouillage automatique après</span>
              <div class="dmd-proxmoxcfg-inline-field">
                <input type="number" name="lock_minutes" data-mfa-lock-minutes min="1" max="720" step="1" value="<?= (int)$mfaSecuritySettings['lock_minutes'] ?>" required>
                <span>minute(s)</span>
              </div>
            </label>
          </div>

          <p class="dmd-proxmoxcfg-muted">
            Durée absolue après la validation mot de passe + MFA. L’utilisation du module ne repousse pas l’échéance.
            Valeur autorisée : 1 à 720 minutes.
          </p>

          <div class="dmd-proxmoxcfg-actions">
            <button type="submit" class="dmd-proxmoxcfg-btn">Enregistrer le timer MFA</button>
          </div>
          <div class="dmd-proxmoxcfg-msg" data-mfa-security-msg></div>
        </form>
      </section>

      <section class="dmd-proxmoxcfg-panel dmd-proxmoxcfg-remote" data-remote-panel>
        <div class="dmd-proxmoxcfg-panel-head">
          <div><h4>Remote HTTPS/WSS</h4><p>Une seule Gateway fixe reçoit les WebSockets publics puis route chaque session vers son bridge éphémère interne.</p></div>
          <span class="dmd-proxmoxcfg-badge" data-remote-state>Diagnostic…</span>
        </div>
        <div class="dmd-proxmoxcfg-remote-grid">
          <form data-remote-form>
            <div class="dmd-proxmoxcfg-fields">
              <label><span>Adresse d’écoute Gateway</span><input name="listen_host" data-remote-bind value="127.0.0.1" placeholder="127.0.0.1"></label>
              <label><span>Port Gateway fixe</span><input type="number" name="listen_port" data-remote-port value="6079" min="1024" max="65535"></label>
              <label><span>Publication WSS</span><select name="public_mode" data-remote-public-mode><option value="same_origin">Même domaine que DoMyDesk</option><option value="custom">URL WSS dédiée</option></select></label>
              <label data-remote-public-url-wrap hidden><span>URL WSS publique</span><input name="public_wss_url" data-remote-public-url placeholder="wss://remote.exemple.fr"></label>
            </div>
            <p class="dmd-proxmoxcfg-muted">Par défaut la Gateway écoute seulement sur 127.0.0.1. Ne mets une IP LAN/VPN que si ton reverse proxy est sur une autre machine. Évite 0.0.0.0 sans firewall.</p>
            <div class="dmd-proxmoxcfg-actions"><button type="submit" class="dmd-proxmoxcfg-btn">Enregistrer</button><button type="button" class="dmd-proxmoxcfg-btn" data-remote-start>Démarrer / tester</button><button type="button" class="dmd-proxmoxcfg-btn" data-remote-refresh>↻ Diagnostic</button></div>
            <div class="dmd-proxmoxcfg-msg" data-remote-msg></div>
          </form>
          <div class="dmd-proxmoxcfg-remote-diag">
            <div data-remote-diag></div>
            <label><span>Procédure d’installation</span><select data-remote-procedure></select></label>
            <div class="dmd-proxmoxcfg-procedure" data-remote-procedure-body></div>
          </div>
        </div>
      </section>
      <?php endif; ?>

      <section class="dmd-proxmoxcfg-panel" data-vm-panel hidden>
        <div class="dmd-proxmoxcfg-panel-head">
          <div><h4>Créer une VM QEMU</h4><p>Si tu saisis un VMID, DMD-Proxmox l’utilise exactement. Si tu le laisses vide, Proxmox fournit le prochain ID libre.</p></div>
          <span class="dmd-proxmoxcfg-badge" data-nextid>VMID —</span>
        </div>
        <form data-vm-form>
          <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <div class="dmd-proxmoxcfg-fields">
            <label><span>Node Proxmox</span><select name="node" data-node required></select></label>
            <label><span>VMID</span><input type="number" name="vmid" data-vmid min="100" placeholder="Auto"></label>
            <label><span>Nom VM</span><input name="vmname" required placeholder="VM-SQL01"></label>
            <label><span>Type système</span><select name="ostype"><option value="l26">Linux</option><option value="win11">Windows 11 / récent</option><option value="win10">Windows 10</option><option value="other">Autre</option></select></label>
            <label><span>CPU</span><input type="number" name="cpu" value="2" min="1" max="128"></label>
            <label><span>RAM (Mo)</span><input type="number" name="ram" value="2048" min="128" step="128"></label>
            <label><span>Disque (Go)</span><input type="number" name="disk" value="20" min="1"></label>
            <label><span>Stockage VM</span><select name="storage_vm" data-storage-vm required></select></label>
            <label><span>ISO</span><select name="iso" data-iso><option value="">Aucune ISO</option></select></label>
            <label><span>Bridge</span><select name="bridge" data-bridge required></select></label>
            <label><span>VLAN</span><select name="vlan" data-vlan><option value="">Aucun VLAN</option></select></label>
          </div>
          <div class="dmd-proxmoxcfg-actions"><button class="dmd-proxmoxcfg-btn" type="submit">Créer la VM</button></div>
          <div class="dmd-proxmoxcfg-msg" data-vm-msg></div>
        </form>
      </section>

      <section class="dmd-proxmoxcfg-panel" data-preset-panel hidden>
        <div class="dmd-proxmoxcfg-panel-head">
          <div><h4>Presets ActionHub · création rapide</h4><p>Prépare une configuration une seule fois. ActionHub génère ensuite automatiquement VMID et nom, peut créer plusieurs VM et ouvrir leur fiche ou leur Remote.</p></div>
          <span class="dmd-proxmoxcfg-badge" data-preset-count>0 preset</span>
        </div>
        <div class="dmd-proxmoxcfg-preset-layout">
          <div class="dmd-proxmoxcfg-preset-list" data-preset-list></div>
          <?php if ($CAN_SERVER_MANAGE): ?>
          <form data-preset-form>
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="preset_id" data-preset-id>
            <div class="dmd-proxmoxcfg-fields">
              <label><span>Nom du preset</span><input name="label" data-preset-label required placeholder="Linux test"></label>
              <label><span>Préfixe nom automatique</span><input name="name_prefix" data-preset-prefix placeholder="LINUX"></label>
              <label><span>Node Proxmox</span><select name="node" data-preset-node required></select></label>
              <label><span>Type système</span><select name="ostype" data-preset-ostype><option value="l26">Linux</option><option value="win11">Windows 11 / récent</option><option value="win10">Windows 10</option><option value="other">Autre</option></select></label>
              <label><span>CPU</span><input type="number" name="cpu" data-preset-cpu value="2" min="1" max="128"></label>
              <label><span>RAM (Mo)</span><input type="number" name="ram" data-preset-ram value="4096" min="128" step="128"></label>
              <label><span>Disque (Go)</span><input type="number" name="disk" data-preset-disk value="32" min="1"></label>
              <label><span>Stockage VM</span><select name="storage_vm" data-preset-storage required></select></label>
              <label><span>ISO</span><select name="iso" data-preset-iso><option value="">Aucune ISO</option></select></label>
              <label><span>Bridge</span><select name="bridge" data-preset-bridge required></select></label>
              <label><span>VLAN</span><select name="vlan" data-preset-vlan><option value="0">Aucun VLAN</option></select></label>
              <label><span>Maximum par lancement</span><input type="number" name="max_quantity" data-preset-max value="10" min="1" max="20"></label>
              <label><span>Après création</span><select name="after_create" data-preset-after><option value="none">Ne rien ouvrir</option><option value="vm" selected>Ouvrir la fiche VM</option><option value="remote">Ouvrir le Remote</option></select></label>
              <label><span>Si plusieurs VM</span><select name="open_count" data-preset-open-count><option value="first">Première uniquement</option><option value="all">Toutes</option></select></label>
              <label class="dmd-proxmoxcfg-check"><input type="checkbox" name="auto_start" value="1" data-preset-autostart checked><span>Démarrer automatiquement</span></label>
              <label class="dmd-proxmoxcfg-check"><input type="checkbox" name="enabled" value="1" data-preset-enabled checked><span>Disponible dans ActionHub</span></label>
            </div>
            <div class="dmd-proxmoxcfg-actions">
              <button class="dmd-proxmoxcfg-btn" type="button" data-preset-new>Nouveau</button>
              <button class="dmd-proxmoxcfg-btn" type="submit">Enregistrer le preset</button>
              <button class="dmd-proxmoxcfg-btn danger" type="button" data-preset-delete hidden>Supprimer</button>
            </div>
            <div class="dmd-proxmoxcfg-msg" data-preset-msg></div>
          </form>
          <?php else: ?>
          <p class="dmd-proxmoxcfg-muted">Les presets sont préparés par un administrateur. Ils deviennent ensuite disponibles dans ActionHub selon le droit « Créer une VM ».</p>
          <?php endif; ?>
        </div>
      </section>

      <section class="dmd-proxmoxcfg-panel" data-iso-panel hidden>
        <div class="dmd-proxmoxcfg-panel-head"><div><h4>ISO</h4><p>Upload vers le node et le stockage ISO sélectionnés.</p></div></div>
        <form data-iso-form enctype="multipart/form-data">
          <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <div class="dmd-proxmoxcfg-fields">
            <label><span>Node</span><select name="node" data-iso-node required></select></label>
            <label><span>Stockage ISO</span><select name="storage_id" data-storage-iso required></select></label>
            <label class="dmd-proxmoxcfg-wide"><span>Fichier ISO</span><input type="file" name="iso_file" accept=".iso,application/octet-stream" required></label>
          </div>
          <div class="dmd-proxmoxcfg-actions"><button class="dmd-proxmoxcfg-btn" type="submit">Envoyer l’ISO</button></div>
          <div class="dmd-proxmoxcfg-msg" data-iso-msg></div>
        </form>
      </section>

      <section class="dmd-proxmoxcfg-panel" data-vm-list-panel hidden>
        <div class="dmd-proxmoxcfg-panel-head"><div><h4>VM & conteneurs détectés</h4><p>Vue cluster : le node réel est conservé avec chaque VMID.</p></div><span class="dmd-proxmoxcfg-badge" data-vm-count>0</span></div>
        <div class="dmd-proxmoxcfg-table-wrap"><table><thead><tr><th>VMID</th><th>Type</th><th>Nom</th><th>Node</th><th>État</th></tr></thead><tbody data-vm-list></tbody></table></div>
      </section>
    </main>
  </div>
</div>

<script>
(function(){
  const root=document.querySelector('[data-dmd-proxmoxcfg]'); if(!root || root.dataset.ready==='1') return; root.dataset.ready='1';
  const csrf=root.dataset.csrf||''; const apiUrl=root.dataset.api||<?= json_encode($dmdProxmoxCfgUrl, JSON_UNESCAPED_SLASHES) ?>;
  const canServerManage=root.dataset.canServerManage==='1';
  const canVmCreate=root.dataset.canVmCreate==='1';
  const canIsoUpload=root.dataset.canIsoUpload==='1';
  const canNetworkManage=root.dataset.canNetworkManage==='1';
  let servers=<?= json_encode($serversPublic, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  let current=null, context=null, nodeData=null, connectionMode='auto', presets=[], editingPreset=null;
  const q=s=>root.querySelector(s);
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const msg=(el,text,ok)=>{if(!el)return;el.textContent=text||'';el.dataset.ok=ok?'1':'0';};

  const mfaSecurityForm=q('[data-mfa-security-form]');
  if(mfaSecurityForm){
    mfaSecurityForm.addEventListener('submit',async event=>{
      event.preventDefault();
      const out=q('[data-mfa-security-msg]');
      const fd=new FormData(mfaSecurityForm);
      fd.set('csrf',csrf);
      msg(out,'Enregistrement du timer MFA…',true);

      try{
        const j=await api('mfa_security_save',{method:'POST',body:fd});
        const minutes=j.settings&&j.settings.lock_minutes?Number(j.settings.lock_minutes):Number(fd.get('lock_minutes')||15);
        msg(out,`Timer MFA enregistré : ${minutes} minute(s).`,true);
        setTimeout(()=>window.location.reload(),450);
      }catch(e){
        msg(out,e.message,false);
      }
    });
  }

  async function api(action, opts={}){
    const method=opts.method||'GET'; const params=opts.params||{}; const body=opts.body||null;
    const url=new URL(apiUrl, window.location.origin);
    url.searchParams.set('ajax',action); Object.entries(params).forEach(([k,v])=>url.searchParams.set(k,v));
    const r=await fetch(url.toString(),{method,credentials:'same-origin',body});
    const t=await r.text(); let j; try{j=JSON.parse(t)}catch(e){throw new Error('Réponse invalide : '+t.slice(0,180))}
    if(!r.ok || !j.ok) throw new Error(j.message||('HTTP '+r.status)); return j;
  }

  function renderServers(){
    q('[data-server-count]').textContent=servers.length;
    q('[data-server-list]').innerHTML=servers.length?servers.map(s=>`<button type="button" class="dmd-proxmoxcfg-server ${current&&current.id===s.id?'active':''}" data-server-id="${esc(s.id)}"><strong>${esc(s.name)}</strong><small>${esc(s.ip)}:${esc(s.port||8006)}</small></button>`).join(''):'<p class="dmd-proxmoxcfg-muted">Aucun serveur.</p>';
  }
  function setConnectionMode(mode){
    connectionMode=mode==='manual'?'manual':'auto';
    q('[data-auto-fields]').hidden=connectionMode!=='auto';
    q('[data-manual-fields]').hidden=connectionMode!=='manual';
    q('[data-bootstrap-server]').hidden=connectionMode!=='auto';
    q('[data-manual-save]').hidden=connectionMode!=='manual';
    q('[data-mode-auto]').disabled=connectionMode==='auto';
    q('[data-mode-manual]').disabled=connectionMode==='manual';
  }
  function resetServerForm(){
    current=null; context=null; nodeData=null; q('[data-server-form]').reset(); q('[data-old-id]').value=''; q('[data-port]').value='8006'; q('[data-admin-user]').value='root@pam'; q('[data-delete-server]').hidden=true; q('[data-api-state]').textContent='Non testé'; setConnectionMode('auto');
    ['[data-vm-panel]','[data-preset-panel]','[data-iso-panel]','[data-vm-list-panel]'].forEach(sel=>{const el=q(sel);if(el)el.hidden=true;}); renderServers();
  }
  function fillServer(s){
    current=s; q('[data-old-id]').value=s.id||''; q('[data-name]').value=s.name||''; q('[data-ip]').value=s.ip||''; q('[data-port]').value=s.port||8006; q('[data-token]').value=s.token_id||''; q('[data-secret]').value=''; q('[data-admin-password]').value=''; q('[data-delete-server]').hidden=!canServerManage; q('[data-api-state]').textContent=s.has_secret?'API configurée':'Secret manquant'; setConnectionMode('manual'); renderServers(); loadContext();
  }
  async function refreshServers(selectId){
    const j=await api('servers'); servers=j.servers||[]; renderServers(); if(selectId){const s=servers.find(x=>x.id===selectId); if(s)fillServer(s);}
  }
  async function loadContext(){
    if(!current)return; msg(q('[data-server-msg]'),'Chargement du cluster…',true);
    try{
      const j=await api('context',{params:{server_id:current.id}}); context=j;
      const nodes=j.nodes||[]; const opts=nodes.map(n=>`<option value="${esc(n.node)}">${esc(n.node)} · ${esc(n.status)}</option>`).join('');
      q('[data-node]').innerHTML=opts; q('[data-iso-node]').innerHTML=opts; const presetNode=q('[data-preset-node]'); if(presetNode)presetNode.innerHTML=opts; q('[data-nextid]').textContent='Prochain VMID '+(j.nextid||'—'); q('[data-vmid]').placeholder=j.nextid?String(j.nextid):'Auto';
      const vms=j.vms||[]; q('[data-vm-count]').textContent=vms.length; q('[data-vm-list]').innerHTML=vms.length?vms.sort((a,b)=>(a.vmid||0)-(b.vmid||0)).map(v=>`<tr><td>#${esc(v.vmid)}</td><td>${esc((v.type||'qemu').toUpperCase())}</td><td>${esc(v.name||'')}</td><td>${esc(v.node||'')}</td><td>${esc(v.status||'')}</td></tr>`).join(''):'<tr><td colspan="5">Aucune VM/CT.</td></tr>';
      q('[data-vm-panel]').hidden=!canVmCreate||!nodes.length; const pp=q('[data-preset-panel]'); if(pp)pp.hidden=!(canVmCreate||canServerManage); q('[data-iso-panel]').hidden=!canIsoUpload||!nodes.length; q('[data-vm-list-panel]').hidden=false; msg(q('[data-server-msg]'),'Cluster chargé.',true); if(nodes.length&&(canVmCreate||canIsoUpload||canNetworkManage||canServerManage))await loadNode(nodes[0].node); if(nodes.length){const pn=q('[data-preset-node]');if(pn&&pn.value)await loadPresetNode(pn.value,null);} await loadPresets();
    }catch(e){msg(q('[data-server-msg]'),e.message,false)}
  }
  async function loadNode(node){
    if(!current||!node)return; try{
      const j=await api('node_data',{params:{server_id:current.id,node}}); nodeData=j;
      const stores=j.storages||[]; const vmStores=stores.filter(s=>{const c=String(s.content||'');return c.includes('images')||c==='';}); const isoStores=stores.filter(s=>String(s.content||'').includes('iso'));
      q('[data-storage-vm]').innerHTML=vmStores.map(s=>`<option value="${esc(s.storage)}">${esc(s.storage)} · ${esc(s.type||'')}</option>`).join(''); q('[data-storage-iso]').innerHTML=isoStores.map(s=>`<option value="${esc(s.storage)}">${esc(s.storage)} · ${esc(s.type||'')}</option>`).join('');
      q('[data-iso]').innerHTML='<option value="">Aucune ISO</option>'+((j.isos||[]).map(i=>`<option value="${esc(i.volid)}">${esc(i.volid)}</option>`).join(''));
      q('[data-bridge]').innerHTML=(j.bridges||[]).map(b=>`<option value="${esc(b)}">${esc(b)}</option>`).join(''); q('[data-vlan]').innerHTML='<option value="">Aucun VLAN</option>'+((j.vlans||[]).map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join(''));
      q('[data-iso-node]').value=node;
    }catch(e){msg(q('[data-vm-msg]'),e.message,false)}
  }

  function presetServerItems(){return presets.filter(p=>current&&String(p.server_id||'')===String(current.id||''));}
  function renderPresets(){
    const list=presetServerItems(),host=q('[data-preset-list]'),count=q('[data-preset-count]');
    if(count)count.textContent=list.length+' preset'+(list.length>1?'s':'');
    if(!host)return;
    host.innerHTML=list.length?list.map(p=>`<button type="button" class="dmd-proxmoxcfg-preset-card ${editingPreset&&editingPreset.id===p.id?'active':''}" data-preset-edit="${esc(p.id)}"><strong>${esc(p.label)}</strong><small>${esc(p.name_prefix)}-{AUTO} · ${esc(p.cpu)} CPU · ${esc(p.ram)} Mo · ${esc(p.disk)} Go${Number(p.vlan)>0?' · VLAN '+esc(p.vlan):''}</small><span>${p.enabled?'ActionHub':'Désactivé'} · ${p.auto_start?'démarrage auto':'reste arrêtée'} · ${p.after_create==='remote'?'Remote':p.after_create==='vm'?'fiche VM':'aucune ouverture'}</span></button>`).join(''):'<p class="dmd-proxmoxcfg-muted">Aucun preset pour ce serveur.</p>';
  }
  async function loadPresets(){
    if(!current){presets=[];renderPresets();return;}
    try{const j=await api('preset_list',{params:{server_id:current.id}});presets=Array.isArray(j.presets)?j.presets:[];renderPresets();}
    catch(e){presets=[];renderPresets();const m=q('[data-preset-msg]');if(m)msg(m,e.message,false);}
  }
  function setSelectValue(el,value){if(!el)return;const v=String(value??'');if(Array.from(el.options).some(o=>o.value===v))el.value=v;}
  async function loadPresetNode(node,preset){
    if(!current||!node)return;
    const storage=q('[data-preset-storage]'),iso=q('[data-preset-iso]'),bridge=q('[data-preset-bridge]'),vlan=q('[data-preset-vlan]');
    if(!storage&&!iso&&!bridge&&!vlan)return;
    try{
      const j=await api('node_data',{params:{server_id:current.id,node}}),storages=Array.isArray(j.storages)?j.storages:[],isos=Array.isArray(j.isos)?j.isos:[],bridges=Array.isArray(j.bridges)?j.bridges:[],vlans=Array.isArray(j.vlans)?j.vlans:[];
      if(storage)storage.innerHTML=storages.filter(x=>String(x.content||'').includes('images')||String(x.content||'')==='').map(x=>`<option value="${esc(x.storage)}">${esc(x.storage)} · ${esc(x.type||'')}</option>`).join('');
      if(iso)iso.innerHTML='<option value="">Aucune ISO</option>'+isos.map(x=>`<option value="${esc(x.volid)}">${esc(x.volid)}</option>`).join('');
      if(bridge)bridge.innerHTML=bridges.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join('');
      if(vlan)vlan.innerHTML='<option value="0">Aucun VLAN</option>'+vlans.map(x=>`<option value="${esc(x)}">VLAN ${esc(x)}</option>`).join('');
      if(preset){setSelectValue(storage,preset.storage_vm);setSelectValue(iso,preset.iso);setSelectValue(bridge,preset.bridge);setSelectValue(vlan,preset.vlan);}
    }catch(e){const m=q('[data-preset-msg]');if(m)msg(m,e.message,false);}
  }
  function resetPresetForm(){
    editingPreset=null;const f=q('[data-preset-form]');if(!f){renderPresets();return;}f.reset();q('[data-preset-id]').value='';q('[data-preset-cpu]').value='2';q('[data-preset-ram]').value='4096';q('[data-preset-disk]').value='32';q('[data-preset-max]').value='10';q('[data-preset-after]').value='vm';q('[data-preset-open-count]').value='first';q('[data-preset-autostart]').checked=true;q('[data-preset-enabled]').checked=true;q('[data-preset-delete]').hidden=true;const node=q('[data-preset-node]');if(node&&node.options.length){node.selectedIndex=0;loadPresetNode(node.value,null);}renderPresets();
  }
  async function fillPreset(p){
    if(!p)return;editingPreset=p;renderPresets();const f=q('[data-preset-form]');if(!f)return;q('[data-preset-id]').value=p.id||'';q('[data-preset-label]').value=p.label||'';q('[data-preset-prefix]').value=p.name_prefix||'';q('[data-preset-ostype]').value=p.ostype||'l26';q('[data-preset-cpu]').value=p.cpu||2;q('[data-preset-ram]').value=p.ram||2048;q('[data-preset-disk]').value=p.disk||20;q('[data-preset-max]').value=p.max_quantity||10;q('[data-preset-after]').value=p.after_create||'vm';q('[data-preset-open-count]').value=p.open_count||'first';q('[data-preset-autostart]').checked=!!p.auto_start;q('[data-preset-enabled]').checked=!!p.enabled;q('[data-preset-delete]').hidden=false;const node=q('[data-preset-node]');setSelectValue(node,p.node);await loadPresetNode(node.value,p);
  }

  root.addEventListener('click',e=>{
    const s=e.target.closest('[data-server-id]'); if(s){const item=servers.find(x=>x.id===s.dataset.serverId); if(item)fillServer(item);return;}
    if(e.target.closest('[data-new-server]')){if(canServerManage)resetServerForm();return;}
    if(e.target.closest('[data-mode-auto]')){setConnectionMode('auto');return;}
    if(e.target.closest('[data-mode-manual]')){setConnectionMode('manual');return;}
  });
  q('[data-node]').addEventListener('change',e=>loadNode(e.target.value));
  q('[data-iso-node]').addEventListener('change',e=>{q('[data-node]').value=e.target.value;loadNode(e.target.value)});

  q('[data-bootstrap-server]').addEventListener('click',async()=>{if(!canServerManage)return;
    const form=q('[data-server-form]'); const f=new FormData(form); f.set('csrf',csrf);
    const pwd=q('[data-admin-password]'); const button=q('[data-bootstrap-server]');
    if(!String(f.get('name')||'').trim()||!String(f.get('ip')||'').trim()||!String(f.get('admin_user')||'').trim()||!String(f.get('admin_password')||'')){msg(q('[data-server-msg]'),'Renseigne le serveur, le compte administrateur Proxmox et son mot de passe.',false);return;}
    button.disabled=true; msg(q('[data-server-msg]'),'Connexion à Proxmox → création d’un compte technique unique → création du token unique…',true);
    try{
      const j=await api('bootstrap_server',{method:'POST',body:f});
      if(pwd)pwd.value='';
      await refreshServers(j.server.id);
      q('[data-api-state]').textContent=j.verified?'API OK':'À vérifier';
      msg(q('[data-server-msg]'),j.message,!!j.verified);
    }catch(err){if(pwd)pwd.value='';msg(q('[data-server-msg]'),err.message,false)}finally{button.disabled=false}
  });
  q('[data-server-form]').addEventListener('submit',async e=>{e.preventDefault();if(!canServerManage||connectionMode!=='manual')return;const f=new FormData(e.currentTarget);f.set('csrf',csrf);try{const j=await api('save_server',{method:'POST',body:f});msg(q('[data-server-msg]'),j.message,true);await refreshServers(j.server.id)}catch(err){msg(q('[data-server-msg]'),err.message,false)}});
  q('[data-test-server]').addEventListener('click',async()=>{if(!canServerManage)return;if(!current){msg(q('[data-server-msg]'),'Enregistre d’abord le serveur.',false);return}try{const j=await api('test',{params:{server_id:current.id}});q('[data-api-state]').textContent='API OK';msg(q('[data-server-msg]'),j.message,true)}catch(e){q('[data-api-state]').textContent='Erreur API';msg(q('[data-server-msg]'),e.message,false)}});
  q('[data-delete-server]').addEventListener('click',async()=>{if(!canServerManage)return;if(!current||!confirm('Supprimer '+current.name+' de DMD-Proxmox ?\n\nSi cet accès a été créé automatiquement, son token API et son compte technique seront également révoqués sur Proxmox.'))return;const f=new FormData();f.set('csrf',csrf);f.set('server_id',current.id);try{const j=await api('delete_server',{method:'POST',body:f});msg(q('[data-server-msg]'),j.message,true);await refreshServers();resetServerForm()}catch(e){msg(q('[data-server-msg]'),e.message,false)}});

  const presetNodeEl=q('[data-preset-node]');if(presetNodeEl)presetNodeEl.addEventListener('change',e=>loadPresetNode(e.target.value,null));
  const presetNew=q('[data-preset-new]');if(presetNew)presetNew.addEventListener('click',resetPresetForm);
  const presetList=q('[data-preset-list]');if(presetList)presetList.addEventListener('click',e=>{const b=e.target.closest('[data-preset-edit]');if(!b)return;const p=presets.find(x=>String(x.id)===String(b.dataset.presetEdit));if(p)fillPreset(p)});
  const presetForm=q('[data-preset-form]');if(presetForm)presetForm.addEventListener('submit',async e=>{e.preventDefault();if(!canServerManage||!current)return;const f=new FormData(e.currentTarget);f.set('csrf',csrf);f.set('server_id',current.id);if(!q('[data-preset-enabled]').checked)f.delete('enabled');if(!q('[data-preset-autostart]').checked)f.delete('auto_start');msg(q('[data-preset-msg]'),'Enregistrement…',true);try{const j=await api('preset_save',{method:'POST',body:f});msg(q('[data-preset-msg]'),j.message,true);await loadPresets();const saved=presets.find(x=>j.preset&&x.id===j.preset.id);if(saved)await fillPreset(saved)}catch(err){msg(q('[data-preset-msg]'),err.message,false)}});
  const presetDelete=q('[data-preset-delete]');if(presetDelete)presetDelete.addEventListener('click',async()=>{if(!canServerManage||!editingPreset||!confirm('Supprimer le preset « '+editingPreset.label+' » ?'))return;const f=new FormData();f.set('csrf',csrf);f.set('preset_id',editingPreset.id);try{const j=await api('preset_delete',{method:'POST',body:f});msg(q('[data-preset-msg]'),j.message,true);await loadPresets();resetPresetForm()}catch(err){msg(q('[data-preset-msg]'),err.message,false)}});

  q('[data-vm-form]').addEventListener('submit',async e=>{e.preventDefault();if(!canVmCreate||!current)return;const f=new FormData(e.currentTarget);f.set('csrf',csrf);f.set('server_id',current.id);msg(q('[data-vm-msg]'),'Création en cours…',true);try{const j=await api('create_vm',{method:'POST',body:f});msg(q('[data-vm-msg]'),j.message,true);await loadContext()}catch(err){msg(q('[data-vm-msg]'),err.message,false)}});
  q('[data-iso-form]').addEventListener('submit',async e=>{e.preventDefault();if(!canIsoUpload||!current)return;const f=new FormData(e.currentTarget);f.set('csrf',csrf);f.set('server_id',current.id);msg(q('[data-iso-msg]'),'Upload en cours…',true);try{const j=await api('upload_iso',{method:'POST',body:f});msg(q('[data-iso-msg]'),j.message,true);await loadNode(q('[data-node]').value)}catch(err){msg(q('[data-iso-msg]'),err.message,false)}});


  const remotePanel=q('[data-remote-panel]');
  if(remotePanel){
    const rq=s=>remotePanel.querySelector(s); let remoteState=null;
    const subst=v=>String(v??'').replaceAll('{{GATEWAY_PORT}}',String(remoteState?.gateway?.settings?.listen_port||6079)).replaceAll('{{GATEWAY_HOST}}',String(remoteState?.gateway?.settings?.listen_host||'127.0.0.1')).replaceAll('{{MODULE_WS_PATH}}',String(remoteState?.module_ws_path||''));
    function syncRemoteMode(){const custom=rq('[data-remote-public-mode]').value==='custom';rq('[data-remote-public-url-wrap]').hidden=!custom}
    function renderProcedure(p){if(!p){rq('[data-remote-procedure-body]').innerHTML='';return}const list=(title,items)=>Array.isArray(items)&&items.length?`<div class="dmd-proxmoxcfg-proc-block"><strong>${esc(title)}</strong><ol>${items.map(x=>`<li><pre>${esc(subst(x))}</pre></li>`).join('')}</ol></div>`:'';const trouble=p.troubleshooting&&typeof p.troubleshooting==='object'?`<div class="dmd-proxmoxcfg-proc-block"><strong>Dépannage</strong>${Object.entries(p.troubleshooting).map(([k,v])=>`<div><code>${esc(k)}</code> · ${esc(subst(v))}</div>`).join('')}</div>`:'';rq('[data-remote-procedure-body]').innerHTML=`<h5>${esc(p.label||'Procédure')}</h5><p>${esc(p.summary||'')}</p>${list('Prérequis',p.requirements)}${list('Étapes',p.steps)}${list('Configuration',p.config)}${list('Test',p.test)}${list('Rollback',p.rollback)}${trouble}${p.reference?`<small>Référence éditeur : ${esc(p.reference)}</small>`:''}`}
    async function loadProcedure(id){try{const j=await api('remote_procedure',{params:{id}});renderProcedure(j.procedure)}catch(e){rq('[data-remote-procedure-body]').textContent=e.message}}
    function renderRemote(j){remoteState=j;const g=j.gateway||{};const s=g.settings||{};rq('[data-remote-state]').textContent=g.running?'✅ Gateway en ligne':'⚠️ Gateway arrêtée';rq('[data-remote-state]').dataset.ok=g.running?'1':'0';rq('[data-remote-bind]').value=s.listen_host||'127.0.0.1';rq('[data-remote-port]').value=s.listen_port||6079;rq('[data-remote-public-mode]').value=s.public_mode||'same_origin';rq('[data-remote-public-url]').value=s.public_wss_url||'';syncRemoteMode();const p=j.platform||{};const rs=g.runtime_status||{};const log=String(g.log_tail||'').trim();rq('[data-remote-diag]').innerHTML=`<div class="dmd-proxmoxcfg-remote-facts"><span><b>Plateforme</b>${esc(p.id||'generic')}</span><span><b>Serveur Web</b>${esc(p.server_software||'inconnu')}</span><span><b>PHP CLI</b>${esc(g.php_cli||'absent')}</span><span><b>Spawn PHP</b>${g.can_spawn?'Disponible':'Indisponible'}</span><span><b>Gateway</b>${esc((s.listen_host||'127.0.0.1')+':'+(s.listen_port||6079))}</span><span><b>PID</b>${esc(g.pid?String(g.pid)+(g.pid_alive?' · actif':' · arrêté'):'aucun')}</span><span><b>Runtime</b>${esc(rs.state||rs.error||'aucun')}</span><span><b>Chemin WSS</b>${esc(j.module_ws_path||'')}</span></div>${!g.running&&g.error?`<div class="dmd-proxmoxcfg-alert is-error"><b>Erreur Gateway :</b> ${esc(g.error)}</div>`:''}${log?`<details class="dmd-proxmoxcfg-remote-log"><summary>Journal Gateway</summary><pre>${esc(log)}</pre></details>`:''}`;const procs=j.manifest?.procedures||[];rq('[data-remote-procedure]').innerHTML=procs.map(x=>`<option value="${esc(x.id)}" ${x.id===p.id?'selected':''}>${esc(x.label)}</option>`).join('');const chosen=rq('[data-remote-procedure]').value;if(chosen)loadProcedure(chosen)}
    async function remoteDiag(){msg(rq('[data-remote-msg]'),'Diagnostic Remote…',true);try{const j=await api('remote_diag');renderRemote(j);msg(rq('[data-remote-msg]'),j.gateway?.running?'Gateway prête.':'Gateway non démarrée : utilise « Démarrer / tester ».',!!j.gateway?.running)}catch(e){msg(rq('[data-remote-msg]'),e.message,false)}}
    rq('[data-remote-public-mode]').addEventListener('change',syncRemoteMode);rq('[data-remote-refresh]').addEventListener('click',remoteDiag);rq('[data-remote-procedure]').addEventListener('change',e=>loadProcedure(e.target.value));rq('[data-remote-start]').addEventListener('click',async()=>{const f=new FormData();f.set('csrf',csrf);msg(rq('[data-remote-msg]'),'Démarrage Gateway…',true);try{const j=await api('remote_gateway_start',{method:'POST',body:f});msg(rq('[data-remote-msg]'),j.message,true)}catch(e){msg(rq('[data-remote-msg]'),e.message,false)}finally{await remoteDiag()}});rq('[data-remote-form]').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.currentTarget);f.set('csrf',csrf);try{const j=await api('remote_gateway_save',{method:'POST',body:f});msg(rq('[data-remote-msg]'),j.message,true);await remoteDiag()}catch(err){msg(rq('[data-remote-msg]'),err.message,false)}});remoteDiag();
  }

  renderServers(); if(servers.length)fillServer(servers[0]); else resetServerForm();
})();
</script>

<?php if ($CAN_ACL_MANAGE): ?>
<section class="dmd-proxmox-acl" data-dmd-proxmox-acl data-endpoint="<?= htmlspecialchars($dmdProxmoxBaseUrl . '/DMD-Proxmox_acl.php', ENT_QUOTES, 'UTF-8') ?>" data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
  <div class="dmd-proxmox-acl-head">
    <div><h3>Droits fins VM / CT</h3><p>Une règle s'ajoute aux permissions générales DoMyDesk. Sans règle spécifique, les permissions habituelles restent appliquées.</p></div>
    <button type="button" class="dmd-proxmoxcfg-btn" data-acl-reload>↻ Actualiser</button>
  </div>
  <div class="dmd-proxmox-acl-grid">
    <form class="dmd-proxmox-acl-form" data-acl-form>
      <label><span>Cible</span><select name="subject_type" data-acl-subject-type><option value="user">Utilisateur</option><option value="role">Groupe / rôle métier</option></select></label>
      <label><span>Utilisateur / groupe</span><select name="subject" data-acl-subject required></select></label>
      <label><span>Serveur</span><select name="server_id" data-acl-server required></select></label>
      <label><span>VM / CT</span><select name="resource" data-acl-resource required></select></label>
      <label><span>Mode</span><select name="mode" data-acl-mode><option value="restrict">Limiter aux actions cochées</option><option value="deny">Aucun accès à cette VM/CT</option></select></label>
      <div class="dmd-proxmox-acl-permissions" data-acl-permissions></div>
      <div class="dmd-proxmoxcfg-actions"><button type="submit" class="dmd-proxmoxcfg-btn">Enregistrer la règle</button></div>
      <div class="dmd-proxmoxcfg-msg" data-acl-msg></div>
    </form>
    <div class="dmd-proxmox-acl-rules">
      <div class="dmd-proxmoxcfg-panel-head"><div><h4>Règles enregistrées</h4><p>L'utilisateur prend priorité sur son rôle métier.</p></div><span class="dmd-proxmoxcfg-badge" data-acl-count>0</span></div>
      <div data-acl-list></div>
    </div>
  </div>
</section>
<style>
.dmd-proxmox-acl{margin-top:18px;border:1px solid var(--dmdm-border,currentColor);border-radius:16px;padding:14px;background:var(--dmdm-front,transparent);color:var(--dmdm-text,inherit)}
.dmd-proxmox-acl *{box-sizing:border-box}.dmd-proxmox-acl-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}.dmd-proxmox-acl-head h3,.dmd-proxmox-acl-head p{margin:0}.dmd-proxmox-acl-head p{margin-top:4px;opacity:.75}.dmd-proxmox-acl-grid{display:grid;grid-template-columns:minmax(280px,420px) minmax(0,1fr);gap:14px}.dmd-proxmox-acl-form,.dmd-proxmox-acl-rules{border:1px solid var(--dmdm-border,currentColor);border-radius:14px;padding:12px;background:var(--dmdm-background,transparent)}.dmd-proxmox-acl-form{display:grid;gap:10px}.dmd-proxmox-acl-form label>span{display:block;font-weight:700;margin-bottom:5px}.dmd-proxmox-acl select{width:100%;min-height:36px;border:1px solid var(--dmdm-border,currentColor);border-radius:9px;background:var(--dmdm-background,inherit);color:var(--dmdm-text,inherit);padding:6px 8px}.dmd-proxmox-acl-permissions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.dmd-proxmox-acl-permissions label{display:flex;gap:7px;align-items:center;border:1px solid var(--dmdm-border,currentColor);border-radius:9px;padding:7px 8px}.dmd-proxmox-acl-rule{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;border-bottom:1px solid var(--dmdm-border,currentColor);padding:9px 0}.dmd-proxmox-acl-rule:last-child{border-bottom:0}.dmd-proxmox-acl-rule small{display:block;opacity:.72;margin-top:3px}.dmd-proxmox-acl-empty{opacity:.7;padding:10px 0}.dmd-proxmox-acl-rule button{white-space:nowrap}@media(max-width:850px){.dmd-proxmox-acl-grid{grid-template-columns:1fr}.dmd-proxmox-acl-permissions{grid-template-columns:1fr}}
</style>
<script>
(function(){
  const root=document.querySelector('[data-dmd-proxmox-acl]'); if(!root||root.dataset.ready==='1')return; root.dataset.ready='1';
  const endpoint=root.dataset.endpoint||''; const csrf=root.dataset.csrf||'';
  const q=s=>root.querySelector(s); const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  let state={subjects:{users:[],roles:[]},servers:[],capabilities:{},rules:[]};
  function message(text,ok){const el=q('[data-acl-msg]');if(!el)return;el.textContent=text||'';el.dataset.ok=ok?'1':'0'}
  async function call(action,body){const url=new URL(endpoint,window.location.origin);url.searchParams.set('action',action);const opt={credentials:'same-origin',cache:'no-store'};if(body){body.set('csrf',csrf);opt.method='POST';opt.body=body}const r=await fetch(url.toString(),opt);const t=await r.text();let j;try{j=JSON.parse(t)}catch(e){throw new Error('Réponse ACL invalide : '+t.slice(0,160))}if(!r.ok||!j.ok)throw new Error(j.message||('HTTP '+r.status));return j}
  function renderSubjects(){const type=q('[data-acl-subject-type]').value;const list=type==='role'?(state.subjects.roles||[]):(state.subjects.users||[]);q('[data-acl-subject]').innerHTML=list.map(x=>type==='role'?`<option value="${esc(x.id)}">${esc(x.label||x.id)}</option>`:`<option value="${esc(x.email)}">${esc(x.name||x.email)} · ${esc(x.email)}</option>`).join('')||'<option value="">Aucune cible</option>'}
  function renderServers(){q('[data-acl-server]').innerHTML=(state.servers||[]).map(s=>`<option value="${esc(s.id)}">${esc(s.name||s.id)}</option>`).join('')||'<option value="">Aucun serveur</option>';renderResources()}
  function renderResources(){const sid=q('[data-acl-server]').value;const server=(state.servers||[]).find(s=>String(s.id)===String(sid));const vms=server&&Array.isArray(server.vms)?server.vms:[];q('[data-acl-resource]').innerHTML=vms.map(v=>`<option value="${esc(v.type+':'+v.vmid)}">#${esc(v.vmid)} · ${esc((v.type||'qemu').toUpperCase())} · ${esc(v.name||'sans nom')} · ${esc(v.node||'')}</option>`).join('')||'<option value="">Aucune VM/CT dans le cache</option>'}
  function renderPermissions(){q('[data-acl-permissions]').innerHTML=Object.entries(state.capabilities||{}).map(([id,label])=>`<label><input type="checkbox" name="permissions[]" value="${esc(id)}" checked> <span>${esc(label)}</span></label>`).join('');syncMode()}
  function syncMode(){const deny=q('[data-acl-mode]').value==='deny';q('[data-acl-permissions]').querySelectorAll('input').forEach(x=>x.disabled=deny)}
  function renderRules(){q('[data-acl-count]').textContent=String((state.rules||[]).length);q('[data-acl-list]').innerHTML=(state.rules||[]).length?(state.rules||[]).map(r=>{const perms=r.mode==='deny'?'Aucun accès':((r.permissions||[]).join(', ')||'Aucune action');return `<div class="dmd-proxmox-acl-rule"><div><strong>${esc(r.subject)}</strong> · ${esc(r.subject_type==='user'?'Utilisateur':'Rôle métier')}<small>${esc(r.server_id)} · ${esc((r.type||'qemu').toUpperCase())} #${esc(r.vmid)} · ${esc(perms)}</small></div><button type="button" class="dmd-proxmoxcfg-btn danger" data-acl-delete="${esc(r.id)}">Supprimer</button></div>`}).join(''):'<div class="dmd-proxmox-acl-empty">Aucune règle spécifique : les droits généraux DoMyDesk s’appliquent.</div>'}
  async function load(){message('Chargement…',true);try{const j=await call('bootstrap');state={subjects:j.subjects||{users:[],roles:[]},servers:j.servers||[],capabilities:j.capabilities||{},rules:j.rules||[]};renderSubjects();renderServers();renderPermissions();renderRules();message('Droits chargés.',true)}catch(e){message(e.message,false)}}
  q('[data-acl-subject-type]').addEventListener('change',renderSubjects);q('[data-acl-server]').addEventListener('change',renderResources);q('[data-acl-mode]').addEventListener('change',syncMode);q('[data-acl-reload]').addEventListener('click',load);
  q('[data-acl-form]').addEventListener('submit',async e=>{e.preventDefault();const resource=q('[data-acl-resource]').value;if(!resource){message('Sélectionne une VM/CT.',false);return}const bits=resource.split(':');const f=new FormData(e.currentTarget);f.set('server_id',q('[data-acl-server]').value);f.set('type',bits[0]||'qemu');f.set('vmid',bits[1]||'');try{const j=await call('save',f);state.rules=j.rules||[];renderRules();message(j.message||'Règle enregistrée.',true)}catch(err){message(err.message,false)}});
  root.addEventListener('click',async e=>{const b=e.target.closest('[data-acl-delete]');if(!b)return;if(!confirm('Supprimer cette règle de droits ?'))return;const f=new FormData();f.set('id',b.dataset.aclDelete||'');try{const j=await call('delete',f);state.rules=j.rules||[];renderRules();message(j.message||'Règle supprimée.',true)}catch(err){message(err.message,false)}});
  load();
})();
</script>
<?php echo dmd_proxmox_mfa_autolock_script($dmdProxmoxBaseUrl); ?>

<?php endif; ?>

