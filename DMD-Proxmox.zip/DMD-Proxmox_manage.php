<?php
require_once __DIR__.'/DMD-Proxmox_lib.php';
header('Cache-Control: no-store');
function pm_error($m,$c=400){dmd_proxmox_json(false,$m,[], $c);}
if ($_SERVER['REQUEST_METHOD']!=='POST' || !dmd_proxmox_has_module_access() || !dmd_proxmox_is_admin()) pm_error('Accès administrateur requis.',403);
$i=json_decode(file_get_contents('php://input'),true);
if (!is_array($i)||!dmd_proxmox_csrf_valid($i['csrf']??'')) pm_error('Jeton invalide.',403);
$s=dmd_proxmox_load_server((string)($i['server_id']??'')); if(!$s)pm_error('Serveur introuvable.',404);
function pm_id($v){if(!is_string($v)||!preg_match('/^[a-zA-Z0-9_.-]+$/D',$v)||$v==='.'||$v==='..')pm_error('Identifiant invalide.');return rawurlencode($v);}
function pm_api($p,$m='GET',$d=null){global $s; $r=dmd_proxmox_api($s,$p,$m,$d,25); if($m!=='GET')dmd_proxmox_log('management_'.$m,$p,$r['ok']?'pending':'error',$r['ok']?'Requête acceptée':$r['error'],['server_id'=>$s['id']]); if(!$r['ok'])pm_error($r['error']?:'Erreur Proxmox',502);return $r['data'];}
function pm_ok($d){dmd_proxmox_json(true,'OK',['data'=>$d],200);}
function pm_confirm(){global $i;if(($i['confirm']??'')!=='Confirmer')pm_error('Saisir Confirmer.');}
function pm_num($v){if(!is_scalar($v)||!preg_match('/^[0-9]{3,9}$/D',(string)$v)||$v<100)pm_error('VMID invalide.');return (int)$v;}
$a=$i['action']??'';
if($a==='context')pm_ok(['nodes'=>pm_api('nodes'),'vms'=>pm_api('cluster/resources?type=vm')]);
$n=pm_id($i['node']??'');$p="nodes/$n";
if($a==='schedule')pm_ok(pm_api('cluster/backup'));
if($a==='schedule_delete'){pm_confirm();pm_ok(pm_api('cluster/backup/'.pm_id($i['job']??''),'DELETE'));}
if($a==='schedule_save'){pm_confirm();$ids=trim((string)($i['vmids']??''));if(!preg_match('/^[0-9]{3,9}(,[0-9]{3,9})*$/D',$ids))pm_error('Sélection VMID obligatoire.');$d=['node'=>$i['node'],'schedule'=>trim((string)($i['schedule']??'')),'storage'=>pm_id($i['storage']??''),'vmid'=>$ids,'enabled'=>($i['enabled']??'')==='1'?1:0];if(!$d['schedule'])pm_error('Horaire obligatoire.');$job=$i['job']??'';if($job!=='')pm_ok(pm_api('cluster/backup/'.pm_id($job),'PUT',$d));pm_ok(pm_api('cluster/backup','POST',$d+['mode'=>'snapshot','compress'=>'zstd']));}
if($a==='storage')pm_ok(pm_api("$p/storage"));
if($a==='content'||$a==='volume_delete'){ $st=pm_id($i['storage']??'');$path="$p/storage/$st/content";if($a==='content')pm_ok(pm_api($path));pm_confirm();$vol=$i['volume']??'';$found=false;foreach(pm_api($path) as $v)if(($v['volid']??'')===$vol&&($v['content']??'')==='iso')$found=true;if(!$found)pm_error('Seules les ISO peuvent être supprimées ici.');pm_ok(pm_api($path.'/'.rawurlencode($vol),'DELETE'));}
if($a==='disks')pm_ok(pm_api("$p/disks/list"));
if($a==='updates')pm_ok(pm_api("$p/apt/update"));
if($a==='refresh_updates'){pm_confirm();pm_ok(pm_api("$p/apt/update",'POST',['notify'=>0]));}
if(in_array($a,['reboot','shutdown'],true)){pm_confirm();pm_ok(pm_api("$p/status",'POST',['command'=>$a]));}
if($a==='history'){ $tf=$i['timeframe']??'hour';if(!in_array($tf,['hour','day','week','month','year'],true))pm_error('Période invalide');pm_ok(pm_api("$p/rrddata?timeframe=$tf&cf=AVERAGE"));}
if($a==='replication')pm_ok(pm_api('cluster/replication'));
if($a==='replication_delete'){pm_confirm();pm_ok(pm_api('cluster/replication/'.pm_id($i['job']??''),'DELETE'));}
if($a==='replication_save'){pm_confirm();$id=pm_id($i['job']??'');$target=pm_id($i['target']??'');$schedule=trim((string)($i['schedule']??''));if(!$schedule)pm_error('Horaire obligatoire.');$d=['target'=>$target,'schedule'=>$schedule,'disable'=>!empty($i['disabled'])?1:0];if(!empty($i['existing']))pm_ok(pm_api('cluster/replication/'.$id,'PUT',$d));pm_ok(pm_api('cluster/replication','POST',$d+['id'=>$id,'type'=>'local']));}
if($a==='pbs'){ $out=[];foreach(pm_api("$p/storage") as $st)if(($st['type']??'')==='pbs')$out[]=$st;pm_ok($out);}
if($a==='alerts'){ $out=[];foreach(pm_api('nodes') as $nd)if(($nd['status']??'')!=='online')$out[]=['message'=>'Nœud indisponible : '.$nd['node']];foreach(pm_api("$p/storage") as $st)if(!empty($st['total'])&&($st['used']??0)/$st['total']>=.9)$out[]=['message'=>'Stockage saturé : '.$st['storage']];foreach(pm_api("$p/tasks?typefilter=vzdump&limit=50") as $t)if(!empty($t['endtime'])&&($t['status']??'')!=='OK')$out[]=['message'=>'Sauvegarde en erreur : '.($t['id']??'').' '.($t['status']??'')];pm_ok($out);}
$id=pm_num($i['vmid']??'');$vm=dmd_proxmox_resolve_vm($s,$id,'');if(!$vm||($vm['node']??'')!==($i['node']??'')||!in_array($vm['type']??'',['qemu','lxc'],true))pm_error('VM/CT introuvable sur ce nœud.',404);$v="$p/{$vm['type']}/$id";
if($a==='vmhistory'){ $tf=$i['timeframe']??'hour';if(!in_array($tf,['hour','day','week','month','year'],true))pm_error('Période invalide');pm_ok(pm_api("$v/rrddata?timeframe=$tf&cf=AVERAGE"));}
if($a==='snapshots')pm_ok(pm_api("$v/snapshot"));
if($a==='snapshot_create'){pm_ok(pm_api("$v/snapshot",'POST',['snapname'=>pm_id($i['snapshot']??''),'description'=>(string)($i['description']??'')]));}
if(in_array($a,['snapshot_restore','snapshot_delete'],true)){pm_confirm();$sn=pm_id($i['snapshot']??'');if($sn==='current')pm_error('Snapshot invalide.');pm_ok(pm_api("$v/snapshot/$sn".($a==='snapshot_restore'?'/rollback':''),$a==='snapshot_restore'?'POST':'DELETE'));}
if($a==='migrate'){pm_confirm();$target=pm_id($i['target']??'');if($target===$n)pm_error('Nœud identique.');$d=['target'=>$target];if($vm['type']==='qemu'){$d['online']=!empty($i['online'])?1:0;$d['with-local-disks']=1;}elseif(($vm['status']??'')==='running')pm_error('Arrêter le conteneur avant migration.');pm_ok(pm_api("$v/migrate",'POST',$d));}
if($a==='clone'){pm_confirm();$new=pm_num($i['newid']??'');pm_api('cluster/nextid?vmid='.$new);$d=['newid'=>$new,'full'=>1];if(!empty($i['name']))$d[$vm['type']==='qemu'?'name':'hostname']=(string)$i['name'];pm_ok(pm_api("$v/clone",'POST',$d));}
if($a==='template'){pm_confirm();if(($vm['status']??'')!=='stopped')pm_error('Arrêter la machine avant conversion.');pm_ok(pm_api("$v/template",'POST',[]));}
pm_error('Action inconnue.');
