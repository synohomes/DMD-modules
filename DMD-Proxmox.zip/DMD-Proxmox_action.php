<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';
require_once __DIR__ . '/DMD-Proxmox_provision.php';

$raw = (string)file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) $input = $_POST;

if (!dmd_proxmox_has_module_access()) {
    dmd_proxmox_json(false, 'Module DMD-Proxmox non autorisé pour cet utilisateur.', array(), 403);
}
if (!dmd_proxmox_csrf_valid(isset($input['csrf']) ? $input['csrf'] : '')) {
    dmd_proxmox_json(false, 'Jeton de sécurité expiré. Recharge la page.', array(), 403);
}

$serverId = trim((string)(isset($input['server_id']) ? $input['server_id'] : (isset($input['node']) ? $input['node'] : '')));
$vmid = (int)(isset($input['vmid']) ? $input['vmid'] : 0);
$type = strtolower(trim((string)(isset($input['type']) ? $input['type'] : '')));
$action = strtolower(trim((string)(isset($input['action']) ? $input['action'] : '')));

// Lecture seule : ne jamais renvoyer la configuration brute (secrets cloud-init, etc.).
if ($action === 'details') {
    header('Cache-Control: no-store');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !dmd_proxmox_user_can('view')) dmd_proxmox_json(false, 'Accès refusé.', [], 403);
    $server = dmd_proxmox_load_server($serverId);
    $vm = $server && $vmid > 0 ? dmd_proxmox_resolve_vm($server, $vmid, $type) : null;
    if (!$vm || !in_array($vm['type'] ?? '', ['qemu','lxc'], true)) dmd_proxmox_json(false, 'VM/CT introuvable.', [], 404);
    $kind = $vm['type'];
    if (!dmd_proxmox_acl_can(dmd_proxmox_user_email(), $server['id'] ?? $serverId, $kind, $vmid, 'view')) dmd_proxmox_json(false, 'Détails non autorisés pour cette VM/CT.', [], 403);
    $base = 'nodes/'.rawurlencode($vm['node']).'/'.$kind.'/'.$vmid;
    $r = dmd_proxmox_api($server, $base.'/config', 'GET', null, 8);
    if (!$r['ok'] || !is_array($r['data'])) dmd_proxmox_json(false, 'Configuration inaccessible : '.$r['error'], [], 502);
    $c = $r['data']; $hardware=[]; $disks=[]; $net=[]; $interfaces=[]; $fs=[]; $notes=[];
    $labels=['cores'=>'Cœurs','sockets'=>'Sockets','cpu'=>'CPU','memory'=>'RAM (Mio)','balloon'=>'Balloon (Mio)','ostype'=>'Type OS','machine'=>'Machine','boot'=>'Ordre de démarrage','scsihw'=>'Contrôleur SCSI','onboot'=>'Démarrage automatique','agent'=>'Agent QEMU'];
    if ($kind==='qemu') $hardware['Firmware']=($c['bios']??'seabios')==='ovmf'?'UEFI (OVMF)':'BIOS (SeaBIOS)';
    if ($kind==='lxc') $hardware['Firmware']='Non applicable (conteneur LXC)';
    foreach ($labels as $key=>$label) if(isset($c[$key]) && is_scalar($c[$key])) $hardware[$label]=$key==='onboot'?(!empty($c[$key])?'Oui':'Non'):(string)$c[$key];
    foreach ($c as $key=>$value) {
        if (!is_string($value)) continue;
        if (preg_match('/^(?:scsi|virtio|sata|ide|unused|mp)\d+$|^(?:rootfs|efidisk0|tpmstate0)$/D',$key)) {
            $parts=explode(',',$value); $volume=preg_replace('/^file=|^volume=/','',$parts[0]);
            $size=''; if(preg_match('/(?:^|,)size=([^,]+)/',$value,$m)) $size=$m[1];
            $role=strpos($value,'media=cdrom')!==false?'CD/DVD':($key==='efidisk0'?'EFI':($key==='tpmstate0'?'TPM':(strpos($key,'unused')===0?'Non attaché':'Disque')));
            $disks[]=['slot'=>$key,'volume'=>$volume,'size'=>$size,'role'=>$role];
        }
        if (preg_match('/^net\d+$/D',$key)) {
            $row=['slot'=>$key,'mac'=>'','bridge'=>'','model'=>'','ip'=>'','vlan'=>''];
            foreach(explode(',',$value) as $part){$kv=explode('=',$part,2);if(count($kv)!==2)continue;[$k,$v]=$kv;
                if(preg_match('/^(?:[0-9a-f]{2}:){5}[0-9a-f]{2}$/iD',$v)){ $row['mac']=$v; if($k!=='hwaddr')$row['model']=$k; }
                if($k==='bridge')$row['bridge']=$v; if($k==='tag')$row['vlan']=$v; if($k==='type')$row['model']=$v;
                if(in_array($k,['ip','ip6'],true))$row['ip'].=($row['ip']?' / ':'').$v;
            }
            if($kind==='qemu' && isset($c['ipconfig'.substr($key,3)])) foreach(explode(',',(string)$c['ipconfig'.substr($key,3)]) as $part) if(preg_match('/^ip6?=(.*)$/',$part,$m))$row['ip'].=($row['ip']?' / ':'').$m[1];
            $net[]=$row;
        }
    }
    if (($vm['status']??'')==='running') {
        $endpoint=$kind==='qemu'?'/agent/network-get-interfaces':'/interfaces';
        $a=dmd_proxmox_api($server,$base.$endpoint,'GET',null,5);
        if($a['ok']) foreach(($a['data']['result']??$a['data']??[]) as $row){
            if(!is_array($row))continue; $ips=[];
            foreach((array)($row['ip-addresses']??[]) as $ip){if(is_array($ip)&&isset($ip['ip-address']))$ips[]=$ip['ip-address'].(isset($ip['prefix'])?'/'.$ip['prefix']:'');}
            foreach(['inet','inet6'] as $key)if(isset($row[$key])&&is_string($row[$key]))$ips[]=$row[$key];
            if(($row['name']??'')==='lo')continue;
            $interfaces[]=['name'=>$row['name']??'','mac'=>$row['hardware-address']??$row['hwaddr']??'','ips'=>array_values(array_unique($ips))];
        } else $notes[]='IP réelles indisponibles : agent invité/API non accessible.';
        if($kind==='qemu'){
            $a=dmd_proxmox_api($server,$base.'/agent/get-fsinfo','GET',null,5);
            if($a['ok'])foreach(($a['data']['result']??[]) as $row)if(is_array($row))$fs[]=['devices'=>array_values(array_filter(array_map(function($d){return is_array($d)?(string)($d['dev']??$d['serial']??''):'';},(array)($row['disk']??[])))), 'mount'=>$row['mountpoint']??'','name'=>$row['name']??'','type'=>$row['type']??'','total'=>$row['total-bytes']??null,'used'=>$row['used-bytes']??null];
            if(!$a['ok'])$notes[]='Occupation interne indisponible : agent invité/API non accessible.';
        }
    } else $notes[]='Machine arrêtée : seules les informations configurées sont disponibles.';
    dmd_proxmox_json(true,'OK',['data'=>['hardware'=>$hardware,'disks'=>$disks,'net'=>$net,'interfaces'=>$interfaces,'fs'=>$fs,'notes'=>array_values(array_filter($notes))]],200);
}

$allowed = array('start', 'shutdown', 'stop', 'reboot', 'reset', 'delete');
if ($serverId === '' || $vmid <= 0 || !in_array($action, $allowed, true)) {
    dmd_proxmox_json(false, 'Requête Proxmox incomplète ou action invalide.', array(), 400);
}

$capability = 'vm.' . $action;
if (!dmd_proxmox_user_can($capability)) {
    dmd_proxmox_json(false, 'Tu n’as pas le droit d’exécuter cette action Proxmox.', array('capability' => $capability), 403);
}

$server = dmd_proxmox_load_server($serverId);
if (!is_array($server)) {
    dmd_proxmox_json(false, 'Serveur Proxmox introuvable.', array(), 404);
}

$vm = dmd_proxmox_resolve_vm($server, $vmid, $type);
if (!is_array($vm)) {
    dmd_proxmox_json(false, 'VM/CT #' . $vmid . ' introuvable sur ce serveur Proxmox.', array(), 404);
}

$realNode = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
$realType = strtolower(trim((string)(isset($vm['type']) ? $vm['type'] : 'qemu')));
if ($realType !== 'qemu' && $realType !== 'lxc') $realType = 'qemu';
if ($realNode === '') {
    dmd_proxmox_json(false, 'Impossible de déterminer le node propriétaire de la VM/CT.', array(), 409);
}
if ($action === 'reset' && $realType !== 'qemu') {
    dmd_proxmox_json(false, 'Le reset matériel est réservé aux VM QEMU.', array(), 400);
}
if ($action === 'delete') {
    $realStatus = strtolower(trim((string)(isset($vm['status']) ? $vm['status'] : '')));
    if ($realStatus !== 'stopped') {
        dmd_proxmox_json(false, 'La VM/CT doit être arrêtée avant suppression.', array(
            'vmid'=>$vmid,
            'status'=>$realStatus
        ), 409);
    }
}
$resolvedServerId = !empty($server['id']) ? (string)$server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : $serverId);
if (!dmd_proxmox_acl_can(dmd_proxmox_user_email(), $resolvedServerId, $realType, $vmid, $capability)) {
    dmd_proxmox_json(false, 'Droit refusé pour cette VM/CT.', array('capability' => $capability), 403);
}

if ($action === 'delete') {
    $endpoint = 'nodes/' . rawurlencode($realNode) . '/' . $realType . '/' . $vmid;
    $res = dmd_proxmox_api($server, $endpoint, 'DELETE', array(), 30);
} else {
    $endpoint = 'nodes/' . rawurlencode($realNode) . '/' . $realType . '/' . $vmid . '/status/' . rawurlencode($action);
    $res = dmd_proxmox_api($server, $endpoint, 'POST', array(), 15);
}
$name = trim((string)(isset($vm['name']) ? $vm['name'] : ''));
$target = strtoupper($realType) . ' #' . $vmid . ($name !== '' ? ' ' . $name : '');
$extra = array(
    'server_id' => isset($server['id']) ? $server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : ''),
    'server_name' => isset($server['name']) ? $server['name'] : '',
    'server_ip' => isset($server['ip']) ? $server['ip'] : '',
    'node' => $realNode,
    'vmid' => $vmid,
    'type' => $realType,
    'action' => $action,
    'http_code' => isset($res['http']) ? $res['http'] : 0
);

if (!$res['ok']) {
    $extra['error'] = $res['error'];
    dmd_proxmox_log('vm_' . $action, $target, 'error', 'Action Proxmox refusée ou en erreur', $extra);
    dmd_proxmox_json(false, $res['error'], array('vmid' => $vmid, 'node' => $realNode, 'type' => $realType), $res['http'] >= 400 ? $res['http'] : 502);
}

$extra['upid'] = $res['data'];

if ($action === 'delete') {
    $task = dmd_proxmox_wait_task($server, $realNode, (string)$res['data'], 60);
    if (empty($task['ok'])) {
        $extra['exitstatus'] = isset($task['exitstatus']) ? $task['exitstatus'] : '';
        dmd_proxmox_log('vm_delete', $target, 'error', 'Suppression soumise mais tâche Proxmox non terminée correctement', $extra);
        dmd_proxmox_json(false, 'La suppression n’a pas terminé correctement.', array(
            'action'=>$action,
            'vmid'=>$vmid,
            'node'=>$realNode,
            'type'=>$realType,
            'upid'=>$res['data'],
            'exitstatus'=>isset($task['exitstatus']) ? $task['exitstatus'] : ''
        ), 502);
    }

    dmd_proxmox_refresh_server_vm_cache($server);
    dmd_proxmox_log('vm_delete', $target, 'success', 'VM/CT supprimée depuis le module', $extra);
    dmd_proxmox_json(true, 'VM/CT supprimée.', array(
        'action'=>$action,
        'vmid'=>$vmid,
        'node'=>$realNode,
        'type'=>$realType,
        'upid'=>$res['data']
    ), 200);
}

$cacheFile = dmd_proxmox_cache_file($server);
if (is_file($cacheFile)) @unlink($cacheFile);
dmd_proxmox_log('vm_' . $action, $target, 'success', 'Action Proxmox exécutée', $extra);
dmd_proxmox_json(true, 'Action envoyée à Proxmox.', array(
    'action' => $action,
    'vmid' => $vmid,
    'node' => $realNode,
    'type' => $realType,
    'upid' => $res['data']
), 200);
