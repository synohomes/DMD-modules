<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Proxmox_lib.php';
require_once __DIR__ . '/DMD-Proxmox_provision.php';

$raw = (string)file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) $input = $_POST;

if (!dmd_proxmox_has_module_access()) {
    dmd_proxmox_json(false, 'Module DMD-Proxmox non autorisé pour cet utilisateur.', array(), 403);
}
if (!dmd_proxmox_csrf_valid(isset($input['csrf']) ? $input['csrf'] : '')) {
    dmd_proxmox_json(false, 'Jeton de sécurité expiré. Recharge la page.', array(), 403);
}

$serverId = trim((string)(isset($input['server_id']) ? $input['server_id'] : (isset($input['node']) ? $input['node'] : '')));
$vmid = (int)(isset($input['vmid']) ? $input['vmid'] : 0);
$type = strtolower(trim((string)(isset($input['type']) ? $input['type'] : '')));
$action = strtolower(trim((string)(isset($input['action']) ? $input['action'] : '')));

$allowed = array('start', 'shutdown', 'stop', 'reboot', 'reset', 'delete');
if ($serverId === '' || $vmid <= 0 || !in_array($action, $allowed, true)) {
    dmd_proxmox_json(false, 'Requête Proxmox incomplète ou action invalide.', array(), 400);
}

$capability = 'vm.' . $action;
if (!dmd_proxmox_user_can($capability)) {
    dmd_proxmox_json(false, 'Tu n’as pas le droit d’exécuter cette action Proxmox.', array('capability' => $capability), 403);
}

$server = dmd_proxmox_load_server($serverId);
if (!is_array($server)) {
    dmd_proxmox_json(false, 'Serveur Proxmox introuvable.', array(), 404);
}

$vm = dmd_proxmox_resolve_vm($server, $vmid, $type);
if (!is_array($vm)) {
    dmd_proxmox_json(false, 'VM/CT #' . $vmid . ' introuvable sur ce serveur Proxmox.', array(), 404);
}

$realNode = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
$realType = strtolower(trim((string)(isset($vm['type']) ? $vm['type'] : 'qemu')));
if ($realType !== 'qemu' && $realType !== 'lxc') $realType = 'qemu';
if ($realNode === '') {
    dmd_proxmox_json(false, 'Impossible de déterminer le node propriétaire de la VM/CT.', array(), 409);
}
if ($action === 'reset' && $realType !== 'qemu') {
    dmd_proxmox_json(false, 'Le reset matériel est réservé aux VM QEMU.', array(), 400);
}
if ($action === 'delete') {
    $realStatus = strtolower(trim((string)(isset($vm['status']) ? $vm['status'] : '')));
    if ($realStatus !== 'stopped') {
        dmd_proxmox_json(false, 'La VM/CT doit être arrêtée avant suppression.', array(
            'vmid'=>$vmid,
            'status'=>$realStatus
        ), 409);
    }
}
$resolvedServerId = !empty($server['id']) ? (string)$server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : $serverId);
if (!dmd_proxmox_acl_can(dmd_proxmox_user_email(), $resolvedServerId, $realType, $vmid, $capability)) {
    dmd_proxmox_json(false, 'Droit refusé pour cette VM/CT.', array('capability' => $capability), 403);
}

if ($action === 'delete') {
    $endpoint = 'nodes/' . rawurlencode($realNode) . '/' . $realType . '/' . $vmid;
    $res = dmd_proxmox_api($server, $endpoint, 'DELETE', array(), 30);
} else {
    $endpoint = 'nodes/' . rawurlencode($realNode) . '/' . $realType . '/' . $vmid . '/status/' . rawurlencode($action);
    $res = dmd_proxmox_api($server, $endpoint, 'POST', array(), 15);
}
$name = trim((string)(isset($vm['name']) ? $vm['name'] : ''));
$target = strtoupper($realType) . ' #' . $vmid . ($name !== '' ? ' ' . $name : '');
$extra = array(
    'server_id' => isset($server['id']) ? $server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : ''),
    'server_name' => isset($server['name']) ? $server['name'] : '',
    'server_ip' => isset($server['ip']) ? $server['ip'] : '',
    'node' => $realNode,
    'vmid' => $vmid,
    'type' => $realType,
    'action' => $action,
    'http_code' => isset($res['http']) ? $res['http'] : 0
);

if (!$res['ok']) {
    $extra['error'] = $res['error'];
    dmd_proxmox_log('vm_' . $action, $target, 'error', 'Action Proxmox refusée ou en erreur', $extra);
    dmd_proxmox_json(false, $res['error'], array('vmid' => $vmid, 'node' => $realNode, 'type' => $realType), $res['http'] >= 400 ? $res['http'] : 502);
}

$extra['upid'] = $res['data'];

if ($action === 'delete') {
    $task = dmd_proxmox_wait_task($server, $realNode, (string)$res['data'], 60);
    if (empty($task['ok'])) {
        $extra['exitstatus'] = isset($task['exitstatus']) ? $task['exitstatus'] : '';
        dmd_proxmox_log('vm_delete', $target, 'error', 'Suppression soumise mais tâche Proxmox non terminée correctement', $extra);
        dmd_proxmox_json(false, 'La suppression n’a pas terminé correctement.', array(
            'action'=>$action,
            'vmid'=>$vmid,
            'node'=>$realNode,
            'type'=>$realType,
            'upid'=>$res['data'],
            'exitstatus'=>isset($task['exitstatus']) ? $task['exitstatus'] : ''
        ), 502);
    }

    dmd_proxmox_refresh_server_vm_cache($server);
    dmd_proxmox_log('vm_delete', $target, 'success', 'VM/CT supprimée depuis le module', $extra);
    dmd_proxmox_json(true, 'VM/CT supprimée.', array(
        'action'=>$action,
        'vmid'=>$vmid,
        'node'=>$realNode,
        'type'=>$realType,
        'upid'=>$res['data']
    ), 200);
}

$cacheFile = dmd_proxmox_cache_file($server);
if (is_file($cacheFile)) @unlink($cacheFile);
dmd_proxmox_log('vm_' . $action, $target, 'success', 'Action Proxmox exécutée', $extra);
dmd_proxmox_json(true, 'Action envoyée à Proxmox.', array(
    'action' => $action,
    'vmid' => $vmid,
    'node' => $realNode,
    'type' => $realType,
    'upid' => $res['data']
), 200);
