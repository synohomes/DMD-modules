<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/DMD-Proxmox_lib.php';

if (!function_exists('dmd_proxmox_mydesk_base_url')) {
    function dmd_proxmox_mydesk_base_url() {
        $fallback = '/domydesk/modules/DMD-Proxmox';
        $documentRoot = realpath(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '');
        $moduleRealDir = realpath(__DIR__);
        if ($documentRoot !== false && $moduleRealDir !== false && strpos($moduleRealDir, $documentRoot) === 0) {
            $rel = str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot)));
            return '/' . trim($rel, '/');
        }
        $scriptName = str_replace('\\', '/', (string)(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : ''));
        if ($scriptName !== '') {
            $dir = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
            if ($dir !== '' && $dir !== '.' && $dir !== '/') return $dir;
        }
        return $fallback;
    }
}

if (!function_exists('dmd_proxmox_mydesk_theme_url')) {
    function dmd_proxmox_mydesk_theme_url($email, $moduleBaseUrl) {
        $theme = 'default';
        $safe = '';
        if (function_exists('dmd_safe_user_key')) {
            try { $safe = (string)dmd_safe_user_key($email); } catch (Throwable $e) { $safe = ''; }
        }
        if ($safe === '') $safe = basename((string)$email);

        $root = dmd_proxmox_root();
        if ($safe !== '') {
            $file = $root . '/users/profiles/' . $safe . '/theme.json';
            if (is_file($file)) {
                $raw = @file_get_contents($file);
                $data = is_string($raw) ? json_decode($raw, true) : null;
                if (is_array($data)) {
                    foreach (array('theme', 'selected_theme', 'selected', 'name') as $key) {
                        $candidate = isset($data[$key]) ? trim((string)$data[$key]) : '';
                        if ($candidate !== '' && preg_match('/^[a-zA-Z0-9_-]+$/', $candidate) && is_file($root . '/theme/' . $candidate . '/style.css')) {
                            $theme = $candidate;
                            break;
                        }
                    }
                }
            }
        }
        $webRoot = preg_replace('~/modules/DMD-Proxmox/?$~i', '', rtrim((string)$moduleBaseUrl, '/'));
        if (!is_string($webRoot)) $webRoot = '';
        return ($webRoot !== '' ? $webRoot : '') . '/theme/' . rawurlencode($theme) . '/style.css';
    }
}

if (!function_exists('dmd_proxmox_mydesk_unlock_key')) {
    function dmd_proxmox_mydesk_unlock_key() { return 'dmd_proxmox_mydesk_unlock'; }
}
if (!function_exists('dmd_proxmox_mydesk_unlock_ttl')) {
    function dmd_proxmox_mydesk_unlock_ttl() { return 300; }
}
if (!function_exists('dmd_proxmox_mydesk_unlock_valid')) {
    function dmd_proxmox_mydesk_unlock_valid() {
        $key = dmd_proxmox_mydesk_unlock_key();
        $state = isset($_SESSION[$key]) && is_array($_SESSION[$key]) ? $_SESSION[$key] : array();
        $email = dmd_proxmox_user_email();
        if ($email === '' || empty($state['email']) || !hash_equals($email, (string)$state['email']) || empty($state['verified_at'])) return false;
        if ((time() - (int)$state['verified_at']) >= dmd_proxmox_mydesk_unlock_ttl()) {
            unset($_SESSION[$key]);
            return false;
        }
        return true;
    }
}
if (!function_exists('dmd_proxmox_mydesk_mark_unlocked')) {
    function dmd_proxmox_mydesk_mark_unlocked($method, $recovery) {
        $now = time();
        $_SESSION[dmd_proxmox_mydesk_unlock_key()] = array(
            'email'=>dmd_proxmox_user_email(),
            'verified_at'=>$now,
            'method'=>(string)$method,
            'recovery'=>(bool)$recovery
        );
        /* Les endpoints historiques DMD-Proxmox exigent ce step-up pour un compte MFA. */
        if (dmd_proxmox_mfa_required()) {
            $_SESSION[dmd_proxmox_mfa_session_key()] = array(
                'email'=>dmd_proxmox_user_email(),
                'verified_at'=>$now,
                'last_activity'=>$now,
                'recovery'=>(bool)$recovery
            );
        }
    }
}
if (!function_exists('dmd_proxmox_mydesk_lock')) {
    function dmd_proxmox_mydesk_lock() {
        unset($_SESSION[dmd_proxmox_mydesk_unlock_key()]);
        dmd_proxmox_mfa_lock();
    }
}
if (!function_exists('dmd_proxmox_mydesk_csrf')) {
    function dmd_proxmox_mydesk_csrf() {
        if (empty($_SESSION['csrf_dmd_proxmox_mydesk'])) $_SESSION['csrf_dmd_proxmox_mydesk'] = bin2hex(random_bytes(32));
        return (string)$_SESSION['csrf_dmd_proxmox_mydesk'];
    }
}
if (!function_exists('dmd_proxmox_mydesk_csrf_valid')) {
    function dmd_proxmox_mydesk_csrf_valid($token) {
        $stored = isset($_SESSION['csrf_dmd_proxmox_mydesk']) ? (string)$_SESSION['csrf_dmd_proxmox_mydesk'] : '';
        return $stored !== '' && is_string($token) && hash_equals($stored, $token);
    }
}
if (!function_exists('dmd_proxmox_mydesk_percent')) {
    function dmd_proxmox_mydesk_percent($value) { return round(((float)$value) * 100, 1); }
}
if (!function_exists('dmd_proxmox_mydesk_ram_percent')) {
    function dmd_proxmox_mydesk_ram_percent($used, $max) {
        $max = (float)$max;
        if ($max <= 0) return 0;
        return round(((float)$used / $max) * 100, 1);
    }
}
if (!function_exists('dmd_proxmox_mydesk_e')) {
    function dmd_proxmox_mydesk_e($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
}

$email = dmd_proxmox_user_email();
$moduleBaseUrl = dmd_proxmox_mydesk_base_url();
$themeUrl = dmd_proxmox_mydesk_theme_url($email, $moduleBaseUrl);
$mydeskCsrf = dmd_proxmox_mydesk_csrf();
if ((isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET') === 'POST' && isset($_POST['mydesk_action'])) {
    if (!dmd_proxmox_has_module_assignment()) dmd_proxmox_json(false, 'Module DMD-Proxmox non autorisé.', array(), 403);
    if (!dmd_proxmox_mydesk_csrf_valid(isset($_POST['csrf']) ? $_POST['csrf'] : '')) dmd_proxmox_json(false, 'Jeton de sécurité expiré.', array(), 403);

    $action = strtolower(trim((string)$_POST['mydesk_action']));
    if ($action === 'lock') {
        dmd_proxmox_mydesk_lock();
        dmd_proxmox_json(true, 'DMD-Proxmox verrouillé.', array('unlocked'=>false), 200);
    }
    if ($action !== 'unlock') dmd_proxmox_json(false, 'Action MyDesk inconnue.', array(), 400);

    $attempt = dmd_proxmox_mfa_attempt_state();
    if (!empty($attempt['locked_until']) && time() < (int)$attempt['locked_until']) {
        $remaining = max(1, (int)ceil(((int)$attempt['locked_until'] - time()) / 60));
        dmd_proxmox_json(false, 'Trop de tentatives. Réessaie dans environ ' . $remaining . ' minute(s).', array(), 429);
    }

    $usedRecovery = false;
    $ok = false;
    $method = dmd_proxmox_mfa_required() ? 'mfa' : 'password';
    if ($method === 'mfa') {
        $code = trim((string)(isset($_POST['mfa_code']) ? $_POST['mfa_code'] : ''));
        if ($code !== '' && function_exists('dmd_mfa_verify_user_code')) {
            try { $ok = (bool)dmd_mfa_verify_user_code($email, $code, $usedRecovery); } catch (Throwable $e) { $ok = false; }
        }
    } else {
        $password = (string)(isset($_POST['password']) ? $_POST['password'] : '');
        $ok = dmd_proxmox_mfa_verify_password($password);
    }

    if (!$ok) {
        $state = dmd_proxmox_mfa_attempt_failed();
        $remaining = max(0, 5 - (int)$state['count']);
        if (function_exists('dmd_system_log')) {
            try { dmd_system_log('dmd_proxmox_mydesk_unlock_failed', $email, 'denied', 'Échec du déverrouillage DMD-Proxmox depuis MyDesk.'); } catch (Throwable $e) {}
        }
        dmd_proxmox_json(false, $remaining > 0 ? 'Authentification incorrecte. Tentatives restantes : ' . $remaining . '.' : 'Trop de tentatives. Accès temporairement verrouillé.', array(), 403);
    }

    dmd_proxmox_mfa_attempt_clear();
    dmd_proxmox_mydesk_mark_unlocked($method, $usedRecovery);
    if (function_exists('dmd_system_log')) {
        try { dmd_system_log('dmd_proxmox_mydesk_unlock', $email, 'success', 'DMD-Proxmox déverrouillé depuis MyDesk avec ' . ($method === 'mfa' ? 'MFA.' : 'mot de passe DoMyDesk.')); } catch (Throwable $e) {}
    }
    dmd_proxmox_json(true, 'DMD-Proxmox déverrouillé.', array('unlocked'=>true, 'method'=>$method, 'expires_after'=>dmd_proxmox_mydesk_unlock_ttl()), 200);
}

$cssVersion = is_file(__DIR__ . '/DMD-Proxmox-mydesk.css') ? (string)@filemtime(__DIR__ . '/DMD-Proxmox-mydesk.css') : '270';
$fullUrl = rtrim($moduleBaseUrl, '/') . '/DMD-Proxmox.php?dmd_proxmox_mydesk_full=1';
$uid = 'dmdProxmoxMyDesk_' . substr(hash('sha256', session_id() . '|' . __DIR__), 0, 10);
?>
<link rel="stylesheet" href="<?= dmd_proxmox_mydesk_e($themeUrl) ?>">
<link rel="stylesheet" href="<?= dmd_proxmox_mydesk_e(rtrim($moduleBaseUrl, '/') . '/DMD-Proxmox-mydesk.css?v=' . rawurlencode($cssVersion)) ?>">
<script>
(function(){
  function sourceWindow(){
    const candidates=[];
    try{if(window.opener&&!window.opener.closed)candidates.push(window.opener);}catch(_){}
    try{if(window.parent&&window.parent!==window)candidates.push(window.parent);}catch(_){}
    for(const candidate of candidates){try{if(candidate.document&&candidate.location.origin===window.location.origin)return candidate;}catch(_){}}
    return null;
  }
  function syncTheme(){
    const source=sourceWindow(); if(!source)return;
    const names=['--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg','--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color','--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg','--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'];
    const targets=[document.documentElement,document.body].filter(Boolean);
    [source.document.documentElement,source.document.body].filter(Boolean).forEach(sourceRoot=>{const cs=source.getComputedStyle(sourceRoot);names.forEach(name=>{const value=cs.getPropertyValue(name);if(value&&value.trim())targets.forEach(target=>target.style.setProperty(name,value.trim()));});});
    try{const bs=source.getComputedStyle(source.document.body);targets.forEach(target=>{target.style.fontFamily=bs.fontFamily||'';});}catch(_){}
    document.documentElement.classList.add('dpx-md-host'); if(document.body)document.body.classList.add('dpx-md-host');
  }
  syncTheme(); window.addEventListener('load',syncTheme,{once:true});
})();
</script>
<?php
if ($email === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    echo '<div class="dpx-md dpx-md-denied">⛔ Connexion MyDesk requise.</div>';
    return;
}
if (!dmd_proxmox_has_module_assignment()) {
    echo '<div class="dpx-md dpx-md-denied">⛔ DMD-Proxmox ne vous est pas attribué.</div>';
    return;
}

$isUnlocked = dmd_proxmox_mydesk_unlock_valid();
if ($isUnlocked && dmd_proxmox_mfa_required() && !dmd_proxmox_mfa_unlocked(false)) {
    dmd_proxmox_mydesk_mark_unlocked('mfa', false);
}

if (!$isUnlocked):
    $requiresMfa = dmd_proxmox_mfa_required();
?>
<section class="dpx-md dpx-md-lock" id="<?= dmd_proxmox_mydesk_e($uid) ?>" data-full-url="<?= dmd_proxmox_mydesk_e($fullUrl) ?>" data-csrf="<?= dmd_proxmox_mydesk_e($mydeskCsrf) ?>">
  <header class="dpx-md-head">
    <div class="dpx-md-brand"><img src="<?= dmd_proxmox_mydesk_e($moduleBaseUrl . '/icon.png') ?>" alt=""><div><strong>DMD-Proxmox</strong><small>Infrastructure rapide</small></div></div>
    <button type="button" class="dpx-md-iconbtn" data-action="full" title="Ouvrir DMD-Proxmox complet dans DoMyDesk / PWA">↗</button>
  </header>
  <div class="dpx-md-lockcard">
    <div class="dpx-md-lockicon">🔐</div>
    <div class="dpx-md-lockcopy">
      <strong>DMD-Proxmox verrouillé</strong>
      <small><?= $requiresMfa ? 'Code MFA uniquement.' : 'Mot de passe DoMyDesk requis.' ?></small>
    </div>
    <form data-unlock autocomplete="off">
      <?php if ($requiresMfa): ?>
        <label><span>Code MFA</span><input name="mfa_code" inputmode="numeric" autocomplete="one-time-code" placeholder="000000" maxlength="32" required autofocus></label>
      <?php else: ?>
        <label><span>Mot de passe DoMyDesk</span><input name="password" type="password" autocomplete="current-password" required autofocus></label>
      <?php endif; ?>
      <button type="submit" class="dpx-md-primary">🔓 Déverrouiller</button>
      <div class="dpx-md-message" data-message aria-live="polite"></div>
    </form>
  </div>
</section>
<script>
(function(){
  const root=document.getElementById(<?= json_encode($uid) ?>); if(!root)return;
  function emit(detail){
    try{if(window.opener&&!window.opener.closed)window.opener.postMessage(detail,window.location.origin);}catch(_){}
    try{if(window.parent&&window.parent!==window)window.parent.postMessage(detail,window.location.origin);}catch(_){}
    try{window.dispatchEvent(new CustomEvent(detail.type,{detail}));}catch(_){}
  }
  function openFull(){
    const url=root.dataset.fullUrl; emit({type:'dmd:mydesk-open-full',module:'DMD-Proxmox',url,target:'domydesk-pwa'});
    try{const w=window.open(url,'_blank');if(w){try{w.focus();}catch(_){}return;}}catch(_){}
    window.location.assign(url);
  }
  root.addEventListener('click',e=>{const b=e.target.closest('[data-action="full"]');if(b){e.preventDefault();openFull();}});
  const form=root.querySelector('[data-unlock]'),msg=root.querySelector('[data-message]');
  form.addEventListener('submit',async e=>{
    e.preventDefault(); const button=form.querySelector('button[type="submit"]'); const fd=new FormData(form); fd.set('mydesk_action','unlock'); fd.set('csrf',root.dataset.csrf||'');
    button.disabled=true; msg.textContent='Vérification…'; msg.dataset.ok='1';
    try{const r=await fetch(window.location.href,{method:'POST',credentials:'same-origin',cache:'no-store',body:fd});const j=await r.json().catch(()=>null);if(!r.ok||!j||!j.ok)throw new Error(j&&j.message?j.message:'Authentification refusée.');msg.textContent='✅ '+(j.message||'Déverrouillé.');window.location.reload();}
    catch(err){msg.dataset.ok='0';msg.textContent='⛔ '+(err&&err.message?err.message:'Authentification refusée.');}
    finally{button.disabled=false;}
  });
  try{window.resizeTo(410,390);}catch(_){}
  emit({type:'dmd:mydesk-resize',module:'DMD-Proxmox',mode:'unlock',width:410,height:390});
})();
</script>
<?php return; endif; ?>
<?php
if (!dmd_proxmox_user_can('view')) {
    echo '<div class="dpx-md dpx-md-denied">⛔ Droit de consultation DMD-Proxmox refusé.</div>';
    return;
}

$canRefresh = dmd_proxmox_user_can('refresh');
$canConsoleGlobal = is_file(__DIR__ . '/novnc/core/rfb.js') && is_file(__DIR__ . '/DMD-Proxmox_remote_bridge.php') && dmd_proxmox_user_can('console');
$canStartGlobal = dmd_proxmox_user_can('vm.start');
$canShutdownGlobal = dmd_proxmox_user_can('vm.shutdown');
$canRebootGlobal = dmd_proxmox_user_can('vm.reboot');
$canStopGlobal = dmd_proxmox_user_can('vm.stop');
$canResetGlobal = dmd_proxmox_user_can('vm.reset');
$servers = dmd_proxmox_list_servers(false);
$rows = array();
$serverOptions = array();
$totalRunning = 0;
$totalStopped = 0;
$totalNodesOnline = 0;
$totalNodes = 0;
foreach ($servers as $server) {
    if (!is_array($server)) continue;
    $serverId = isset($server['id']) ? (string)$server['id'] : dmd_proxmox_slug(isset($server['name']) ? $server['name'] : 'server');
    $serverName = trim((string)(isset($server['name']) ? $server['name'] : $serverId));
    if ($serverName === '') $serverName = $serverId;
    $serverOptions[$serverId] = $serverName;
    $cache = dmd_proxmox_read_cache($server);
    $cluster = is_array($cache) && isset($cache['cluster']) && is_array($cache['cluster']) ? $cache['cluster'] : array();
    $totalNodesOnline += (int)(isset($cluster['nodes_online']) ? $cluster['nodes_online'] : 0);
    $totalNodes += (int)(isset($cluster['nodes_total']) ? $cluster['nodes_total'] : 0);
    $vms = is_array($cache) && isset($cache['vms']) && is_array($cache['vms']) ? $cache['vms'] : array();
    foreach ($vms as $vm) {
        if (!is_array($vm)) continue;
        $vmid = (int)(isset($vm['vmid']) ? $vm['vmid'] : 0); if ($vmid <= 0) continue;
        $type = strtolower(trim((string)(isset($vm['type']) ? $vm['type'] : 'qemu'))); if ($type !== 'lxc') $type = 'qemu';
        $name = trim((string)(isset($vm['name']) ? $vm['name'] : '')); if ($name === '') $name = strtoupper($type) . '-' . $vmid;
        $status = strtolower(trim((string)(isset($vm['status']) ? $vm['status'] : 'stopped')));
        $running = $status === 'running';
        if ($running) $totalRunning++; else $totalStopped++;
        $cpu = isset($vm['cpu']) ? dmd_proxmox_mydesk_percent($vm['cpu']) : 0;
        $ram = dmd_proxmox_mydesk_ram_percent(isset($vm['mem']) ? $vm['mem'] : 0, isset($vm['maxmem']) ? $vm['maxmem'] : 0);
        $node = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
        $permissions = array(
            'start'=>$canStartGlobal && dmd_proxmox_acl_can($email, $serverId, $type, $vmid, 'vm.start'),
            'shutdown'=>$canShutdownGlobal && dmd_proxmox_acl_can($email, $serverId, $type, $vmid, 'vm.shutdown'),
            'reboot'=>$canRebootGlobal && dmd_proxmox_acl_can($email, $serverId, $type, $vmid, 'vm.reboot'),
            'stop'=>$canStopGlobal && dmd_proxmox_acl_can($email, $serverId, $type, $vmid, 'vm.stop'),
            'reset'=>$canResetGlobal && $type === 'qemu' && dmd_proxmox_acl_can($email, $serverId, $type, $vmid, 'vm.reset'),
            'console'=>$canConsoleGlobal && dmd_proxmox_acl_can($email, $serverId, $type, $vmid, 'console')
        );
        $rows[] = array('server_id'=>$serverId,'server_name'=>$serverName,'vmid'=>$vmid,'name'=>$name,'type'=>$type,'status'=>$status,'running'=>$running,'cpu'=>$cpu,'ram'=>$ram,'node'=>$node,'permissions'=>$permissions);
    }
}
usort($rows, function($a, $b) {
    if ($a['running'] !== $b['running']) return $a['running'] ? -1 : 1;
    $c = strcasecmp((string)$a['server_name'], (string)$b['server_name']);
    if ($c !== 0) return $c;
    return ((int)$a['vmid']) - ((int)$b['vmid']);
});
$csrf = dmd_proxmox_csrf_token();
?>
<section class="dpx-md" id="<?= dmd_proxmox_mydesk_e($uid) ?>"
  data-base-url="<?= dmd_proxmox_mydesk_e($moduleBaseUrl) ?>"
  data-full-url="<?= dmd_proxmox_mydesk_e($fullUrl) ?>"
  data-csrf="<?= dmd_proxmox_mydesk_e($csrf) ?>"
  data-lock-csrf="<?= dmd_proxmox_mydesk_e($mydeskCsrf) ?>"
  data-can-refresh="<?= $canRefresh ? '1' : '0' ?>">
  <header class="dpx-md-head">
    <div class="dpx-md-brand"><img src="<?= dmd_proxmox_mydesk_e($moduleBaseUrl . '/icon.png') ?>" alt=""><div><strong>DMD-Proxmox</strong><small><?= count($rows) ?> VM/CT · <?= $totalRunning ?> actives</small></div></div>
    <div class="dpx-md-headtools">
      <span class="dpx-md-health" title="Nodes Proxmox en ligne"><?= $totalNodesOnline ?>/<?= $totalNodes ?> nodes</span>
      <?php if ($canRefresh): ?><button type="button" class="dpx-md-iconbtn" data-action="refresh" title="Actualiser Proxmox">↻</button><?php endif; ?>
      <button type="button" class="dpx-md-iconbtn" data-action="lock" title="Verrouiller DMD-Proxmox">🔒</button>
      <button type="button" class="dpx-md-iconbtn" data-action="full" title="Ouvrir DMD-Proxmox complet dans DoMyDesk / PWA">↗</button>
    </div>
  </header>

  <section class="dpx-md-listview" data-listview>
    <div class="dpx-md-tools">
      <label class="dpx-md-search"><span>⌕</span><input type="search" data-search placeholder="VM, CT, VMID, node…" autocomplete="off"></label>
      <select data-server-filter aria-label="Filtrer par serveur"><option value="">Tous les serveurs</option><?php foreach ($serverOptions as $sid=>$sname): ?><option value="<?= dmd_proxmox_mydesk_e($sid) ?>"><?= dmd_proxmox_mydesk_e($sname) ?></option><?php endforeach; ?></select>
    </div>
    <div class="dpx-md-filters" role="group" aria-label="Filtrer par état">
      <button type="button" data-status-filter="all" class="is-active">Toutes <span><?= count($rows) ?></span></button>
      <button type="button" data-status-filter="running">Actives <span><?= $totalRunning ?></span></button>
      <button type="button" data-status-filter="stopped">Arrêtées <span><?= $totalStopped ?></span></button>
    </div>

    <div class="dpx-md-vmlist" data-vmlist>
      <?php foreach ($rows as $row):
        $payload = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $search = strtolower($row['name'] . ' ' . $row['vmid'] . ' ' . $row['node'] . ' ' . $row['server_name'] . ' ' . $row['type']);
      ?>
      <button type="button" class="dpx-md-vm <?= $row['running'] ? 'is-running' : 'is-stopped' ?>" data-vm data-server="<?= dmd_proxmox_mydesk_e($row['server_id']) ?>" data-status="<?= $row['running'] ? 'running' : 'stopped' ?>" data-search="<?= dmd_proxmox_mydesk_e($search) ?>" data-payload="<?= dmd_proxmox_mydesk_e($payload) ?>">
        <span class="dpx-md-state"></span>
        <span class="dpx-md-vmcopy"><strong><?= dmd_proxmox_mydesk_e($row['name']) ?></strong><small>#<?= (int)$row['vmid'] ?> · <?= strtoupper(dmd_proxmox_mydesk_e($row['type'])) ?><?= $row['node'] !== '' ? ' · ' . dmd_proxmox_mydesk_e($row['node']) : '' ?> · <?= dmd_proxmox_mydesk_e($row['server_name']) ?></small></span>
        <span class="dpx-md-metrics"><small>CPU</small><strong><?= dmd_proxmox_mydesk_e($row['cpu']) ?>%</strong><small>RAM</small><strong><?= dmd_proxmox_mydesk_e($row['ram']) ?>%</strong></span>
        <span class="dpx-md-chevron">›</span>
      </button>
      <?php endforeach; ?>
      <?php if (!$rows): ?><div class="dpx-md-empty">Aucune VM/CT dans le cache Proxmox.<?= $canRefresh ? ' Lance une actualisation.' : '' ?></div><?php endif; ?>
    </div>
  </section>

  <section class="dpx-md-detail" data-detail hidden>
    <div class="dpx-md-subhead"><button type="button" data-action="back">‹ Machines</button><strong data-detail-title>VM</strong><span data-detail-state></span></div>
    <div class="dpx-md-detailmeta">
      <div><span>Serveur</span><strong data-detail-server>-</strong></div><div><span>Node</span><strong data-detail-node>-</strong></div><div><span>Type / VMID</span><strong data-detail-type>-</strong></div>
    </div>
    <div class="dpx-md-gauges"><div><span>CPU</span><strong data-detail-cpu>0%</strong><i><b data-cpu-bar></b></i></div><div><span>RAM</span><strong data-detail-ram>0%</strong><i><b data-ram-bar></b></i></div></div>
    <div class="dpx-md-actions" data-power-actions>
      <button type="button" data-vm-action="start">▶ Démarrer</button>
      <button type="button" data-vm-action="shutdown">⏻ Arrêt propre</button>
      <button type="button" data-vm-action="reboot">↻ Redémarrer</button>
      <button type="button" class="is-danger" data-vm-action="stop">■ Stop forcé</button>
      <button type="button" class="is-danger" data-vm-action="reset">⚡ Reset</button>
    </div>
    <button type="button" class="dpx-md-remote" data-action="remote">🖥 Remote</button>
    <div class="dpx-md-message" data-message aria-live="polite"></div>
  </section>

  <section class="dpx-md-remoteview" data-remoteview hidden>
    <div class="dpx-md-subhead"><button type="button" data-action="back-detail">‹ VM</button><strong data-remote-title>Remote</strong><button type="button" data-action="restart-remote" title="Relancer le Remote">↻ Remote</button></div>
    <iframe data-remote-frame src="about:blank" title="Remote Proxmox" referrerpolicy="no-referrer"></iframe>
  </section>

  <div class="dpx-md-toast" data-toast></div>
</section>
<script>
(function(){
  'use strict';
  const root=document.getElementById(<?= json_encode($uid) ?>); if(!root||root.dataset.ready==='1')return; root.dataset.ready='1';
  const base=root.dataset.baseUrl||''; const csrf=root.dataset.csrf||''; const canRefresh=root.dataset.canRefresh==='1';
  const listView=root.querySelector('[data-listview]'),detail=root.querySelector('[data-detail]'),remoteView=root.querySelector('[data-remoteview]'),remoteFrame=root.querySelector('[data-remote-frame]');
  const search=root.querySelector('[data-search]'),serverFilter=root.querySelector('[data-server-filter]'),toastBox=root.querySelector('[data-toast]'); let statusFilter='all',currentVm=null,currentRemoteUrl='';

  function emit(detailObj){try{if(window.opener&&!window.opener.closed)window.opener.postMessage(detailObj,window.location.origin);}catch(_){}try{if(window.parent&&window.parent!==window)window.parent.postMessage(detailObj,window.location.origin);}catch(_){}try{window.dispatchEvent(new CustomEvent(detailObj.type,{detail:detailObj}));}catch(_){}}
  function requestSize(mode){let width=430,height=640;if(mode==='detail'){width=520;height=650;}if(mode==='remote'){width=960;height=700;}try{window.resizeTo(width,height);}catch(_){}emit({type:'dmd:mydesk-resize',module:'DMD-Proxmox',mode,width,height});}
  function toast(text,ok=true){if(!toastBox)return;toastBox.textContent=text||'';toastBox.dataset.ok=ok?'1':'0';toastBox.classList.add('is-visible');clearTimeout(window.__dpxMdToast);window.__dpxMdToast=setTimeout(()=>toastBox.classList.remove('is-visible'),2600);}
  function openFull(){const url=root.dataset.fullUrl;emit({type:'dmd:mydesk-open-full',module:'DMD-Proxmox',url,target:'domydesk-pwa'});try{const w=window.open(url,'_blank');if(w){try{w.focus();}catch(_){}return;}}catch(_){}window.location.assign(url);}
  function applyFilters(){const q=(search?.value||'').trim().toLocaleLowerCase('fr');const sid=serverFilter?.value||'';root.querySelectorAll('[data-vm]').forEach(row=>{const showQ=!q||(row.dataset.search||'').includes(q);const showS=!sid||row.dataset.server===sid;const showStatus=statusFilter==='all'||row.dataset.status===statusFilter;row.hidden=!(showQ&&showS&&showStatus);});}
  function pct(v){const n=Math.max(0,Math.min(100,Number(v)||0));return n;}
  function showList(){currentVm=null;if(remoteFrame)remoteFrame.src='about:blank';remoteView.hidden=true;detail.hidden=true;listView.hidden=false;requestSize('compact');}
  function showDetail(vm){currentVm=vm;listView.hidden=true;remoteView.hidden=true;detail.hidden=false;root.querySelector('[data-detail-title]').textContent=vm.name||('VM #'+vm.vmid);root.querySelector('[data-detail-state]').textContent=vm.running?'● active':'● arrêtée';root.querySelector('[data-detail-state]').dataset.running=vm.running?'1':'0';root.querySelector('[data-detail-server]').textContent=vm.server_name||vm.server_id||'-';root.querySelector('[data-detail-node]').textContent=vm.node||'-';root.querySelector('[data-detail-type]').textContent=String(vm.type||'qemu').toUpperCase()+' #'+vm.vmid;root.querySelector('[data-detail-cpu]').textContent=pct(vm.cpu)+'%';root.querySelector('[data-detail-ram]').textContent=pct(vm.ram)+'%';root.querySelector('[data-cpu-bar]').style.width=pct(vm.cpu)+'%';root.querySelector('[data-ram-bar]').style.width=pct(vm.ram)+'%';
    root.querySelectorAll('[data-vm-action]').forEach(btn=>{const action=btn.dataset.vmAction;const allowed=!!(vm.permissions&&vm.permissions[action]);btn.hidden=!allowed;if(action==='start')btn.disabled=!!vm.running;else btn.disabled=!vm.running;});
    const remoteBtn=root.querySelector('[data-action="remote"]');remoteBtn.hidden=!(vm.running&&vm.permissions&&vm.permissions.console);requestSize('detail');}
  function remoteUrl(vm,restart){const u=new URL(base+'/DMD-Proxmox_console.php',window.location.origin);u.searchParams.set('server_id',vm.server_id);u.searchParams.set('vmid',String(vm.vmid));u.searchParams.set('type',vm.type||'qemu');u.searchParams.set('csrf',csrf);u.searchParams.set('_remote_instance','mydesk-'+Date.now()+'-'+Math.random().toString(16).slice(2));if(restart)u.searchParams.set('_remote_restart',String(Date.now()));return u.pathname+u.search;}
  function openRemote(restart=false){if(!currentVm||!currentVm.permissions?.console)return;currentRemoteUrl=remoteUrl(currentVm,restart);remoteFrame.src=currentRemoteUrl;root.querySelector('[data-remote-title]').textContent='Remote · '+(currentVm.name||('#'+currentVm.vmid));listView.hidden=true;detail.hidden=true;remoteView.hidden=false;requestSize('remote');}
  async function runVmAction(action){if(!currentVm||!(currentVm.permissions&&currentVm.permissions[action]))return;const labels={shutdown:'arrêter proprement',reboot:'redémarrer',stop:'forcer l’arrêt de',reset:'réinitialiser'};if(action!=='start'&&!confirm('Confirmer : '+(labels[action]||action)+' '+currentVm.name+' ?'))return;const msg=root.querySelector('[data-message]');msg.textContent='Action en cours…';msg.dataset.ok='1';try{const r=await fetch(base+'/DMD-Proxmox_action.php',{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({csrf,server_id:currentVm.server_id,vmid:currentVm.vmid,type:currentVm.type,action})});const j=await r.json().catch(()=>null);if(!r.ok||!j||!j.ok)throw new Error(j&&j.message?j.message:'Action refusée.');msg.textContent='✅ '+(j.message||'Action envoyée.');toast('Action envoyée à Proxmox.');}catch(err){msg.dataset.ok='0';msg.textContent='⛔ '+(err&&err.message?err.message:'Action refusée.');toast(err&&err.message?err.message:'Action refusée.',false);}}
  async function refresh(){if(!canRefresh)return;toast('Actualisation Proxmox…');try{const u=new URL(base+'/DMD-Proxmox_fetch.php',window.location.origin);u.searchParams.set('csrf',csrf);u.searchParams.set('t',String(Date.now()));const r=await fetch(u.pathname+u.search,{credentials:'same-origin',cache:'no-store'});const j=await r.json().catch(()=>null);if(!r.ok||!j||!j.ok)throw new Error(j&&j.message?j.message:'Actualisation impossible.');window.location.reload();}catch(err){toast(err&&err.message?err.message:'Actualisation impossible.',false);}}
  async function lock(){const fd=new FormData();fd.set('mydesk_action','lock');fd.set('csrf',root.dataset.lockCsrf||'');try{await fetch(window.location.href,{method:'POST',credentials:'same-origin',cache:'no-store',body:fd});}catch(_){}window.location.reload();}

  root.addEventListener('click',e=>{
    const vmRow=e.target.closest('[data-vm]');if(vmRow&&root.contains(vmRow)){e.preventDefault();try{showDetail(JSON.parse(vmRow.dataset.payload||'{}'));}catch(_){toast('Fiche VM invalide.',false);}return;}
    const filter=e.target.closest('[data-status-filter]');if(filter){e.preventDefault();statusFilter=filter.dataset.statusFilter||'all';root.querySelectorAll('[data-status-filter]').forEach(b=>b.classList.toggle('is-active',b===filter));applyFilters();return;}
    const power=e.target.closest('[data-vm-action]');if(power){e.preventDefault();runVmAction(power.dataset.vmAction);return;}
    const action=e.target.closest('[data-action]')?.dataset.action;if(!action)return;e.preventDefault();if(action==='full')openFull();else if(action==='refresh')refresh();else if(action==='lock')lock();else if(action==='back')showList();else if(action==='remote')openRemote(false);else if(action==='back-detail'){remoteFrame.src='about:blank';remoteView.hidden=true;detail.hidden=false;requestSize('detail');}else if(action==='restart-remote')openRemote(true);
  });
  if(search)search.addEventListener('input',applyFilters);if(serverFilter)serverFilter.addEventListener('change',applyFilters);applyFilters();requestSize('compact');
})();
</script>
