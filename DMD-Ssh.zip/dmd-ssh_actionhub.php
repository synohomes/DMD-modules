<?php
declare(strict_types=1);
require_once __DIR__ . '/dmd-ssh_lib.php';

function dmd_ssh_actionhub_local_id($resource): string {
    if(!is_array($resource))return '';
    $id=(string)($resource['id']??'');$prefix=DMD_SSH_ID.':connection:';
    if(strpos($id,$prefix)!==0)return '';
    return dmd_ssh_slug(substr($id,strlen($prefix)));
}

function dmd_ssh_actionhub_permissions(string $email, array $permissions): ?array {
    foreach ($permissions as $permission) {
        if (!dmd_ssh_has_permission((string)$permission, $email)) {
            return array(
                'ok' => false,
                'error' => 'permission_denied',
                'message' => 'Droit DMD-Ssh manquant : ' . (string)$permission . '.'
            );
        }
    }
    return null;
}

function dmd_ssh_actionhub_handle($context): array {
    $context=is_array($context)?$context:array();$email=trim((string)($context['email']??''));$action=is_array($context['action']??null)?$context['action']:array();$actionId=(string)($action['id']??'');$payload=is_array($context['payload']??null)?$context['payload']:array();$resource=is_array($context['resource']??null)?$context['resource']:null;
    if(filter_var($email,FILTER_VALIDATE_EMAIL)===false)return array('ok'=>false,'error'=>'invalid_user','message'=>'Utilisateur DMD-Ssh invalide.');
    $id=dmd_ssh_actionhub_local_id($resource);if($id==='')return array('ok'=>false,'error'=>'invalid_resource','message'=>'Connexion SSH invalide.');
    $c=dmd_ssh_get_connection($id,$email,true);if(!$c)return array('ok'=>false,'error'=>'missing_resource','message'=>'Connexion SSH introuvable pour cet utilisateur.');
    if (!dmd_ssh_has_permission('module.view',$email)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Droit DMD-Ssh manquant : module.view.');
    if (!dmd_ssh_has_permission('connections.view',$email) && !dmd_ssh_has_permission('connections.manage',$email)) return array('ok'=>false,'error'=>'permission_denied','message'=>'Accès aux connexions SSH refusé.');

    if($actionId==='connection.open'){
        if($denied=dmd_ssh_actionhub_permissions($email,array('actionhub.use','terminal.open')))return $denied;
        dmd_ssh_log('connection.open',$c,$email,'success',array(),dmd_ssh_resource($c),'actionhub');
        return array('ok'=>true,'message'=>'Ouverture de la console SSH DMD-Ssh.','data'=>array('ui'=>array('type'=>'open_ssh','connection_id'=>$id)),'event_emitted'=>true);
    }
    if($actionId==='connection.test'){
        if($denied=dmd_ssh_actionhub_permissions($email,array('actionhub.use','terminal.open')))return $denied;
        try{
            $r=dmd_ssh_test($c,$email,'actionhub');
            $c['last_test_at']=date(DATE_ATOM);$c['last_test_status']=$r['ok']?'online':'error';$c['last_test_message']=dmd_ssh_clean(trim($r['stderr']!==''?$r['stderr']:$r['stdout']),300);dmd_ssh_write_json(dmd_ssh_connection_file($id,$email),$c);
            return array('ok'=>$r['ok'],'message'=>$r['ok']?'Connexion SSH opérationnelle.':'Test SSH en échec.','data'=>array('exit_code'=>$r['exit_code'],'duration_ms'=>$r['duration_ms'],'reload'=>true),'event_emitted'=>true);
        }catch(Throwable $e){return array('ok'=>false,'error'=>'ssh_test_failed','message'=>$e->getMessage());}
    }
    if($actionId==='command.execute'){
        if($denied=dmd_ssh_actionhub_permissions($email,array('actionhub.use','terminal.execute')))return $denied;
        try{$command=(string)($payload['command']??'');$timeout=(int)($payload['timeout']??30);$r=dmd_ssh_execute($c,$command,$email,$timeout,'command.execute','actionhub');return array('ok'=>$r['ok'],'message'=>$r['ok']?'Commande SSH exécutée.':'Commande SSH terminée avec erreur.','data'=>array('exit_code'=>$r['exit_code'],'stdout'=>dmd_ssh_clean($r['stdout'],2000),'stderr'=>dmd_ssh_clean($r['stderr'],2000)),'event_emitted'=>true);}catch(Throwable $e){return array('ok'=>false,'error'=>'ssh_command_failed','message'=>$e->getMessage());}
    }
    if($actionId==='quicksession.add'){
        if($denied=dmd_ssh_actionhub_permissions($email,array('actionhub.use','quicksession.use')))return $denied;
        try{dmd_ssh_boot_core();if(!function_exists('dmd_qs_add_resource'))throw new RuntimeException('Quick-Session indisponible.');$r=dmd_qs_add_resource($email,dmd_ssh_resource($c));dmd_ssh_log('quicksession.add',$c,$email,!empty($r['ok'])?'success':'error',array(),dmd_ssh_resource($c),'actionhub');return array('ok'=>!empty($r['ok']),'message'=>!empty($r['ok'])?'Connexion ajoutée à Quick-Session.':'Aucune Quick-Session active.','event_emitted'=>true);}catch(Throwable $e){return array('ok'=>false,'error'=>'quicksession_failed','message'=>$e->getMessage());}
    }
    if(in_array($actionId,array('scenario.connection.open','scenario.connection.test','scenario.command.execute'),true)){
        $id=dmd_ssh_slug((string)($payload['connection_id']??''));
        if($id==='')return array('ok'=>false,'error'=>'invalid_resource','message'=>'Sélectionnez une connexion SSH.');
        $c=dmd_ssh_get_connection($id,$email,true);
        if(!$c)return array('ok'=>false,'error'=>'missing_resource','message'=>'Connexion SSH introuvable pour cet utilisateur.');
        if($actionId==='scenario.connection.open'){
            if($denied=dmd_ssh_actionhub_permissions($email,array('terminal.open')))return $denied;
            dmd_ssh_log('connection.open',$c,$email,'success',array(),dmd_ssh_resource($c),'actionhub');
            return array('ok'=>true,'message'=>'Ouverture de la console SSH DMD-Ssh.','data'=>array('ui'=>array('type'=>'open_ssh','connection_id'=>$id)),'event_emitted'=>true);
        }
        if($actionId==='scenario.connection.test'){
            if($denied=dmd_ssh_actionhub_permissions($email,array('terminal.open')))return $denied;
            try{
                $r=dmd_ssh_test($c,$email,'actionhub');
                $c['last_test_at']=date(DATE_ATOM);$c['last_test_status']=$r['ok']?'online':'error';$c['last_test_message']=dmd_ssh_clean(trim($r['stderr']!==''?$r['stderr']:$r['stdout']),300);dmd_ssh_write_json(dmd_ssh_connection_file($id,$email),$c);
                return array('ok'=>$r['ok'],'message'=>$r['ok']?'Connexion SSH opérationnelle.':'Test SSH en échec.','data'=>array('exit_code'=>$r['exit_code'],'duration_ms'=>$r['duration_ms'],'reload'=>true),'event_emitted'=>true);
            }catch(Throwable $e){return array('ok'=>false,'error'=>'ssh_test_failed','message'=>$e->getMessage());}
        }
        if($denied=dmd_ssh_actionhub_permissions($email,array('terminal.execute')))return $denied;
        try{
            $command=(string)($payload['command']??'');$timeout=(int)($payload['timeout']??30);
            $r=dmd_ssh_execute($c,$command,$email,$timeout,'command.execute','actionhub');
            return array('ok'=>$r['ok'],'message'=>$r['ok']?'Commande SSH exécutée.':'Commande SSH terminée avec erreur.','data'=>array('exit_code'=>$r['exit_code'],'stdout'=>dmd_ssh_clean($r['stdout'],2000),'stderr'=>dmd_ssh_clean($r['stderr'],2000)),'event_emitted'=>true);
        }catch(Throwable $e){return array('ok'=>false,'error'=>'ssh_command_failed','message'=>$e->getMessage());}
    }
    return array('ok'=>false,'error'=>'unknown_action','message'=>'Action ActionHub DMD-Ssh inconnue.');
}

/**
 * ActionHub runtime catalog.
 * Populates the SSH connection selector for module-scope scenario actions.
 * This makes DMD-Ssh discoverable by the ActionHub/QuickSession scenario editor
 * even when no SSH resource has previously been memorised by ActionHub.
 */
function dmd_ssh_actionhub_catalog($context): array {
    $context = is_array($context) ? $context : array();
    $email = trim((string)($context['email'] ?? ''));
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return array('actions' => array());

    $options = array();
    try {
        foreach (dmd_ssh_list_connections($email) as $connection) {
            if (!is_array($connection)) continue;
            $id = dmd_ssh_slug((string)($connection['id'] ?? ''));
            if ($id === '') continue;
            $name = dmd_ssh_clean((string)($connection['name'] ?? $id), 120);
            $host = dmd_ssh_clean((string)($connection['host'] ?? ''), 160);
            $user = dmd_ssh_clean((string)($connection['username'] ?? ''), 100);
            $port = (int)($connection['port'] ?? 22);
            $label = $name;
            if ($host !== '') $label .= ' — ' . ($user !== '' ? $user . '@' : '') . $host . ':' . $port;
            $options[] = array('value' => $id, 'label' => $label);
        }
    } catch (Throwable $e) {
        $options = array();
    }

    $provided = array();
    foreach ((array)($context['actions'] ?? array()) as $action) {
        if (!is_array($action)) continue;
        $id = (string)($action['id'] ?? '');
        if (!in_array($id, array('scenario.connection.open','scenario.connection.test','scenario.command.execute'), true)) continue;
        $copy = $action;
        foreach ((array)($copy['inputs'] ?? array()) as $i => $input) {
            if (is_array($input) && (string)($input['id'] ?? '') === 'connection_id') {
                $copy['inputs'][$i]['options'] = $options;
            }
        }
        $provided[] = $copy;
    }
    return array('actions' => $provided);
}
