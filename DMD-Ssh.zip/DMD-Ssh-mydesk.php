<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ssh_lib.php';
$email = dmd_ssh_email();
if ($email === '') { echo '<div class="dmdssh-mydesk-denied">Connexion MyDesk requise.</div>'; return; }
if (!dmd_ssh_has_permission('module.view', $email)) { echo '<div class="dmdssh-mydesk-denied">Accès DMD-Ssh refusé.</div>'; return; }

$moduleBase = rtrim(dmd_ssh_module_web_path(), '/');
$themeUrl = dmd_ssh_theme_web_url($email);
$cssVersion = is_file(__DIR__ . '/dmd-ssh.css') ? (string)filemtime(__DIR__ . '/dmd-ssh.css') : DMD_SSH_VERSION;
$myCssVersion = is_file(__DIR__ . '/dmd-ssh-mydesk.css') ? (string)filemtime(__DIR__ . '/dmd-ssh-mydesk.css') : DMD_SSH_VERSION;
$uid = 'dmdssh_mydesk_' . bin2hex(random_bytes(5));
$uiJs = is_file(__DIR__ . '/dmd-ssh-ui.js') ? (string)file_get_contents(__DIR__ . '/dmd-ssh-ui.js') : '';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleBase . '/dmd-ssh.css?v=' . rawurlencode($cssVersion), ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleBase . '/dmd-ssh-mydesk.css?v=' . rawurlencode($myCssVersion), ENT_QUOTES, 'UTF-8') ?>">
<script>
(() => {
    function sourceWindow(){
        const candidates=[];
        try { if(window.opener && !window.opener.closed)candidates.push(window.opener); } catch(_){}
        try { if(window.parent && window.parent!==window)candidates.push(window.parent); } catch(_){}
        for(const candidate of candidates){ try{ if(candidate.document && candidate.location.origin===window.location.origin)return candidate; }catch(_){} }
        return null;
    }
    function syncTheme(){
        const source=sourceWindow(); if(!source)return;
        const names=['--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg','--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-input-bg'];
        const targets=[document.documentElement,document.body].filter(Boolean);
        [source.document.documentElement,source.document.body].filter(Boolean).forEach(sourceRoot=>{
            const cs=source.getComputedStyle(sourceRoot); names.forEach(name=>{const value=cs.getPropertyValue(name);if(value&&value.trim())targets.forEach(t=>t.style.setProperty(name,value.trim()));});
        });
        try{const bs=source.getComputedStyle(source.document.body);targets.forEach(t=>t.style.fontFamily=bs.fontFamily||'');}catch(_){}
        document.documentElement.classList.add('dmdssh-mydesk-host'); if(document.body)document.body.classList.add('dmdssh-mydesk-host');
    }
    syncTheme(); window.addEventListener('load',syncTheme,{once:true});
})();
</script>
<section class="dmdssh-app dmdssh-mydesk" id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
 data-mode="mydesk"
 data-api="<?= htmlspecialchars($moduleBase . '/dmd-ssh_api.php', ENT_QUOTES, 'UTF-8') ?>"
 data-terminal-api="<?= htmlspecialchars($moduleBase . '/dmd-ssh_terminal_api.php', ENT_QUOTES, 'UTF-8') ?>"
 data-module-base="<?= htmlspecialchars($moduleBase, ENT_QUOTES, 'UTF-8') ?>"
 data-source="mydesk"
 data-dmd-module-id="DMD-Ssh"
 data-dmd-context-type="ssh_module"
 data-dmd-context-id="DMD-Ssh:module"
 data-dmd-context-name="DMD-Ssh">
    <header class="dmdssh-head">
        <div class="dmdssh-title"><img src="<?= htmlspecialchars($moduleBase . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt=""><span><strong>DMD-Ssh</strong><small data-role="subtitle">Connexions SSH</small></span></div>
        <div class="dmdssh-head-actions">
            <span class="dmdssh-runtime" data-role="runtime">…</span>
            <button type="button" data-action="home" title="Connexions">⌂</button>
            <?php if (dmd_ssh_has_permission('connections.manage', $email)): ?><button type="button" data-action="config" title="Connexions">⚙</button><?php endif; ?>
            <button type="button" data-action="refresh" title="Actualiser">↻</button>
        </div>
    </header>
    <div class="dmdssh-session-tabs" data-role="tabs" hidden></div>
    <div class="dmdssh-body dmdssh-mydesk-body" data-role="body"><div class="dmdssh-empty">Chargement…</div></div>
    <div class="dmdssh-toast" data-role="toast" hidden></div>
</section>
<script><?= $uiJs ?></script>
