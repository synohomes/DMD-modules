<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-ssh_lib.php';

$email = dmd_ssh_email();
if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) dmd_ssh_reply(array('ok'=>false,'message'=>'Non connecté.'), 401);
if (!dmd_ssh_has_permission('module.view', $email)) dmd_ssh_reply(array('ok'=>false,'message'=>'Accès DMD-Ssh refusé.'), 403);
if (!dmd_ssh_has_permission('connections.view', $email) && !dmd_ssh_has_permission('connections.manage', $email)) dmd_ssh_reply(array('ok'=>false,'message'=>'Accès aux connexions SSH refusé.'), 403);

function dmd_ssh_terminal_api_input(): array {
    $raw = (string)file_get_contents('php://input');
    $json = $raw !== '' ? json_decode($raw, true) : null;
    return is_array($json) ? $json : $_POST;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') dmd_ssh_reply(array('ok'=>false,'message'=>'Méthode refusée.'), 405);
dmd_ssh_check_csrf();
$input = dmd_ssh_terminal_api_input();
$action = (string)($_GET['action'] ?? $input['action'] ?? '');
$source = dmd_ssh_clean($input['source'] ?? 'module', 30) ?: 'module';

try {
    if ($action === 'start') {
        dmd_ssh_require_permission('terminal.open');
        $id = dmd_ssh_slug($input['id'] ?? '');
        $c = dmd_ssh_get_connection($id, $email, true);
        if (!$c) throw new RuntimeException('Connexion SSH introuvable.');
        $session = dmd_ssh_terminal_start($c, $email, (int)($input['cols'] ?? 100), (int)($input['rows'] ?? 30), $source);
        dmd_ssh_reply(array('ok'=>true,'session'=>$session));
    }
    if ($action === 'read') {
        dmd_ssh_require_permission('terminal.open');
        $token = dmd_ssh_terminal_token($input['token'] ?? '');
        if ($token === '') throw new RuntimeException('Session terminal invalide.');
        dmd_ssh_reply(array('ok'=>true,'terminal'=>dmd_ssh_terminal_read($token, $email, (int)($input['offset'] ?? 0))));
    }
    if ($action === 'input') {
        dmd_ssh_require_permission('terminal.execute');
        $token = dmd_ssh_terminal_token($input['token'] ?? '');
        $raw = base64_decode((string)($input['data_b64'] ?? ''), true);
        if ($token === '' || !is_string($raw)) throw new RuntimeException('Entrée terminal invalide.');
        dmd_ssh_terminal_input($token, $email, $raw);
        dmd_ssh_reply(array('ok'=>true));
    }
    if ($action === 'resize') {
        dmd_ssh_require_permission('terminal.open');
        $token = dmd_ssh_terminal_token($input['token'] ?? '');
        if ($token === '') throw new RuntimeException('Session terminal invalide.');
        dmd_ssh_terminal_resize($token, $email, (int)($input['cols'] ?? 100), (int)($input['rows'] ?? 30));
        dmd_ssh_reply(array('ok'=>true));
    }
    if ($action === 'close') {
        dmd_ssh_require_permission('terminal.open');
        $token = dmd_ssh_terminal_token($input['token'] ?? '');
        if ($token === '') throw new RuntimeException('Session terminal invalide.');
        dmd_ssh_terminal_close($token, $email, $source);
        dmd_ssh_reply(array('ok'=>true));
    }
    throw new RuntimeException('Action terminal inconnue.');
} catch (Throwable $e) {
    dmd_ssh_reply(array('ok'=>false,'message'=>$e->getMessage()), 400);
}
