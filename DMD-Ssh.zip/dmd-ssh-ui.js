(() => {
'use strict';

let xtermPromise=null;

function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
function text(v){return String(v??'').trim();}
function ensureCss(doc,url,key){if(doc.querySelector(`link[data-dmdssh-css="${key}"]`))return;const l=doc.createElement('link');l.rel='stylesheet';l.href=url;l.dataset.dmdsshCss=key;doc.head.appendChild(l);}
function ensureXterm(moduleBase){
    if(window.Terminal && window.FitAddon?.FitAddon)return Promise.resolve();
    if(xtermPromise)return xtermPromise;
    ensureCss(document,moduleBase+'/vendor/xterm.css','xterm');
    xtermPromise=import(moduleBase+'/vendor/xterm-module.js').then(mod=>{
        const bundle=mod?.default||mod;
        if(!bundle?.Terminal||!bundle?.FitAddon)throw new Error('Moteur terminal DMD-Ssh indisponible.');
        window.Terminal=bundle.Terminal;
        window.FitAddon={FitAddon:bundle.FitAddon};
    });
    return xtermPromise;
}
function host(){try{if(window.parent&&window.parent!==window&&window.parent.document?.body)return {win:window.parent,doc:window.parent.document};}catch(_){}return {win:window,doc:document};}
function cssValue(root,name,fallback=''){const v=getComputedStyle(root).getPropertyValue(name).trim();return v||fallback;}
function usableColor(value){return value&&value!=='transparent'&&value!=='inherit'&&value!=='initial'&&value!=='unset';}
function themeFor(root){
    const rs=getComputedStyle(root),bs=getComputedStyle(document.body||root);
    const bg=cssValue(root,'--input-bg',cssValue(root,'--page-bg',rs.backgroundColor||bs.backgroundColor));
    const fg=cssValue(root,'--text-color',rs.color||bs.color);
    const cursor=cssValue(root,'--primary-color',fg);
    const out={};
    if(usableColor(bg))out.background=bg;
    if(usableColor(fg))out.foreground=fg;
    if(usableColor(cursor))out.cursor=cursor;
    const selection=cssValue(root,'--primary-soft','');if(usableColor(selection))out.selectionBackground=selection;
    return out;
}
function b64FromString(value){const bytes=new TextEncoder().encode(value);let binary='';const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));return btoa(binary);}
function bytesFromB64(value){const binary=atob(value||'');const out=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)out[i]=binary.charCodeAt(i);return out;}

function init(root){
    if(root.dataset.dmdsshReady==='1')return;root.dataset.dmdsshReady='1';
    const mode=root.dataset.mode||'main',api=root.dataset.api,termApi=root.dataset.terminalApi,moduleBase=root.dataset.moduleBase||'',source=root.dataset.source||mode;
    const body=root.querySelector('[data-role="body"]'),toastEl=root.querySelector('[data-role="toast"]'),runtimeEl=root.querySelector('[data-role="runtime"]'),subtitleEl=root.querySelector('[data-role="subtitle"]'),tabsEl=root.querySelector('[data-role="tabs"]');
    let state={connections:[],permissions:{},runtime:{}},csrf='',loaded=false,z=25000;
    const sessions=new Map();

    function toast(message,bad=false){if(!toastEl)return;toastEl.textContent=message||'';toastEl.dataset.bad=bad?'1':'0';toastEl.hidden=false;clearTimeout(toastEl._timer);toastEl._timer=setTimeout(()=>toastEl.hidden=true,4200);}
    function hub(){const h=host();return h.win.DMDActionHub||window.DMDActionHub||null;}
    function context(c){return {type:'ssh_connection',id:`DMD-Ssh:connection:${c.id}`,label:c.name||c.host,name:c.name||c.host,source:'DMD-Ssh',tags:['ssh',...(c.tags||[])]};}
    async function request(url,action,payload={},method='POST',keepalive=false){
        const target=url+(url.includes('?')?'&':'?')+'action='+encodeURIComponent(action);
        const opt={method,credentials:'same-origin',cache:'no-store'};
        if(method==='POST'){opt.headers={'Content-Type':'application/json','X-DMD-CSRF':csrf};opt.body=JSON.stringify(payload);opt.keepalive=keepalive;}
        const r=await fetch(target,opt);const j=await r.json().catch(()=>({ok:false,message:'Réponse DMD-Ssh invalide.'}));if(!r.ok||!j.ok)throw new Error(j.message||`Erreur HTTP ${r.status}`);return j;
    }
    async function load(silent=false){
        try{const r=await fetch(api+'?action=state',{credentials:'same-origin',cache:'no-store'});const j=await r.json();if(!r.ok||!j.ok)throw new Error(j.message||'Chargement impossible.');state=j;csrf=j.csrf||csrf;loaded=true;renderRuntime();if(mode==='config'){body.innerHTML=configMarkup();bindConfig(body);}else if(mode==='mydesk')setupMydesk();else renderCards(body);registerProvider();decorate(root);}
        catch(e){body.innerHTML=`<div class="dmdssh-empty dmdssh-error">${esc(e.message)}</div>`;if(!silent)toast(e.message,true);}
    }
    function renderRuntime(){if(!runtimeEl)return;const rt=state.runtime||{};const parts=[];parts.push(rt.ssh?'SSH ✓':'SSH ✕');parts.push(rt.pty?'PTY ✓':'PTY ✕');runtimeEl.textContent=parts.join(' · ');runtimeEl.dataset.bad=(!rt.ssh||!rt.pty)?'1':'0';}
    function conn(id){return (state.connections||[]).find(c=>String(c.id)===String(id));}
    function authLabel(c){return c.auth_type==='password'?'Mot de passe':c.auth_type==='private_key'?'Clé privée':'Agent SSH';}
    function statusLabel(c){if(c.last_test_status==='online')return '<span class="dmdssh-state ok">En ligne</span>';if(c.last_test_status==='error')return '<span class="dmdssh-state bad">Erreur</span>';return '<span class="dmdssh-state">Non testé</span>';}
    function cardHtml(c){return `<article class="dmdssh-card" data-dmd-module-id="DMD-Ssh" data-dmd-context-type="ssh_connection" data-dmd-context-id="${esc(`DMD-Ssh:connection:${c.id}`)}" data-dmd-context-name="${esc(c.name||c.host)}">
        <div class="dmdssh-card-head"><div><strong>${esc(c.name||c.host)}</strong><small>${esc(c.username)}@${esc(c.host)}:${Number(c.port)||22}</small></div>${statusLabel(c)}</div>
        <div class="dmdssh-card-meta"><span>${esc(authLabel(c))}</span>${(c.tags||[]).slice(0,4).map(t=>`<span>${esc(t)}</span>`).join('')}</div>
        <div class="dmdssh-card-actions">
            ${state.permissions.terminal_open?`<button type="button" data-open="${esc(c.id)}" class="primary">⌨ Terminal</button>`:''}
            ${state.permissions.terminal_open?`<button type="button" data-test="${esc(c.id)}">Tester</button>`:''}
            ${state.permissions.quicksession_use?`<button type="button" data-qs="${esc(c.id)}">QuickSession</button>`:''}
            
            ${state.permissions.connections_manage?`<button type="button" data-edit="${esc(c.id)}">✎</button>`:''}
        </div></article>`;}
    function renderCards(target){if(!target)return;target.innerHTML=(state.connections||[]).length?`<div class="dmdssh-grid">${state.connections.map(cardHtml).join('')}</div>`:`<div class="dmdssh-empty"><strong>Aucune connexion SSH</strong>${state.permissions.connections_manage?'<button type="button" data-action="config">Ajouter un équipement</button>':''}</div>`;decorate(target);}

    function hostKeyChanged(message){const t=String(message||'').toLowerCase();return t.includes('remote host identification has changed')||t.includes('host key verification failed')||(t.includes('offending ')&&t.includes('known_hosts'));}
    async function acceptChangedHostKey(c){
        if(!confirm(`L’identité SSH de ${c.name||c.host} a changé.\n\nCela arrive notamment après une réinstallation ou un remplacement du serveur.\n\nAccepter la nouvelle identité et reconnecter ?`))return false;
        const j=await request(api,'hostkey_accept',{id:c.id,source});toast(j.message||'Nouvelle identité SSH autorisée.');return true;
    }
    async function testConnection(id,retry=false){const c=conn(id);if(!c)return;toast(`Test ${c.name}…`);try{const j=await request(api,'test',{id,source});if(!j.test_ok&&hostKeyChanged(j.message)&&!retry){if(await acceptChangedHostKey(c))return testConnection(id,true);}toast(j.test_ok?'Connexion SSH opérationnelle.':j.message,!j.test_ok);await load(true);}catch(e){if(hostKeyChanged(e.message)&&!retry){try{if(await acceptChangedHostKey(c))return testConnection(id,true);}catch(x){toast(x.message,true);return;}}toast(e.message,true);}}
    async function quickSession(id){try{const j=await request(api,'quicksession_add',{id,source});toast(j.message,!j.ok);}catch(e){toast(e.message,true);}}
    function openHub(id){const c=conn(id),h=hub();if(!c||!h||typeof h.open!=='function'){toast('ActionHub indisponible.',true);return;}h.open(context(c));}

    function ensureHostStyles(doc){ensureCss(doc,moduleBase+'/dmd-ssh.css','module');ensureCss(doc,moduleBase+'/vendor/xterm.css','xterm');}
    function floatingWindow(title,kind='terminal',width=900,height=620){const h=host();ensureHostStyles(h.doc);const win=h.doc.createElement('section');win.className='dmdssh-float';win.dataset.kind=kind;win.style.width=Math.min(width,h.win.innerWidth-24)+'px';win.style.height=Math.min(height,h.win.innerHeight-24)+'px';win.style.left=Math.max(8,(h.win.innerWidth-Math.min(width,h.win.innerWidth-24))/2)+'px';win.style.top=Math.max(8,(h.win.innerHeight-Math.min(height,h.win.innerHeight-24))/2)+'px';win.style.zIndex=String(++z);win.innerHTML=`<header class="dmdssh-float-head"><strong>${esc(title)}</strong><div><button type="button" data-float-refresh title="Actualiser">↻</button><button type="button" data-float-close title="Fermer">×</button></div></header><div class="dmdssh-float-body"></div>`;h.doc.body.appendChild(win);win.addEventListener('pointerdown',()=>win.style.zIndex=String(++z));win.querySelector('[data-float-close]').onclick=()=>{win.dispatchEvent(new CustomEvent('dmdssh:closing'));win.remove();};
        const head=win.querySelector('.dmdssh-float-head');let drag=null;head.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;drag={x:e.clientX,y:e.clientY,l:parseFloat(win.style.left)||0,t:parseFloat(win.style.top)||0};head.setPointerCapture?.(e.pointerId);});head.addEventListener('pointermove',e=>{if(!drag)return;win.style.left=Math.max(0,drag.l+e.clientX-drag.x)+'px';win.style.top=Math.max(0,drag.t+e.clientY-drag.y)+'px';});head.addEventListener('pointerup',()=>drag=null);return win;}

    function terminalToolbar(c,where='main'){return `<div class="dmdssh-terminal-toolbar"><div><strong>${esc(c.name)}</strong><small>${esc(c.username)}@${esc(c.host)}:${Number(c.port)||22}</small></div><span class="dmdssh-terminal-status" data-term-status>Connexion…</span><div class="dmdssh-terminal-actions">${state.permissions.quicksession_use?'<button type="button" data-term-qs>QuickSession</button>':''}<button type="button" data-term-reconnect>↻ Reconnecter</button>${where==='mydesk'?'<button type="button" data-term-close>×</button>':''}</div></div>`;}

    async function mountTerminal(c,container,opts={}){
        await ensureXterm(moduleBase);
        container.innerHTML=`<div class="dmdssh-terminal-shell">${terminalToolbar(c,opts.where||'main')}<div class="dmdssh-terminal" data-terminal></div><div class="dmdssh-terminal-foot"><span>Ctrl+Shift+C copier · Ctrl+Shift+V coller</span><span data-term-detail></span></div></div>`;
        const holder=container.querySelector('[data-terminal]'),status=container.querySelector('[data-term-status]'),detail=container.querySelector('[data-term-detail]');
        const baseFont=parseFloat(getComputedStyle(root).fontSize)||13;const termFont=Math.max(12,Math.min(16,baseFont));const term=new window.Terminal({cursorBlink:true,convertEol:false,scrollback:10000,fontSize:termFont,fontFamily:'Consolas, "Liberation Mono", Menlo, monospace',allowTransparency:true,theme:themeFor(root)});
        const fit=new window.FitAddon.FitAddon();term.loadAddon(fit);term.open(holder);requestAnimationFrame(()=>{try{fit.fit();}catch(_){}});
        let token='',offset=0,closed=false,pollTimer=null,inputQueue='',inputTimer=null,resizeTimer=null;
        const session={c,term,fit,container,get token(){return token;},close};
        function setStatus(t,bad=false){status.textContent=t;status.dataset.bad=bad?'1':'0';}
        async function start(retry=false){if(closed)return;setStatus('Connexion…');term.reset();term.write(`\x1b[2mConnexion à ${c.username}@${c.host}:${Number(c.port)||22}…\x1b[0m\r\n`);try{fit.fit();const j=await request(termApi,'start',{id:c.id,cols:term.cols,rows:term.rows,source});token=j.session.token;offset=0;setStatus('Session active');detail.textContent='';poll();}catch(e){if(hostKeyChanged(e.message)&&!retry){try{if(await acceptChangedHostKey(c))return start(true);}catch(x){e=x;}}setStatus('Échec',true);term.write(`\r\n\x1b[31m${e.message}\x1b[0m\r\n`);detail.textContent=e.message;}}
        async function poll(){if(closed||!token)return;try{const j=await request(termApi,'read',{token,offset,source});const t=j.terminal||{};if(t.data_b64){const bytes=bytesFromB64(t.data_b64);if(bytes.length)term.write(bytes);}offset=Number(t.offset)||offset;if(t.state?.dead){setStatus(`Fermée · code ${Number(t.state.exit_code)||0}`,true);detail.textContent='Session SSH terminée.';return;}setStatus('Session active');}catch(e){setStatus('Lecture interrompue',true);detail.textContent=e.message;}if(!closed&&token)pollTimer=setTimeout(poll,120);}
        async function flushInput(){inputTimer=null;if(!token||!inputQueue||closed)return;const data=inputQueue;inputQueue='';try{await request(termApi,'input',{token,data_b64:b64FromString(data),source});}catch(e){setStatus('Entrée refusée',true);detail.textContent=e.message;}}
        term.onData(data=>{if(!state.permissions.terminal_execute)return;inputQueue+=data;if(inputQueue.length>8192){flushInput();return;}if(!inputTimer)inputTimer=setTimeout(flushInput,18);});
        term.onResize(size=>{if(!token||closed)return;clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>request(termApi,'resize',{token,cols:size.cols,rows:size.rows,source}).catch(()=>{}),140);});
        const termDoc=holder.ownerDocument||document;
        const termWin=termDoc.defaultView||window;
        function terminalOwnsFocus(){const a=termDoc.activeElement;return !!a&&(a===holder||holder.contains(a));}
        async function copyTerminalSelection(){
            const sel=term.getSelection();if(!sel)return false;
            try{if(termWin.isSecureContext&&termWin.navigator?.clipboard?.writeText){await termWin.navigator.clipboard.writeText(sel);term.focus();return true;}}catch(_){}
            const ta=termDoc.createElement('textarea');ta.value=sel;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.left='-10000px';ta.style.top='0';ta.style.opacity='0';termDoc.body.appendChild(ta);ta.focus();ta.select();ta.setSelectionRange(0,ta.value.length);let ok=false;try{ok=termDoc.execCommand('copy');}catch(_){}ta.remove();term.focus();return ok;
        }
        function pasteText(value){if(typeof value!=='string'||value==='')return false;term.paste(value);term.focus();return true;}
        function pasteFromEvent(e){
            if(!terminalOwnsFocus())return;
            const value=e.clipboardData?.getData('text/plain')??e.clipboardData?.getData('text');
            if(pasteText(value)){e.preventDefault();e.stopImmediatePropagation();}
        }
        function clipboardKeyCapture(e){
            if(!terminalOwnsFocus()||e.type!=='keydown')return;
            const mod=e.ctrlKey||e.metaKey;
            if(mod&&e.code==='KeyC'&&term.hasSelection()){
                e.preventDefault();e.stopImmediatePropagation();copyTerminalSelection();return;
            }
            // Laisser le navigateur produire son vrai évènement "paste". Cela fonctionne aussi
            // en HTTP lorsque navigator.clipboard est interdit. Ctrl+V, Ctrl+Shift+V et Shift+Insert.
            if((mod&&e.code==='KeyV')||(e.shiftKey&&e.code==='Insert')){
                const ta=holder.querySelector('.xterm-helper-textarea');if(ta&&termDoc.activeElement!==ta)ta.focus();
            }
        }
        termDoc.addEventListener('paste',pasteFromEvent,true);
        termDoc.addEventListener('keydown',clipboardKeyCapture,true);
        session.clipboardCleanup=()=>{termDoc.removeEventListener('paste',pasteFromEvent,true);termDoc.removeEventListener('keydown',clipboardKeyCapture,true);};
        term.attachCustomKeyEventHandler(ev=>{
            if(ev.type!=='keydown')return true;
            const mod=ev.ctrlKey||ev.metaKey;
            // Ctrl+C copie uniquement s'il existe une sélection ; sinon il reste SIGINT.
            if(mod&&ev.code==='KeyC'&&term.hasSelection())return false;
            // Ne jamais transformer les raccourcis de collage en caractères envoyés au shell.
            if((mod&&ev.code==='KeyV')||(ev.shiftKey&&ev.code==='Insert'))return false;
            return true;
        });
        holder.addEventListener('contextmenu',e=>{
            const sel=term.getSelection();
            if(sel){e.preventDefault();copyTerminalSelection();return;}
            const ta=holder.querySelector('.xterm-helper-textarea');if(ta)ta.focus();else term.focus();
        });
        const ro=new ResizeObserver(()=>{try{fit.fit();}catch(_){}});ro.observe(holder);session.ro=ro;
        container.querySelector('[data-term-reconnect]').onclick=async()=>{if(token)try{await request(termApi,'close',{token,source});}catch(_){}token='';offset=0;start();};
        const qs=container.querySelector('[data-term-qs]');if(qs)qs.onclick=()=>quickSession(c.id);const ah=container.querySelector('[data-term-ah]');if(ah)ah.onclick=()=>openHub(c.id);const closeBtn=container.querySelector('[data-term-close]');if(closeBtn)closeBtn.onclick=()=>opts.onClose?.();
        async function close(){if(closed)return;closed=true;clearTimeout(pollTimer);clearTimeout(inputTimer);clearTimeout(resizeTimer);try{ro.disconnect();}catch(_){}if(token)try{await request(termApi,'close',{token,source});}catch(_){}token='';try{session.clipboardCleanup?.();}catch(_){}try{term.dispose();}catch(_){}}
        await start();return session;
    }

    async function openFloatingTerminal(id){const c=conn(id);if(!c)return;if(!state.runtime?.interactive_terminal){toast(state.runtime?.pty_error||'Terminal interactif indisponible : OpenSSH ou backend PTY DMD-Ssh manquant.',true);return;}const w=floatingWindow('SSH · '+c.name,'terminal',940,650),b=w.querySelector('.dmdssh-float-body');w.querySelector('[data-float-refresh]').hidden=true;let s=null;w.addEventListener('dmdssh:closing',()=>s?.close());try{s=await mountTerminal(c,b,{where:'main'});}catch(e){b.innerHTML=`<div class="dmdssh-empty dmdssh-error">${esc(e.message)}</div>`;}}

    function setupMydesk(){
        if(body.dataset.mydeskSetup==='1'){renderMydeskList();return;}body.dataset.mydeskSetup='1';body.innerHTML='<div data-mydesk-list></div><div data-mydesk-terminals hidden></div><div data-mydesk-config hidden></div>';
        renderMydeskList();
    }
    function myViews(){return {list:body.querySelector('[data-mydesk-list]'),terms:body.querySelector('[data-mydesk-terminals]'),config:body.querySelector('[data-mydesk-config]')};}
    function showMy(name){const v=myViews();if(!v.list)return;v.list.hidden=name!=='list';v.terms.hidden=name!=='terms';v.config.hidden=name!=='config';if(subtitleEl)subtitleEl.textContent=name==='list'?'Connexions SSH':name==='config'?'Configuration':'Terminal SSH';}
    function renderMydeskList(){const v=myViews();if(!v.list)return;v.list.innerHTML=(state.connections||[]).length?`<div class="dmdssh-grid dmdssh-mydesk-grid">${state.connections.map(cardHtml).join('')}</div>`:`<div class="dmdssh-empty"><strong>Aucune connexion SSH</strong>${state.permissions.connections_manage?'<button type="button" data-action="config">Ajouter un équipement</button>':''}</div>`;showMy('list');decorate(v.list);renderTabs();}
    function renderTabs(){if(!tabsEl)return;tabsEl.hidden=sessions.size===0;tabsEl.innerHTML=[...sessions.entries()].map(([id,s])=>`<button type="button" data-session-tab="${esc(id)}" class="${s.active?'is-active':''}">${esc(s.c.name)}<span data-session-x="${esc(id)}">×</span></button>`).join('');}
    async function openMydeskTerminal(id){const c=conn(id);if(!c)return;if(!state.runtime?.interactive_terminal){toast(state.runtime?.pty_error||'Terminal interactif indisponible : OpenSSH ou backend PTY DMD-Ssh manquant.',true);return;}const v=myViews();showMy('terms');const panel=document.createElement('div');panel.className='dmdssh-mydesk-terminal-panel';v.terms.appendChild(panel);const sid='s'+Math.random().toString(36).slice(2);const record={c,panel,terminal:null,active:true};sessions.forEach(s=>s.active=false);sessions.set(sid,record);renderTabs();try{record.terminal=await mountTerminal(c,panel,{where:'mydesk',onClose:()=>closeMydeskSession(sid)});}catch(e){panel.innerHTML=`<div class="dmdssh-empty dmdssh-error">${esc(e.message)}</div>`;}activateMydeskSession(sid);}
    function activateMydeskSession(sid){const v=myViews();showMy('terms');sessions.forEach((s,id)=>{s.active=id===sid;s.panel.hidden=id!==sid;if(id===sid)setTimeout(()=>{try{s.terminal?.fit.fit();s.terminal?.term.focus();}catch(_){}},30);});renderTabs();}
    async function closeMydeskSession(sid){const s=sessions.get(sid);if(!s)return;await s.terminal?.close();s.panel.remove();sessions.delete(sid);if(sessions.size){activateMydeskSession(sessions.keys().next().value);}else{showMy('list');renderTabs();}}

    function configMarkup(){const secret=!!state.permissions.connections_secret;return `<div class="dmdssh-config"><aside><div class="dmdssh-config-head"><strong>Connexions</strong><button type="button" data-new>＋</button></div><div data-config-list></div></aside><form data-config-form><div class="dmdssh-config-head"><div><strong data-form-title>Nouvelle connexion</strong><small>Données privées dans le profil utilisateur</small></div><div><button type="button" class="danger" data-delete hidden>Supprimer</button><button type="submit" class="primary">Enregistrer</button></div></div><input type="hidden" name="id"><div class="dmdssh-fields"><label><span>Nom</span><input name="name" required placeholder="VPS-Ionos"></label><label><span>Hôte / IP / DNS</span><input name="host" required placeholder="10.10.3.111"></label><label><span>Port</span><input name="port" type="number" min="1" max="65535" value="22" required></label><label><span>Utilisateur</span><input name="username" required placeholder="root"></label><label class="wide"><span>Authentification</span><select name="auth_type"><option value="password">Mot de passe</option><option value="private_key">Clé privée</option><option value="agent">Agent SSH du serveur</option></select></label><div class="wide" data-auth-password><label><span>Mot de passe</span><input name="password" type="password" autocomplete="new-password" placeholder="${secret?'Vide = conserver l’existant':'Droit secrets requis'}" ${secret?'':'disabled'}></label>${secret?'<label class="check"><input type="checkbox" name="clear_password" value="1"> Effacer le mot de passe enregistré</label>':''}</div><div class="wide" data-auth-key hidden><label><span>Clé privée OpenSSH / PEM</span><textarea name="private_key" rows="7" ${secret?'':'disabled'}></textarea></label><label><span>Phrase secrète</span><input name="passphrase" type="password" autocomplete="new-password" ${secret?'':'disabled'}></label>${secret?'<label class="check"><input type="checkbox" name="clear_private_key" value="1"> Effacer la clé enregistrée</label>':''}</div><label class="wide"><span>Tags</span><input name="tags_text" placeholder="prod, linux, web"></label><label class="wide"><span>Notes</span><textarea name="notes" rows="5"></textarea></label></div><div class="dmdssh-form-message" data-form-message></div></form></div>`;}
    function bindConfig(target,selected=''){
        const form=target.querySelector('[data-config-form]'),list=target.querySelector('[data-config-list]'),msg=target.querySelector('[data-form-message]');let current=selected||'';
        function listRender(){list.innerHTML=(state.connections||[]).length?state.connections.map(c=>`<button type="button" data-pick="${esc(c.id)}" class="${current===c.id?'is-active':''}"><strong>${esc(c.name)}</strong><small>${esc(c.username)}@${esc(c.host)}:${Number(c.port)||22}</small></button>`).join(''):'<div class="dmdssh-empty">Aucune connexion.</div>';}
        function authUi(){const a=form.elements.auth_type.value;target.querySelector('[data-auth-password]').hidden=a!=='password';target.querySelector('[data-auth-key]').hidden=a!=='private_key';}
        function fill(c=null){current=c?.id||'';form.reset();form.elements.id.value=current;form.elements.name.value=c?.name||'';form.elements.host.value=c?.host||'';form.elements.port.value=c?.port||22;form.elements.username.value=c?.username||'';form.elements.auth_type.value=c?.auth_type||'password';form.elements.tags_text.value=(c?.tags||[]).join(', ');form.elements.notes.value=c?.notes||'';target.querySelector('[data-form-title]').textContent=c?c.name:'Nouvelle connexion';target.querySelector('[data-delete]').hidden=!c;msg.textContent='';authUi();listRender();}
        target.querySelector('[data-new]').onclick=()=>fill();list.onclick=e=>{const b=e.target.closest('[data-pick]');if(b)fill(conn(b.dataset.pick));};form.elements.auth_type.onchange=authUi;
        target.querySelector('[data-delete]').onclick=async()=>{if(!current||!confirm('Supprimer cette connexion SSH ?'))return;try{await request(api,'delete',{id:current});toast('Connexion supprimée.');await reloadStateOnly();fill();if(mode==='mydesk')renderMydeskList();}catch(e){msg.textContent=e.message;msg.dataset.bad='1';}};
        form.onsubmit=async e=>{e.preventDefault();const fd=new FormData(form),payload={};for(const [k,v] of fd.entries())payload[k]=(k==='clear_password'||k==='clear_private_key')?true:v;msg.textContent='Enregistrement…';msg.dataset.bad='0';try{const j=await request(api,'save',payload);await reloadStateOnly();fill(conn(j.connection.id));msg.textContent=j.message;toast(j.message);if(mode==='mydesk')renderMydeskList();else if(mode==='main')renderCards(body);}catch(err){msg.textContent=err.message;msg.dataset.bad='1';}};fill(current?conn(current):null);
    }
    async function reloadStateOnly(){const r=await fetch(api+'?action=state',{credentials:'same-origin',cache:'no-store'});const j=await r.json();if(!r.ok||!j.ok)throw new Error(j.message||'Actualisation impossible.');state=j;csrf=j.csrf||csrf;renderRuntime();}
    function openConfig(selected=''){
        if(!state.permissions.connections_manage){toast('Droit de gestion des connexions requis.',true);return;}
        if(mode==='config'){body.innerHTML=configMarkup();bindConfig(body,selected);return;}
        if(mode==='mydesk'){const v=myViews();v.config.innerHTML=configMarkup();bindConfig(v.config,selected);showMy('config');return;}
        const w=floatingWindow('DMD-Ssh · Connexions','config',850,620),b=w.querySelector('.dmdssh-float-body');b.innerHTML=configMarkup();bindConfig(b,selected);w.querySelector('[data-float-refresh]').onclick=async()=>{await reloadStateOnly();b.innerHTML=configMarkup();bindConfig(b,selected);};
    }
    async function openLogs(){const w=floatingWindow('DMD-Ssh · Journal','logs',800,560),b=w.querySelector('.dmdssh-float-body');const go=async()=>{b.innerHTML='<div class="dmdssh-empty">Chargement…</div>';try{const j=await request(api,'logs',{limit:200});b.innerHTML=(j.logs||[]).length?`<div class="dmdssh-logs">${j.logs.map(r=>`<article><div><strong>${esc(r.action||'')}</strong><small>${esc(r.datetime||'')} · ${esc(r.name||'')}</small></div><span class="${r.status==='success'?'ok':'bad'}">${esc(r.status||'')}</span></article>`).join('')}</div>`:'<div class="dmdssh-empty">Aucune activité.</div>';}catch(e){b.innerHTML=`<div class="dmdssh-empty dmdssh-error">${esc(e.message)}</div>`;}};w.querySelector('[data-float-refresh]').onclick=go;go();}

    function decorate(scope){const h=hub();try{if(h?.decorate)h.decorate(scope);else if(h?.scan)h.scan(scope);}catch(_){} }
    let provider=false;function registerProvider(){if(provider||!state.permissions.actionhub_use)return;const h=hub();if(!h||typeof h.registerProvider!=='function')return;try{h.registerProvider({id:'DMD-Ssh',getResources:()=>state.connections.map(c=>({resource:context(c),last_seen:c.last_test_at?Date.parse(c.last_test_at)||0:0}))});provider=true;}catch(_){} }
    function actionEvent(ev){const d=ev.detail||{},ui=d.ui||(d.result&&d.result.data&&d.result.data.ui)||{},mod=String(d.module||d.action?.module||d.context?.source||'').toLowerCase();if(mod!=='dmd-ssh'||String(ui.type||'')!=='open_ssh')return;const id=String(ui.connection_id||'');if(!conn(id))return;mode==='mydesk'?openMydeskTerminal(id):openFloatingTerminal(id);}
    document.addEventListener('dmd:actionhub-ui-action',actionEvent);document.addEventListener('dmd:actionhub-action-complete',actionEvent);try{const h=host();if(h.doc!==document){h.doc.addEventListener('dmd:actionhub-ui-action',actionEvent);h.doc.addEventListener('dmd:actionhub-action-complete',actionEvent);}}catch(_){}

    root.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const a=b.dataset.action;if(a==='refresh'){load();return;}if(a==='config'){openConfig();return;}if(a==='logs'){openLogs();return;}if(a==='home'&&mode==='mydesk'){showMy('list');renderTabs();return;}if(b.dataset.open){mode==='mydesk'?openMydeskTerminal(b.dataset.open):openFloatingTerminal(b.dataset.open);return;}if(b.dataset.test){testConnection(b.dataset.test);return;}if(b.dataset.qs){quickSession(b.dataset.qs);return;}if(b.dataset.ah){openHub(b.dataset.ah);return;}if(b.dataset.edit){openConfig(b.dataset.edit);return;}if(b.dataset.sessionTab){activateMydeskSession(b.dataset.sessionTab);return;}if(b.dataset.sessionX){e.stopPropagation();closeMydeskSession(b.dataset.sessionX);return;}});
    if(tabsEl)tabsEl.addEventListener('click',e=>{const x=e.target.closest('[data-session-x]');if(x){e.stopPropagation();closeMydeskSession(x.dataset.sessionX);return;}const b=e.target.closest('[data-session-tab]');if(b)activateMydeskSession(b.dataset.sessionTab);});
    window.addEventListener('pagehide',()=>{for(const s of sessions.values()){const token=s.terminal?.token;if(token)request(termApi,'close',{token,source},'POST',true).catch(()=>{});}});
    load();
}

document.querySelectorAll('.dmdssh-app:not([data-dmdssh-ready="1"])').forEach(init);
})();
