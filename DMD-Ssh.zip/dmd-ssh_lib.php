<?php
declare(strict_types=1);

if (!defined('DMD_SSH_ID')) define('DMD_SSH_ID', 'DMD-Ssh');
if (!defined('DMD_SSH_VERSION')) define('DMD_SSH_VERSION', '1.3.0');

function dmd_ssh_root(): string {
    $root = realpath(__DIR__ . '/../..');
    return $root !== false ? $root : dirname(__DIR__, 2);
}

function dmd_ssh_boot_core(): void {
    static $done = false;
    if ($done) return;
    $done = true;
    $root = dmd_ssh_root();
    foreach (array(
        $root . '/core/dmd_permissions.php',
        $root . '/core/dmd_system_services.php',
        $root . '/core/dmd_activity.php',
        $root . '/core/dmd_module_logs.php',
        $root . '/core/dmd_module_events.php',
        $root . '/Quick-Session/dmd_quick_session.php',
        $root . '/core/dmd_quick_session.php'
    ) as $file) {
        if (is_file($file)) require_once $file;
    }
}

function dmd_ssh_email(): string {
    return trim((string)($_SESSION['user']['email'] ?? $_SESSION['email'] ?? $_SESSION['user_email'] ?? ''));
}

function dmd_ssh_is_admin(string $email = ''): bool {
    if ($email === '') $email = dmd_ssh_email();
    dmd_ssh_boot_core();
    foreach (array('dmd_current_user_is_superadmin','dmd_is_superadmin') as $fn) {
        if (function_exists($fn)) {
            try { return (bool)$fn(); } catch (Throwable $e) {}
        }
    }
    $role = strtolower((string)($_SESSION['user']['role_system'] ?? $_SESSION['role_system'] ?? $_SESSION['user']['role'] ?? $_SESSION['role'] ?? ''));
    return in_array($role, array('superadmin','admin','administrator'), true);
}

function dmd_ssh_has_permission(string $permission, string $email = ''): bool {
    if ($email === '') $email = dmd_ssh_email();
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return false;
    dmd_ssh_boot_core();

    // Un superadmin/admin DoMyDesk conserve tous les droits du module.
    if (dmd_ssh_is_admin($email)) return true;

    if (function_exists('dmd_current_user_has_module_permission') && $email === dmd_ssh_email()) {
        try { return (bool)dmd_current_user_has_module_permission(DMD_SSH_ID, $permission); } catch (Throwable $e) {}
    }
    if (function_exists('dmd_user_has_module_permission')) {
        try { return (bool)dmd_user_has_module_permission($email, DMD_SSH_ID, $permission); } catch (Throwable $e) {}
    }
    return false;
}

function dmd_ssh_require_permission(string $permission): void {
    if (!dmd_ssh_has_permission($permission)) dmd_ssh_reply(array('ok'=>false,'message'=>'Accès refusé.','permission'=>$permission), 403);
}

function dmd_ssh_profiles_root(): string {
    return dmd_ssh_root() . '/users/profiles';
}

function dmd_ssh_profile_dir(string $email): string {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) throw new InvalidArgumentException('Utilisateur invalide.');
    $base = dmd_ssh_profiles_root();
    $candidate = $base . DIRECTORY_SEPARATOR . $email;
    if (!is_dir($candidate)) throw new RuntimeException('Profil utilisateur introuvable.');
    $realBase = realpath($base);
    $realCandidate = realpath($candidate);
    if ($realBase === false || $realCandidate === false || strpos(str_replace('\\','/',$realCandidate), rtrim(str_replace('\\','/',$realBase), '/') . '/') !== 0) {
        throw new RuntimeException('Profil utilisateur invalide.');
    }
    return $realCandidate;
}

function dmd_ssh_protect_dir(string $dir): void {
    if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) throw new RuntimeException('Impossible de créer le stockage DMD-Ssh.');
    @chmod($dir, 0770);
    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) @file_put_contents($ht, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n", LOCK_EX);
    $idx = $dir . '/index.php';
    if (!is_file($idx)) @file_put_contents($idx, "<?php http_response_code(404); exit;\n", LOCK_EX);
}

function dmd_ssh_user_dir(string $email = ''): string {
    if ($email === '') $email = dmd_ssh_email();
    $dir = dmd_ssh_profile_dir($email) . '/' . DMD_SSH_ID;
    dmd_ssh_prepare_storage($email, $dir);
    return $dir;
}

function dmd_ssh_legacy_dirs(): array {
    return array_values(array_unique(array(
        dmd_ssh_root() . '/data/modules/DMD-Ssh',
        dmd_ssh_root() . '/data/modules/dmd-ssh'
    )));
}

function dmd_ssh_migrate_legacy_user(string $email, string $userDir): void {
    $marker = $userDir . '/.migration-1.1.0';
    if (is_file($marker)) return;
    $connectionsDir = $userDir . '/connections';
    $hasUserConnections = count(glob($connectionsDir . '/*.json') ?: array()) > 0;
    foreach (dmd_ssh_legacy_dirs() as $legacy) {
        if (!is_dir($legacy)) continue;
        $owned = array();
        foreach (glob($legacy . '/connections/*.json') ?: array() as $file) {
            $row = dmd_ssh_read_json($file);
            if (!$row) continue;
            $creator = strtolower(trim((string)($row['created_by'] ?? '')));
            $updater = strtolower(trim((string)($row['updated_by'] ?? '')));
            if ($creator === strtolower($email) || $updater === strtolower($email)) $owned[] = array($file, $row);
        }
        if (!$hasUserConnections && $owned) {
            $legacyKey = $legacy . '/secrets/module.key';
            $userKey = $userDir . '/secrets/module.key';
            if (is_file($legacyKey) && !is_file($userKey)) @copy($legacyKey, $userKey);
            foreach ($owned as [$file, $row]) {
                $id = dmd_ssh_slug($row['id'] ?? pathinfo($file, PATHINFO_FILENAME));
                if ($id === '') continue;
                $row['migrated_to_user_storage_at'] = date(DATE_ATOM);
                dmd_ssh_write_json($connectionsDir . '/' . $id . '.json', $row);
            }
            $hasUserConnections = true;
        }
    }
    @file_put_contents($marker, date(DATE_ATOM) . "\n", LOCK_EX);
    @chmod($marker, 0640);
}

function dmd_ssh_prepare_storage(string $email = '', ?string $knownUserDir = null): void {
    if ($email === '') $email = dmd_ssh_email();
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) throw new RuntimeException('Utilisateur DMD-Ssh invalide.');
    $dir = $knownUserDir ?? (dmd_ssh_profile_dir($email) . '/' . DMD_SSH_ID);
    dmd_ssh_protect_dir($dir);
    foreach (array('connections','secrets','logs','tmp','sessions') as $name) dmd_ssh_protect_dir($dir . '/' . $name);
    dmd_ssh_migrate_legacy_user($email, $dir);
    $key = $dir . '/secrets/module.key';
    if (!is_file($key)) {
        if (@file_put_contents($key, base64_encode(random_bytes(32)) . "\n", LOCK_EX) === false) throw new RuntimeException('Impossible de créer la clé de chiffrement DMD-Ssh.');
        @chmod($key, 0600);
    }
}

function dmd_ssh_atomic_write(string $path, string $data, int $mode = 0640): bool {
    $dir = dirname($path);
    dmd_ssh_protect_dir($dir);
    $tmp = tempnam($dir, '.dmdssh-');
    if ($tmp === false) return false;
    try {
        if (@file_put_contents($tmp, $data, LOCK_EX) === false) return false;
        @chmod($tmp, $mode);
        if (!@rename($tmp, $path)) {
            if (!@copy($tmp, $path)) return false;
            @unlink($tmp);
        }
        @chmod($path, $mode);
        return true;
    } finally {
        if (is_file($tmp)) @unlink($tmp);
    }
}

function dmd_ssh_read_json(string $path, array $fallback = array()): array {
    if (!is_file($path)) return $fallback;
    $raw = @file_get_contents($path);
    if (!is_string($raw) || trim($raw) === '') return $fallback;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
}

function dmd_ssh_write_json(string $path, array $data): bool {
    $json = json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    return is_string($json) && dmd_ssh_atomic_write($path, $json . "\n", 0600);
}

function dmd_ssh_clean($value, int $max = 240): string {
    $v = trim(is_scalar($value) ? (string)$value : '');
    return function_exists('mb_substr') ? mb_substr($v, 0, $max, 'UTF-8') : substr($v, 0, $max);
}

function dmd_ssh_slug($value): string {
    $v = strtolower(dmd_ssh_clean($value, 80));
    return preg_match('/^[a-z0-9][a-z0-9_-]{0,79}$/D', $v) ? $v : '';
}

function dmd_ssh_valid_host(string $host): bool {
    if ($host === '' || strlen($host) > 253 || preg_match('/[\s\x00-\x1F\x7F]/', $host)) return false;
    if (filter_var($host, FILTER_VALIDATE_IP) !== false) return true;
    return (bool)preg_match('/^(?=.{1,253}$)(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/D', $host);
}

function dmd_ssh_valid_username(string $username): bool {
    return $username !== '' && strlen($username) <= 120 && !preg_match('/[\s\x00-\x1F\x7F@]/', $username);
}

function dmd_ssh_key(string $email = ''): string {
    $dir = dmd_ssh_user_dir($email);
    $raw = trim((string)@file_get_contents($dir . '/secrets/module.key'));
    $key = base64_decode($raw, true);
    if (!is_string($key) || strlen($key) !== 32) throw new RuntimeException('Clé de chiffrement DMD-Ssh invalide.');
    return $key;
}

function dmd_ssh_encrypt(string $plain, string $email = ''): string {
    $key = dmd_ssh_key($email);
    if (function_exists('sodium_crypto_secretbox')) {
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return 'sodium:' . base64_encode($nonce . sodium_crypto_secretbox($plain, $nonce, $key));
    }
    if (function_exists('openssl_encrypt')) {
        $iv = random_bytes(12); $tag = '';
        $ct = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, DMD_SSH_ID);
        if ($ct === false) throw new RuntimeException('Chiffrement OpenSSL impossible.');
        return 'gcm:' . base64_encode($iv . $tag . $ct);
    }
    throw new RuntimeException('Aucun moteur de chiffrement sécurisé disponible.');
}

function dmd_ssh_decrypt(string $encoded, string $email = ''): string {
    $key = dmd_ssh_key($email);
    if (str_starts_with($encoded, 'sodium:')) {
        $raw = base64_decode(substr($encoded, 7), true);
        if (!is_string($raw) || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) throw new RuntimeException('Secret chiffré invalide.');
        $nonce = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $plain = sodium_crypto_secretbox_open(substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $nonce, $key);
        if ($plain === false) throw new RuntimeException('Secret DMD-Ssh illisible.');
        return $plain;
    }
    if (str_starts_with($encoded, 'gcm:')) {
        $raw = base64_decode(substr($encoded, 4), true);
        if (!is_string($raw) || strlen($raw) <= 28) throw new RuntimeException('Secret chiffré invalide.');
        $iv=substr($raw,0,12); $tag=substr($raw,12,16); $ct=substr($raw,28);
        $plain=openssl_decrypt($ct,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag,DMD_SSH_ID);
        if ($plain === false) throw new RuntimeException('Secret DMD-Ssh illisible.');
        return $plain;
    }
    throw new RuntimeException('Format de secret DMD-Ssh inconnu.');
}

function dmd_ssh_connection_file(string $id, string $email = ''): string {
    return dmd_ssh_user_dir($email) . '/connections/' . $id . '.json';
}

function dmd_ssh_connection_public(array $c): array {
    return array(
        'id'=>(string)($c['id']??''), 'name'=>(string)($c['name']??''), 'host'=>(string)($c['host']??''),
        'port'=>(int)($c['port']??22), 'username'=>(string)($c['username']??''), 'auth_type'=>(string)($c['auth_type']??'agent'),
        'tags'=>array_values((array)($c['tags']??array())), 'notes'=>(string)($c['notes']??''),
        'last_test_at'=>(string)($c['last_test_at']??''), 'last_test_status'=>(string)($c['last_test_status']??''),
        'last_test_message'=>(string)($c['last_test_message']??''),
        'has_password'=>!empty($c['password_enc']), 'has_private_key'=>!empty($c['private_key_enc']),
        'created_at'=>(string)($c['created_at']??''), 'updated_at'=>(string)($c['updated_at']??'')
    );
}

function dmd_ssh_list_connections(string $email = ''): array {
    if ($email === '') $email=dmd_ssh_email();
    $out=array();
    foreach(glob(dmd_ssh_user_dir($email).'/connections/*.json')?:array() as $file){
        $c=dmd_ssh_read_json($file); if(!$c)continue; $out[]=dmd_ssh_connection_public($c);
    }
    usort($out,static fn($a,$b)=>strcasecmp((string)($a['name']??''),(string)($b['name']??'')));
    return $out;
}

function dmd_ssh_get_connection(string $id, string $email = '', bool $requireAccess = true): ?array {
    if ($email==='')$email=dmd_ssh_email();
    $id=dmd_ssh_slug($id); if($id==='')return null;
    $c=dmd_ssh_read_json(dmd_ssh_connection_file($id,$email));
    return $c ?: null;
}

function dmd_ssh_can_access_connection(array $c, string $email): bool { return filter_var($email,FILTER_VALIDATE_EMAIL)!==false; }

function dmd_ssh_resource(array $c): array {
    $id=(string)($c['id']??''); $name=dmd_ssh_clean($c['name']??$id,120);
    return array('id'=>DMD_SSH_ID.':connection:'.$id,'type'=>'ssh_connection','local_id'=>$id,'name'=>$name,'label'=>$name,'module'=>DMD_SSH_ID,'source'=>DMD_SSH_ID,'tags'=>array_merge(array('ssh'),array_values((array)($c['tags']??array()))));
}

function dmd_ssh_binary_optional(string $name): string {
    if (!preg_match('/^[A-Za-z0-9._+\-]+$/', $name)) return '';
    $dirs = array('/usr/bin','/bin','/usr/local/bin','/usr/sbin','/sbin','/opt/bin','/opt/sbin');
    $pathEnv = (string)getenv('PATH');
    if ($pathEnv !== '') {
        foreach (explode(PATH_SEPARATOR, $pathEnv) as $dir) {
            $dir = rtrim(trim($dir), '/');
            if ($dir !== '' && !in_array($dir, $dirs, true)) $dirs[] = $dir;
        }
    }
    foreach ($dirs as $dir) {
        $path = $dir . '/' . $name;
        if (is_file($path) && is_executable($path)) return $path;
    }
    return '';
}

function dmd_ssh_binary(string $name): string {
    $path = dmd_ssh_binary_optional($name);
    if ($path !== '') return $path;
    throw new RuntimeException('Binaire requis absent : ' . $name . '.');
}

function dmd_ssh_redact_command(string $command): string {
    $value = dmd_ssh_clean($command, 500);
    $value = preg_replace('/((?:pass(?:word)?|passwd|token|secret|api[_-]?key)\s*[=:]\s*)([^\s;&|]+)/i', '$1***', $value);
    $value = preg_replace('/(--(?:password|token|secret|api-key)(?:=|\s+))([^\s;&|]+)/i', '$1***', $value);
    return is_string($value) ? $value : '[commande masquée]';
}

function dmd_ssh_is_privileged_command(string $command): bool {
    return (bool)preg_match('/(^|[;&|]\s*|\b)(sudo|su\b|reboot\b|shutdown\b|poweroff\b|halt\b|mkfs\b|fdisk\b|parted\b|dd\s+if=|rm\s+-rf\s+\/)/i',$command);
}

function dmd_ssh_temp_file(string $prefix, string $content, int $mode, string $email = '', bool $executable = false): string {
    $dirs = array();
    if ($executable) {
        $systemTmp = rtrim((string)sys_get_temp_dir(), DIRECTORY_SEPARATOR);
        if ($systemTmp !== '' && is_dir($systemTmp) && is_writable($systemTmp)) $dirs[] = $systemTmp;
        if (is_dir('/tmp') && is_writable('/tmp') && !in_array('/tmp', $dirs, true)) $dirs[] = '/tmp';
    }
    try { $dirs[] = dmd_ssh_user_dir($email) . '/tmp'; } catch (Throwable $e) {}
    foreach ($dirs as $dir) {
        if (!is_dir($dir) || !is_writable($dir)) continue;
        $path = @tempnam($dir, $prefix);
        if ($path === false) continue;
        if (@file_put_contents($path, $content, LOCK_EX) === false) { @unlink($path); continue; }
        @chmod($path, $mode);
        if (!$executable || is_executable($path)) return $path;
        @unlink($path);
    }
    throw new RuntimeException($executable ? 'Impossible de créer le helper SSH temporaire exécutable.' : 'Impossible de créer un fichier SSH temporaire.');
}

function dmd_ssh_process_env(): array {
    $base = getenv();
    if (!is_array($base)) $base = array();
    foreach ($_ENV as $k => $v) if (is_string($k) && is_scalar($v)) $base[$k] = (string)$v;
    $base['LANG'] = 'C';
    $base['LC_ALL'] = 'C';
    return $base;
}

function dmd_ssh_setsid_prefix(): string {
    $setsid = dmd_ssh_binary_optional('setsid');
    if ($setsid !== '') return escapeshellarg($setsid) . ' -w ';
    $busybox = dmd_ssh_binary_optional('busybox');
    if ($busybox !== '') return escapeshellarg($busybox) . ' setsid ';
    return '';
}

function dmd_ssh_http_host(): string {
    $raw = trim((string)($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? ''));
    if ($raw === '') return '';
    if ($raw[0] === '[') {
        $end = strpos($raw, ']');
        if ($end !== false) return substr($raw, 1, $end - 1);
    }
    if (substr_count($raw, ':') === 1) return preg_replace('/:\d+$/', '', $raw) ?: $raw;
    return $raw;
}

function dmd_ssh_host_ips(string $host): array {
    $host = trim($host, "[] \t\r\n");
    if ($host === '') return array();
    if (filter_var($host, FILTER_VALIDATE_IP)) return array($host);
    $out = array();
    $v4 = @gethostbynamel($host);
    if (is_array($v4)) foreach ($v4 as $ip) if (filter_var($ip, FILTER_VALIDATE_IP) && !in_array($ip, $out, true)) $out[] = $ip;
    if (function_exists('dns_get_record')) {
        $aaaa = @dns_get_record($host, DNS_AAAA);
        if (is_array($aaaa)) foreach ($aaaa as $row) { $ip = (string)($row['ipv6'] ?? ''); if (filter_var($ip, FILTER_VALIDATE_IP) && !in_array($ip, $out, true)) $out[] = $ip; }
    }
    return $out;
}

function dmd_ssh_local_addresses(): array {
    $out = array('127.0.0.1', '::1');
    foreach (array((string)($_SERVER['SERVER_ADDR'] ?? ''), (string)gethostbyname((string)gethostname())) as $ip) {
        $ip = trim($ip, "[] \t\r\n");
        if (filter_var($ip, FILTER_VALIDATE_IP) && !in_array($ip, $out, true)) $out[] = $ip;
    }
    $hostname = trim((string)gethostname());
    if ($hostname !== '') foreach (dmd_ssh_host_ips($hostname) as $ip) if (!in_array($ip, $out, true)) $out[] = $ip;
    $httpHost = dmd_ssh_http_host();
    if ($httpHost !== '') foreach (dmd_ssh_host_ips($httpHost) as $ip) if (!in_array($ip, $out, true)) $out[] = $ip;
    return $out;
}

function dmd_ssh_target_is_local(string $host): bool {
    $host = trim($host, "[] \t\r\n");
    if ($host === '') return false;
    if (in_array(strtolower($host), array('localhost','localhost.localdomain'), true)) return true;
    $httpHost = dmd_ssh_http_host();
    if ($httpHost !== '' && strcasecmp($host, $httpHost) === 0) return true;
    $local = dmd_ssh_local_addresses();
    foreach (dmd_ssh_host_ips($host) as $ip) if (in_array($ip, $local, true)) return true;
    return false;
}

function dmd_ssh_target_candidates(array $c): array {
    $host = trim((string)($c['host'] ?? ''));
    return $host === '' ? array() : array($host);
}

function dmd_ssh_transport_failure(array $result): bool {
    if (!empty($result['ok'])) return false;
    $text = strtolower((string)($result['stderr'] ?? '') . "\n" . (string)($result['stdout'] ?? ''));
    foreach (array('connection refused','no route to host','network is unreachable','connection timed out','operation timed out','connection reset by peer','could not resolve hostname') as $needle) {
        if (strpos($text, $needle) !== false) return true;
    }
    return false;
}


function dmd_ssh_known_hosts_file(string $email = ''): string {
    if ($email === '') $email = dmd_ssh_email();
    $file = dmd_ssh_user_dir($email) . '/secrets/known_hosts';
    if (!is_file($file)) {
        if (@file_put_contents($file, '', LOCK_EX) === false) throw new RuntimeException('Impossible de préparer les identités SSH connues.');
    }
    @chmod($file, 0600);
    return $file;
}

function dmd_ssh_hostkey_changed_message(string $text): bool {
    $t = strtolower($text);
    return strpos($t, 'remote host identification has changed') !== false
        || strpos($t, 'host key verification failed') !== false
        || strpos($t, 'offending ') !== false && strpos($t, 'known_hosts') !== false;
}

function dmd_ssh_hostkey_tokens(array $c): array {
    $host = trim((string)($c['host'] ?? ''), "[] \t\r\n");
    $port = (int)($c['port'] ?? 22);
    if ($host === '') return array();
    $tokens = array($host);
    $bracket = '[' . $host . ']:' . $port;
    if (!in_array($bracket, $tokens, true)) $tokens[] = $bracket;
    return $tokens;
}

function dmd_ssh_forget_hostkey(array $c, string $email): void {
    $file = dmd_ssh_known_hosts_file($email);
    $tokens = dmd_ssh_hostkey_tokens($c);
    if (!$tokens) throw new RuntimeException('Hôte SSH invalide.');
    $keygen = dmd_ssh_binary_optional('ssh-keygen');
    if ($keygen !== '') {
        foreach ($tokens as $token) {
            $cmd = escapeshellarg($keygen) . ' -q -R ' . escapeshellarg($token) . ' -f ' . escapeshellarg($file) . ' 2>/dev/null';
            @exec($cmd, $out, $rc);
        }
    } else {
        $lines = @file($file, FILE_IGNORE_NEW_LINES);
        if (is_array($lines)) {
            $keep = array();
            foreach ($lines as $line) {
                $first = preg_split('/\s+/', trim($line), 2)[0] ?? '';
                $names = $first !== '' ? explode(',', $first) : array();
                $drop = false;
                foreach ($tokens as $token) if (in_array($token, $names, true)) { $drop = true; break; }
                if (!$drop) $keep[] = $line;
            }
            dmd_ssh_atomic_write($file, $keep ? implode("\n", $keep) . "\n" : '', 0600);
        }
    }
    @chmod($file, 0600);
}

function dmd_ssh_terminal_ssh_wrapper(string $realSsh, string $email, string $dir): string {
    $known = dmd_ssh_known_hosts_file($email);
    $wrapper = $dir . '/ssh-wrapper.sh';
    $script = "#!/bin/sh\nexec " . escapeshellarg($realSsh)
        . " -o StrictHostKeyChecking=accept-new"
        . " -o UserKnownHostsFile=" . escapeshellarg($known)
        . " -o HashKnownHosts=no \"\$@\"\n";
    if (@file_put_contents($wrapper, $script, LOCK_EX) === false) throw new RuntimeException('Impossible de préparer la vérification d’identité SSH.');
    @chmod($wrapper, 0700);
    return $wrapper;
}

function dmd_ssh_build_command(array $c, string $remoteCommand, array &$tempFiles, array &$env, string $email = '', ?string $targetHost = null): string {
    $ssh = dmd_ssh_binary('ssh');
    $host = $targetHost !== null && $targetHost !== '' ? $targetHost : (string)$c['host'];
    $port = (int)($c['port'] ?? 22);
    $user = (string)$c['username'];
    $parts = array(
        escapeshellarg($ssh), '-T', '-p', (string)$port,
        '-o', 'BatchMode=no',
        '-o', 'ConnectTimeout=10',
        '-o', 'ServerAliveInterval=10',
        '-o', 'ServerAliveCountMax=2',
        '-o', 'StrictHostKeyChecking=accept-new',
        '-o', 'UserKnownHostsFile=' . dmd_ssh_known_hosts_file($email),
        '-o', 'HashKnownHosts=no',
        '-o', 'LogLevel=ERROR',
        '-o', 'NumberOfPasswordPrompts=1'
    );
    $auth = (string)($c['auth_type'] ?? 'agent');
    $prefix = '';
    if ($auth === 'password') {
        if (empty($c['password_enc'])) throw new RuntimeException('Mot de passe SSH non enregistré.');
        $password = dmd_ssh_decrypt((string)$c['password_enc'], $email);
        $sshpass = dmd_ssh_binary_optional('sshpass');
        if ($sshpass !== '') {
            $env['SSHPASS'] = $password;
            $prefix = escapeshellarg($sshpass) . ' -e ';
        } else {
            $prefix = dmd_ssh_setsid_prefix();
            if ($prefix === '') throw new RuntimeException('Authentification SSH par mot de passe impossible : ni sshpass ni setsid/busybox disponibles sur le serveur DoMyDesk.');
            $ask = dmd_ssh_temp_file('dmdssh-ask-', "#!/bin/sh\nprintf '%s\\n' \"\$DMD_SSH_PASSWORD\"\n", 0700, $email, true);
            $tempFiles[] = $ask;
            $env['DMD_SSH_PASSWORD'] = $password;
            $env['SSH_ASKPASS'] = $ask;
            $env['SSH_ASKPASS_REQUIRE'] = 'force';
            $env['DISPLAY'] = ':0';
            unset($env['SSH_AUTH_SOCK']);
        }
        $parts[] = '-o'; $parts[] = 'PreferredAuthentications=password,keyboard-interactive';
        $parts[] = '-o'; $parts[] = 'PubkeyAuthentication=no';
    } elseif ($auth === 'private_key') {
        if (empty($c['private_key_enc'])) throw new RuntimeException('Clé privée SSH non enregistrée.');
        $keyFile = dmd_ssh_temp_file('key-', rtrim(dmd_ssh_decrypt((string)$c['private_key_enc'], $email), "\r\n") . "\n", 0600, $email);
        $tempFiles[] = $keyFile;
        $parts[] = '-i'; $parts[] = escapeshellarg($keyFile);
        $parts[] = '-o'; $parts[] = 'IdentitiesOnly=yes';
        if (!empty($c['passphrase_enc'])) {
            $prefix = dmd_ssh_setsid_prefix();
            if ($prefix === '') throw new RuntimeException('Clé privée protégée impossible à utiliser : ni setsid ni busybox disponibles sur le serveur DoMyDesk.');
            $ask = dmd_ssh_temp_file('dmdssh-ask-', "#!/bin/sh\nprintf '%s\\n' \"\$DMD_SSH_PASSPHRASE\"\n", 0700, $email, true);
            $tempFiles[] = $ask;
            $env['DMD_SSH_PASSPHRASE'] = dmd_ssh_decrypt((string)$c['passphrase_enc'], $email);
            $env['SSH_ASKPASS'] = $ask;
            $env['SSH_ASKPASS_REQUIRE'] = 'force';
            $env['DISPLAY'] = ':0';
        }
    }
    $parts[] = '-l'; $parts[] = escapeshellarg($user);
    $parts[] = escapeshellarg($host);
    $parts[] = escapeshellarg($remoteCommand);
    return $prefix . implode(' ', $parts);
}

function dmd_ssh_run_once(array $c, string $command, string $email, int $timeout, string $targetHost): array {
    $tempFiles = array();
    $env = dmd_ssh_process_env();
    $cmd = dmd_ssh_build_command($c, $command, $tempFiles, $env, $email, $targetHost);
    $start = microtime(true); $out = ''; $err = ''; $code = 255; $timedOut = false;
    try {
        $proc = proc_open($cmd, array(0=>array('pipe','r'),1=>array('pipe','w'),2=>array('pipe','w')), $pipes, null, $env);
        if (!is_resource($proc)) throw new RuntimeException('Impossible de lancer SSH.');
        fclose($pipes[0]); stream_set_blocking($pipes[1], false); stream_set_blocking($pipes[2], false);
        while (true) {
            $status = proc_get_status($proc);
            $out .= (string)stream_get_contents($pipes[1]); $err .= (string)stream_get_contents($pipes[2]);
            if (!$status['running']) { $code = (int)$status['exitcode']; break; }
            if ((microtime(true) - $start) > $timeout) {
                $timedOut = true; proc_terminate($proc, 15); usleep(150000); $s2 = proc_get_status($proc); if ($s2['running']) proc_terminate($proc, 9); break;
            }
            usleep(50000);
        }
        $out .= (string)stream_get_contents($pipes[1]); $err .= (string)stream_get_contents($pipes[2]);
        fclose($pipes[1]); fclose($pipes[2]); $close = proc_close($proc); if ($code < 0) $code = (int)$close; if ($timedOut) $code = 124;
    } finally { foreach ($tempFiles as $file) @unlink($file); }
    return array(
        'ok'=>$code===0, 'exit_code'=>$code, 'stdout'=>$out, 'stderr'=>$err,
        'timed_out'=>$timedOut, 'duration_ms'=>(int)round((microtime(true)-$start)*1000),
        'transport_host'=>$targetHost
    );
}

function dmd_ssh_execute(array $c, string $command, string $email, int $timeout = 30, string $logAction = 'command.execute', string $source = 'module'): array {
    $command = trim($command); if ($command === '') throw new InvalidArgumentException('Commande vide.');
    if (strlen($command) > 8000) throw new InvalidArgumentException('Commande trop longue.');
    if (dmd_ssh_is_privileged_command($command) && !dmd_ssh_has_permission('terminal.privileged', $email)) throw new RuntimeException('Commande privilégiée refusée par les droits DMD-Ssh.');
    $timeout = max(3, min(180, $timeout));
    $candidates = dmd_ssh_target_candidates($c); if (!$candidates) throw new RuntimeException('Hôte SSH invalide.');
    $result = null; $attempted = array();
    foreach ($candidates as $index => $targetHost) {
        $attempted[] = $targetHost;
        $result = dmd_ssh_run_once($c, $command, $email, $timeout, $targetHost);
        if (!empty($result['ok'])) break;
        // On ne change de cible que pour une panne de transport. Une erreur de
        // mot de passe/clé reste renvoyée telle quelle et n'est jamais masquée.
        if (!dmd_ssh_transport_failure($result)) break;
    }
    if (!is_array($result)) throw new RuntimeException('Impossible de lancer SSH.');
    $result['transport_fallback'] = count($attempted) > 1 && (string)($result['transport_host'] ?? '') !== (string)($c['host'] ?? '');
    $result['attempted_hosts'] = $attempted;
    dmd_ssh_log($logAction, $c, $email, $result['ok'] ? 'success' : 'error', array(
        'command'=>dmd_ssh_redact_command($command), 'exit_code'=>$result['exit_code'],
        'duration_ms'=>$result['duration_ms'], 'timed_out'=>$result['timed_out'],
        'transport_host'=>(string)($result['transport_host'] ?? '')
    ), dmd_ssh_resource($c), $source);
    return $result;
}

function dmd_ssh_test(array $c, string $email, string $source = 'module'): array {
    return dmd_ssh_execute($c,'printf DMD_SSH_OK',$email,15,'connection.test',$source);
}

function dmd_ssh_log(string $action, array $c, string $email, string $status, array $details = array(), ?array $resource = null, string $source = 'module'): void {
    $safe=$details;foreach(array('password','passphrase','private_key','secret','token') as $key)unset($safe[$key]);
    $row=array('datetime'=>date(DATE_ATOM),'module'=>DMD_SSH_ID,'user'=>$email,'action'=>$action,'target'=>(string)($c['id']??''),'name'=>(string)($c['name']??''),'status'=>$status,'details'=>$safe,'resource'=>$resource,'source'=>$source);
    $path=dmd_ssh_user_dir($email).'/logs/'.date('Y-m').'.jsonl';dmd_ssh_protect_dir(dirname($path));@file_put_contents($path,json_encode($row,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n",FILE_APPEND|LOCK_EX);@chmod($path,0640);
    dmd_ssh_boot_core();
    if(function_exists('dmd_module_event')&&is_array($resource)){
        try{dmd_module_event(DMD_SSH_ID,$action,$resource,array('email'=>$email,'status'=>$status,'details'=>json_encode($safe,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),'meta'=>array('source'=>$source)));}catch(Throwable $e){}
    }
}

function dmd_ssh_recent_logs(string $email, int $limit = 100): array {
    $limit=max(1,min(500,$limit));$rows=array();$files=glob(dmd_ssh_user_dir($email).'/logs/*.jsonl')?:array();rsort($files,SORT_NATURAL);
    foreach($files as $file){$lines=@file($file,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES)?:array();for($i=count($lines)-1;$i>=0;$i--){$r=json_decode($lines[$i],true);if(is_array($r))$rows[]=$r;if(count($rows)>=$limit)break 2;}}
    return $rows;
}

function dmd_ssh_csrf(): string {
    if(empty($_SESSION['dmd_ssh_csrf'])||!is_string($_SESSION['dmd_ssh_csrf']))$_SESSION['dmd_ssh_csrf']=bin2hex(random_bytes(24));return $_SESSION['dmd_ssh_csrf'];
}

function dmd_ssh_check_csrf(): void {
    $sent=(string)($_SERVER['HTTP_X_DMD_CSRF']??'');if($sent===''||!hash_equals(dmd_ssh_csrf(),$sent))dmd_ssh_reply(array('ok'=>false,'message'=>'Jeton CSRF invalide.'),419);
}

function dmd_ssh_reply(array $data, int $status = 200): void {
    http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');header('X-Content-Type-Options: nosniff');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;
}

function dmd_ssh_module_web_path(): string {
    $documentRoot=realpath((string)($_SERVER['DOCUMENT_ROOT']??''));$moduleRealDir=realpath(__DIR__);
    if($documentRoot!==false&&$moduleRealDir!==false){$doc=rtrim(str_replace('\\','/',$documentRoot),'/');$mod=rtrim(str_replace('\\','/',$moduleRealDir),'/');if($doc!==''&&($mod===$doc||strpos($mod,$doc.'/')===0))return '/'.ltrim(substr($mod,strlen($doc)),'/');}
    $script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));$base=rtrim(str_replace('\\','/',dirname($script)),'/');if($base==='.'||$base==='/')$base='';return $base.'/modules/'.rawurlencode(basename(__DIR__));
}

function dmd_ssh_domydesk_web_root(): string {
    $module=dmd_ssh_module_web_path();$needle='/modules/'.rawurlencode(basename(__DIR__));$pos=strrpos($module,$needle);return $pos===false?'':substr($module,0,$pos);
}

function dmd_ssh_theme_name(string $email = ''): string {
    if($email==='')$email=dmd_ssh_email();$theme='default';
    try{$dir=dmd_ssh_profile_dir($email);foreach(array($dir.'/theme.json',$dir.'/profile/theme.json') as $file){if(!is_file($file))continue;$j=dmd_ssh_read_json($file);$candidate=(string)($j['theme']??$j['name']??'');if(preg_match('/^[A-Za-z0-9_-]+$/D',$candidate)){$theme=$candidate;break;}}}catch(Throwable $e){}
    return $theme;
}

function dmd_ssh_theme_web_url(string $email = ''): string {
    return rtrim(dmd_ssh_domydesk_web_root(),'/').'/theme/'.rawurlencode(dmd_ssh_theme_name($email)).'/style.css';
}


/* -------------------------------------------------------------------------
 * Terminal SSH persistant — backend PTY DMD-Ssh embarqué
 * ---------------------------------------------------------------------- */
function dmd_ssh_terminal_token($value): string {
    $v = strtolower(trim(is_scalar($value) ? (string)$value : ''));
    return preg_match('/^[a-f0-9]{32}$/D', $v) ? $v : '';
}

function dmd_ssh_terminal_session_dir(string $token, string $email = ''): string {
    $token = dmd_ssh_terminal_token($token);
    if ($token === '') throw new InvalidArgumentException('Session terminal invalide.');
    return dmd_ssh_user_dir($email) . '/sessions/' . $token;
}
function dmd_ssh_terminal_meta_file(string $token, string $email = ''): string { return dmd_ssh_terminal_session_dir($token,$email).'/meta.json'; }
function dmd_ssh_terminal_socket(string $token, string $email = ''): string {
    $token=dmd_ssh_terminal_token($token);
    if($token==='') throw new InvalidArgumentException('Session terminal invalide.');
    if($email==='') $email=dmd_ssh_email();
    // Les sockets UNIX Linux sont limitees a environ 108 octets.
    // Les chemins de profils DoMyDesk/Synology peuvent depasser cette limite,
    // donc la socket du PTY vit volontairement dans un chemin temporaire court.
    $base=rtrim(sys_get_temp_dir(),'/\\').DIRECTORY_SEPARATOR.'dmdssh-s';
    if(!is_dir($base) && !@mkdir($base,0700,true) && !is_dir($base))
        throw new RuntimeException('Impossible de creer le dossier temporaire du terminal SSH.');
    @chmod($base,0700);
    $name=substr(hash('sha256',strtolower($email).'|'.$token),0,32).'.sock';
    return $base.DIRECTORY_SEPARATOR.$name;
}
function dmd_ssh_terminal_unlink_socket(string $socket): void {
    if($socket!=='' && (file_exists($socket) || is_link($socket))) @unlink($socket);
}

function dmd_ssh_terminal_rm_tree(string $dir): void {
    if (!is_dir($dir)) return;
    $items = scandir($dir); if (!is_array($items)) return;
    foreach ($items as $item) { if ($item==='.'||$item==='..') continue; $path=$dir.DIRECTORY_SEPARATOR.$item; if (is_dir($path)&&!is_link($path)) dmd_ssh_terminal_rm_tree($path); else @unlink($path); }
    @rmdir($dir);
}

function dmd_ssh_terminal_meta(string $token, string $email = ''): array {
    if ($email==='') $email=dmd_ssh_email();
    $meta=dmd_ssh_read_json(dmd_ssh_terminal_meta_file($token,$email));
    if (!$meta || !hash_equals(strtolower((string)($meta['email']??'')),strtolower($email))) throw new RuntimeException('Session terminal introuvable.');
    return $meta;
}

function dmd_ssh_terminal_helper(): string {
    $machine=strtolower((string)php_uname('m'));
    if (in_array($machine,array('x86_64','amd64'),true)) $name='dmdssh-pty-linux-amd64';
    elseif (in_array($machine,array('aarch64','arm64'),true)) $name='dmdssh-pty-linux-arm64';
    elseif (preg_match('/^arm(v7|v7l|hf)/',$machine)) $name='dmdssh-pty-linux-armv7';
    elseif (in_array($machine,array('i386','i486','i586','i686','x86'),true)) $name='dmdssh-pty-linux-386';
    else throw new RuntimeException('Architecture Linux non prise en charge : '.$machine);

    $source=__DIR__.'/bin/'.$name;
    if (!is_file($source)) throw new RuntimeException('Backend PTY DMD-Ssh absent pour '.$machine.'.');

    // Ne dépend pas du droit d'exécution du dossier Web : le binaire statique est
    // copié dans un répertoire temporaire exécutable du système si nécessaire.
    $hash=substr(hash_file('sha256',$source) ?: md5($source),0,16);
    $dirs=array(sys_get_temp_dir(),'/tmp','/var/tmp');
    try { $dirs[]=dmd_ssh_user_dir().'/tmp'; } catch(Throwable $e) {}
    $dirs=array_values(array_unique(array_filter($dirs)));
    $errors=array();
    foreach($dirs as $tmp){
        if(!is_dir($tmp) || !is_writable($tmp)) continue;
        $dest=rtrim($tmp,'/\\').DIRECTORY_SEPARATOR.'dmdssh-pty-'.$hash.'-'.$name;
        if(!is_file($dest) || @filesize($dest)!==@filesize($source)){
            $part=$dest.'.'.bin2hex(random_bytes(4)).'.tmp';
            if(!@copy($source,$part)){ $errors[]=$tmp.': copie impossible'; continue; }
            @chmod($part,0755);
            if(!@rename($part,$dest)){ @unlink($part); $errors[]=$tmp.': installation impossible'; continue; }
        }
        @chmod($dest,0755);
        $o=array();$rc=1;
        @exec(escapeshellarg($dest).' --help >/dev/null 2>&1',$o,$rc);
        if($rc===0) return $dest;
        $errors[]=$tmp.': exécution refusée';
    }

    // Dernier essai direct depuis le module.
    @chmod($source,0755);
    $o=array();$rc=1;@exec(escapeshellarg($source).' --help >/dev/null 2>&1',$o,$rc);
    if($rc===0) return $source;
    throw new RuntimeException('Backend PTY impossible à exécuter sur ce serveur'.($errors?' ('.implode('; ',$errors).')':'').'.');
}

function dmd_ssh_terminal_http(string $socket, string $method, string $path, string $body='', int $timeout=5): array {
    $errno=0;$errstr='';
    $fp=@stream_socket_client('unix://'.$socket,$errno,$errstr,max(1,$timeout),STREAM_CLIENT_CONNECT);
    if (!$fp) throw new RuntimeException('Session terminal indisponible.');
    stream_set_timeout($fp,max(1,$timeout));
    $req=$method.' '.$path." HTTP/1.1\r\nHost: dmdssh\r\nConnection: close\r\nContent-Length: ".strlen($body)."\r\nContent-Type: application/octet-stream\r\n\r\n".$body;
    fwrite($fp,$req);$raw=(string)stream_get_contents($fp);fclose($fp);
    $pos=strpos($raw,"\r\n\r\n");$head=$pos===false?$raw:substr($raw,0,$pos);$payload=$pos===false?'':substr($raw,$pos+4);
    if (!preg_match('#HTTP/1\.[01]\s+(\d+)#',$head,$m) || (int)$m[1]>=400) throw new RuntimeException(trim($payload)!==''?trim($payload):'Erreur du terminal PTY.');
    return array('body'=>$payload,'headers'=>$head);
}

function dmd_ssh_terminal_wait_socket(string $socket, int $ms=5000, string $logFile=''): void {
    $end=microtime(true)+($ms/1000);
    do {
        if (file_exists($socket)) {
            try { dmd_ssh_terminal_http($socket,'GET','/read?offset=0','',1); return; } catch(Throwable $e) {}
        }
        usleep(50000);
    } while(microtime(true)<$end);
    $detail='';
    if ($logFile!=='' && is_file($logFile)) {
        $raw=@file_get_contents($logFile);
        if (is_string($raw)) $detail=trim(substr($raw,-4000));
    }
    throw new RuntimeException('Le terminal SSH n’a pas pu démarrer.'.($detail!==''?' Détail : '.$detail:''));
}

function dmd_ssh_terminal_cleanup(string $email='', int $maxAge=43200): void {
    if($email==='')$email=dmd_ssh_email();$root=dmd_ssh_user_dir($email).'/sessions';
    foreach(glob($root.'/*',GLOB_ONLYDIR)?:array() as $dir){$meta=dmd_ssh_read_json($dir.'/meta.json');$updated=(int)($meta['updated_ts']??$meta['created_ts']??@filemtime($dir)?:0);if($updated>0&&time()-$updated>$maxAge){$sock=(string)($meta['socket']??'');if($sock!==''){try{dmd_ssh_terminal_http($sock,'POST','/close','',1);}catch(Throwable $e){} dmd_ssh_terminal_unlink_socket($sock);}dmd_ssh_terminal_rm_tree($dir);}}
}

function dmd_ssh_terminal_start(array $c,string $email,int $cols=100,int $rows=30,string $source='module'): array {
    $ssh=dmd_ssh_binary('ssh');$helper=dmd_ssh_terminal_helper();dmd_ssh_terminal_cleanup($email);
    $cols=max(40,min(300,$cols));$rows=max(10,min(120,$rows));
    $host=(string)($c['host']??'');$port=(int)($c['port']??22);$user=(string)($c['username']??'');
    if(!dmd_ssh_valid_host($host)||!dmd_ssh_valid_username($user)||$port<1||$port>65535)throw new RuntimeException('Connexion SSH invalide.');
    $token=bin2hex(random_bytes(16));$dir=dmd_ssh_terminal_session_dir($token,$email);if(!@mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Impossible de créer la session terminal.');@chmod($dir,0700);
    $socket=dmd_ssh_terminal_socket($token,$email);dmd_ssh_terminal_unlink_socket($socket);$log=$dir.'/backend.log';
    $sshWrapper=dmd_ssh_terminal_ssh_wrapper($ssh,$email,$dir);
    $args=array($helper,'--socket',$socket,'--ssh',$sshWrapper,'--host',$host,'--port',(string)$port,'--user',$user,'--cols',(string)$cols,'--rows',(string)$rows);
    $auth=(string)($c['auth_type']??'agent');
    if($auth==='password'){
        if(empty($c['password_enc']))throw new RuntimeException('Mot de passe SSH non enregistré.');
        $secret=$dir.'/password.secret';if(@file_put_contents($secret,dmd_ssh_decrypt((string)$c['password_enc'],$email)."\n",LOCK_EX)===false)throw new RuntimeException('Impossible de préparer le mot de passe SSH.');@chmod($secret,0600);$args[]='--secret-file';$args[]=$secret;
    }elseif($auth==='private_key'){
        if(empty($c['private_key_enc']))throw new RuntimeException('Clé privée SSH non enregistrée.');
        $key=$dir.'/identity.key';if(@file_put_contents($key,rtrim(dmd_ssh_decrypt((string)$c['private_key_enc'],$email),"\r\n")."\n",LOCK_EX)===false)throw new RuntimeException('Impossible de préparer la clé privée SSH.');@chmod($key,0600);$args[]='--key';$args[]=$key;
        if(!empty($c['passphrase_enc'])){$pf=$dir.'/passphrase.secret';@file_put_contents($pf,dmd_ssh_decrypt((string)$c['passphrase_enc'],$email)."\n",LOCK_EX);@chmod($pf,0600);$args[]='--passphrase-file';$args[]=$pf;}
    }
    $parts=array();foreach($args as $a)$parts[]=escapeshellarg((string)$a);
    $cmd=implode(' ',$parts).' >>'.escapeshellarg($log).' 2>&1 < /dev/null & echo $!';
    $out=array();$rc=0;@exec($cmd,$out,$rc);
    if($rc!==0){$detail=is_file($log)?trim((string)@file_get_contents($log)):'';dmd_ssh_terminal_unlink_socket($socket);dmd_ssh_terminal_rm_tree($dir);throw new RuntimeException('Impossible de démarrer le terminal SSH.'.($detail!==''?' Détail : '.$detail:''));}
    try{dmd_ssh_terminal_wait_socket($socket,5000,$log);}catch(Throwable $e){$detail=is_file($log)?trim((string)@file_get_contents($log)):'';dmd_ssh_terminal_unlink_socket($socket);dmd_ssh_terminal_rm_tree($dir);throw new RuntimeException($detail!==''?'Le terminal SSH n’a pas pu démarrer : '.$detail:$e->getMessage());}
    $meta=array('token'=>$token,'email'=>$email,'connection_id'=>(string)$c['id'],'connection_name'=>(string)$c['name'],'host'=>$host,'port'=>$port,'username'=>$user,'socket'=>$socket,'backend_pid'=>(int)($out[0]??0),'created_at'=>date(DATE_ATOM),'created_ts'=>time(),'updated_ts'=>time(),'source'=>$source);
    dmd_ssh_write_json($dir.'/meta.json',$meta);dmd_ssh_log('terminal.open',$c,$email,'success',array('session'=>$token,'cols'=>$cols,'rows'=>$rows),dmd_ssh_resource($c),$source);
    return array('token'=>$token,'connection'=>dmd_ssh_connection_public($c),'cols'=>$cols,'rows'=>$rows);
}

function dmd_ssh_terminal_read(string $token,string $email,int $offset=0): array {
    $meta=dmd_ssh_terminal_meta($token,$email);$socket=(string)($meta['socket']??dmd_ssh_terminal_socket($token,$email));$offset=max(0,$offset);
    $r=dmd_ssh_terminal_http($socket,'GET','/read?offset='.$offset,'',3);$j=json_decode((string)$r['body'],true);if(!is_array($j))throw new RuntimeException('Réponse PTY invalide.');
    $dir=dmd_ssh_terminal_session_dir($token,$email);$meta['updated_ts']=time();dmd_ssh_write_json($dir.'/meta.json',$meta);
    return array('data_b64'=>(string)($j['data_b64']??''),'offset'=>(int)($j['offset']??$offset),'size'=>(int)($j['offset']??$offset),'state'=>array('running'=>empty($j['dead']),'dead'=>!empty($j['dead']),'exit_code'=>(int)($j['exit_code']??0),'command'=>'ssh'));
}
function dmd_ssh_terminal_input(string $token,string $email,string $data): void { if($data==='')return;if(strlen($data)>65536)throw new RuntimeException('Entrée terminal trop volumineuse.');$meta=dmd_ssh_terminal_meta($token,$email);dmd_ssh_terminal_http((string)$meta['socket'],'POST','/write',$data,3); }
function dmd_ssh_terminal_resize(string $token,string $email,int $cols,int $rows): void { $meta=dmd_ssh_terminal_meta($token,$email);$cols=max(40,min(300,$cols));$rows=max(10,min(120,$rows));dmd_ssh_terminal_http((string)$meta['socket'],'POST','/resize?cols='.$cols.'&rows='.$rows,'',3); }
function dmd_ssh_terminal_close(string $token,string $email,string $source='module'): void { $meta=dmd_ssh_terminal_meta($token,$email);$c=dmd_ssh_get_connection((string)$meta['connection_id'],$email,false);$socket=(string)($meta['socket']??'');try{if($socket!=='')dmd_ssh_terminal_http($socket,'POST','/close','',2);}catch(Throwable $e){}usleep(150000);dmd_ssh_terminal_unlink_socket($socket);dmd_ssh_terminal_rm_tree(dmd_ssh_terminal_session_dir($token,$email));if($c)dmd_ssh_log('terminal.close',$c,$email,'success',array('session'=>$token),dmd_ssh_resource($c),$source); }
