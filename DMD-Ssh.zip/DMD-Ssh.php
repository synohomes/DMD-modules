<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ssh_lib.php';

$email = dmd_ssh_email();
if ($email === '') { echo '<div class="dmdssh-denied">Connexion DoMyDesk requise.</div>'; return; }
if (!dmd_ssh_has_permission('module.view', $email)) { echo '<div class="dmdssh-denied">Accès DMD-Ssh refusé.</div>'; return; }

$moduleBase = rtrim(dmd_ssh_module_web_path(), '/');
$cssVersion = is_file(__DIR__ . '/dmd-ssh.css') ? (string)filemtime(__DIR__ . '/dmd-ssh.css') : DMD_SSH_VERSION;
$jsVersion = is_file(__DIR__ . '/dmd-ssh-ui.js') ? (string)filemtime(__DIR__ . '/dmd-ssh-ui.js') : DMD_SSH_VERSION;
$uid = 'dmdssh_' . bin2hex(random_bytes(5));
$configOnly = defined('DMD_SSH_CONFIG_ONLY') && DMD_SSH_CONFIG_ONLY;
$uiJs = is_file(__DIR__ . '/dmd-ssh-ui.js') ? (string)file_get_contents(__DIR__ . '/dmd-ssh-ui.js') : '';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($moduleBase . '/dmd-ssh.css?v=' . rawurlencode($cssVersion), ENT_QUOTES, 'UTF-8') ?>">
<section class="dmdssh-app" id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
 data-mode="<?= $configOnly ? 'config' : 'main' ?>"
 data-api="<?= htmlspecialchars($moduleBase . '/dmd-ssh_api.php', ENT_QUOTES, 'UTF-8') ?>"
 data-terminal-api="<?= htmlspecialchars($moduleBase . '/dmd-ssh_terminal_api.php', ENT_QUOTES, 'UTF-8') ?>"
 data-module-base="<?= htmlspecialchars($moduleBase, ENT_QUOTES, 'UTF-8') ?>"
 data-source="module"
 data-dmd-module-id="DMD-Ssh"
 data-dmd-context-type="ssh_module"
 data-dmd-context-id="DMD-Ssh:module"
 data-dmd-context-name="DMD-Ssh">
    <header class="dmdssh-head">
        <div class="dmdssh-title"><img src="<?= htmlspecialchars($moduleBase . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt=""><span><strong>DMD-Ssh</strong><small>Terminal SSH</small></span></div>
        <div class="dmdssh-head-actions">
            <span class="dmdssh-runtime" data-role="runtime">Chargement…</span>
            <?php if (!$configOnly && dmd_ssh_has_permission('logs.view', $email)): ?><button type="button" data-action="logs">Journal</button><?php endif; ?>
            <?php if (dmd_ssh_has_permission('connections.manage', $email)): ?><button type="button" data-action="config">⚙ Connexions</button><?php endif; ?>
            <button type="button" data-action="refresh" title="Actualiser">↻</button>
        </div>
    </header>
    <div class="dmdssh-body" data-role="body"><div class="dmdssh-empty">Chargement…</div></div>
    <div class="dmdssh-toast" data-role="toast" hidden></div>
</section>
<script><?= $uiJs ?></script>
