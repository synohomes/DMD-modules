<?php
if (!defined('DMD_SSH_CONFIG_ONLY')) define('DMD_SSH_CONFIG_ONLY', true);
require __DIR__ . '/DMD-Ssh.php';
