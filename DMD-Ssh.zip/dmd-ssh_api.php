<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-ssh_lib.php';

$email=dmd_ssh_email();
if(filter_var($email,FILTER_VALIDATE_EMAIL)===false)dmd_ssh_reply(array('ok'=>false,'message'=>'Non connecté.'),401);
if(!dmd_ssh_has_permission('module.view',$email))dmd_ssh_reply(array('ok'=>false,'message'=>'Accès DMD-Ssh refusé.'),403);

function dmd_ssh_api_input(): array {
    $raw=(string)file_get_contents('php://input');
    $json=$raw!==''?json_decode($raw,true):null;
    return is_array($json)?$json:$_POST;
}
function dmd_ssh_api_resources(array $connections): array {
    $out=array();
    foreach($connections as $row){$id=dmd_ssh_slug($row['id']??'');if($id==='')continue;$c=dmd_ssh_get_connection($id);if($c)$out[]=dmd_ssh_resource($c);}
    return $out;
}
function dmd_ssh_api_require_connection_access(string $email): void {
    if (!dmd_ssh_has_permission('connections.view',$email) && !dmd_ssh_has_permission('connections.manage',$email)) {
        dmd_ssh_reply(array('ok'=>false,'message'=>'Accès aux connexions SSH refusé.'),403);
    }
}

$action=(string)($_GET['action']??$_POST['action']??'state');

if($action==='state'||$action==='admin_state'){
    if($action==='admin_state') dmd_ssh_require_permission('connections.manage');
    dmd_ssh_prepare_storage($email);
    $connections=dmd_ssh_has_permission('connections.view',$email)||dmd_ssh_has_permission('connections.manage',$email)?dmd_ssh_list_connections($email):array();
    $runtime=array();try{$runtime['ssh']=dmd_ssh_binary('ssh')!=='';}catch(Throwable $e){$runtime['ssh']=false;}try{$runtime['pty']=dmd_ssh_terminal_helper()!=='';}catch(Throwable $e){$runtime['pty']=false;$runtime['pty_error']=$e->getMessage();}$runtime['interactive_terminal']=!empty($runtime['ssh'])&&!empty($runtime['pty']);
    dmd_ssh_reply(array(
        'ok'=>true,'csrf'=>dmd_ssh_csrf(),'version'=>DMD_SSH_VERSION,'connections'=>$connections,
        'resources'=>dmd_ssh_api_resources($connections),'runtime'=>$runtime,
        'storage_scope'=>'user','storage_label'=>'users/profiles/<utilisateur>/'.DMD_SSH_ID,
        'permissions'=>array(
            'connections_view'=>dmd_ssh_has_permission('connections.view',$email),
            'connections_manage'=>dmd_ssh_has_permission('connections.manage',$email),
            'connections_secret'=>dmd_ssh_has_permission('connections.secret',$email),
            'terminal_open'=>dmd_ssh_has_permission('terminal.open',$email),
            'terminal_execute'=>dmd_ssh_has_permission('terminal.execute',$email),
            'terminal_privileged'=>dmd_ssh_has_permission('terminal.privileged',$email),
            'logs_view'=>dmd_ssh_has_permission('logs.view',$email),
            'quicksession_use'=>dmd_ssh_has_permission('quicksession.use',$email),
            'actionhub_use'=>dmd_ssh_has_permission('actionhub.use',$email)
        )
    ));
}

if($_SERVER['REQUEST_METHOD']!=='POST')dmd_ssh_reply(array('ok'=>false,'message'=>'Méthode refusée.'),405);
dmd_ssh_check_csrf();
$input=dmd_ssh_api_input();

if($action==='save'){
    dmd_ssh_require_permission('connections.manage');
    try{
        $id=dmd_ssh_slug($input['id']??'');$existing=$id!==''?dmd_ssh_get_connection($id,$email,false):null;
        if(!$existing){$id=substr(hash('sha256',random_bytes(24)),0,16);$existing=array('id'=>$id);}
        $name=dmd_ssh_clean($input['name']??'',120);$host=dmd_ssh_clean($input['host']??'',253);$port=(int)($input['port']??22);$username=dmd_ssh_clean($input['username']??'',120);
        if($name===''||!dmd_ssh_valid_host($host)||!dmd_ssh_valid_username($username)||$port<1||$port>65535)throw new InvalidArgumentException('Nom, hôte, port ou utilisateur invalide.');
        $auth=strtolower(dmd_ssh_clean($input['auth_type']??'agent',30));if(!in_array($auth,array('agent','password','private_key'),true))$auth='agent';
        $tags=array();foreach(preg_split('/[,;\n]+/',(string)($input['tags_text']??''))?:array() as $tag){$t=dmd_ssh_clean($tag,40);if($t!==''&&!in_array($t,$tags,true))$tags[]=$t;if(count($tags)>=20)break;}
        $c=array_replace($existing,array('id'=>$id,'name'=>$name,'host'=>$host,'port'=>$port,'username'=>$username,'auth_type'=>$auth,'tags'=>$tags,'notes'=>dmd_ssh_clean($input['notes']??'',2000),'updated_at'=>date(DATE_ATOM),'updated_by'=>$email));
        if(empty($c['created_at'])){$c['created_at']=date(DATE_ATOM);$c['created_by']=$email;}
        if(dmd_ssh_has_permission('connections.secret',$email)){
            $password=(string)($input['password']??'');$privateKey=(string)($input['private_key']??'');$passphrase=(string)($input['passphrase']??'');
            if($password!=='')$c['password_enc']=dmd_ssh_encrypt($password,$email);
            if($privateKey!=='')$c['private_key_enc']=dmd_ssh_encrypt($privateKey,$email);
            if($passphrase!=='')$c['passphrase_enc']=dmd_ssh_encrypt($passphrase,$email);
            if(!empty($input['clear_password']))unset($c['password_enc']);
            if(!empty($input['clear_private_key']))unset($c['private_key_enc'],$c['passphrase_enc']);
        }
        if(!dmd_ssh_write_json(dmd_ssh_connection_file($id,$email),$c))throw new RuntimeException('Impossible d’enregistrer la connexion.');
        dmd_ssh_log('connection.save',$c,$email,'success',array('host'=>$host,'port'=>$port,'auth_type'=>$auth),dmd_ssh_resource($c));
        dmd_ssh_reply(array('ok'=>true,'message'=>'Connexion enregistrée.','connection'=>dmd_ssh_connection_public($c)));
    }catch(Throwable $e){dmd_ssh_reply(array('ok'=>false,'message'=>$e->getMessage()),400);}
}

if($action==='delete'){
    dmd_ssh_require_permission('connections.manage');$id=dmd_ssh_slug($input['id']??'');$c=dmd_ssh_get_connection($id,$email,false);if(!$c)dmd_ssh_reply(array('ok'=>false,'message'=>'Connexion introuvable.'),404);
    @unlink(dmd_ssh_connection_file($id,$email));dmd_ssh_log('connection.delete',$c,$email,'success',array(),dmd_ssh_resource($c));dmd_ssh_reply(array('ok'=>true,'message'=>'Connexion supprimée.'));
}

if($action==='test'){
    dmd_ssh_require_permission('terminal.open');
    dmd_ssh_api_require_connection_access($email);
    try{$id=dmd_ssh_slug($input['id']??'');$c=dmd_ssh_get_connection($id,$email,true);if(!$c)throw new RuntimeException('Connexion introuvable.');$result=dmd_ssh_test($c,$email,(string)($input['source']??'module'));$c['last_test_at']=date(DATE_ATOM);$c['last_test_status']=$result['ok']?'online':'error';$detail=trim((string)($result['stderr']!==''?$result['stderr']:$result['stdout']));$c['last_test_message']=dmd_ssh_clean($detail,300);dmd_ssh_write_json(dmd_ssh_connection_file($id,$email),$c);dmd_ssh_reply(array('ok'=>true,'test_ok'=>$result['ok'],'message'=>$result['ok']?'Connexion SSH opérationnelle.':($detail!==''?'SSH : '.$detail:'Test SSH en échec (code '.$result['exit_code'].').'),'result'=>$result,'connection'=>dmd_ssh_connection_public($c)));}
    catch(Throwable $e){dmd_ssh_reply(array('ok'=>false,'message'=>$e->getMessage()),400);}
}

if($action==='execute'){
    dmd_ssh_require_permission('terminal.execute');
    dmd_ssh_api_require_connection_access($email);
    try{$id=dmd_ssh_slug($input['id']??'');$c=dmd_ssh_get_connection($id,$email,true);if(!$c)throw new RuntimeException('Connexion introuvable.');$result=dmd_ssh_execute($c,(string)($input['command']??''),$email,(int)($input['timeout']??30),'command.execute',(string)($input['source']??'module'));dmd_ssh_reply(array('ok'=>true,'message'=>$result['ok']?'Commande terminée.':'Commande terminée avec erreur.','result'=>$result));}
    catch(Throwable $e){dmd_ssh_reply(array('ok'=>false,'message'=>$e->getMessage()),400);}
}

if($action==='quicksession_add'){
    dmd_ssh_require_permission('quicksession.use');
    dmd_ssh_api_require_connection_access($email);
    try{$id=dmd_ssh_slug($input['id']??'');$c=dmd_ssh_get_connection($id,$email,true);if(!$c)throw new RuntimeException('Connexion introuvable.');dmd_ssh_boot_core();if(!function_exists('dmd_qs_add_resource'))throw new RuntimeException('Quick-Session indisponible.');$result=dmd_qs_add_resource($email,dmd_ssh_resource($c));dmd_ssh_log('quicksession.add',$c,$email,!empty($result['ok'])?'success':'error',array(),dmd_ssh_resource($c),(string)($input['source']??'module'));dmd_ssh_reply(array('ok'=>!empty($result['ok']),'message'=>!empty($result['ok'])?'Connexion ajoutée à Quick-Session.':'Aucune Quick-Session active.','result'=>$result));}
    catch(Throwable $e){dmd_ssh_reply(array('ok'=>false,'message'=>$e->getMessage()),400);}
}


if($action==='hostkey_accept'){
    dmd_ssh_require_permission('terminal.open');
    dmd_ssh_api_require_connection_access($email);
    try{
        $id=dmd_ssh_slug($input['id']??'');
        $c=dmd_ssh_get_connection($id,$email,true);
        if(!$c)throw new RuntimeException('Connexion introuvable.');
        dmd_ssh_forget_hostkey($c,$email);
        dmd_ssh_log('hostkey.accept_new',$c,$email,'success',array('host'=>(string)$c['host'],'port'=>(int)$c['port']),dmd_ssh_resource($c),(string)($input['source']??'module'));
        dmd_ssh_reply(array('ok'=>true,'message'=>'Nouvelle identité SSH autorisée. La prochaine connexion l’enregistrera automatiquement.'));
    }catch(Throwable $e){dmd_ssh_reply(array('ok'=>false,'message'=>$e->getMessage()),400);}
}

if($action==='logs'){
    dmd_ssh_require_permission('logs.view');dmd_ssh_reply(array('ok'=>true,'logs'=>dmd_ssh_recent_logs($email,(int)($input['limit']??100))));
}

dmd_ssh_reply(array('ok'=>false,'message'=>'Action inconnue.'),404);
