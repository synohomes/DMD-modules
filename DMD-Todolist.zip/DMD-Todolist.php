<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/DMD-Todolist_lib.php';

dmdtodo_require_access();

$email = $_SESSION['user']['email'] ?? '';
if ($email === '') {
    echo '<div class="dmdtodo-alert dmdtodo-alert-error">Utilisateur non connecté.</div>';
    return;
}

$todoPermissions = array(
    'create' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.create'),
    'edit' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.edit'),
    'status' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.status'),
    'checklist' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.checklist'),
    'share' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.share'),
    'delete' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.delete'),
    'history' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'history.view'),
    'print' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'history.print'),
);
$todoCanOpenEdit = $todoPermissions['edit'] || $todoPermissions['status'] || $todoPermissions['checklist'] || $todoPermissions['share'];

list($data) = dmdtodo_load($email);
$settings = $data['settings'];
$members = dmdtodo_members($email);
$tasks = array();

foreach ($data['tasks'] as $task) {
    $tasks[] = dmdtodo_normalize_task($task);
}

$priorityWeight = array('urgent' => 4, 'high' => 3, 'normal' => 2, 'low' => 1);
usort($tasks, function ($a, $b) use ($priorityWeight) {
    $aClosed = in_array($a['status'], array('done', 'archived'), true);
    $bClosed = in_array($b['status'], array('done', 'archived'), true);

    if ($aClosed !== $bClosed) {
        return $aClosed ? 1 : -1;
    }

    $pa = $priorityWeight[$a['priority']] ?? 0;
    $pb = $priorityWeight[$b['priority']] ?? 0;
    if ($pa !== $pb) {
        return $pb <=> $pa;
    }

    $da = $a['due_date'] !== '' ? $a['due_date'] : '9999-12-31';
    $db = $b['due_date'] !== '' ? $b['due_date'] : '9999-12-31';
    return strcmp($da, $db);
});

$visible = array();
foreach ($tasks as $task) {
    if ($task['status'] === 'archived' && empty($settings['show_archives'])) {
        continue;
    }
    $visible[] = $task;
}

$openCount = 0;
$doneCount = 0;
$sharedCount = 0;
foreach ($visible as $task) {
    if (in_array($task['status'], array('done', 'archived'), true)) {
        $doneCount++;
    } else {
        $openCount++;
    }
    if (!empty($task['shared_with'])) {
        $sharedCount++;
    }
}

$today = date('Y-m-d');
$cssHref = 'modules/DMD-Todolist/DMD-Todolist.css?v=2.1.1';
$apiHref = 'modules/DMD-Todolist/DMD-Todolist_api.php';
try {
    $todoInstanceId = 'dmdtodo_' . bin2hex(random_bytes(8));
} catch (Exception $e) {
    $todoInstanceId = 'dmdtodo_' . uniqid('', true);
}
?>
<link rel="stylesheet" href="<?= htmlspecialchars($cssHref, ENT_QUOTES, 'UTF-8') ?>">

<div class="dmdtodo" data-api="<?= htmlspecialchars($apiHref, ENT_QUOTES, 'UTF-8') ?>" data-todo-instance="<?= htmlspecialchars($todoInstanceId, ENT_QUOTES, 'UTF-8') ?>">
    <div class="dmdtodo-toolbar">
        <div class="dmdtodo-summary" aria-label="Résumé des tâches">
            <span class="dmdtodo-counter"><strong><?= (int)$openCount ?></strong> à faire</span>
            <span class="dmdtodo-counter"><strong><?= (int)$doneCount ?></strong> terminée<?= $doneCount > 1 ? 's' : '' ?></span>
            <?php if ($sharedCount > 0): ?>
                <span class="dmdtodo-counter dmdtodo-counter-shared"><strong><?= (int)$sharedCount ?></strong> partagée<?= $sharedCount > 1 ? 's' : '' ?></span>
            <?php endif; ?>
        </div>

        <div class="dmdtodo-actions">
            <label class="dmdtodo-search-wrap" title="Rechercher dans les tâches">
                <span aria-hidden="true">⌕</span>
                <input class="dmdtodo-input dmdtodo-search" type="search" placeholder="Rechercher…" data-search>
            </label>

            <select class="dmdtodo-input dmdtodo-cat-filter" data-cat-filter aria-label="Filtrer par catégorie">
                <option value="">Toutes les catégories</option>
                <?php foreach ($settings['categories'] as $cat): ?>
                    <option value="<?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?></option>
                <?php endforeach; ?>
            </select>

            <?php if ($todoPermissions['create']): ?><button type="button" class="dmdtodo-btn dmdtodo-btn-primary" data-new>＋ Nouvelle tâche</button><?php endif; ?>
            <?php if ($todoPermissions['history']): ?><button type="button" class="dmdtodo-btn" data-history>🕘 Historique</button><?php endif; ?>
            <button type="button" class="dmdtodo-btn dmdtodo-btn-icon" data-refresh title="Recharger les tâches synchronisées" aria-label="Recharger">↻</button>
        </div>
    </div>

    <div class="dmdtodo-grid" data-list>
        <?php foreach ($visible as $task): ?>
            <?php
            $done = 0;
            $total = count($task['checklist']);
            foreach ($task['checklist'] as $item) {
                if (!empty($item['done'])) {
                    $done++;
                }
            }

            $isLate = $task['due_date'] !== ''
                && $task['due_date'] < $today
                && !in_array($task['status'], array('done', 'archived'), true);

            $progress = $total > 0 ? (int)round(($done / $total) * 100) : 0;
            $searchText = dmdtodo_lower(
                $task['title'] . ' ' .
                $task['description'] . ' ' .
                $task['comment'] . ' ' .
                $task['category'] . ' ' .
                implode(' ', $task['tags'])
            );
            $json = htmlspecialchars(
                json_encode($task, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP),
                ENT_QUOTES,
                'UTF-8'
            );
            $resource = dmdtodo_resource($task);
            $resourceJson = htmlspecialchars(
                json_encode($resource, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP),
                ENT_QUOTES,
                'UTF-8'
            );
            $resourceActions = array();
            if ($todoPermissions['edit']) $resourceActions[] = array('id' => 'task.edit', 'label' => 'Modifier');
            if ($todoPermissions['status']) $resourceActions[] = array('id' => 'task.status', 'label' => 'Changer le statut');
            if ($todoPermissions['checklist']) $resourceActions[] = array('id' => 'task.checklist', 'label' => 'Checklist');
            if ($todoPermissions['share']) $resourceActions[] = array('id' => 'task.share', 'label' => 'Partager');
            if ($todoPermissions['delete']) $resourceActions[] = array('id' => 'task.delete', 'label' => 'Supprimer');
            $resourceActionsJson = htmlspecialchars(
                json_encode($resourceActions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP),
                ENT_QUOTES,
                'UTF-8'
            );
            ?>

            <article
                class="dmdtodo-task<?= $task['status'] === 'done' ? ' is-done' : '' ?><?= $task['status'] === 'archived' ? ' is-archived' : '' ?><?= $isLate ? ' is-late' : '' ?>"
                data-task='<?= $json ?>'
                data-id="<?= htmlspecialchars($task['id'], ENT_QUOTES, 'UTF-8') ?>"
                data-search="<?= htmlspecialchars($searchText, ENT_QUOTES, 'UTF-8') ?>"
                data-category="<?= htmlspecialchars($task['category'], ENT_QUOTES, 'UTF-8') ?>"
                data-dmd-resource='<?= $resourceJson ?>'
                data-dmd-resource-type="task"
                data-dmd-resource-id="<?= htmlspecialchars($resource['id'], ENT_QUOTES, 'UTF-8') ?>"
                data-dmd-resource-name="<?= htmlspecialchars($resource['name'], ENT_QUOTES, 'UTF-8') ?>"
                data-dmd-resource-module="DMD-Todolist"
                data-dmd-context-type="task"
                data-dmd-context-id="<?= htmlspecialchars($resource['id'], ENT_QUOTES, 'UTF-8') ?>"
                data-dmd-context-name="<?= htmlspecialchars($resource['name'], ENT_QUOTES, 'UTF-8') ?>"
                data-dmd-context-source="DMD-Todolist"
                data-dmd-context-tags="<?= htmlspecialchars(implode(',', (array)($resource['tags'] ?? array())), ENT_QUOTES, 'UTF-8') ?>"
                data-dmd-actions='<?= $resourceActionsJson ?>'
            >
                <?php if ($todoPermissions['status']): ?>
                <button
                    type="button"
                    class="dmdtodo-checkbtn"
                    data-quick-status
                    title="<?= $task['status'] === 'done' ? 'Rouvrir la tâche' : 'Marquer comme terminée' ?>"
                    aria-label="<?= $task['status'] === 'done' ? 'Rouvrir la tâche' : 'Marquer comme terminée' ?>"
                ><?= $task['status'] === 'done' ? '✓' : '' ?></button>
                <?php endif; ?>

                <div class="dmdtodo-task-main">
                    <div class="dmdtodo-task-head">
                        <div class="dmdtodo-task-title"><?= htmlspecialchars($task['title'], ENT_QUOTES, 'UTF-8') ?></div>
                        <?php if ($todoPermissions['delete']): ?><button type="button" class="dmdtodo-deletebtn" data-delete title="Supprimer" aria-label="Supprimer">×</button><?php endif; ?>
                    </div>

                    <?php if ($task['description'] !== ''): ?>
                        <div class="dmdtodo-task-preview"><?= htmlspecialchars($task['description'], ENT_QUOTES, 'UTF-8') ?></div>
                    <?php endif; ?>

                    <div class="dmdtodo-task-meta">
                        <span class="dmdtodo-chip dmdtodo-status-<?= htmlspecialchars($task['status'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($settings['statuses'][$task['status']] ?? $task['status'], ENT_QUOTES, 'UTF-8') ?></span>
                        <span class="dmdtodo-chip dmdtodo-priority-<?= htmlspecialchars($task['priority'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($settings['priorities'][$task['priority']] ?? $task['priority'], ENT_QUOTES, 'UTF-8') ?></span>
                        <?php if ($task['category'] !== ''): ?><span class="dmdtodo-chip"><?= htmlspecialchars($task['category'], ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
                        <?php if ($task['due_date'] !== ''): ?><span class="dmdtodo-chip<?= $isLate ? ' dmdtodo-late' : '' ?>">🗓 <?= htmlspecialchars(date('d/m', strtotime($task['due_date'])), ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
                        <?php if (!empty($task['shared_with'])): ?><button type="button" class="dmdtodo-chip dmdtodo-share-chip" data-share title="Voir le partage">👥 <?= count($task['shared_with']) ?></button><?php endif; ?>
                    </div>

                    <?php if ($total > 0): ?>
                        <div class="dmdtodo-progress-row" title="Checklist : <?= (int)$done ?>/<?= (int)$total ?>">
                            <div class="dmdtodo-progress"><span style="width:<?= (int)$progress ?>%"></span></div>
                            <small><?= (int)$done ?>/<?= (int)$total ?></small>
                        </div>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <?php if (!$visible): ?>
        <div class="dmdtodo-empty">
            <strong>✓ Rien à faire ici</strong>
            <span>Ajoute une tâche ou change le filtre de catégorie.</span>
        </div>
    <?php endif; ?>
</div>

<div class="dmdtodo-modal" data-modal="view" data-todo-instance="<?= htmlspecialchars($todoInstanceId, ENT_QUOTES, 'UTF-8') ?>" aria-hidden="true">
    <section class="dmdtodo-window dmdtodo-view-window">
        <header class="dmdtodo-window-head">
            <div>
                <small>DMD-Todolist</small>
                <h3 data-view-title></h3>
            </div>
            <button class="dmdtodo-close" type="button" data-close aria-label="Fermer">×</button>
        </header>
        <div class="dmdtodo-view-body">
            <div class="dmdtodo-view-meta" data-view-meta></div>
            <div class="dmdtodo-view-section" data-desc-wrap><strong>Description</strong><p data-view-desc></p></div>
            <div class="dmdtodo-view-section" data-check-wrap><strong>Checklist</strong><div class="dmdtodo-checklist-view" data-view-checklist></div></div>
            <div class="dmdtodo-view-section" data-comment-wrap><strong>Commentaire</strong><p data-view-comment></p></div>
            <div class="dmdtodo-view-actions">
                <?php if ($todoCanOpenEdit): ?><button class="dmdtodo-btn dmdtodo-btn-primary" type="button" data-edit>Modifier</button><?php endif; ?>
                <?php if ($todoPermissions['status']): ?><button class="dmdtodo-btn" type="button" data-status="done">Terminer</button><?php endif; ?>
                <?php if ($todoPermissions['status']): ?><button class="dmdtodo-btn" type="button" data-status="todo">À faire</button><?php endif; ?>
                <?php if ($todoPermissions['delete']): ?><button class="dmdtodo-btn dmdtodo-danger" type="button" data-delete-current>Supprimer</button><?php endif; ?>
                <button class="dmdtodo-btn" type="button" data-close>Fermer</button>
            </div>
        </div>
    </section>
</div>

<div class="dmdtodo-modal" data-modal="form" data-todo-instance="<?= htmlspecialchars($todoInstanceId, ENT_QUOTES, 'UTF-8') ?>" aria-hidden="true">
    <section class="dmdtodo-window dmdtodo-form-window">
        <header class="dmdtodo-window-head">
            <div>
                <small>DMD-Todolist</small>
                <h3 data-form-title>Nouvelle tâche</h3>
            </div>
            <button class="dmdtodo-close" type="button" data-close aria-label="Fermer">×</button>
        </header>

        <form class="dmdtodo-form" data-form>
            <input type="hidden" name="id">

            <label class="dmdtodo-field dmdtodo-full">
                <span>Titre *</span>
                <input class="dmdtodo-input" name="title" maxlength="180" required>
            </label>

            <div class="dmdtodo-grid2">
                <label class="dmdtodo-field">
                    <span>Catégorie</span>
                    <select class="dmdtodo-input" name="category">
                        <?php foreach ($settings['categories'] as $cat): ?>
                            <option value="<?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label class="dmdtodo-field">
                    <span>Priorité</span>
                    <select class="dmdtodo-input" name="priority">
                        <?php foreach ($settings['priorities'] as $key => $label): ?>
                            <option value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label class="dmdtodo-field">
                    <span>Échéance</span>
                    <input class="dmdtodo-input" type="date" name="due_date">
                </label>

                <label class="dmdtodo-field">
                    <span>Statut</span>
                    <select class="dmdtodo-input" name="status">
                        <?php foreach ($settings['statuses'] as $key => $label): ?>
                            <option value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>

            <label class="dmdtodo-field dmdtodo-full">
                <span>Description</span>
                <textarea class="dmdtodo-input" name="description" rows="3" maxlength="5000"></textarea>
            </label>

            <div class="dmdtodo-field dmdtodo-full">
                <div class="dmdtodo-field-title-row">
                    <span>Checklist</span>
                    <button class="dmdtodo-mini-btn" type="button" data-add-step>＋ Ajouter une étape</button>
                </div>
                <div class="dmdtodo-check-editor" data-check-editor></div>
            </div>

            <details class="dmdtodo-details dmdtodo-full">
                <summary>Options et partage</summary>
                <div class="dmdtodo-details-body">
                    <div class="dmdtodo-grid2">
                        <label class="dmdtodo-field"><span>Tags</span><input class="dmdtodo-input" name="tags" placeholder="client, urgent"></label>
                        <label class="dmdtodo-field"><span>Commentaire</span><input class="dmdtodo-input" name="comment" maxlength="5000"></label>
                    </div>

                    <div class="dmdtodo-field">
                        <span>Partager et synchroniser avec</span>
                        <small class="dmdtodo-help">Les modifications, statuts et cases cochées sont recopiés chez tous les participants.</small>
                        <div class="dmdtodo-members" data-members>
                            <?php if (!$members): ?>
                                <div class="dmdtodo-empty-small">Aucun autre utilisateur disponible.</div>
                            <?php endif; ?>
                            <?php foreach ($members as $member): ?>
                                <label class="dmdtodo-member">
                                    <input type="checkbox" name="shared_with[]" value="<?= htmlspecialchars($member['email'], ENT_QUOTES, 'UTF-8') ?>">
                                    <span><?= htmlspecialchars($member['name'], ENT_QUOTES, 'UTF-8') ?></span>
                                    <small><?= htmlspecialchars($member['email'], ENT_QUOTES, 'UTF-8') ?></small>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </details>

            <div class="dmdtodo-form-actions">
                <button class="dmdtodo-btn dmdtodo-btn-primary" type="submit">Enregistrer</button>
                <button class="dmdtodo-btn" type="button" data-close>Annuler</button>
            </div>
        </form>
    </section>
</div>

<div class="dmdtodo-modal" data-modal="share" data-todo-instance="<?= htmlspecialchars($todoInstanceId, ENT_QUOTES, 'UTF-8') ?>" aria-hidden="true">
    <section class="dmdtodo-window dmdtodo-share-window">
        <header class="dmdtodo-window-head">
            <div><small>DMD-Todolist</small><h3>Partage synchronisé</h3></div>
            <button class="dmdtodo-close" type="button" data-close aria-label="Fermer">×</button>
        </header>
        <div class="dmdtodo-view-body" data-share-body></div>
    </section>
</div>

<div class="dmdtodo-modal" data-modal="history" data-todo-instance="<?= htmlspecialchars($todoInstanceId, ENT_QUOTES, 'UTF-8') ?>" aria-hidden="true">
    <section class="dmdtodo-window dmdtodo-history-window">
        <header class="dmdtodo-window-head">
            <div><small>DMD-Todolist</small><h3>Historique des tâches</h3></div>
            <button class="dmdtodo-close" type="button" data-close aria-label="Fermer">×</button>
        </header>
        <div class="dmdtodo-history-tools">
            <div>
                <strong>Liste des tâches</strong>
                <small>Clique sur une tâche pour afficher sa fiche complète et toutes ses actions.</small>
            </div>
            <?php if ($todoPermissions['print']): ?><button class="dmdtodo-btn" type="button" data-history-print-all>🖨 Imprimer tout / PDF</button><?php endif; ?>
        </div>
        <div class="dmdtodo-history-list" data-history-list>
            <div class="dmdtodo-empty-small">Chargement…</div>
        </div>
    </section>
</div>

<div class="dmdtodo-modal" data-modal="history-detail" data-todo-instance="<?= htmlspecialchars($todoInstanceId, ENT_QUOTES, 'UTF-8') ?>" aria-hidden="true">
    <section class="dmdtodo-window dmdtodo-history-detail-window">
        <header class="dmdtodo-window-head">
            <div><small>DMD-Todolist · Historique</small><h3 data-history-detail-title>Détail de la tâche</h3></div>
            <button class="dmdtodo-close" type="button" data-close aria-label="Fermer">×</button>
        </header>
        <div class="dmdtodo-history-detail-actions">
            <?php if ($todoPermissions['print']): ?><button class="dmdtodo-btn dmdtodo-btn-primary" type="button" data-history-print>🖨 Imprimer / PDF</button><?php endif; ?>
            <button class="dmdtodo-btn" type="button" data-close>Fermer</button>
        </div>
        <div class="dmdtodo-history-detail-body" data-history-detail-body></div>
    </section>
</div>

<div class="dmdtodo-modal" data-modal="print" data-todo-instance="<?= htmlspecialchars($todoInstanceId, ENT_QUOTES, 'UTF-8') ?>" aria-hidden="true">
    <section class="dmdtodo-window dmdtodo-print-window">
        <header class="dmdtodo-window-head dmdtodo-print-controls">
            <div><small>DMD-Todolist</small><h3>Aperçu avant impression</h3></div>
            <button class="dmdtodo-close" type="button" data-close aria-label="Fermer">×</button>
        </header>
        <div class="dmdtodo-print-controls dmdtodo-print-actions">
            <span>Choisis « Enregistrer au format PDF » dans la boîte d’impression pour créer le PDF.</span>
            <button class="dmdtodo-btn dmdtodo-btn-primary" type="button" data-print-now>🖨 Imprimer / PDF</button>
        </div>
        <div class="dmdtodo-print-sheet" data-print-sheet></div>
    </section>
</div>

<script>
(function () {
    var roots = Array.prototype.slice.call(document.querySelectorAll('.dmdtodo'));
    var wrap = roots.length ? roots[roots.length - 1] : null;
    if (!wrap || wrap.dataset.ready) return;
    wrap.dataset.ready = '1';

    var api = wrap.dataset.api;
    var labels = {
        statuses: <?= json_encode($settings['statuses'], JSON_UNESCAPED_UNICODE) ?>,
        priorities: <?= json_encode($settings['priorities'], JSON_UNESCAPED_UNICODE) ?>
    };
    var members = <?= json_encode($members, JSON_UNESCAPED_UNICODE) ?>;
    var permissions = <?= json_encode($todoPermissions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    var popupZ = 12000;
    var tasks = Array.prototype.slice.call(wrap.querySelectorAll('[data-task]')).map(function (el) {
        return JSON.parse(el.dataset.task);
    });
    var current = null;
    var modals = {};
    var ownedModals = [];
    var cleanupDone = false;
    var cleanupTimer = null;
    var cleanupObserver = null;
    var instanceId = wrap.dataset.todoInstance || '';
    var historyLogs = [];
    var historyTasks = {};
    var historySelectedId = '';

    Array.prototype.slice.call(document.querySelectorAll('.dmdtodo-modal[data-modal]')).forEach(function (modal) {
        if ((modal.dataset.todoInstance || '') !== instanceId) return;
        modals[modal.dataset.modal] = modal;
        ownedModals.push(modal);
        if (modal.parentElement !== document.body) document.body.appendChild(modal);
        var modalWindow = modal.querySelector('.dmdtodo-window');
        makeDrag(modalWindow);
        if (modalWindow) {
            modalWindow.addEventListener('pointerdown', function () { bringToFront(modalWindow); }, true);
        }
    });

    function cleanupDetachedPopups() {
        if (cleanupDone) return;
        cleanupDone = true;
        if (cleanupTimer) window.clearInterval(cleanupTimer);
        if (cleanupObserver) cleanupObserver.disconnect();
        ownedModals.forEach(function (modal) {
            if (modal && modal.parentNode) modal.parentNode.removeChild(modal);
        });
        document.body.style.userSelect = '';
    }

    function ensureModuleStillMounted() {
        if (!document.documentElement.contains(wrap)) cleanupDetachedPopups();
    }

    cleanupTimer = window.setInterval(ensureModuleStillMounted, 300);
    if (window.MutationObserver) {
        cleanupObserver = new MutationObserver(ensureModuleStillMounted);
        cleanupObserver.observe(document.documentElement, {childList: true, subtree: true});
    }
    window.addEventListener('beforeunload', cleanupDetachedPopups);

    function esc(value) {
        return String(value == null ? '' : value).replace(/[&<>'"]/g, function (char) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char];
        });
    }

    function fmtDate(date) {
        if (!date) return '';
        var parsed = new Date(date + 'T00:00:00');
        return isNaN(parsed.getTime()) ? date : parsed.toLocaleDateString('fr-FR', {day:'2-digit', month:'2-digit', year:'numeric'});
    }

    function bringToFront(win) {
        if (!win) return;
        popupZ += 1;
        win.style.zIndex = String(popupZ);
    }

    function openModal(name) {
        var modal = modals[name];
        if (!modal) return;
        var win = modal.querySelector('.dmdtodo-window');
        modal.setAttribute('aria-hidden', 'false');
        bringToFront(win);

        if (win && !win.dataset.placed) {
            var rect = wrap.getBoundingClientRect();
            win.style.left = (window.scrollX + rect.left + Math.min(220, Math.max(16, rect.width * 0.18))) + 'px';
            win.style.top = (window.scrollY + rect.top + 36) + 'px';
            win.dataset.placed = '1';
        }
    }

    function closeModal(element) {
        var modal = element && element.closest ? element.closest('.dmdtodo-modal') : element;
        if (modal) modal.setAttribute('aria-hidden', 'true');
    }

    function chip(text) {
        return '<span class="dmdtodo-chip">' + esc(text) + '</span>';
    }

    function checkCount(task) {
        var list = task.checklist || [];
        var done = list.filter(function (item) { return !!item.done; }).length;
        return [done, list.length];
    }

    function renderView(task) {
        current = task;
        modals.view.querySelector('[data-view-title]').textContent = task.title;

        var counts = checkCount(task);
        var meta = [
            labels.statuses[task.status] || task.status,
            labels.priorities[task.priority] || task.priority,
            task.category,
            task.due_date ? '🗓 ' + fmtDate(task.due_date) : '',
            counts[1] ? '☑ ' + counts[0] + '/' + counts[1] : '',
            (task.shared_with || []).length ? '👥 synchronisé' : ''
        ];

        (task.tags || []).forEach(function (tag) { meta.push('#' + tag); });
        modals.view.querySelector('[data-view-meta]').innerHTML = meta.filter(Boolean).map(chip).join('');
        modals.view.querySelector('[data-view-desc]').textContent = task.description || '—';
        modals.view.querySelector('[data-view-comment]').textContent = task.comment || '—';

        var checklist = modals.view.querySelector('[data-view-checklist]');
        if (!counts[1]) {
            checklist.innerHTML = '<div class="dmdtodo-empty-small">Pas d’étape.</div>';
        } else {
            checklist.innerHTML = (task.checklist || []).map(function (item, index) {
                var id = item.id || index;
                return '<label class="dmdtodo-check-row">' +
                    '<input type="checkbox" data-check-toggle data-check-id="' + esc(id) + '" ' + (item.done ? 'checked' : '') + (permissions.checklist ? '' : ' disabled') + '>' +
                    '<span class="' + (item.done ? 'is-checked' : '') + '">' + esc(item.text) + '</span>' +
                    (item.done_by ? '<small>' + esc(item.done_by) + '</small>' : '') +
                    '</label>';
            }).join('');
        }

        openModal('view');
    }

    function renderShare(task) {
        var owner = task.owner_email || task.created_by || '';
        var body = '<div class="dmdtodo-view-section"><strong>Synchronisation</strong><p>Checklist, statut et modifications sont partagés entre tous les participants.</p></div>';

        if (owner) {
            body += '<div class="dmdtodo-view-section"><strong>Créée par</strong><p>' + esc(owner) + '</p></div>';
        }

        body += '<div class="dmdtodo-view-section"><strong>Partagée avec</strong>';
        var list = task.shared_with || [];

        if (list.length) {
            body += list.map(function (mail) {
                var member = members.find(function (entry) { return entry.email === mail; });
                return '<div class="dmdtodo-share-person"><span>👤</span><div><b>' + esc(member ? member.name : mail) + '</b><small>' + esc(mail) + '</small></div></div>';
            }).join('');
        } else {
            body += '<p>Personne.</p>';
        }

        body += '</div>';

        if (task.last_changed_by) {
            body += '<div class="dmdtodo-view-section"><strong>Dernière modification</strong><p>' + esc(task.last_changed_by) + '</p></div>';
        }

        modals.share.querySelector('[data-share-body]').innerHTML = body;
        openModal('share');
    }

    function fmtDateTime(value) {
        if (!value) return '';
        var parsed = new Date(value);
        return isNaN(parsed.getTime()) ? value : parsed.toLocaleString('fr-FR');
    }

    function textValue(value) {
        if (value == null || value === '') return '—';
        if (Array.isArray(value)) return value.length ? value.join(', ') : '—';
        if (typeof value === 'object') {
            try { return JSON.stringify(value); } catch (e) { return String(value); }
        }
        return String(value);
    }

    function taskParticipants(task) {
        var list = [];
        if (task.owner_email) list.push(task.owner_email);
        (task.shared_with || []).forEach(function (mail) {
            if (list.indexOf(mail) === -1) list.push(mail);
        });
        return list;
    }

    function logSummary(row) {
        var details = row.details || {};
        if (row.action === 'task.checklist') {
            return (details.done ? 'Étape cochée' : 'Étape décochée') +
                (details.check_text ? ' : ' + details.check_text : '');
        }
        if (row.action === 'task.status') {
            return textValue(details.from) + ' → ' + textValue(details.to);
        }
        if (row.action === 'task.share') {
            var added = details.added || [];
            var removed = details.removed || [];
            var parts = [];
            if (added.length) parts.push('Ajout : ' + added.join(', '));
            if (removed.length) parts.push('Retrait : ' + removed.join(', '));
            return parts.join(' · ') || 'Participants modifiés';
        }
        if (row.action === 'task.update' && details.changes) {
            var names = Object.keys(details.changes);
            return names.length ? 'Champs modifiés : ' + names.join(', ') : 'Tâche modifiée';
        }
        if (row.action === 'task.create') return 'Création de la tâche';
        if (row.action === 'task.delete') return 'Suppression de la tâche';
        return '';
    }

    function collectHistory(logs) {
        historyLogs = Array.isArray(logs) ? logs : [];
        historyTasks = {};

        tasks.forEach(function (task) {
            historyTasks[task.id] = {
                task: task,
                logs: [],
                last: task.updated_at || task.created_at || '',
                deleted: false,
                live: true,
                snapshotSet: true
            };
        });

        historyLogs.forEach(function (row) {
            var id = row.task_id || '';
            if (!id) return;
            if (!historyTasks[id]) {
                historyTasks[id] = {
                    task: row.task_snapshot || {
                        id: id,
                        title: row.task_title || 'Tâche supprimée',
                        owner_email: row.owner_email || '',
                        shared_with: row.participants || [],
                        status: row.action === 'task.delete' ? 'deleted' : '',
                        priority: '',
                        checklist: [],
                        tags: []
                    },
                    logs: [],
                    last: row.timestamp || '',
                    deleted: row.action === 'task.delete',
                    live: false,
                    snapshotSet: !!(row.task_snapshot && Object.keys(row.task_snapshot).length)
                };
            }
            if (!historyTasks[id].live && !historyTasks[id].snapshotSet && row.task_snapshot && Object.keys(row.task_snapshot).length) {
                historyTasks[id].task = row.task_snapshot;
                historyTasks[id].snapshotSet = true;
            }
            historyTasks[id].logs.push(row);
            if (!historyTasks[id].last || String(row.timestamp || '') > String(historyTasks[id].last)) {
                historyTasks[id].last = row.timestamp || '';
            }
            if (row.action === 'task.delete') historyTasks[id].deleted = true;
        });

        Object.keys(historyTasks).forEach(function (id) {
            historyTasks[id].logs.sort(function (a, b) {
                return String(b.timestamp || '').localeCompare(String(a.timestamp || ''));
            });
        });
    }

    function renderHistory(logs) {
        collectHistory(logs);
        var list = modals.history.querySelector('[data-history-list]');
        var ids = Object.keys(historyTasks).sort(function (a, b) {
            return String(historyTasks[b].last || '').localeCompare(String(historyTasks[a].last || ''));
        });

        if (!ids.length) {
            list.innerHTML = '<div class="dmdtodo-empty-small">Aucune tâche à afficher pour le moment.</div>';
            return;
        }

        list.innerHTML = ids.map(function (id) {
            var entry = historyTasks[id];
            var task = entry.task || {};
            var counts = checkCount(task);
            var participants = taskParticipants(task);
            var status = entry.deleted ? 'Supprimée' : (labels.statuses[task.status] || task.status || '—');
            var lastLog = entry.logs.length ? entry.logs[0] : null;

            return '<button type="button" class="dmdtodo-history-task" data-history-task-id="' + esc(id) + '">' +
                '<div class="dmdtodo-history-task-main">' +
                    '<strong>' + esc(task.title || 'Sans titre') + '</strong>' +
                    '<div class="dmdtodo-history-task-chips">' +
                        chip(status) +
                        (task.priority ? chip(labels.priorities[task.priority] || task.priority) : '') +
                        (task.category ? chip(task.category) : '') +
                        (counts[1] ? chip('☑ ' + counts[0] + '/' + counts[1]) : '') +
                        (participants.length > 1 ? chip('👥 ' + participants.length) : '') +
                    '</div>' +
                    (lastLog ? '<small>' + esc(lastLog.action_label || lastLog.action || '') + (logSummary(lastLog) ? ' · ' + esc(logSummary(lastLog)) : '') + '</small>' : '<small>Aucune action journalisée pour cette tâche.</small>') +
                '</div>' +
                '<div class="dmdtodo-history-task-side">' +
                    '<strong>' + esc(String(entry.logs.length)) + '</strong><span>action' + (entry.logs.length > 1 ? 's' : '') + '</span>' +
                    '<small>' + esc(fmtDateTime(entry.last)) + '</small>' +
                '</div>' +
            '</button>';
        }).join('');
    }

    function fieldRow(label, value) {
        return '<div class="dmdtodo-report-field"><span>' + esc(label) + '</span><strong>' + esc(textValue(value)) + '</strong></div>';
    }

    function renderChecklistReport(task) {
        var list = task.checklist || [];
        if (!list.length) return '<div class="dmdtodo-empty-small">Aucune étape.</div>';

        return '<div class="dmdtodo-report-checklist">' + list.map(function (item) {
            var suffix = '';
            if (item.done_by) suffix += ' par ' + item.done_by;
            if (item.done_at) suffix += ' · ' + fmtDateTime(item.done_at);
            return '<div class="dmdtodo-report-check ' + (item.done ? 'is-done' : '') + '">' +
                '<span class="dmdtodo-report-checkmark">' + (item.done ? '✓' : '○') + '</span>' +
                '<div><strong>' + esc(item.text || 'Étape') + '</strong>' +
                (suffix ? '<small>' + esc(suffix) + '</small>' : '') +
                '</div></div>';
        }).join('') + '</div>';
    }

    function renderChanges(changes) {
        if (!changes || typeof changes !== 'object') return '';
        var keys = Object.keys(changes);
        if (!keys.length) return '';

        return '<div class="dmdtodo-log-changes">' + keys.map(function (key) {
            var change = changes[key] || {};
            return '<div><b>' + esc(key) + '</b><span>' +
                esc(textValue(change.before)) + ' → ' + esc(textValue(change.after)) +
            '</span></div>';
        }).join('') + '</div>';
    }

    function renderLogRow(row) {
        var detail = logSummary(row);
        var technical = [];
        if (row.ip) technical.push('IP : ' + row.ip);
        if (row.user_agent) technical.push('Client : ' + row.user_agent);

        return '<article class="dmdtodo-log-card">' +
            '<div class="dmdtodo-log-head">' +
                '<div><strong>' + esc(row.action_label || row.action || 'Action') + '</strong>' +
                    '<span>' + esc(row.actor_email || 'Utilisateur inconnu') + '</span></div>' +
                '<time>' + esc(fmtDateTime(row.timestamp)) + '</time>' +
            '</div>' +
            (detail ? '<p>' + esc(detail) + '</p>' : '') +
            renderChanges(row.details && row.details.changes ? row.details.changes : null) +
            (technical.length ? '<details class="dmdtodo-log-tech"><summary>Informations techniques</summary><small>' + technical.map(esc).join('<br>') + '</small></details>' : '') +
        '</article>';
    }

    function taskReportHtml(task, logs, includeTitle) {
        task = task || {};
        logs = logs || [];
        var counts = checkCount(task);
        var participants = taskParticipants(task);
        var html = '<div class="dmdtodo-report">';

        if (includeTitle) {
            html += '<div class="dmdtodo-report-title"><small>DMD-Todolist</small><h2>' + esc(task.title || 'Sans titre') + '</h2></div>';
        }

        html += '<section class="dmdtodo-report-section"><h4>Informations générales</h4><div class="dmdtodo-report-grid">' +
            fieldRow('ID', task.id || '—') +
            fieldRow('Statut', labels.statuses[task.status] || task.status || '—') +
            fieldRow('Priorité', labels.priorities[task.priority] || task.priority || '—') +
            fieldRow('Catégorie', task.category || '—') +
            fieldRow('Échéance', task.due_date ? fmtDate(task.due_date) : '—') +
            fieldRow('Propriétaire', task.owner_email || '—') +
            fieldRow('Créée par', task.created_by || '—') +
            fieldRow('Dernière modification par', task.last_changed_by || '—') +
            fieldRow('Créée le', fmtDateTime(task.created_at)) +
            fieldRow('Modifiée le', fmtDateTime(task.updated_at)) +
            fieldRow('Terminée le', fmtDateTime(task.completed_at)) +
            fieldRow('Checklist', counts[0] + '/' + counts[1]) +
        '</div></section>';

        html += '<section class="dmdtodo-report-section"><h4>Description</h4><div class="dmdtodo-report-text">' + esc(task.description || '—') + '</div></section>';
        html += '<section class="dmdtodo-report-section"><h4>Commentaire</h4><div class="dmdtodo-report-text">' + esc(task.comment || '—') + '</div></section>';
        html += '<section class="dmdtodo-report-section"><h4>Tags</h4><div class="dmdtodo-report-text">' + esc((task.tags || []).join(', ') || '—') + '</div></section>';
        html += '<section class="dmdtodo-report-section"><h4>Partage / synchronisation</h4><div class="dmdtodo-report-text">' +
            (participants.length ? participants.map(esc).join('<br>') : 'Non partagée') +
        '</div></section>';
        html += '<section class="dmdtodo-report-section"><h4>Checklist</h4>' + renderChecklistReport(task) + '</section>';

        html += '<section class="dmdtodo-report-section"><h4>Historique des actions (' + logs.length + ')</h4>';
        if (!logs.length) {
            html += '<div class="dmdtodo-empty-small">Aucune action journalisée pour cette tâche.</div>';
        } else {
            html += '<div class="dmdtodo-log-list">' + logs.map(renderLogRow).join('') + '</div>';
        }
        html += '</section></div>';
        return html;
    }

    function renderHistoryDetail(id) {
        var entry = historyTasks[id];
        if (!entry) return;
        historySelectedId = id;
        var task = entry.task || {};
        modals['history-detail'].querySelector('[data-history-detail-title]').textContent = task.title || 'Détail de la tâche';
        modals['history-detail'].querySelector('[data-history-detail-body]').innerHTML = taskReportHtml(task, entry.logs, false);
        openModal('history-detail');
    }

    function openPrintPreview(task, logs) {
        modals.print.querySelector('[data-print-sheet]').innerHTML =
            '<div class="dmdtodo-print-header"><strong>DMD-Todolist</strong><span>Rapport généré le ' + esc(fmtDateTime(new Date().toISOString())) + '</span></div>' +
            taskReportHtml(task, logs, true);
        openModal('print');
    }

    function openPrintAll() {
        var ids = Object.keys(historyTasks).sort(function (a, b) {
            return String(historyTasks[b].last || '').localeCompare(String(historyTasks[a].last || ''));
        });
        var content = '<div class="dmdtodo-print-header"><strong>DMD-Todolist</strong><span>Historique complet · ' + esc(fmtDateTime(new Date().toISOString())) + '</span></div>';
        if (!ids.length) {
            content += '<div class="dmdtodo-empty-small">Aucune tâche.</div>';
        } else {
            ids.forEach(function (id, index) {
                var entry = historyTasks[id];
                content += '<div class="dmdtodo-print-task' + (index ? ' dmdtodo-print-page' : '') + '">' +
                    taskReportHtml(entry.task || {}, entry.logs || [], true) + '</div>';
            });
        }
        modals.print.querySelector('[data-print-sheet]').innerHTML = content;
        openModal('print');
    }

    function printCurrentPreview() {
        var sheet = modals.print ? modals.print.querySelector('[data-print-sheet]') : null;
        if (!sheet) return;

        /*
         * L'impression se fait dans un document isolé afin que le dashboard,
         * les autres modules et les popups ouvertes ne puissent jamais se
         * retrouver dans le PDF. Aucun nouvel onglet / aucune nouvelle fenêtre.
         */
        var frame = document.createElement('iframe');
        frame.setAttribute('aria-hidden', 'true');
        frame.setAttribute('tabindex', '-1');
        frame.style.position = 'fixed';
        frame.style.right = '0';
        frame.style.bottom = '0';
        frame.style.width = '1px';
        frame.style.height = '1px';
        frame.style.border = '0';
        frame.style.opacity = '0';
        frame.style.pointerEvents = 'none';
        document.body.appendChild(frame);

        var printWindow = frame.contentWindow;
        var printDocument = printWindow.document;
        var reportTitle = 'DMD-Todolist - Rapport';

        printDocument.open();
        printDocument.write('<!doctype html><html lang="fr"><head><meta charset="utf-8">' +
            '<title>' + reportTitle + '</title>' +
            '<style>' +
                '@page{size:A4 portrait;margin:12mm;}' +
                '*{box-sizing:border-box;}' +
                'html,body{margin:0;padding:0;background:#fff;color:#111;font-family:Arial,Helvetica,sans-serif;font-size:10pt;}' +
                'body{width:100%;}' +
                '.dmdtodo-print-header{display:flex;justify-content:space-between;align-items:flex-end;gap:12px;margin:0 0 12px;padding:0 0 8px;border-bottom:2px solid #222;}' +
                '.dmdtodo-print-header strong{font-size:15pt;}' +
                '.dmdtodo-print-header span{font-size:8pt;color:#555;text-align:right;}' +
                '.dmdtodo-report{display:block;}' +
                '.dmdtodo-report-title{margin:0 0 10px;padding:0 0 8px;border-bottom:1px solid #999;}' +
                '.dmdtodo-report-title small{font-size:7.5pt;color:#666;text-transform:uppercase;letter-spacing:.05em;}' +
                '.dmdtodo-report-title h2{margin:3px 0 0;font-size:17pt;line-height:1.2;}' +
                '.dmdtodo-report-section{margin:0 0 9px;padding:8px;border:1px solid #aaa;border-radius:5px;background:#fff;break-inside:avoid;page-break-inside:avoid;}' +
                '.dmdtodo-report-section>h4{margin:0 0 7px;font-size:8.5pt;text-transform:uppercase;letter-spacing:.04em;color:#555;}' +
                '.dmdtodo-report-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px;}' +
                '.dmdtodo-report-field{min-width:0;padding:5px 6px;border:1px solid #bbb;border-radius:4px;background:#fff;}' +
                '.dmdtodo-report-field span{display:block;margin-bottom:2px;font-size:6.5pt;color:#666;text-transform:uppercase;}' +
                '.dmdtodo-report-field strong{display:block;font-size:8.2pt;overflow-wrap:anywhere;}' +
                '.dmdtodo-report-text{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.4;}' +
                '.dmdtodo-report-checklist,.dmdtodo-log-list{display:grid;gap:5px;}' +
                '.dmdtodo-report-check{display:grid;grid-template-columns:20px minmax(0,1fr);gap:6px;align-items:start;padding:6px;border:1px solid #bbb;border-radius:4px;break-inside:avoid;page-break-inside:avoid;}' +
                '.dmdtodo-report-checkmark{font-weight:700;text-align:center;}' +
                '.dmdtodo-report-check>div{display:grid;gap:1px;}' +
                '.dmdtodo-report-check small{font-size:7pt;color:#666;}' +
                '.dmdtodo-log-card{display:block;margin:0 0 5px;padding:7px;border:1px solid #bbb;border-radius:4px;background:#fff;break-inside:avoid;page-break-inside:avoid;}' +
                '.dmdtodo-log-head{display:flex;justify-content:space-between;gap:10px;margin-bottom:4px;}' +
                '.dmdtodo-log-head>div{display:grid;gap:1px;}' +
                '.dmdtodo-log-head span,.dmdtodo-log-head time{font-size:7pt;color:#666;}' +
                '.dmdtodo-log-card p{margin:0 0 4px;font-size:8pt;}' +
                '.dmdtodo-log-changes{display:grid;gap:3px;}' +
                '.dmdtodo-log-changes>div{display:grid;grid-template-columns:115px minmax(0,1fr);gap:6px;padding:4px 5px;border:1px solid #ddd;border-radius:3px;font-size:7.2pt;}' +
                '.dmdtodo-log-changes span{overflow-wrap:anywhere;}' +
                '.dmdtodo-log-tech{margin-top:4px;}' +
                '.dmdtodo-log-tech summary{font-size:7pt;color:#555;}' +
                '.dmdtodo-log-tech small{display:block;margin-top:3px;font-size:6.8pt;color:#666;overflow-wrap:anywhere;}' +
                'details{display:block;}' +
                'details>summary{display:none;}' +
                'details>*{display:block !important;}' +
                '.dmdtodo-empty-small{padding:6px 0;color:#666;font-size:8pt;}' +
                '.dmdtodo-print-task{display:block;}' +
                '.dmdtodo-print-page{break-before:page;page-break-before:always;}' +
                '@media print{' +
                    'html,body{width:auto!important;height:auto!important;overflow:visible!important;}' +
                    '.dmdtodo-report-section,.dmdtodo-report-check,.dmdtodo-log-card{box-shadow:none!important;}' +
                '}' +
            '</style></head><body>' + sheet.innerHTML + '</body></html>');
        printDocument.close();

        var cleaned = false;
        var cleanup = function () {
            if (cleaned) return;
            cleaned = true;
            if (frame.parentNode) frame.parentNode.removeChild(frame);
        };

        printWindow.onafterprint = cleanup;
        printWindow.focus();
        printWindow.print();
        window.setTimeout(cleanup, 300000);
    }

    function loadHistory() {
        openModal('history');
        var list = modals.history.querySelector('[data-history-list]');
        list.innerHTML = '<div class="dmdtodo-empty-small">Chargement…</div>';
        send({action: 'logs', limit: 1000}).then(function (result) {
            renderHistory(result.logs || []);
        }).catch(function (error) {
            list.innerHTML = '<div class="dmdtodo-empty-small">Impossible de charger l’historique.</div>';
            showError(error);
        });
    }

    function send(payload) {
        return fetch(api, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            cache: 'no-store',
            body: JSON.stringify(payload)
        }).then(function (response) {
            return response.json().catch(function () {
                return {status: 'error', message: 'Réponse invalide'};
            }).then(function (json) {
                if (!response.ok || json.status !== 'ok') {
                    throw new Error(json.message || 'Erreur');
                }
                return json;
            });
        });
    }

    function reloadSoon() {
        window.setTimeout(function () { location.reload(); }, 180);
    }

    function taskFromElement(element) {
        var card = element.closest('[data-task]');
        return card ? JSON.parse(card.dataset.task) : null;
    }

    wrap.addEventListener('click', function (event) {
        var share = event.target.closest('[data-share]');
        var del = event.target.closest('[data-delete]');
        var quick = event.target.closest('[data-quick-status]');
        var card = event.target.closest('[data-task]');

        if (share) {
            event.stopPropagation();
            renderShare(taskFromElement(share));
            return;
        }

        if (del) {
            event.stopPropagation();
            if (!permissions.delete) return;
            var deleteTask = taskFromElement(del);
            if (deleteTask && confirm('Supprimer cette tâche synchronisée chez tout le monde ?')) {
                send({action: 'delete', id: deleteTask.id}).then(reloadSoon).catch(showError);
            }
            return;
        }

        if (quick) {
            event.stopPropagation();
            if (!permissions.status) return;
            var quickTask = taskFromElement(quick);
            if (quickTask) {
                send({action: 'status', id: quickTask.id, status: quickTask.status === 'done' ? 'todo' : 'done'})
                    .then(reloadSoon)
                    .catch(showError);
            }
            return;
        }

        if (card) renderView(taskFromElement(card));
    });

    var newButton = wrap.querySelector('[data-new]');
    var historyButton = wrap.querySelector('[data-history]');
    var refreshButton = wrap.querySelector('[data-refresh]');
    var searchInput = wrap.querySelector('[data-search]');
    var categoryFilter = wrap.querySelector('[data-cat-filter]');

    if (newButton) newButton.addEventListener('click', function () { openForm(null); });
    if (historyButton) historyButton.addEventListener('click', loadHistory);
    if (refreshButton) refreshButton.addEventListener('click', function () { location.reload(); });

    if (searchInput) searchInput.addEventListener('input', filterTasks);
    if (categoryFilter) categoryFilter.addEventListener('change', filterTasks);

    function filterTasks() {
        var query = searchInput ? (searchInput.value || '').toLowerCase() : '';
        var category = categoryFilter ? categoryFilter.value : '';

        Array.prototype.slice.call(wrap.querySelectorAll('[data-task]')).forEach(function (card) {
            var matchesQuery = !query || (card.dataset.search || '').indexOf(query) !== -1;
            var matchesCategory = !category || card.dataset.category === category;
            card.style.display = matchesQuery && matchesCategory ? '' : 'none';
        });
    }

    document.addEventListener('click', function (event) {
        var historyTaskButton = event.target.closest ? event.target.closest('[data-history-task-id]') : null;
        if (historyTaskButton) {
            renderHistoryDetail(historyTaskButton.dataset.historyTaskId || '');
            return;
        }

        if (permissions.print && event.target.matches('[data-history-print]') && historySelectedId && historyTasks[historySelectedId]) {
            var selected = historyTasks[historySelectedId];
            openPrintPreview(selected.task || {}, selected.logs || []);
            return;
        }

        if (permissions.print && event.target.matches('[data-history-print-all]')) {
            openPrintAll();
            return;
        }

        if (permissions.print && event.target.matches('[data-print-now]')) {
            printCurrentPreview();
            return;
        }

        if (event.target.matches('[data-close]')) {
            closeModal(event.target);
            return;
        }

        if (event.target.matches('[data-edit]') && current && (permissions.edit || permissions.status || permissions.checklist || permissions.share)) {
            openForm(current);
            return;
        }

        if (permissions.delete && event.target.matches('[data-delete-current]') && current) {
            if (confirm('Supprimer cette tâche synchronisée chez tout le monde ?')) {
                send({action: 'delete', id: current.id}).then(reloadSoon).catch(showError);
            }
            return;
        }

        if (permissions.status && event.target.matches('[data-status]') && current) {
            send({action: 'status', id: current.id, status: event.target.dataset.status})
                .then(function (result) {
                    current = result.task;
                    renderView(current);
                    reloadSoon();
                })
                .catch(showError);
            return;
        }

        if (permissions.checklist && event.target.matches('[data-check-toggle]') && current) {
            event.stopPropagation();
            var checkbox = event.target;
            checkbox.disabled = true;
            send({
                action: 'checklist_toggle',
                id: current.id,
                check_id: checkbox.dataset.checkId,
                done: checkbox.checked
            }).then(function (result) {
                current = result.task;
                renderView(current);
            }).catch(function (error) {
                checkbox.checked = !checkbox.checked;
                showError(error);
            });
        }
    });

    function addStep(text, done, id) {
        var box = modals.form.querySelector('[data-check-editor]');
        var row = document.createElement('div');
        row.className = 'dmdtodo-check-edit-row';
        var disabled = permissions.checklist ? '' : ' disabled';
        row.innerHTML = '<input type="checkbox" ' + (done ? 'checked' : '') + disabled + ' aria-label="Étape terminée">' +
            '<input class="dmdtodo-input" value="' + esc(text || '') + '" data-check-id="' + esc(id || '') + '" placeholder="Nouvelle étape"' + disabled + '>' +
            '<button type="button" class="dmdtodo-mini-btn" aria-label="Supprimer cette étape"' + disabled + '>×</button>';
        row.querySelector('button').addEventListener('click', function () { if (permissions.checklist) row.remove(); });
        box.appendChild(row);
    }

    function openForm(task) {
        current = task;
        var form = modals.form.querySelector('[data-form]');
        form.reset();
        modals.form.querySelector('[data-form-title]').textContent = task ? 'Modifier la tâche' : 'Nouvelle tâche';
        form.elements.id.value = task ? task.id : '';
        form.elements.title.value = task ? task.title : '';
        if (task && task.category) form.elements.category.value = task.category;
        form.elements.priority.value = task ? task.priority : 'normal';
        form.elements.due_date.value = task ? task.due_date : '';
        form.elements.status.value = task ? task.status : 'todo';
        form.elements.description.value = task ? task.description : '';
        form.elements.tags.value = task ? (task.tags || []).join(', ') : '';
        form.elements.comment.value = task ? task.comment : '';

        var editor = modals.form.querySelector('[data-check-editor]');
        editor.innerHTML = '';
        if (task && (task.checklist || []).length) {
            (task.checklist || []).forEach(function (item) { addStep(item.text, item.done, item.id); });
        } else {
            addStep('', false, '');
        }

        Array.prototype.slice.call(form.querySelectorAll('[name="shared_with[]"]')).forEach(function (checkbox) {
            checkbox.checked = !!(task && (task.shared_with || []).indexOf(checkbox.value) !== -1);
        });

        var isEdit = !!task;
        var genericAllowed = isEdit ? !!permissions.edit : !!permissions.create;
        ['title', 'category', 'priority', 'due_date', 'description', 'tags', 'comment'].forEach(function (name) {
            if (form.elements[name]) form.elements[name].disabled = !genericAllowed;
        });
        if (form.elements.status) form.elements.status.disabled = !permissions.status;
        Array.prototype.slice.call(form.querySelectorAll('[name="shared_with[]"]')).forEach(function (checkbox) {
            checkbox.disabled = !permissions.share;
        });
        var addButton = form.querySelector('[data-add-step]');
        if (addButton) addButton.disabled = !permissions.checklist;
        Array.prototype.slice.call(form.querySelectorAll('.dmdtodo-check-edit-row input, .dmdtodo-check-edit-row button')).forEach(function (control) {
            control.disabled = !permissions.checklist;
        });
        var submitButton = form.querySelector('[type="submit"]');
        if (submitButton) {
            submitButton.disabled = isEdit
                ? !(permissions.edit || permissions.status || permissions.checklist || permissions.share)
                : !permissions.create;
        }

        openModal('form');
    }

    var addStepButton = modals.form.querySelector('[data-add-step]');
    if (addStepButton) {
        addStepButton.addEventListener('click', function () { if (permissions.checklist) addStep('', false, ''); });
    }

    modals.form.querySelector('[data-form]').addEventListener('submit', function (event) {
        event.preventDefault();
        var form = event.currentTarget;
        var submit = form.querySelector('[type="submit"]');
        var isEdit = !!form.elements.id.value;
        if ((!isEdit && !permissions.create) || (isEdit && !(permissions.edit || permissions.status || permissions.checklist || permissions.share))) {
            return;
        }
        submit.disabled = true;

        var checklist = Array.prototype.slice.call(form.querySelectorAll('.dmdtodo-check-edit-row')).map(function (row) {
            var textInput = row.querySelector('input[data-check-id]');
            return {
                id: textInput.dataset.checkId || '',
                text: textInput.value,
                done: row.querySelector('input[type="checkbox"]').checked
            };
        }).filter(function (item) { return item.text.trim() !== ''; });

        var payload = {
            action: form.elements.id.value ? 'update' : 'create',
            id: form.elements.id.value || undefined,
            title: form.elements.title.value,
            category: form.elements.category.value,
            priority: form.elements.priority.value,
            due_date: form.elements.due_date.value,
            status: form.elements.status.value,
            description: form.elements.description.value,
            comment: form.elements.comment.value,
            tags: form.elements.tags.value.split(',').map(function (value) { return value.trim(); }).filter(Boolean),
            shared_with: Array.prototype.slice.call(form.querySelectorAll('[name="shared_with[]"]:checked')).map(function (checkbox) { return checkbox.value; }),
            checklist: checklist
        };

        send(payload).then(function () {
            closeModal(modals.form);
            reloadSoon();
        }).catch(showError).finally(function () {
            submit.disabled = false;
        });
    });

    function showError(error) {
        console.error('DMD-Todolist :', error);
        alert(error && error.message ? error.message : 'Une erreur est survenue.');
    }

    function makeDrag(win) {
        if (!win) return;
        var head = win.querySelector('.dmdtodo-window-head');
        if (!head) return;

        var startX = 0;
        var startY = 0;
        var left = 0;
        var top = 0;
        var dragging = false;
        var pointerId = null;

        head.addEventListener('pointerdown', function (event) {
            if (event.target.closest('button,input,select,textarea,a')) return;
            dragging = true;
            pointerId = event.pointerId;
            startX = event.clientX;
            startY = event.clientY;
            var rect = win.getBoundingClientRect();
            left = window.scrollX + rect.left;
            top = window.scrollY + rect.top;
            bringToFront(win);
            document.body.style.userSelect = 'none';
            if (head.setPointerCapture) {
                try { head.setPointerCapture(pointerId); } catch (e) {}
            }
            event.preventDefault();
        });

        head.addEventListener('pointermove', function (event) {
            if (!dragging || event.pointerId !== pointerId) return;
            win.style.left = Math.max(0, left + event.clientX - startX) + 'px';
            win.style.top = Math.max(0, top + event.clientY - startY) + 'px';
        });

        function stopDrag(event) {
            if (!dragging) return;
            if (event && pointerId !== null && event.pointerId !== pointerId) return;
            dragging = false;
            if (head.releasePointerCapture && pointerId !== null) {
                try { head.releasePointerCapture(pointerId); } catch (e) {}
            }
            pointerId = null;
            document.body.style.userSelect = '';
        }

        head.addEventListener('pointerup', stopDrag);
        head.addEventListener('pointercancel', stopDrag);
    }

    document.addEventListener('dmd:actionhub-action-complete', function (event) {
        var detail = event && event.detail ? event.detail : {};
        var context = detail.context || {};
        var result = detail.result || {};
        var data = result.data || {};
        if (String(context.source || '') !== 'DMD-Todolist') return;

        var task = data.task && typeof data.task === 'object' ? data.task : null;
        var uiAction = String(data.ui_action || '');

        if (uiAction === 'view' && task) {
            renderView(task);
            return;
        }
        if ((uiAction === 'edit' || uiAction === 'checklist' || uiAction === 'share') && task) {
            openForm(task);
            if (uiAction === 'checklist') {
                window.setTimeout(function () {
                    var editor = modals.form.querySelector('[data-check-editor] input[data-check-id]');
                    if (editor) editor.focus();
                }, 40);
            }
            if (uiAction === 'share') {
                var details = modals.form.querySelector('details.dmdtodo-details');
                if (details) details.open = true;
                window.setTimeout(function () {
                    var member = modals.form.querySelector('[name="shared_with[]"]');
                    if (member) member.focus();
                }, 40);
            }
            return;
        }
        if (data.reload) {
            reloadSoon();
        }
    });

    if (window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') {
        window.setTimeout(function () { window.DMDActionHub.decorate(wrap); }, 0);
    }
})();
</script>