<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('X-Content-Type-Options: nosniff');
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/DMD-Todolist_lib.php';

$email = $_SESSION['user']['email'] ?? '';
if ($email === '') {
    http_response_code(401);
    echo json_encode(array('status' => 'error', 'message' => 'Non connecté'), JSON_UNESCAPED_UNICODE);
    exit;
}

if (!dmd_user_can_use_module($email, DMD_TODO_MODULE_ID)) {
    http_response_code(403);
    echo json_encode(array('status' => 'error', 'message' => 'Accès refusé à ce module.'), JSON_UNESCAPED_UNICODE);
    exit;
}

function dmdtodo_api_require_permission($email, $permission) {
    if (dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, $permission)) {
        return;
    }

    http_response_code(403);
    echo json_encode(array(
        'status' => 'error',
        'message' => 'Permission refusée : ' . $permission,
    ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function dmdtodo_api_changed($before, $after, $field) {
    return json_encode($before[$field] ?? null) !== json_encode($after[$field] ?? null);
}

try {
    $input = json_decode((string)file_get_contents('php://input'), true);
    if (!is_array($input)) {
        throw new Exception('Requête invalide');
    }

    $action = (string)($input['action'] ?? 'create');
    list($data, $file) = dmdtodo_load($email);

    if ($file === '') {
        throw new Exception('Stockage utilisateur indisponible');
    }

    if ($action === 'logs') {
        dmdtodo_api_require_permission($email, 'history.view');
        $limit = isset($input['limit']) ? (int)$input['limit'] : 200;
        $logs = dmdtodo_read_logs($email, $limit);
        foreach ($logs as $key => $entry) {
            $logs[$key]['action_label'] = dmdtodo_log_action_label((string)($entry['action'] ?? ''));
        }
        echo json_encode(array('status' => 'ok', 'logs' => $logs), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($action === 'create') {
        dmdtodo_api_require_permission($email, 'task.create');
        $task = dmdtodo_build_task($input, array(), $email);
        if (!empty($task['shared_with'])) {
            dmdtodo_api_require_permission($email, 'task.share');
        }
        if (!empty($task['checklist'])) {
            dmdtodo_api_require_permission($email, 'task.checklist');
        }
        if ((string)($task['status'] ?? 'todo') !== 'todo') {
            dmdtodo_api_require_permission($email, 'task.status');
        }
        $data['tasks'][] = $task;

        if (!dmdtodo_json_write($file, $data)) {
            throw new Exception('Impossible d’enregistrer la tâche');
        }

        dmdtodo_sync_shared_task($task, array());
        $notifications = dmdtodo_notify_new_shares($task, array(), $email);
        dmdtodo_log_task_event($email, 'task.create', $task, array(), array(
            'shared_with' => $task['shared_with'] ?? array(),
            'notifications_sent' => $notifications,
            'changes' => dmdtodo_task_changes(array(), $task),
        ));
        echo json_encode(array('status' => 'ok', 'task' => $task, 'notifications' => $notifications), JSON_UNESCAPED_UNICODE);
        exit;
    }

    $id = (string)($input['id'] ?? '');
    if ($id === '') {
        throw new Exception('ID manquant');
    }

    $index = dmdtodo_find_task($data, $id);
    if ($index < 0) {
        throw new Exception('Tâche introuvable');
    }

    $old = $data['tasks'][$index];

    if ($action === 'delete') {
        dmdtodo_api_require_permission($email, 'task.delete');
        $group = (string)($old['shared_group_id'] ?? '');
        $notifications = dmdtodo_notify_shared_change($old, $old, $email, 'task.delete', array());
        dmdtodo_log_task_event($email, 'task.delete', $old, $old, array(
            'participants' => dmdtodo_participants($old),
            'task_snapshot' => dmdtodo_task_snapshot($old),
            'notifications_sent' => $notifications,
        ));
        dmdtodo_delete_group($group, $id, dmdtodo_participants($old));
        echo json_encode(array(
            'status' => 'ok',
            'deleted' => true,
            'shared_group_id' => $group,
            'notifications' => $notifications,
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }

    $logAction = 'task.update';
    $logDetails = array();

    if ($action === 'checklist_toggle') {
        dmdtodo_api_require_permission($email, 'task.checklist');
        $logAction = 'task.checklist';
        $checkId = (string)($input['check_id'] ?? '');
        $found = false;

        if (!isset($old['checklist']) || !is_array($old['checklist'])) {
            $old['checklist'] = array();
        }

        foreach ($old['checklist'] as $key => $item) {
            $itemId = (string)($item['id'] ?? $key);
            if ($itemId !== $checkId && (string)$key !== $checkId) {
                continue;
            }

            $done = !empty($input['done']);
            $old['checklist'][$key]['done'] = $done;
            $old['checklist'][$key]['done_by'] = $done ? $email : '';
            $old['checklist'][$key]['done_at'] = $done ? date('c') : '';
            $logDetails = array(
                'check_id' => $checkId,
                'check_text' => (string)($old['checklist'][$key]['text'] ?? ''),
                'done' => $done,
                'done_by' => $done ? $email : '',
                'done_at' => $done ? (string)($old['checklist'][$key]['done_at'] ?? date('c')) : '',
            );
            $found = true;
            break;
        }

        if (!$found) {
            throw new Exception('Étape introuvable');
        }

        $task = dmdtodo_build_task($old, $old, $email);
    } elseif ($action === 'status') {
        dmdtodo_api_require_permission($email, 'task.status');
        $logAction = 'task.status';
        $previousStatus = (string)($old['status'] ?? 'todo');
        $old['status'] = (string)($input['status'] ?? ($old['status'] ?? 'todo'));
        $task = dmdtodo_build_task($old, $old, $email);
        $logDetails = array(
            'from' => $previousStatus,
            'to' => (string)$task['status'],
            'changes' => dmdtodo_task_changes($old, $task),
        );
    } elseif ($action === 'update') {
        $task = dmdtodo_build_task($input, $old, $email);
        $changes = dmdtodo_task_changes($old, $task);
        $logDetails = array('changes' => $changes);

        $genericFields = array('title', 'description', 'comment', 'category', 'priority', 'due_date', 'tags');
        foreach ($genericFields as $field) {
            if (dmdtodo_api_changed($old, $task, $field)) {
                dmdtodo_api_require_permission($email, 'task.edit');
                break;
            }
        }
        if (dmdtodo_api_changed($old, $task, 'status')) {
            dmdtodo_api_require_permission($email, 'task.status');
        }
        if (dmdtodo_api_changed($old, $task, 'checklist')) {
            dmdtodo_api_require_permission($email, 'task.checklist');
        }
        if (dmdtodo_api_changed($old, $task, 'shared_with')) {
            dmdtodo_api_require_permission($email, 'task.share');
        }

        $oldShared = isset($old['shared_with']) && is_array($old['shared_with']) ? $old['shared_with'] : array();
        $newShared = isset($task['shared_with']) && is_array($task['shared_with']) ? $task['shared_with'] : array();
        if ($oldShared !== $newShared) {
            $logAction = 'task.share';
            $logDetails['before'] = $oldShared;
            $logDetails['after'] = $newShared;
            $logDetails['added'] = array_values(array_diff($newShared, $oldShared));
            $logDetails['removed'] = array_values(array_diff($oldShared, $newShared));
        }
    } else {
        throw new Exception('Action inconnue');
    }

    $data['tasks'][$index] = $task;

    if (!dmdtodo_json_write($file, $data)) {
        throw new Exception('Impossible d’enregistrer la modification');
    }

    if (!isset($logDetails['changes'])) {
        $logDetails['changes'] = dmdtodo_task_changes($old, $task);
    }

    dmdtodo_sync_shared_task($task, $old);
    $shareNotifications = dmdtodo_notify_new_shares($task, $old, $email);
    $newShareRecipients = dmdtodo_new_share_recipients($task, $old);
    $changeNotifications = dmdtodo_notify_shared_change(
        $task,
        $old,
        $email,
        $logAction,
        $logDetails,
        $newShareRecipients
    );

    $notifications = $shareNotifications + $changeNotifications;
    if ($notifications > 0) {
        $logDetails['notifications_sent'] = $notifications;
        $logDetails['share_notifications_sent'] = $shareNotifications;
        $logDetails['change_notifications_sent'] = $changeNotifications;
    }
    dmdtodo_log_task_event($email, $logAction, $task, $old, $logDetails);

    echo json_encode(array(
        'status' => 'ok',
        'task' => $task,
        'synced' => !empty($task['shared_group_id']),
        'notifications' => $notifications,
    ), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    if (http_response_code() < 400) {
        http_response_code(400);
    }
    echo json_encode(array(
        'status' => 'error',
        'message' => $e->getMessage(),
    ), JSON_UNESCAPED_UNICODE);
}
