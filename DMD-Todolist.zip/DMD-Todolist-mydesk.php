<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/DMD-Todolist_lib.php';

dmdtodo_require_access();

$email = (string)($_SESSION['user']['email'] ?? '');
if ($email === '') {
    echo '<section class="dtm-denied">Utilisateur non connecté.</section>';
    return;
}

list($data, $dataFile) = dmdtodo_load($email);
$settings = is_array($data['settings'] ?? null) ? $data['settings'] : dmdtodo_defaults()['settings'];
$members = dmdtodo_members($email);
$tasks = array();
$storageChanged = false;

foreach ((array)($data['tasks'] ?? array()) as $index => $storedTask) {
    $task = dmdtodo_normalize_task($storedTask);
    if (json_encode($storedTask) !== json_encode($task)) {
        $data['tasks'][$index] = $task;
        $storageChanged = true;
    }
    if ($task['status'] === 'archived' && empty($settings['show_archives'])) continue;
    $tasks[] = $task;
}

if ($storageChanged && $dataFile !== '') {
    dmdtodo_json_write($dataFile, $data);
}

$priorityWeight = array('urgent' => 4, 'high' => 3, 'normal' => 2, 'low' => 1);
usort($tasks, function ($a, $b) use ($priorityWeight) {
    $aClosed = in_array($a['status'], array('done', 'archived'), true);
    $bClosed = in_array($b['status'], array('done', 'archived'), true);
    if ($aClosed !== $bClosed) return $aClosed ? 1 : -1;
    $pa = $priorityWeight[$a['priority']] ?? 0;
    $pb = $priorityWeight[$b['priority']] ?? 0;
    if ($pa !== $pb) return $pb <=> $pa;
    $da = $a['due_date'] !== '' ? $a['due_date'] : '9999-12-31';
    $db = $b['due_date'] !== '' ? $b['due_date'] : '9999-12-31';
    return strcmp($da, $db);
});

$permissions = array(
    'create' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.create'),
    'edit' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.edit'),
    'status' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.status'),
    'checklist' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.checklist'),
    'share' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.share'),
    'delete' => dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.delete')
);

$documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? '')) ?: '';
$moduleDir = realpath(__DIR__) ?: __DIR__;
$moduleWeb = '/modules/DMD-Todolist';

if ($documentRoot !== '' && strpos(str_replace('\\', '/', $moduleDir), str_replace('\\', '/', $documentRoot)) === 0) {
    $moduleWeb = '/' . ltrim(str_replace('\\', '/', substr($moduleDir, strlen($documentRoot))), '/');
}
$moduleWeb = rtrim($moduleWeb, '/');
$baseWeb = preg_replace('~/modules/DMD-Todolist$~i', '', $moduleWeb) ?: '';

$safeUser = function_exists('dmd_safe_user_key') ? dmd_safe_user_key($email) : basename($email);
$theme = 'default';
$themeFile = DMD_TODO_ROOT . '/users/profiles/' . $safeUser . '/theme.json';

if ($safeUser !== '' && is_file($themeFile)) {
    $themeData = json_decode((string)@file_get_contents($themeFile), true);
    if (is_array($themeData) && !empty($themeData['theme'])) {
        $candidate = basename((string)$themeData['theme']);
        if (is_file(DMD_TODO_ROOT . '/theme/' . $candidate . '/style.css')) {
            $theme = $candidate;
        }
    }
}

$themeUrl = rtrim($baseWeb, '/') . '/theme/' . rawurlencode($theme) . '/style.css';
$uid = 'dtm_' . bin2hex(random_bytes(5));
$cssVer = (string)@filemtime(__DIR__ . '/DMD-Todolist-mydesk.css');
$jsVer = (string)@filemtime(__DIR__ . '/DMD-Todolist-mydesk.js');
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleWeb . '/DMD-Todolist-mydesk.css?v=' . rawurlencode($cssVer), ENT_QUOTES, 'UTF-8') ?>">

<section
    id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
    class="dtm-app"
    data-dtm-root
    data-api="<?= htmlspecialchars($moduleWeb . '/DMD-Todolist_api.php', ENT_QUOTES, 'UTF-8') ?>"
>
    <header class="dtm-head">
        <div class="dtm-brand">
            <img src="<?= htmlspecialchars($moduleWeb . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt="">
            <div>
                <strong>DMD-Todolist</strong>
                <small data-dtm-subtitle>Mes tâches</small>
            </div>
        </div>
        <div class="dtm-head-actions">
            <button type="button" class="dtm-icon-btn" data-dtm-refresh aria-label="Actualiser">↻</button>
            <?php if ($permissions['create']): ?>
            <button type="button" class="dtm-btn dtm-primary" data-dtm-new>+ Tâche</button>
            <?php endif; ?>
        </div>
    </header>

    <section class="dtm-summary">
        <article><strong data-dtm-open>0</strong><span>À faire</span></article>
        <article><strong data-dtm-progress>0</strong><span>En cours</span></article>
        <article><strong data-dtm-due>0</strong><span>Échéance proche</span></article>
        <article><strong data-dtm-done>0</strong><span>Terminées</span></article>
    </section>

    <section class="dtm-toolbar">
        <div class="dtm-search">
            <span>⌕</span>
            <input type="search" data-dtm-search placeholder="Rechercher une tâche…">
        </div>
        <div class="dtm-filter-row">
            <select data-dtm-category>
                <option value="">Toutes les catégories</option>
                <?php foreach ((array)($settings['categories'] ?? array()) as $category): ?>
                <option value="<?= htmlspecialchars((string)$category, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string)$category, ENT_QUOTES, 'UTF-8') ?></option>
                <?php endforeach; ?>
            </select>
            <select data-dtm-status>
                <option value="">Tous les statuts</option>
                <?php foreach ((array)($settings['statuses'] ?? array()) as $statusId => $statusLabel): ?>
                <option value="<?= htmlspecialchars((string)$statusId, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string)$statusLabel, ENT_QUOTES, 'UTF-8') ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </section>

    <main class="dtm-content" data-dtm-list></main>

    <section class="dtm-overlay" data-dtm-detail hidden>
        <article class="dtm-sheet">
            <header>
                <div>
                    <strong data-dtm-detail-title>Tâche</strong>
                    <small data-dtm-detail-meta>—</small>
                </div>
                <button type="button" class="dtm-icon-btn" data-dtm-detail-close>×</button>
            </header>
            <div class="dtm-sheet-body">
                <section class="dtm-detail-card">
                    <div class="dtm-detail-grid" data-dtm-detail-info></div>
                    <p class="dtm-description" data-dtm-detail-description hidden></p>
                </section>
                <section class="dtm-detail-card" data-dtm-checklist-card hidden>
                    <div class="dtm-card-title"><strong>Checklist</strong><span data-dtm-check-count></span></div>
                    <div class="dtm-checklist" data-dtm-checklist></div>
                </section>
                <section class="dtm-detail-card" data-dtm-tags-card hidden>
                    <div class="dtm-card-title"><strong>Tags</strong></div>
                    <div class="dtm-tags" data-dtm-tags></div>
                </section>
                <section class="dtm-detail-card" data-dtm-shared-card>
                    <div class="dtm-card-title">
                        <strong>Partage synchronisé</strong>
                        <?php if ($permissions['share']): ?>
                        <button type="button" class="dtm-mini-btn" data-dtm-share-edit>Gérer</button>
                        <?php endif; ?>
                    </div>
                    <div class="dtm-tags" data-dtm-shared></div>
                    <small class="dtm-share-help" data-dtm-share-help>Cette tâche n’est partagée avec personne.</small>
                </section>
            </div>
            <footer>
                <?php if ($permissions['status']): ?>
                <button type="button" class="dtm-btn" data-dtm-toggle-status>Terminer</button>
                <?php endif; ?>
                <?php if ($permissions['edit']): ?>
                <button type="button" class="dtm-btn" data-dtm-edit>Modifier</button>
                <?php endif; ?>
                <?php if ($permissions['delete']): ?>
                <button type="button" class="dtm-btn dtm-danger" data-dtm-delete>Supprimer</button>
                <?php endif; ?>
            </footer>
        </article>
    </section>

    <section class="dtm-overlay" data-dtm-editor hidden>
        <form class="dtm-sheet dtm-editor-sheet" data-dtm-form>
            <header>
                <div>
                    <strong data-dtm-form-title>Nouvelle tâche</strong>
                    <small>Création rapide MyDesk</small>
                </div>
                <button type="button" class="dtm-icon-btn" data-dtm-editor-close>×</button>
            </header>
            <div class="dtm-sheet-body">
                <input type="hidden" name="id">
                <div class="dtm-form-grid">
                    <label class="dtm-field dtm-col-2">
                        <span>Titre</span>
                        <input type="text" name="title" maxlength="180" required>
                    </label>
                    <label class="dtm-field">
                        <span>Catégorie</span>
                        <select name="category">
                            <option value="">Sans catégorie</option>
                            <?php foreach ((array)($settings['categories'] ?? array()) as $category): ?>
                            <option value="<?= htmlspecialchars((string)$category, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string)$category, ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label class="dtm-field">
                        <span>Priorité</span>
                        <select name="priority">
                            <?php foreach ((array)($settings['priorities'] ?? array()) as $priorityId => $priorityLabel): ?>
                            <option value="<?= htmlspecialchars((string)$priorityId, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string)$priorityLabel, ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label class="dtm-field">
                        <span>Statut</span>
                        <select name="status">
                            <?php foreach ((array)($settings['statuses'] ?? array()) as $statusId => $statusLabel): ?>
                            <option value="<?= htmlspecialchars((string)$statusId, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string)$statusLabel, ENT_QUOTES, 'UTF-8') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                    <label class="dtm-field">
                        <span>Échéance</span>
                        <input type="date" name="due_date">
                    </label>
                    <label class="dtm-field dtm-col-2">
                        <span>Description</span>
                        <textarea name="description" rows="4"></textarea>
                    </label>
                    <label class="dtm-field dtm-col-2">
                        <span>Tags</span>
                        <input type="text" name="tags" placeholder="travail, urgent, client">
                    </label>
                    <label class="dtm-field dtm-col-2">
                        <span>Checklist</span>
                        <textarea name="checklist" rows="5" placeholder="Une étape par ligne"></textarea>
                    </label>
                    <?php if ($permissions['share']): ?>
                    <section class="dtm-share-editor dtm-col-2">
                        <div class="dtm-card-title">
                            <strong>Partager et synchroniser avec</strong>
                            <span data-dtm-share-count>0 personne</span>
                        </div>
                        <small class="dtm-share-help">Les modifications, statuts et cases cochées seront synchronisés chez tous les participants.</small>
                        <div class="dtm-member-list" data-dtm-members>
                            <?php if (!$members): ?>
                            <div class="dtm-member-empty">Aucun autre utilisateur disponible.</div>
                            <?php endif; ?>
                            <?php foreach ($members as $member): ?>
                            <label class="dtm-member">
                                <input type="checkbox" name="shared_with[]" value="<?= htmlspecialchars((string)$member['email'], ENT_QUOTES, 'UTF-8') ?>">
                                <span>
                                    <strong><?= htmlspecialchars((string)$member['name'], ENT_QUOTES, 'UTF-8') ?></strong>
                                    <small><?= htmlspecialchars((string)$member['email'], ENT_QUOTES, 'UTF-8') ?></small>
                                </span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </section>
                    <?php endif; ?>
                </div>
                <p class="dtm-error" data-dtm-error hidden></p>
            </div>
            <footer>
                <button type="button" class="dtm-btn" data-dtm-editor-cancel>Annuler</button>
                <button type="submit" class="dtm-btn dtm-primary" data-dtm-save>Enregistrer</button>
            </footer>
        </form>
    </section>

    <div class="dtm-toast" data-dtm-toast hidden></div>
</section>

<script>
window.DMD_TODOLIST_MYDESK_BOOT = <?= json_encode(array(
    'tasks' => $tasks,
    'settings' => $settings,
    'permissions' => $permissions,
    'members' => $members,
    'user' => strtolower($email)
), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
</script>
<script src="<?= htmlspecialchars($moduleWeb . '/DMD-Todolist-mydesk.js?v=' . rawurlencode($jsVer), ENT_QUOTES, 'UTF-8') ?>"></script>
