(function(){
"use strict";
const root=document.querySelector('[data-dtm-root]');
if(!root||root.dataset.ready==='1')return;
root.dataset.ready='1';

const boot=window.DMD_TODOLIST_MYDESK_BOOT||{};
let tasks=Array.isArray(boot.tasks)?boot.tasks:[];
const settings=boot.settings||{};
const permissions=boot.permissions||{};
const members=Array.isArray(boot.members)?boot.members:[];
const api=root.dataset.api||'';
let active=null;

const $=(s,c=root)=>c.querySelector(s);
const $$=(s,c=root)=>Array.from(c.querySelectorAll(s));
const esc=v=>String(v??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[m]));
const today=()=>new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate());
const parseDate=v=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(String(v||'')))return null;const p=String(v).split('-').map(Number);return new Date(p[0],p[1]-1,p[2]);};
const statusLabel=id=>(settings.statuses||{})[id]||id||'—';
const priorityLabel=id=>(settings.priorities||{})[id]||id||'—';
const formatDate=v=>{const d=parseDate(v);return d?d.toLocaleDateString('fr-FR'):'—';};

function toast(text){
    const el=$('[data-dtm-toast]');
    el.textContent=text||'';
    el.hidden=false;
    clearTimeout(el._timer);
    el._timer=setTimeout(()=>el.hidden=true,2200);
}

async function post(payload){
    const res=await fetch(api,{
        method:'POST',
        credentials:'same-origin',
        cache:'no-store',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify(payload)
    });
    const data=await res.json().catch(()=>({status:'error',message:'Réponse invalide.'}));
    if(!res.ok||data.status!=='ok')throw new Error(data.message||`HTTP ${res.status}`);
    return data;
}

function checklistProgress(task){
    const list=Array.isArray(task.checklist)?task.checklist:[];
    if(!list.length)return null;
    const done=list.filter(x=>x.done).length;
    return {done,total:list.length,pct:Math.round(done/list.length*100)};
}

function dueState(task){
    const due=parseDate(task.due_date);
    if(!due||['done','archived'].includes(task.status))return '';
    const diff=Math.round((due-today())/86400000);
    if(diff<0)return'late';
    if(diff<=2)return'soon';
    return'';
}

function filtered(){
    const search=String($('[data-dtm-search]').value||'').trim().toLowerCase();
    const category=$('[data-dtm-category]').value||'';
    const status=$('[data-dtm-status]').value||'';
    return tasks.filter(task=>{
        if(category&&task.category!==category)return false;
        if(status&&task.status!==status)return false;
        if(!search)return true;
        const hay=[task.title,task.description,task.comment,task.category,statusLabel(task.status),priorityLabel(task.priority),(task.tags||[]).join(' '),(task.checklist||[]).map(x=>x.text).join(' ')].join(' ').toLowerCase();
        return hay.includes(search);
    });
}

function summary(){
    const now=today();
    const soonEnd=new Date(now);soonEnd.setDate(soonEnd.getDate()+2);
    $('[data-dtm-open]').textContent=String(tasks.filter(x=>!['done','archived'].includes(x.status)).length);
    $('[data-dtm-progress]').textContent=String(tasks.filter(x=>x.status==='in_progress').length);
    $('[data-dtm-done]').textContent=String(tasks.filter(x=>x.status==='done').length);
    $('[data-dtm-due]').textContent=String(tasks.filter(x=>{
        const d=parseDate(x.due_date);
        return d&&!['done','archived'].includes(x.status)&&d>=now&&d<=soonEnd;
    }).length);
    $('[data-dtm-subtitle]').textContent=`${tasks.length} tâche${tasks.length>1?'s':''}`;
}

function render(){
    summary();
    const list=filtered();
    const host=$('[data-dtm-list]');
    if(!list.length){
        host.innerHTML='<div class="dtm-empty">Aucune tâche correspondant aux filtres.</div>';
        return;
    }
    host.innerHTML='<div class="dtm-list">'+list.map(task=>{
        const progress=checklistProgress(task);
        const due=dueState(task);
        const shared=Array.isArray(task.shared_with)&&task.shared_with.length;
        const done=['done','archived'].includes(task.status);
        return `<article class="dtm-task ${done?'is-done':''}" data-dtm-task="${esc(task.id)}">
            <button type="button" class="dtm-check-btn" data-dtm-quick-status="${esc(task.id)}" aria-label="${done?'Rouvrir':'Terminer'}">${done?'✓':'○'}</button>
            <div class="dtm-task-main">
                <div class="dtm-task-top">
                    <strong class="dtm-task-title">${esc(task.title||'Sans titre')}</strong>
                    ${task.due_date?`<span class="dtm-due ${due==='late'?'is-late':due==='soon'?'is-soon':''}">${due==='late'?'Retard · ':due==='soon'?'Bientôt · ':''}${esc(formatDate(task.due_date))}</span>`:''}
                </div>
                <div class="dtm-task-meta">
                    ${task.category?`<span class="dtm-pill">${esc(task.category)}</span>`:''}
                    <span class="dtm-pill dtm-priority-${esc(task.priority)}">${esc(priorityLabel(task.priority))}</span>
                    <span class="dtm-pill">${esc(statusLabel(task.status))}</span>
                    ${shared?`<span class="dtm-pill">👥 ${shared}</span>`:''}
                </div>
                ${progress?`<span class="dtm-task-progress">Checklist ${progress.done}/${progress.total} · ${progress.pct}%</span>`:''}
            </div>
            <span class="dtm-arrow">›</span>
        </article>`;
    }).join('')+'</div>';
}

function taskById(id){
    return tasks.find(x=>String(x.id)===String(id))||null;
}

function detailInfo(task){
    return [
        ['Catégorie',task.category||'—'],
        ['Statut',statusLabel(task.status)],
        ['Priorité',priorityLabel(task.priority)],
        ['Échéance',task.due_date?formatDate(task.due_date):'Aucune'],
        ['Propriétaire',task.owner_email||task.created_by||'—'],
        ['Dernière modification',task.updated_at?new Date(task.updated_at).toLocaleString('fr-FR'):'—']
    ].map(row=>`<div class="dtm-detail-row"><span>${esc(row[0])}</span><strong>${esc(row[1])}</strong></div>`).join('');
}

function openDetail(id){
    const task=taskById(id);
    if(!task)return;
    active=task;
    $('[data-dtm-detail-title]').textContent=task.title||'Tâche';
    $('[data-dtm-detail-meta]').textContent=[task.category,statusLabel(task.status),task.due_date?`Échéance ${formatDate(task.due_date)}`:''].filter(Boolean).join(' · ');
    $('[data-dtm-detail-info]').innerHTML=detailInfo(task);

    const desc=$('[data-dtm-detail-description]');
    const text=[task.description,task.comment].filter(Boolean).join('\n\n');
    desc.hidden=!text;
    desc.textContent=text;

    const checklist=Array.isArray(task.checklist)?task.checklist:[];
    const checkCard=$('[data-dtm-checklist-card]');
    checkCard.hidden=!checklist.length;
    $('[data-dtm-check-count]').textContent=checklist.length?`${checklist.filter(x=>x.done).length}/${checklist.length}`:'';
    $('[data-dtm-checklist]').innerHTML=checklist.map(item=>`<label class="dtm-check-row ${item.done?'is-done':''}">
        <input type="checkbox" class="dtm-check-toggle" data-dtm-check-toggle="${esc(item.id)}" ${item.done?'checked':''} ${permissions.checklist?'':'disabled'}>
        <span>${esc(item.text||'')}</span>
    </label>`).join('');

    const tags=Array.isArray(task.tags)?task.tags:[];
    $('[data-dtm-tags-card]').hidden=!tags.length;
    $('[data-dtm-tags]').innerHTML=tags.map(x=>`<span class="dtm-tag">${esc(x)}</span>`).join('');

    const shared=Array.isArray(task.shared_with)?task.shared_with:[];
    const sharedHost=$('[data-dtm-shared]');
    const sharedHelp=$('[data-dtm-share-help]');
    sharedHost.innerHTML=shared.length?shared.map(email=>{
        const member=members.find(x=>String(x.email).toLowerCase()===String(email).toLowerCase());
        return `<span class="dtm-tag">${esc(member?.name||email)}</span>`;
    }).join(''):'';
    sharedHelp.hidden=shared.length>0;
    if(shared.length>0)sharedHelp.textContent='Les modifications et les cases cochées sont synchronisées pour tous les participants.';
    else sharedHelp.textContent='Cette tâche n’est partagée avec personne.';

    const toggle=$('[data-dtm-toggle-status]');
    if(toggle)toggle.textContent=task.status==='done'?'Rouvrir':'Terminer';
    $('[data-dtm-detail]').hidden=false;
}

function closeDetail(){
    $('[data-dtm-detail]').hidden=true;
    active=null;
}

function checklistLines(task){
    return (task?.checklist||[]).map(x=>x.text||'').filter(Boolean).join('\n');
}
function updateShareCount(){
    const form=$('[data-dtm-form]');
    const count=form?form.querySelectorAll('[name="shared_with[]"]:checked').length:0;
    const out=$('[data-dtm-share-count]');
    if(out)out.textContent=`${count} personne${count>1?'s':''}`;
}

function openEditor(task){
    const form=$('[data-dtm-form]');
    form.reset();
    $('[data-dtm-error]').hidden=true;
    $('[data-dtm-form-title]').textContent=task?'Modifier la tâche':'Nouvelle tâche';
    form.elements.id.value=task?.id||'';
    form.elements.title.value=task?.title||'';
    form.elements.category.value=task?.category||'';
    form.elements.priority.value=task?.priority||'normal';
    form.elements.status.value=task?.status||'todo';
    form.elements.due_date.value=task?.due_date||'';
    form.elements.description.value=task?.description||'';
    form.elements.tags.value=(task?.tags||[]).join(', ');
    form.elements.checklist.value=checklistLines(task);
    Array.from(form.querySelectorAll('[name="shared_with[]"]')).forEach(box=>{
        box.checked=!!(task&&(task.shared_with||[]).some(email=>String(email).toLowerCase()===String(box.value).toLowerCase()));
    });
    updateShareCount();
    $('[data-dtm-editor]').hidden=false;
}

function closeEditor(){
    $('[data-dtm-editor]').hidden=true;
}

function formPayload(){
    const form=$('[data-dtm-form]');
    const id=form.elements.id.value||'';
    const old=id?taskById(id):null;
    const oldChecklist=new Map((old?.checklist||[]).map(x=>[String(x.text||'').trim().toLowerCase(),x]));
    const checklist=String(form.elements.checklist.value||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean).slice(0,80).map(text=>{
        const previous=oldChecklist.get(text.toLowerCase());
        return previous?{id:previous.id,text,done:!!previous.done}:{text,done:false};
    });
    const tags=String(form.elements.tags.value||'').split(',').map(x=>x.trim()).filter(Boolean);
    return {
        action:id?'update':'create',
        id:id,
        title:form.elements.title.value||'',
        category:form.elements.category.value||'',
        priority:form.elements.priority.value||'normal',
        status:form.elements.status.value||'todo',
        due_date:form.elements.due_date.value||'',
        description:form.elements.description.value||'',
        tags:tags,
        shared_with:Array.from(form.querySelectorAll('[name="shared_with[]"]:checked')).map(box=>box.value),
        checklist:checklist
    };
}

async function save(event){
    event.preventDefault();
    const btn=$('[data-dtm-save]');
    const err=$('[data-dtm-error]');
    btn.disabled=true;
    err.hidden=true;
    try{
        const data=await post(formPayload());
        const task=data.task;
        const index=tasks.findIndex(x=>x.id===task.id);
        if(index>=0)tasks[index]=task;
        else tasks.unshift(task);
        closeEditor();
        closeDetail();
        render();
        toast(index>=0?'Tâche modifiée':'Tâche créée');
    }catch(error){
        err.textContent=error.message;
        err.hidden=false;
    }finally{
        btn.disabled=false;
    }
}

async function changeStatus(task,status){
    if(!task||!permissions.status)return;
    const data=await post({action:'status',id:task.id,status});
    const index=tasks.findIndex(x=>x.id===task.id);
    if(index>=0)tasks[index]=data.task;
    active=data.task;
    render();
}

async function quickStatus(id){
    const task=taskById(id);
    if(!task||!permissions.status)return;
    try{
        await changeStatus(task,task.status==='done'?'todo':'done');
        toast(task.status==='done'?'Tâche rouverte':'Tâche terminée');
    }catch(error){
        toast(error.message);
    }
}

async function toggleChecklist(checkId,done,input){
    if(!active||!permissions.checklist)return;
    const item=(active.checklist||[]).find(x=>String(x.id)===String(checkId));
    if(!item)return;
    if(input)input.disabled=true;
    try{
        const data=await post({action:'checklist_toggle',id:active.id,check_id:item.id,done:!!done});
        const index=tasks.findIndex(x=>x.id===active.id);
        if(index>=0)tasks[index]=data.task;
        active=data.task;
        render();
        openDetail(data.task.id);
        toast(done?'Étape cochée':'Étape rouverte');
    }catch(error){
        if(input)input.checked=!done;
        toast(error.message);
    }finally{
        if(input)input.disabled=!permissions.checklist;
    }
}

async function removeTask(){
    if(!active||!permissions.delete)return;
    if(!confirm('Supprimer cette tâche et ses copies synchronisées ?'))return;
    const id=active.id;
    try{
        await post({action:'delete',id});
        tasks=tasks.filter(x=>x.id!==id);
        closeDetail();
        render();
        toast('Tâche supprimée');
    }catch(error){
        toast(error.message);
    }
}

$('[data-dtm-search]').addEventListener('input',render);
$('[data-dtm-category]').addEventListener('change',render);
$('[data-dtm-status]').addEventListener('change',render);
$('[data-dtm-refresh]').addEventListener('click',()=>location.reload());
$('[data-dtm-new]')?.addEventListener('click',()=>openEditor(null));

$('[data-dtm-list]').addEventListener('click',event=>{
    const quick=event.target.closest('[data-dtm-quick-status]');
    if(quick){
        event.stopPropagation();
        quickStatus(quick.dataset.dtmQuickStatus);
        return;
    }
    const task=event.target.closest('[data-dtm-task]');
    if(task)openDetail(task.dataset.dtmTask);
});

$('[data-dtm-checklist]').addEventListener('change',event=>{
    const input=event.target.closest('[data-dtm-check-toggle]');
    if(input)toggleChecklist(input.dataset.dtmCheckToggle,input.checked,input);
});

$('[data-dtm-detail-close]').addEventListener('click',closeDetail);
$('[data-dtm-detail]').addEventListener('click',event=>{if(event.target===event.currentTarget)closeDetail();});
$('[data-dtm-editor]').addEventListener('click',event=>{if(event.target===event.currentTarget)closeEditor();});
$('[data-dtm-editor-close]').addEventListener('click',closeEditor);
$('[data-dtm-editor-cancel]').addEventListener('click',closeEditor);
$('[data-dtm-form]').addEventListener('submit',save);
$('[data-dtm-form]').addEventListener('change',event=>{
    if(event.target.matches('[name="shared_with[]"]'))updateShareCount();
});
$('[data-dtm-share-edit]')?.addEventListener('click',()=>{
    if(active){
        const task=active;
        closeDetail();
        openEditor(task);
        setTimeout(()=>{
            const editor=$('[data-dtm-members]');
            if(editor)editor.scrollIntoView({block:'nearest'});
        },0);
    }
});
$('[data-dtm-edit]')?.addEventListener('click',()=>{if(active){const task=active;closeDetail();openEditor(task);}});
$('[data-dtm-delete]')?.addEventListener('click',removeTask);
$('[data-dtm-toggle-status]')?.addEventListener('click',async()=>{
    if(!active)return;
    const id=active.id;
    try{
        await changeStatus(active,active.status==='done'?'todo':'done');
        openDetail(id);
    }catch(error){
        toast(error.message);
    }
});

render();
})();