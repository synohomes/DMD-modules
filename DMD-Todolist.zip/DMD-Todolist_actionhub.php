<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
require_once __DIR__ . '/DMD-Todolist_lib.php';

if (!function_exists('dmd_todolist_actionhub_find_task')) {
    function dmd_todolist_actionhub_find_task($email, $resourceId) {
        list($data, $file) = dmdtodo_load($email);
        $resourceId = trim((string)$resourceId);
        $suffix = $resourceId;
        $prefix = DMD_TODO_MODULE_ID . ':';
        if (strpos($suffix, $prefix) === 0) $suffix = substr($suffix, strlen($prefix));

        foreach ($data['tasks'] as $index => $task) {
            $resource = dmdtodo_resource($task);
            if (
                strcasecmp((string)$resource['id'], $resourceId) === 0 ||
                (string)($task['id'] ?? '') === $suffix ||
                ((string)($task['shared_group_id'] ?? '') !== '' && (string)$task['shared_group_id'] === $suffix)
            ) {
                return array('data' => $data, 'file' => $file, 'index' => $index, 'task' => $task);
            }
        }
        return null;
    }
}

if (!function_exists('dmd_todolist_actionhub_handle')) {
    function dmd_todolist_actionhub_handle(array $context) {
        $email = trim((string)($context['email'] ?? ''));
        $action = isset($context['action']) && is_array($context['action']) ? $context['action'] : array();
        $actionId = trim((string)($action['id'] ?? ''));
        $permissions = isset($action['permissions']) && is_array($action['permissions'])
            ? $action['permissions']
            : array($action['permission'] ?? 'module.view');
        $resource = isset($context['resource']) && is_array($context['resource']) ? $context['resource'] : array();
        $payload = isset($context['payload']) && is_array($context['payload']) ? $context['payload'] : array();

        if ($email === '' || $actionId === '') {
            return array('ok' => false, 'error' => 'invalid_context', 'message' => 'Contexte ActionHub invalide.');
        }

        if (!dmd_user_can_use_module($email, DMD_TODO_MODULE_ID)) {
            return array('ok' => false, 'error' => 'permission_denied', 'message' => 'Accès au module refusé.');
        }

        foreach ($permissions as $permission) {
            $permission = trim((string)$permission);
            if ($permission === '' || $permission === 'module.view' || $permission === 'use') continue;
            if (!dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, $permission)) {
                return array('ok' => false, 'error' => 'permission_denied', 'message' => 'Permission ActionHub refusée.');
            }
        }
        if ($actionId === 'task.create_list') {
            $title = trim((string)($payload['title'] ?? ''));
            $items = isset($payload['items']) && is_array($payload['items']) ? $payload['items'] : array();

            if ($title === '') {
                return array('ok' => false, 'error' => 'title_required', 'message' => 'Le titre de la liste est obligatoire.');
            }

            $checklist = array();
            foreach ($items as $item) {
                $text = trim((string)$item);
                if ($text === '') continue;
                $checklist[] = array(
                    'text' => $text,
                    'done' => false,
                );
                if (count($checklist) >= 200) break;
            }

            if (!$checklist) {
                return array('ok' => false, 'error' => 'items_required', 'message' => 'Ajoute au moins un élément à la liste.');
            }

            list($data, $file) = dmdtodo_load($email);
            if ($file === '') {
                return array('ok' => false, 'error' => 'storage_unavailable', 'message' => 'Stockage DMD-Todolist indisponible.');
            }

            $sharedWith = isset($payload['shared_with']) && is_array($payload['shared_with'])
                ? dmdtodo_clean_emails($payload['shared_with'])
                : array();

            if ($sharedWith && !dmd_user_has_module_permission($email, DMD_TODO_MODULE_ID, 'task.share')) {
                return array('ok' => false, 'error' => 'permission_denied', 'message' => 'Permission de partage refusée.');
            }

            $tags = isset($payload['tags']) ? $payload['tags'] : array();
            if (is_string($tags)) {
                $tags = preg_split('/[,;]+/', $tags);
            }

            $taskInput = array(
                'title' => $title,
                'description' => trim((string)($payload['description'] ?? '')),
                'checklist' => $checklist,
                'category' => trim((string)($payload['category'] ?? '')),
                'due_date' => trim((string)($payload['due_date'] ?? '')),
                'priority' => trim((string)($payload['priority'] ?? 'normal')),
                'tags' => is_array($tags) ? $tags : array(),
                'comment' => trim((string)($payload['comment'] ?? '')),
                'shared_with' => $sharedWith,
                'status' => 'todo',
            );

            $task = dmdtodo_build_task($taskInput, array(), $email);
            $data['tasks'][] = $task;

            if (!dmdtodo_json_write($file, $data)) {
                return array('ok' => false, 'error' => 'write_failed', 'message' => 'Impossible de créer la liste.');
            }

            dmdtodo_sync_shared_task($task, array());
            $notifications = dmdtodo_notify_new_shares($task, array(), $email);
            dmdtodo_log_task_event($email, 'task.create', $task, array(), array(
                'shared_with' => $task['shared_with'] ?? array(),
                'notifications_sent' => $notifications,
                'changes' => dmdtodo_task_changes(array(), $task),
                'message' => 'Liste créée depuis un scénario ActionHub.',
                'source' => 'actionhub_scenario',
            ));

            $eventEmitted = false;
            if (function_exists('dmd_module_event')) {
                $eventResult = dmd_module_event(DMD_TODO_MODULE_ID, 'task.create', dmdtodo_resource($task), array(
                    'email' => $email,
                    'label' => 'Liste créée par ActionHub',
                    'target' => (string)$task['title'],
                    'status' => 'success',
                    'details' => 'Création depuis un scénario ActionHub.',
                    'meta' => array('source' => 'actionhub_scenario'),
                    'log' => false,
                ));
                $eventEmitted = !empty($eventResult['activity']);
            }

            return array(
                'ok' => true,
                'message' => 'Liste « ' . (string)$task['title'] . ' » créée.',
                'event_emitted' => $eventEmitted,
                'data' => array(
                    'reload' => true,
                    'task' => $task,
                    'resource' => dmdtodo_resource($task),
                    'notifications' => $notifications,
                ),
            );
        }

        if (empty($resource['id'])) {
            return array('ok' => false, 'error' => 'invalid_context', 'message' => 'Ressource ActionHub manquante.');
        }

        $found = dmd_todolist_actionhub_find_task($email, (string)$resource['id']);
        if (!$found) {
            return array('ok' => false, 'error' => 'task_not_found', 'message' => 'Tâche introuvable.');
        }

        $data = $found['data'];
        $file = $found['file'];
        $index = (int)$found['index'];
        $task = dmdtodo_normalize_task($found['task']);

        if ($actionId === 'task.open') {
            return array('ok' => true, 'message' => 'Tâche ouverte.', 'event_emitted' => true, 'data' => array('ui_action' => 'view', 'task' => $task));
        }
        if ($actionId === 'task.edit') {
            return array('ok' => true, 'message' => 'Édition ouverte.', 'event_emitted' => true, 'data' => array('ui_action' => 'edit', 'task' => $task));
        }
        if ($actionId === 'task.checklist') {
            return array('ok' => true, 'message' => 'Checklist ouverte.', 'event_emitted' => true, 'data' => array('ui_action' => 'checklist', 'task' => $task));
        }
        if ($actionId === 'task.share') {
            return array('ok' => true, 'message' => 'Partage ouvert.', 'event_emitted' => true, 'data' => array('ui_action' => 'share', 'task' => $task));
        }

        if ($actionId === 'task.status_toggle') {
            $before = $task;
            $nextStatus = (string)($task['status'] ?? 'todo') === 'done' ? 'todo' : 'done';
            $task['status'] = $nextStatus;
            $task = dmdtodo_build_task($task, $before, $email);
            $data['tasks'][$index] = $task;
            if (!dmdtodo_json_write($file, $data)) {
                return array('ok' => false, 'error' => 'write_failed', 'message' => 'Impossible de modifier le statut.');
            }
            dmdtodo_sync_shared_task($task, $before);
            $details = array(
                'from' => (string)($before['status'] ?? 'todo'),
                'to' => (string)$task['status'],
                'changes' => dmdtodo_task_changes($before, $task),
                'message' => 'Statut modifié depuis ActionHub.',
            );
            $notifications = dmdtodo_notify_shared_change($task, $before, $email, 'task.status', $details);
            if ($notifications > 0) $details['notifications_sent'] = $notifications;
            dmdtodo_log_task_event($email, 'task.status', $task, $before, $details);
            return array(
                'ok' => true,
                'message' => $nextStatus === 'done' ? 'Tâche marquée comme terminée.' : 'Tâche rouverte.',
                'event_emitted' => true,
                'changes' => $details['changes'],
                'data' => array('reload' => true, 'task' => $task),
            );
        }

        if ($actionId === 'task.delete') {
            $group = (string)($task['shared_group_id'] ?? '');
            $details = array(
                'participants' => dmdtodo_participants($task),
                'task_snapshot' => dmdtodo_task_snapshot($task),
                'message' => 'Tâche supprimée depuis ActionHub.',
            );
            $notifications = dmdtodo_notify_shared_change($task, $task, $email, 'task.delete', $details);
            if ($notifications > 0) $details['notifications_sent'] = $notifications;
            dmdtodo_log_task_event($email, 'task.delete', $task, $task, $details);
            dmdtodo_delete_group($group, (string)($task['id'] ?? ''), dmdtodo_participants($task));
            return array(
                'ok' => true,
                'message' => 'Tâche supprimée.',
                'event_emitted' => true,
                'data' => array('reload' => true, 'deleted' => true),
            );
        }

        return array('ok' => false, 'error' => 'unsupported_action', 'message' => 'Action non prise en charge.');
    }
}
