<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/DMD-Todolist_lib.php';

dmdtodo_require_access();

$email = $_SESSION['user']['email'] ?? '';
if ($email === '') {
    http_response_code(401);
    exit('Non connecté');
}

$type = strtolower(trim((string)($_GET['type'] ?? 'logs')));
$format = strtolower(trim((string)($_GET['format'] ?? 'json')));

if (!in_array($type, array('logs', 'tasks'), true)) {
    $type = 'logs';
}
if (!in_array($format, array('json', 'csv'), true)) {
    $format = 'json';
}

if ($type === 'logs') {
    $data = dmdtodo_read_logs($email, 10000);
} else {
    list($todoData) = dmdtodo_load($email);
    $data = isset($todoData['tasks']) && is_array($todoData['tasks']) ? $todoData['tasks'] : array();
}

$stamp = date('Ymd_His');
$filename = 'DMD-Todolist_' . $type . '_' . $stamp . '.' . $format;
header('X-Content-Type-Options: nosniff');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');

if ($format === 'json') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array(
        'module' => DMD_TODO_MODULE_ID,
        'exported_at' => date('c'),
        'user' => $email,
        'type' => $type,
        'data' => $data,
    ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

header('Content-Type: text/csv; charset=utf-8');
echo "\xEF\xBB\xBF";
$out = fopen('php://output', 'w');

if ($type === 'logs') {
    fputcsv($out, array('Date', 'Action', 'Utilisateur', 'Tâche', 'ID tâche', 'Propriétaire', 'Participants', 'Détails', 'IP'), ';');
    foreach ($data as $row) {
        fputcsv($out, array(
            (string)($row['timestamp'] ?? ''),
            dmdtodo_log_action_label((string)($row['action'] ?? '')),
            (string)($row['actor_email'] ?? ''),
            (string)($row['task_title'] ?? ''),
            (string)($row['task_id'] ?? ''),
            (string)($row['owner_email'] ?? ''),
            implode(', ', is_array($row['participants'] ?? null) ? $row['participants'] : array()),
            json_encode($row['details'] ?? array(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            (string)($row['ip'] ?? ''),
        ), ';');
    }
} else {
    fputcsv($out, array('ID', 'Titre', 'Statut', 'Priorité', 'Catégorie', 'Échéance', 'Propriétaire', 'Partagée avec', 'Checklist', 'Tags', 'Créée le', 'Modifiée le', 'Description', 'Commentaire'), ';');
    foreach ($data as $task) {
        $checklist = isset($task['checklist']) && is_array($task['checklist']) ? $task['checklist'] : array();
        $done = 0;
        foreach ($checklist as $item) {
            if (!empty($item['done'])) {
                $done++;
            }
        }
        fputcsv($out, array(
            (string)($task['id'] ?? ''),
            (string)($task['title'] ?? ''),
            (string)($task['status'] ?? ''),
            (string)($task['priority'] ?? ''),
            (string)($task['category'] ?? ''),
            (string)($task['due_date'] ?? ''),
            (string)($task['owner_email'] ?? ''),
            implode(', ', is_array($task['shared_with'] ?? null) ? $task['shared_with'] : array()),
            $done . '/' . count($checklist),
            implode(', ', is_array($task['tags'] ?? null) ? $task['tags'] : array()),
            (string)($task['created_at'] ?? ''),
            (string)($task['updated_at'] ?? ''),
            (string)($task['description'] ?? ''),
            (string)($task['comment'] ?? ''),
        ), ';');
    }
}

fclose($out);
