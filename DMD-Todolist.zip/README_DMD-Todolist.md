# DMD-Todolist

**DMD-Todolist** est le module de gestion de tâches de **DoMyDesk 1.2.0**.

Il permet de gérer des tâches personnelles ou partagées directement depuis le Dashboard DoMyDesk, avec synchronisation des modifications entre utilisateurs, checklists collaboratives, notifications, historique des actions et impression des fiches au format PDF via le navigateur.

> **Version documentée : 2.0.3**  
> **DoMyDesk minimum : 1.2.0**  
> **PHP : 7.3+**  
> **Type de stockage : utilisateur**  
> **Base de données : aucune**

---

## 1. Fonctionnalités principales

DMD-Todolist permet notamment de :

- créer des tâches ;
- modifier une tâche existante ;
- supprimer une tâche ;
- définir une catégorie ;
- définir une priorité ;
- définir une échéance ;
- changer le statut d’une tâche ;
- ajouter une description ;
- ajouter un commentaire ;
- ajouter des tags ;
- créer une checklist composée de plusieurs étapes ;
- cocher ou décocher les étapes d’une checklist ;
- partager une tâche avec un ou plusieurs utilisateurs DoMyDesk ;
- synchroniser automatiquement une tâche partagée entre tous ses participants ;
- notifier un utilisateur lorsqu’une nouvelle tâche lui est partagée ;
- consulter l’historique des actions ;
- consulter une fiche détaillée d’une tâche depuis l’historique ;
- imprimer une tâche ou l’historique complet ;
- enregistrer l’impression au format PDF depuis le navigateur ;
- afficher ou masquer les tâches archivées ;
- personnaliser les catégories utilisées par le compte connecté.

---

## 2. Interface du module

La vue principale affiche un résumé compact des tâches :

- nombre de tâches **à faire** ;
- nombre de tâches **terminées** ;
- nombre de tâches **partagées** lorsque des tâches sont synchronisées.

La barre d’actions permet de :

- rechercher une tâche ;
- filtrer par catégorie ;
- créer une nouvelle tâche ;
- ouvrir l’historique ;
- recharger les tâches afin de récupérer les dernières informations synchronisées.

Les tâches non terminées sont affichées avant les tâches terminées ou archivées.

Le tri tient ensuite compte de la priorité puis de l’échéance.

---

## 3. Contenu d’une tâche

Une tâche peut contenir les informations suivantes :

| Information | Description |
|---|---|
| Titre | Nom principal de la tâche. Obligatoire. |
| Catégorie | Classement personnel de la tâche. |
| Priorité | Basse, Normale, Haute ou Urgente. |
| Échéance | Date prévue pour la réalisation. |
| Statut | À faire, En cours, En attente, Terminé ou Archivé. |
| Description | Texte détaillé décrivant la tâche. |
| Checklist | Liste d’étapes pouvant être cochées individuellement. |
| Tags | Mots-clés permettant de compléter le classement. |
| Commentaire | Note ou remarque associée à la tâche. |
| Partage | Liste des utilisateurs DoMyDesk participant à la tâche. |

Le module conserve également des informations techniques utiles à la synchronisation et à l’historique :

- identifiant unique de la tâche ;
- identifiant du groupe de partage ;
- propriétaire ;
- créateur ;
- dernier utilisateur ayant effectué une modification ;
- date de création ;
- date de dernière modification ;
- date de terminaison lorsque la tâche est terminée.

---

## 4. Statuts

Les statuts disponibles par défaut sont :

- **À faire** ;
- **En cours** ;
- **En attente** ;
- **Terminé** ;
- **Archivé**.

Une tâche terminée conserve sa date de terminaison.

Les tâches archivées sont masquées par défaut. Leur affichage peut être activé depuis la configuration personnelle du module.

---

## 5. Priorités

Les priorités disponibles sont :

- **Basse** ;
- **Normale** ;
- **Haute** ;
- **Urgente**.

Les tâches ouvertes de priorité élevée remontent naturellement dans l’affichage avant les tâches de priorité inférieure.

---

## 6. Checklist

Chaque tâche peut contenir une checklist composée de plusieurs étapes.

Pour chaque étape, DMD-Todolist conserve :

- un identifiant unique ;
- le texte de l’étape ;
- son état coché ou non coché ;
- l’utilisateur ayant coché l’étape ;
- la date et l’heure auxquelles elle a été cochée.

Dans une tâche partagée, si un participant coche une étape, cette modification est synchronisée avec les autres participants.

L’auteur de la validation reste donc identifiable dans l’historique.

---

## 7. Partage des tâches

Une tâche peut être partagée avec un ou plusieurs utilisateurs existants de DoMyDesk.

Seuls les profils réellement présents dans :

```text
users/profiles/
```

peuvent être ajoutés au partage.

Lorsqu’une tâche devient partagée, DMD-Todolist lui attribue un identifiant de groupe de synchronisation :

```text
shared_group_id
```

Cet identifiant permet de retrouver la même tâche dans les espaces des différents participants.

### Exemple

Alice crée une tâche et la partage avec Bob :

```text
Alice
  │
  ├── crée la tâche
  │
  └── partage avec Bob
          │
          ▼
        Bob
```

La tâche est alors disponible chez Alice et Bob.

Si Bob modifie la tâche ou coche une étape :

```text
Bob modifie la tâche
        │
        ▼
Synchronisation DMD-Todolist
        │
        ▼
Alice récupère la modification
```

---

## 8. Éléments synchronisés

Pour une tâche partagée, le module synchronise notamment :

- le titre ;
- la description ;
- le commentaire ;
- la catégorie ;
- la priorité ;
- l’échéance ;
- le statut ;
- les tags ;
- la checklist ;
- l’état des cases ;
- l’auteur et la date de validation d’une étape ;
- la liste des participants ;
- les principales informations de suivi de la tâche.

Le bouton de rafraîchissement du module permet de recharger l’affichage avec les données présentes dans le stockage utilisateur.

---

## 9. Suppression d’une tâche partagée

La suppression d’une tâche appartenant à un groupe partagé supprime cette tâche du stockage des participants concernés.

Cela évite qu’une ancienne copie désynchronisée reste visible chez un autre utilisateur après la suppression de la tâche commune.

---

## 10. Notifications DoMyDesk

DMD-Todolist utilise le système de notifications natif de DoMyDesk 1.2.0.

Lorsqu’un utilisateur est **nouvellement ajouté** au partage d’une tâche, il reçoit une notification DoMyDesk de type :

> **DMD-Todolist · Nouvelle tâche partagée**  
> Un utilisateur vous a partagé la tâche « Nom de la tâche ».

La notification contient également les informations permettant d’identifier le module et la tâche concernée.

### Pas de spam de notifications

Une notification n’est pas renvoyée à chaque simple modification.

Par exemple :

- cocher une case : pas de nouvelle notification de partage ;
- changer un statut : pas de nouvelle notification de partage ;
- modifier la description : pas de nouvelle notification de partage ;
- ajouter un **nouveau participant** : notification envoyée au nouveau participant.

Le partage et la synchronisation restent donc collaboratifs sans générer une notification à chaque action.

---

## 11. Historique des actions

Le bouton **Historique** ouvre une fenêtre popup interne à DMD-Todolist.

L’historique présente une **liste des tâches** connues du module.

Un clic sur une tâche ouvre sa fiche détaillée en popup avec les informations disponibles ainsi que ses actions enregistrées.

Les types d’actions journalisés comprennent notamment :

- `task.create` — tâche créée ;
- `task.update` — tâche modifiée ;
- `task.delete` — tâche supprimée ;
- `task.status` — statut modifié ;
- `task.checklist` — checklist modifiée ;
- `task.share` — partage modifié ;
- `config.update` — préférences modifiées.

---

## 12. Contenu des logs

Une entrée de log peut contenir :

- date et heure ;
- module ;
- type d’action ;
- utilisateur ayant réalisé l’action ;
- utilisateur pour lequel le journal est enregistré ;
- ID de la tâche ;
- titre de la tâche ;
- ID du groupe partagé ;
- propriétaire ;
- participants ;
- snapshot de la tâche ;
- détail des modifications ;
- anciennes et nouvelles valeurs lorsque disponibles ;
- IP à l’origine de l’action ;
- User-Agent du navigateur.

Pour une tâche partagée, les actions utiles sont journalisées chez les participants concernés afin que chacun puisse retrouver l’historique de la tâche depuis son propre compte.

---

## 13. Stockage des données

DMD-Todolist n’utilise aucune base de données.

Les données sont stockées dans le dossier du profil utilisateur.

### Tâches et préférences

```text
users/profiles/[email]/DMD-Todolist/todolist.json
```

Ce fichier contient notamment :

- les préférences personnelles ;
- les catégories ;
- l’option d’affichage des archives ;
- les tâches ;
- les informations nécessaires au partage et à la synchronisation.

### Logs

```text
users/profiles/[email]/logs/DMD-Todolist/YYYY-MM-DD.json
```

Un fichier de journal est créé par journée lorsqu’une action doit être enregistrée.

---

## 14. Protection des données

Les répertoires de données utilisés par le module sont créés à travers le Core DoMyDesk.

Le module applique notamment :

- protection HTTP des répertoires concernés ;
- permissions de répertoire adaptées au stockage privé ;
- fichiers JSON en permissions restreintes ;
- écriture JSON avec fichier temporaire puis renommage afin de limiter les fichiers partiellement écrits ;
- validation des profils avant partage ;
- contrôle d’accès au module à travers le Core DoMyDesk.

Les données privées du module ne sont pas destinées à être consultées directement par URL.

---

## 15. Historique partagé

Lorsqu’une action est effectuée sur une tâche partagée, le module identifie l’auteur réel de l’action.

Exemple :

```text
Alice partage une tâche avec Bob
Bob coche « Appeler le client »
```

Le journal d’Alice peut alors conserver l’information indiquant que l’étape a été cochée **par Bob**, et le journal de Bob contient lui aussi l’action correspondante.

Cette logique permet de conserver une traçabilité cohérente dans le cadre d’une tâche collaborative.

---

## 16. Impression et export PDF

DMD-Todolist ne propose pas d’export JSON ou CSV dans son interface utilisateur.

L’export destiné à l’utilisateur passe par une **mise en page imprimable**.

Depuis l’historique :

1. ouvrir **Historique** ;
2. sélectionner une tâche ;
3. ouvrir sa fiche complète ;
4. cliquer sur **Imprimer / PDF** ;
5. vérifier l’aperçu ;
6. lancer l’impression ;
7. choisir **Enregistrer au format PDF** dans la boîte d’impression du navigateur si un fichier PDF est souhaité.

Il est également possible d’utiliser :

**Imprimer tout / PDF**

pour produire un rapport regroupant l’historique des tâches disponibles.

### Isolation de l’impression

Le contenu à imprimer est placé dans un document d’impression isolé.

Le Dashboard DoMyDesk, les autres modules et les fenêtres popup ouvertes derrière le rapport ne doivent donc pas être intégrés au PDF.

Aucun nouvel onglet de navigation n’est nécessaire pour générer l’impression.

---

## 17. Configuration personnelle

La configuration de DMD-Todolist est accessible à travers le système de configuration des modules de DoMyDesk.

Le point d’entrée déclaré est :

```text
DMD-Todolistcfg.php
```

Chaque utilisateur peut modifier ses propres préférences.

### Catégories

Les catégories sont configurables, à raison d’une catégorie par ligne.

Catégories proposées par défaut :

```text
Perso
Pro
Courses
Maison
Administratif
```

### Archives

L’option :

```text
Afficher les tâches archivées
```

permet de réafficher les tâches ayant le statut `archived` dans la vue principale.

---

## 18. Migration depuis l’ancien Todolist

Le module utilise désormais l’identifiant et le dossier :

```text
DMD-Todolist
```

Les anciennes données sont recherchées automatiquement dans les emplacements historiques :

```text
users/profiles/[email]/todolist/todolist.json
```

et :

```text
users/profiles/[email]/todolist.json
```

Lors du premier chargement, le module peut déplacer ou recopier ces données vers :

```text
users/profiles/[email]/DMD-Todolist/todolist.json
```

Les anciens formats de configuration présents dans le JSON sont également normalisés lors du chargement.

Le manifeste conserve l’ancien identifiant :

```json
"legacy_ids": [
  "todolist"
]
```

---

## 19. Intégration DoMyDesk 1.2.0

Le manifeste du module est :

```text
dmd_module.json
```

Principales informations déclarées :

```text
ID                : DMD-Todolist
Nom               : DMD-Todolist
DoMyDesk minimum  : 1.2.0
Storage scope     : user
Default access    : everyone
Entrypoint        : DMD-Todolist.php
Config entrypoint : DMD-Todolistcfg.php
```

DMD-Todolist repose sur les services du Core DoMyDesk pour :

- les droits d’accès ;
- la localisation du dossier utilisateur ;
- la protection des dossiers privés ;
- les notifications ;
- l’intégration de la configuration du module.

---

## 20. Permissions / capacités déclarées

Le manifeste déclare les capacités suivantes :

```text
task.create
task.edit
task.delete
task.share
task.checklist
configure
history.view
history.print
```

Elles décrivent les fonctions exposées par le module et permettent son intégration au système de droits de DoMyDesk 1.2.0.

---

## 21. Structure du module

Structure principale :

```text
modules/
└── DMD-Todolist/
    ├── DMD-Todolist.php
    ├── DMD-Todolist_api.php
    ├── DMD-Todolist_lib.php
    ├── DMD-Todolistcfg.php
    ├── DMD-Todolist.css
    ├── dmd_module.json
    └── icon.png
```

### Rôle des fichiers

#### `DMD-Todolist.php`

Interface principale du module :

- liste des tâches ;
- recherche et filtres ;
- fenêtres popup ;
- création/modification ;
- checklist ;
- partage ;
- historique ;
- aperçu et impression PDF.

#### `DMD-Todolist_api.php`

API interne utilisée par l’interface pour :

- créer ;
- modifier ;
- supprimer ;
- changer le statut ;
- cocher une checklist ;
- récupérer l’historique.

#### `DMD-Todolist_lib.php`

Bibliothèque commune contenant notamment :

- gestion du stockage ;
- migration legacy ;
- normalisation des données ;
- construction des tâches ;
- partage ;
- synchronisation ;
- notifications ;
- logs ;
- lecture des utilisateurs DoMyDesk.

#### `DMD-Todolistcfg.php`

Interface des préférences personnelles du module.

#### `DMD-Todolist.css`

Mise en forme du module en utilisant l’environnement graphique DoMyDesk.

#### `dmd_module.json`

Contrat et manifeste du module DoMyDesk 1.2.0.

#### `icon.png`

Icône affichée par DoMyDesk pour identifier DMD-Todolist.

---

## 22. Dépendances

DMD-Todolist ne nécessite :

- aucune base MariaDB/MySQL ;
- aucun serveur externe ;
- aucune API Internet ;
- aucun agent installé sur les postes ;
- aucune dépendance JavaScript externe spécifique au module.

Il dépend en revanche du Core DoMyDesk 1.2.0 et de ses services PHP.

Le code prévoit également un fonctionnement sans l’extension PHP `mbstring` en utilisant des fonctions de repli lorsque celle-ci n’est pas disponible.

---

## 23. Installation

### Via le Market DoMyDesk

Le module est prévu pour utiliser le contrat strict de DoMyDesk 1.2.0.

Le ZIP d’installation doit contenir `dmd_module.json` à sa racine, ainsi que tous les fichiers déclarés dans `package.files`.

Le Market peut alors valider le manifeste avant l’installation.

### Installation manuelle

Pour une installation manuelle, placer le module dans :

```text
modules/DMD-Todolist/
```

DoMyDesk doit ensuite reconnaître le module avec l’ID :

```text
DMD-Todolist
```

> Ne pas renommer arbitrairement le dossier sans adapter l’ID et tous les chemins associés : le nom `DMD-Todolist` fait partie de l’intégration actuelle du module.

---

## 24. Mise à jour

Le manifeste utilise :

```text
preserve_on_update: true
```

Les données utilisateurs doivent donc rester séparées du package du module et être conservées lors d’une mise à jour.

Les données ne sont pas stockées dans :

```text
modules/DMD-Todolist/
```

mais dans les dossiers des profils utilisateurs.

Cela permet de remplacer le code du module sans écraser les tâches.

---

## 25. Sauvegarde

Pour sauvegarder manuellement les données DMD-Todolist d’un utilisateur, conserver au minimum :

```text
users/profiles/[email]/DMD-Todolist/
```

Pour conserver également la traçabilité :

```text
users/profiles/[email]/logs/DMD-Todolist/
```

Une sauvegarde complète du dossier utilisateur DoMyDesk inclut naturellement ces deux emplacements.

---

## 26. Dépannage

### Le module n’apparaît pas

Vérifier :

- que le dossier s’appelle bien `DMD-Todolist` ;
- que `dmd_module.json` est présent ;
- que le module est autorisé pour l’utilisateur ;
- que le module est activé dans le profil de l’utilisateur.

### Une tâche partagée n’apparaît pas chez le destinataire

Vérifier :

- que le destinataire possède un profil DoMyDesk existant ;
- que son adresse correspond exactement au dossier de profil attendu ;
- que le module est accessible sur son compte ;
- puis recharger DMD-Todolist.

### Le destinataire ne reçoit pas de notification

La notification de partage est déclenchée lorsqu’un utilisateur est **nouvellement ajouté** à la tâche.

Une tâche déjà partagée avant l’activation de cette fonction ne génère pas rétroactivement une notification.

### Les archives ont disparu

Elles sont masquées par défaut.

Activer :

```text
Afficher les tâches archivées
```

dans les préférences DMD-Todolist.

### Je veux un fichier PDF

Depuis la fiche historique :

```text
Historique → Tâche → Imprimer / PDF
```

puis choisir **Enregistrer au format PDF** comme destination dans le navigateur.

---

## 27. Comportements importants à connaître

- Une tâche personnelle reste dans le stockage de son propriétaire.
- Une tâche partagée est synchronisée entre ses participants.
- Une checklist partagée conserve l’auteur de la validation d’une étape.
- Un nouvel utilisateur ajouté au partage reçoit une notification DoMyDesk.
- Une simple modification ne renvoie pas automatiquement une notification de partage.
- La suppression d’une tâche partagée retire la tâche des participants concernés.
- Les actions sont journalisées dans les profils concernés.
- Les tâches archivées peuvent être masquées ou affichées selon les préférences personnelles.
- Les données sont stockées en JSON, sans base de données.
- L’impression PDF est effectuée côté navigateur à partir d’un document d’impression isolé.

---

## 28. Vie privée et autonomie

DMD-Todolist fonctionne directement sur l’installation DoMyDesk.

Le module n’a pas besoin d’envoyer les tâches vers un service tiers pour fonctionner.

Les tâches, checklists, commentaires, participants et logs restent dans les dossiers utilisateurs de l’instance DoMyDesk, sous le contrôle de l’administrateur de l’installation.

---

## 29. Résumé technique

```text
Module              : DMD-Todolist
Famille              : DoMyDesk
DoMyDesk minimum     : 1.2.0
Version documentée   : 2.0.3
PHP                  : 7.3+
Stockage             : JSON par utilisateur
Base de données      : Non
Partage              : Oui
Synchronisation      : Oui
Notifications        : Oui
Checklist            : Oui
Historique           : Oui
Logs                  : Oui
Impression / PDF     : Oui
Migration legacy     : Oui
Configuration user   : Oui
```

---

## 30. Note pour la distribution du README

Le package DoMyDesk 1.2.0 utilise un manifeste strict.

Si `README.md` est ajouté **à l’intérieur du ZIP d’installation du module**, il doit également être ajouté dans la liste :

```json
package.files
```

de `dmd_module.json`.

Sinon, le README peut simplement être distribué à côté du ZIP ou publié sur le dépôt du module sans modifier le package d’installation.

---

**DMD-Todolist — gestion de tâches personnelles et collaboratives pour DoMyDesk.**
