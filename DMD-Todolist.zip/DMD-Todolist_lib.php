<?php
/*
 * DMD-Todolist - bibliothèque commune
 * DoMyDesk 1.2.0 / PHP 7.3+
 */

if (!defined('DMD_TODO_MODULE_ID')) {
    define('DMD_TODO_MODULE_ID', 'DMD-Todolist');
}

if (!defined('DMD_TODO_ROOT')) {
    define('DMD_TODO_ROOT', dirname(__DIR__, 2));
}

require_once DMD_TODO_ROOT . '/core/dmd_permissions.php';

/*
 * Notifications DoMyDesk Core.
 * Le module reste fonctionnel si un ancien squelette ne fournit pas encore
 * ce service, mais DoMyDesk 1.2.0 le fournit nativement.
 */
$dmdTodoSystemServices = DMD_TODO_ROOT . '/core/dmd_system_services.php';
if (is_file($dmdTodoSystemServices)) {
    require_once $dmdTodoSystemServices;
}

if (!function_exists('dmdtodo_substr')) {
    function dmdtodo_substr($value, $start, $length) {
        $value = (string)$value;
        return function_exists('mb_substr')
            ? mb_substr($value, $start, $length, 'UTF-8')
            : substr($value, $start, $length);
    }
}

if (!function_exists('dmdtodo_lower')) {
    function dmdtodo_lower($value) {
        $value = (string)$value;
        return function_exists('mb_strtolower')
            ? mb_strtolower($value, 'UTF-8')
            : strtolower($value);
    }
}

if (!function_exists('dmdtodo_require_access')) {
    function dmdtodo_require_access($permission = 'use') {
        dmd_require_module_access(DMD_TODO_MODULE_ID, $permission);
    }
}

if (!function_exists('dmdtodo_defaults')) {
    function dmdtodo_defaults() {
        return array(
            'version' => 2,
            'settings' => array(
                'show_archives' => false,
                'categories' => array('Perso', 'Pro', 'Courses', 'Maison', 'Administratif'),
                'statuses' => array(
                    'todo' => 'À faire',
                    'in_progress' => 'En cours',
                    'waiting' => 'En attente',
                    'done' => 'Terminé',
                    'archived' => 'Archivé',
                ),
                'priorities' => array(
                    'low' => 'Basse',
                    'normal' => 'Normale',
                    'high' => 'Haute',
                    'urgent' => 'Urgente',
                ),
                'shared_defaults' => array(),
            ),
            'tasks' => array(),
        );
    }
}

if (!function_exists('dmdtodo_json_write')) {
    function dmdtodo_json_write($file, $data) {
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            return false;
        }

        $json = json_encode(
            $data,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        if ($json === false) {
            return false;
        }

        $tmp = $file . '.tmp.' . bin2hex(random_bytes(4));
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) {
            return false;
        }

        @chmod($tmp, 0640);

        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            return false;
        }

        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmdtodo_user_root')) {
    function dmdtodo_user_root($email) {
        return dmd_user_dir($email);
    }
}

if (!function_exists('dmdtodo_data_dir')) {
    function dmdtodo_data_dir($email, $create) {
        return dmd_user_module_data_dir($email, DMD_TODO_MODULE_ID, $create !== false);
    }
}

if (!function_exists('dmdtodo_logs_dir')) {
    function dmdtodo_logs_dir($email, $create = true) {
        $userRoot = dmdtodo_user_root($email);
        if ($userRoot === '') {
            return '';
        }

        $logsRoot = rtrim($userRoot, '/\\') . '/logs/';
        $moduleRoot = $logsRoot . DMD_TODO_MODULE_ID . '/';

        if ($create) {
            if (!dmd_ensure_denied_directory($logsRoot)) {
                return '';
            }
            if (!dmd_ensure_denied_directory($moduleRoot)) {
                return '';
            }
        }

        return $moduleRoot;
    }
}

if (!function_exists('dmdtodo_log_file')) {
    function dmdtodo_log_file($email, $date = '') {
        $dir = dmdtodo_logs_dir($email, true);
        if ($dir === '') {
            return '';
        }

        if (!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', (string)$date)) {
            $date = date('Y-m-d');
        }

        return rtrim($dir, '/\\') . '/' . $date . '.json';
    }
}


if (!function_exists('dmdtodo_task_snapshot')) {
    function dmdtodo_task_snapshot($task) {
        $task = is_array($task) ? $task : array();
        $keys = array(
            'id', 'shared_group_id', 'owner_email', 'created_by', 'last_changed_by',
            'title', 'description', 'comment', 'category', 'status', 'priority',
            'due_date', 'shared_with', 'tags', 'checklist', 'created_at', 'updated_at',
            'completed_at'
        );

        $snapshot = array();
        foreach ($keys as $key) {
            if (array_key_exists($key, $task)) {
                $snapshot[$key] = $task[$key];
            }
        }

        $snapshot['shared_with'] = isset($snapshot['shared_with']) && is_array($snapshot['shared_with'])
            ? array_values($snapshot['shared_with'])
            : array();
        $snapshot['tags'] = isset($snapshot['tags']) && is_array($snapshot['tags'])
            ? array_values($snapshot['tags'])
            : array();
        $snapshot['checklist'] = isset($snapshot['checklist']) && is_array($snapshot['checklist'])
            ? array_values($snapshot['checklist'])
            : array();

        return $snapshot;
    }
}

if (!function_exists('dmdtodo_task_changes')) {
    function dmdtodo_task_changes($before, $after) {
        $before = is_array($before) ? $before : array();
        $after = is_array($after) ? $after : array();

        $labels = array(
            'title' => 'Titre',
            'description' => 'Description',
            'comment' => 'Commentaire',
            'category' => 'Catégorie',
            'status' => 'Statut',
            'priority' => 'Priorité',
            'due_date' => 'Échéance',
            'tags' => 'Tags',
            'shared_with' => 'Partage',
            'checklist' => 'Checklist',
        );

        $changes = array();
        foreach ($labels as $field => $label) {
            $oldValue = $before[$field] ?? null;
            $newValue = $after[$field] ?? null;

            if (json_encode($oldValue) === json_encode($newValue)) {
                continue;
            }

            $changes[$label] = array(
                'before' => $oldValue,
                'after' => $newValue,
            );
        }

        return $changes;
    }
}

if (!function_exists('dmdtodo_resource')) {
    function dmdtodo_resource($task) {
        $task = is_array($task) ? $task : array();
        $rawId = trim((string)($task['shared_group_id'] ?? ''));
        if ($rawId === '') {
            $rawId = trim((string)($task['id'] ?? ''));
        }
        $name = trim((string)($task['title'] ?? ''));
        if ($name === '') {
            $name = 'Tâche';
        }

        return array(
            'type' => 'task',
            'id' => DMD_TODO_MODULE_ID . ':' . $rawId,
            'name' => $name,
            'module' => DMD_TODO_MODULE_ID,
        );
    }
}

if (!function_exists('dmdtodo_activity_file')) {
    function dmdtodo_activity_file($email) {
        $dir = dmdtodo_data_dir($email, true);
        return $dir !== '' ? rtrim($dir, '/\\') . '/activity.json' : '';
    }
}

if (!function_exists('dmdtodo_record_resource_activity')) {
    function dmdtodo_record_resource_activity($viewerEmail, $actorEmail, $action, $task, $details = array()) {
        if (!is_array($task) || empty($task) || !dmdtodo_existing_profile($viewerEmail)) {
            return false;
        }

        $resource = dmdtodo_resource($task);
        if (substr($resource['id'], -1) === ':') {
            return false;
        }

        $file = dmdtodo_activity_file($viewerEmail);
        if ($file === '') {
            return false;
        }

        $data = array('version' => 1, 'resources' => array());
        if (is_file($file)) {
            $decoded = json_decode((string)@file_get_contents($file), true);
            if (is_array($decoded)) {
                $data = array_merge($data, $decoded);
            }
        }
        if (!isset($data['resources']) || !is_array($data['resources'])) {
            $data['resources'] = array();
        }

        $data['resources'][$resource['id']] = array(
            'type' => $resource['type'],
            'id' => $resource['id'],
            'name' => $resource['name'],
            'module' => DMD_TODO_MODULE_ID,
            'last_action' => (string)$action,
            'actor_email' => (string)$actorEmail,
            'viewer_email' => (string)$viewerEmail,
            'updated_at' => date('c'),
            'updated_ts' => time(),
            'status' => (string)($task['status'] ?? ''),
            'details' => is_array($details) ? $details : array(),
        );

        if (count($data['resources']) > 250) {
            uasort($data['resources'], function ($a, $b) {
                return (int)($b['updated_ts'] ?? 0) <=> (int)($a['updated_ts'] ?? 0);
            });
            $data['resources'] = array_slice($data['resources'], 0, 250, true);
        }

        return dmdtodo_json_write($file, $data);
    }
}

if (!function_exists('dmdtodo_quick_session_event')) {
    function dmdtodo_quick_session_event($actorEmail, $action, $task, $details = array()) {
        $actorEmail = trim((string)$actorEmail);
        if ($actorEmail === '' || !is_array($task) || empty($task)) {
            return false;
        }

        $userRoot = dmdtodo_user_root($actorEmail);
        if ($userRoot === '') {
            return false;
        }

        $dir = rtrim($userRoot, '/\\') . '/quick-session';
        if (!is_dir($dir)) {
            return false;
        }

        $files = glob($dir . '/*.json');
        if (!is_array($files) || !$files) {
            return false;
        }

        usort($files, function ($a, $b) {
            return (int)@filemtime($b) - (int)@filemtime($a);
        });

        $resource = dmdtodo_resource($task);
        $actionLabel = dmdtodo_log_action_label($action);
        $label = $actionLabel . ' · ' . $resource['name'];

        foreach ($files as $file) {
            $qs = json_decode((string)@file_get_contents($file), true);
            if (!is_array($qs)) {
                continue;
            }
            $status = strtolower((string)($qs['status'] ?? ''));
            if (!in_array($status, array('active', 'open', 'running', 'in_progress'), true)) {
                continue;
            }
            if (!isset($qs['timeline']) || !is_array($qs['timeline'])) {
                $qs['timeline'] = array();
            }

            $qs['timeline'][] = array(
                'timestamp' => time(),
                'date_iso' => date('c'),
                'module' => DMD_TODO_MODULE_ID,
                'action' => (string)$action,
                'label' => $label,
                'target' => $resource['id'],
                'status' => 'success',
                'details' => !empty($details)
                    ? json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                    : '',
                'resource' => $resource,
            );
            $qs['updated_at'] = time();

            return dmdtodo_json_write($file, $qs);
        }

        return false;
    }
}

if (!function_exists('dmdtodo_log_event')) {
    function dmdtodo_log_event($viewerEmail, $actorEmail, $action, $task = array(), $details = array()) {
        $viewerEmail = trim((string)$viewerEmail);
        $actorEmail = trim((string)$actorEmail);
        $action = trim((string)$action);
        $task = is_array($task) ? $task : array();
        $details = is_array($details) ? $details : array();

        if ($viewerEmail === '' || $action === '' || !dmdtodo_existing_profile($viewerEmail)) {
            return false;
        }

        $file = dmdtodo_log_file($viewerEmail);
        if ($file === '') {
            return false;
        }

        $logs = array();
        if (is_file($file)) {
            $raw = @file_get_contents($file);
            $decoded = $raw !== false ? json_decode($raw, true) : null;
            if (is_array($decoded)) {
                $logs = $decoded;
            }
        }

        $logs[] = array(
            'timestamp' => date('c'),
            'module' => DMD_TODO_MODULE_ID,
            'action' => $action,
            'target' => !empty($task) ? (string)(dmdtodo_resource($task)['id'] ?? '') : DMD_TODO_MODULE_ID,
            'result' => (string)($details['result'] ?? 'success'),
            'resource' => !empty($task) ? dmdtodo_resource($task) : array(),
            'actor_email' => $actorEmail,
            'viewer_email' => $viewerEmail,
            'task_id' => (string)($task['id'] ?? ''),
            'task_title' => (string)($task['title'] ?? ''),
            'shared_group_id' => (string)($task['shared_group_id'] ?? ''),
            'owner_email' => (string)($task['owner_email'] ?? ''),
            'participants' => !empty($task) ? dmdtodo_participants($task) : array(),
            'task_snapshot' => !empty($task) ? dmdtodo_task_snapshot($task) : array(),
            'details' => $details,
            'ip' => (string)($_SERVER['REMOTE_ADDR'] ?? ''),
            'user_agent' => dmdtodo_substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 300),
        );

        return dmdtodo_json_write($file, $logs);
    }
}

if (!function_exists('dmdtodo_log_task_event')) {
    function dmdtodo_log_task_event($actorEmail, $action, $task, $oldTask = array(), $details = array()) {
        $targets = array();
        foreach (array($task, $oldTask) as $candidate) {
            if (!is_array($candidate) || empty($candidate)) {
                continue;
            }
            foreach (dmdtodo_participants($candidate) as $participant) {
                $targets[strtolower((string)$participant)] = (string)$participant;
            }
        }

        if ($actorEmail !== '') {
            $targets[strtolower((string)$actorEmail)] = (string)$actorEmail;
        }

        $written = 0;
        foreach ($targets as $target) {
            if (dmdtodo_log_event($target, $actorEmail, $action, $task, $details)) {
                $written++;
            }
            dmdtodo_record_resource_activity($target, $actorEmail, $action, $task, $details);
        }

        dmdtodo_quick_session_event($actorEmail, $action, $task, $details);
        return $written;
    }
}

if (!function_exists('dmdtodo_read_logs')) {
    function dmdtodo_read_logs($email, $limit = 200) {
        $dir = dmdtodo_logs_dir($email, false);
        if ($dir === '' || !is_dir($dir)) {
            return array();
        }

        $limit = max(1, min((int)$limit, 10000));
        $files = glob(rtrim($dir, '/\\') . '/*.json');
        if (!is_array($files)) {
            return array();
        }

        rsort($files, SORT_STRING);
        $logs = array();

        foreach ($files as $file) {
            $raw = @file_get_contents($file);
            $rows = $raw !== false ? json_decode($raw, true) : null;
            if (!is_array($rows)) {
                continue;
            }

            for ($i = count($rows) - 1; $i >= 0; $i--) {
                if (!is_array($rows[$i])) {
                    continue;
                }
                $logs[] = $rows[$i];
                if (count($logs) >= $limit) {
                    break 2;
                }
            }
        }

        return $logs;
    }
}

if (!function_exists('dmdtodo_log_action_label')) {
    function dmdtodo_log_action_label($action) {
        $labels = array(
            'task.create' => 'Tâche créée',
            'task.update' => 'Tâche modifiée',
            'task.delete' => 'Tâche supprimée',
            'task.status' => 'Statut modifié',
            'task.checklist' => 'Checklist modifiée',
            'task.share' => 'Partage modifié',
            'config.update' => 'Préférences modifiées',
        );
        return $labels[$action] ?? $action;
    }
}

if (!function_exists('dmdtodo_migrate_legacy_data')) {
    function dmdtodo_migrate_legacy_data($email, $newFile) {
        if (is_file($newFile)) {
            return true;
        }

        $userRoot = dmdtodo_user_root($email);
        if ($userRoot === '') {
            return false;
        }

        $legacyCandidates = array(
            $userRoot . 'todolist/todolist.json',
            $userRoot . 'todolist.json',
        );

        foreach ($legacyCandidates as $legacyFile) {
            if (!is_file($legacyFile)) {
                continue;
            }

            if (@rename($legacyFile, $newFile)) {
                @chmod($newFile, 0640);
                return true;
            }

            if (@copy($legacyFile, $newFile)) {
                @chmod($newFile, 0640);
                @unlink($legacyFile);
                return true;
            }
        }

        return true;
    }
}

if (!function_exists('dmdtodo_file')) {
    function dmdtodo_file($email) {
        $dir = dmdtodo_data_dir($email, true);
        if ($dir === '') {
            return '';
        }

        $file = rtrim($dir, '/\\') . '/todolist.json';
        dmdtodo_migrate_legacy_data($email, $file);
        return $file;
    }
}

if (!function_exists('dmdtodo_normalize_data')) {
    function dmdtodo_normalize_data($data) {
        $def = dmdtodo_defaults();

        if (!is_array($data)) {
            $data = $def;
        }

        if (!isset($data['settings']) || !is_array($data['settings'])) {
            $data['settings'] = array();
        }

        if (isset($data['categories']) && is_array($data['categories'])) {
            $data['settings']['categories'] = $data['categories'];
            unset($data['categories']);
        }

        if (isset($data['shared_defaults']) && is_array($data['shared_defaults'])) {
            $data['settings']['shared_defaults'] = $data['shared_defaults'];
            unset($data['shared_defaults']);
        }

        $data['version'] = 2;
        $data['settings'] = array_replace_recursive($def['settings'], $data['settings']);
        $data['tasks'] = isset($data['tasks']) && is_array($data['tasks'])
            ? array_values($data['tasks'])
            : array();

        return $data;
    }
}

if (!function_exists('dmdtodo_load')) {
    function dmdtodo_load($email) {
        $file = dmdtodo_file($email);
        if ($file === '') {
            return array(dmdtodo_defaults(), '');
        }

        if (!is_file($file)) {
            $defaults = dmdtodo_defaults();
            dmdtodo_json_write($file, $defaults);
            return array($defaults, $file);
        }

        $raw = @file_get_contents($file);
        $decoded = $raw !== false ? json_decode($raw, true) : null;
        $data = dmdtodo_normalize_data($decoded);

        // Migration ciblée uniquement si le format réellement stocké diffère.
        if (!is_array($decoded) || json_encode($decoded) !== json_encode($data)) {
            dmdtodo_json_write($file, $data);
        }

        return array($data, $file);
    }
}

if (!function_exists('dmdtodo_clean_list')) {
    function dmdtodo_clean_list($values) {
        if (!is_array($values)) {
            $values = explode(',', (string)$values);
        }

        $out = array();
        foreach ($values as $value) {
            $value = trim((string)$value);
            if ($value !== '' && !in_array($value, $out, true)) {
                $out[] = $value;
            }
        }

        return array_slice($out, 0, 80);
    }
}

if (!function_exists('dmdtodo_existing_profile')) {
    function dmdtodo_existing_profile($email) {
        $dir = dmd_user_dir($email);
        return $dir !== '' && is_dir($dir);
    }
}

if (!function_exists('dmdtodo_clean_emails')) {
    function dmdtodo_clean_emails($values) {
        $out = array();

        foreach (dmdtodo_clean_list($values) as $email) {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                continue;
            }
            if (!dmdtodo_existing_profile($email)) {
                continue;
            }
            if (!in_array($email, $out, true)) {
                $out[] = $email;
            }
        }

        return $out;
    }
}

if (!function_exists('dmdtodo_checklist_old_map')) {
    function dmdtodo_checklist_old_map($old) {
        $map = array();
        $items = isset($old['checklist']) && is_array($old['checklist']) ? $old['checklist'] : array();

        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }
            $id = (string)($item['id'] ?? $index);
            $map[$id] = $item;
        }

        return $map;
    }
}

if (!function_exists('dmdtodo_build_task')) {
    function dmdtodo_build_task($input, $old, $actorEmail) {
        if (!is_array($input)) {
            $input = array();
        }
        if (!is_array($old)) {
            $old = array();
        }

        $now = date('c');
        $title = trim((string)($input['title'] ?? ($old['title'] ?? '')));
        if ($title === '') {
            throw new Exception('Titre requis');
        }

        $oldChecklist = dmdtodo_checklist_old_map($old);
        $incomingChecklist = $input['checklist'] ?? ($old['checklist'] ?? array());
        if (!is_array($incomingChecklist)) {
            $incomingChecklist = array();
        }

        $checklist = array();
        foreach ($incomingChecklist as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            $text = trim((string)($item['text'] ?? ''));
            if ($text === '') {
                continue;
            }

            $id = trim((string)($item['id'] ?? ''));
            if ($id === '') {
                $id = 'chk_' . bin2hex(random_bytes(5));
            }

            $done = !empty($item['done']);
            $oldItem = isset($oldChecklist[$id]) && is_array($oldChecklist[$id])
                ? $oldChecklist[$id]
                : array();

            $doneBy = '';
            $doneAt = '';

            if ($done) {
                if (!empty($oldItem['done'])) {
                    $doneBy = (string)($oldItem['done_by'] ?? $actorEmail);
                    $doneAt = (string)($oldItem['done_at'] ?? $now);
                } else {
                    $doneBy = $actorEmail;
                    $doneAt = $now;
                }
            }

            $checklist[] = array(
                'id' => $id,
                'text' => dmdtodo_substr($text, 0, 220),
                'done' => $done,
                'done_by' => $doneBy,
                'done_at' => $doneAt,
            );
        }

        $owner = (string)($old['owner_email'] ?? ($old['created_by'] ?? $actorEmail));
        if ($owner === '') {
            $owner = $actorEmail;
        }

        $sharedWith = dmdtodo_clean_emails($input['shared_with'] ?? ($old['shared_with'] ?? array()));
        $sharedWith = array_values(array_filter($sharedWith, function ($mail) use ($owner) {
            return strcasecmp((string)$mail, (string)$owner) !== 0;
        }));

        $group = (string)($old['shared_group_id'] ?? ($input['shared_group_id'] ?? ''));
        if ($group === '' && !empty($sharedWith)) {
            $group = 'grp_' . bin2hex(random_bytes(10));
        }

        $statusCandidate = (string)($input['status'] ?? ($old['status'] ?? 'todo'));
        $status = in_array($statusCandidate, array('todo', 'in_progress', 'waiting', 'done', 'archived'), true)
            ? $statusCandidate
            : 'todo';

        $priorityCandidate = (string)($input['priority'] ?? ($old['priority'] ?? 'normal'));
        $priority = in_array($priorityCandidate, array('low', 'normal', 'high', 'urgent'), true)
            ? $priorityCandidate
            : 'normal';

        $dueCandidate = (string)($input['due_date'] ?? ($old['due_date'] ?? ''));
        $dueDate = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dueCandidate) ? $dueCandidate : '';

        $oldStatus = (string)($old['status'] ?? '');
        $completedAt = '';
        if ($status === 'done') {
            $completedAt = $oldStatus === 'done' && !empty($old['completed_at'])
                ? (string)$old['completed_at']
                : $now;
        }

        return array(
            'id' => (string)($old['id'] ?? ($input['id'] ?? ('task_' . bin2hex(random_bytes(8))))),
            'shared_group_id' => $group,
            'owner_email' => $owner,
            'created_by' => (string)($old['created_by'] ?? $actorEmail),
            'last_changed_by' => $actorEmail,
            'title' => dmdtodo_substr($title, 0, 180),
            'description' => dmdtodo_substr((string)($input['description'] ?? ($old['description'] ?? '')), 0, 5000),
            'comment' => dmdtodo_substr((string)($input['comment'] ?? ($old['comment'] ?? '')), 0, 5000),
            'category' => dmdtodo_substr(trim((string)($input['category'] ?? ($old['category'] ?? ''))), 0, 80),
            'status' => $status,
            'priority' => $priority,
            'due_date' => $dueDate,
            'shared_with' => $sharedWith,
            'tags' => dmdtodo_clean_list($input['tags'] ?? ($old['tags'] ?? array())),
            'checklist' => $checklist,
            'created_at' => (string)($old['created_at'] ?? $now),
            'updated_at' => $now,
            'completed_at' => $completedAt,
        );
    }
}

if (!function_exists('dmdtodo_participants')) {
    function dmdtodo_participants($task) {
        $participants = array();

        if (!empty($task['owner_email'])) {
            $participants[] = (string)$task['owner_email'];
        }

        $shared = isset($task['shared_with']) && is_array($task['shared_with'])
            ? $task['shared_with']
            : array();

        foreach ($shared as $email) {
            $participants[] = (string)$email;
        }

        return array_values(array_unique(array_filter($participants)));
    }
}


if (!function_exists('dmdtodo_new_share_recipients')) {
    function dmdtodo_new_share_recipients($task, $oldTask) {
        $newShared = isset($task['shared_with']) && is_array($task['shared_with'])
            ? dmdtodo_clean_emails($task['shared_with'])
            : array();
        $oldShared = isset($oldTask['shared_with']) && is_array($oldTask['shared_with'])
            ? dmdtodo_clean_emails($oldTask['shared_with'])
            : array();

        $oldMap = array();
        foreach ($oldShared as $mail) {
            $oldMap[strtolower((string)$mail)] = true;
        }

        $added = array();
        foreach ($newShared as $mail) {
            $key = strtolower((string)$mail);
            if ($key === '' || isset($oldMap[$key])) {
                continue;
            }
            if (!dmdtodo_existing_profile($mail)) {
                continue;
            }
            $added[] = $mail;
        }

        return array_values(array_unique($added));
    }
}

if (!function_exists('dmdtodo_notify_new_shares')) {
    function dmdtodo_notify_new_shares($task, $oldTask, $actorEmail) {
        if (!function_exists('dmd_notify_user')) {
            return 0;
        }

        $recipients = dmdtodo_new_share_recipients($task, $oldTask);
        if (!$recipients) {
            return 0;
        }

        $actorProfile = dmd_read_profile($actorEmail);
        $actorName = dmdtodo_member_display_name($actorProfile, $actorEmail);
        $taskTitle = trim((string)($task['title'] ?? ''));
        if ($taskTitle === '') {
            $taskTitle = 'Sans titre';
        }

        $sent = 0;
        foreach ($recipients as $recipient) {
            if (strcasecmp((string)$recipient, (string)$actorEmail) === 0) {
                continue;
            }

            $ok = dmd_notify_user(
                $recipient,
                'module_share',
                'DMD-Todolist · Nouvelle tâche partagée',
                $actorName . ' vous a partagé la tâche « ' . $taskTitle . ' ».',
                array(
                    'level' => 'info',
                    'action_url' => 'dashboard.php',
                    'action_label' => 'Ouvrir le dashboard',
                    'meta' => array(
                        'scope' => 'module',
                        'module' => 'DMD-Todolist',
                        'task_id' => (string)($task['id'] ?? ''),
                        'task_title' => $taskTitle,
                        'shared_group_id' => (string)($task['shared_group_id'] ?? ''),
                        'shared_by' => (string)$actorEmail,
                    ),
                )
            );

            if ($ok !== false) {
                $sent++;
            }
        }

        return $sent;
    }
}

if (!function_exists('dmdtodo_notify_shared_change')) {
    function dmdtodo_notify_shared_change($task, $oldTask, $actorEmail, $action, $details = array(), $excludeRecipients = array()) {
        if (!function_exists('dmd_notify_user')) {
            return 0;
        }

        $group = (string)($task['shared_group_id'] ?? ($oldTask['shared_group_id'] ?? ''));
        if ($group === '') {
            return 0;
        }

        $participantMap = array();
        foreach (array($task, $oldTask) as $participantSource) {
            if (!is_array($participantSource) || empty($participantSource)) {
                continue;
            }
            foreach (dmdtodo_participants($participantSource) as $participant) {
                $key = strtolower((string)$participant);
                if ($key !== '') {
                    $participantMap[$key] = (string)$participant;
                }
            }
        }
        $participants = array_values($participantMap);
        if (count($participants) < 2) {
            return 0;
        }

        $excludeMap = array();
        foreach ((array)$excludeRecipients as $mail) {
            $excludeMap[strtolower((string)$mail)] = true;
        }

        $actorProfile = dmd_read_profile($actorEmail);
        $actorName = dmdtodo_member_display_name($actorProfile, $actorEmail);
        $taskTitle = trim((string)($task['title'] ?? ($oldTask['title'] ?? '')));
        if ($taskTitle === '') {
            $taskTitle = 'Sans titre';
        }

        $title = 'DMD-Todolist · Tâche modifiée';
        $message = $actorName . ' a modifié la tâche « ' . $taskTitle . ' ».';
        $notificationType = 'module_update';

        if ($action === 'task.checklist') {
            $checkText = trim((string)($details['check_text'] ?? ''));
            $done = !empty($details['done']);
            $title = 'DMD-Todolist · Checklist modifiée';
            $message = $actorName . ' a ' . ($done ? 'coché' : 'décoché')
                . ($checkText !== '' ? ' « ' . $checkText . ' »' : ' une étape')
                . ' dans la tâche « ' . $taskTitle . ' ».';
        } elseif ($action === 'task.status') {
            $statusLabels = array(
                'todo' => 'À faire',
                'in_progress' => 'En cours',
                'waiting' => 'En attente',
                'done' => 'Terminé',
                'archived' => 'Archivé',
            );
            $to = (string)($details['to'] ?? ($task['status'] ?? ''));
            $statusLabel = $statusLabels[$to] ?? $to;
            $title = 'DMD-Todolist · Statut modifié';
            $message = $actorName . ' a passé la tâche « ' . $taskTitle . ' » au statut « ' . $statusLabel . ' ».';
        } elseif ($action === 'task.share') {
            $title = 'DMD-Todolist · Partage modifié';
            $message = $actorName . ' a modifié les participants de la tâche « ' . $taskTitle . ' ».';
        } elseif ($action === 'task.delete') {
            $title = 'DMD-Todolist · Tâche supprimée';
            $message = $actorName . ' a supprimé la tâche partagée « ' . $taskTitle . ' ».';
            $notificationType = 'module_delete';
        }

        $sent = 0;
        foreach ($participants as $recipient) {
            $recipientKey = strtolower((string)$recipient);
            if (
                $recipientKey === '' ||
                strcasecmp((string)$recipient, (string)$actorEmail) === 0 ||
                isset($excludeMap[$recipientKey]) ||
                !dmdtodo_existing_profile($recipient)
            ) {
                continue;
            }

            $ok = dmd_notify_user(
                $recipient,
                $notificationType,
                $title,
                $message,
                array(
                    'level' => 'info',
                    'action_url' => 'dashboard.php',
                    'action_label' => 'Ouvrir le dashboard',
                    'meta' => array(
                        'scope' => 'module',
                        'module' => 'DMD-Todolist',
                        'task_id' => (string)($task['id'] ?? ($oldTask['id'] ?? '')),
                        'task_title' => $taskTitle,
                        'shared_group_id' => $group,
                        'changed_by' => (string)$actorEmail,
                        'change_action' => (string)$action,
                    ),
                )
            );

            if ($ok !== false) {
                $sent++;
            }
        }

        return $sent;
    }
}

if (!function_exists('dmdtodo_sync_shared_task')) {
    function dmdtodo_sync_shared_task($task, $oldTask = array()) {
        $group = (string)($task['shared_group_id'] ?? ($oldTask['shared_group_id'] ?? ''));
        if ($group === '') {
            return 0;
        }

        $currentParticipants = dmdtodo_participants($task);
        $oldParticipants = is_array($oldTask) && !empty($oldTask) ? dmdtodo_participants($oldTask) : array();
        $currentMap = array();
        $targets = array();

        foreach ($currentParticipants as $participant) {
            $key = strtolower((string)$participant);
            if ($key === '') continue;
            $currentMap[$key] = true;
            $targets[$key] = (string)$participant;
        }
        foreach ($oldParticipants as $participant) {
            $key = strtolower((string)$participant);
            if ($key === '') continue;
            $targets[$key] = (string)$participant;
        }

        $writes = 0;
        foreach ($targets as $key => $profileEmail) {
            if (!dmdtodo_existing_profile($profileEmail)) {
                continue;
            }

            list($data, $file) = dmdtodo_load($profileEmail);
            if ($file === '') {
                continue;
            }

            $found = false;
            $changed = false;
            foreach ($data['tasks'] as $index => $existing) {
                if ((string)($existing['shared_group_id'] ?? '') !== $group) {
                    continue;
                }

                $found = true;
                if (!isset($currentMap[$key])) {
                    unset($data['tasks'][$index]);
                    $changed = true;
                    continue;
                }

                $copy = $task;
                $copy['id'] = (string)($existing['id'] ?? ($task['id'] ?? ''));
                if (json_encode($data['tasks'][$index]) !== json_encode($copy)) {
                    $data['tasks'][$index] = $copy;
                    $changed = true;
                }
            }

            if (isset($currentMap[$key]) && !$found) {
                $copy = $task;
                $copy['id'] = (string)($task['id'] ?? '');
                $data['tasks'][] = $copy;
                $changed = true;
            }

            if ($changed) {
                $data['tasks'] = array_values($data['tasks']);
                if (dmdtodo_json_write($file, $data)) {
                    $writes++;
                }
            }
        }

        return $writes;
    }
}

if (!function_exists('dmdtodo_delete_group')) {
    function dmdtodo_delete_group($group, $fallbackId, $participants = array()) {
        $targets = array();
        foreach ((array)$participants as $profileEmail) {
            $key = strtolower(trim((string)$profileEmail));
            if ($key !== '') {
                $targets[$key] = (string)$profileEmail;
            }
        }

        $sessionEmail = trim((string)($_SESSION['user']['email'] ?? ''));
        if ($sessionEmail !== '') {
            $targets[strtolower($sessionEmail)] = $sessionEmail;
        }

        $writes = 0;
        foreach ($targets as $profileEmail) {
            if (!dmdtodo_existing_profile($profileEmail)) {
                continue;
            }

            list($data, $file) = dmdtodo_load($profileEmail);
            if ($file === '' || empty($data['tasks'])) {
                continue;
            }

            $before = count($data['tasks']);
            $data['tasks'] = array_values(array_filter($data['tasks'], function ($task) use ($group, $fallbackId) {
                if ($group !== '' && (string)($task['shared_group_id'] ?? '') === $group) {
                    return false;
                }
                if ($group === '' && $fallbackId !== '' && (string)($task['id'] ?? '') === $fallbackId) {
                    return false;
                }
                return true;
            }));

            if (count($data['tasks']) !== $before && dmdtodo_json_write($file, $data)) {
                $writes++;
            }
        }

        return $writes;
    }
}

if (!function_exists('dmdtodo_find_task')) {
    function dmdtodo_find_task(&$data, $id) {
        foreach ($data['tasks'] as $index => $task) {
            if ((string)($task['id'] ?? '') === (string)$id) {
                return $index;
            }
        }
        return -1;
    }
}

if (!function_exists('dmdtodo_member_display_name')) {
    function dmdtodo_member_display_name($profile, $fallback) {
        if (!is_array($profile)) {
            return $fallback;
        }

        $first = trim((string)($profile['prenom'] ?? ($profile['first_name'] ?? ($profile['firstname'] ?? ''))));
        $last = trim((string)($profile['nom'] ?? ($profile['last_name'] ?? ($profile['lastname'] ?? ''))));
        $full = trim($first . ' ' . $last);

        if ($full !== '') {
            return $full;
        }

        foreach (array('name', 'display_name', 'username') as $key) {
            if (!empty($profile[$key])) {
                return trim((string)$profile[$key]);
            }
        }

        return $fallback;
    }
}

if (!function_exists('dmdtodo_members')) {
    function dmdtodo_members($currentEmail) {
        $profilesDir = DMD_TODO_ROOT . '/users/profiles/';
        $members = array();

        if (!is_dir($profilesDir)) {
            return $members;
        }

        $dirs = glob($profilesDir . '*', GLOB_ONLYDIR);
        if (!is_array($dirs)) {
            return $members;
        }

        foreach ($dirs as $dir) {
            $email = basename($dir);
            if (strcasecmp($email, $currentEmail) === 0) {
                continue;
            }

            $profile = dmd_read_profile($email);
            $members[] = array(
                'email' => $email,
                'name' => dmdtodo_member_display_name($profile, $email),
            );
        }

        usort($members, function ($a, $b) {
            return strcasecmp((string)$a['name'], (string)$b['name']);
        });

        return $members;
    }
}

if (!function_exists('dmdtodo_normalize_task')) {
    function dmdtodo_normalize_task($task) {
        $task = is_array($task) ? $task : array();

        if (empty($task['id'])) {
            $task['id'] = 'task_' . bin2hex(random_bytes(5));
        }

        $task['id'] = (string)$task['id'];
        $task['shared_group_id'] = (string)($task['shared_group_id'] ?? '');
        $task['title'] = trim((string)($task['title'] ?? 'Sans titre'));
        $task['description'] = (string)($task['description'] ?? '');
        $task['comment'] = (string)($task['comment'] ?? '');
        $task['category'] = (string)($task['category'] ?? '');
        $task['status'] = (string)($task['status'] ?? 'todo');
        $task['priority'] = (string)($task['priority'] ?? 'normal');
        $task['due_date'] = (string)($task['due_date'] ?? '');
        $task['shared_with'] = isset($task['shared_with']) && is_array($task['shared_with'])
            ? array_values($task['shared_with'])
            : array();
        $task['tags'] = isset($task['tags']) && is_array($task['tags'])
            ? array_values($task['tags'])
            : array();
        $task['checklist'] = isset($task['checklist']) && is_array($task['checklist'])
            ? array_values($task['checklist'])
            : array();
        $task['owner_email'] = (string)($task['owner_email'] ?? ($task['created_by'] ?? ''));
        $task['created_by'] = (string)($task['created_by'] ?? '');
        $task['last_changed_by'] = (string)($task['last_changed_by'] ?? '');
        $task['updated_at'] = (string)($task['updated_at'] ?? '');

        foreach ($task['checklist'] as $index => $item) {
            if (!is_array($item)) {
                $item = array();
            }
            $task['checklist'][$index] = array(
                'id' => (string)($item['id'] ?? ('chk_' . bin2hex(random_bytes(4)))),
                'text' => (string)($item['text'] ?? ''),
                'done' => !empty($item['done']),
                'done_by' => (string)($item['done_by'] ?? ''),
                'done_at' => (string)($item['done_at'] ?? ''),
            );
        }

        return $task;
    }
}

if (!function_exists('dmdtodo_lines')) {
    function dmdtodo_lines($text) {
        $out = array();
        $lines = preg_split('/\R+/', (string)$text);
        if (!is_array($lines)) {
            return $out;
        }

        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line !== '' && !in_array($line, $out, true)) {
                $out[] = $line;
            }
        }

        return array_slice($out, 0, 80);
    }
}
