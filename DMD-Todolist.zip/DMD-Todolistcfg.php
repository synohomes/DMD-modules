<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/DMD-Todolist_lib.php';

dmdtodo_require_access('configure');

$email = $_SESSION['user']['email'] ?? '';
if ($email === '') {
    echo '<div class="dmdtodo-alert dmdtodo-alert-error">Utilisateur non connecté.</div>';
    return;
}

list($data, $file) = dmdtodo_load($email);
$message = '';
$error = '';

if (empty($_SESSION['csrf_dmd_todolist_cfg'])) {
    $_SESSION['csrf_dmd_todolist_cfg'] = bin2hex(random_bytes(32));
}
$csrf = (string)$_SESSION['csrf_dmd_todolist_cfg'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedCsrf = (string)($_POST['csrf_token'] ?? '');
    if ($postedCsrf === '' || !hash_equals($csrf, $postedCsrf)) {
        http_response_code(403);
        $error = 'Formulaire expiré ou invalide.';
    } else {
    $categories = dmdtodo_lines($_POST['categories'] ?? '');
    if (!$categories) {
        $categories = dmdtodo_defaults()['settings']['categories'];
    }

    $data['settings']['categories'] = $categories;
    $data['settings']['show_archives'] = !empty($_POST['show_archives']);

    if (dmdtodo_json_write($file, $data)) {
        dmdtodo_log_event($email, $email, 'config.update', array(), array(
            'show_archives' => !empty($data['settings']['show_archives']),
            'categories_count' => count($data['settings']['categories']),
        ));
        $message = 'Préférences enregistrées.';
    } else {
        $error = 'Impossible d’enregistrer la configuration.';
    }
    }
}

$categories = $data['settings']['categories'];
?>
<link rel="stylesheet" href="modules/DMD-Todolist/DMD-Todolist.css?v=2.1.1">

<div class="dmdtodo dmdtodo-config">
    <?php if ($message !== ''): ?><div class="dmdtodo-alert dmdtodo-alert-ok"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <?php if ($error !== ''): ?><div class="dmdtodo-alert dmdtodo-alert-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

    <form method="post" class="dmdtodo-config-card">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
        <div class="dmdtodo-config-head">
            <div>
                <strong>Préférences personnelles</strong>
                <span>Ces réglages concernent uniquement ton compte.</span>
            </div>
        </div>

        <label class="dmdtodo-field">
            <span>Catégories</span>
            <textarea class="dmdtodo-input" name="categories" rows="8"><?= htmlspecialchars(implode("\n", $categories), ENT_QUOTES, 'UTF-8') ?></textarea>
            <small class="dmdtodo-help">Une catégorie par ligne.</small>
        </label>

        <label class="dmdtodo-toggle-row">
            <input type="checkbox" name="show_archives" value="1" <?= !empty($data['settings']['show_archives']) ? 'checked' : '' ?>>
            <span><strong>Afficher les tâches archivées</strong><small>Les archives réapparaîtront dans la liste principale.</small></span>
        </label>

        <div class="dmdtodo-storage-note">
            <strong>Stockage DoMyDesk 1.2.0</strong>
            <span>Données : users/profiles/[email]/DMD-Todolist/todolist.json</span>
            <span>Logs : users/profiles/[email]/logs/DMD-Todolist/YYYY-MM-DD.json</span>
        </div>

        <div class="dmdtodo-storage-note">
            <strong>Historique et PDF</strong>
            <span>Historique ouvre la liste des tâches. Chaque fiche peut être ouverte en popup puis imprimée ou enregistrée en PDF, sans ouvrir de nouvel onglet.</span>
        </div>

        <div class="dmdtodo-form-actions">
            <button class="dmdtodo-btn dmdtodo-btn-primary" type="submit">Enregistrer</button>
        </div>
    </form>
</div>
