<?php
/* DMD-Chess — module DoMyDesk. Ne modifie pas le Core.
 * srcdoc conserve l'exécution JS dans les fenêtres qui chargent les modules en AJAX.
 * L'API multijoueur contrôle séparément la session et les droits sur chaque requête.
 */
$chessDir = __DIR__ . '/assets/';
$chessMarkup = (string)file_get_contents($chessDir . 'view.html');
$chessStyle = (string)file_get_contents($chessDir . 'chess.css');
$chessScript = (string)file_get_contents($chessDir . 'chess.js');
$chessWorker = (string)file_get_contents($chessDir . 'chess_ai_worker.js');
$chessWorker = str_ireplace('</script', '<\/script', $chessWorker);
$chessSrcdoc = '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><style>' . $chessStyle . '</style></head><body>' . $chessMarkup . '<script type="text/plain" id="dch-ai-worker">' . $chessWorker . '</script><script>' . $chessScript . '</script></body></html>';
?>
<div class="dmd-chess-host" style="display:block;width:100%;max-width:100%;min-width:0;padding:0;margin:0;box-sizing:border-box;overflow:hidden;">
<iframe title="DMD-Chess — Échecs" loading="eager" style="display:block;box-sizing:border-box;width:100%;max-width:100%;min-width:0;min-height:0;height:1px;border:0;background:transparent;" srcdoc="<?= htmlspecialchars($chessSrcdoc, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>"></iframe>
</div>
