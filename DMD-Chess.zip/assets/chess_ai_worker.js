const UNICODE={wk:'♔',wq:'♕',wr:'♖',wb:'♗',wn:'♘',wp:'♙',bk:'♚',bq:'♛',br:'♜',bb:'♝',bn:'♞',bp:'♟'};
const VAL={p:100,n:320,b:330,r:500,q:900,k:0};
const FILES='abcdefgh';
const pos=(r,c)=>r*8+c, row=i=>i>>3,col=i=>i&7,own=p=>p?p[0]:null, enemy=c=>c==='w'?'b':'w';
const inside=(r,c)=>r>=0&&r<8&&c>=0&&c<8;
const INITIAL=['br','bn','bb','bq','bk','bb','bn','br',...Array(8).fill('bp'),...Array(32).fill(null),...Array(8).fill('wp'),'wr','wn','wb','wq','wk','wb','wn','wr'];
function fresh(){return {b:INITIAL.slice(),turn:'w',castle:'KQkq',ep:-1,half:0,full:1,last:null,history:[],snapshots:[],over:'',clocks:{w:600,b:600},clockStart:Date.now(),options:{mode:'ai',level:2,color:'w',time:600}}}
function copy(g){return {...g,b:g.b.slice(),last:g.last?g.last.slice():null,clocks:{...g.clocks}}}
function attacked(g,s,by){let r=row(s),c=col(s),b=g.b;for(let dc of [-1,1]){let pr=r+(by==='w'?1:-1),pc=c+dc;if(inside(pr,pc)&&b[pos(pr,pc)]===by+'p')return true}
for(let [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]){let nr=r+dr,nc=c+dc;if(inside(nr,nc)&&b[pos(nr,nc)]===by+'n')return true}
for(let [dr,dc] of [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]){let nr=r+dr,nc=c+dc,step=1;while(inside(nr,nc)){let p=b[pos(nr,nc)];if(p){if(own(p)===by&&(step===1&&p[1]==='k'||(dr&&dc?'bq':'rq').includes(p[1])))return true;break}nr+=dr;nc+=dc;step++}}
return false}
function inCheck(g,side){let k=g.b.indexOf(side+'k');return k<0||attacked(g,k,enemy(side))}
function pseudo(g){let moves=[],b=g.b,t=g.turn;const add=(from,to,promotion,ep=false,castle='')=>moves.push({from,to,promotion:promotion||'',ep,castle});
for(let i=0;i<64;i++){let p=b[i];if(!p||own(p)!==t)continue;let r=row(i),c=col(i),type=p[1];
if(type==='p'){let d=t==='w'?-1:1,rr=r+d,prom=rr===0||rr===7;let push=(to,ep)=>{if(prom){for(let q of ['q','r','b','n'])add(i,to,q,ep)}else add(i,to,'',ep)};
if(inside(rr,c)&&!b[pos(rr,c)]){push(pos(rr,c));let start=t==='w'?6:1;if(r===start&&!b[pos(r+2*d,c)])add(i,pos(r+2*d,c))}
for(let dc of [-1,1])if(inside(rr,c+dc)){let j=pos(rr,c+dc);if(b[j]&&own(b[j])!==t&&b[j][1]!=='k')push(j);else if(j===g.ep&&!b[j]&&b[pos(r,c+dc)]===enemy(t)+'p')push(j,true)}
}else if(type==='n'){for(let [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]){let nr=r+dr,nc=c+dc;if(inside(nr,nc)){let j=pos(nr,nc);if(!b[j]||(own(b[j])!==t&&b[j][1]!=='k'))add(i,j)}}
}else if(type==='k'){for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){if(!dr&&!dc)continue;let nr=r+dr,nc=c+dc;if(inside(nr,nc)){let j=pos(nr,nc);if(!b[j]||(own(b[j])!==t&&b[j][1]!=='k'))add(i,j)}}
let home=t==='w'?60:4,cr=t==='w'?'K':'k',cq=t==='w'?'Q':'q';if(i===home&&!inCheck(g,t)){
if(g.castle.includes(cr)&&b[home+3]===t+'r'&&!b[home+1]&&!b[home+2]&&!attacked(g,home+1,enemy(t))&&!attacked(g,home+2,enemy(t)))add(i,home+2,'',false,'K');
if(g.castle.includes(cq)&&b[home-4]===t+'r'&&!b[home-1]&&!b[home-2]&&!b[home-3]&&!attacked(g,home-1,enemy(t))&&!attacked(g,home-2,enemy(t)))add(i,home-2,'',false,'Q')}
}else{let dirs=[];if('bq'.includes(type))dirs.push([-1,-1],[-1,1],[1,-1],[1,1]);if('rq'.includes(type))dirs.push([-1,0],[1,0],[0,-1],[0,1]);for(let [dr,dc] of dirs){let nr=r+dr,nc=c+dc;while(inside(nr,nc)){let j=pos(nr,nc);if(!b[j])add(i,j);else{if(own(b[j])!==t&&b[j][1]!=='k')add(i,j);break}nr+=dr;nc+=dc}}}}
return moves}
function execute(g,m){let n=copy(g),b=n.b,p=b[m.from],captured=b[m.to];b[m.to]=p;b[m.from]=null;
if(m.ep){let at=m.to+(g.turn==='w'?8:-8);captured=b[at];b[at]=null}
if(m.promotion)b[m.to]=g.turn+m.promotion;
if(m.castle){let start=m.castle==='K'?m.from+3:m.from-4,end=m.castle==='K'?m.from+1:m.from-1;b[end]=b[start];b[start]=null}
let rights=n.castle;if(p[1]==='k')rights=rights.replace(g.turn==='w'?/[KQ]/g:/[kq]/g,'');
for(let [sq,letter] of [[63,'K'],[56,'Q'],[7,'k'],[0,'q']])if(m.from===sq||m.to===sq)rights=rights.replace(letter,'');n.castle=rights;
n.ep=p[1]==='p'&&Math.abs(m.to-m.from)===16?(m.from+m.to)/2:-1;n.half=(p[1]==='p'||captured)?0:g.half+1;if(g.turn==='b')n.full++;n.turn=enemy(g.turn);n.last=[m.from,m.to];return n}
function legal(g){return pseudo(g).filter(m=>!inCheck(execute(g,m),g.turn))}
function square(i){return FILES[col(i)]+(8-row(i))}
function notation(g,m,after){let p=g.b[m.from],name={p:'',n:'N',b:'B',r:'R',q:'Q',k:'K'}[p[1]];if(m.castle)return m.castle==='K'?'O-O':'O-O-O';let s=name;if(p[1]==='p'&&(g.b[m.to]||m.ep))s+=FILES[col(m.from)];else if(p[1]!=='p'){let peers=legal(g).filter(x=>x.to===m.to&&x.from!==m.from&&g.b[x.from]===p);if(peers.length){if(peers.some(x=>col(x.from)===col(m.from)))s+=(8-row(m.from));else s+=FILES[col(m.from)]}}
if(g.b[m.to]||m.ep)s+='x';s+=square(m.to);if(m.promotion)s+='='+m.promotion.toUpperCase();if(inCheck(after,after.turn))s+=legal(after).length?'+' :'#';return s}
function key(g){return g.b.map(p=>p||'--').join('')+'|'+g.turn+'|'+g.castle+'|'+g.ep}
function result(g){let lm=legal(g);if(!lm.length)return inCheck(g,g.turn)?`Échec et mat — ${g.turn==='w'?'Noirs':'Blancs'} gagnent`:'Pat — partie nulle';if(g.half>=100)return 'Nulle — règle des 50 coups';let pieces=g.b.filter(Boolean).filter(p=>p[1]!=='k');if(!pieces.length||pieces.length===1&&'bn'.includes(pieces[0][1]))return 'Nulle — matériel insuffisant';if(g.snapshots){let count=1,k=key(g);for(let h of g.snapshots)if(h.position===k)count++;if(count>=3)return 'Nulle — triple répétition'}return ''}
function evaluate(g){let score=0;for(let i=0;i<64;i++){let p=g.b[i];if(!p)continue;let v=VAL[p[1]],r=row(i),c=col(i);let center=3.5-Math.abs(3.5-c)+3.5-Math.abs(3.5-r);if(p[1]==='p')v+=(p[0]==='w'?6-r:r-1)*9;if('nb'.includes(p[1]))v+=center*5;if(p[1]==='k'&&g.full<25)v-=center*4;score+=(p[0]===g.turn?1:-1)*v}return score}
function search(g,depth,alpha,beta){let moves=legal(g);if(!moves.length)return inCheck(g,g.turn)?-100000-depth:0;if(depth<=0)return evaluate(g);let best=-Infinity;for(let m of moves){let n=execute(g,m),s=-search(n,depth-1,-beta,-alpha);if(s>best)best=s;if(s>alpha)alpha=s;if(alpha>=beta)break}return best}
function aiMove(g,level){let ms=legal(g);if(!ms.length)return null;let lv=Number(level)||1;if(lv===1)return ms[Math.floor(Math.random()*ms.length)];let depth=lv<=2?1:lv===3?2:lv===4?2:3;let ordered=ms.map(m=>({m,priority:(g.b[m.to]?VAL[g.b[m.to][1]]:0)+(m.promotion?800:0)+Math.random()*3})).sort((a,b)=>b.priority-a.priority).map(x=>x.m);let scores=ordered.map(m=>({m,s:-search(execute(g,m),depth-1,-Infinity,Infinity)}));scores.sort((a,b)=>b.s-a.s);if(lv===2){let pool=scores.filter(x=>x.s>=scores[0].s-170).slice(0,Math.min(5,scores.length));return pool[Math.floor(Math.random()*pool.length)].m}return scores[0].m}

let nodes=0, deadline=0, aborted=false, cache=new Map();
const PST={
 p:[0,0,0,0,0,0,0,0,5,10,10,-20,-20,10,10,5,5,-5,-10,0,0,-10,-5,5,0,0,0,20,20,0,0,0,5,5,10,25,25,10,5,5,10,10,20,30,30,20,10,10,50,50,50,50,50,50,50,50,0,0,0,0,0,0,0,0],
 n:[-50,-40,-30,-30,-30,-30,-40,-50,-40,-20,0,0,0,0,-20,-40,-30,0,10,15,15,10,0,-30,-30,5,15,20,20,15,5,-30,-30,0,15,20,20,15,0,-30,-30,5,10,15,15,10,5,-30,-40,-20,0,5,5,0,-20,-40,-50,-40,-30,-30,-30,-30,-40,-50],
 b:[-20,-10,-10,-10,-10,-10,-10,-20,-10,0,0,0,0,0,0,-10,-10,0,5,10,10,5,0,-10,-10,5,5,10,10,5,5,-10,-10,0,10,10,10,10,0,-10,-10,10,10,10,10,10,10,-10,-10,5,0,0,0,0,5,-10,-20,-10,-10,-10,-10,-10,-10,-20],
 r:[0,0,0,5,5,0,0,0,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,-5,0,0,0,0,0,0,-5,5,10,10,10,10,10,10,5,0,0,0,0,0,0,0,0],
 q:[-20,-10,-10,-5,-5,-10,-10,-20,-10,0,0,0,0,0,0,-10,-10,0,5,5,5,5,0,-10,-5,0,5,5,5,5,0,-5,0,0,5,5,5,5,0,-5,-10,5,5,5,5,5,0,-10,-10,0,5,0,0,0,0,-10,-20,-10,-10,-5,-5,-10,-10,-20]
};
function valPosition(g){let total=0, phase=0;for(const p of g.b)if(p)phase+=({q:4,r:2,b:1,n:1}[p[1]]||0);for(let i=0;i<64;i++){const p=g.b[i];if(!p)continue;const c=p[0],t=p[1],idx=c==='w'?i:63-i;let v=VAL[t]+(PST[t]?.[idx]||0);if(t==='p'){let rank=c==='w'?6-row(i):row(i)-1;v+=rank*rank*2}if(t==='k'){const centre=3.5-Math.abs(col(i)-3.5)+3.5-Math.abs(row(i)-3.5);v+=phase<=6?centre*12:-centre*9;}total+=(c===g.turn?1:-1)*v;}return total}
function moveSort(g,m){let target=g.b[m.to];return (target?10*VAL[target[1]]-VAL[g.b[m.from][1]]:0)+(m.promotion?VAL[m.promotion]+1000:0)+(m.ep?1050:0)}
function tactical(g,m){return g.b[m.to]||m.ep||m.promotion}
function qsearch(g,alpha,beta,depth){if(++nodes%512===0&&Date.now()>deadline)throw Error('budget');let check=inCheck(g,g.turn);let stand=valPosition(g);if(!check){if(stand>=beta)return beta;if(stand>alpha)alpha=stand;if(depth<=0)return alpha}if(depth < -4)return stand;
let ms=legal(g);if(!ms.length)return check?-90000:0;ms=ms.filter(m=>check||tactical(g,m)).sort((a,b)=>moveSort(g,b)-moveSort(g,a));for(const m of ms){let v=-qsearch(execute(g,m),-beta,-alpha,depth-1);if(v>=beta)return beta;if(v>alpha)alpha=v;}return alpha}
function negamax(g,depth,alpha,beta,ply){if(++nodes%512===0&&Date.now()>deadline)throw Error('budget');const check=inCheck(g,g.turn);if(depth<=0)return qsearch(g,alpha,beta,0);let ms=legal(g);if(!ms.length)return check?-90000+ply:0;if(g.half>=100)return 0;let ky=key(g);let entry=cache.get(ky);if(entry&&entry.depth>=depth){if(entry.flag==='exact')return entry.value;if(entry.flag==='low')alpha=Math.max(alpha,entry.value);if(entry.flag==='high')beta=Math.min(beta,entry.value);if(alpha>=beta)return entry.value}
let prevAlpha=alpha,best=-Infinity,bestMove=null;ms.sort((a,b)=>(entry?.move&&a.from===entry.move.from&&a.to===entry.move.to?100000:moveSort(g,a))-(entry?.move&&b.from===entry.move.from&&b.to===entry.move.to?100000:moveSort(g,b)));ms.reverse();for(const m of ms){let v=-negamax(execute(g,m),depth-1,-beta,-alpha,ply+1);if(v>best){best=v;bestMove=m}alpha=Math.max(alpha,v);if(alpha>=beta)break}if(cache.size>160000)cache.clear();cache.set(ky,{depth,value:best,flag:best<=prevAlpha?'high':best>=beta?'low':'exact',move:bestMove});return best}
function choose(g,level){const ms=legal(g);if(!ms.length)return null;let lv=Math.max(1,Math.min(5,Number(level)||1));if(lv===1)return ms[Math.floor(Math.random()*ms.length)];const limits={2:180,3:500,4:1400,5:3200};const depths={2:2,3:4,4:6,5:9};deadline=Date.now()+limits[lv];nodes=0;let best=ms[0],resultDepth=0,score=0;for(let d=1;d<=depths[lv];d++){let sorted=ms.slice().sort((a,b)=>moveSort(g,b)-moveSort(g,a));if(best)sorted.sort((a,b)=>(a.from===best.from&&a.to===best.to?-1:b.from===best.from&&b.to===best.to?1:0));let highest=-Infinity,chosen=best;try{for(const m of sorted){let val=-negamax(execute(g,m),d-1,-Infinity,Infinity,1);if(val>highest){highest=val;chosen=m}}best=chosen;resultDepth=d;score=highest;if(Math.abs(score)>80000)break;}catch(e){if(e.message!=='budget')throw e;break;}if(Date.now()>deadline)break}return {move:best,depth:resultDepth,score,nodes}}
onmessage=(event)=>{const data=event.data;try{if(data?.action!=='think')return;const result=choose(data.game,data.level);postMessage({id:data.id,ok:true,...result})}catch(e){postMessage({id:data.id,ok:false,error:String(e.message||e)})}}
