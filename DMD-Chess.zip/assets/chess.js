/* DMD-Chess — moteur local indépendant, sans réseau ni SQL. */
(function(){'use strict';
const S='DMD-Chess:game:v1', P='DMD-Chess:prefs:v1';
const UNICODE={wk:'♔',wq:'♕',wr:'♖',wb:'♗',wn:'♘',wp:'♙',bk:'♚',bq:'♛',br:'♜',bb:'♝',bn:'♞',bp:'♟'};
const VAL={p:100,n:320,b:330,r:500,q:900,k:0};
const FILES='abcdefgh';
const pos=(r,c)=>r*8+c, row=i=>i>>3,col=i=>i&7,own=p=>p?p[0]:null, enemy=c=>c==='w'?'b':'w';
const inside=(r,c)=>r>=0&&r<8&&c>=0&&c<8;
const INITIAL=['br','bn','bb','bq','bk','bb','bn','br',...Array(8).fill('bp'),...Array(32).fill(null),...Array(8).fill('wp'),'wr','wn','wb','wq','wk','wb','wn','wr'];
function fresh(){return {b:INITIAL.slice(),turn:'w',castle:'KQkq',ep:-1,half:0,full:1,last:null,history:[],snapshots:[],over:'',clocks:{w:600,b:600},clockStart:Date.now(),options:{mode:'ai',level:2,color:'w',time:600}}}
function copy(g){return {...g,b:g.b.slice(),last:g.last?g.last.slice():null,clocks:{...g.clocks}}}
function attacked(g,s,by){let r=row(s),c=col(s),b=g.b;for(let dc of [-1,1]){let pr=r+(by==='w'?1:-1),pc=c+dc;if(inside(pr,pc)&&b[pos(pr,pc)]===by+'p')return true}
for(let [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]){let nr=r+dr,nc=c+dc;if(inside(nr,nc)&&b[pos(nr,nc)]===by+'n')return true}
for(let [dr,dc] of [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]){let nr=r+dr,nc=c+dc,step=1;while(inside(nr,nc)){let p=b[pos(nr,nc)];if(p){if(own(p)===by&&(step===1&&p[1]==='k'||(dr&&dc?'bq':'rq').includes(p[1])))return true;break}nr+=dr;nc+=dc;step++}}
return false}
function inCheck(g,side){let k=g.b.indexOf(side+'k');return k<0||attacked(g,k,enemy(side))}
function pseudo(g){let moves=[],b=g.b,t=g.turn;const add=(from,to,promotion,ep=false,castle='')=>moves.push({from,to,promotion:promotion||'',ep,castle});
for(let i=0;i<64;i++){let p=b[i];if(!p||own(p)!==t)continue;let r=row(i),c=col(i),type=p[1];
if(type==='p'){let d=t==='w'?-1:1,rr=r+d,prom=rr===0||rr===7;let push=(to,ep)=>{if(prom){for(let q of ['q','r','b','n'])add(i,to,q,ep)}else add(i,to,'',ep)};
if(inside(rr,c)&&!b[pos(rr,c)]){push(pos(rr,c));let start=t==='w'?6:1;if(r===start&&!b[pos(r+2*d,c)])add(i,pos(r+2*d,c))}
for(let dc of [-1,1])if(inside(rr,c+dc)){let j=pos(rr,c+dc);if(b[j]&&own(b[j])!==t&&b[j][1]!=='k')push(j);else if(j===g.ep&&!b[j]&&b[pos(r,c+dc)]===enemy(t)+'p')push(j,true)}
}else if(type==='n'){for(let [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]){let nr=r+dr,nc=c+dc;if(inside(nr,nc)){let j=pos(nr,nc);if(!b[j]||(own(b[j])!==t&&b[j][1]!=='k'))add(i,j)}}
}else if(type==='k'){for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){if(!dr&&!dc)continue;let nr=r+dr,nc=c+dc;if(inside(nr,nc)){let j=pos(nr,nc);if(!b[j]||(own(b[j])!==t&&b[j][1]!=='k'))add(i,j)}}
let home=t==='w'?60:4,cr=t==='w'?'K':'k',cq=t==='w'?'Q':'q';if(i===home&&!inCheck(g,t)){
if(g.castle.includes(cr)&&b[home+3]===t+'r'&&!b[home+1]&&!b[home+2]&&!attacked(g,home+1,enemy(t))&&!attacked(g,home+2,enemy(t)))add(i,home+2,'',false,'K');
if(g.castle.includes(cq)&&b[home-4]===t+'r'&&!b[home-1]&&!b[home-2]&&!b[home-3]&&!attacked(g,home-1,enemy(t))&&!attacked(g,home-2,enemy(t)))add(i,home-2,'',false,'Q')}
}else{let dirs=[];if('bq'.includes(type))dirs.push([-1,-1],[-1,1],[1,-1],[1,1]);if('rq'.includes(type))dirs.push([-1,0],[1,0],[0,-1],[0,1]);for(let [dr,dc] of dirs){let nr=r+dr,nc=c+dc;while(inside(nr,nc)){let j=pos(nr,nc);if(!b[j])add(i,j);else{if(own(b[j])!==t&&b[j][1]!=='k')add(i,j);break}nr+=dr;nc+=dc}}}}
return moves}
function execute(g,m){let n=copy(g),b=n.b,p=b[m.from],captured=b[m.to];b[m.to]=p;b[m.from]=null;
if(m.ep){let at=m.to+(g.turn==='w'?8:-8);captured=b[at];b[at]=null}
if(m.promotion)b[m.to]=g.turn+m.promotion;
if(m.castle){let start=m.castle==='K'?m.from+3:m.from-4,end=m.castle==='K'?m.from+1:m.from-1;b[end]=b[start];b[start]=null}
let rights=n.castle;if(p[1]==='k')rights=rights.replace(g.turn==='w'?/[KQ]/g:/[kq]/g,'');
for(let [sq,letter] of [[63,'K'],[56,'Q'],[7,'k'],[0,'q']])if(m.from===sq||m.to===sq)rights=rights.replace(letter,'');n.castle=rights;
n.ep=p[1]==='p'&&Math.abs(m.to-m.from)===16?(m.from+m.to)/2:-1;n.half=(p[1]==='p'||captured)?0:g.half+1;if(g.turn==='b')n.full++;n.turn=enemy(g.turn);n.last=[m.from,m.to];return n}
function legal(g){return pseudo(g).filter(m=>!inCheck(execute(g,m),g.turn))}
function square(i){return FILES[col(i)]+(8-row(i))}
function notation(g,m,after){let p=g.b[m.from],name={p:'',n:'N',b:'B',r:'R',q:'Q',k:'K'}[p[1]];if(m.castle)return m.castle==='K'?'O-O':'O-O-O';let s=name;if(p[1]==='p'&&(g.b[m.to]||m.ep))s+=FILES[col(m.from)];else if(p[1]!=='p'){let peers=legal(g).filter(x=>x.to===m.to&&x.from!==m.from&&g.b[x.from]===p);if(peers.length){if(peers.some(x=>col(x.from)===col(m.from)))s+=(8-row(m.from));else s+=FILES[col(m.from)]}}
if(g.b[m.to]||m.ep)s+='x';s+=square(m.to);if(m.promotion)s+='='+m.promotion.toUpperCase();if(inCheck(after,after.turn))s+=legal(after).length?'+' :'#';return s}
function key(g){return g.b.map(p=>p||'--').join('')+'|'+g.turn+'|'+g.castle+'|'+g.ep}
function result(g){let lm=legal(g);if(!lm.length)return inCheck(g,g.turn)?`Échec et mat — ${g.turn==='w'?'Noirs':'Blancs'} gagnent`:'Pat — partie nulle';if(g.half>=100)return 'Nulle — règle des 50 coups';let pieces=g.b.filter(Boolean).filter(p=>p[1]!=='k');if(!pieces.length||pieces.length===1&&'bn'.includes(pieces[0][1]))return 'Nulle — matériel insuffisant';if(g.snapshots){let count=1,k=key(g);for(let h of g.snapshots)if(h.position===k)count++;if(count>=3)return 'Nulle — triple répétition'}return ''}
function evaluate(g){let score=0;for(let i=0;i<64;i++){let p=g.b[i];if(!p)continue;let v=VAL[p[1]],r=row(i),c=col(i);let center=3.5-Math.abs(3.5-c)+3.5-Math.abs(3.5-r);if(p[1]==='p')v+=(p[0]==='w'?6-r:r-1)*9;if('nb'.includes(p[1]))v+=center*5;if(p[1]==='k'&&g.full<25)v-=center*4;score+=(p[0]===g.turn?1:-1)*v}return score}
function search(g,depth,alpha,beta){let moves=legal(g);if(!moves.length)return inCheck(g,g.turn)?-100000-depth:0;if(depth<=0)return evaluate(g);let best=-Infinity;for(let m of moves){let n=execute(g,m),s=-search(n,depth-1,-beta,-alpha);if(s>best)best=s;if(s>alpha)alpha=s;if(alpha>=beta)break}return best}
function aiMove(g,level){let ms=legal(g);if(!ms.length)return null;let lv=Number(level)||1;if(lv===1)return ms[Math.floor(Math.random()*ms.length)];let depth=lv<=2?1:lv===3?2:lv===4?2:3;let ordered=ms.map(m=>({m,priority:(g.b[m.to]?VAL[g.b[m.to][1]]:0)+(m.promotion?800:0)+Math.random()*3})).sort((a,b)=>b.priority-a.priority).map(x=>x.m);let scores=ordered.map(m=>({m,s:-search(execute(g,m),depth-1,-Infinity,Infinity)}));scores.sort((a,b)=>b.s-a.s);if(lv===2){let pool=scores.filter(x=>x.s>=scores[0].s-170).slice(0,Math.min(5,scores.length));return pool[Math.floor(Math.random()*pool.length)].m}return scores[0].m}
function boot(root){if(root.dataset.chessReady)return;root.dataset.chessReady='1';let $=s=>root.querySelector(s), $$=s=>Array.from(root.querySelectorAll(s));let game=fresh(),selected=-1,orient='w',pending=null,aiBusy=false,networkBusy=false,stagedMove=null,online=null,netUser='',netCsrf='',netGames=[],lastRev=-1,serverProblem='',userSelectedLocal=false,onlineReady=false,settings={mode:'ai',level:2,color:'w',time:600};
try{let saved=JSON.parse(localStorage.getItem(S)||'null');if(valid(saved))game=saved;let sp=JSON.parse(localStorage.getItem(P)||'null');if(sp&&typeof sp==='object')settings={...settings,...sp}}catch(e){}
if(game.options)settings={...settings,...game.options};if(settings.mode==='online')settings.mode='ai';orient=settings.color==='b'?'b':'w';
function valid(g){return g&&Array.isArray(g.b)&&g.b.length===64&&['w','b'].includes(g.turn)&&typeof g.castle==='string'&&Array.isArray(g.history)&&Array.isArray(g.snapshots)&&g.history.length<=2000&&g.snapshots.length<=2000&&g.b.filter(x=>x==='wk').length===1&&g.b.filter(x=>x==='bk').length===1&&g.b.every(x=>x===null||/^[wb][pnbrqk]$/.test(x))&&g.clocks&&typeof g.clocks.w==='number'&&typeof g.clocks.b==='number'}
function save(){if(settings.mode==='online')return;try{localStorage.setItem(S,JSON.stringify(game));localStorage.setItem(P,JSON.stringify(settings))}catch(e){}}
function modal(title,text,yes){$('[data-modal-title]').textContent=title;$('[data-modal-text]').textContent=text;$('[data-modal]').hidden=false;pending=yes}
function hideModal(){pending=null;$('[data-modal]').hidden=true}
$('[data-modal-cancel]').onclick=hideModal;$('[data-modal-confirm]').onclick=()=>{let cb=pending;hideModal();if(cb)cb()};
let showMoveArrow=true;try{showMoveArrow=localStorage.getItem('dmd-chess-show-arrow')!=='false'}catch(e){}
const arrowToggle=$('[data-show-arrow]');if(arrowToggle)arrowToggle.checked=showMoveArrow;
if(arrowToggle)arrowToggle.addEventListener('change',()=>{showMoveArrow=arrowToggle.checked;try{localStorage.setItem('dmd-chess-show-arrow',String(showMoveArrow))}catch(e){}renderArrow()});
function clockText(sec){if(!settings.time)return '—';sec=Math.max(0,Math.ceil(sec));return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`}
function activeSide(){return game.turn}
function tick(){if(settings.mode==='online'||game.over||!settings.time)return;let now=Date.now(),delta=(now-game.clockStart)/1000;if(delta<=0)return;game.clockStart=now;game.clocks[game.turn]=Math.max(0,game.clocks[game.turn]-delta);if(game.clocks[game.turn]===0){game.over='Temps écoulé — '+(game.turn==='w'?'Noirs':'Blancs')+' gagnent';save();render()}else updateClocks()}
function updateClocks(){
 const ourSide=online?.white===netUser?'w':'b';
 const waiting=settings.mode==='online'&&online?.state==='playing'&&online?.turn===ourSide;
 for(let c of ['w','b']){
  const clock=$(`[data-clock="${c==='w'?'white':'black'}"]`);
  const ours=settings.mode==='online'&&online&&ourSide===c;
  clock.textContent=settings.mode==='online'?(ours?(stagedMove?'✓ VALIDER':'◷ JOUER'):'—'):clockText(game.clocks[c]);
  clock.classList.toggle('dch-clock-commit',Boolean(ours&&stagedMove));
  clock.classList.toggle('dch-clock-ready',Boolean(ours&&waiting));
  if(settings.mode==='online'){
   clock.setAttribute('role',ours?'button':'status');clock.setAttribute('tabindex',ours?'0':'-1');
   clock.title=ours?'Après avoir déplacé une pièce, cliquez ici pour valider':'Compteur de l’adversaire';
  }else{clock.removeAttribute('role');clock.removeAttribute('tabindex');clock.removeAttribute('title')}
 }
 const submit=$('[data-action="send"]');
 if(submit){submit.hidden=!(settings.mode==='online'&&online?.state==='playing');submit.disabled=!stagedMove||networkBusy;submit.textContent=stagedMove?'✓ Valider mon coup — avertir mon adversaire':'Déplacez une pièce pour valider votre coup';}
 const hint=$('[data-turn-hint]');if(hint)hint.textContent=settings.mode!=='online'?'':stagedMove?'Coup prêt : cliquez sur votre compteur ou sur « Valider mon coup ».':waiting?'Votre tour : déplacez une pièce, puis validez sur votre compteur.':'En attente du coup adverse.';
 $$('.dch-player').forEach(x=>x.classList.toggle('active',x.dataset.side===(game.turn==='w'?'white':'black')&&!game.over));
}
function aiTurn(){return (settings.mode==='ai'&&game.turn!==settings.color)||(settings.mode==='online'&&(!online||game.turn!==(online.white===netUser?'w':'b')||online.state!=='playing'))}
let aiWorker=null,thinkSeq=0;
try{const source=document.getElementById('dch-ai-worker')?.textContent;if(source&&typeof Worker!=='undefined'){const url=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));aiWorker=new Worker(url);URL.revokeObjectURL(url)}}catch(e){aiWorker=null}
function refreshAI(){
 if(settings.mode==='online'||game.over||!aiTurn()||aiBusy)return;
 aiBusy=true;const id=++thinkSeq;const position=key(game),level=settings.level;
 const finish=m=>{if(id!==thinkSeq)return;aiBusy=false;if(settings.mode==='ai'&&!game.over&&aiTurn()&&key(game)===position&&m){const found=legal(game).find(x=>x.from===m.from&&x.to===m.to&&(x.promotion||'')===(m.promotion||''));if(found)play(found);}render();};
 if(aiWorker){const timeout=setTimeout(()=>{if(id===thinkSeq){try{aiWorker.terminate()}catch(e){}aiWorker=null;finish(aiMove(game,Math.min(3,level)))}},8500);
 aiWorker.onmessage=e=>{if(e.data?.id!==id)return;clearTimeout(timeout);finish(e.data.ok?e.data.move:aiMove(game,Math.min(3,level)))};
 aiWorker.onerror=()=>{clearTimeout(timeout);try{aiWorker.terminate()}catch(e){}aiWorker=null;finish(aiMove(game,Math.min(3,level)))};
 aiWorker.postMessage({action:'think',id,game,level});
 }else setTimeout(()=>finish(aiMove(game,Math.min(3,level))),30);
}
function play(m){if(game.over||networkBusy)return;if(settings.mode==='online'){stageOnlineMove(m);return;}tick();if(game.over)return;let before=copy(game),n=execute(game,m);let name=notation(game,m,n);let snapshots=game.snapshots.slice(),history=game.history.slice();snapshots.push({b:game.b.slice(),turn:game.turn,castle:game.castle,ep:game.ep,half:game.half,full:game.full,last:game.last,clocks:{...game.clocks},position:key(game)});history.push(name);game={...n,history,snapshots,options:{...settings},clockStart:Date.now(),over:''};game.over=result(game);selected=-1;save();render();if(!game.over)refreshAI()}
function undo(){thinkSeq++;aiBusy=false;if(aiWorker){try{aiWorker.terminate()}catch(e){}aiWorker=null} if(settings.mode==='online'||!game.snapshots.length)return;let count=settings.mode==='ai'?Math.min(2,game.snapshots.length):1;for(let i=0;i<count;i++){let prev=game.snapshots[game.snapshots.length-1];if(!prev)break;game={...game,...prev,b:prev.b.slice(),clocks:{...prev.clocks},snapshots:game.snapshots.slice(0,-1),history:game.history.slice(0,-1),over:'',clockStart:Date.now()}}selected=-1;save();render();refreshAI()}
function clickSquare(i){if(game.over||aiBusy||aiTurn()||stagedMove)return;let moves=legal(game);if(selected>=0){let candidates=moves.filter(x=>x.from===selected&&x.to===i);if(candidates.length){let promo=candidates.find(x=>x.promotion==='q')||candidates[0];play(promo);return}}selected=game.b[i]&&own(game.b[i])===game.turn?i:-1;render()}
function captured(side){let initial={p:8,n:2,b:2,r:2,q:1},current={p:0,n:0,b:0,r:0,q:0};game.b.filter(p=>p&&own(p)===side&&p[1]!=='k').forEach(p=>{current[p[1]]++});return Object.keys(initial).flatMap(k=>Array(Math.max(0,initial[k]-current[k])).fill(UNICODE[enemy(side)+k])).join(' ')||'—'}
function syncPlayerRibbons(){
 // Le joueur au bas de l'échiquier doit toujours correspondre aux pièces du bas.
 // On déplace les bandeaux complets (nom, avatar, captures et chrono), pas seulement le texte.
 const gameMain=$('.game-main');
 const boardWrap=$('.dch-board-wrap');
 const whiteRibbon=$('[data-player-ribbon="white"]');
 const blackRibbon=$('[data-player-ribbon="black"]');
 if(!gameMain||!boardWrap||!whiteRibbon||!blackRibbon)return;
 const top=orient==='w'?blackRibbon:whiteRibbon;
 const bottom=orient==='w'?whiteRibbon:blackRibbon;
 gameMain.insertBefore(top,boardWrap);
 gameMain.insertBefore(bottom,boardWrap.nextSibling);
}
function render(){syncPlayerRibbons();let board=$('[data-board]');board.replaceChildren();let order=Array.from({length:64},(_,i)=>orient==='w'?i:63-i),lm=selected>=0?legal(game).filter(x=>x.from===selected):[];
for(let i of order){let sq=document.createElement('button'),p=game.b[i];sq.type='button';sq.className='dch-square'+((row(i)+col(i))%2?' dark':'');if(game.last&&game.last.includes(i))sq.classList.add('last');if(selected===i)sq.classList.add('selected');if(p===game.turn+'k'&&inCheck(game,game.turn))sq.classList.add('check');if(lm.some(x=>x.to===i))sq.classList.add(p?'capture':'move');sq.dataset.index=i;sq.setAttribute('role','gridcell');sq.setAttribute('aria-label',square(i)+(p?' '+(own(p)==='w'?'blanc ':'noir ')+p[1]:''));if(p){let icon=document.createElement('span');icon.className='dch-piece '+(own(p)==='w'?'white':'black');icon.textContent=UNICODE[p];sq.append(icon)}if((orient==='w'?row(i)===7:row(i)===0)||(orient==='w'?col(i)===0:col(i)===7)){let coordinate=document.createElement('small');coordinate.className='dch-coord';coordinate.textContent=(orient==='w'?row(i)===7:row(i)===0)?FILES[col(i)]:(8-row(i));sq.append(coordinate)}sq.addEventListener('click',()=>clickSquare(i));board.append(sq)}
$('[data-status]').textContent=(settings.mode==='online'&&game.over ? game.over.replace(/\b(Blancs|Noirs) gagnent\b/,(_,color)=>(color==='Blancs'?(online?.white_name||'Joueur blanc'):(online?.black_name||'Joueur noir'))+' gagne').replace(/\b(Blancs|Noirs) abandonnent\b/,(_,color)=>(color==='Blancs'?(online?.white_name||'Joueur blanc'):(online?.black_name||'Joueur noir'))+' abandonne') : game.over)||(inCheck(game,game.turn)?'Échec !':'Partie en cours');$('[data-result]').textContent=game.over?'Partie terminée':aiTurn()?'L’ordinateur réfléchit…':'À vous de jouer';$('[data-turn]').textContent=game.over||((game.turn==='w'?'Blancs':'Noirs')+' aux traits');$('[data-level]').textContent=settings.mode==='online'?'DMD • Multijoueur':settings.mode==='ai'?'IA • Niveau '+settings.level:'Deux joueurs';$('[data-player-name="white"]').textContent=settings.mode==='online'?(online?.white_name||'Joueur blanc'):settings.mode==='local'?'Joueur blanc':settings.color==='w'?'Vous':'Ordinateur';$('[data-player-name="black"]').textContent=settings.mode==='online'?(online?.black_name||'Joueur noir'):settings.mode==='local'?'Joueur noir':settings.color==='b'?'Vous':'Ordinateur';$('[data-captured="white"]').textContent=captured('b');$('[data-captured="black"]').textContent=captured('w');updateClocks();
renderArrow();let moves=$('[data-moves]');moves.replaceChildren();for(let i=0;i<game.history.length;i+=2){let r=document.createElement('div');r.className='dch-move-row';for(let item of [String(i/2+1).padStart(2,'0'),game.history[i],game.history[i+1]||'']){let x=document.createElement('span');x.textContent=item;r.append(x)}moves.append(r)}moves.scrollTop=moves.scrollHeight;$('[data-move-total]').textContent=game.history.length+' coups';$('[data-action="undo"]').disabled=settings.mode==='online'||!game.snapshots.length}
function newGame(){thinkSeq++;aiBusy=false;if(aiWorker){try{aiWorker.terminate()}catch(e){}aiWorker=null} if(settings.mode==='online')leaveOnline();game=fresh();game.options={...settings};game.clocks={w:settings.time,b:settings.time};game.clockStart=Date.now();if(settings.color==='random')settings.color=Math.random()<.5?'w':'b';game.options={...settings};orient=settings.color;selected=-1;save();render();refreshAI()}
function readSettings(){let out={};for(let e of $$('[data-setting]'))out[e.dataset.setting]=e.value;return {mode:out.mode==='local'?'local':'ai',level:Math.min(5,Math.max(1,Number(out.level)||2)),color:['w','b','random'].includes(out.color)?out.color:'w',time:[0,60,180,300,600,900,1800].includes(Number(out.time))?Number(out.time):600}}
function apply(){let proposed=readSettings();modal('Démarrer une nouvelle partie','La partie actuelle sera remplacée. Vous pouvez l’exporter avant.',()=>{settings=proposed;newGame()})}
for(let e of $$('[data-setting]'))e.value=String(settings[e.dataset.setting]);
for(let e of $$('[data-tab]'))e.addEventListener('click',()=>{setTab(e.dataset.tab);if(e.dataset.tab==='online')loadMembers()});
for(let b of $$('[data-action]'))b.addEventListener('click',()=>{switch(b.dataset.action){case 'new':modal('Nouvelle partie','Recommencer avec les paramètres actuels ?',newGame);break;case 'apply':apply();break;case 'undo':undo();break;case 'flip':orient=enemy(orient);render();break;case 'draw':if(settings.mode==='online'){modal('Partie nulle','Clôturer cette partie en ligne comme nulle ?',()=>onlineAction('draw'));break;}modal('Partie nulle','Terminer la partie sur un résultat nul ?',()=>{game.over='Partie nulle par accord';save();render()});break;case 'resign':if(settings.mode==='online'){modal('Abandon','Abandonner cette partie multijoueur ?',()=>onlineAction('resign'));break;}modal('Abandonner','Confirmer l’abandon ?',()=>{game.over='Abandon — '+(game.turn==='w'?'Noirs':'Blancs')+' gagnent';save();render()});break;case 'refresh':refreshNetwork();break;case 'exit-online':leaveOnline();break;case 'invite':sendInvite();break;case 'open-invite':setTab('online');refreshNetwork();loadMembers();break;case 'view-invites':setTab('online');refreshNetwork();break;case 'reload-members':loadMembers();break;case 'send':commitOnlineMove();break;case 'export':{let blob=new Blob([JSON.stringify({format:'DMD-Chess-v1',game,settings},null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='DMD-Chess-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);break}}});
$('[data-import]').addEventListener('change',async function(){let f=this.files&&this.files[0];this.value='';if(!f||f.size>1048576){modal('Import refusé','Fichier JSON absent ou supérieur à 1 Mo.',null);return}try{let obj=JSON.parse(await f.text());if(obj.format!=='DMD-Chess-v1'||!valid(obj.game))throw Error('Format invalide');modal('Importer la partie','Remplacer la partie actuelle par celle de ce fichier ?',()=>{if(settings.mode==='online')leaveOnline();game=obj.game;settings={...settings,...game.options};if(!['w','b'].includes(settings.color))settings.color='w';orient=settings.color;game.clockStart=Date.now();selected=-1;for(let e of $$('[data-setting]'))e.value=String(settings[e.dataset.setting]);save();render();refreshAI()})}catch(e){modal('Import refusé','Le fichier ne contient pas une partie DMD-Chess valide.',null)}});
// Module multijoueur — serveur DMD, identification par la session PHP, JSON verrouillé.
let apiURL='';try{apiURL=new URL('modules/DMD-Chess/chess_api.php',window.parent.location.href).href}catch(e){apiURL='/modules/DMD-Chess/chess_api.php'}
async function request(action,data=null,id=''){
 const url=new URL(apiURL);url.searchParams.set('action',action);if(id)url.searchParams.set('id',id);
 const opts={credentials:'same-origin',cache:'no-store'};
 if(data){const body=new URLSearchParams(data);opts.method='POST';opts.body=body;opts.headers={'X-DMD-Chess-CSRF':netCsrf};}
 const res=await fetch(url,opts),j=await res.json();if(!j.ok)throw new Error(j.error||'Erreur réseau');return j;
}
function onlineToLocal(g){
 if(!g||!Array.isArray(g.b)||g.b.length!==64)return;
 if(!online||online.id!==g.id||online.rev!==g.rev)stagedMove=null;online=g;lastRev=g.rev;settings.mode='online';settings.time=0;settings.color=g.white===netUser?'w':'b';orient=settings.color;
 game={...fresh(),b:g.b.slice(),turn:g.turn,castle:g.castle,ep:g.ep,half:g.half,full:g.full,last:g.last,over:g.over||'',history:g.history.slice(),snapshots:[],clocks:{w:0,b:0},options:{...settings},clockStart:Date.now()};
 selected=-1;
 const banner=$('[data-online-banner]');banner.hidden=false;
 try{localStorage.setItem('dmd-chess-active-online:'+netUser,g.id)}catch(e){}
 $('[data-online-status]').textContent=g.drawOffer&&g.drawOffer!==netUser?'L’adversaire propose une nulle':g.drawOffer===netUser?'Proposition de nulle envoyée':g.state==='invited'?'Invitation en attente':g.state==='rejected'?'Invitation refusée':g.state==='cancelled'?'Invitation annulée':g.state==='done'?(g.over||'Terminé').replace(/\b(Blancs|Noirs) gagnent\b/,(_,color)=>(color==='Blancs'?(g.white_name||'Joueur blanc'):(g.black_name||'Joueur noir'))+' gagne').replace(/\b(Blancs|Noirs) abandonnent\b/,(_,color)=>(color==='Blancs'?(g.white_name||'Joueur blanc'):(g.black_name||'Joueur noir'))+' abandonne'):(g.turn===(g.white===netUser?'w':'b')?'À vous de jouer':'Tour de l’adversaire');
 
 render();updateClocks();
}
function leaveOnline(){stagedMove=null;userSelectedLocal=true;try{localStorage.removeItem('dmd-chess-active-online:'+netUser)}catch(e){}online=null;lastRev=-1;settings.mode='ai';settings.time=600;try{let st=JSON.parse(localStorage.getItem(S)||'null');if(valid(st))game=st;else game=fresh()}catch(e){game=fresh()}game.options.mode=settings.mode;orient=settings.color='w';$('[data-online-banner]').hidden=true;$('[data-action="send"]').hidden=true;render();refreshAI();}
function drawOnlineList(){const box=$('[data-online-games]');box.replaceChildren();let invites=0;
 for(const g of netGames){
  const mine=g.inviter===netUser,incoming=g.state==='invited'&&!mine;if(incoming)invites++;
  const row=document.createElement('div');row.className='online-item';
  const meta=document.createElement('div');const name=document.createElement('b');name.textContent=g.white===netUser?(g.black_name||'Joueur DMD'):(g.white_name||'Joueur DMD');
  const sub=document.createElement('small');sub.textContent=incoming?'Invitation reçue':g.state==='invited'?'Invitation envoyée · en attente':g.state==='playing'?(g.turn===(g.white===netUser?'w':'b')?'Votre tour':'Tour adverse'):g.state==='cancelled'?'Invitation annulée':g.state==='rejected'?'Invitation refusée':'Partie terminée';meta.append(name,sub);row.append(meta);
  function actionButton(text,fn,style){const b=document.createElement('button');b.type='button';b.textContent=text;if(style)b.classList.add(style);b.onclick=fn;row.append(b)}
  if(incoming){actionButton('Accepter',()=>onlineAction('accept',g.id));actionButton('Refuser',()=>onlineAction('reject',g.id));}
  else if(g.state==='invited'&&mine){actionButton('Annuler',()=>modal('Annuler l’invitation','Le destinataire sera informé que l’invitation est annulée.',()=>onlineAction('cancel',g.id)),'danger');}
  else if(g.state==='playing'){actionButton('Reprendre',()=>{userSelectedLocal=false;onlineToLocal(g);setTab('game')});}
  if(g.state!=='playing'){
   actionButton('Supprimer',()=>modal('Retirer de ma liste','Cette invitation sera retirée de votre liste. Si elle est en attente, l’autre joueur verra son annulation ou son refus.',()=>onlineAction('delete',g.id)),'danger');
  }
  box.append(row);
 }
 $('[data-invite-count]').textContent=invites?String(invites):'';
 const alert=$('[data-invite-alert]');alert.hidden=!invites;
 $('[data-invite-alert-text]').textContent=invites===1?'Vous avez une invitation à jouer aux échecs':`Vous avez ${invites} invitations à jouer`;
 const btn=$('[data-action="open-invite"]');btn.textContent=invites?`♟ Invitations (${invites})`:'♟ Inviter un membre';
 if(!netGames.length)box.textContent='Aucune partie ni invitation enregistrée.';
}
function setTab(tab){for(const b of $$('[data-tab]'))b.classList.toggle('active',b.dataset.tab===tab);for(const pane of $$('[data-pane]'))pane.hidden=pane.dataset.pane!==tab}
async function loadMembers(){
 try{const data=await request('members');if(data.csrf)netCsrf=data.csrf;
 const sel=$('[data-invite-member]');const previous=sel.value;sel.replaceChildren();
 const first=document.createElement('option');first.value='';first.textContent='— Choisir un membre —';sel.append(first);
 const members=data.members||[], permitted=members.filter(m=>m.allowed), blocked=members.length-permitted.length;
 for(const member of members){const opt=document.createElement('option');opt.value=member.email;opt.disabled=!member.allowed;opt.textContent=member.name+(!member.allowed?' — Accès au module désactivé':'');sel.append(opt)}
 if(previous && [...sel.options].some(o=>o.value===previous&&!o.disabled))sel.value=previous;
 if(!permitted.length)first.textContent=members.length?'Aucun membre avec accès DMD-Chess':'Aucun autre compte DMD trouvé';
 const state=$('[data-members-status]');if(state)state.textContent=permitted.length+' membre(s) disponible(s)'+(blocked?' · '+blocked+' sans accès DMD-Chess':'')+(blocked?' — autoriser le module pour ces comptes dans les droits DMD.':'');
 }catch(e){const state=$('[data-members-status]');if(state)state.textContent='Impossible de charger les membres : '+e.message;else $('[data-network-state]').textContent='Liste des membres indisponible : '+e.message;}
}
async function refreshNetwork(){if(networkBusy)return;networkBusy=true;try{const data=await request('list');netUser=data.me;netCsrf=data.csrf;netGames=data.games||[];serverProblem='';$('[data-network-state]').textContent='Connecté : '+netUser;
 drawOnlineList();
 // La partie autoritative reste sur le serveur : la page ne doit jamais l'effacer au rechargement.
 let storedId='';try{storedId=localStorage.getItem('dmd-chess-active-online:'+netUser)||''}catch(e){}
 let chosen=online?netGames.find(g=>g.id===online.id):null;
 if(!chosen && !onlineReady && !userSelectedLocal){
   chosen=netGames.find(g=>g.id===storedId && (g.state==='playing'||g.state==='invited'));
   if(!chosen)chosen=netGames.find(g=>g.state==='playing');
 }
 onlineReady=true;
 if(chosen){
   const changed=!online || chosen.id!==online.id || chosen.rev!==lastRev;
   if(changed){const wasOurTurn=online && online.state==='playing' && online.turn===(online.white===netUser?'w':'b');onlineToLocal(chosen);
     if(chosen.state==='playing' && chosen.turn===(chosen.white===netUser?'w':'b') && !wasOurTurn){try{navigator.vibrate?.(100)}catch(e){}}}
 }else if(online){
   // Une erreur réseau ou un filtrage inattendu ne doit pas faire disparaître l'échiquier.
   $('[data-online-status]').textContent='Synchronisation de la partie en attente…';
 }
 }catch(e){serverProblem=e.message;$('[data-network-state]').textContent='Multijoueur indisponible : '+serverProblem;}finally{networkBusy=false}}
async function onlineAction(action,id=online?.id){if(!id)return;
 try{
  if(!netCsrf)await refreshNetwork();
  const data=await request(action,{id});
  const active=online&&online.id===id;
  if(action==='accept'){userSelectedLocal=false;onlineToLocal(data.game);setTab('game');}
  else if(action==='cancel'||action==='reject'||action==='delete'){
   if(active)leaveOnline();
   setTab('online');
  }else if(active){userSelectedLocal=false;onlineToLocal(data.game);setTab('game');}
  await refreshNetwork();
 }catch(e){modal('Connexion',e.message,null)}
}
async function sendInvite(){let target=$('[data-invite-target]').value.trim()||$('[data-invite-member]').value;if(!target){modal('Invitation','Saisir l’adresse email du membre DoMyDesk.',null);return;}try{if(!netCsrf)await refreshNetwork();const r=await request('invite',{target,side:$('[data-invite-side]').value});$('[data-invite-target]').value='';$('[data-invite-member]').value='';userSelectedLocal=false;onlineToLocal(r.game);await refreshNetwork();setTab('game')}catch(e){modal('Invitation impossible',e.message,null)}}
function stageOnlineMove(m){
 if(!online||online.state!=='playing'||stagedMove||networkBusy||game.turn!==(online.white===netUser?'w':'b'))return;
 stagedMove={move:m,rev:lastRev};
 const preview=execute(game,m);
 game={...game,...preview,b:preview.b.slice(),last:[m.from,m.to],turn:online.turn,history:online.history.slice(),over:online.over||''};
 selected=-1;render();
 $('[data-online-status]').textContent='Coup préparé : cliquez sur VOTRE COMPTEUR pour l’envoyer.';
 updateClocks();
}
function renderArrow(){
 const board=$('[data-board]');let overlay=board.querySelector('.dch-last-arrow');if(overlay)overlay.remove();
 if(settings.mode!=='online'||!showMoveArrow)return;
 const last=stagedMove?[stagedMove.move.from,stagedMove.move.to]:online?.last;
 if(!Array.isArray(last)||last.length!==2||last.some(n=>!Number.isInteger(n)||n<0||n>63))return;
 const center=i=>{const r=Math.floor(i/8),c=i%8;return orient==='w'?[c+.5,r+.5]:[7.5-c,7.5-r]};
 const [a,b]=last.map(center),dx=b[0]-a[0],dy=b[1]-a[1],dist=Math.hypot(dx,dy)||1;
 const ex=b[0]-dx/dist*.22,ey=b[1]-dy/dist*.22;
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('dch-last-arrow');svg.setAttribute('viewBox','0 0 8 8');svg.setAttribute('aria-hidden','true');
 const line=document.createElementNS(svg.namespaceURI,'line');for(const [key,val] of Object.entries({x1:a[0],y1:a[1],x2:ex,y2:ey,stroke:'var(--ch-danger)','stroke-width':.045,'stroke-linecap':'round'}))line.setAttribute(key,String(val));
 const head=document.createElementNS(svg.namespaceURI,'polygon');const ux=dx/dist,uy=dy/dist,px=-uy,py=ux;
 head.setAttribute('points',[[ex,ey],[ex-ux*.17+px*.09,ey-uy*.17+py*.09],[ex-ux*.17-px*.09,ey-uy*.17-py*.09]].map(x=>x.join(',')).join(' '));head.setAttribute('fill','var(--ch-danger)');
 svg.append(line,head);board.append(svg);
}
for(const c of ['white','black']){const node=$(`[data-clock="${c}"]`);node.addEventListener('click',()=>{if(settings.mode==='online'&&stagedMove&&(online.white===netUser?'white':'black')===c)commitOnlineMove()});node.addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&settings.mode==='online'&&stagedMove&&(online.white===netUser?'white':'black')===c){e.preventDefault();commitOnlineMove()}})}
async function commitOnlineMove(){
 if(!online||!stagedMove||networkBusy)return;
 const m=stagedMove.move;
 // Le plateau affiché est un aperçu : reconstruire depuis la dernière position serveur.
 const before={...game,b:online.b.slice(),turn:online.turn,castle:online.castle,ep:online.ep,half:online.half,full:online.full,last:online.last,history:online.history.slice()};
 networkBusy=true;const n=execute(before,m),name=notation(before,m,n);const proposed={b:n.b,turn:n.turn,castle:n.castle,ep:n.ep,half:n.half,full:n.full,last:n.last,over:result({...n,history:[...game.history,name],snapshots:[]})};
 try{const data=await request('move',{id:online.id,move:JSON.stringify(m),position:JSON.stringify(proposed),notation:name,rev:String(stagedMove.rev)});stagedMove=null;onlineToLocal(data.game);setTab('game');}catch(e){stagedMove=null;game={...game,b:online.b.slice(),turn:online.turn,castle:online.castle,ep:online.ep,half:online.half,full:online.full,last:online.last};render();modal('Coup non transmis',e.message,null);}
 finally{networkBusy=false;refreshNetwork();}}
// Thème DMD : récupérer les propriétés calculées du thème actif de l'utilisateur.
// srcdoc possède son propre document : les variables CSS ne traversent pas l'iframe.
function syncTheme(){
 try {
  const owner=window.parent;
  const doc=owner.document;
  const frame=window.frameElement;
  const candidates=[frame?.parentElement,doc.body,doc.documentElement].filter(Boolean);
  const styles=candidates.map(el=>owner.getComputedStyle(el));
  const lookup=names=>{
   for(const name of names){
    for(const st of styles){
     const value=st.getPropertyValue(name).trim();
     if(value && !['initial','inherit','unset','transparent'].includes(value.toLowerCase()))return value;
    }
   }
   return '';
  };
  const palette={
   '--ch-bg':['--dmd-bg','--dmd-bg-page','--background-color','--page-bg','--bg'],
   '--ch-panel':['--dmd-panel-bg','--dmd-bg-panel','--dmd-window-bg','--panel-bg','--card-bg'],
   '--ch-surface':['--dmd-section-bg','--dmd-bg-section','--dmd-tile-bg','--dmd-bg-card','--section-bg'],
   '--ch-input':['--dmd-input-bg','--dmd-bg-input','--dmd-control-bg','--input-bg'],
   '--ch-accent':['--dmd-accent','--primary-color','--accent','--primary'],
   '--ch-title':['--dmd-title','--title-color','--dmd-accent'],
   '--ch-ink':['--dmd-text','--text-color','--text'],
   '--ch-muted':['--dmd-muted','--dmd-text-muted','--muted-color','--text-muted'],
   '--ch-border':['--dmd-border','--dmd-panel-border','--border-color'],
   '--ch-danger':['--dmd-danger','--danger-color'],
   '--ch-soft':['--dmd-accent-soft','--primary-soft'],
   '--ch-button-bg':['--dmd-button-bg','--dmd-bg-card','--dmd-tile-bg'],
   '--ch-button-ink':['--dmd-button-text','--dmd-text'],
   '--ch-radius':['--dmd-radius-module','--dmd-radius-panel','--dmd-panel-radius','--radius'],
   '--ch-radius-button':['--dmd-radius-button','--dmd-button-radius','--radius-sm'],
   '--ch-radius-input':['--dmd-radius-input','--dmd-input-radius','--radius-sm']
  };
  for(const [target,names] of Object.entries(palette)){
   const value=lookup(names);
   if(value)root.style.setProperty(target,value);
   else root.style.removeProperty(target);
  }
  // Dériver les deux couleurs du damier de la palette de l'utilisateur.
  // Les cases restent distinctes sans imposer l'ancien bleu/cyan.
  root.style.setProperty('--ch-light','color-mix(in srgb, var(--ch-panel) 48%, var(--ch-accent) 52%)');
  root.style.setProperty('--ch-dark','color-mix(in srgb, var(--ch-bg) 84%, var(--ch-accent) 16%)');
  const font=styles.map(st=>st.fontFamily).find(f=>f&&f!=='initial');
  if(font)root.style.fontFamily=font;
  const cs=owner.getComputedStyle(doc.body);
  root.style.setProperty('--ch-ui-scale',lookup(['--dmd-ui-scale'])||'1');
 }catch(err){ /* Hôte hors origine : conserver le thème de secours. */ }
}
syncTheme();
// Actualise aussi les changements de thème personnels sans recharger la partie.
try{
 const owner=window.parent,doc=owner.document;
 const observer=new MutationObserver(syncTheme);
 observer.observe(doc.documentElement,{attributes:true,attributeFilter:['class','style','data-theme','data-user-theme']});
 if(doc.body)observer.observe(doc.body,{attributes:true,attributeFilter:['class','style','data-theme']});
}catch(err){}
setInterval(syncTheme,3000);
// Le contenu décide de sa hauteur. Ne jamais mesurer scrollHeight de l'iframe :
// cette valeur dépend de la hauteur précédente et provoquait l'allongement sans fin.
let lastHostHeight=0;
function resizeHost(){
 try{
  const frame=window.frameElement;
  if(!frame)return;
  const target=Math.max(180,Math.ceil(root.getBoundingClientRect().height));
  if(target!==lastHostHeight){lastHostHeight=target;frame.style.height=target+'px';}
 }catch(e){}
}
if(typeof ResizeObserver!=='undefined')new ResizeObserver(resizeHost).observe(root);
window.addEventListener('resize',resizeHost);
setTimeout(resizeHost,0);

render();refreshAI();refreshNetwork();loadMembers();setInterval(()=>{if(root.isConnected)tick()},1000);setInterval(()=>{if(root.isConnected)refreshNetwork()},5000);document.addEventListener('visibilitychange',()=>{if(document.hidden&&settings.time&&!game.over){tick();save()}else if(!document.hidden){game.clockStart=Date.now();render()}})
}
function init(){document.querySelectorAll('[data-dmd-chess]').forEach(boot)}if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
