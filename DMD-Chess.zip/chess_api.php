<?php
/* DMD-Chess — parties communes JSON, PHP 7.3+, aucun SQL. */
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
$root = dirname(__DIR__, 2);
$core = $root . '/core/dmd_permissions.php';
function result($data, int $code=200) { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit; }
if (!is_file($core)) result(['ok'=>false,'error'=>'Core permissions DMD absent'],403);
require_once $core;
require_once __DIR__ . '/chess_rules.php';
$user = $_SESSION['user']['email'] ?? '';
if (!is_string($user) || !filter_var($user, FILTER_VALIDATE_EMAIL) || !function_exists('dmd_current_user_has_module_permission') || !dmd_current_user_has_module_permission('DMD-Chess','use')) result(['ok'=>false,'error'=>'Accès DMD-Chess refusé'],403);
$user = strtolower(trim($user));
$dir = __DIR__ . '/data';
if (!is_dir($dir) && !@mkdir($dir,0750,true)) result(['ok'=>false,'error'=>'Répertoire des parties inaccessible'],500);
if (!is_file($dir.'/.htaccess')) @file_put_contents($dir.'/.htaccess',"Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
$action = (string)($_GET['action'] ?? $_POST['action'] ?? 'list');
$mutating = in_array($action,['invite','accept','reject','move','resign','draw','cancel','delete'],true);
if ($mutating && $_SERVER['REQUEST_METHOD'] !== 'POST') result(['ok'=>false,'error'=>'Méthode incorrecte'],405);
if ($mutating) {
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    if ($origin && strtolower((string)parse_url($origin, PHP_URL_HOST)) !== strtolower(preg_replace('/:\d+$/','',$host))) result(['ok'=>false,'error'=>'Origine incorrecte'],403);
    $csrf=(string)($_SERVER['HTTP_X_DMD_CHESS_CSRF'] ?? '');
    if (!$csrf || !isset($_SESSION['dmd_chess_csrf']) || !hash_equals($_SESSION['dmd_chess_csrf'],$csrf)) result(['ok'=>false,'error'=>'Session CSRF expirée'],403);
}
if (!isset($_SESSION['dmd_chess_csrf'])) $_SESSION['dmd_chess_csrf']=bin2hex(random_bytes(24));
$token=$_SESSION['dmd_chess_csrf'];
session_write_close();
$initial=['br','bn','bb','bq','bk','bb','bn','br'];
for($i=0;$i<8;$i++) $initial[]='bp';
for($i=0;$i<32;$i++) $initial[]=null;
for($i=0;$i<8;$i++) $initial[]='wp';
foreach(['wr','wn','wb','wq','wk','wb','wn','wr'] as $p) $initial[]=$p;
function guardGame(array $g,string $user) { if (($g['white']??'')!==$user && ($g['black']??'')!==$user) result(['ok'=>false,'error'=>'Partie non autorisée'],403); }
function chessDisplayName(string $email): string {
    static $cache = [];
    $email = strtolower(trim($email));
    if (isset($cache[$email])) return $cache[$email];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return $cache[$email] = 'Joueur DMD';
    $profile = dmd_read_profile($email);
    if (!is_array($profile)) $profile = [];
    $first = trim((string)($profile['prenom'] ?? $profile['first_name'] ?? $profile['firstname'] ?? ''));
    $last = trim((string)($profile['nom'] ?? $profile['last_name'] ?? $profile['lastname'] ?? ''));
    $name = trim($first . ' ' . $last);
    if ($name === '') {
        $name = trim((string)($profile['display_name'] ?? $profile['name'] ?? $profile['username'] ?? ''));
        if (filter_var($name, FILTER_VALIDATE_EMAIL)) $name = '';
    }
    return $cache[$email] = ($name !== '' && strlen($name) <= 120 ? $name : 'Joueur DMD');
}
function safeGame(array $g) {
    unset($g['secret']);
    $g['white_name'] = chessDisplayName((string)($g['white'] ?? ''));
    $g['black_name'] = chessDisplayName((string)($g['black'] ?? ''));
    return $g;
}
function idFile(string $dir,string $id) { if (!preg_match('/^[a-f0-9]{24}$/D',$id)) result(['ok'=>false,'error'=>'Partie invalide'],400);return $dir.'/'.$id.'.json'; }
function gameLock(string $file, callable $callback) {
    $h=@fopen($file,'c+');if (!$h) result(['ok'=>false,'error'=>'Stockage inaccessible'],500);
    if (!flock($h,LOCK_EX)){fclose($h);result(['ok'=>false,'error'=>'Verrouillage impossible'],503);}
    rewind($h);$data=stream_get_contents($h);$g=json_decode($data?:'',true);if(!is_array($g))$g=[];
    $out=$callback($g);
    if(isset($out['save'])&&$out['save']) {rewind($h);ftruncate($h,0);fwrite($h,json_encode($g,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));fflush($h);@chmod($file,0640);}
    flock($h,LOCK_UN);fclose($h);return $out['response']??[];
}
if ($action==='members') {
    $members=[]; $blocked=0;
    $profileBase=$root.'/users/profiles';
    foreach (glob($profileBase.'/*',GLOB_ONLYDIR) ?: [] as $folder) {
        if(count($members)>=500)break;
        $email=strtolower(trim(basename($folder)));
        if ($email===$user || !filter_var($email,FILTER_VALIDATE_EMAIL))continue;
        // Un profil DMD valide est requis. Aucune identité arbitraire n'est invitée.
        $profile=dmd_read_profile($email);
        if (!is_array($profile) || !$profile)continue;
        $allowed=dmd_user_has_module_permission($email,'DMD-Chess','use');
        if (!$allowed) $blocked++;
        $label=chessDisplayName($email);
        $members[]=['email'=>$email,'name'=>$label,'allowed'=>$allowed];
    }
    usort($members,function($a,$b){return ((int)$b['allowed'] <=> (int)$a['allowed']) ?: strcasecmp($a['name'],$b['name']);});
    result(['ok'=>true,'members'=>$members,'blocked'=>$blocked,'me'=>$user,'csrf'=>$token,'access_mode'=>function_exists('dmd_module_access_mode')?dmd_module_access_mode('DMD-Chess'):'controlled']);
}
if ($action==='list') {
    $items=[];foreach(glob($dir.'/*.json')?:[] as $path){if(count($items)>=200)break;$g=json_decode(@file_get_contents($path),true);if(is_array($g) && (($g['white']??'')===$user || ($g['black']??'')===$user) && empty($g['hidden'][$user])) $items[]=safeGame($g);}
    usort($items,function($a,$b){return ($b['updated']??0)<=>($a['updated']??0);});result(['ok'=>true,'me'=>$user,'csrf'=>$token,'games'=>$items]);
}
if ($action==='invite') {
    $target=strtolower(trim((string)($_POST['target']??''))); $side=(string)($_POST['side']??'w');
    if (!filter_var($target,FILTER_VALIDATE_EMAIL) || strlen($target)>180 || $target===$user) result(['ok'=>false,'error'=>'Adresse du destinataire invalide'],400);
    if (!is_dir($root.'/users/profiles/'.$target)) result(['ok'=>false,'error'=>'Ce membre ne possède pas de profil DoMyDesk'],404);
    if (!function_exists('dmd_user_has_module_permission') || !dmd_user_has_module_permission($target,'DMD-Chess','use')) result(['ok'=>false,'error'=>'Ce membre n’a pas accès à DMD-Chess'],403);
    foreach(glob($dir.'/*.json')?:[] as $existingPath){
        $existing=json_decode((string)@file_get_contents($existingPath),true);
        if(!is_array($existing) || !in_array($existing['state']??'', ['invited'],true))continue;
        if(($existing['inviter']??'')===$user && (($existing['white']??'')===$target || ($existing['black']??'')===$target))result(['ok'=>false,'error'=>'Une invitation est déjà en attente pour ce membre'],409);
    }
    if (!in_array($side,['w','b'],true))$side='w';$id=bin2hex(random_bytes(12));
    $g=['id'=>$id,'white'=>$side==='w'?$user:$target,'black'=>$side==='b'?$user:$target,'inviter'=>$user,'state'=>'invited','turn'=>'w','b'=>$initial,'castle'=>'KQkq','ep'=>-1,'half'=>0,'full'=>1,'last'=>null,'history'=>[],'moves'=>[],'over'=>'','created'=>time(),'updated'=>time(),'rev'=>0,'drawOffer'=>''];
    $path=idFile($dir,$id); if(@file_put_contents($path,json_encode($g,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX)===false)result(['ok'=>false,'error'=>'Écriture impossible'],500);@chmod($path,0640);result(['ok'=>true,'game'=>safeGame($g)]);
}
$id=(string)($_GET['id']??$_POST['id']??'');$file=idFile($dir,$id);
if ($action==='get') {if(!is_file($file))result(['ok'=>false,'error'=>'Partie introuvable'],404);$g=json_decode((string)@file_get_contents($file),true);if(!is_array($g))result(['ok'=>false,'error'=>'Partie invalide'],500);guardGame($g,$user);if(!empty($g['hidden'][$user]))result(['ok'=>false,'error'=>'Partie retirée'],404);result(['ok'=>true,'game'=>safeGame($g),'me'=>$user]);}
if(!is_file($file))result(['ok'=>false,'error'=>'Partie introuvable'],404);
$res=gameLock($file,function(&$g)use($action,$user,$id){
    if (!$g || ($g['id']??'')!==$id) result(['ok'=>false,'error'=>'Partie invalide'],404);
    guardGame($g,$user);$state=$g['state']??'';$side=$g['white']===$user?'w':'b';
    if($action==='cancel'){
        if($state!=='invited'||($g['inviter']??'')!==$user)result(['ok'=>false,'error'=>'Seul l’invitant peut annuler une invitation en attente'],409);
        $g['state']='cancelled';
    }elseif($action==='delete'){
        if($state==='playing')result(['ok'=>false,'error'=>'Terminez la partie avant de la retirer'],409);
        if($state==='invited')$g['state']=(($g['inviter']??'')===$user)?'cancelled':'rejected';
        elseif(!in_array($state,['cancelled','rejected','done'],true))result(['ok'=>false,'error'=>'Invitation non supprimable'],409);
        if(!isset($g['hidden'])||!is_array($g['hidden']))$g['hidden']=[];
        $g['hidden'][$user]=true;
    }elseif ($action==='accept' || $action==='reject') {
        if($state!=='invited'||($g['inviter']??'')===$user)result(['ok'=>false,'error'=>'Invitation non disponible'],409);
        $g['state']=$action==='accept'?'playing':'rejected';
    } elseif ($action==='move') {
        if ($state!=='playing'||($g['turn']??'')!==$side||!empty($g['over']))result(['ok'=>false,'error'=>'Ce n’est pas votre tour'],409);
        $move=json_decode((string)($_POST['move']??''),true);
        if(!is_array($move)||!isset($move['from'],$move['to'])||!is_int($move['from'])||!is_int($move['to'])||$move['from']<0||$move['from']>63||$move['to']<0||$move['to']>63)result(['ok'=>false,'error'=>'Coup invalide'],400);
        $next=json_decode((string)($_POST['position']??''),true);
        if(!is_array($next)||!isset($next['b'])||!is_array($next['b'])||count($next['b'])!==64 || count($g['moves']??[])>=500)result(['ok'=>false,'error'=>'Position invalide'],400);
        $piece=$g['b'][$move['from']]??null;
        if(!is_string($piece)||substr($piece,0,1)!==$side)result(['ok'=>false,'error'=>'Pièce non autorisée'],409);
        $promo=$move['promotion']??'';if(!in_array($promo,['','q','r','b','n'],true))result(['ok'=>false,'error'=>'Promotion invalide'],400);
        $expectedRev=(int)($_POST['rev']??-1);if($expectedRev!==($g['rev']??0))result(['ok'=>false,'error'=>'La partie a été modifiée, actualisation nécessaire'],409);
        $legalMoves=cr_legal($g);$actualMove=null;
        foreach($legalMoves as $candidate){if($candidate['from']===$move['from']&&$candidate['to']===$move['to']&&$candidate['promotion']===$promo){$actualMove=$candidate;break;}}
        if($actualMove===null)result(['ok'=>false,'error'=>'Coup illégal'],409);
        $computed=cr_apply($g,$actualMove);
        foreach(['b','turn','castle','ep','half','full','last'] as $field){if(!array_key_exists($field,$next)||$next[$field]!==$computed[$field])result(['ok'=>false,'error'=>'Position incohérente'],409);}
        foreach(['b','turn','castle','ep','half','full','last'] as $field)$g[$field]=$computed[$field];
        $g['drawOffer']='';
        if($computed['half']>=100)$g['over']='Nulle — règle des 50 coups';
        elseif(!cr_legal($computed))$g['over']=cr_check($computed['b'],$computed['turn'])?'Échec et mat — '.($side==='w'?'Blancs':'Noirs').' gagnent':'Pat — partie nulle';
        if($g['over'])$g['state']='done';
        $notation=substr((string)($_POST['notation']??''),0,32);$g['history'][]=$notation;$g['moves'][]=['by'=>$user,'from'=>$move['from'],'to'=>$move['to'],'promotion'=>$promo];
    } elseif ($action==='resign' || $action==='draw') {
        if($state!=='playing')result(['ok'=>false,'error'=>'Partie inactive'],409);
        if($action==='draw'){
            if(($g['drawOffer']??'')===$user)result(['ok'=>false,'error'=>'Offre de nulle déjà envoyée'],409);
            if(($g['drawOffer']??'')!=='' && $g['drawOffer']!==$user){$g['state']='done';$g['over']='Partie nulle par accord';$g['drawOffer']='';}
            else $g['drawOffer']=$user;
        } else {$g['state']='done';$g['over']=($side==='w'?'Blancs':'Noirs').' abandonnent';}

    }else result(['ok'=>false,'error'=>'Action inconnue'],400);
    $g['updated']=time();$g['rev']=($g['rev']??0)+1;
    return ['save'=>true,'response'=>['ok'=>true,'game'=>safeGame($g)]];
});result($res);
