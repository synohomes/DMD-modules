<?php
/* Moteur de validation serveur — règles classiques (PHP 7.3+). */
function cr_side($p){return is_string($p)?$p[0]:'';}
function cr_enemy($s){return $s==='w'?'b':'w';}
function cr_inside($r,$c){return $r>=0&&$r<8&&$c>=0&&$c<8;}
function cr_attacked($b,$at,$side){
 $r=intdiv($at,8);$c=$at%8;
 foreach([-1,1] as $dc){$rr=$r+($side==='w'?1:-1);if(cr_inside($rr,$c+$dc)&&($b[$rr*8+$c+$dc]??null)===$side.'p')return true;}
 foreach([[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]] as $d){$rr=$r+$d[0];$cc=$c+$d[1];if(cr_inside($rr,$cc)&&($b[$rr*8+$cc]??null)===$side.'n')return true;}
 foreach([[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]] as $d){$rr=$r+$d[0];$cc=$c+$d[1];$distance=1;while(cr_inside($rr,$cc)){$p=$b[$rr*8+$cc]??null;if($p!==null){if(cr_side($p)===$side && (($distance===1&&$p[1]==='k')||(($d[0]!==0&&$d[1]!==0?'bq':'rq')!==''&&strpos(($d[0]!==0&&$d[1]!==0?'bq':'rq'),$p[1])!==false)))return true;break;}$rr+=$d[0];$cc+=$d[1];$distance++;}}
 return false;
}
function cr_check($b,$side){$king=array_search($side.'k',$b,true);return $king===false||cr_attacked($b,(int)$king,cr_enemy($side));}
function cr_apply($g,$move){
 $n=$g;$n['b']=$g['b'];$b=&$n['b'];$from=$move['from'];$to=$move['to'];$side=$g['turn'];$p=$b[$from];$captured=$b[$to];$b[$to]=$p;$b[$from]=null;
 if(!empty($move['ep'])){$at=$to+($side==='w'?8:-8);$captured=$b[$at];$b[$at]=null;}
 if(!empty($move['promotion']))$b[$to]=$side.$move['promotion'];
 if(!empty($move['castle'])){$r=$side==='w'?7:0;$rs=$r*8+($move['castle']==='K'?7:0);$re=$r*8+($move['castle']==='K'?5:3);$b[$re]=$b[$rs];$b[$rs]=null;}
 $rights=$g['castle'];if($p[1]==='k')$rights=str_replace($side==='w'?['K','Q']:['k','q'],'',$rights);
 foreach([63=>'K',56=>'Q',7=>'k',0=>'q'] as $sq=>$letter)if($from===$sq||$to===$sq)$rights=str_replace($letter,'',$rights);
 $n['castle']=$rights;$n['ep']=$p[1]==='p'&&abs($to-$from)===16?intdiv($from+$to,2):-1;
 $n['half']=($p[1]==='p'||$captured!==null)?0:$g['half']+1;$n['full']=$g['full']+($side==='b'?1:0);
 $n['turn']=cr_enemy($side);$n['last']=[$from,$to];return $n;
}
function cr_legal($g){
 $b=$g['b'];$side=$g['turn'];$out=[];
 $push=function($from,$to,$promo='',$ep=false,$castle='')use(&$out,$g,$side){$m=['from'=>$from,'to'=>$to,'promotion'=>$promo,'ep'=>$ep,'castle'=>$castle];$n=cr_apply($g,$m);if(!cr_check($n['b'],$side))$out[]=$m;};
 for($i=0;$i<64;$i++){
 $piece=$b[$i];if(!is_string($piece)||cr_side($piece)!==$side)continue;$type=$piece[1];$r=intdiv($i,8);$c=$i%8;
 if($type==='p'){$d=$side==='w'?-1:1;$rr=$r+$d;$start=$side==='w'?6:1;
   if(cr_inside($rr,$c)&&$b[$rr*8+$c]===null){$to=$rr*8+$c;if($rr===0||$rr===7){foreach(['q','r','b','n'] as $pr)$push($i,$to,$pr);}else $push($i,$to);if($r===$start&&$b[($r+2*$d)*8+$c]===null)$push($i,($r+2*$d)*8+$c);}
   foreach([-1,1] as $dc)if(cr_inside($rr,$c+$dc)){$to=$rr*8+$c+$dc;$capture=$b[$to]!==null&&cr_side($b[$to])!==$side&&$b[$to][1]!=='k';$ep=$to===($g['ep']??-1)&&$b[$to]===null&&($b[$r*8+$c+$dc]??null)===cr_enemy($side).'p';if($capture||$ep){if($rr===0||$rr===7){foreach(['q','r','b','n'] as $pr)$push($i,$to,$pr,$ep);}else $push($i,$to,'',$ep);}}
 }elseif($type==='n'){
   foreach([[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]] as $d){$rr=$r+$d[0];$cc=$c+$d[1];if(cr_inside($rr,$cc)){$to=$rr*8+$cc;$p=$b[$to];if($p===null||(cr_side($p)!==$side&&$p[1]!=='k'))$push($i,$to);}}
 }elseif($type==='k'){
   for($dr=-1;$dr<=1;$dr++)for($dc=-1;$dc<=1;$dc++){if(!$dr&&!$dc)continue;$rr=$r+$dr;$cc=$c+$dc;if(cr_inside($rr,$cc)){$to=$rr*8+$cc;$p=$b[$to];if($p===null||(cr_side($p)!==$side&&$p[1]!=='k'))$push($i,$to);}}
   $home=$side==='w'?60:4;$rights=$g['castle'];$r0=$side==='w'?7:0;
   if($i===$home&&!cr_check($b,$side)){
    if(strpos($rights,$side==='w'?'K':'k')!==false&&$b[$home+1]===null&&$b[$home+2]===null&&$b[$r0*8+7]===$side.'r'&&!cr_attacked($b,$home+1,cr_enemy($side))&&!cr_attacked($b,$home+2,cr_enemy($side)))$push($i,$home+2,'',false,'K');
    if(strpos($rights,$side==='w'?'Q':'q')!==false&&$b[$home-1]===null&&$b[$home-2]===null&&$b[$home-3]===null&&$b[$r0*8]===$side.'r'&&!cr_attacked($b,$home-1,cr_enemy($side))&&!cr_attacked($b,$home-2,cr_enemy($side)))$push($i,$home-2,'',false,'Q');
   }
 }else{
   $ds=[];if($type==='q'||$type==='b')$ds=array_merge($ds,[[-1,-1],[-1,1],[1,-1],[1,1]]);if($type==='q'||$type==='r')$ds=array_merge($ds,[[-1,0],[1,0],[0,-1],[0,1]]);
   foreach($ds as $d){$rr=$r+$d[0];$cc=$c+$d[1];while(cr_inside($rr,$cc)){$to=$rr*8+$cc;$p=$b[$to];if($p===null)$push($i,$to);else{if(cr_side($p)!==$side&&$p[1]!=='k')$push($i,$to);break;}$rr+=$d[0];$cc+=$d[1];}}
 }
 }
 return $out;
}
