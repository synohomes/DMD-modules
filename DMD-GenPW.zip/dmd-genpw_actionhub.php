<?php
declare(strict_types=1);

require_once __DIR__ . '/dmd-genpw_crypto.php';

function dmd_genpw_actionhub_owned_file($email) {
    return dmd_genpw_user_dir($email) . '/pw.json';
}

function dmd_genpw_actionhub_shared_file($email) {
    return dmd_genpw_user_dir($email) . '/shared.json';
}

function dmd_genpw_actionhub_local_id($resource) {
    if (!is_array($resource)) return null;
    $id = isset($resource['id']) ? (string)$resource['id'] : '';
    $prefix = DMD_GENPW_ID . ':credential:';
    if (strpos($id, $prefix) !== 0) return null;
    return dmd_genpw_valid_id(substr($id, strlen($prefix)));
}

function dmd_genpw_actionhub_generate_password($length, $withSpecials) {
    $length = max(12, min(128, (int)$length));
    $lower = 'abcdefghijkmnopqrstuvwxyz';
    $upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    $digits = '23456789';
    $specials = '!@#$%^&*()-_=+[]{};:,.?';
    $groups = array($lower, $upper, $digits);
    if ($withSpecials) $groups[] = $specials;

    $chars = array();
    foreach ($groups as $group) {
        $chars[] = $group[random_int(0, strlen($group) - 1)];
    }
    $pool = implode('', $groups);
    while (count($chars) < $length) {
        $chars[] = $pool[random_int(0, strlen($pool) - 1)];
    }
    for ($i = count($chars) - 1; $i > 0; $i--) {
        $j = random_int(0, $i);
        $tmp = $chars[$i];
        $chars[$i] = $chars[$j];
        $chars[$j] = $tmp;
    }
    return implode('', $chars);
}

function dmd_genpw_actionhub_validate_url($value) {
    $url = dmd_genpw_clean($value, 2048);
    if ($url === '') return '';
    $valid = filter_var($url, FILTER_VALIDATE_URL);
    $scheme = is_string($valid) ? strtolower((string)parse_url($valid, PHP_URL_SCHEME)) : '';
    if ($valid === false || !in_array($scheme, array('http', 'https'), true)) {
        throw new InvalidArgumentException('L’URL doit commencer par http:// ou https://.');
    }
    return $url;
}

function dmd_genpw_actionhub_require_unlocked($email) {
    if (dmd_genpw_is_unlocked($email)) return null;
    return array(
        'ok' => false,
        'error' => 'vault_locked',
        'message' => 'Le coffre DMD-GenPW doit être déverrouillé avant cette action.'
    );
}

function dmd_genpw_actionhub_resolve_owned($email, $reference, &$owned = null, &$id = null, &$entry = null) {
    $reference = dmd_genpw_clean($reference, 180);
    if ($reference === '') {
        return array('ok'=>false,'error'=>'missing_credential','message'=>'Indique le nom ou l’ID de l’entrée DMD-GenPW.');
    }

    $file = dmd_genpw_actionhub_owned_file($email);
    $owned = dmd_genpw_read_json($file, array());

    $candidate = $reference;
    $prefix = DMD_GENPW_ID . ':credential:';
    if (strpos($candidate, $prefix) === 0) $candidate = substr($candidate, strlen($prefix));
    $validId = dmd_genpw_valid_id($candidate);
    if ($validId !== null && isset($owned[$validId]) && is_array($owned[$validId])) {
        $id = $validId;
        $entry = $owned[$id];
        return array('ok'=>true,'file'=>$file);
    }

    $matches = array();
    foreach ($owned as $itemId => $item) {
        if (dmd_genpw_valid_id($itemId) === null || !is_array($item)) continue;
        $name = dmd_genpw_clean(isset($item['name']) ? $item['name'] : '', 120);
        if ($name !== '' && strcasecmp($name, $reference) === 0) {
            $matches[$itemId] = $item;
        }
    }
    if (count($matches) === 1) {
        $id = (string)array_key_first($matches);
        $entry = $matches[$id];
        return array('ok'=>true,'file'=>$file);
    }
    if (count($matches) > 1) {
        return array('ok'=>false,'error'=>'ambiguous_credential','message'=>'Plusieurs entrées portent ce nom. Utilise l’ID de l’entrée.');
    }
    return array('ok'=>false,'error'=>'credential_not_found','message'=>'Entrée DMD-GenPW introuvable : ' . $reference . '.');
}

function dmd_genpw_actionhub_update_shared_metadata($owner, $sourceId, $entry) {
    $index = dmd_genpw_share_index();
    $updated = 0;
    $changedIndex = false;
    foreach ($index as $shareId => &$row) {
        if (!is_array($row) || (string)($row['owner'] ?? '') !== $owner || (string)($row['source_id'] ?? '') !== $sourceId) continue;
        $recipient = (string)($row['recipient'] ?? '');
        if (filter_var($recipient, FILTER_VALIDATE_EMAIL) === false) continue;
        $file = dmd_genpw_actionhub_shared_file($recipient);
        $shared = dmd_genpw_read_json($file, array());
        if (!isset($shared[$shareId]) || !is_array($shared[$shareId])) continue;
        foreach (array('name','cat','url','user','notes') as $field) {
            $shared[$shareId][$field] = isset($entry[$field]) ? $entry[$field] : '';
        }
        $shared[$shareId]['date'] = date('d/m/Y H:i');
        $shared[$shareId]['updated_at'] = date(DATE_ATOM);
        dmd_genpw_write_json($file, $shared);
        $row['label'] = (string)($entry['name'] ?? 'Identifiant');
        $row['updated_at'] = date(DATE_ATOM);
        $changedIndex = true;
        $updated++;
    }
    unset($row);
    if ($changedIndex) dmd_genpw_write_share_index($index);
    return $updated;
}

function dmd_genpw_actionhub_sync_shared_secret($owner, $sourceId, $entry, $secret) {
    $index = dmd_genpw_share_index();
    $updated = 0;
    $changedIndex = false;
    foreach ($index as $shareId => &$row) {
        if (!is_array($row) || (string)($row['owner'] ?? '') !== $owner || (string)($row['source_id'] ?? '') !== $sourceId) continue;
        $recipient = (string)($row['recipient'] ?? '');
        if (filter_var($recipient, FILTER_VALIDATE_EMAIL) === false) continue;
        try {
            $file = dmd_genpw_actionhub_shared_file($recipient);
            $shared = dmd_genpw_read_json($file, array());
            if (!isset($shared[$shareId]) || !is_array($shared[$shareId])) continue;
            $recipientKey = dmd_genpw_key(dmd_genpw_user_dir($recipient), $recipient);
            $encrypted = dmd_genpw_encrypt($secret, $recipientKey, dmd_genpw_aad($recipient, $shareId));
            $base = $shared[$shareId];
            foreach (array('pw','iv','tag','data','cipher','v') as $field) unset($base[$field]);
            $shared[$shareId] = array_merge($base, array(
                'name'=>(string)($entry['name'] ?? 'Identifiant'),
                'cat'=>(string)($entry['cat'] ?? 'Autre'),
                'url'=>(string)($entry['url'] ?? ''),
                'user'=>(string)($entry['user'] ?? ''),
                'notes'=>(string)($entry['notes'] ?? ''),
                'date'=>date('d/m/Y H:i'),
                'updated_at'=>date(DATE_ATOM)
            ), $encrypted);
            dmd_genpw_write_json($file, $shared);
            $row['label'] = (string)($entry['name'] ?? 'Identifiant');
            $row['updated_at'] = date(DATE_ATOM);
            $changedIndex = true;
            $updated++;
        } catch (Throwable $e) {
            // Un partage cassé ne doit pas empêcher la rotation du coffre du propriétaire.
        }
    }
    unset($row);
    if ($changedIndex) dmd_genpw_write_share_index($index);
    return $updated;
}

function dmd_genpw_actionhub_share($email, $sourceId, $entry, $recipients) {
    $recipients = is_array($recipients) ? $recipients : array();
    $key = dmd_genpw_key(dmd_genpw_user_dir($email), $email);
    $owned = dmd_genpw_read_json(dmd_genpw_actionhub_owned_file($email), array());
    $secret = dmd_genpw_decrypt_entry($owned, $sourceId, $key, $email, dmd_genpw_actionhub_owned_file($email));
    $index = dmd_genpw_share_index();
    $done = array();

    foreach ($recipients as $recipient) {
        $recipient = trim((string)$recipient);
        if ($recipient === $email || filter_var($recipient, FILTER_VALIDATE_EMAIL) === false) continue;
        dmd_genpw_profile_dir($recipient);
        if (!dmd_genpw_user_has_permission($recipient, 'module.view')) continue;

        $existing = '';
        foreach ($index as $shareId => $row) {
            if (is_array($row) && (string)($row['owner'] ?? '') === $email && (string)($row['source_id'] ?? '') === $sourceId && (string)($row['recipient'] ?? '') === $recipient) {
                $existing = (string)$shareId;
                break;
            }
        }
        $shareId = $existing !== '' ? $existing : bin2hex(random_bytes(8));
        $file = dmd_genpw_actionhub_shared_file($recipient);
        $shared = dmd_genpw_read_json($file, array());
        $recipientKey = dmd_genpw_key(dmd_genpw_user_dir($recipient), $recipient);
        $encrypted = dmd_genpw_encrypt($secret, $recipientKey, dmd_genpw_aad($recipient, $shareId));
        $shared[$shareId] = array_merge(array(
            'name'=>(string)($entry['name'] ?? 'Identifiant'),
            'cat'=>(string)($entry['cat'] ?? 'Autre'),
            'url'=>(string)($entry['url'] ?? ''),
            'user'=>(string)($entry['user'] ?? ''),
            'notes'=>(string)($entry['notes'] ?? ''),
            'date'=>date('d/m/Y H:i'),
            'created_at'=>date(DATE_ATOM),
            'updated_at'=>date(DATE_ATOM),
            'owner'=>$email,
            'source_id'=>$sourceId,
            'shared_at'=>date(DATE_ATOM)
        ), $encrypted);
        dmd_genpw_write_json($file, $shared);
        $index[$shareId] = array(
            'owner'=>$email,
            'recipient'=>$recipient,
            'source_id'=>$sourceId,
            'recipient_id'=>$shareId,
            'label'=>(string)($entry['name'] ?? 'Identifiant'),
            'created_at'=>isset($index[$shareId]['created_at']) ? $index[$shareId]['created_at'] : date(DATE_ATOM),
            'updated_at'=>date(DATE_ATOM)
        );
        $done[] = $recipient;
        dmd_genpw_notify($recipient, 'credential_shared', 'Nouvel accès partagé', (string)($entry['name'] ?? 'Identifiant') . ' a été partagé avec vous par ' . $email . '.', array('source_id'=>$sourceId,'share_id'=>$shareId));
    }
    dmd_genpw_write_share_index($index);
    return array_values(array_unique($done));
}

function dmd_genpw_actionhub_revoke_for_users($email, $sourceId, $recipients) {
    $recipients = array_values(array_unique(array_map('strval', is_array($recipients) ? $recipients : array())));
    $index = dmd_genpw_share_index();
    $revoked = array();
    foreach (array_keys($index) as $shareId) {
        $row = isset($index[$shareId]) && is_array($index[$shareId]) ? $index[$shareId] : null;
        if (!$row || (string)($row['owner'] ?? '') !== $email || (string)($row['source_id'] ?? '') !== $sourceId) continue;
        $recipient = (string)($row['recipient'] ?? '');
        if (!in_array($recipient, $recipients, true)) continue;
        $file = dmd_genpw_actionhub_shared_file($recipient);
        $shared = dmd_genpw_read_json($file, array());
        unset($shared[$shareId]);
        dmd_genpw_write_json($file, $shared);
        unset($index[$shareId]);
        $revoked[] = $recipient;
        dmd_genpw_notify($recipient, 'credential_share_revoked', 'Partage retiré', (string)($row['label'] ?? 'Un accès') . ' n’est plus partagé avec vous.', array('source_id'=>$sourceId,'share_id'=>$shareId));
    }
    dmd_genpw_write_share_index($index);
    return array_values(array_unique($revoked));
}

function dmd_genpw_actionhub_revoke_all($email, $sourceId) {
    $index = dmd_genpw_share_index();
    $count = 0;
    foreach (array_keys($index) as $shareId) {
        $row = isset($index[$shareId]) && is_array($index[$shareId]) ? $index[$shareId] : null;
        if (!$row || (string)($row['owner'] ?? '') !== $email || (string)($row['source_id'] ?? '') !== $sourceId) continue;
        $recipient = (string)($row['recipient'] ?? '');
        if (filter_var($recipient, FILTER_VALIDATE_EMAIL) !== false) {
            $file = dmd_genpw_actionhub_shared_file($recipient);
            $shared = dmd_genpw_read_json($file, array());
            unset($shared[$shareId]);
            dmd_genpw_write_json($file, $shared);
            dmd_genpw_notify($recipient, 'credential_share_revoked', 'Partage retiré', (string)($row['label'] ?? 'Un accès') . ' n’est plus partagé avec vous.', array('source_id'=>$sourceId,'share_id'=>$shareId));
        }
        unset($index[$shareId]);
        $count++;
    }
    dmd_genpw_write_share_index($index);
    return $count;
}

function dmd_genpw_actionhub_store_generated($email, $payload) {
    /*
     * Action de scénario "aveugle" : le secret est généré côté serveur,
     * chiffré puis stocké sans jamais être renvoyé à ActionHub ou au navigateur.
     * Elle dépend donc de vault.create, mais pas de l'état visuel verrouillé du coffre.
     * Les actions qui lisent/modifient un secret existant restent, elles, protégées
     * par dmd_genpw_actionhub_require_unlocked().
     */
    $name = dmd_genpw_clean($payload['name'] ?? '', 120);
    if ($name === '') $name = 'Identifiant généré';
    $cat = dmd_genpw_clean($payload['category'] ?? 'Application', 40);
    if (!in_array($cat, dmd_genpw_categories($email), true)) $cat = dmd_genpw_fallback_category($email);
    try { $url = dmd_genpw_actionhub_validate_url($payload['url'] ?? ''); }
    catch (InvalidArgumentException $e) { return array('ok'=>false,'error'=>'invalid_url','message'=>$e->getMessage()); }
    $user = dmd_genpw_clean($payload['user'] ?? '', 255);
    $notes = dmd_genpw_clean($payload['notes'] ?? '', 2000);
    $length = isset($payload['length']) ? (int)$payload['length'] : 20;
    $withSpecials = !array_key_exists('specials', $payload) || !empty($payload['specials']);
    $secret = dmd_genpw_actionhub_generate_password($length, $withSpecials);

    $file = dmd_genpw_actionhub_owned_file($email);
    $owned = dmd_genpw_read_json($file, array());
    do { $id = bin2hex(random_bytes(8)); } while (isset($owned[$id]));
    $key = dmd_genpw_key(dmd_genpw_user_dir($email), $email);
    $encrypted = dmd_genpw_encrypt($secret, $key, dmd_genpw_aad($email, $id));
    $now = date(DATE_ATOM);
    $owned[$id] = array_merge(array(
        'name'=>$name,'cat'=>$cat,'url'=>$url,'user'=>$user,'notes'=>$notes,
        'created_at'=>$now,'updated_at'=>$now,'date'=>date('d/m/Y H:i')
    ), $encrypted);
    dmd_genpw_write_json($file, $owned);
    $resource = dmd_genpw_resource($id, $name, $email);
    dmd_genpw_log('credential.create', $id, 'success', array('category'=>$cat,'source'=>'actionhub','generated'=>true), $resource);

    return array(
        'ok'=>true,
        'message'=>'Identifiant généré et enregistré dans DMD-GenPW.',
        'data'=>array('module'=>DMD_GENPW_ID,'credential_id'=>$id,'resource_id'=>$resource['id'],'name'=>$name,'reload'=>true),
        'event_emitted'=>true
    );
}

function dmd_genpw_actionhub_handle($context) {
    $context = is_array($context) ? $context : array();
    $email = trim((string)($context['email'] ?? ''));
    $action = is_array($context['action'] ?? null) ? $context['action'] : array();
    $actionId = trim((string)($action['id'] ?? ''));
    $payload = is_array($context['payload'] ?? null) ? $context['payload'] : array();
    $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;

    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        return array('ok'=>false,'error'=>'invalid_user','message'=>'Utilisateur DMD-GenPW invalide.');
    }

    if ($actionId === 'credential.create-generated') {
        return dmd_genpw_actionhub_store_generated($email, $payload);
    }

    if ($actionId === 'vault.lock-scenario' || $actionId === 'vault.lock') {
        unset($_SESSION['dmd_genpw_unlocked_at'], $_SESSION['dmd_genpw_qr_tokens']);
        dmd_genpw_log('vault.lock', 'vault', 'success', array('source'=>'actionhub'), dmd_genpw_vault_resource($email));
        return array('ok'=>true,'message'=>'Coffre DMD-GenPW verrouillé.','data'=>array('module'=>DMD_GENPW_ID,'locked'=>true,'reload'=>true),'event_emitted'=>true);
    }

    if ($locked = dmd_genpw_actionhub_require_unlocked($email)) return $locked;

    if ($actionId === 'credential.edit') {
        $localId = dmd_genpw_actionhub_local_id($resource);
        if ($localId === null) return array('ok'=>false,'error'=>'invalid_resource','message'=>'Identifiant DMD-GenPW invalide.');
        $owned = dmd_genpw_read_json(dmd_genpw_actionhub_owned_file($email), array());
        if (empty($owned[$localId]) || !is_array($owned[$localId])) {
            return array('ok'=>false,'error'=>'read_only_or_missing','message'=>'Cette entrée n’est pas modifiable par cet utilisateur.');
        }
        return array(
            'ok'=>true,
            'message'=>'Ouverture de l’entrée DMD-GenPW.',
            'data'=>array('module'=>DMD_GENPW_ID,'command'=>'edit-credential','credential_id'=>$localId)
        );
    }

    if ($actionId === 'credential.rotate-generated-resource' || $actionId === 'credential.delete-resource') {
        $localId = dmd_genpw_actionhub_local_id($resource);
        if ($localId === null) return array('ok'=>false,'error'=>'invalid_resource','message'=>'Identifiant DMD-GenPW invalide.');
        $payload['entry_ref'] = $localId;
        if ($actionId === 'credential.rotate-generated-resource') {
            $actionId = 'credential.rotate-generated';
            $payload['length'] = 20;
            $payload['specials'] = true;
        } else {
            $actionId = 'credential.delete';
        }
    }

    $owned = null; $id = null; $entry = null;
    $needsEntry = in_array($actionId, array(
        'credential.assert-exists','credential.rotate-generated','credential.rename','credential.set-category',
        'credential.set-login','credential.set-url','credential.set-notes','credential.share','credential.revoke-share',
        'credential.delete','credential.open'
    ), true);
    if ($needsEntry) {
        $resolved = dmd_genpw_actionhub_resolve_owned($email, $payload['entry_ref'] ?? '', $owned, $id, $entry);
        if (empty($resolved['ok'])) return $resolved;
    }

    if ($actionId === 'credential.assert-exists') {
        dmd_genpw_log('credential.check', $id, 'success', array('source'=>'actionhub'), dmd_genpw_resource($id, (string)$entry['name'], $email));
        return array('ok'=>true,'message'=>'Entrée trouvée : ' . (string)$entry['name'] . '.','data'=>array('module'=>DMD_GENPW_ID,'credential_id'=>$id),'event_emitted'=>true);
    }

    if ($actionId === 'credential.rotate-generated') {
        $length = isset($payload['length']) ? (int)$payload['length'] : 20;
        $specials = !array_key_exists('specials', $payload) || !empty($payload['specials']);
        $secret = dmd_genpw_actionhub_generate_password($length, $specials);
        $key = dmd_genpw_key(dmd_genpw_user_dir($email), $email);
        foreach (array('pw','iv','tag','data','cipher','v') as $field) unset($entry[$field]);
        $entry = array_merge($entry, dmd_genpw_encrypt($secret, $key, dmd_genpw_aad($email, $id)));
        $entry['updated_at'] = date(DATE_ATOM); $entry['date'] = date('d/m/Y H:i');
        $owned[$id] = $entry;
        dmd_genpw_write_json(dmd_genpw_actionhub_owned_file($email), $owned);
        $sharedUpdated = dmd_genpw_actionhub_sync_shared_secret($email, $id, $entry, $secret);
        dmd_genpw_log('credential.password.rotate', $id, 'success', array('source'=>'actionhub','shared_updated'=>$sharedUpdated), dmd_genpw_resource($id, (string)$entry['name'], $email));
        return array('ok'=>true,'message'=>'Mot de passe régénéré pour ' . (string)$entry['name'] . '.','data'=>array('module'=>DMD_GENPW_ID,'credential_id'=>$id,'shared_updated'=>$sharedUpdated,'reload'=>true),'event_emitted'=>true);
    }

    if (in_array($actionId, array('credential.rename','credential.set-category','credential.set-login','credential.set-url','credential.set-notes'), true)) {
        try {
            if ($actionId === 'credential.rename') {
                $value = dmd_genpw_clean($payload['new_name'] ?? '', 120);
                if ($value === '') return array('ok'=>false,'error'=>'invalid_name','message'=>'Le nouveau nom est obligatoire.');
                $entry['name'] = $value;
            } elseif ($actionId === 'credential.set-category') {
                $value = dmd_genpw_clean($payload['category'] ?? '', 40);
                if (!in_array($value, dmd_genpw_categories($email), true)) return array('ok'=>false,'error'=>'invalid_category','message'=>'Catégorie DMD-GenPW invalide.');
                $entry['cat'] = $value;
            } elseif ($actionId === 'credential.set-login') {
                $entry['user'] = dmd_genpw_clean($payload['login'] ?? '', 255);
            } elseif ($actionId === 'credential.set-url') {
                $entry['url'] = dmd_genpw_actionhub_validate_url($payload['url'] ?? '');
            } elseif ($actionId === 'credential.set-notes') {
                $entry['notes'] = dmd_genpw_clean($payload['notes'] ?? '', 2000);
            }
        } catch (InvalidArgumentException $e) {
            return array('ok'=>false,'error'=>'invalid_value','message'=>$e->getMessage());
        }
        $entry['updated_at'] = date(DATE_ATOM); $entry['date'] = date('d/m/Y H:i');
        $owned[$id] = $entry;
        dmd_genpw_write_json(dmd_genpw_actionhub_owned_file($email), $owned);
        $sharedUpdated = dmd_genpw_actionhub_update_shared_metadata($email, $id, $entry);
        dmd_genpw_log($actionId, $id, 'success', array('source'=>'actionhub','shared_updated'=>$sharedUpdated), dmd_genpw_resource($id, (string)$entry['name'], $email));
        return array('ok'=>true,'message'=>'Entrée DMD-GenPW mise à jour.','data'=>array('module'=>DMD_GENPW_ID,'credential_id'=>$id,'shared_updated'=>$sharedUpdated,'reload'=>true),'event_emitted'=>true);
    }

    if ($actionId === 'credential.share') {
        $recipients = is_array($payload['recipients'] ?? null) ? $payload['recipients'] : array();
        if (!$recipients) return array('ok'=>false,'error'=>'no_recipient','message'=>'Sélectionne au moins un utilisateur.');
        $done = dmd_genpw_actionhub_share($email, $id, $entry, $recipients);
        dmd_genpw_log('credential.share', $id, 'success', array('source'=>'actionhub','recipients'=>$done), dmd_genpw_resource($id, (string)$entry['name'], $email));
        return array('ok'=>true,'message'=>count($done) . ' partage(s) appliqué(s).','data'=>array('module'=>DMD_GENPW_ID,'credential_id'=>$id,'shared_with'=>$done,'reload'=>true),'event_emitted'=>true);
    }

    if ($actionId === 'credential.revoke-share') {
        $recipients = is_array($payload['recipients'] ?? null) ? $payload['recipients'] : array();
        if (!$recipients) return array('ok'=>false,'error'=>'no_recipient','message'=>'Sélectionne au moins un utilisateur.');
        $done = dmd_genpw_actionhub_revoke_for_users($email, $id, $recipients);
        dmd_genpw_log('credential.share.revoke', $id, 'success', array('source'=>'actionhub','recipients'=>$done), dmd_genpw_resource($id, (string)$entry['name'], $email));
        return array('ok'=>true,'message'=>count($done) . ' partage(s) retiré(s).','data'=>array('module'=>DMD_GENPW_ID,'credential_id'=>$id,'revoked_from'=>$done,'reload'=>true),'event_emitted'=>true);
    }

    if ($actionId === 'credential.delete') {
        $label = (string)($entry['name'] ?? 'Identifiant');
        $revoked = dmd_genpw_actionhub_revoke_all($email, $id);
        unset($owned[$id]);
        dmd_genpw_write_json(dmd_genpw_actionhub_owned_file($email), $owned);
        dmd_genpw_log('credential.delete', $id, 'success', array('source'=>'actionhub','shares_revoked'=>$revoked), dmd_genpw_resource($id, $label, $email));
        return array('ok'=>true,'message'=>'Entrée supprimée : ' . $label . '.','data'=>array('module'=>DMD_GENPW_ID,'credential_id'=>$id,'shares_revoked'=>$revoked,'reload'=>true),'event_emitted'=>true);
    }

    if ($actionId === 'credential.open') {
        dmd_genpw_log('credential.open', $id, 'success', array('source'=>'actionhub'), dmd_genpw_resource($id, (string)$entry['name'], $email));
        return array(
            'ok'=>true,
            'message'=>'Ouverture de ' . (string)$entry['name'] . ' dans DMD-GenPW.',
            'data'=>array(
                'module'=>DMD_GENPW_ID,
                'credential_id'=>$id,
                'ui'=>array('type'=>'genpw-open-credential','credential_id'=>$id)
            ),
            'event_emitted'=>true
        );
    }

    return array('ok'=>false,'error'=>'unknown_action','message'=>'Action ActionHub DMD-GenPW inconnue.');
}
