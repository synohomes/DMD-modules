<?php
declare(strict_types=1);

require_once __DIR__ . '/dmd-genpw_crypto.php';
require_once __DIR__ . '/dmd-genpw_pro.php';

/*
 * DMD-GenPW - partage public v2
 * Le secret du lien est placé dans #fragment : il n'est pas envoyé par le navigateur
 * au serveur dans l'URL HTTP et n'apparaît donc pas dans les logs HTTP standards.
 * Au premier affichage, le navigateur transmet le secret en POST, puis le fragment est
 * retiré immédiatement de la barre d'adresse avec history.replaceState().
 */

$https = !empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off';
if (session_status() === PHP_SESSION_NONE) {
    session_name('DMDGP_PUBLIC');
    session_set_cookie_params(array(
        'lifetime' => 0,
        'path' => rtrim(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/')), '/') . '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => 'Lax'
    ));
    session_start();
}

function sh_h($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function sh_headers(): void {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
}

function sh_fail(string $m, int $s = 404): void {
    http_response_code($s);
    sh_headers();
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Partage GenPW</title>'
       . '<style>*{box-sizing:border-box}body{margin:0;background:#0b1220;color:#e7edf7;font:14px system-ui,sans-serif;display:grid;place-items:center;min-height:100vh;padding:16px}.c{width:min(620px,100%);border:1px solid #34445a;border-radius:14px;background:#101b2a;padding:20px}h1{font-size:18px;margin:0 0 12px}p{color:#c8d3e2}</style>'
       . '<main class="c"><h1>🔐 Partage DMD-GenPW</h1><p>'.sh_h($m).'</p></main></html>';
    exit;
}

function sh_file(): string {
    $d = dmd_genpw_system_dir() . '/private';
    dmd_genpw_protect_directory($d);
    return $d . '/public_shares.json';
}

function sh_rows(): array {
    return dmd_genpw_read_json(sh_file(), array());
}

function sh_write(array $r): void {
    dmd_genpw_write_json(sh_file(), $r);
}

function sh_share_by_id(array $rows, string $sid): array {
    if (!preg_match('/^[a-f0-9]{24}$/D', $sid)) return array();
    return isset($rows[$sid]) && is_array($rows[$sid]) ? $rows[$sid] : array();
}

function sh_key(string $token, string $sid, string $pin = ''): string {
    $material = $token . "\0" . $pin;
    if (function_exists('hash_hkdf')) {
        return hash_hkdf('sha256', $material, 32, 'DMD-GenPW public share v2', $sid);
    }
    return hash_hmac('sha256', "DMD-GenPW public share v2\0" . $sid . "\0" . $material, $material, true);
}

function sh_aad(string $sid): string {
    return 'DMD-GenPW|public-share|v2|' . $sid . '|snapshot';
}

function sh_blob_aad(string $sid, string $bid): string {
    return 'DMD-GenPW|public-share|v2|' . $sid . '|attachment|' . $bid;
}

function sh_blob_file(string $sid, string $bid): string {
    if (!preg_match('/^[a-f0-9]{24}$/D', $sid) || !preg_match('/^[a-f0-9]{24}$/D', $bid)) {
        sh_fail('Fichier invalide.');
    }
    return dmd_genpw_system_dir() . '/private/public_share_blobs/' . $sid . '/' . $bid . '.json';
}

function sh_session_bucket(): array {
    if (!isset($_SESSION['dmdgp_public']) || !is_array($_SESSION['dmdgp_public'])) {
        $_SESSION['dmdgp_public'] = array();
    }
    return $_SESSION['dmdgp_public'];
}

function sh_session_get(string $sid): array {
    return isset($_SESSION['dmdgp_public'][$sid]) && is_array($_SESSION['dmdgp_public'][$sid])
        ? $_SESSION['dmdgp_public'][$sid]
        : array();
}

function sh_session_set(string $sid, array $data): void {
    if (!isset($_SESSION['dmdgp_public']) || !is_array($_SESSION['dmdgp_public'])) {
        $_SESSION['dmdgp_public'] = array();
    }
    $_SESSION['dmdgp_public'][$sid] = $data;
}

function sh_session_clear(string $sid): void {
    if (isset($_SESSION['dmdgp_public'][$sid])) unset($_SESSION['dmdgp_public'][$sid]);
}

function sh_valid_token(array $share, string $token): bool {
    if ($token === '' || strlen($token) < 32 || strlen($token) > 128) return false;
    $stored = (string)($share['token_hash'] ?? '');
    if ($stored === '') return false;
    return hash_equals($stored, hash('sha256', $token));
}

function sh_mfa_code($cfg): string {
    if (!is_array($cfg)) return '';
    try {
        if (function_exists('dmd_genpw_mfa_generate_code')) {
            $r = dmd_genpw_mfa_generate_code($cfg);
            return (string)($r['code'] ?? '');
        }
        if (function_exists('dmd_genpw_pro_mfa_code')) {
            $r = dmd_genpw_pro_mfa_code($cfg);
            return (string)($r['code'] ?? '');
        }
    } catch (Throwable $e) {}
    return '';
}

sh_headers();

$rows = sh_rows();

/* Compatibilité : ancien lien ?t=... -> conversion immédiate vers id#token.
   Les nouveaux liens n'utilisent jamais ?t=. */
if (isset($_GET['t']) && is_scalar($_GET['t'])) {
    $legacy = trim((string)$_GET['t']);
    if ($legacy !== '') {
        foreach ($rows as $legacyId => $legacyShare) {
            if (is_array($legacyShare) && sh_valid_token($legacyShare, $legacy)) {
                $base = strtok((string)($_SERVER['REQUEST_URI'] ?? ''), '?');
                header('Location: ' . $base . '?id=' . rawurlencode((string)$legacyId) . '#' . rawurlencode($legacy), true, 302);
                exit;
            }
        }
    }
    sh_fail('Ce lien est invalide ou n’existe plus.');
}

$sid = isset($_GET['id']) && is_scalar($_GET['id']) ? strtolower(trim((string)$_GET['id'])) : '';
$share = sh_share_by_id($rows, $sid);

if (!$share) sh_fail('Ce lien est invalide ou n’existe plus.');
if ((int)($share['v'] ?? 1) !== 2 || !is_array($share['snapshot'] ?? null)) {
    sh_fail('Ce partage a été créé avec une ancienne version. Crée un nouveau lien sécurisé.', 410);
}
if (!empty($share['revoked_at'])) {
    sh_session_clear($sid);
    sh_fail('Ce lien a été révoqué.', 410);
}
if (!empty($share['expires_at'])) {
    $e = strtotime((string)$share['expires_at']);
    if ($e !== false && $e < time()) {
        sh_session_clear($sid);
        sh_fail('Ce lien a expiré.', 410);
    }
}

/* Réception du secret du fragment en POST. Il n'est jamais inclus dans l'URL HTTP. */
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['access_token'])) {
    header('Content-Type: application/json; charset=utf-8');

    $token = is_scalar($_POST['access_token']) ? trim((string)$_POST['access_token']) : '';
    if (!sh_valid_token($share, $token)) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'Lien de partage invalide.'));
        exit;
    }

    $state = array(
        'verified_at' => time(),
        'token' => $token,
        'key' => '',
        'pin_ok' => empty($share['pin_hash'])
    );

    if (empty($share['pin_hash'])) {
        $state['key'] = base64_encode(sh_key($token, $sid, ''));
        $state['token'] = '';
    }

    sh_session_set($sid, $state);
    session_write_close();

    echo json_encode(array('ok' => true, 'need_pin' => !empty($share['pin_hash'])));
    exit;
}

$state = sh_session_get($sid);
$hasKey = !empty($state['key']);

/* Un lien one-shot reste utilisable par la session qui l'a ouvert, notamment pour ses fichiers. */
if (!empty($share['one_time']) && !empty($share['used_at']) && !$hasKey) {
    sh_session_clear($sid);
    sh_fail('Ce lien à usage unique a déjà été utilisé.', 410);
}

/* Tant que le fragment n'a pas été transmis, afficher une page bootstrap.
   Le JS retire #secret AVANT de faire le POST. */
if (empty($state) || (empty($state['token']) && !$hasKey)) {
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Partage GenPW</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#0b1220;color:#e7edf7;font:14px system-ui,sans-serif;display:grid;place-items:center;min-height:100vh;padding:16px}
.c{width:min(500px,100%);border:1px solid #34445a;border-radius:14px;background:#101b2a;padding:20px}
h1{font-size:18px;margin:0 0 10px}p{color:#aebed2}.err{color:#ff9a9a}
</style>
</head>
<body>
<main class="c">
<h1>🔐 Partage DMD-GenPW</h1>
<p id="status">Vérification sécurisée du lien…</p>
</main>
<script>
(async()=>{
    const status=document.getElementById('status');
    const secret=decodeURIComponent((location.hash||'').replace(/^#/,''));
    history.replaceState(null,'',location.pathname+location.search);

    if(!secret){
        status.className='err';
        status.textContent='Le secret du lien est absent. Utilise le lien complet reçu.';
        return;
    }

    const body=new URLSearchParams();
    body.set('access_token',secret);

    try{
        const r=await fetch(location.pathname+location.search,{
            method:'POST',
            credentials:'same-origin',
            cache:'no-store',
            headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},
            body
        });
        const data=await r.json();
        if(!r.ok||!data||data.ok!==true) throw new Error((data&&data.error)||'Lien invalide.');
        location.replace(location.pathname+location.search);
    }catch(e){
        status.className='err';
        status.textContent=e.message||'Impossible de vérifier le partage.';
    }
})();
</script>
</body>
</html>
<?php
    exit;
}

/* PIN : il sert aussi à dériver la clé du snapshot. */
$pinHash = (string)($share['pin_hash'] ?? '');
$pinError = '';

if (!$hasKey && $pinHash !== '') {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['pin'])) {
        $pin = is_scalar($_POST['pin']) ? trim((string)$_POST['pin']) : '';

        if ($pin !== '' && password_verify($pin, $pinHash) && !empty($state['token'])) {
            $state['key'] = base64_encode(sh_key((string)$state['token'], $sid, $pin));
            $state['token'] = '';
            $state['pin_ok'] = true;
            sh_session_set($sid, $state);
            $hasKey = true;

            header('Location: ?id=' . rawurlencode($sid), true, 303);
            exit;
        }

        $pinError = 'PIN incorrect.';
    }

    if (!$hasKey) {
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Partage GenPW</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#0b1220;color:#e7edf7;font:14px system-ui,sans-serif;display:grid;place-items:center;min-height:100vh;padding:16px}
.c{width:min(430px,100%);border:1px solid #34445a;border-radius:14px;background:#101b2a;padding:20px}
input,button{width:100%;min-height:42px;border:1px solid #425675;border-radius:8px;background:#0b1523;color:#fff;padding:9px 11px;font:inherit}
button{margin-top:10px;background:#18324f;font-weight:700;cursor:pointer}.err{color:#ff9a9a}
</style>
</head>
<body>
<main class="c">
<h1>🔐 Partage DMD-GenPW</h1>
<p>Ce partage est protégé par un PIN.</p>
<?php if ($pinError !== ''): ?><p class="err"><?=sh_h($pinError)?></p><?php endif; ?>
<form method="post" action="?id=<?=rawurlencode($sid)?>">
<input type="password" inputmode="numeric" name="pin" maxlength="12" autocomplete="one-time-code" autofocus placeholder="PIN">
<button type="submit">Ouvrir le partage</button>
</form>
</main>
</body>
</html>
<?php
        exit;
    }
}

$state = sh_session_get($sid);
$keyRaw = !empty($state['key']) ? base64_decode((string)$state['key'], true) : false;
if (!is_string($keyRaw) || strlen($keyRaw) !== 32) {
    sh_session_clear($sid);
    sh_fail('La session de partage a expiré. Ouvre à nouveau le lien complet.', 403);
}

/* Déchiffrement du snapshot dédié. */
try {
    $json = dmd_genpw_decrypt((array)$share['snapshot'], $keyRaw, sh_aad($sid));
} catch (Throwable $e) {
    sh_session_clear($sid);
    sh_fail('Le partage chiffré est illisible ou le PIN est incorrect.', 403);
}

if (!is_string($json)) {
    sh_session_clear($sid);
    sh_fail('Le partage chiffré est illisible.', 403);
}

$snapshot = json_decode($json, true);
if (!is_array($snapshot)) sh_fail('Le partage est altéré.', 500);

/* Pièce jointe : pas de token dans le lien de téléchargement. */
if (isset($_GET['attachment']) && is_scalar($_GET['attachment'])) {
    $bid = trim((string)$_GET['attachment']);
    $meta = null;

    foreach ((array)($snapshot['attachments'] ?? array()) as $m) {
        if (is_array($m) && (string)($m['id'] ?? '') === $bid) {
            $meta = $m;
            break;
        }
    }

    if (!$meta) sh_fail('Fichier joint introuvable.', 404);

    try {
        $enc = dmd_genpw_read_json(sh_blob_file($sid, $bid), array());
        $bytes = dmd_genpw_decrypt($enc, $keyRaw, sh_blob_aad($sid, $bid));
    } catch (Throwable $e) {
        sh_fail('Fichier chiffré illisible ou altéré.', 500);
    }

    if (!is_string($bytes)) sh_fail('Fichier chiffré illisible ou altéré.', 500);

    $name = preg_replace('/[\r\n"\\\\]+/', '_', basename((string)($meta['name'] ?? 'fichier')));
    if ($name === '') $name = 'fichier';

    $mime = (string)($meta['mime'] ?? 'application/octet-stream');
    if (!preg_match('~^[a-z0-9.+-]+/[a-z0-9.+-]+$~i', $mime)) {
        $mime = 'application/octet-stream';
    }

    $inline = !empty($_GET['inline']) && preg_match('~^(image/|text/|application/pdf$)~i', $mime);

    header('Content-Type: ' . $mime);
    header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . $name . '"');
    header('Content-Length: ' . strlen($bytes));
    echo $bytes;
    exit;
}

/* One-shot consommé uniquement au premier affichage réel.
   La même session reste autorisée pour ouvrir/télécharger les fichiers de la fiche. */
if (!empty($share['one_time']) && empty($share['used_at'])) {
    $rows[$sid]['used_at'] = date(DATE_ATOM);
    sh_write($rows);
    $share = $rows[$sid];
}

function sh_row(string $label, string $value, bool $secret = false, bool $url = false): void {
    $id = 'v_' . bin2hex(random_bytes(4));
    if ($value === '') $value = '—';

    echo '<div class="row">';
    echo '<span class="label">' . sh_h($label) . '</span>';
    echo '<span class="value' . ($secret && $value !== '—' ? ' secret hidden' : '') . '" id="' . $id . '">' . sh_h($value) . '</span>';
    echo '<span class="actions">';

    if ($secret && $value !== '—') {
        echo '<button type="button" onclick="toggleSecret(\'' . $id . '\',this)">Afficher</button>';
    }
    if ($value !== '—') {
        echo '<button type="button" onclick="copyValue(\'' . $id . '\',this)">Copier</button>';
    }
    if ($url && $value !== '—') {
        echo '<a class="btn" target="_blank" rel="noopener noreferrer" href="' . sh_h($value) . '">Ouvrir</a>';
    }

    echo '</span>';
    echo '</div>';
}

$mfaCode = sh_mfa_code($snapshot['mfa'] ?? null);
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=sh_h((string)($snapshot['name'] ?? 'Partage GenPW'))?></title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#0b1220;color:#e7edf7;font:14px system-ui,-apple-system,"Segoe UI",sans-serif;min-height:100vh;padding:22px}
.card{width:min(840px,100%);margin:auto;border:1px solid #34445a;border-radius:14px;background:#101b2a;overflow:hidden}
.head{display:flex;justify-content:space-between;gap:12px;align-items:center;padding:16px 18px;border-bottom:1px solid #34445a}
.head h1{font-size:18px;margin:0}.badge{font-size:12px;color:#9eb3ca}
.rows{display:grid;gap:8px;padding:16px}
.row{display:grid;grid-template-columns:150px minmax(0,1fr) auto;gap:10px;align-items:center;border:1px solid #2f4159;border-radius:9px;padding:9px 10px}
.label{font-size:12px;color:#96aac2;font-weight:700}.value{min-width:0;overflow-wrap:anywhere}
.secret{font-family:ui-monospace,Consolas,monospace}.hidden{filter:blur(5px);user-select:none}
.actions{display:flex;gap:5px;align-items:center;justify-content:flex-end;flex-wrap:wrap}
button,a.btn{border:1px solid #425675;border-radius:7px;background:#14243a;color:#fff;padding:6px 9px;font:inherit;cursor:pointer;text-decoration:none;white-space:nowrap}
.foot{padding:0 16px 16px;color:#8298b2;font-size:12px}
@media(max-width:620px){body{padding:10px}.row{grid-template-columns:1fr auto}.label{grid-column:1/-1}}
</style>
</head>
<body>
<main class="card">
<div class="head">
<h1>🔐 <?=sh_h((string)($snapshot['name'] ?? 'Entrée'))?></h1>
<span class="badge">Partage chiffré DMD-GenPW</span>
</div>
<div class="rows">
<?php
sh_row('Nom', (string)($snapshot['name'] ?? ''));
sh_row('Catégorie', (string)($snapshot['cat'] ?? ''));
sh_row('Identifiant / e-mail', (string)($snapshot['user'] ?? ''));
sh_row('Adresse / URL', (string)($snapshot['url'] ?? ''), false, true);
sh_row('Date', (string)($snapshot['date'] ?? ''));
sh_row(
    'Double authentification',
    $mfaCode !== '' ? $mfaCode : (is_array($snapshot['mfa'] ?? null) ? 'Configurée' : 'Non configurée'),
    $mfaCode !== ''
);

foreach ((array)($snapshot['extra_fields'] ?? array()) as $f) {
    if (!is_array($f)) continue;
    $type = strtolower((string)($f['type'] ?? ''));
    sh_row(
        (string)($f['label'] ?? 'Champ'),
        (string)($f['value'] ?? ''),
        in_array($type, array('password','secret','pin','api_key','ssh_key'), true),
        in_array($type, array('web','url'), true)
    );
}

sh_row('Notes', (string)($snapshot['notes'] ?? ''));
sh_row('Mot de passe', (string)($snapshot['password'] ?? ''), true);

foreach ((array)($snapshot['attachments'] ?? array()) as $m) {
    if (!is_array($m)) continue;

    $bid = (string)($m['id'] ?? '');
    if ($bid === '') continue;

    $name = (string)($m['name'] ?? 'fichier');
    $mime = (string)($m['mime'] ?? 'application/octet-stream');
    $size = (int)($m['size'] ?? 0);
    $href = '?id=' . rawurlencode($sid) . '&attachment=' . rawurlencode($bid);

    echo '<div class="row">';
    echo '<span class="label">Fichier joint</span>';
    echo '<span class="value">' . sh_h($name) . ' · ' . sh_h((string)max(1, (int)ceil($size / 1024))) . ' Ko</span>';
    echo '<span class="actions">';

    if (preg_match('~^(image/|text/|application/pdf$)~i', $mime)) {
        echo '<a class="btn" target="_blank" rel="noopener noreferrer" href="' . sh_h($href . '&inline=1') . '">Ouvrir</a>';
    }

    echo '<a class="btn" href="' . sh_h($href) . '">Télécharger</a>';
    echo '</span></div>';
}
?>
</div>
<div class="foot">
<?php if (!empty($share['one_time'])): ?>
Lien à usage unique.
<?php elseif (!empty($share['expires_at'])): ?>
Valide jusqu’au <?=sh_h((string)$share['expires_at'])?>.
<?php endif; ?>
</div>
</main>

<script>
function toggleSecret(id,b){
    const e=document.getElementById(id);
    if(!e)return;
    e.classList.toggle('hidden');
    b.textContent=e.classList.contains('hidden')?'Afficher':'Masquer';
}
async function copyValue(id,b){
    const e=document.getElementById(id);
    if(!e)return;
    const t=e.textContent||'';
    try{
        if(navigator.clipboard&&window.isSecureContext){
            await navigator.clipboard.writeText(t);
        }else{
            const a=document.createElement('textarea');
            a.value=t;
            a.style.position='fixed';
            a.style.opacity='0';
            document.body.appendChild(a);
            a.select();
            document.execCommand('copy');
            a.remove();
        }
        const old=b.textContent;
        b.textContent='Copié';
        setTimeout(()=>b.textContent=old,800);
    }catch(_){
        alert('Copie impossible.');
    }
}
</script>
</body>
</html>
