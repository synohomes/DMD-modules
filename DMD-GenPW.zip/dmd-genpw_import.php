<?php
declare(strict_types=1);

/*
 * Importeurs DMD-GenPW.
 * Les fichiers exportés ne sont jamais copiés dans le stockage du module :
 * ils sont lus depuis le fichier temporaire PHP puis supprimés par PHP.
 */

function dmd_genpw_import_utf8($value) {
    $value = is_string($value) ? $value : (is_scalar($value) ? (string)$value : '');
    $value = preg_replace('/^\xEF\xBB\xBF/', '', $value);
    if (!is_string($value)) $value = '';
    if (function_exists('mb_check_encoding') && !mb_check_encoding($value, 'UTF-8')) {
        if (function_exists('mb_convert_encoding')) $value = (string)@mb_convert_encoding($value, 'UTF-8', 'Windows-1252,ISO-8859-1');
        elseif (function_exists('iconv')) {
            $converted = @iconv('Windows-1252', 'UTF-8//IGNORE', $value);
            if (is_string($converted)) $value = $converted;
        }
    }
    return $value;
}

function dmd_genpw_import_scalar($value) {
    if ($value === null) return '';
    if (is_bool($value)) return $value ? '1' : '0';
    if (is_scalar($value)) return trim(dmd_genpw_import_utf8((string)$value));
    return '';
}

function dmd_genpw_import_limit($value, $max) {
    $value = dmd_genpw_import_scalar($value);
    return function_exists('mb_substr') ? mb_substr($value, 0, (int)$max, 'UTF-8') : substr($value, 0, (int)$max);
}

function dmd_genpw_import_notes_join($parts, $max = 12000) {
    $clean = array();
    foreach ((array)$parts as $part) {
        $part = dmd_genpw_import_scalar($part);
        if ($part !== '') $clean[] = $part;
    }
    return dmd_genpw_import_limit(implode("\n", $clean), $max);
}

function dmd_genpw_import_url($raw) {
    $raw = trim(dmd_genpw_import_scalar($raw));
    if ($raw === '' || strtolower($raw) === 'http://sn' || strtolower($raw) === 'https://sn') return '';
    if (strpos($raw, '://') === false && preg_match('/^[a-z0-9.-]+\.[a-z]{2,}(?::\d+)?(?:\/.*)?$/i', $raw)) $raw = 'https://' . $raw;
    $valid = filter_var($raw, FILTER_VALIDATE_URL);
    if ($valid === false) return '';
    $scheme = strtolower((string)parse_url((string)$valid, PHP_URL_SCHEME));
    return in_array($scheme, array('http','https'), true) ? dmd_genpw_import_limit($raw, 2048) : '';
}

function dmd_genpw_import_category($url, $name = '', $hint = '') {
    $hintText = strtolower(dmd_genpw_import_scalar($hint) . ' ' . dmd_genpw_import_scalar($name));
    if (preg_match('/wi[- ]?fi|wireless|wlan|ssid/', $hintText)) return 'Wi-Fi';
    if (preg_match('/ssh|server|serveur|root|rdp|vps|nas|proxmox|hyper[- ]?v/', $hintText)) return 'Serveur';
    if (preg_match('/mail|email|e-mail|imap|smtp|outlook|gmail/', $hintText)) return 'Mail';
    if ($url !== '') return 'Site web';
    if (preg_match('/network|réseau|reseau|routeur|router|switch|firewall|vpn/', $hintText)) return 'Réseau';
    if (preg_match('/app|application|software|logiciel/', $hintText)) return 'Application';
    return 'Autre';
}

function dmd_genpw_import_entry($name, $secret, $url = '', $user = '', $notes = '', $hint = '') {
    $secret = is_scalar($secret) ? (string)$secret : '';
    if ($secret === '') return null;
    if (strlen($secret) > 4096) $secret = function_exists('mb_substr') ? mb_substr($secret, 0, 4096, 'UTF-8') : substr($secret, 0, 4096);
    $name = dmd_genpw_import_limit($name, 120);
    if ($name === '') $name = 'Entrée importée';
    $url = dmd_genpw_import_url($url);
    $user = dmd_genpw_import_limit($user, 255);
    return array(
        'name'=>$name,
        'cat'=>dmd_genpw_import_category($url, $name, $hint),
        'url'=>$url,
        'user'=>$user,
        'notes'=>dmd_genpw_import_limit($notes, 12000),
        'pw'=>$secret
    );
}

function dmd_genpw_import_csv_delimiter($headerLine) {
    $candidates = array(',', ';', "\t");
    $best = ','; $bestCount = -1;
    foreach ($candidates as $delimiter) {
        $count = count(str_getcsv((string)$headerLine, $delimiter));
        if ($count > $bestCount) { $best = $delimiter; $bestCount = $count; }
    }
    return $best;
}

function dmd_genpw_import_header_key($value) {
    $value = strtolower(trim(dmd_genpw_import_utf8((string)$value)));
    $value = preg_replace('/^\xEF\xBB\xBF/', '', $value);
    $value = str_replace(array(' ', '-', '.', '/', '\\'), '_', $value);
    $value = preg_replace('/_+/', '_', (string)$value);
    return trim((string)$value, '_');
}

function dmd_genpw_import_csv_rows($contents) {
    $contents = dmd_genpw_import_utf8((string)$contents);
    $fp = fopen('php://temp', 'r+');
    if ($fp === false) throw new RuntimeException('Impossible de lire le fichier CSV.');
    fwrite($fp, $contents); rewind($fp);
    $first = fgets($fp);
    if ($first === false) { fclose($fp); return array(); }
    $delimiter = dmd_genpw_import_csv_delimiter($first);
    rewind($fp);
    $headers = fgetcsv($fp, 0, $delimiter);
    if (!is_array($headers) || !$headers) { fclose($fp); return array(); }
    $keys = array_map('dmd_genpw_import_header_key', $headers);
    $rows = array();
    while (($row = fgetcsv($fp, 0, $delimiter)) !== false) {
        if (!array_filter($row, function($v){ return trim((string)$v) !== ''; })) continue;
        $assoc = array();
        foreach ($keys as $index=>$key) if ($key !== '') $assoc[$key] = isset($row[$index]) ? dmd_genpw_import_utf8((string)$row[$index]) : '';
        $rows[] = $assoc;
    }
    fclose($fp);
    return $rows;
}

function dmd_genpw_import_pick($row, $keys, $default = '') {
    foreach ((array)$keys as $key) {
        if (array_key_exists($key, $row)) {
            $value = dmd_genpw_import_scalar($row[$key]);
            if ($value !== '') return $value;
        }
    }
    return $default;
}

function dmd_genpw_import_lastpass_csv($contents) {
    $rows = dmd_genpw_import_csv_rows($contents);
    $items = array(); $skipped = 0;
    foreach ($rows as $row) {
        $name = dmd_genpw_import_pick($row, array('name','title'), 'Entrée LastPass');
        $url = dmd_genpw_import_pick($row, array('url','website'));
        $user = dmd_genpw_import_pick($row, array('username','user','login'));
        $password = dmd_genpw_import_pick($row, array('password','pass'));
        $extra = dmd_genpw_import_pick($row, array('extra','notes','note'));
        $grouping = dmd_genpw_import_pick($row, array('grouping','group','folder'));
        $totp = dmd_genpw_import_pick($row, array('totp','otp','one_time_password'));
        $isSecureNote = strtolower($url) === 'http://sn' || strtolower($url) === 'https://sn';
        $secret = $password;
        $notes = array();
        if ($grouping !== '') $notes[] = 'Dossier LastPass : ' . $grouping;
        if ($totp !== '') $notes[] = 'TOTP : ' . $totp;
        if ($isSecureNote && $secret === '' && $extra !== '') {
            $secret = $extra;
            $extra = '';
            $notes[] = 'Type importé : note sécurisée LastPass';
            $url = '';
        }
        if ($extra !== '') $notes[] = $extra;
        $entry = dmd_genpw_import_entry($name, $secret, $url, $user, dmd_genpw_import_notes_join($notes), $grouping);
        if ($entry === null) { $skipped++; continue; }
        $items[] = $entry;
    }
    return array('source'=>'LastPass','items'=>$items,'skipped'=>$skipped);
}

function dmd_genpw_import_bitwarden_csv($contents) {
    $rows = dmd_genpw_import_csv_rows($contents);
    $items = array(); $skipped = 0;
    foreach ($rows as $row) {
        $type = strtolower(dmd_genpw_import_pick($row, array('type'), 'login'));
        $name = dmd_genpw_import_pick($row, array('name','title'), 'Entrée Bitwarden');
        $folder = dmd_genpw_import_pick($row, array('folder','collections'));
        $notesRaw = dmd_genpw_import_pick($row, array('notes','note'));
        $fields = dmd_genpw_import_pick($row, array('fields'));
        $totp = dmd_genpw_import_pick($row, array('login_totp','totp'));
        $notes = array();
        if ($folder !== '') $notes[] = 'Dossier Bitwarden : ' . $folder;
        if ($fields !== '') $notes[] = 'Champs : ' . $fields;
        if ($totp !== '') $notes[] = 'TOTP : ' . $totp;
        $secret = dmd_genpw_import_pick($row, array('login_password','password'));
        $url = dmd_genpw_import_pick($row, array('login_uri','url','website'));
        $user = dmd_genpw_import_pick($row, array('login_username','username','user'));
        if ($type === 'note' && $secret === '' && $notesRaw !== '') {
            $secret = $notesRaw; $notesRaw = ''; $url = ''; $user = '';
            $notes[] = 'Type importé : note sécurisée Bitwarden';
        }
        if ($notesRaw !== '') $notes[] = $notesRaw;
        $entry = dmd_genpw_import_entry($name, $secret, $url, $user, dmd_genpw_import_notes_join($notes), $folder . ' ' . $type);
        if ($entry === null) { $skipped++; continue; }
        $items[] = $entry;
    }
    return array('source'=>'Bitwarden','items'=>$items,'skipped'=>$skipped);
}

function dmd_genpw_import_bitwarden_fields($item) {
    $parts = array();
    if (!empty($item['fields']) && is_array($item['fields'])) {
        foreach ($item['fields'] as $field) {
            if (!is_array($field)) continue;
            $label = dmd_genpw_import_scalar(isset($field['name']) ? $field['name'] : 'Champ');
            $value = dmd_genpw_import_scalar(isset($field['value']) ? $field['value'] : '');
            if ($value !== '') $parts[] = ($label !== '' ? $label : 'Champ') . ' : ' . $value;
        }
    }
    return $parts;
}

function dmd_genpw_import_bitwarden_json($contents) {
    $data = json_decode(dmd_genpw_import_utf8((string)$contents), true);
    if (!is_array($data)) throw new InvalidArgumentException('Export Bitwarden JSON invalide.');
    if (!empty($data['encrypted']) || isset($data['encKeyValidation_DO_NOT_EDIT'])) throw new InvalidArgumentException('Cet export Bitwarden est chiffré. Exportez le coffre en JSON non chiffré ou en CSV avant l’import.');
    $rows = isset($data['items']) && is_array($data['items']) ? $data['items'] : array();
    $folders = array();
    if (!empty($data['folders']) && is_array($data['folders'])) foreach ($data['folders'] as $folder) if (is_array($folder) && isset($folder['id'])) $folders[(string)$folder['id']] = dmd_genpw_import_scalar(isset($folder['name'])?$folder['name']:'');
    $items = array(); $skipped = 0;
    foreach ($rows as $item) {
        if (!is_array($item)) { $skipped++; continue; }
        $type = (int)(isset($item['type']) ? $item['type'] : 1);
        $name = dmd_genpw_import_scalar(isset($item['name']) ? $item['name'] : 'Entrée Bitwarden');
        $folder = isset($item['folderId']) && isset($folders[(string)$item['folderId']]) ? $folders[(string)$item['folderId']] : '';
        $notes = array();
        if ($folder !== '') $notes[] = 'Dossier Bitwarden : ' . $folder;
        if (!empty($item['notes'])) $notes[] = dmd_genpw_import_scalar($item['notes']);
        foreach (dmd_genpw_import_bitwarden_fields($item) as $fieldLine) $notes[] = $fieldLine;
        $url = ''; $user = ''; $secret = ''; $hint = $folder;
        if ($type === 1 || isset($item['login'])) {
            $login = isset($item['login']) && is_array($item['login']) ? $item['login'] : array();
            $user = dmd_genpw_import_scalar(isset($login['username']) ? $login['username'] : '');
            $secret = isset($login['password']) && is_scalar($login['password']) ? (string)$login['password'] : '';
            if (!empty($login['uris']) && is_array($login['uris'])) foreach ($login['uris'] as $uriRow) {
                if (is_array($uriRow) && !empty($uriRow['uri'])) { $url = dmd_genpw_import_scalar($uriRow['uri']); break; }
            }
            if (!empty($login['totp'])) $notes[] = 'TOTP : ' . dmd_genpw_import_scalar($login['totp']);
            $hint .= ' login';
        } elseif ($type === 2 || isset($item['secureNote'])) {
            $secret = dmd_genpw_import_scalar(isset($item['notes']) ? $item['notes'] : '');
            if ($secret !== '') {
                $notes = array_filter($notes, function($line) use ($secret){ return (string)$line !== $secret; });
                $notes[] = 'Type importé : note sécurisée Bitwarden';
            }
            $hint .= ' note';
        } elseif ($type === 3 || isset($item['card'])) {
            $card = isset($item['card']) && is_array($item['card']) ? $item['card'] : array();
            $user = dmd_genpw_import_scalar(isset($card['cardholderName']) ? $card['cardholderName'] : '');
            $protected = array();
            foreach (array('brand'=>'Type','number'=>'Numéro','code'=>'Code','expMonth'=>'Mois expiration','expYear'=>'Année expiration') as $key=>$label) {
                $value = dmd_genpw_import_scalar(isset($card[$key]) ? $card[$key] : '');
                if ($value !== '') $protected[] = $label . ' : ' . $value;
            }
            $secret = implode("\n", $protected);
            $notes[] = 'Type importé : carte Bitwarden'; $hint .= ' carte';
        } elseif ($type === 4 || isset($item['identity'])) {
            $identity = isset($item['identity']) && is_array($item['identity']) ? $item['identity'] : array();
            $protected = array();
            foreach ($identity as $key=>$value) {
                if (!is_scalar($value) || dmd_genpw_import_scalar($value) === '') continue;
                $protected[] = (string)$key . ' : ' . dmd_genpw_import_scalar($value);
            }
            $secret = implode("\n", $protected);
            $notes[] = 'Type importé : identité Bitwarden'; $hint .= ' identité';
        }
        $entry = dmd_genpw_import_entry($name, $secret, $url, $user, dmd_genpw_import_notes_join($notes), $hint);
        if ($entry === null) { $skipped++; continue; }
        $items[] = $entry;
    }
    return array('source'=>'Bitwarden','items'=>$items,'skipped'=>$skipped);
}

function dmd_genpw_import_1password_csv($contents) {
    $rows = dmd_genpw_import_csv_rows($contents);
    $items = array(); $skipped = 0;
    foreach ($rows as $row) {
        $name = dmd_genpw_import_pick($row, array('title','name'), 'Entrée 1Password');
        $url = dmd_genpw_import_pick($row, array('website','url'));
        $user = dmd_genpw_import_pick($row, array('username','user'));
        $secret = dmd_genpw_import_pick($row, array('password','pass'));
        $notesRaw = dmd_genpw_import_pick($row, array('notes','note'));
        $tags = dmd_genpw_import_pick($row, array('tags','tag'));
        $otp = dmd_genpw_import_pick($row, array('one_time_password','one_time_passwords','otp_auth','otp','totp'));
        $notes = array();
        if ($tags !== '') $notes[] = 'Tags 1Password : ' . $tags;
        if ($otp !== '') $notes[] = 'TOTP : ' . $otp;
        if ($notesRaw !== '') $notes[] = $notesRaw;
        $entry = dmd_genpw_import_entry($name, $secret, $url, $user, dmd_genpw_import_notes_join($notes), $tags);
        if ($entry === null) { $skipped++; continue; }
        $items[] = $entry;
    }
    return array('source'=>'1Password','items'=>$items,'skipped'=>$skipped);
}

function dmd_genpw_import_1password_value($value) {
    if (is_scalar($value)) return dmd_genpw_import_scalar($value);
    if (is_array($value)) {
        if (array_key_exists('string', $value)) return dmd_genpw_import_scalar($value['string']);
        if (array_key_exists('concealed', $value)) return dmd_genpw_import_scalar($value['concealed']);
        if (array_key_exists('email', $value)) return dmd_genpw_import_scalar($value['email']);
        if (array_key_exists('url', $value)) return dmd_genpw_import_scalar($value['url']);
        if (array_key_exists('phone', $value)) return dmd_genpw_import_scalar($value['phone']);
        if (array_key_exists('date', $value)) return dmd_genpw_import_scalar($value['date']);
        if (array_key_exists('monthYear', $value)) return dmd_genpw_import_scalar($value['monthYear']);
        if (array_key_exists('reference', $value)) return dmd_genpw_import_scalar($value['reference']);
        $encoded = json_encode($value, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        return is_string($encoded) ? $encoded : '';
    }
    return '';
}

function dmd_genpw_import_1password_data($data) {
    if (!is_array($data) || empty($data['accounts']) || !is_array($data['accounts'])) throw new InvalidArgumentException('Export 1Password 1PUX invalide.');
    $items = array(); $skipped = 0;
    foreach ($data['accounts'] as $account) {
        if (!is_array($account)) continue;
        $vaults = isset($account['vaults']) && is_array($account['vaults']) ? $account['vaults'] : array();
        foreach ($vaults as $vault) {
            if (!is_array($vault)) continue;
            $vaultName = dmd_genpw_import_scalar(isset($vault['attrs']['name']) ? $vault['attrs']['name'] : '');
            $rows = isset($vault['items']) && is_array($vault['items']) ? $vault['items'] : array();
            foreach ($rows as $item) {
                if (!is_array($item)) { $skipped++; continue; }
                $state = strtolower(dmd_genpw_import_scalar(isset($item['state']) ? $item['state'] : 'active'));
                if ($state === 'archived') { /* On importe quand même, mais on le signale. */ }
                $overview = isset($item['overview']) && is_array($item['overview']) ? $item['overview'] : array();
                $details = isset($item['details']) && is_array($item['details']) ? $item['details'] : array();
                $name = dmd_genpw_import_scalar(isset($overview['title']) ? $overview['title'] : 'Entrée 1Password');
                $url = dmd_genpw_import_scalar(isset($overview['url']) ? $overview['url'] : '');
                if ($url === '' && !empty($overview['urls']) && is_array($overview['urls'])) foreach ($overview['urls'] as $u) if (is_array($u) && !empty($u['url'])) { $url = dmd_genpw_import_scalar($u['url']); break; }
                $user = ''; $secret = ''; $protected = array(); $publicFields = array();
                if (!empty($details['loginFields']) && is_array($details['loginFields'])) {
                    foreach ($details['loginFields'] as $field) {
                        if (!is_array($field)) continue;
                        $value = dmd_genpw_import_scalar(isset($field['value']) ? $field['value'] : '');
                        $designation = strtolower(dmd_genpw_import_scalar(isset($field['designation']) ? $field['designation'] : ''));
                        $fieldType = strtoupper(dmd_genpw_import_scalar(isset($field['fieldType']) ? $field['fieldType'] : (isset($field['type']) ? $field['type'] : '')));
                        if ($designation === 'username' && $user === '') $user = $value;
                        if ($designation === 'password' && $secret === '') $secret = $value;
                        if ($secret === '' && $fieldType === 'P' && $value !== '') $secret = $value;
                    }
                }
                if (!empty($details['sections']) && is_array($details['sections'])) {
                    foreach ($details['sections'] as $section) {
                        if (!is_array($section) || empty($section['fields']) || !is_array($section['fields'])) continue;
                        $sectionTitle = dmd_genpw_import_scalar(isset($section['title']) ? $section['title'] : '');
                        foreach ($section['fields'] as $field) {
                            if (!is_array($field)) continue;
                            $title = dmd_genpw_import_scalar(isset($field['title']) ? $field['title'] : (isset($field['id']) ? $field['id'] : 'Champ'));
                            $value = dmd_genpw_import_1password_value(isset($field['value']) ? $field['value'] : '');
                            if ($value === '') continue;
                            $valueArray = isset($field['value']) && is_array($field['value']) ? $field['value'] : array();
                            $isConcealed = isset($valueArray['concealed']) || preg_match('/password|mot de passe|pin|secret|code|cvv|cvc/i', $title);
                            $line = ($sectionTitle !== '' ? $sectionTitle . ' / ' : '') . ($title !== '' ? $title : 'Champ') . ' : ' . $value;
                            if ($isConcealed) $protected[] = $line; else $publicFields[] = $line;
                        }
                    }
                }
                if ($secret === '' && $protected) $secret = implode("\n", $protected);
                $notesPlain = dmd_genpw_import_scalar(isset($details['notesPlain']) ? $details['notesPlain'] : '');
                if ($secret === '' && $notesPlain !== '') {
                    $secret = $notesPlain; $notesPlain = '';
                    $publicFields[] = 'Type importé : note sécurisée 1Password';
                }
                $notes = array();
                if ($vaultName !== '') $notes[] = 'Coffre 1Password : ' . $vaultName;
                if ($state === 'archived') $notes[] = 'État 1Password : archivé';
                if (!empty($overview['tags']) && is_array($overview['tags'])) $notes[] = 'Tags 1Password : ' . implode(', ', array_map('strval', $overview['tags']));
                if ($notesPlain !== '') $notes[] = $notesPlain;
                foreach ($publicFields as $line) $notes[] = $line;
                if (!empty($details['passwordHistory']) && is_array($details['passwordHistory'])) $notes[] = 'Historique de mot de passe présent dans l’export 1Password (non importé).';
                if (isset($item['file']) && is_array($item['file'])) $notes[] = 'Pièce jointe/document 1Password référencé (fichier non importé dans DMD-GenPW).';
                $entry = dmd_genpw_import_entry($name, $secret, $url, $user, dmd_genpw_import_notes_join($notes), $vaultName . ' ' . dmd_genpw_import_scalar(isset($item['categoryUuid'])?$item['categoryUuid']:''));
                if ($entry === null) { $skipped++; continue; }
                $items[] = $entry;
            }
        }
    }
    return array('source'=>'1Password','items'=>$items,'skipped'=>$skipped);
}

function dmd_genpw_import_zip_entry_fallback($tmpPath, $wantedBasename) {
    $blob = file_get_contents($tmpPath);
    if (!is_string($blob) || strlen($blob) < 22) return false;
    $tailStart = max(0, strlen($blob) - 65557);
    $eocd = strrpos(substr($blob, $tailStart), "PK\x05\x06");
    if ($eocd === false) return false;
    $eocd += $tailStart;
    if ($eocd + 22 > strlen($blob)) return false;
    $dirSize = unpack('V', substr($blob, $eocd + 12, 4))[1];
    $dirOffset = unpack('V', substr($blob, $eocd + 16, 4))[1];
    if ($dirOffset + $dirSize > strlen($blob)) return false;
    $pos = $dirOffset; $end = $dirOffset + $dirSize;
    while ($pos + 46 <= $end && substr($blob, $pos, 4) === "PK\x01\x02") {
        $method = unpack('v', substr($blob, $pos + 10, 2))[1];
        $compSize = unpack('V', substr($blob, $pos + 20, 4))[1];
        $nameLen = unpack('v', substr($blob, $pos + 28, 2))[1];
        $extraLen = unpack('v', substr($blob, $pos + 30, 2))[1];
        $commentLen = unpack('v', substr($blob, $pos + 32, 2))[1];
        $localOffset = unpack('V', substr($blob, $pos + 42, 4))[1];
        $name = substr($blob, $pos + 46, $nameLen);
        if (basename(str_replace('\\','/',$name)) === $wantedBasename) {
            if ($localOffset + 30 > strlen($blob) || substr($blob, $localOffset, 4) !== "PK\x03\x04") return false;
            $localNameLen = unpack('v', substr($blob, $localOffset + 26, 2))[1];
            $localExtraLen = unpack('v', substr($blob, $localOffset + 28, 2))[1];
            $dataOffset = $localOffset + 30 + $localNameLen + $localExtraLen;
            if ($dataOffset + $compSize > strlen($blob)) return false;
            $compressed = substr($blob, $dataOffset, $compSize);
            if ($method === 0) return $compressed;
            if ($method === 8 && function_exists('gzinflate')) {
                $plain = @gzinflate($compressed);
                return is_string($plain) ? $plain : false;
            }
            throw new RuntimeException('Compression 1PUX non prise en charge par ce serveur PHP.');
        }
        $pos += 46 + $nameLen + $extraLen + $commentLen;
    }
    return false;
}

function dmd_genpw_import_1pux($tmpPath) {
    $contents = false;
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        $open = $zip->open($tmpPath);
        if ($open === true) {
            $index = $zip->locateName('export.data', ZipArchive::FL_NODIR);
            if ($index !== false) $contents = $zip->getFromIndex((int)$index);
            $zip->close();
        }
    }
    if (!is_string($contents) || $contents === '') $contents = dmd_genpw_import_zip_entry_fallback($tmpPath, 'export.data');
    if (!is_string($contents) || $contents === '') throw new InvalidArgumentException('Le fichier 1PUX ne contient pas un export.data lisible.');
    $data = json_decode(dmd_genpw_import_utf8($contents), true);
    if (!is_array($data)) throw new InvalidArgumentException('Le fichier export.data du 1PUX est invalide.');
    return dmd_genpw_import_1password_data($data);
}

function dmd_genpw_import_detect_csv_source($rows) {
    if (!$rows) return '';
    $keys = array_keys($rows[0]);
    $has = function($key) use ($keys) { return in_array($key, $keys, true); };
    if ($has('grouping') || ($has('extra') && $has('fav'))) return 'lastpass';
    if ($has('login_uri') || $has('login_username') || $has('login_password')) return 'bitwarden';
    if ($has('title') && ($has('website') || $has('one_time_password') || $has('archived'))) return '1password';
    if ($has('url') && $has('username') && $has('password') && $has('name')) return 'lastpass';
    return '';
}

function dmd_genpw_import_parse_file($tmpPath, $originalName, $requestedSource = 'auto') {
    if (!is_file($tmpPath) || !is_readable($tmpPath)) throw new InvalidArgumentException('Fichier d’import introuvable.');
    $size = filesize($tmpPath);
    if ($size === false || $size <= 0) throw new InvalidArgumentException('Le fichier d’import est vide.');
    if ($size > 32 * 1024 * 1024) throw new InvalidArgumentException('Le fichier d’import dépasse 32 Mo.');
    $name = strtolower((string)$originalName);
    $source = strtolower(trim((string)$requestedSource));
    if ($source === '') $source = 'auto';

    if ($source === '1password' && substr($name, -5) === '.1pux') return dmd_genpw_import_1pux($tmpPath);
    if ($source === 'auto' && substr($name, -5) === '.1pux') return dmd_genpw_import_1pux($tmpPath);

    $contents = file_get_contents($tmpPath);
    if (!is_string($contents)) throw new RuntimeException('Impossible de lire le fichier d’import.');
    $trimmed = ltrim(dmd_genpw_import_utf8($contents));

    if ($source === 'bitwarden' || ($source === 'auto' && ($trimmed[0] ?? '') === '{')) {
        try {
            $json = json_decode($trimmed, true);
            if (is_array($json) && isset($json['accounts'])) return dmd_genpw_import_1password_data($json);
            if (is_array($json) && (isset($json['items']) || isset($json['folders']) || isset($json['encrypted']))) return dmd_genpw_import_bitwarden_json($contents);
        } catch (Throwable $e) {
            if ($source === 'bitwarden') throw $e;
        }
    }

    $rows = dmd_genpw_import_csv_rows($contents);
    $detected = $source === 'auto' ? dmd_genpw_import_detect_csv_source($rows) : $source;
    if ($detected === 'lastpass') return dmd_genpw_import_lastpass_csv($contents);
    if ($detected === 'bitwarden') return dmd_genpw_import_bitwarden_csv($contents);
    if ($detected === '1password') return dmd_genpw_import_1password_csv($contents);

    throw new InvalidArgumentException('Format non reconnu. Formats acceptés : LastPass CSV, Bitwarden CSV/JSON non chiffré, 1Password CSV/1PUX.');
}
