<?php
declare(strict_types=1);

/* DMD-GenPW Pro extensions
 * - metadata (favorites, tags, expiry, masks, specialized cards)
 * - encrypted history, trash, backups, attachments
 * - duplicates/security audit
 * - temporary/read-write share metadata
 */

function dmd_genpw_pro_dir(string $email): string {
    $dir = dmd_genpw_user_dir($email) . '/pro';
    if (!is_dir($dir)) @mkdir($dir, 0770, true);
    foreach (array('history','attachments') as $sub) {
        if (!is_dir($dir . '/' . $sub)) @mkdir($dir . '/' . $sub, 0770, true);
    }
    return $dir;
}
function dmd_genpw_pro_meta_file(string $email): string { return dmd_genpw_pro_dir($email) . '/meta.json'; }
function dmd_genpw_pro_trash_file(string $email): string { return dmd_genpw_pro_dir($email) . '/trash.json'; }
function dmd_genpw_pro_attachments_file(string $email): string { return dmd_genpw_pro_dir($email) . '/attachments.json'; }
function dmd_genpw_pro_settings_file(string $email): string { return dmd_genpw_pro_dir($email) . '/settings.json'; }
function dmd_genpw_pro_read(string $file, $fallback=array()) { return dmd_genpw_read_json($file,$fallback); }
function dmd_genpw_pro_write(string $file,$data): void { dmd_genpw_write_json($file,$data); }

function dmd_genpw_pro_settings(string $email): array {
    $defaults=array(
        'reveal_seconds'=>20,
        'clipboard_seconds'=>20,
        'auto_lock_minutes'=>10,
        'sensitive_reauth'=>true,
        'duplicate_detection'=>true,
        'hibp_enabled'=>false,
        'default_share_minutes'=>1440,
    );
    $raw=dmd_genpw_pro_read(dmd_genpw_pro_settings_file($email),array());
    return array_merge($defaults,is_array($raw)?$raw:array());
}
function dmd_genpw_pro_save_settings(string $email,array $input): array {
    $cfg=dmd_genpw_pro_settings($email);
    foreach(array('reveal_seconds'=>array(5,300),'clipboard_seconds'=>array(5,300),'auto_lock_minutes'=>array(1,480),'default_share_minutes'=>array(5,525600)) as $k=>$range){
        if(array_key_exists($k,$input)) $cfg[$k]=max($range[0],min($range[1],(int)$input[$k]));
    }
    foreach(array('sensitive_reauth','duplicate_detection','hibp_enabled') as $k) if(array_key_exists($k,$input)) $cfg[$k]=!empty($input[$k]);
    dmd_genpw_pro_write(dmd_genpw_pro_settings_file($email),$cfg);
    return $cfg;
}

function dmd_genpw_pro_meta_all(string $email): array {
    $m=dmd_genpw_pro_read(dmd_genpw_pro_meta_file($email),array());
    return is_array($m)?$m:array();
}
function dmd_genpw_pro_meta(string $email,string $id): array {
    $all=dmd_genpw_pro_meta_all($email);
    $m=isset($all[$id])&&is_array($all[$id])?$all[$id]:array();
    return array_merge(array(
        'favorite'=>false,'tags'=>array(),'expires_at'=>'','profile_type'=>'generic',
        'field_masks'=>array(),'rotation_days'=>0,'last_rotated_at'=>'','updated_at'=>''
    ),$m);
}
function dmd_genpw_pro_meta_save(string $email,string $id,array $input): array {
    $all=dmd_genpw_pro_meta_all($email);
    $m=dmd_genpw_pro_meta($email,$id);
    if(array_key_exists('favorite',$input)) $m['favorite']=!empty($input['favorite']);
    if(array_key_exists('tags',$input)){
        $tags=is_array($input['tags'])?$input['tags']:preg_split('/[,;]+/',(string)$input['tags']);
        $tags=array_values(array_unique(array_filter(array_map(function($v){return dmd_genpw_clean(trim((string)$v),40);},$tags))));
        $m['tags']=array_slice($tags,0,30);
    }
    if(array_key_exists('expires_at',$input)){
        $v=trim((string)$input['expires_at']);
        if($v!=='' && strtotime($v)===false) throw new InvalidArgumentException('Date d’expiration invalide.');
        $m['expires_at']=$v;
    }
    if(array_key_exists('rotation_days',$input)) $m['rotation_days']=max(0,min(3650,(int)$input['rotation_days']));
    if(array_key_exists('last_rotated_at',$input)) $m['last_rotated_at']=trim((string)$input['last_rotated_at']);
    if(array_key_exists('profile_type',$input)){
        $types=array('generic','website','server','database','wifi','api','ssh','license','card');
        $v=strtolower(trim((string)$input['profile_type']));
        $m['profile_type']=in_array($v,$types,true)?$v:'generic';
    }
    if(array_key_exists('field_masks',$input) && is_array($input['field_masks'])){
        $masks=array();
        foreach($input['field_masks'] as $k=>$v){
            $k=dmd_genpw_clean((string)$k,80);
            $v=strtolower((string)$v);
            if($k!=='' && in_array($v,array('visible','masked','confirm'),true)) $masks[$k]=$v;
        }
        $m['field_masks']=$masks;
    }
    $m['updated_at']=date(DATE_ATOM);
    $all[$id]=$m;
    dmd_genpw_pro_write(dmd_genpw_pro_meta_file($email),$all);
    return $m;
}
function dmd_genpw_pro_meta_delete(string $email,string $id): void {
    $all=dmd_genpw_pro_meta_all($email); unset($all[$id]); dmd_genpw_pro_write(dmd_genpw_pro_meta_file($email),$all);
}

function dmd_genpw_pro_history_file(string $email,string $id): string { return dmd_genpw_pro_dir($email).'/history/'.$id.'.json'; }
function dmd_genpw_pro_snapshot(string $email,string $id,array $entry,string $event='update'): void {
    $rows=dmd_genpw_pro_read(dmd_genpw_pro_history_file($email,$id),array());
    if(!is_array($rows))$rows=array();
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
    $payload=json_encode(array('entry'=>$entry,'meta'=>dmd_genpw_pro_meta($email,$id)),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $version=date('YmdHis').'-'.bin2hex(random_bytes(3));
    $enc=dmd_genpw_encrypt((string)$payload,$key,dmd_genpw_aad($email,$id).'|history|'.$version);
    $rows[]=array('version'=>$version,'at'=>date(DATE_ATOM),'by'=>$email,'event'=>$event,'payload'=>$enc);
    if(count($rows)>100) $rows=array_slice($rows,-100);
    dmd_genpw_pro_write(dmd_genpw_pro_history_file($email,$id),$rows);
}
function dmd_genpw_pro_history_list(string $email,string $id): array {
    $rows=dmd_genpw_pro_read(dmd_genpw_pro_history_file($email,$id),array());
    $out=array();
    foreach(is_array($rows)?$rows:array() as $r){
        if(!is_array($r))continue;
        $out[]=array('version'=>(string)($r['version']??''),'at'=>(string)($r['at']??''),'by'=>(string)($r['by']??''),'event'=>(string)($r['event']??''));
    }
    return array_reverse($out);
}
function dmd_genpw_pro_history_restore(string $email,string $id,string $version,string $ownedFile): array {
    $rows=dmd_genpw_pro_read(dmd_genpw_pro_history_file($email,$id),array());
    $found=null;
    foreach($rows as $r) if(is_array($r)&&hash_equals((string)($r['version']??''),$version)){$found=$r;break;}
    if(!$found||!is_array($found['payload']??null)) throw new OutOfBoundsException('Version introuvable.');
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
    $plain=dmd_genpw_decrypt($found['payload'],$key,dmd_genpw_aad($email,$id).'|history|'.$version);
    $data=json_decode((string)$plain,true);
    if(!is_array($data)||!is_array($data['entry']??null)) throw new RuntimeException('Historique illisible.');
    $owned=dmd_genpw_read_json($ownedFile,array());
    if(isset($owned[$id])&&is_array($owned[$id])) dmd_genpw_pro_snapshot($email,$id,$owned[$id],'before_restore');
    $owned[$id]=$data['entry']; $owned[$id]['updated_at']=date(DATE_ATOM); $owned[$id]['date']=date('d/m/Y H:i');
    dmd_genpw_write_json($ownedFile,$owned);
    if(is_array($data['meta']??null)) dmd_genpw_pro_meta_save($email,$id,$data['meta']);
    return $owned[$id];
}

function dmd_genpw_pro_trash_move(string $email,string $id,array $entry): void {
    $trash=dmd_genpw_pro_read(dmd_genpw_pro_trash_file($email),array());
    $trash[$id]=array('deleted_at'=>date(DATE_ATOM),'deleted_by'=>$email,'entry'=>$entry,'meta'=>dmd_genpw_pro_meta($email,$id));
    dmd_genpw_pro_write(dmd_genpw_pro_trash_file($email),$trash);
}
function dmd_genpw_pro_trash_list(string $email): array {
    $trash=dmd_genpw_pro_read(dmd_genpw_pro_trash_file($email),array()); $out=array();
    foreach($trash as $id=>$row) if(is_array($row)&&is_array($row['entry']??null)) $out[]=array(
        'id'=>$id,'name'=>(string)($row['entry']['name']??'Sans nom'),'deleted_at'=>(string)($row['deleted_at']??'')
    );
    usort($out,function($a,$b){return strcmp($b['deleted_at'],$a['deleted_at']);}); return $out;
}
function dmd_genpw_pro_trash_restore(string $email,string $id,string $ownedFile): array {
    $trash=dmd_genpw_pro_read(dmd_genpw_pro_trash_file($email),array());
    if(!isset($trash[$id])||!is_array($trash[$id])||!is_array($trash[$id]['entry']??null)) throw new OutOfBoundsException('Élément de corbeille introuvable.');
    $owned=dmd_genpw_read_json($ownedFile,array());
    if(isset($owned[$id])) throw new InvalidArgumentException('Une entrée avec cet identifiant existe déjà.');
    $owned[$id]=$trash[$id]['entry']; $owned[$id]['updated_at']=date(DATE_ATOM); $owned[$id]['date']=date('d/m/Y H:i');
    dmd_genpw_write_json($ownedFile,$owned);
    if(is_array($trash[$id]['meta']??null)) dmd_genpw_pro_meta_save($email,$id,$trash[$id]['meta']);
    unset($trash[$id]); dmd_genpw_pro_write(dmd_genpw_pro_trash_file($email),$trash);
    return $owned[$id];
}
function dmd_genpw_pro_trash_purge(string $email,array $ids): int {
    $trash=dmd_genpw_pro_read(dmd_genpw_pro_trash_file($email),array()); $n=0;
    foreach($ids as $id){$id=(string)$id;if(isset($trash[$id])){unset($trash[$id]);$n++;}}
    dmd_genpw_pro_write(dmd_genpw_pro_trash_file($email),$trash); return $n;
}

function dmd_genpw_pro_entry_passwords(string $email,string $id,array $entry,string $ownedFile): array {
    $owned=dmd_genpw_read_json($ownedFile,array()); $out=array();
    if(isset($owned[$id])) {
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
        try{$out[]=array('label'=>'Mot de passe','value'=>dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile));}catch(Throwable $e){}
    }
    if(function_exists('dmd_genpw_extra_decrypt')){
        try{
            foreach(dmd_genpw_extra_decrypt($email,$id,$entry) as $f) if(($f['type']??'')==='password' || ($f['type']??'')==='secret' || ($f['type']??'')==='pin' || ($f['type']??'')==='api_key' || ($f['type']??'')==='ssh_key') $out[]=array('label'=>(string)($f['label']??'Secret'),'value'=>(string)($f['value']??''));
        }catch(Throwable $e){}
    }
    return $out;
}
function dmd_genpw_pro_strength(string $pw): array {
    $score=0; $reasons=array();
    $len=strlen($pw);
    if($len>=16)$score+=2; elseif($len>=12)$score+=1; else $reasons[]='court';
    if(preg_match('/[a-z]/',$pw)&&preg_match('/[A-Z]/',$pw))$score++;
    if(preg_match('/\d/',$pw))$score++;
    if(preg_match('/[^a-zA-Z0-9]/',$pw))$score++;
    if(preg_match('/(.)\1{2,}/',$pw)){$score--; $reasons[]='répétitions';}
    if(in_array(strtolower($pw),array('password','motdepasse','admin','123456','qwerty'),true)){$score=0;$reasons[]='très courant';}
    return array('score'=>max(0,min(5,$score)),'weak'=>$score<3,'reasons'=>$reasons);
}
function dmd_genpw_pro_hibp_count(string $pw): ?int {
    if(!function_exists('curl_init')) return null;
    $sha=strtoupper(sha1($pw)); $prefix=substr($sha,0,5); $suffix=substr($sha,5);
    $ch=curl_init('https://api.pwnedpasswords.com/range/'.$prefix);
    if($ch===false)return null;
    curl_setopt_array($ch,array(CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>8,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_USERAGENT=>'DMD-GenPW'));
    $body=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);
    if(!is_string($body)||$code!==200)return null;
    foreach(preg_split('/\r?\n/',$body) as $line){$p=explode(':',$line,2);if(count($p)===2&&hash_equals($suffix,trim($p[0])))return (int)trim($p[1]);}
    return 0;
}
function dmd_genpw_pro_security_audit(string $email,array $owned,string $ownedFile,bool $hibp=false): array {
    $items=array(); $hashes=array(); $weak=0;$reused=0;$old=0;$nomfa=0;$pwned=0;
    foreach($owned as $id=>$entry){
        if(!is_array($entry))continue;
        $passwords=dmd_genpw_pro_entry_passwords($email,$id,$entry,$ownedFile);
        $entryIssues=array();
        foreach($passwords as $p){
            $s=dmd_genpw_pro_strength((string)$p['value']); if($s['weak']){$weak++;$entryIssues[]='Mot de passe faible : '.$p['label'];}
            $h=hash('sha256',(string)$p['value']); $hashes[$h][]=$id;
            if($hibp){$c=dmd_genpw_pro_hibp_count((string)$p['value']);if(is_int($c)&&$c>0){$pwned++;$entryIssues[]='Compromis ('.$c.') : '.$p['label'];}}
        }
        $meta=dmd_genpw_pro_meta($email,$id);
        $updated=strtotime((string)($entry['updated_at']??$entry['created_at']??''));
        if($updated && $updated<strtotime('-180 days')){$old++;$entryIssues[]='Ancien (>180 jours)';}
        if(empty($entry['mfa_data'])){$nomfa++;$entryIssues[]='Sans MFA';}
        if($meta['expires_at']!=='' && strtotime($meta['expires_at'])!==false && strtotime($meta['expires_at'])<time())$entryIssues[]='Expiré';
        if((int)($meta['rotation_days']??0)>0){
            $base=strtotime((string)($meta['last_rotated_at']??'')); if(!$base)$base=$updated;
            if($base && $base + ((int)$meta['rotation_days']*86400) < time()) $entryIssues[]='Rotation échue';
        }
        $items[$id]=array('id'=>$id,'name'=>(string)($entry['name']??''),'issues'=>$entryIssues);
    }
    foreach($hashes as $ids) if(count(array_unique($ids))>1){$reused+=count(array_unique($ids));foreach(array_unique($ids) as $id)$items[$id]['issues'][]='Mot de passe réutilisé';}
    return array('summary'=>array('entries'=>count($owned),'weak'=>$weak,'reused'=>$reused,'old'=>$old,'without_mfa'=>$nomfa,'pwned'=>$pwned),'items'=>array_values($items));
}
function dmd_genpw_pro_duplicates(string $email,array $owned,string $ownedFile): array {
    $groups=array('url'=>array(),'user'=>array(),'password'=>array());
    foreach($owned as $id=>$entry){if(!is_array($entry))continue;
        $url=strtolower(trim((string)($entry['url']??''))); if($url!=='')$groups['url'][$url][]=$id;
        $user=strtolower(trim((string)($entry['user']??''))); if($user!=='')$groups['user'][$user][]=$id;
        foreach(dmd_genpw_pro_entry_passwords($email,$id,$entry,$ownedFile) as $p){$h=hash('sha256',(string)$p['value']);$groups['password'][$h][]=$id;}
    }
    $out=array();
    foreach($groups as $type=>$rows)foreach($rows as $value=>$ids){$ids=array_values(array_unique($ids));if(count($ids)>1)$out[]=array('type'=>$type,'value'=>$type==='password'?'••••••••':$value,'ids'=>$ids);}
    return $out;
}

function dmd_genpw_pro_attachment_encrypt(string $email,string $entryId,string $name,string $mime,string $bytes): array {
    if(strlen($bytes)>20*1024*1024) throw new InvalidArgumentException('Pièce jointe limitée à 20 Mio.');
    $aid=bin2hex(random_bytes(12)); $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
    $enc=dmd_genpw_encrypt($bytes,$key,dmd_genpw_aad($email,$entryId).'|attachment|'.$aid);
    $file=dmd_genpw_pro_dir($email).'/attachments/'.$aid.'.json';
    dmd_genpw_pro_write($file,$enc);
    $idx=dmd_genpw_pro_read(dmd_genpw_pro_attachments_file($email),array());
    $idx[$aid]=array('id'=>$aid,'entry_id'=>$entryId,'name'=>dmd_genpw_clean($name,255),'mime'=>dmd_genpw_clean($mime,120),'size'=>strlen($bytes),'created_at'=>date(DATE_ATOM));
    dmd_genpw_pro_write(dmd_genpw_pro_attachments_file($email),$idx);
    return $idx[$aid];
}
function dmd_genpw_pro_attachment_list(string $email,string $entryId): array {
    $idx=dmd_genpw_pro_read(dmd_genpw_pro_attachments_file($email),array());$out=array();
    foreach($idx as $r)if(is_array($r)&&(string)($r['entry_id']??'')===$entryId)$out[]=$r; return $out;
}
function dmd_genpw_pro_attachment_get(string $email,string $aid): array {
    $idx=dmd_genpw_pro_read(dmd_genpw_pro_attachments_file($email),array());
    if(!isset($idx[$aid])||!is_array($idx[$aid]))throw new OutOfBoundsException('Pièce jointe introuvable.');
    $r=$idx[$aid];$entryId=(string)$r['entry_id'];$enc=dmd_genpw_pro_read(dmd_genpw_pro_dir($email).'/attachments/'.$aid.'.json',array());
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);$bytes=dmd_genpw_decrypt($enc,$key,dmd_genpw_aad($email,$entryId).'|attachment|'.$aid);
    return array('meta'=>$r,'bytes'=>$bytes);
}
function dmd_genpw_pro_attachment_delete(string $email,string $aid): void {
    $idx=dmd_genpw_pro_read(dmd_genpw_pro_attachments_file($email),array()); if(!isset($idx[$aid]))return;
    unset($idx[$aid]);dmd_genpw_pro_write(dmd_genpw_pro_attachments_file($email),$idx);@unlink(dmd_genpw_pro_dir($email).'/attachments/'.$aid.'.json');
}

function dmd_genpw_pro_backup_create(string $email,array $owned): array {
    $attachmentIndex=dmd_genpw_pro_read(dmd_genpw_pro_attachments_file($email),array());$attachmentFiles=array();
    foreach($attachmentIndex as $aid=>$meta){$f=dmd_genpw_pro_dir($email).'/attachments/'.$aid.'.json';if(is_file($f))$attachmentFiles[$aid]=dmd_genpw_pro_read($f,array());}
    $payload=array('version'=>2,'created_at'=>date(DATE_ATOM),'owned'=>$owned,'meta'=>dmd_genpw_pro_meta_all($email),'trash'=>dmd_genpw_pro_read(dmd_genpw_pro_trash_file($email),array()),'settings'=>dmd_genpw_pro_settings($email),'attachments'=>$attachmentIndex,'attachment_files'=>$attachmentFiles);
    $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);$enc=dmd_genpw_encrypt((string)$json,$key,'DMD-GenPW|backup|'.$email);
    return array('filename'=>'DMD-GenPW-backup-'.date('Ymd-His').'.dmdgp','content'=>base64_encode((string)json_encode($enc,JSON_UNESCAPED_SLASHES)));
}
function dmd_genpw_pro_backup_restore(string $email,string $content,string $ownedFile): array {
    $wrapped=json_decode((string)base64_decode($content,true),true);
    if(!is_array($wrapped)) throw new InvalidArgumentException('Sauvegarde invalide.');
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);$plain=dmd_genpw_decrypt($wrapped,$key,'DMD-GenPW|backup|'.$email);
    $data=json_decode((string)$plain,true);if(!is_array($data)||!is_array($data['owned']??null))throw new InvalidArgumentException('Sauvegarde illisible.');
    dmd_genpw_write_json($ownedFile,$data['owned']);
    if(is_array($data['meta']??null))dmd_genpw_pro_write(dmd_genpw_pro_meta_file($email),$data['meta']);
    if(is_array($data['trash']??null))dmd_genpw_pro_write(dmd_genpw_pro_trash_file($email),$data['trash']);
    if(is_array($data['settings']??null))dmd_genpw_pro_write(dmd_genpw_pro_settings_file($email),$data['settings']);
    if(is_array($data['attachments']??null))dmd_genpw_pro_write(dmd_genpw_pro_attachments_file($email),$data['attachments']);
    if(is_array($data['attachment_files']??null)){foreach($data['attachment_files'] as $aid=>$enc){if(is_array($enc))dmd_genpw_pro_write(dmd_genpw_pro_dir($email).'/attachments/'.basename((string)$aid).'.json',$enc);}}
    return array('entries'=>count($data['owned']),'attachments'=>is_array($data['attachments']??null)?count($data['attachments']):0);
}

function dmd_genpw_pro_sensitive_ok(string $email): bool { return (int)($_SESSION['dmd_genpw_sensitive_until']??0) > time(); }
function dmd_genpw_pro_sensitive_auth(string $email,string $code='',string $password=''): bool {
    $ok=false;
    if(dmd_genpw_system_mfa_enabled($email) && $code!=='') $ok=dmd_genpw_verify_system_mfa($email,$code);
    elseif($password!=='') $ok=dmd_genpw_verify_unlock_password($email,$password);
    if($ok)$_SESSION['dmd_genpw_sensitive_until']=time()+300; return $ok;
}

function dmd_genpw_pro_advanced_search(string $email,array $owned,array $input): array {
    $q=strtolower(trim((string)($input['q']??'')));$cat=(string)($input['category']??'');$tag=strtolower(trim((string)($input['tag']??'')));
    $hasMfa=array_key_exists('has_mfa',$input)?(bool)$input['has_mfa']:null;$favorite=array_key_exists('favorite',$input)?(bool)$input['favorite']:null;
    $from=trim((string)($input['modified_from']??''));$to=trim((string)($input['modified_to']??''));$out=array();
    foreach($owned as $id=>$e){if(!is_array($e))continue;$m=dmd_genpw_pro_meta($email,$id);
        $hay=strtolower(implode(' ',array((string)($e['name']??''),(string)($e['url']??''),(string)($e['user']??''),(string)($e['notes']??''),implode(' ',$m['tags']))));
        if($q!==''&&strpos($hay,$q)===false)continue;if($cat!==''&&(string)($e['cat']??'')!==$cat)continue;
        if($tag!==''&&!in_array($tag,array_map('strtolower',$m['tags']),true))continue;
        if($hasMfa!==null && (bool)!empty($e['mfa_data'])!==$hasMfa)continue;
        if($favorite!==null && (bool)$m['favorite']!==$favorite)continue;
        $ut=strtotime((string)($e['updated_at']??'')); if($from!==''&&$ut&&$ut<strtotime($from))continue;if($to!==''&&$ut&&$ut>strtotime($to.' 23:59:59'))continue;
        $out[]=$id;
    }return $out;
}

function dmd_genpw_pro_profile_templates(): array {
    return array(
        'website'=>array(array('type'=>'web','label'=>'URL'),array('type'=>'user','label'=>'Identifiant'),array('type'=>'password','label'=>'Mot de passe')),
        'server'=>array(array('type'=>'text','label'=>'Hôte'),array('type'=>'number','label'=>'Port'),array('type'=>'user','label'=>'Utilisateur'),array('type'=>'password','label'=>'Mot de passe')),
        'database'=>array(array('type'=>'text','label'=>'Serveur'),array('type'=>'number','label'=>'Port'),array('type'=>'text','label'=>'Base'),array('type'=>'user','label'=>'Utilisateur'),array('type'=>'password','label'=>'Mot de passe')),
        'wifi'=>array(array('type'=>'text','label'=>'SSID'),array('type'=>'password','label'=>'Clé Wi-Fi')),
        'api'=>array(array('type'=>'web','label'=>'Endpoint'),array('type'=>'api_key','label'=>'Clé API'),array('type'=>'secret','label'=>'Secret')),
        'ssh'=>array(array('type'=>'text','label'=>'Hôte'),array('type'=>'number','label'=>'Port'),array('type'=>'user','label'=>'Utilisateur'),array('type'=>'ssh_key','label'=>'Clé privée'),array('type'=>'password','label'=>'Passphrase')),
        'license'=>array(array('type'=>'text','label'=>'Produit'),array('type'=>'secret','label'=>'Clé de licence'),array('type'=>'date','label'=>'Expiration')),
        'card'=>array(array('type'=>'text','label'=>'Titulaire'),array('type'=>'secret','label'=>'Numéro'),array('type'=>'date','label'=>'Expiration'),array('type'=>'pin','label'=>'PIN')),
    );
}


function dmd_genpw_pro_mfa_aad(string $email,string $id): string { return dmd_genpw_aad($email,$id).'|mfa'; }
function dmd_genpw_pro_mfa_decrypt(string $email,string $id,array $entry): ?array {
    if(empty($entry['mfa_data'])||empty($entry['mfa_iv'])||empty($entry['mfa_tag'])) return null;
    $wrapped=array(
        'v'=>(int)($entry['mfa_v']??2),
        'cipher'=>(string)($entry['mfa_cipher']??'aes-256-gcm'),
        'iv'=>(string)$entry['mfa_iv'],'tag'=>(string)$entry['mfa_tag'],'data'=>(string)$entry['mfa_data']
    );
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
    $plain=dmd_genpw_decrypt($wrapped,$key,dmd_genpw_pro_mfa_aad($email,$id));
    $cfg=json_decode((string)$plain,true); return is_array($cfg)?$cfg:null;
}
function dmd_genpw_pro_base32_decode(string $secret): string {
    $secret=strtoupper(preg_replace('/[^A-Z2-7]/i','',$secret)); if($secret==='')return '';
    $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$buffer=0;$bits=0;$out='';
    for($i=0,$len=strlen($secret);$i<$len;$i++){ $val=strpos($alphabet,$secret[$i]); if($val===false)throw new InvalidArgumentException('Secret Base32 invalide.');
        $buffer=($buffer<<5)|$val;$bits+=5;while($bits>=8){$bits-=8;$out.=chr(($buffer>>$bits)&0xff);$buffer&=(1<<$bits)-1;}}
    return $out;
}
function dmd_genpw_pro_mfa_decode_secret(string $secret,string $encoding): string {
    $secret=trim($secret);$encoding=strtolower($encoding);
    if($encoding==='auto'){
        $compact=preg_replace('/[\s-]+/','',$secret);
        if($compact!==''&&preg_match('/^[A-Z2-7]+=*$/i',$compact))$encoding='base32';
        elseif($compact!==''&&strlen($compact)%2===0&&preg_match('/^[0-9a-f]+$/i',$compact))$encoding='hex';
        elseif($compact!==''&&preg_match('/^[A-Za-z0-9+\/=]+$/',$compact)&&strpos($compact,'=')!==false)$encoding='base64';
        else $encoding='raw';
    }
    if($encoding==='base32')return dmd_genpw_pro_base32_decode($secret);
    if($encoding==='hex'){ $v=@hex2bin(preg_replace('/\s+/','',$secret)); if($v===false)throw new InvalidArgumentException('Secret hex invalide.'); return $v;}
    if($encoding==='base64'){ $v=base64_decode(preg_replace('/\s+/','',$secret),true); if($v===false)throw new InvalidArgumentException('Secret Base64 invalide.'); return $v;}
    return $secret;
}
function dmd_genpw_pro_hotp(string $secret,int $counter,int $digits,string $algorithm,string $encoding='auto'): string {
    $key=dmd_genpw_pro_mfa_decode_secret($secret,$encoding); if($key==='')throw new InvalidArgumentException('Secret 2FA vide.');
    $counter=max(0,$counter);$high=(int)floor($counter/4294967296);$low=(int)($counter%4294967296);
    $binary=pack('N2',$high,$low);$algo=strtolower($algorithm);if(!in_array($algo,array('sha1','sha256','sha512'),true))$algo='sha1';
    $hash=hash_hmac($algo,$binary,$key,true);$offset=ord($hash[strlen($hash)-1])&0x0f;
    $bin=((ord($hash[$offset])&0x7f)<<24)|((ord($hash[$offset+1])&0xff)<<16)|((ord($hash[$offset+2])&0xff)<<8)|(ord($hash[$offset+3])&0xff);
    $digits=max(6,min(10,$digits));$mod=10**$digits;return str_pad((string)($bin%$mod),$digits,'0',STR_PAD_LEFT);
}
function dmd_genpw_pro_mfa_code(array $config): array {
    $method=(string)($config['method']??'');
    if(!in_array($method,array('totp','hotp'),true))throw new InvalidArgumentException('Cette 2FA ne génère pas de code.');
    $encoding=(string)($config['encoding']??'auto');$digits=(int)($config['digits']??6);$algo=(string)($config['algorithm']??'SHA1');
    if($method==='totp'){ $period=max(15,min(300,(int)($config['period']??30)));$now=time();$counter=(int)floor($now/$period);
        return array('code'=>dmd_genpw_pro_hotp((string)$config['secret'],$counter,$digits,$algo,$encoding),'method'=>'totp','remaining'=>$period-($now%$period),'counter'=>$counter);}
    $counter=max(0,(int)($config['counter']??0));return array('code'=>dmd_genpw_pro_hotp((string)$config['secret'],$counter,$digits,$algo,$encoding),'method'=>'hotp','remaining'=>0,'counter'=>$counter);
}


function dmd_genpw_pro_extra_decrypt(string $email,string $id,array $entry): array {
    if(!isset($entry['extra_fields']) || !is_array($entry['extra_fields'])) return array();
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);$out=array();
    foreach($entry['extra_fields'] as $row){
        if(!is_array($row))continue;
        $type=strtolower(trim((string)($row['type']??'other')));
        $fid=dmd_genpw_clean((string)($row['id']??''),40);if($fid==='')continue;
        $sensitive=in_array($type,array('password','secret','pin','api_key','ssh_key'),true);
        $value='';
        if($sensitive){
            if(!empty($row['data'])&&!empty($row['iv'])&&!empty($row['tag'])){
                $wrapped=array('v'=>(int)($row['v']??2),'cipher'=>(string)($row['cipher']??'aes-256-gcm'),'iv'=>(string)$row['iv'],'tag'=>(string)$row['tag'],'data'=>(string)$row['data']);
                $value=(string)dmd_genpw_decrypt($wrapped,$key,dmd_genpw_aad($email,$id).'|extra-field|'.$fid);
            }
        } else $value=is_scalar($row['value']??null)?(string)$row['value']:'';
        $out[]=array('id'=>$fid,'type'=>$type,'label'=>(string)($row['label']??''),'value'=>$value);
    }
    return $out;
}
