<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



declare(strict_types=1);
require_once __DIR__ . '/dmd-genpw_lib.php';
function dmd_genpw_private_key_directory($vault = null) {
    $dir = dmd_genpw_system_dir() . DIRECTORY_SEPARATOR . 'private' . DIRECTORY_SEPARATOR . 'keys';
    dmd_genpw_protect_directory($dir);
    return $dir;
}

function dmd_genpw_cleanup_legacy_private_path($path) {
    if (!is_file($path)) return;
    @unlink($path);
    $root = rtrim(dmd_genpw_root(), DIRECTORY_SEPARATOR);
    $stop = array(
        $root . DIRECTORY_SEPARATOR . '.domydesk-private',
        $root . DIRECTORY_SEPARATOR . 'data',
        $root . DIRECTORY_SEPARATOR . 'users'
    );

    $dir = dirname($path);
    for ($i = 0; $i < 4; $i++) {
        if (!is_dir($dir)) break;
        $entries = @scandir($dir);
        if (!is_array($entries) || count(array_diff($entries, array('.', '..'))) !== 0) break;
        @rmdir($dir);
        if (in_array($dir, $stop, true)) break;
        $parent = dirname($dir);
        if ($parent === $dir) break;
        $dir = $parent;
    }
}

function dmd_genpw_key($vault, $userIdentifier) {
    dmd_genpw_protect_directory($vault);

    $dir = dmd_genpw_private_key_directory($vault);
    $filename = hash('sha256', (string)$userIdentifier) . '.key';
    $path = $dir . DIRECTORY_SEPARATOR . $filename;

    if (!is_file($path)) {
        $legacy = array();
        $configured = trim((string)getenv('DOMYDESK_PRIVATE_DIR'));
        if ($configured !== '') {
            $legacy[] = rtrim($configured, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . DMD_GENPW_ID . DIRECTORY_SEPARATOR . $filename;
            $legacy[] = rtrim($configured, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'genpw' . DIRECTORY_SEPARATOR . $filename;
        }
        $legacy[] = dmd_genpw_root() . DIRECTORY_SEPARATOR . '.domydesk-private' . DIRECTORY_SEPARATOR . DMD_GENPW_ID . DIRECTORY_SEPARATOR . $filename;
        $legacy[] = dmd_genpw_root() . DIRECTORY_SEPARATOR . '.domydesk-private' . DIRECTORY_SEPARATOR . 'genpw' . DIRECTORY_SEPARATOR . $filename;
        $legacy[] = $vault . DIRECTORY_SEPARATOR . '.private' . DIRECTORY_SEPARATOR . $filename;
        $legacy[] = $vault . DIRECTORY_SEPARATOR . 'key.bin';

        $key = null;
        $source = null;
        foreach ($legacy as $candidate) {
            if (!is_file($candidate)) continue;
            $value = @file_get_contents($candidate);
            if (is_string($value) && strlen($value) === 32) {
                $key = $value;
                $source = $candidate;
                break;
            }
        }

        if (!is_string($key)) $key = random_bytes(32);
        dmd_genpw_atomic_write($path, $key, 0600);

        // On ne retire l'ancienne clé qu'après avoir vérifié la nouvelle copie.
        $written = @file_get_contents($path);
        if ($source !== null && is_string($written) && hash_equals($key, $written)) {
            dmd_genpw_cleanup_legacy_private_path($source);
        }
    }

    $key = @file_get_contents($path);
    if (!is_string($key) || strlen($key) !== 32) {
        throw new RuntimeException('Clé de chiffrement DMD-GenPW invalide.');
    }
    return $key;
}

function dmd_genpw_aad($email, $id) { return 'domydesk:genpw:v2|' . $email . '|' . $id; }

function dmd_genpw_encrypt($plain, $key, $aad) {
    $iv = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, $aad, 16);
    if ($cipher === false || strlen($tag) !== 16) throw new RuntimeException('Échec du chiffrement DMD-GenPW.');
    return array('v'=>2,'cipher'=>'aes-256-gcm','iv'=>base64_encode($iv),'tag'=>base64_encode($tag),'data'=>base64_encode($cipher));
}

function dmd_genpw_decrypt($entry, $key, $aad) {
    if (isset($entry['v']) && (int)$entry['v'] === 2 && isset($entry['cipher']) && $entry['cipher'] === 'aes-256-gcm') {
        $iv = base64_decode((string)(isset($entry['iv']) ? $entry['iv'] : ''), true);
        $tag = base64_decode((string)(isset($entry['tag']) ? $entry['tag'] : ''), true);
        $data = base64_decode((string)(isset($entry['data']) ? $entry['data'] : ''), true);
        if ($iv === false || strlen($iv) !== 12 || $tag === false || strlen($tag) !== 16 || $data === false) return null;
        $plain = openssl_decrypt($data, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, $aad);
        return is_string($plain) ? $plain : null;
    }
    if (isset($entry['pw'], $entry['iv'])) {
        $data = base64_decode((string)$entry['pw'], true); $iv = base64_decode((string)$entry['iv'], true);
        if ($data === false || $iv === false || strlen($iv) !== 16) return null;
        $plain = openssl_decrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
        return is_string($plain) ? $plain : null;
    }
    return null;
}

function dmd_genpw_is_legacy($entry) { return !isset($entry['v']) && isset($entry['pw'], $entry['iv']); }

function dmd_genpw_decrypt_entry(&$store, $id, $key, $email, $file) {
    if (!isset($store[$id]) || !is_array($store[$id])) throw new OutOfBoundsException('Entrée introuvable.');
    $entry = $store[$id];
    $plain = dmd_genpw_decrypt($entry, $key, dmd_genpw_aad($email, $id));
    if ($plain === null) throw new RuntimeException('Données chiffrées illisibles ou altérées.');
    if (dmd_genpw_is_legacy($entry)) {
        $encrypted = dmd_genpw_encrypt($plain, $key, dmd_genpw_aad($email, $id));
        foreach (array('pw','iv','tag','data','cipher','v') as $field) unset($entry[$field]);
        $store[$id] = array_merge($entry, $encrypted);
        dmd_genpw_write_json($file, $store);
    }
    return $plain;
}
