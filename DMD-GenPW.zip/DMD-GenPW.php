<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/dmd-genpw_lib.php';

$email = dmd_genpw_email();
if (!is_string($email) || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    return;
}
if (!dmd_genpw_has_permission('module.view')) {
    echo '<div class="genpw-app"><section class="genpw-card">⛔ ' . htmlspecialchars(dmd_genpw_text('Accès DMD-GenPW refusé.','DMD-GenPW access denied.'), ENT_QUOTES, 'UTF-8') . '</section></div>';
    return;
}

$tr = dmd_genpw_strings();
$cfg = dmd_genpw_config($email);
$csrf = dmd_genpw_csrf();
$instanceId = 'dmd_genpw_' . bin2hex(random_bytes(5));
$cssVersion = is_file(__DIR__ . '/dmd-genpw.css') ? (string)filemtime(__DIR__ . '/dmd-genpw.css') : '1';
$moduleBase = dmd_genpw_module_web_path();
$themeUrl = dmd_genpw_user_theme_url($email);
$myDeskFull = isset($_GET['dmdgp_mydesk_full']) && (string)$_GET['dmdgp_mydesk_full'] === '1';
$myDeskCompactUrl = rtrim($moduleBase, '/') . '/dmd-genpw-mydesk.php?force_compact=1';
$myDeskCssVersion = is_file(__DIR__ . '/dmd-genpw-mydesk.css') ? (string)filemtime(__DIR__ . '/dmd-genpw-mydesk.css') : DMD_GENPW_VERSION;

$permissions = array();
foreach (array('vault.unlock','vault.list','vault.create','vault.edit','vault.delete','vault.reveal','vault.qr','vault.share','vault.revoke','vault.export','vault.export.secrets','logs.view','logs.export','logs.delete') as $permission) {
    $permissions[$permission] = dmd_genpw_has_permission($permission);
}

function dmdgp_h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function dmdgp_t($tr, $key, $fallback = '') {
    return isset($tr[$key]) ? (string)$tr[$key] : (string)$fallback;
}
?>
<?php if ($myDeskFull): ?><link rel="stylesheet" href="<?= dmdgp_h($themeUrl) ?>"><?php endif; ?>
<link rel="stylesheet" href="<?= dmdgp_h($moduleBase) ?>/dmd-genpw.css?v=<?= dmdgp_h($cssVersion) ?>">
<script>
(()=>{
    const href = <?= json_encode($moduleBase . '/dmd-genpw.css?v=' . $cssVersion, JSON_UNESCAPED_SLASHES) ?>;
    const id = 'dmd-genpw-style';
    let link = document.getElementById(id);
    if (!link) {
        link = document.createElement('link');
        link.id = id;
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }
    if (link.getAttribute('href') !== href) link.setAttribute('href', href);
})();
</script>

<?php if ($myDeskFull): ?>
<link rel="stylesheet" href="<?= dmdgp_h($moduleBase) ?>/dmd-genpw-mydesk.css?v=<?= dmdgp_h($myDeskCssVersion) ?>">
<script>
(() => {
    const href = <?= json_encode($moduleBase . '/dmd-genpw-mydesk.css?v=' . $myDeskCssVersion, JSON_UNESCAPED_SLASHES) ?>;
    let link = document.getElementById('dmd-genpw-mydesk-style');
    if (!link) { link = document.createElement('link'); link.id = 'dmd-genpw-mydesk-style'; link.rel = 'stylesheet'; document.head.appendChild(link); }
    if (link.getAttribute('href') !== href) link.setAttribute('href', href);

    function sourceWindow(){
        const candidates=[];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}
        for (const candidate of candidates) {
            try { if (candidate.document && candidate.location.origin === window.location.origin) return candidate; } catch (_) {}
        }
        return null;
    }
    function syncTheme(){
        const source=sourceWindow();
        if (!source) return;
        const names=[
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color','--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg','--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];
        const targets=[document.documentElement,document.body].filter(Boolean);
        [source.document.documentElement,source.document.body].filter(Boolean).forEach(sourceRoot=>{
            const cs=source.getComputedStyle(sourceRoot);
            names.forEach(name=>{ const value=cs.getPropertyValue(name); if(value&&value.trim()) targets.forEach(target=>target.style.setProperty(name,value.trim())); });
        });
        try {
            const bs=source.getComputedStyle(source.document.body);
            targets.forEach(target=>{ target.style.fontFamily=bs.fontFamily||''; });
            if(!getComputedStyle(document.documentElement).getPropertyValue('--background-color').trim()) document.documentElement.style.setProperty('--background-color',bs.backgroundColor||'#0b0f17');
            if(!getComputedStyle(document.documentElement).getPropertyValue('--text-color').trim()) document.documentElement.style.setProperty('--text-color',bs.color||'#e6eefc');
        } catch (_) {}
        document.documentElement.classList.add('dmdgp-mydesk-full-host');
        if(document.body) document.body.classList.add('dmdgp-mydesk-full-host');
    }
    syncTheme();
    window.addEventListener('load',syncTheme,{once:true});
    try {
        const w=Math.max(760,Math.min(1050,(screen.availWidth||1050)-40));
        const h=Math.max(560,Math.min(760,(screen.availHeight||760)-60));
        window.resizeTo(w,h);
    } catch (_) {}
})();
</script>
<div class="dmdgp-mydesk-fullbar">
    <strong>🔐 DMD-GenPW · mode complet</strong>
    <button type="button" data-dmdgp-mydesk-compact title="Revenir au mode compact">▣ Compact</button>
</div>
<?php endif; ?>

<div
    class="genpw-app"
    id="<?= dmdgp_h($instanceId) ?>"
    data-api="<?= dmdgp_h($moduleBase) ?>/dmd-genpw_api.php"
    data-qr="<?= dmdgp_h($moduleBase) ?>/dmd-genpw_qr.php"
    data-qr-decoder="<?= dmdgp_h($moduleBase) ?>/dmd-genpw_qr_reader.php"
    data-qr-local="<?= dmdgp_h($moduleBase) ?>/dmd-genpw_qr_local.js?v=<?= is_file(__DIR__ . '/dmd-genpw_qr_local.js') ? (string)filemtime(__DIR__ . '/dmd-genpw_qr_local.js') : '1' ?>"
    data-web-proxy="<?= dmdgp_h($moduleBase) ?>/dmd-genpw_web_proxy.php"
    data-csrf="<?= dmdgp_h($csrf) ?>"
    data-dmd-module-id="DMD-GenPW"
    data-dmd-context-type="credential_vault"
    data-dmd-context-id="DMD-GenPW:vault"
    data-dmd-context-name="DMD-GenPW"
    data-dmd-action-hub="1"
>
    <header class="genpw-head">
        <div class="genpw-title-wrap"><br>
            <p></p>
        </div>
        <span class="genpw-status" data-role="status"><?= dmdgp_h(dmdgp_t($tr, 'locked', 'Coffre verrouillé')) ?></span>
    </header>

    <div class="genpw-grid">
        <details class="genpw-card genpw-accordion" data-role="entry-panel" hidden aria-labelledby="<?= dmdgp_h($instanceId) ?>_generator_title">
            <summary class="genpw-accordion-summary">
                <span class="genpw-card-title" id="<?= dmdgp_h($instanceId) ?>_generator_title" data-role="entry-title"><?= dmdgp_h(dmdgp_t($tr, 'generator', 'Nouvelle entrée')) ?></span>
                <span class="genpw-accordion-arrow" aria-hidden="true">⌄</span>
            </summary>

            <div class="genpw-accordion-body">
            <div class="genpw-form-grid">
                <label class="genpw-field">
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'name', 'Nom')) ?></span>
                    <input class="genpw-input" type="text" data-field="name" maxlength="120" placeholder="Gmail personnel" autocomplete="off">
                </label>

                <label class="genpw-field">
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'category', 'Catégorie')) ?></span>
                    <select class="genpw-select" data-field="category">
                        <?php foreach (dmd_genpw_categories($email) as $category): ?>
                            <option value="<?= dmdgp_h($category) ?>"<?= $category === $cfg['default_category'] ? ' selected' : '' ?>><?= dmdgp_h(isset($tr['cat_' . $category]) ? $tr['cat_' . $category] : $category) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label class="genpw-field" data-role="url-field" hidden>
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'url', 'URL')) ?></span>
                    <input class="genpw-input" type="url" data-field="url" maxlength="2048" placeholder="https://exemple.fr" autocomplete="url">
                </label>

                <label class="genpw-field">
                    <span class="genpw-label" data-role="user-label"><?= dmdgp_h(dmdgp_t($tr, 'user', 'Identifiant / e-mail')) ?></span>
                    <input class="genpw-input" type="text" data-field="user" maxlength="255" placeholder="nom@exemple.fr" autocomplete="off">
                </label>

                <label class="genpw-field is-wide">
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'notes', 'Notes')) ?></span>
                    <textarea class="genpw-input genpw-textarea" data-field="notes" maxlength="12000" rows="3" placeholder="Notes, dossier d’origine, informations importées…"></textarea>
                </label>

                <div class="genpw-field is-wide genpw-extra-wrap">
                    <div class="genpw-extra-head">
                        <span class="genpw-label">Champs supplémentaires</span>
                        <div class="genpw-extra-add">
                            <select class="genpw-select" data-role="extra-add-type" aria-label="Ajouter un champ supplémentaire">
                                <option value="" selected>Ajouter un champ…</option>
                                <option value="web">Lien Web</option>
                                <option value="user">Identifiant</option>
                                <option value="password">Mot de passe</option>
                                <option value="secret">Secret</option>
                                <option value="pin">PIN</option>
                                <option value="api_key">Clé API / Token</option>
                                <option value="ssh_key">Clé SSH</option>
                                <option value="note">Note longue</option>
                                <option value="text">Texte</option>
                                <option value="date">Date</option>
                                <option value="number">Numéro</option>
                                <option value="email">E-mail</option>
                                <option value="phone">Téléphone</option>
                                <option value="other">Autres</option>
                            </select>
                        </div>
                    </div>
                    <div class="genpw-extra-list" data-role="extra-fields"></div>
                </div>

                <div class="genpw-field is-wide genpw-entry-attachments" data-role="entry-attachments">
                    <span class="genpw-label">📎 Fichiers joints</span>
                    <div class="genpw-entry-attachment-list" data-role="entry-attachment-list"></div>
                    <div class="genpw-inline">
                        <input class="genpw-input" type="file" data-field="entry-attachment-file" multiple>
                        <button class="genpw-btn" type="button" data-action="entry-attachment-add">＋ Ajouter le fichier</button>
                    </div>
                    <small class="genpw-security-note">Les fichiers sont stockés chiffrés avec DMD-GenPW et sont inclus dans les liens de partage temporaires.</small>
                </div>

                <div class="genpw-field is-wide genpw-mfa-wrap">
                    <details class="genpw-mfa-editor" data-role="mfa-editor">
                        <summary>
                            <span>🔐 Authentification multifacteur (MFA / 2FA)</span>
                            <span class="genpw-mfa-summary" data-role="mfa-summary">Aucune</span>
                        </summary>
                        <div class="genpw-mfa-body">
                            <div class="genpw-mfa-grid">
                                <label class="genpw-field">
                                    <span class="genpw-label">Type de MFA / méthode</span>
                                    <select class="genpw-select" data-field="mfa-method">
                                        <option value="none">Aucune</option>
                                        <option value="totp">TOTP · application d’authentification</option>
                                        <option value="hotp">HOTP · compteur</option>
                                        <option value="email">Code par e-mail · mémoriser la méthode</option>
                                        <option value="sms">Code par SMS · mémoriser la méthode</option>
                                        <option value="push">Validation Push · mémoriser la méthode</option>
                                        <option value="webauthn">Clé de sécurité / Passkey · mémoriser la méthode</option>
                                        <option value="other">Autre méthode · mémoriser</option>
                                    </select>
                                </label>
                                <label class="genpw-field" data-role="mfa-secret-field">
                                    <span class="genpw-label" data-role="mfa-source-label">Clé secrète TOTP / URI otpauth://</span>
                                    <input class="genpw-input" type="password" data-field="mfa-source" maxlength="8192" autocomplete="off" placeholder="otpauth://… ou secret Base32">
                                </label>
                                <label class="genpw-field" data-role="mfa-encoding-field">
                                    <span class="genpw-label">Format de la clé secrète</span>
                                    <select class="genpw-select" data-field="mfa-encoding">
                                        <option value="auto">Automatique</option><option value="base32">Base32</option><option value="hex">Hex</option><option value="base64">Base64</option><option value="raw">Brut</option>
                                    </select>
                                </label>
                                <label class="genpw-field" data-role="mfa-algorithm-field">
                                    <span class="genpw-label">Algorithme HMAC</span>
                                    <select class="genpw-select" data-field="mfa-algorithm">
                                        <option value="SHA1">SHA-1</option><option value="SHA256">SHA-256</option><option value="SHA512">SHA-512</option>
                                    </select>
                                </label>
                                <label class="genpw-field" data-role="mfa-digits-field">
                                    <span class="genpw-label">Longueur du code OTP (chiffres)</span>
                                    <input class="genpw-input" type="number" data-field="mfa-digits" min="6" max="10" value="6">
                                </label>
                                <label class="genpw-field" data-role="mfa-period-field">
                                    <span class="genpw-label">Renouvellement du code TOTP (secondes)</span>
                                    <input class="genpw-input" type="number" data-field="mfa-period" min="15" max="300" value="30">
                                </label>
                                <label class="genpw-field" data-role="mfa-counter-field" hidden>
                                    <span class="genpw-label">Compteur HOTP initial</span>
                                    <input class="genpw-input" type="number" data-field="mfa-counter" min="0" value="0">
                                </label>
                                <label class="genpw-field">
                                    <span class="genpw-label" data-role="mfa-issuer-label">Service / fournisseur MFA</span>
                                    <input class="genpw-input" type="text" data-field="mfa-issuer" maxlength="255" placeholder="Microsoft, Google, Synology…">
                                </label>
                                <label class="genpw-field">
                                    <span class="genpw-label" data-role="mfa-account-label">Compte protégé par MFA</span>
                                    <input class="genpw-input" type="text" data-field="mfa-account" maxlength="255" placeholder="compte@exemple.fr">
                                </label>
                                <label class="genpw-field is-wide">
                                    <span class="genpw-label">Codes de récupération MFA (secours)</span>
                                    <textarea class="genpw-input genpw-textarea" data-field="mfa-recovery" maxlength="12000" rows="3" placeholder="Un code par ligne"></textarea>
                                </label>
                                <label class="genpw-field is-wide">
                                    <span class="genpw-label" data-role="mfa-notes-label">Notes MFA / procédure</span>
                                    <textarea class="genpw-input genpw-textarea" data-field="mfa-notes" maxlength="12000" rows="2" placeholder="Informations complémentaires, procédure ou emplacement du second facteur"></textarea>
                                </label>
                            </div>
                            <div class="genpw-mfa-actions">
                                <input type="file" data-field="mfa-qr-file" accept="image/png,image/jpeg,image/webp,image/*" hidden>
                                <button class="genpw-btn" type="button" data-action="mfa-import-qr">📷 Importer un QR TOTP/HOTP</button>
                                <button class="genpw-btn" type="button" data-action="mfa-import-uri">⌨ Saisir une URI otpauth:// / clé secrète</button>
                                <button class="genpw-btn" type="button" data-action="mfa-import-domydesk">🛡️ MFA DoMyDesk</button>
                                <button class="genpw-btn" type="button" data-action="mfa-load" hidden>👁 Charger / afficher la configuration MFA</button>
                                <button class="genpw-btn is-danger" type="button" data-action="mfa-clear" hidden>🗑 Supprimer le MFA de cette fiche</button>
                            </div>
                            <p class="genpw-security-note" data-role="mfa-method-help">DMD-GenPW génère les codes pour TOTP/HOTP. Les méthodes e-mail, SMS, Push, Passkey et autres sont enregistrées comme informations de méthode et ne génèrent pas de code dans GenPW.</p>
                            <p class="genpw-security-note">Le secret TOTP/HOTP et les codes de récupération sont stockés chiffrés avec l’entrée. Le MFA DoMyDesk utilisé pour déverrouiller le coffre reste indépendant.</p>
                        </div>
                    </details>
                </div>

                <label class="genpw-field">
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'length', 'Longueur')) ?></span>
                    <input class="genpw-input" type="number" data-field="length" value="<?= (int)$cfg['default_length'] ?>" min="12" max="128" inputmode="numeric">
                </label>

                <div class="genpw-field">
                    <span class="genpw-label">Composition</span>
                    <label class="genpw-check">
                        <input type="checkbox" data-field="special"<?= $cfg['default_specials'] ? ' checked' : '' ?>>
                        <?= dmdgp_h(dmdgp_t($tr, 'specials', 'Caractères spéciaux')) ?>
                    </label>
                </div>

                <label class="genpw-field is-wide">
                    <span class="genpw-label" data-role="manual-label"><?= dmdgp_h(dmdgp_t($tr, 'manual', 'Mot de passe existant')) ?></span>
                    <div class="genpw-inline">
                        <input class="genpw-input" type="password" data-field="manual" maxlength="4096" placeholder="<?= dmdgp_h(dmdgp_t($tr, 'manual', 'Mot de passe existant')) ?>" autocomplete="new-password">
                        <button class="genpw-btn" type="button" data-action="use-manual"><?= dmdgp_h(dmdgp_t($tr, 'use', 'Utiliser')) ?></button>
                    </div>
                </label>

                <div class="genpw-field is-wide">
                    <span class="genpw-label">Mot de passe retenu</span>
                    <div class="genpw-inline">
                        <input class="genpw-preview" type="text" data-role="preview" readonly aria-label="Mot de passe retenu">
                        <button class="genpw-btn" type="button" data-action="generate">⚡ <?= dmdgp_h(dmdgp_t($tr, 'generate', 'Générer')) ?></button>
                        <button class="genpw-btn is-icon" type="button" data-action="copy-preview" title="<?= dmdgp_h(dmdgp_t($tr, 'copy', 'Copier')) ?>">📋</button>
                    </div>
                </div>

                <div class="genpw-field is-wide genpw-strength">
                    <div class="genpw-strength-meta">
                        <span data-role="strength-label"><?= dmdgp_h(dmdgp_t($tr, 'strength_none', 'Robustesse non évaluée')) ?></span>
                        <span data-role="strength-time">—</span>
                    </div>
                    <div class="genpw-strength-track" aria-hidden="true">
                        <div class="genpw-strength-fill" data-role="strength-bar"></div>
                    </div>
                </div>
            </div>

            <div class="genpw-actions">
                <button class="genpw-btn is-primary" type="button" data-action="save">💾 <?= dmdgp_h(dmdgp_t($tr, 'save', 'Enregistrer dans le coffre')) ?></button>
            </div>
            </div>
        </details>

        <details class="genpw-card genpw-accordion" data-role="access-panel" aria-labelledby="<?= dmdgp_h($instanceId) ?>_vault_title">
            <summary class="genpw-accordion-summary">
                <span class="genpw-card-title" id="<?= dmdgp_h($instanceId) ?>_vault_title"><?= dmdgp_h(dmdgp_t($tr, 'vault', 'Accès au coffre')) ?></span>
                <span class="genpw-accordion-arrow" aria-hidden="true">⌄</span>
            </summary>

            <div class="genpw-accordion-body">
            <div class="genpw-unlock" data-role="access-locked">
                <?php if (!empty($cfg['require_system_mfa'])): ?>
                <label class="genpw-field">
                    <span class="genpw-label">🛡️ <?= dmdgp_h(dmd_genpw_text('Code MFA DoMyDesk','DoMyDesk MFA code')) ?></span>
                    <input class="genpw-input" type="text" data-field="system-mfa-code" inputmode="numeric" pattern="[0-9]*" maxlength="8" autocomplete="one-time-code" placeholder="000000">
                </label>
                <p class="genpw-security-note">
                    <?= dmdgp_h(dmd_genpw_text('Utilise le MFA déjà configuré sur votre compte DoMyDesk. Quand cette protection est active, le code MFA suffit pour déverrouiller DMD-GenPW : le mot de passe n’est plus demandé. Aucun MFA séparé n’est créé pour DMD-GenPW.','Uses the MFA already configured on your DoMyDesk account. When this protection is enabled, the MFA code alone unlocks DMD-GenPW: no password is requested. No separate MFA is created for DMD-GenPW.')) ?>
                    <?php if (empty($cfg['system_mfa_enabled'])): ?>
                        <strong>⚠️ <?= dmdgp_h(dmd_genpw_text('MFA DoMyDesk actuellement désactivé.','DoMyDesk MFA is currently disabled.')) ?></strong>
                    <?php endif; ?>
                </p>
                <?php endif; ?>
                <label class="genpw-field"<?= !empty($cfg['require_system_mfa']) ? ' hidden' : '' ?>>
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'account_password', 'Mot de passe de verrouillage')) ?></span>
                    <input class="genpw-input" type="password" data-field="account-password" maxlength="4096" autocomplete="current-password" placeholder="<?= dmdgp_h(dmdgp_t($tr, 'unlock', 'Déverrouiller')) ?>">
                </label>
                <button class="genpw-btn is-primary" type="button" data-action="unlock">🔓 <?= dmdgp_h(dmdgp_t($tr, 'unlock', 'Déverrouiller')) ?></button>
                <p class="genpw-security-note"><?= dmdgp_h(dmdgp_t($tr, 'security_note', 'Le coffre se reverrouille automatiquement.')) ?> <strong><?= (int)$cfg['auto_lock_minutes'] ?> min</strong>.</p>
            </div>
            <div class="genpw-security-note" data-role="access-unlocked" hidden>
                🔓 <?= dmdgp_h(dmdgp_t($tr, 'unlocked_info', 'Coffre déverrouillé. Aucun nouveau mot de passe ne sera demandé avant le reverrouillage automatique.')) ?>
                <strong><?= (int)$cfg['auto_lock_minutes'] ?> min</strong>.
            </div>
            </div>
        </details>
    </div>

    <section class="genpw-vault" data-role="vault" hidden aria-label="Contenu du coffre">
        <div class="genpw-toolbar">
            <input class="genpw-input" type="search" data-field="search" placeholder="<?= dmdgp_h(dmdgp_t($tr, 'search', 'Rechercher…')) ?>" autocomplete="off">
            <button class="genpw-btn" type="button" data-action="refresh">↻ <?= dmdgp_h(dmdgp_t($tr, 'refresh', 'Actualiser')) ?></button>
        </div>

        <div class="genpw-bulk">
            <label class="genpw-check">
                <input type="checkbox" data-field="select-all">
                Tout sélectionner
            </label>
            <button class="genpw-btn is-danger" type="button" data-action="delete-selected">🗑 <?= dmdgp_h(dmdgp_t($tr, 'delete_selected', 'Supprimer la sélection')) ?></button>
        </div>

        <div class="genpw-tools">
            <button class="genpw-btn" type="button" data-action="categories">📂 <?= dmdgp_h(dmdgp_t($tr, 'categories', 'Catégories')) ?></button>
            <button class="genpw-btn" type="button" data-action="import">⇧ <?= dmdgp_h(dmdgp_t($tr, 'import', 'Importer')) ?></button>
            <button class="genpw-btn" type="button" data-action="export">⇩ <?= dmdgp_h(dmdgp_t($tr, 'export', 'Exporter')) ?></button>
            <button class="genpw-btn" type="button" data-action="logs">🧾 <?= dmdgp_h(dmdgp_t($tr, 'logs', 'Journal')) ?></button>
        </div>

        <div class="genpw-list" data-role="list"></div>
    </section>

    <div class="genpw-toast" data-role="toast" hidden aria-live="polite"></div>
</div>

<script>
(() => {
    'use strict';

    const root = document.getElementById(<?= json_encode($instanceId, JSON_UNESCAPED_SLASHES) ?>);
    if (!root || root.dataset.initialized === '1') return;
    root.dataset.initialized = '1';

    const TXT = <?= json_encode($tr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const PERMS = <?= json_encode($permissions, JSON_UNESCAPED_SLASHES) ?>;
    const DEFAULT_CATEGORY = <?= json_encode($cfg['default_category'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const INITIAL_CATEGORIES = <?= json_encode(dmd_genpw_categories($email), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const DEFAULT_CATEGORIES = <?= json_encode(dmd_genpw_active_default_categories($email), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const AUTO_LOCK_MINUTES = <?= (int)$cfg['auto_lock_minutes'] ?>;
    const MODULE_VERSION = <?= json_encode(DMD_GENPW_VERSION, JSON_UNESCAPED_SLASHES) ?>;
    const MYDESK_FULL = <?= $myDeskFull ? 'true' : 'false' ?>;
    const REQUIRE_SYSTEM_MFA = <?= !empty($cfg['require_system_mfa']) ? 'true' : 'false' ?>;
    const apiUrl = root.dataset.api;
    const qrDecoderUrl = root.dataset.qrDecoder || '';
    const qrLocalUrl = root.dataset.qrLocal || '';
    const qrUrl = root.dataset.qr;
    const webProxyUrl = root.dataset.webProxy;
    const csrf = root.dataset.csrf;
    const byRole = role => root.querySelector(`[data-role="${role}"]`);
    const byField = field => root.querySelector(`[data-field="${field}"]`) || (entryPanel ? entryPanel.querySelector(`[data-field="${field}"]`) : null);
    const byAction = action => root.querySelector(`[data-action="${action}"]`) || (entryPanel ? entryPanel.querySelector(`[data-action="${action}"]`) : null);

    let PRO_SETTINGS = { reveal_seconds:20, clipboard_seconds:20, auto_lock_minutes:AUTO_LOCK_MINUTES, sensitive_reauth:true, hibp_enabled:false };
    const state = { preview: '', editingId: null, editingKind:'owned', items: [], categories: Array.isArray(INITIAL_CATEGORIES) ? [...INITIAL_CATEGORIES] : [], defaultCategories: Array.isArray(DEFAULT_CATEGORIES) ? [...DEFAULT_CATEGORIES] : [], unlocked: false, toastTimer: null, autoLockTimer: null, revealTimers: new Map(), openCategories: new Set(), dragIds: [], suppressCardClickUntil: 0, editingMfaExisting: false, editingMfaLoaded: false, editingMfaOriginalMethod: 'none', entryAttachments: [], pendingAttachmentFiles: [] };
    const statusEl = byRole('status');
    const vaultEl = byRole('vault');
    const entryPanel = byRole('entry-panel');
    const accessPanel = byRole('access-panel');
    const accessLockedEl = byRole('access-locked');
    const accessUnlockedEl = byRole('access-unlocked');
    const listEl = byRole('list');
    const previewEl = byRole('preview');
    const strengthBar = byRole('strength-bar');
    const strengthLabel = byRole('strength-label');
    const strengthTime = byRole('strength-time');
    let modal = null;
    let modalDialog = null;
    let modalTitle = null;
    let webBrowser = null;
    let mfaImportCameraStream = null;
    let webTabsBar = null;
    let webFramesHost = null;
    let webTabs = [];
    let activeWebTabId = null;
    let webTabSequence = 0;
    let webSessionToken = '';
    let webSessionExpiresAt = 0;
    let webProxyCheckedVersion = '';
    let qrImage = null;
    let modalPanel = null;
    let credentialDetailsModal = null;
    let credentialDetailsDialog = null;
    let credentialDetailsTitle = null;
    let credentialDetailsPanel = null;
    const toastEl = byRole('toast');
    const entryTitleEl = byRole('entry-title');
    const saveButton = byAction('save');
    const mfaEditor = byRole('mfa-editor');
    const mfaSummary = byRole('mfa-summary');
    const extraFieldsHost = byRole('extra-fields');
    const entryPanelHome = { parent: entryPanel ? entryPanel.parentNode : null, next: entryPanel ? entryPanel.nextSibling : null };
    let credentialEditingItem = null;

    function t(key, fallback) { return Object.prototype.hasOwnProperty.call(TXT, key) ? TXT[key] : fallback; }
    function can(permission) { return PERMS[permission] !== false; }

    function mountExternalModal() {
        /* La popup ne doit jamais vivre dans le DOM draggable du module :
           sinon le clone/aperçu du dashboard peut embarquer la fenêtre complète. */
        document.querySelectorAll('[data-genpw-popup="1"][data-genpw-owner]').forEach(existing => {
            const ownerId = existing.getAttribute('data-genpw-owner') || '';
            const owner = ownerId ? document.getElementById(ownerId) : null;
            if (!owner || owner === root) existing.remove();
        });

        modal = document.createElement('div');
        modal.className = 'genpw-modal';
        modal.dataset.genpwPopup = '1';
        modal.dataset.genpwOwner = root.id;
        modal.hidden = true;
        modal.setAttribute('aria-hidden', 'true');

        modalDialog = document.createElement('div');
        modalDialog.className = 'genpw-modal-dialog';
        modalDialog.dataset.genpwPopup = '1';
        modalDialog.dataset.genpwOwner = root.id;
        modalDialog.hidden = true;
        modalDialog.setAttribute('aria-hidden', 'true');
        modalDialog.setAttribute('role', 'dialog');
        modalDialog.setAttribute('aria-modal', 'true');

        const head = document.createElement('div');
        head.className = 'genpw-modal-head';
        head.setAttribute('data-dmd-window-handle', '');

        modalTitle = document.createElement('h3');
        modalTitle.className = 'genpw-modal-title';
        modalTitle.id = `${root.id}_modal_title`;
        modalTitle.textContent = 'Aperçu';
        modalDialog.setAttribute('aria-labelledby', modalTitle.id);

        const closeButton = document.createElement('button');
        closeButton.className = 'genpw-btn';
        closeButton.type = 'button';
        closeButton.textContent = `✕ ${t('close', 'Fermer')}`;
        closeButton.addEventListener('click', closeModal);
        head.append(modalTitle, closeButton);

        const body = document.createElement('div');
        body.className = 'genpw-modal-body';

        webBrowser = document.createElement('div');
        webBrowser.className = 'genpw-web-browser';
        webBrowser.hidden = true;

        webTabsBar = document.createElement('div');
        webTabsBar.className = 'genpw-web-tabs';
        webTabsBar.setAttribute('role', 'tablist');
        webTabsBar.setAttribute('aria-label', t('web_tabs', 'Onglets web'));

        webFramesHost = document.createElement('div');
        webFramesHost.className = 'genpw-web-frames';
        webBrowser.append(webFramesHost);

        qrImage = document.createElement('img');
        qrImage.className = 'genpw-qr-image';
        qrImage.alt = 'QR code à usage unique';
        qrImage.hidden = true;

        modalPanel = document.createElement('div');
        modalPanel.className = 'genpw-modal-panel';
        modalPanel.hidden = true;

        body.append(webBrowser, qrImage, modalPanel);
        modalDialog.append(head, body);
        modal.appendChild(modalDialog);
        document.body.appendChild(modal);

        modal.addEventListener('click', event => {
            if (event.target === modal) closeModal();
        });

        /* DMDWorkspace gère lui-même le z-index des fenêtres enregistrées.
           On ne modifie jamais les z-index des ancêtres/MyDesk depuis le module. */
        if (window.DMDWorkspace && typeof window.DMDWorkspace.registerPopup === 'function') {
            try {
                window.DMDWorkspace.registerPopup(modalDialog, {
                    key: `DMD-GenPW:${root.id}:popup`,
                    handle: '.genpw-modal-head'
                });
            } catch (_) {}
        }

        /* registerPopup peut portaliser la fenêtre. Le hidden est donc porté
           par le conteneur ET par la fenêtre elle-même. */
        modal.hidden = true;
        modalDialog.hidden = true;
        modalDialog.setAttribute('aria-hidden', 'true');
    }

    mountExternalModal();

    function mountCredentialDetailsModal() {
        /* La fiche d'un identifiant est une fenêtre indépendante du navigateur web.
           Ainsi, consulter/copier un identifiant ne remplace jamais la fenêtre du site
           déjà ouverte dans le workspace. */
        document.querySelectorAll('[data-genpw-credential-popup="1"][data-genpw-owner]').forEach(existing => {
            const ownerId = existing.getAttribute('data-genpw-owner') || '';
            const owner = ownerId ? document.getElementById(ownerId) : null;
            if (!owner || owner === root) existing.remove();
        });

        credentialDetailsModal = document.createElement('div');
        credentialDetailsModal.className = 'genpw-modal genpw-credential-details-modal';
        credentialDetailsModal.dataset.genpwCredentialPopup = '1';
        credentialDetailsModal.dataset.genpwOwner = root.id;
        credentialDetailsModal.hidden = true;
        credentialDetailsModal.setAttribute('aria-hidden', 'true');

        credentialDetailsDialog = document.createElement('div');
        credentialDetailsDialog.className = 'genpw-modal-dialog is-panel is-credential-details';
        credentialDetailsDialog.dataset.genpwCredentialPopup = '1';
        credentialDetailsDialog.dataset.genpwOwner = root.id;
        credentialDetailsDialog.hidden = true;
        credentialDetailsDialog.setAttribute('aria-hidden', 'true');
        credentialDetailsDialog.setAttribute('role', 'dialog');
        credentialDetailsDialog.setAttribute('aria-modal', 'false');

        const head = document.createElement('div');
        head.className = 'genpw-modal-head';
        head.setAttribute('data-dmd-window-handle', '');

        credentialDetailsTitle = document.createElement('h3');
        credentialDetailsTitle.className = 'genpw-modal-title';
        credentialDetailsTitle.id = `${root.id}_credential_details_title`;
        credentialDetailsDialog.setAttribute('aria-labelledby', credentialDetailsTitle.id);

        const closeButton = document.createElement('button');
        closeButton.className = 'genpw-btn';
        closeButton.type = 'button';
        closeButton.textContent = `✕ ${t('close', 'Fermer')}`;
        closeButton.addEventListener('click', closeCredentialDetailsModal);
        head.append(credentialDetailsTitle, closeButton);

        const body = document.createElement('div');
        body.className = 'genpw-modal-body';
        credentialDetailsPanel = document.createElement('div');
        credentialDetailsPanel.className = 'genpw-modal-panel';
        body.appendChild(credentialDetailsPanel);
        credentialDetailsDialog.append(head, body);
        credentialDetailsModal.appendChild(credentialDetailsDialog);
        document.body.appendChild(credentialDetailsModal);

        credentialDetailsModal.addEventListener('click', event => {
            if (event.target === credentialDetailsModal) closeCredentialDetailsModal();
        });
        ['pointerdown','mousedown','mouseup','click'].forEach(type => {
            credentialDetailsDialog.addEventListener(type, event => event.stopPropagation());
        });

        if (window.DMDWorkspace && typeof window.DMDWorkspace.registerPopup === 'function') {
            try {
                window.DMDWorkspace.registerPopup(credentialDetailsDialog, {
                    key: `DMD-GenPW:${root.id}:credential-details`,
                    handle: '.genpw-modal-head'
                });
            } catch (_) {}
        }

        credentialDetailsModal.hidden = true;
        credentialDetailsDialog.hidden = true;
        credentialDetailsDialog.classList.remove('is-edit-mode');
        credentialDetailsDialog.setAttribute('aria-hidden', 'true');
        makeCredentialDialogDraggable();
    }

    function openCredentialDetailsModal(title) {
        if (!credentialDetailsDialog || !credentialDetailsPanel) mountCredentialDetailsModal();
        credentialDetailsTitle.textContent = title || 'Identifiant';
        credentialDetailsDialog.hidden = false;
        credentialDetailsDialog.setAttribute('aria-hidden', 'false');
        try { credentialDetailsDialog.dispatchEvent(new Event('pointerdown', { bubbles: true })); } catch (_) {}
        const managedByWorkspace = credentialDetailsDialog.dataset.dmdWindowManaged === '1' || credentialDetailsDialog.parentElement !== credentialDetailsModal;
        credentialDetailsModal.hidden = managedByWorkspace;
        credentialDetailsModal.setAttribute('aria-hidden', managedByWorkspace ? 'true' : 'false');
    }

    function closeCredentialDetailsModal() {
        if (!credentialDetailsModal || !credentialDetailsDialog) return;
        if (credentialEditingItem) { restoreEntryPanelHome(true); credentialEditingItem = null; }
        credentialDetailsModal.hidden = true;
        credentialDetailsModal.setAttribute('aria-hidden', 'true');
        credentialDetailsDialog.hidden = true;
        credentialDetailsDialog.setAttribute('aria-hidden', 'true');
        credentialDetailsDialog.classList.remove('genpw-open-bottom-right');
        if (credentialDetailsPanel) credentialDetailsPanel.replaceChildren();
    }

    mountCredentialDetailsModal();

    function toast(message, isError = false) {
        window.clearTimeout(state.toastTimer);
        toastEl.textContent = message;
        toastEl.classList.toggle('is-error', isError);
        toastEl.hidden = false;
        state.toastTimer = window.setTimeout(() => { toastEl.hidden = true; }, 3200);
    }
    function emitActivity(data) {
        if (!data || !data.activity) return;
        const detail = data.activity;
        try { window.dispatchEvent(new CustomEvent('dmd:resource-activity', { detail })); } catch (_) {}
        try { document.dispatchEvent(new CustomEvent('dmd:resource-activity', { detail })); } catch (_) {}
    }
    async function api(action, payload = {}) {
        const response = await fetch(apiUrl, {
            method: 'POST', credentials: 'same-origin', cache: 'no-store',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
            body: JSON.stringify({ action, ...payload })
        });
        let data;
        try { data = await response.json(); } catch (_) { throw new Error('Réponse serveur invalide (' + response.status + ').'); }
        if (!response.ok || data.error || data.ok === false) {
            if (data.locked || response.status === 423) setLocked();
            const error = new Error(data.error || t('error', 'Erreur'));
            error.data = data;
            throw error;
        }
        if (state.unlocked && !['status','bootstrap','unlock','lock'].includes(action)) scheduleAutoLock(AUTO_LOCK_MINUTES * 60);
        emitActivity(data);
        return data;
    }

    function scheduleAutoLock(seconds) {
        if (state.autoLockTimer) clearTimeout(state.autoLockTimer);
        state.autoLockTimer = null;
        if (!state.unlocked) return;
        const delay = Math.max(1, Number(seconds || (AUTO_LOCK_MINUTES * 60))) * 1000;
        state.autoLockTimer = setTimeout(() => setLocked(), delay);
    }
    function setUnlocked(expiresIn) {
        state.unlocked = true;
        statusEl.textContent = t('unlock', 'Déverrouillé').replace(/^Déverrouiller$/, 'Déverrouillé').replace(/^Unlock$/, 'Unlocked');
        statusEl.classList.add('is-unlocked');
        entryPanel.hidden = false;
        entryPanel.open = false;
        accessPanel.open = false;
        accessPanel.hidden = true;
        if (accessLockedEl) accessLockedEl.hidden = true;
        if (accessUnlockedEl) accessUnlockedEl.hidden = true;
        vaultEl.hidden = false;
        scheduleAutoLock(expiresIn);
        api('pro_settings_get').then(r=>{if(r&&r.settings)PRO_SETTINGS=Object.assign(PRO_SETTINGS,r.settings)}).catch(()=>{});
        announceResize();
    }
    function setLocked() {
        state.unlocked = false;
        state.items = [];
        if (state.autoLockTimer) clearTimeout(state.autoLockTimer);
        state.autoLockTimer = null;
        statusEl.textContent = t('locked', 'Coffre verrouillé');
        statusEl.classList.remove('is-unlocked');
        entryPanel.open = false;
        entryPanel.hidden = true;
        accessPanel.hidden = false;
        accessPanel.open = false;
        if (accessLockedEl) accessLockedEl.hidden = false;
        if (accessUnlockedEl) accessUnlockedEl.hidden = true;
        vaultEl.hidden = true;
        listEl.replaceChildren();
        byField('select-all').checked = false;
        if (byField('account-password')) byField('account-password').value = '';
        webSessionToken = '';
        webSessionExpiresAt = 0;
        closeModal();
        announceResize();
    }

    function randomIndex(max) {
        if (!Number.isInteger(max) || max <= 0) throw new Error('Pool aléatoire invalide.');
        const limit = Math.floor(0x100000000 / max) * max;
        const buffer = new Uint32Array(1);
        do { window.crypto.getRandomValues(buffer); } while (buffer[0] >= limit);
        return buffer[0] % max;
    }
    function securePick(chars) { return chars[randomIndex(chars.length)]; }
    function secureShuffle(characters) {
        for (let index = characters.length - 1; index > 0; index--) {
            const swapIndex = randomIndex(index + 1);
            [characters[index], characters[swapIndex]] = [characters[swapIndex], characters[index]];
        }
        return characters.join('');
    }
    function generatePassword() {
        const lower = 'abcdefghijkmnopqrstuvwxyz';
        const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        const numbers = '23456789';
        const special = '!@#$%&*?_+-=';
        const includeSpecial = byField('special').checked;
        const length = Math.max(12, Math.min(128, Number.parseInt(byField('length').value, 10) || 20));
        byField('length').value = String(length);
        const requiredPools = [lower, upper, numbers];
        if (includeSpecial) requiredPools.push(special);
        const fullPool = requiredPools.join('');
        const characters = requiredPools.map(securePick);
        while (characters.length < length) characters.push(securePick(fullPool));
        setPreview(secureShuffle(characters));
    }
    function setPreview(value) {
        state.preview = String(value || '');
        previewEl.value = state.preview;
        updateStrength(state.preview);
    }
    function updateStrength(password) {
        strengthBar.className = 'genpw-strength-fill';
        if (!password) { strengthLabel.textContent = t('strength_none', 'Robustesse non évaluée'); strengthTime.textContent = '—'; return; }
        let charset = 0;
        if (/[a-z]/.test(password)) charset += 26;
        if (/[A-Z]/.test(password)) charset += 26;
        if (/\d/.test(password)) charset += 10;
        if (/[^A-Za-z0-9]/.test(password)) charset += 32;
        let entropy = password.length * Math.log2(Math.max(charset, 1));
        if (/(.)\1{2,}/.test(password)) entropy -= 20;
        if (/1234|abcd|azerty|qwerty|password|admin/i.test(password)) entropy -= 35;
        entropy = Math.max(0, entropy);
        let level = 1, label = 'Faible';
        if (entropy >= 45) { level = 2; label = t('strength_medium', 'Moyen'); }
        if (entropy >= 70) { level = 3; label = 'Fort'; }
        if (entropy >= 95) { level = 4; label = t('strength_excellent', 'Excellent'); }
        strengthBar.classList.add(`level-${level}`);
        strengthLabel.textContent = `${label} · ~${Math.round(entropy)} bits`;
        strengthTime.textContent = formatCrackTime(entropy);
    }
    function formatCrackTime(entropy) {
        const log10Seconds = entropy * Math.LOG10E * Math.LN2 - 10;
        if (log10Seconds < 0) return t('time_instant', 'Moins d’une seconde');
        if (log10Seconds > 20) return t('millennia', 'Des millénaires');
        const seconds = 10 ** log10Seconds;
        const units = [[t('years','an(s)'),31557600],[t('days','jour(s)'),86400],[t('hours','heure(s)'),3600],[t('minutes','minute(s)'),60],[t('seconds','seconde(s)'),1]];
        for (const [name, divider] of units) if (seconds >= divider) return `~${Math.max(1, Math.floor(seconds / divider)).toLocaleString()} ${name}`;
        return t('time_instant', 'Moins d’une seconde');
    }
    function toggleCategoryFields() {
        const category = byField('category').value;
        byRole('url-field').hidden = category !== 'Site web';
        byRole('user-label').textContent = category === 'Wi-Fi' ? t('ssid','Nom du réseau (SSID)') : t('user','Identifiant / e-mail');
        byRole('manual-label').textContent = category === 'Wi-Fi' ? t('wifi_manual','Clé Wi-Fi existante') : t('manual','Mot de passe existant');
        byField('user').placeholder = category === 'Wi-Fi' ? t('ssid','Nom du réseau (SSID)') : 'nom@exemple.fr';
        announceResize();
    }
    async function copyText(text, button) {
        if (!text) return;
        try {
            if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
            else {
                const area = document.createElement('textarea');
                area.value = text; area.setAttribute('readonly', ''); area.style.position = 'fixed'; area.style.left = '-9999px';
                document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
            }
            if (button) { const original = button.innerHTML; button.textContent = '✓'; window.setTimeout(() => { button.innerHTML = original; }, 800); }
            const clearAfter=Math.max(0,Number(PRO_SETTINGS.clipboard_seconds||0));
            if(clearAfter>0 && navigator.clipboard && window.isSecureContext){
                window.setTimeout(()=>{ navigator.clipboard.writeText('').catch(()=>{}); },clearAfter*1000);
            }
        } catch (_) { toast('Copie refusée par le navigateur.', true); }
    }

    function extraFieldLabel(type) {
        return ({web:'Lien Web',user:'Identifiant',note:'Note longue',text:'Texte',date:'Date',number:'Numéro',email:'E-mail',phone:'Téléphone',password:'Mot de passe',secret:'Secret',pin:'PIN',api_key:'Clé API / Token',ssh_key:'Clé SSH',other:'Autres'})[type] || 'Autres';
    }
    function addExtraFieldRow(field = {}) {
        if (!extraFieldsHost) return;
        const allowedTypes=['web','user','password','secret','pin','api_key','ssh_key','note','text','date','number','email','phone','other'];
        const type = allowedTypes.includes(String(field.type || '')) ? String(field.type) : 'other';
        const row = document.createElement('div'); row.className = 'genpw-extra-row'; row.dataset.extraId = String(field.id || ('f_'+Math.random().toString(36).slice(2,14)));
        const typeSelect = document.createElement('select'); typeSelect.className='genpw-select genpw-extra-type';
        [['web','Lien Web'],['user','Identifiant'],['password','Mot de passe'],['secret','Secret'],['pin','PIN'],['api_key','Clé API / Token'],['ssh_key','Clé SSH'],['note','Note longue'],['text','Texte'],['date','Date'],['number','Numéro'],['email','E-mail'],['phone','Téléphone'],['other','Autres']].forEach(([v,l])=>{ const o=document.createElement('option'); o.value=v;o.textContent=l;typeSelect.appendChild(o); });
        typeSelect.value=type;
        const label = document.createElement('input'); label.className='genpw-input genpw-extra-label'; label.type='text'; label.maxLength=120; label.placeholder='Libellé'; label.value=String(field.label || extraFieldLabel(type));
        let value = document.createElement(type === 'note' ? 'textarea' : 'input');
        const configureValue = (node, fieldType) => {
            node.className='genpw-input genpw-extra-value'; node.placeholder='Valeur';
            if (node.tagName === 'TEXTAREA') { node.rows=2; node.maxLength=12000; }
            else {
                const sensitive=['password','secret','pin','api_key','ssh_key'].includes(fieldType);
                node.type = sensitive ? 'password' : (fieldType === 'web' ? 'url' : (fieldType === 'date' ? 'date' : (fieldType === 'number' ? 'number' : (fieldType === 'email' ? 'email' : (fieldType === 'phone' ? 'tel' : 'text')))));
                if (fieldType !== 'date') node.maxLength = fieldType === 'web' ? 2048 : (sensitive ? 16384 : 12000);
            }
        };
        configureValue(value,type); value.value=String(field.value || '');
        const del=document.createElement('button'); del.type='button'; del.className='genpw-btn is-danger genpw-extra-remove'; del.textContent='✕'; del.title='Supprimer ce champ'; del.addEventListener('click',()=>row.remove());
        typeSelect.addEventListener('change',()=>{
            const current=value.value; const nextType=typeSelect.value; const replacement=document.createElement(nextType==='note'?'textarea':'input');
            configureValue(replacement,nextType); replacement.value=current; value.replaceWith(replacement); value=replacement;
            if(!label.value.trim()) label.value=extraFieldLabel(nextType);
        });
        row.append(typeSelect,label,value,del); extraFieldsHost.appendChild(row);
    }
    function setExtraFields(fields) {
        if (!extraFieldsHost) return; extraFieldsHost.replaceChildren();
        (Array.isArray(fields)?fields:[]).forEach(addExtraFieldRow);
    }
    function collectExtraFields() {
        if (!extraFieldsHost) return [];
        return [...extraFieldsHost.querySelectorAll('.genpw-extra-row')].map(row=>({id:String(row.dataset.extraId||''),type:String(row.querySelector('.genpw-extra-type')?.value||'other'),label:String(row.querySelector('.genpw-extra-label')?.value||'').trim(),value:String(row.querySelector('.genpw-extra-value')?.value||'')})).filter(f=>f.label||f.value);
    }
    function restoreEntryPanelHome(reset = false) {
        if (!entryPanel || !entryPanelHome.parent) return;
        if (entryPanel.parentNode !== entryPanelHome.parent) entryPanelHome.parent.insertBefore(entryPanel, entryPanelHome.next);
        entryPanel.classList.remove('is-in-credential-window');
        if (reset) { resetEntryForm(); entryPanel.hidden = !can('vault.create'); entryPanel.open = false; }
    }
    function makeCredentialDialogDraggable() {
        if (!credentialDetailsDialog || credentialDetailsDialog.dataset.localDrag === '1') return;
        credentialDetailsDialog.dataset.localDrag='1';
        const head=credentialDetailsDialog.querySelector('.genpw-modal-head'); if(!head) return;
        head.addEventListener('pointerdown', event=>{
            if (event.button !== 0 || event.target.closest('button,input,select,textarea,a')) return;
            credentialDetailsDialog.classList.remove('genpw-open-bottom-right');
            const rect=credentialDetailsDialog.getBoundingClientRect();
            credentialDetailsDialog.style.position='fixed'; credentialDetailsDialog.style.left=rect.left+'px'; credentialDetailsDialog.style.top=rect.top+'px'; credentialDetailsDialog.style.transform='none'; credentialDetailsDialog.style.margin='0';
            const dx=event.clientX-rect.left, dy=event.clientY-rect.top;
            const move=e=>{ const w=credentialDetailsDialog.offsetWidth,h=credentialDetailsDialog.offsetHeight; credentialDetailsDialog.style.left=Math.max(0,Math.min(window.innerWidth-w,e.clientX-dx))+'px'; credentialDetailsDialog.style.top=Math.max(0,Math.min(window.innerHeight-h,e.clientY-dy))+'px'; };
            const up=()=>{ window.removeEventListener('pointermove',move,true); window.removeEventListener('pointerup',up,true); };
            window.addEventListener('pointermove',move,true); window.addEventListener('pointerup',up,true); event.preventDefault();
        });
    }

    function mfaMethodLabel(method) {
        const labels = {
            none:'Aucune',
            totp:'TOTP - code temporaire',
            hotp:'HOTP - code par compteur',
            email:'Code reçu par e-mail',
            sms:'Code reçu par SMS',
            push:'Validation Push',
            webauthn:'Clé de sécurité / Passkey',
            other:'Autre méthode MFA'
        };
        return labels[String(method || 'none')] || String(method || 'MFA');
    }
    function setMfaLabel(role, text) {
        const node = root.querySelector(`[data-role="${role}"]`);
        if (node) node.textContent = text;
    }
    function setMfaFieldVisible(role, visible) {
        const node = byRole(role);
        if (!node) return;
        node.hidden = !visible;
        node.style.display = visible ? '' : 'none';
        node.setAttribute('aria-hidden', visible ? 'false' : 'true');
    }
    function setMfaActionVisible(action, visible) {
        const node = byAction(action);
        if (!node) return;
        node.hidden = !visible;
        node.style.display = visible ? '' : 'none';
        node.setAttribute('aria-hidden', visible ? 'false' : 'true');
    }
    function updateMfaEditor() {
        const method = String(byField('mfa-method') ? byField('mfa-method').value : 'none');
        const totp = method === 'totp';
        const hotp = method === 'hotp';
        const otp = totp || hotp;

        // Les paramètres cryptographiques n'ont de sens que pour TOTP/HOTP.
        setMfaFieldVisible('mfa-secret-field', otp);
        setMfaFieldVisible('mfa-encoding-field', otp);
        setMfaFieldVisible('mfa-algorithm-field', otp);
        setMfaFieldVisible('mfa-digits-field', otp);
        setMfaFieldVisible('mfa-period-field', totp);
        setMfaFieldVisible('mfa-counter-field', hotp);

        // QR/URI servent uniquement à enrôler un générateur OTP. On les laisse aussi
        // disponibles quand aucune méthode n'est encore choisie afin que l'import
        // puisse déterminer automatiquement TOTP ou HOTP.
        setMfaActionVisible('mfa-import-qr', method === 'none' || otp);
        setMfaActionVisible('mfa-import-uri', method === 'none' || otp);

        const labels = {
            none:    {source:'Clé secrète / URI MFA', issuer:'Service / fournisseur MFA', account:'Compte / destination MFA', notes:'Notes MFA / procédure'},
            totp:    {source:'Clé secrète TOTP / URI otpauth://', issuer:'Service / fournisseur TOTP', account:'Compte protégé par TOTP', notes:'Notes TOTP / procédure'},
            hotp:    {source:'Clé secrète HOTP / URI otpauth://', issuer:'Service / fournisseur HOTP', account:'Compte protégé par HOTP', notes:'Notes HOTP / procédure'},
            email:   {source:'Clé secrète', issuer:'Service / site utilisant le MFA', account:'Adresse e-mail recevant le code', notes:'Notes sur le MFA par e-mail'},
            sms:     {source:'Clé secrète', issuer:'Service / site utilisant le MFA', account:'Numéro de téléphone recevant le code', notes:'Notes sur le MFA par SMS'},
            push:    {source:'Clé secrète', issuer:'Application / fournisseur Push', account:'Compte / appareil de validation Push', notes:'Notes sur la validation Push'},
            webauthn:{source:'Clé secrète', issuer:'Service / site utilisant la Passkey', account:'Clé / appareil / identifiant Passkey', notes:'Notes sur la clé de sécurité / Passkey'},
            other:   {source:'Clé secrète', issuer:'Service / fournisseur MFA', account:'Identifiant / destination du second facteur', notes:'Description de la méthode MFA'}
        };
        const meta = labels[method] || labels.other;
        setMfaLabel('mfa-source-label', meta.source);
        setMfaLabel('mfa-issuer-label', meta.issuer);
        setMfaLabel('mfa-account-label', meta.account);
        setMfaLabel('mfa-notes-label', meta.notes);
        const help = byRole('mfa-method-help');
        if (help) {
            const helpText = {
                totp:'TOTP : DMD-GenPW stocke la clé secrète chiffrée et génère un code temporaire renouvelé selon la période configurée.',
                hotp:'HOTP : DMD-GenPW stocke la clé secrète chiffrée et génère un code basé sur le compteur. Le compteur doit rester synchronisé avec le service.',
                email:'Code par e-mail : GenPW mémorise le service et l’adresse de réception. Le code reste envoyé par le service et n’est pas généré par GenPW.',
                sms:'Code par SMS : GenPW mémorise le service et le numéro destinataire. Le code reste envoyé par le service et n’est pas généré par GenPW.',
                push:'Validation Push : GenPW mémorise le fournisseur, le compte ou l’appareil. La notification Push reste gérée par l’application du fournisseur.',
                webauthn:'Passkey / clé de sécurité : GenPW mémorise la méthode et l’appareil. La clé privée WebAuthn n’est pas copiée dans GenPW.',
                other:'Autre méthode : utilisez ces champs pour documenter précisément le second facteur. Aucun code n’est généré par GenPW.',
                none:'Sélectionnez une méthode MFA. TOTP/HOTP permettent la génération de codes directement dans DMD-GenPW.'
            };
            help.textContent = helpText[method] || helpText.other;
        }

        const account = byField('mfa-account');
        if (account) {
            const placeholders = {
                totp:'compte@exemple.fr', hotp:'compte@exemple.fr', email:'adresse@exemple.fr',
                sms:'+33 6 00 00 00 00', push:'compte / téléphone / application',
                webauthn:'YubiKey, Windows Hello, iPhone…', other:'identifiant ou destination'
            };
            account.placeholder = placeholders[method] || 'compte / destination';
        }
        if (mfaSummary) {
            let suffix = '';
            if (state.editingMfaExisting && !state.editingMfaLoaded && method === state.editingMfaOriginalMethod && method !== 'none') suffix = ' · configurée';
            else if (method !== 'none' && method !== state.editingMfaOriginalMethod) suffix = ' · non enregistrée';
            mfaSummary.textContent = mfaMethodLabel(method) + suffix;
        }
        announceResize();
    }
    function resetMfaForm() {
        state.editingMfaExisting = false;
        state.editingMfaLoaded = false;
        state.editingMfaOriginalMethod = 'none';
        if (byField('mfa-method')) byField('mfa-method').value = 'none';
        if (byField('mfa-source')) byField('mfa-source').value = '';
        if (byField('mfa-encoding')) byField('mfa-encoding').value = 'auto';
        if (byField('mfa-algorithm')) byField('mfa-algorithm').value = 'SHA1';
        if (byField('mfa-digits')) byField('mfa-digits').value = '6';
        if (byField('mfa-period')) byField('mfa-period').value = '30';
        if (byField('mfa-counter')) byField('mfa-counter').value = '0';
        if (byField('mfa-issuer')) byField('mfa-issuer').value = '';
        if (byField('mfa-account')) byField('mfa-account').value = '';
        if (byField('mfa-recovery')) byField('mfa-recovery').value = '';
        if (byField('mfa-notes')) byField('mfa-notes').value = '';
        if (byAction('mfa-load')) byAction('mfa-load').hidden = true;
        if (byAction('mfa-clear')) byAction('mfa-clear').hidden = true;
        if (mfaEditor) mfaEditor.open = false;
        updateMfaEditor();
    }
    function prepareMfaForItem(item) {
        resetMfaForm();
        state.editingMfaExisting = Boolean(item && item.mfa_configured);
        state.editingMfaLoaded = false;
        state.editingMfaOriginalMethod = state.editingMfaExisting ? String(item.mfa_method || 'totp') : 'none';
        if (byField('mfa-method')) byField('mfa-method').value = state.editingMfaOriginalMethod;
        if (byAction('mfa-load')) byAction('mfa-load').hidden = !state.editingMfaExisting;
        if (byAction('mfa-clear')) byAction('mfa-clear').hidden = !state.editingMfaExisting;
        updateMfaEditor();
    }
    function fillMfaForm(config) {
        config = config && typeof config === 'object' ? {...config} : {};
        /* Nettoyage des valeurs polluées par les anciennes tentatives d'import Microsoft.
           Une URL mobileappcommunicator/phonefactor n'est jamais un émetteur, un compte,
           un code de récupération ni un secret TOTP. */
        ['issuer','account','recovery_codes','notes','secret','otpauth_uri'].forEach((key)=>{
            if (mfaLooksLikeMicrosoftPushEnrollment(config[key])) config[key]='';
        });
        const legacyNumeric=[config.issuer,config.account,config.recovery_codes].map(v=>String(v||'').trim());
        if (!String(config.secret||config.otpauth_uri||'').trim() && legacyNumeric[0] && legacyNumeric.every(v=>v===legacyNumeric[0]) && /^[0-9]{6,10}$/.test(legacyNumeric[0])) {
            config.issuer=''; config.account=''; config.recovery_codes='';
        }
        const set = (field, value) => { const node=byField(field); if(node) node.value = value == null ? '' : String(value); };
        set('mfa-method', config.method || 'none');
        set('mfa-source', config.otpauth_uri || config.secret || '');
        set('mfa-encoding', config.encoding || 'auto');
        set('mfa-algorithm', config.algorithm || 'SHA1');
        set('mfa-digits', config.digits || 6);
        set('mfa-period', config.period || 30);
        set('mfa-counter', config.counter || 0);
        set('mfa-issuer', config.issuer || '');
        set('mfa-account', config.account || '');
        set('mfa-recovery', config.recovery_codes || '');
        set('mfa-notes', config.notes || '');
        state.editingMfaLoaded = true;
        if (byAction('mfa-load')) byAction('mfa-load').hidden = true;
        updateMfaEditor();
    }
    async function loadMfaForEditing(item) {
        if (!item || !item.mfa_configured) return;
        const button = byAction('mfa-load'); if (button) button.disabled = true;
        try {
            const result = await api('mfa_get', { id:item.id, kind:item.kind || 'owned' });
            if (!result.configured || !result.mfa) return toast('Aucune 2FA configurée sur cette entrée.', true);
            fillMfaForm(result.mfa);
            if (mfaEditor) mfaEditor.open = true;
        } catch (error) { toast(error.message,true); }
        finally { if (button) button.disabled = false; }
    }
    async function importDomyDeskMfa() {
        const button = byAction('mfa-import-domydesk');
        if (button) button.disabled = true;
        try {
            const result = await api('system_mfa_import', {});
            if (!result || !result.mfa) throw new Error('MFA DoMyDesk indisponible.');
            fillMfaForm(result.mfa);
            if (mfaEditor) mfaEditor.open = true;
            toast('MFA DoMyDesk intégré à la fiche.');
        } catch (error) {
            toast(error && error.message ? error.message : 'Impossible d’intégrer le MFA DoMyDesk.', true);
        } finally {
            if (button) button.disabled = false;
        }
    }
    function mfaLooksLikeMicrosoftPushEnrollment(value) {
        const raw=String(value||'').trim().toLowerCase();
        return raw.includes('mobileappcommunicator.auth.microsoft.com/activate') || raw.startsWith('phonefactor:/') || raw.startsWith('phonefactor://');
    }
    function mfaMicrosoftPushMessage() {
        return 'Ce QR Microsoft Authenticator est un enrôlement Push et ne contient pas le secret TOTP. Pour utiliser DMD-GenPW comme authentificateur, configurez une autre application d’authentification sur le service puis importez le QR TOTP ou la clé secrète affichée.';
    }
    function mfaCurrentEntryPicker(items,title='Choisir le compte MFA') {
        items=Array.isArray(items)?items.filter(Boolean):[];
        if(!items.length) throw new Error('Aucun compte MFA exploitable détecté.');
        if(items.length===1){ mfaApplyToCurrentEntry(items[0]); toast('MFA chargé dans la fiche.'); return; }
        const wrap=el('div','genpw-panel-stack');
        wrap.appendChild(el('div','genpw-import-info','Sélectionnez le compte MFA à associer à cette fiche.'));
        const list=el('div','genpw-mfa-import-list'); wrap.appendChild(list);
        let selected=0;
        items.forEach((item,index)=>{
            const row=el('label','genpw-mfa-import-row');
            const radio=document.createElement('input'); radio.type='radio'; radio.name='genpw-current-mfa-pick'; radio.value=String(index); radio.checked=index===0;
            radio.addEventListener('change',()=>{selected=index;});
            const body=el('span','genpw-mfa-import-row-main');
            body.append(el('strong','',item.issuer||item.account||'Compte MFA'),el('span','',`${item.account||'Compte sans libellé'} · ${String(item.method||'totp').toUpperCase()} · ${item.digits||6} chiffres`));
            row.append(radio,body); list.appendChild(row);
        });
        const actions=el('div','genpw-panel-actions');
        const apply=el('button','genpw-btn is-primary','Utiliser ce compte'); apply.type='button';
        apply.addEventListener('click',()=>{ mfaApplyToCurrentEntry(items[selected]); closeModal(); toast('MFA chargé dans la fiche.'); });
        actions.appendChild(apply); wrap.appendChild(actions);
        modalPanel.replaceChildren(wrap); openModal(title,'panel');
    }
    function mfaApplyToCurrentEntry(item) {
        if(!item || typeof item!=='object') throw new Error('Données MFA invalides.');
        const set=(field,value)=>{const n=byField(field);if(n)n.value=value==null?'':String(value)};
        set('mfa-method',item.method||'totp');
        set('mfa-source',item.source||item.secret||item.otpauth_uri||'');
        set('mfa-encoding',item.encoding||'base32');
        set('mfa-algorithm',item.algorithm||'SHA1');
        set('mfa-digits',item.digits||6);
        set('mfa-period',item.period||30);
        set('mfa-counter',item.counter||0);
        if(item.issuer) set('mfa-issuer',item.issuer);
        if(item.account) set('mfa-account',item.account);
        if(item.recovery_codes) set('mfa-recovery',item.recovery_codes);
        if(item.notes) set('mfa-notes',item.notes);
        state.editingMfaLoaded=true;
        if(mfaEditor)mfaEditor.open=true;
        updateMfaEditor();
    }
    function mfaParseManualInput(value) {
        const raw=String(value||'').trim();
        if(!raw) throw new Error('Aucune donnée MFA saisie.');
        if(mfaLooksLikeMicrosoftPushEnrollment(raw)) throw new Error(mfaMicrosoftPushMessage());
        const msUrl=(raw.match(/https?:\/\/mobileappcommunicator\.auth\.microsoft\.com\/activate(?:v2)?\/[^\s]+/i)||[])[0];
        if(msUrl) throw new Error(mfaMicrosoftPushMessage());
        const uri=(raw.match(/otpauth:\/\/[^\s<>'"]+/i)||[])[0];
        if(uri) return mfaParseOtpAuth(uri);
        const compact=raw.replace(/[\s-]+/g,'');
        if(/^[A-Z2-7]+=*$/i.test(compact) && compact.length>=16) {
            return {method:'totp',source:compact.toUpperCase(),encoding:'base32',algorithm:'SHA1',digits:6,period:30,counter:0,issuer:'',account:'',recovery_codes:'',notes:'Import clé secrète MFA'};
        }
        if(/^[0-9a-f]+$/i.test(compact) && compact.length>=20 && compact.length%2===0) {
            return {method:'totp',source:compact,encoding:'hex',algorithm:'SHA1',digits:6,period:30,counter:0,issuer:'',account:'',recovery_codes:'',notes:'Import clé secrète MFA'};
        }
        if(/^[A-Za-z0-9+/]+={0,2}$/.test(compact) && compact.length>=16 && /[+/=]/.test(compact)) {
            return {method:'totp',source:compact,encoding:'base64',algorithm:'SHA1',digits:6,period:30,counter:0,issuer:'',account:'',recovery_codes:'',notes:'Import clé secrète MFA'};
        }
        throw new Error('Aucun secret TOTP/HOTP ou URI otpauth exploitable détecté.');
    }
    async function importQrIntoCurrentEntry(file) {
        const values=await mfaDecodeQrImage(file);
        if(!values.length) throw new Error('Aucun QR MFA lisible dans cette image.');
        const raw=String(values[0]||'').trim();
        if(mfaLooksLikeMicrosoftPushEnrollment(raw)) { openCurrentMicrosoftImport(raw); return 'microsoft'; }
        if(raw.toLowerCase().startsWith('otpauth://')) { mfaApplyToCurrentEntry(mfaParseOtpAuth(raw)); return 'otp'; }
        if(raw.toLowerCase().startsWith('otpauth-migration://')) { const parsed=mfaParseGoogleMigration(raw); mfaCurrentEntryPicker(parsed.items,'Choisir un compte Google Authenticator'); return 'google'; }
        throw new Error('Le QR est lisible mais ne contient pas de configuration MFA importable.');
    }
    function openCurrentMfaManualImport() {
        const wrap=el('div','genpw-panel-stack');
        const info=el('div','genpw-import-info');
        info.innerHTML='<strong>Ajouter DMD-GenPW comme authentificateur</strong><span>Collez une URI <code>otpauth://</code> ou la clé secrète fournie par le service.</span><span>Pour Microsoft/Entra, utilisez l’option « autre application d’authentification » afin d’obtenir un QR/secret TOTP standard.</span>';
        wrap.appendChild(info);
        const label=el('label','genpw-field');label.appendChild(el('span','genpw-label','URI / clé secrète'));
        const input=document.createElement('textarea');input.className='genpw-input genpw-textarea';input.rows=4;input.placeholder='otpauth://… ou clé Base32';label.appendChild(input);wrap.appendChild(label);
        const actions=el('div','genpw-panel-actions');const apply=el('button','genpw-btn is-primary','Utiliser ce MFA');apply.type='button';actions.appendChild(apply);wrap.appendChild(actions);
        apply.addEventListener('click',()=>{try{const raw=String(input.value||'').trim();if(mfaLooksLikeMicrosoftPushEnrollment(raw)){closeModal();openCurrentMicrosoftImport(raw);return;}mfaApplyToCurrentEntry(mfaParseManualInput(raw));closeModal();toast('Configuration MFA chargée dans la fiche.');}catch(e){toast(e.message,true)}});
        modalPanel.replaceChildren(wrap);openModal('Ajouter un MFA à cette fiche','panel');
    }

    function collectMfaPayload() {
        return {
            method: byField('mfa-method') ? byField('mfa-method').value : 'none',
            source: byField('mfa-source') ? byField('mfa-source').value : '',
            encoding: byField('mfa-encoding') ? byField('mfa-encoding').value : 'auto',
            algorithm: byField('mfa-algorithm') ? byField('mfa-algorithm').value : 'SHA1',
            digits: byField('mfa-digits') ? byField('mfa-digits').value : 6,
            period: byField('mfa-period') ? byField('mfa-period').value : 30,
            counter: byField('mfa-counter') ? byField('mfa-counter').value : 0,
            issuer: byField('mfa-issuer') ? byField('mfa-issuer').value : '',
            account: byField('mfa-account') ? byField('mfa-account').value : '',
            recovery_codes: byField('mfa-recovery') ? byField('mfa-recovery').value : '',
            notes: byField('mfa-notes') ? byField('mfa-notes').value : ''
        };
    }
    async function persistMfaForEntry(id, editing) {
        const method = String(byField('mfa-method') ? byField('mfa-method').value : 'none');
        if (method === 'none') {
            if (editing && state.editingMfaExisting) await api('mfa_clear', { id });
            return;
        }
        const generatedMethods = ['totp','hotp'];
        const memoMethods = ['email','sms','push','webauthn','other'];
        if (!generatedMethods.includes(method) && !memoMethods.includes(method)) throw new Error('Méthode MFA non prise en charge.');
        if (editing && state.editingMfaExisting && !state.editingMfaLoaded && method === state.editingMfaOriginalMethod) return;
        if (generatedMethods.includes(method) && !String(byField('mfa-source') ? byField('mfa-source').value : '').trim()) {
            const suspect=[byField('mfa-account')?.value||'',byField('mfa-recovery')?.value||'',byField('mfa-notes')?.value||''].find(mfaLooksLikeMicrosoftPushEnrollment);
            if(suspect) throw new Error(mfaMicrosoftPushMessage());
            if(!editing || !state.editingMfaExisting) throw new Error('Ajoutez le secret permanent ou l’URI otpauth pour la 2FA.');
        }
        await api('mfa_save', { id, mfa: collectMfaPayload() });
    }

    const entryAttachmentListEl = root.querySelector('[data-role="entry-attachment-list"]');
    const entryAttachmentFileEl = byField('entry-attachment-file');

    function formatAttachmentSize(bytes) {
        const n=Number(bytes||0);
        if(n<1024) return n+' o';
        if(n<1024*1024) return Math.ceil(n/1024)+' Ko';
        return (n/(1024*1024)).toFixed(1)+' Mo';
    }

    function renderEntryAttachments() {
        if(!entryAttachmentListEl) return;
        entryAttachmentListEl.replaceChildren();

        state.entryAttachments.forEach(a=>{
            const row=el('div','genpw-share-line');
            row.appendChild(el('span','',`${a.name||'fichier'} · ${formatAttachmentSize(a.size)}`));
            const actions=el('div','genpw-panel-actions');

            const get=el('button','genpw-btn','⇩ Télécharger');
            get.type='button';
            get.addEventListener('click',async()=>{
                try{
                    const r=await api('attachment_get',{attachment_id:a.id});
                    downloadBase64(r.attachment.name,r.attachment.mime,r.content);
                }catch(e){toast(e.message,true)}
            });
            actions.appendChild(get);

            if(state.editingId && state.editingKind!=='shared'){
                const del=el('button','genpw-btn is-danger','🗑');
                del.type='button';
                del.title='Supprimer le fichier';
                del.addEventListener('click',async()=>{
                    if(!window.confirm('Supprimer cette pièce jointe ?')) return;
                    try{
                        await api('attachment_delete',{attachment_id:a.id});
                        state.entryAttachments=state.entryAttachments.filter(x=>x.id!==a.id);
                        renderEntryAttachments();
                    }catch(e){toast(e.message,true)}
                });
                actions.appendChild(del);
            }
            row.appendChild(actions);
            entryAttachmentListEl.appendChild(row);
        });

        state.pendingAttachmentFiles.forEach((f,index)=>{
            const row=el('div','genpw-share-line');
            row.appendChild(el('span','',`${f.name} · ${formatAttachmentSize(f.size)} · à enregistrer`));
            const del=el('button','genpw-btn is-danger','✕');
            del.type='button';
            del.addEventListener('click',()=>{
                state.pendingAttachmentFiles.splice(index,1);
                renderEntryAttachments();
            });
            row.appendChild(del);
            entryAttachmentListEl.appendChild(row);
        });

        if(!state.entryAttachments.length && !state.pendingAttachmentFiles.length){
            entryAttachmentListEl.appendChild(el('p','genpw-empty','Aucun fichier joint.'));
        }
    }

    async function loadEntryAttachments(id) {
        state.entryAttachments=[];
        if(!id){ renderEntryAttachments(); return; }
        try{
            const r=await api('attachment_list',{id});
            state.entryAttachments=Array.isArray(r.items)?r.items:[];
        }catch(e){
            toast(e.message,true);
        }
        renderEntryAttachments();
    }

    async function uploadPendingAttachments(id) {
        if(!id || !state.pendingAttachmentFiles.length) return;
        const files=[...state.pendingAttachmentFiles];
        for(const file of files){
            const fd=new FormData();
            fd.append('action','attachment_add');
            fd.append('id',id);
            fd.append('file',file,file.name);
            const resp=await fetch(apiUrl,{
                method:'POST',
                credentials:'same-origin',
                cache:'no-store',
                headers:{'X-CSRF-Token':csrf},
                body:fd
            });
            let data=null;
            try{data=await resp.json();}catch(_){}
            if(!resp.ok || !data || data.ok===false) throw new Error((data&&data.error)||`Upload impossible : ${file.name}`);
            state.entryAttachments.push(data.attachment);
        }
        state.pendingAttachmentFiles=[];
        renderEntryAttachments();
    }

    function queueEntryAttachments() {
        if(!entryAttachmentFileEl || !entryAttachmentFileEl.files || !entryAttachmentFileEl.files.length) return;
        for(const file of Array.from(entryAttachmentFileEl.files)){
            state.pendingAttachmentFiles.push(file);
        }
        entryAttachmentFileEl.value='';
        renderEntryAttachments();
    }

    async function startEdit(item) {
        if ((item.kind === 'shared' && item.read_only) || !can('vault.edit')) return;
        credentialEditingItem = item;
        state.editingId = item.id;
        state.editingKind = item.kind || 'owned';
        entryTitleEl.textContent = t('edit','Modifier') + ' · ' + (item.name || '');
        saveButton.textContent = '💾 ' + t('update','Enregistrer les modifications');
        byField('name').value = item.name || '';
        byField('category').value = item.cat || 'Autre';
        byField('url').value = item.url || '';
        byField('user').value = item.user || '';
        byField('notes').value = item.notes || '';
        byField('manual').value = '';
        setPreview('');
        previewEl.placeholder = 'Laisser vide pour conserver le mot de passe actuel';
        prepareMfaForItem(item);
        setExtraFields([]);
        try {
            const full = await api('entry_get', { id:item.id, kind:item.kind || 'owned' });
            setExtraFields(full.extra_fields || []);
        } catch (error) { toast(error.message, true); }
        state.pendingAttachmentFiles=[];
        await loadEntryAttachments(item.id);
        toggleCategoryFields();
        if (!credentialDetailsPanel) mountCredentialDetailsModal();
        if (credentialDetailsDialog) credentialDetailsDialog.classList.add('is-edit-mode');
        credentialDetailsPanel.replaceChildren();
        entryPanel.hidden = false; entryPanel.open = true; entryPanel.classList.add('is-in-credential-window');
        credentialDetailsPanel.appendChild(entryPanel);
        openCredentialDetailsModal(item.name || 'Identifiant');
        makeCredentialDialogDraggable();
    }
    function resetEntryForm() {
        state.editingId = null;
        state.editingKind = 'owned';
        entryTitleEl.textContent = t('generator','Nouvelle entrée');
        saveButton.textContent = '💾 ' + t('save','Enregistrer dans le coffre');
        byField('name').value = '';
        byField('category').value = DEFAULT_CATEGORY;
        byField('url').value = '';
        byField('user').value = '';
        byField('notes').value = '';
        byField('manual').value = '';
        previewEl.placeholder = '';
        setPreview('');
        resetMfaForm();
        setExtraFields([]);
        state.entryAttachments=[];
        state.pendingAttachmentFiles=[];
        if(entryAttachmentFileEl) entryAttachmentFileEl.value='';
        renderEntryAttachments();
        toggleCategoryFields();
    }
    async function startCreate() {
        if (!state.unlocked || !can('vault.create')) return;
        credentialEditingItem = null;
        resetEntryForm();
        state.editingId = null;
        state.editingKind = 'owned';
        entryTitleEl.textContent = t('generator','Nouvelle entrée');
        saveButton.textContent = '💾 ' + t('save','Enregistrer dans le coffre');
        if (!credentialDetailsPanel) mountCredentialDetailsModal();
        if (credentialDetailsDialog) credentialDetailsDialog.classList.add('is-edit-mode');
        credentialDetailsPanel.replaceChildren();
        entryPanel.hidden = false;
        entryPanel.open = true;
        entryPanel.classList.add('is-in-credential-window');
        credentialDetailsPanel.appendChild(entryPanel);
        openCredentialDetailsModal(t('generator','Nouvelle entrée'));
        makeCredentialDialogDraggable();
        const first = byField('name');
        if (first) setTimeout(() => first.focus(), 0);
    }

    async function saveEntry() {
        if (!state.unlocked) {
            toast(t('locked','Coffre verrouillé'), true);
            const unlockField = REQUIRE_SYSTEM_MFA ? byField('system-mfa-code') : byField('account-password');
            if (unlockField) unlockField.focus();
            return;
        }
        const editing = state.editingId !== null;
        if ((!editing && !can('vault.create')) || (editing && !can('vault.edit'))) return toast('Accès refusé.', true);
        if (!editing && !state.preview) return toast(t('empty_password','Mot de passe vide'), true);
        try {
            const action = editing ? (state.editingKind === 'shared' ? 'shared_update' : 'update') : 'add';
            const saved = await api(action, { id: editing ? state.editingId : undefined, name: byField('name').value, cat: byField('category').value, url: byField('url').value, user: byField('user').value, notes: byField('notes').value, pw: state.preview, extra_fields: collectExtraFields() });
            const savedId=saved.id || state.editingId;
            if (state.editingKind !== 'shared') await persistMfaForEntry(savedId, editing);
            if (state.editingKind !== 'shared') await uploadPendingAttachments(savedId);
            toast(editing ? 'Entrée modifiée.' : 'Entrée enregistrée.');
            restoreEntryPanelHome(false);
            entryPanel.open = false;
            credentialEditingItem = null;
            closeCredentialDetailsModal();
            resetEntryForm();
            await loadList();
        } catch (error) { toast(error.message, true); }
    }
    async function unlockVault() {
        const passwordInput = byField('account-password');
        const mfaInput = byField('system-mfa-code');
        if (REQUIRE_SYSTEM_MFA) {
            if (!mfaInput || !String(mfaInput.value || '').trim()) {
                toast('Code MFA DoMyDesk requis.', true);
                if (mfaInput) mfaInput.focus();
                return;
            }
        } else if (!passwordInput || !passwordInput.value) {
            toast(t('empty_password','Mot de passe vide'), true);
            if (passwordInput) passwordInput.focus();
            return;
        }
        byAction('unlock').disabled = true;
        try {
            const result = await api('unlock', {
                pwd: REQUIRE_SYSTEM_MFA ? '' : (passwordInput ? passwordInput.value : ''),
                mfa_code: mfaInput ? mfaInput.value : ''
            });
            if (passwordInput) passwordInput.value = '';
            if (mfaInput) mfaInput.value = '';
            setUnlocked(result.expires_in); await loadList();
            toast(`${t('unlock','Déverrouiller')} · ${AUTO_LOCK_MINUTES} min`);
        } catch (error) { toast(error.message, true); } finally { byAction('unlock').disabled = false; }
    }
    function categoryLabel(category) {
        return TXT['cat_' + category] || category;
    }
    function updateCategorySelect(preferredValue = '') {
        const select = byField('category');
        if (!select) return;
        const current = preferredValue || select.value || DEFAULT_CATEGORY || 'Autre';
        const values = [...new Set((state.categories || []).filter(Boolean))];
        if (!values.includes(current)) values.push(current);
        select.replaceChildren();
        values.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = categoryLabel(category);
            select.appendChild(option);
        });
        select.value = values.includes(current) ? current : (values.includes(DEFAULT_CATEGORY) ? DEFAULT_CATEGORY : 'Autre');
        toggleCategoryFields();
    }
    function applyCategoryPayload(result, preferredValue = '') {
        if (result && Array.isArray(result.categories)) state.categories = [...result.categories];
        if (result && Array.isArray(result.defaults)) state.defaultCategories = [...result.defaults];
        updateCategorySelect(preferredValue);
    }
    async function loadCategories(preferredValue = '') {
        const result = await api('categories');
        applyCategoryPayload(result, preferredValue);
        return result;
    }
    async function loadList() {
        if (!can('vault.list')) return;
        try {
            const result = await api('list');
            state.items = Array.isArray(result.items) ? result.items : [];
            const discovered = state.items.map(item => String(item.cat || 'Autre')).filter(Boolean);
            state.categories = [...new Set([...(state.categories || []), ...discovered])];
            updateCategorySelect();
            renderList(filteredItems());
        } catch (error) { toast(error.message, true); }
    }
    function filteredItems() {
        const query = byField('search').value.trim().toLocaleLowerCase();
        if (!query) return state.items;
        return state.items.filter(item => [item.name, item.cat, item.user, item.url, item.notes, item.owner].some(value => String(value || '').toLocaleLowerCase().includes(query)));
    }
    function makeButton(text, title, handler, extraClass = '') {
        const button = document.createElement('button');
        button.type = 'button'; button.className = `genpw-btn is-icon ${extraClass}`.trim(); button.textContent = text; button.title = title; button.addEventListener('click', handler); return button;
    }
    function renderList(items) {
        listEl.replaceChildren(); byField('select-all').checked = false;
        if (!items.length) { const empty = document.createElement('p'); empty.className = 'genpw-empty'; empty.textContent = t('empty','Aucune entrée.'); listEl.appendChild(empty); announceResize(); return; }
        const groups = new Map();
        items.forEach(item => { const category = item.cat || 'Autre'; if (!groups.has(category)) groups.set(category, []); groups.get(category).push(item); });
        groups.forEach((groupItems, category) => {
            const details = document.createElement('details');
            details.className = 'genpw-folder';
            details.dataset.category = category;
            details.open = byField('search').value.trim() !== '' || state.openCategories.has(category);
            details.addEventListener('toggle', () => {
                if (details.open) state.openCategories.add(category); else state.openCategories.delete(category);
            });

            const summary = document.createElement('summary');
            summary.dataset.dropCategory = category;
            const title = document.createElement('span'); title.textContent = `📂 ${categoryLabel(category)}`;
            const count = document.createElement('span'); count.className = 'genpw-count'; count.textContent = `${groupItems.length} ${t('entries','entrée(s)')}`;
            summary.append(title, count);

            if (can('vault.edit')) {
                const markDrop = event => {
                    if (!state.dragIds.length) return;
                    event.preventDefault();
                    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
                    details.classList.add('is-drop-target');
                };
                summary.addEventListener('dragenter', markDrop);
                summary.addEventListener('dragover', markDrop);
                summary.addEventListener('dragleave', event => {
                    if (!summary.contains(event.relatedTarget)) details.classList.remove('is-drop-target');
                });
                summary.addEventListener('drop', async event => {
                    event.preventDefault(); event.stopPropagation(); details.classList.remove('is-drop-target');
                    const ids = [...state.dragIds]; state.dragIds = [];
                    await moveItemsToCategory(ids, category);
                });
            }

            const body = document.createElement('div'); body.className = 'genpw-folder-body'; groupItems.forEach(item => body.appendChild(renderItem(item)));
            details.append(summary, body); listEl.appendChild(details);
        });
        decorateActionHub(); announceResize();
    }
    function renderItem(item) {
        const row = document.createElement('article');
        row.className = 'genpw-item' + (item.kind === 'shared' ? ' is-shared' : ''); row.dataset.id = item.id;
        row.dataset.dmdModuleId = 'DMD-GenPW'; row.dataset.dmdContextType = 'credential'; row.dataset.dmdContextId = `DMD-GenPW:credential:${item.id}`; row.dataset.dmdContextName = item.name || 'Identifiant'; row.dataset.dmdActionHub = '1';

        const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.className = 'genpw-select-item'; checkbox.value = item.id; checkbox.setAttribute('aria-label', `Sélectionner ${item.name}`);
        if (item.kind === 'shared' || !can('vault.delete')) { checkbox.disabled = true; checkbox.hidden = true; }

        const main = document.createElement('div'); main.className = 'genpw-item-main';
        const name = document.createElement('div'); name.className = 'genpw-item-name'; name.textContent = (item.favorite ? '★ ' : '') + (item.name || 'Sans nom'); name.title = item.name || 'Sans nom';
        if (item.mfa_code_ready) { const badge=document.createElement('span'); badge.className='genpw-mfa-badge'; badge.textContent='2FA'; badge.title=mfaMethodLabel(item.mfa_method || 'totp')+' · code générable'; name.appendChild(badge); }
        if (item.rotation_due) { const badge=document.createElement('span'); badge.className='genpw-mfa-badge'; badge.textContent='ROT'; badge.title='Rotation du mot de passe échue'; name.appendChild(badge); }
        if (item.expires_at && Date.parse(item.expires_at) < Date.now()) { const badge=document.createElement('span'); badge.className='genpw-mfa-badge'; badge.textContent='EXP'; badge.title='Entrée expirée'; name.appendChild(badge); }
        main.appendChild(name);

        if (item.user) {
            const userLine = document.createElement('div');
            userLine.className = 'genpw-vignette-user'; userLine.title = `Identifiant : ${item.user}`;
            const userValue = document.createElement('span'); userValue.textContent = item.user;
            userLine.appendChild(userValue);
            main.appendChild(userLine);
        } else {
            const userLine = document.createElement('div'); userLine.className = 'genpw-vignette-user is-empty'; userLine.textContent = 'Aucun identifiant';
            main.appendChild(userLine);
        }

        const meta = document.createElement('div'); meta.className = 'genpw-item-meta';
        const compactNote = String(item.notes || '').replace(/\s+/g, ' ').trim();
        const compactUrl = String(item.url || '').replace(/^https?:\/\//i, '').replace(/\/$/, '');
        const bits = [item.date, compactNote || compactUrl].filter(Boolean);
        if (item.kind === 'shared') bits.push(`${t('shared_by','Partagé par')} ${item.owner || '—'}`);
        meta.textContent = bits.join(' · ') || categoryLabel(item.cat || 'Autre');
        meta.title = bits.join(' · ');
        main.appendChild(meta);

        const buttons = document.createElement('div'); buttons.className = 'genpw-item-buttons';
        if (can('vault.reveal') && !item.mfa_only) {
            const reveal = document.createElement('button');
            reveal.type = 'button'; reveal.className = 'genpw-vignette-action'; reveal.title = t('reveal','Afficher le mot de passe'); reveal.setAttribute('aria-label', `${t('reveal','Afficher')} · ${item.name || ''}`); reveal.textContent = '👁';
            reveal.addEventListener('click', async event => {
                event.stopPropagation();
                if (reveal.disabled) return;
                reveal.disabled = true;
                try { showCredentialPopover('Mot de passe', await getSecret(item), reveal, true); }
                catch (error) { toast(error.message, true); }
                finally { reveal.disabled = false; }
            });
            buttons.appendChild(reveal);
        }

        if ((item.user || (item.kind || 'owned') !== 'shared') && can('vault.copy.user')) {
            const copyUser = document.createElement('button');
            copyUser.type = 'button';
            copyUser.className = 'genpw-vignette-action';
            copyUser.title = t('copy_user','Copier l’identifiant');
            copyUser.setAttribute('aria-label', `${t('copy_user','Copier l’identifiant')} · ${item.name || ''}`);
            copyUser.textContent = 'ID';
            copyUser.addEventListener('click', async event => {
                event.stopPropagation();
                await copyUserValues(item, copyUser);
                api('access_event',{id:item.id,event:'copy.id'}).catch(()=>{});
            });
            buttons.appendChild(copyUser);
        }

        if (can('vault.reveal') && !item.mfa_only) {
            const copyPassword = document.createElement('button');
            copyPassword.type = 'button';
            copyPassword.className = 'genpw-vignette-action';
            copyPassword.title = t('copy','Copier le mot de passe');
            copyPassword.setAttribute('aria-label', `${t('copy','Copier le mot de passe')} · ${item.name || ''}`);
            copyPassword.textContent = 'PW';
            copyPassword.addEventListener('click', async event => {
                event.stopPropagation();
                await copySecret(item, copyPassword);
                api('access_event',{id:item.id,event:'copy.pw'}).catch(()=>{});
            });
            buttons.appendChild(copyPassword);
        }

        if (item.mfa_code_ready && can('vault.reveal') && ['totp','hotp'].includes(String(item.mfa_method || ''))) {
            const copyMfa = document.createElement('button');
            copyMfa.type = 'button';
            copyMfa.className = 'genpw-vignette-action';
            copyMfa.title = 'Copier le code MFA';
            copyMfa.setAttribute('aria-label', `Copier le code MFA · ${item.name || ''}`);
            copyMfa.textContent = 'MFA';
            copyMfa.addEventListener('click', event => {
                event.stopPropagation();
                copyMfaCode(item, copyMfa);
                api('access_event',{id:item.id,event:'copy.mfa'}).catch(()=>{});
            });
            buttons.appendChild(copyMfa);
        }

        if (item.url && can('vault.web')) {
            const openWeb = document.createElement('button');
            openWeb.type = 'button';
            openWeb.className = 'genpw-vignette-action genpw-web-action';
            openWeb.title = 'Ouvrir la page du site';
            openWeb.setAttribute('aria-label', `Ouvrir la page du site · ${item.name || ''}`);
            openWeb.textContent = '🌐';
            openWeb.addEventListener('click', event => {
                event.preventDefault();
                event.stopPropagation();
                openWebsite(item.url, item.name || 'Site web', openWeb);
                api('access_event',{id:item.id,event:'open.url'}).catch(()=>{});
            });
            buttons.appendChild(openWeb);
        }

        const menu = document.createElement('details'); menu.className = 'genpw-entry-menu'; menu.dataset.genpwEntryMenu = '1';
        const trigger = document.createElement('summary'); trigger.className = 'genpw-entry-menu-trigger'; trigger.title = t('actions','Actions'); trigger.setAttribute('aria-label', `${t('actions','Actions')} · ${item.name || ''}`); trigger.textContent = '•••';
        const panel = document.createElement('div'); panel.className = 'genpw-entry-menu-panel';

        const menuAction = (icon, label, handler, extraClass = '') => {
            const button = document.createElement('button'); button.type = 'button'; button.className = `genpw-entry-menu-action ${extraClass}`.trim(); button.title = label;
            const iconEl = document.createElement('span'); iconEl.className = 'genpw-entry-menu-icon'; iconEl.textContent = icon;
            const labelEl = document.createElement('span'); labelEl.className = 'genpw-entry-menu-label'; labelEl.textContent = label;
            button.append(iconEl, labelEl);
            button.addEventListener('click', event => {
                event.preventDefault();
                event.stopPropagation();
                menu.open = false;
                handler(event);
            });
            return button;
        };

        if (can('vault.reveal') && !item.mfa_only) panel.appendChild(menuAction('📋', t('copy','Copier le mot de passe'), event => copySecret(item, event.currentTarget)));
        if (item.mfa_code_ready && can('vault.reveal') && ['totp','hotp'].includes(String(item.mfa_method || ''))) panel.appendChild(menuAction('🔐', 'Code 2FA', event => showMfaCode(item, event.currentTarget)));
        const hasEntryActions = (item.kind !== 'shared' && can('vault.edit')) || Boolean(item.user) || Boolean(item.url) || can('vault.qr') || (item.kind !== 'shared' && can('vault.share'));
        if (panel.childElementCount && hasEntryActions) { const separator = document.createElement('div'); separator.className = 'genpw-entry-menu-separator'; panel.appendChild(separator); }
        if (item.kind !== 'shared' && can('vault.edit')) panel.appendChild(menuAction('✏️', t('edit','Modifier'), () => startEdit(item)));
        if ((item.user || (item.kind || 'owned') !== 'shared') && can('vault.copy.user')) panel.appendChild(menuAction('ID', t('copy_user','Copier l’identifiant'), event => copyUserValues(item, event.currentTarget)));
        if (item.kind !== 'shared' && can('vault.edit')) panel.appendChild(menuAction(item.favorite?'★':'☆', item.favorite?'Retirer des favoris':'Ajouter aux favoris', async()=>{try{await api('favorite_toggle',{id:item.id});await loadList()}catch(e){toast(e.message,true)}}));
        if (item.kind !== 'shared' && can('vault.list')) panel.appendChild(menuAction('⚡','Joindre à QuickSession', async()=>{try{const r=await api('quicksession_attach',{ids:[item.id]});document.dispatchEvent(new CustomEvent('dmd:quicksession-resource-add',{detail:{module:'DMD-GenPW',resources:r.resources||[]}}));toast('Entrée jointe à la QuickSession sans secret.')}catch(e){toast(e.message,true)}}));
        if (can('vault.qr')) panel.appendChild(menuAction('QR', t('qr','QR 60 s'), () => showQr(item)));
        if (item.kind !== 'shared' && can('vault.share')) panel.appendChild(menuAction('↗', t('share','Partager'), () => openShare(item)));

        menu.addEventListener('toggle', () => {
            if (!menu.open) { panel.style.left=''; panel.style.top=''; panel.style.right=''; panel.style.bottom=''; return; }
            root.querySelectorAll('.genpw-entry-menu[open]').forEach(other => { if (other !== menu) other.open = false; });
            requestAnimationFrame(() => {
                const rect = trigger.getBoundingClientRect();
                const pr = panel.getBoundingClientRect();
                const gap = 5;
                const left = Math.max(8, Math.min(window.innerWidth - pr.width - 8, rect.right - pr.width));
                let top = rect.bottom + gap;
                if (top + pr.height > window.innerHeight - 8) top = Math.max(8, rect.top - pr.height - gap);
                panel.style.left = left + 'px'; panel.style.top = top + 'px'; panel.style.right = 'auto'; panel.style.bottom = 'auto';
            });
        });
        menu.append(trigger, panel); buttons.appendChild(menu);
        buttons.addEventListener('click', event => event.stopPropagation());
        buttons.addEventListener('pointerdown', event => event.stopPropagation());
        if (item.kind === 'shared') { const badge = document.createElement('span'); badge.className = 'genpw-share-badge'; badge.textContent = item.read_only ? t('read_only','Lecture seule') : 'Lecture + modification'; main.appendChild(badge); }
        row.append(checkbox, main, buttons);

        checkbox.addEventListener('click', event => event.stopPropagation());
        checkbox.addEventListener('change', () => row.classList.toggle('is-selected', checkbox.checked));

        if (item.kind !== 'shared' && can('vault.edit')) {
            row.draggable = true;
            row.title = 'Cliquer pour afficher les informations · Glisser vers une catégorie pour déplacer';
            row.addEventListener('dragstart', event => {
                if (event.target && event.target.closest && event.target.closest('button,input,a')) { event.preventDefault(); return; }
                const selectedIds = [...root.querySelectorAll('.genpw-select-item:checked:not(:disabled)')].map(input => input.value);
                state.dragIds = checkbox.checked && selectedIds.length ? selectedIds : [item.id];
                if (!checkbox.checked) {
                    root.querySelectorAll('.genpw-item.is-dragging').forEach(node => node.classList.remove('is-dragging'));
                }
                state.dragIds.forEach(id => { const card = root.querySelector(`.genpw-item[data-id="${id}"]`); if (card) card.classList.add('is-dragging'); });
                if (event.dataTransfer) {
                    event.dataTransfer.effectAllowed = 'move';
                    event.dataTransfer.setData('text/plain', state.dragIds.join(','));
                }
            });
            row.addEventListener('dragend', () => {
                state.suppressCardClickUntil = Date.now() + 250;
                state.dragIds = [];
                root.querySelectorAll('.genpw-item.is-dragging').forEach(node => node.classList.remove('is-dragging'));
                root.querySelectorAll('.genpw-folder.is-drop-target').forEach(node => node.classList.remove('is-drop-target'));
            });
        } else {
            row.title = 'Cliquer pour afficher les informations';
        }

        row.addEventListener('click', event => {
            if (Date.now() < state.suppressCardClickUntil) return;
            if (event.target && event.target.closest && event.target.closest('button,input,summary,a,.genpw-entry-menu')) return;
            openCredentialDetails(item);
        });
        return row;
    }

    async function moveItemsToCategory(ids, category) {
        const cleanIds = [...new Set((ids || []).map(String).filter(Boolean))];
        if (!cleanIds.length || !category) return;
        const movable = cleanIds.filter(id => {
            const item = state.items.find(candidate => candidate.id === id);
            return item && item.kind !== 'shared' && String(item.cat || 'Autre') !== String(category);
        });
        if (!movable.length) return;
        try {
            const result = await api('move_category', { ids: movable, category });
            state.openCategories.add(category);
            toast(`${result.moved || movable.length} identifiant(s) déplacé(s) vers ${categoryLabel(category)}.`);
            await loadList();
        } catch (error) { toast(error.message, true); }
    }

    function detailLine(label, value, options = {}) {
        const line = el('div','genpw-detail-line');
        const key = el('div','genpw-detail-label',label);
        const val = el('div','genpw-detail-value',value || '—');
        if (options.multiline) val.classList.add('is-multiline');
        const actions = el('div','genpw-detail-line-actions');
        if (options.copyValue !== undefined && options.copyValue !== null && String(options.copyValue) !== '') {
            const copy = el('button','genpw-btn','📋 Copier'); copy.type='button';
            copy.addEventListener('click',event=>{ event.preventDefault(); event.stopPropagation(); copyText(String(options.copyValue), copy); });
            actions.appendChild(copy);
        }
        if (typeof options.onOpen === 'function') {
            const open = el('button','genpw-btn','🌐 Ouvrir'); open.type='button';
            open.addEventListener('click',event=>{ event.preventDefault(); event.stopPropagation(); options.onOpen(event); });
            actions.appendChild(open);
        }
        line.append(key,val);
        if (actions.childElementCount) line.appendChild(actions);
        return { line, value: val, actions };
    }

    async function openCredentialDetails(item) {
        if (!credentialDetailsPanel) mountCredentialDetailsModal();
        if (credentialDetailsDialog) credentialDetailsDialog.classList.remove('is-edit-mode');
        if (credentialEditingItem) { restoreEntryPanelHome(true); credentialEditingItem = null; }
        credentialDetailsPanel.replaceChildren();
        const wrap = el('div','genpw-credential-details');
        const grid = el('div','genpw-detail-grid');
        let proMeta={field_masks:{}};
        if(item.kind!=='shared'){ try{const mr=await api('pro_meta_get',{id:item.id});proMeta=mr.meta||proMeta;}catch(_){} }
        const maskMode=(key,defaultMode='visible')=>String((proMeta.field_masks||{})[key]||defaultMode);
        const protectedLine=(label,raw,key,options={})=>{
            const mode=maskMode(key,options.sensitive?'masked':'visible');
            if(mode==='visible') return detailLine(label,raw||'—',{multiline:!!options.multiline,copyValue:raw||'',onOpen:options.onOpen||null});
            const dl=detailLine(label,'************',{multiline:false});
            dl.value.dataset.masked='1';
            const reveal=el('button','genpw-btn','👁 Afficher');reveal.type='button';
            reveal.addEventListener('click',async event=>{
                event.preventDefault();event.stopPropagation();
                if(dl.value.dataset.masked==='0'){dl.value.textContent='************';dl.value.dataset.masked='1';reveal.textContent='👁 Afficher';return;}
                try{if(mode==='confirm')await ensureSensitiveAuth();dl.value.textContent=raw||'—';dl.value.dataset.masked='0';reveal.textContent='🙈 Masquer';
                    const sec=Math.max(5,Number(PRO_SETTINGS.reveal_seconds||20));window.setTimeout(()=>{if(dl.value.dataset.masked==='0'){dl.value.textContent='************';dl.value.dataset.masked='1';reveal.textContent='👁 Afficher';}},sec*1000);
                }catch(e){toast(e.message,true)}
            });
            dl.actions.appendChild(reveal);
            if(raw){const copy=el('button','genpw-btn','📋 Copier');copy.type='button';copy.addEventListener('click',async e=>{e.preventDefault();e.stopPropagation();try{if(mode==='confirm')await ensureSensitiveAuth();await copyText(raw,copy);}catch(err){toast(err.message,true)}});dl.actions.appendChild(copy);}
            if(typeof options.onOpen==='function'){const open=el('button','genpw-btn','🌐 Ouvrir');open.type='button';open.addEventListener('click',async e=>{e.preventDefault();e.stopPropagation();try{if(mode==='confirm')await ensureSensitiveAuth();options.onOpen(e);}catch(err){toast(err.message,true)}});dl.actions.appendChild(open);}
            if(!dl.actions.parentNode)dl.line.appendChild(dl.actions);
            return dl;
        };
        grid.appendChild(detailLine('Nom', item.name || 'Sans nom', { copyValue:item.name || '' }).line);
        grid.appendChild(detailLine('Catégorie', categoryLabel(item.cat || 'Autre'), { copyValue:categoryLabel(item.cat || 'Autre') }).line);
        grid.appendChild(protectedLine('Identifiant / e-mail', item.user || '', 'user').line);
        const urlDetail = protectedLine('Adresse / URL', item.url || '', 'url', { onOpen:(event)=>{ if(item.url && can('vault.web')) openWebsite(item.url,item.name||'Site web',event.currentTarget); } });
        if (item.url && can('vault.web')) { urlDetail.value.classList.add('is-link'); }
        grid.appendChild(urlDetail.line);
        grid.appendChild(detailLine('Date', item.date || '—', { copyValue:item.date || '' }).line);
        if (item.kind === 'shared') grid.appendChild(detailLine('Partagé par', item.owner || '—', { copyValue:item.owner || '' }).line);
        if (item.notes) grid.appendChild(protectedLine('Notes', item.notes, 'notes', { multiline:true }).line);
        if (item.mfa_configured) {
            const mfaLine = detailLine('MFA / double authentification', mfaMethodLabel(item.mfa_method || 'totp') + ' · configurée');
            if (item.mfa_code_ready && can('vault.reveal') && ['totp','hotp'].includes(String(item.mfa_method || ''))) {
                const codeBtn=el('button','genpw-btn','🔐 Code 2FA'); codeBtn.type='button';
                codeBtn.addEventListener('click',event=>{ event.preventDefault(); event.stopPropagation(); showMfaCode(item,event.currentTarget); });
                mfaLine.actions.appendChild(codeBtn); if (!mfaLine.actions.parentNode) mfaLine.line.appendChild(mfaLine.actions);
            }
            grid.appendChild(mfaLine.line);
        } else grid.appendChild(detailLine('MFA / double authentification', 'Non configurée').line);
        try {
            const full = await api('entry_get', { id:item.id, kind:item.kind || 'owned' });
            (Array.isArray(full.extra_fields) ? full.extra_fields : []).forEach(field => {
                const raw = String(field.value || '');
                const isPassword = ['password','secret','pin','api_key','ssh_key'].includes(String(field.type || '').toLowerCase());
                const fieldKey='extra:'+String(field.id||field.label||field.type||'');
                const line = isPassword
                    ? detailLine(String(field.label || extraFieldLabel(field.type)), '************')
                    : protectedLine(String(field.label || extraFieldLabel(field.type)), raw, fieldKey, {
                        multiline: field.type === 'note' || field.type === 'other' || field.type === 'ssh_key',
                        onOpen: field.type === 'web' && raw && can('vault.web') ? (event)=>openWebsite(raw,String(field.label||item.name||'Site web'),event.currentTarget) : null
                    });
                if (isPassword && raw) {
                    line.value.dataset.masked='1';
                    const reveal=el('button','genpw-btn','👁 Afficher'); reveal.type='button';
                    reveal.addEventListener('click',event=>{
                        event.preventDefault(); event.stopPropagation(); const masked=line.value.dataset.masked==='1';
                        line.value.textContent=masked?raw:'************'; line.value.dataset.masked=masked?'0':'1'; reveal.textContent=masked?'🙈 Masquer':'👁 Afficher';
                        if(masked){ const sec=Math.max(5,Number(PRO_SETTINGS.reveal_seconds||20)); window.setTimeout(()=>{ if(line.value.dataset.masked==='0'){line.value.textContent='************';line.value.dataset.masked='1';reveal.textContent='👁 Afficher';}},sec*1000); }
                    });
                    const copy=el('button','genpw-btn','📋 Copier'); copy.type='button'; copy.addEventListener('click',event=>{ event.preventDefault(); event.stopPropagation(); copyText(raw,copy); });
                    line.actions.append(reveal,copy); if (!line.actions.parentNode) line.line.appendChild(line.actions);
                }
                if (field.type === 'web' && raw && can('vault.web')) line.value.classList.add('is-link');
                grid.appendChild(line.line);
            });
        } catch (_) {}

        if (!item.mfa_only) {
        const passwordDetail = detailLine('Mot de passe', '************');
        const passwordLine = passwordDetail.line;
        const passwordValue = passwordDetail.value;
        passwordValue.classList.add('is-password');
        passwordValue.dataset.masked = '1';
        const passwordActions = passwordDetail.actions;
        if (can('vault.reveal')) {
            const reveal = el('button','genpw-btn','👁 Afficher'); reveal.type='button';
            const copy = el('button','genpw-btn','📋 Copier'); copy.type='button';
            let secret = '';
            reveal.addEventListener('click', async event => {
                event.preventDefault(); event.stopPropagation();
                if (passwordValue.dataset.masked === '0') { passwordValue.textContent='************'; passwordValue.dataset.masked='1'; reveal.textContent='👁 Afficher'; secret=''; return; }
                reveal.disabled=true;
                try { secret=await getSecret(item); passwordValue.textContent=secret||'—'; passwordValue.dataset.masked='0'; reveal.textContent='🙈 Masquer';
                    const sec=Math.max(5,Number(PRO_SETTINGS.reveal_seconds||20)); window.setTimeout(()=>{if(passwordValue.dataset.masked==='0'){passwordValue.textContent='************';passwordValue.dataset.masked='1';reveal.textContent='👁 Afficher';secret='';}},sec*1000);
                }
                catch(error){ toast(error.message,true); } finally { reveal.disabled=false; }
            });
            copy.addEventListener('click', async event => {
                event.preventDefault(); event.stopPropagation(); copy.disabled=true;
                try { await copyText(secret || await getSecret(item), copy); }
                catch(error){ toast(error.message,true); } finally { copy.disabled=false; }
            });
            passwordActions.append(reveal,copy);
            passwordLine.appendChild(passwordActions);
        }
        grid.appendChild(passwordLine);
        }
        wrap.appendChild(grid);

        const actions = el('div','genpw-detail-actions');
        if (item.kind !== 'shared' && can('vault.list')) { const proBtn=el('button','genpw-btn','🛡️ Pro'); proBtn.type='button'; proBtn.addEventListener('click',()=>openEntryPro(item)); actions.appendChild(proBtn); }
        if (item.kind !== 'shared' && can('vault.edit')) { const manageMfa=el('button','genpw-btn','🔐 Gérer 2FA'); manageMfa.type='button'; manageMfa.addEventListener('click',async()=>{ await startEdit(item); if (mfaEditor) mfaEditor.open=true; if (item.mfa_configured) await loadMfaForEditing(item); }); actions.appendChild(manageMfa); }
        if (!item.read_only && can('vault.edit')) { const edit=el('button','genpw-btn is-primary','✏ Modifier'); edit.type='button'; edit.addEventListener('click',()=>startEdit(item)); actions.appendChild(edit); }
        if (actions.childElementCount) wrap.appendChild(actions);
        credentialDetailsPanel.appendChild(wrap); openCredentialDetailsModal(item.name || 'Identifiant'); makeCredentialDialogDraggable();
    }

    async function showMfaCode(item, anchor) {
        if (!item || !item.mfa_code_ready) return toast('Aucun secret TOTP/HOTP valide n’est configuré pour cette entrée.', true);
        if (anchor) anchor.disabled = true;
        try {
            const result = await api('mfa_code', { id:item.id, kind:item.kind || 'owned', advance:String(item.mfa_method || '') === 'hotp' });
            const label = result.method === 'totp' ? `Code TOTP · ${Number(result.remaining || 0)} s` : `Code HOTP · compteur ${Number(result.counter || 0)}`;
            showCredentialPopover(label, String(result.code || ''), anchor || root, true);
        } catch (error) { toast(error.message,true); }
        finally { if (anchor) anchor.disabled = false; }
    }

    async function ensureSensitiveAuth() {
        const code=window.prompt('Code MFA DoMyDesk (laisser vide pour utiliser le mot de passe de verrouillage) :')||'';
        let password='';
        if(!code) password=window.prompt('Mot de passe de verrouillage :')||'';
        await api('sensitive_reauth',{mfa_code:code,password});
    }
    async function getSecret(item) {
        try {
            const result = await api('get_secret', { id: item.id, kind: item.kind || 'owned' });
            return String(result.secret || '');
        } catch(error) {
            if(String(error && error.message || '').includes('Ré-authentification')){
                await ensureSensitiveAuth();
                const result = await api('get_secret', { id: item.id, kind: item.kind || 'owned' });
                return String(result.secret || '');
            }
            throw error;
        }
    }
    function setSecretToggleState(button, visible) {
        if (!button) return;
        const icon = button.querySelector('.genpw-entry-menu-icon');
        const label = button.querySelector('.genpw-entry-menu-label');
        const text = visible ? t('hide','Masquer') : t('reveal','Afficher');
        if (icon) icon.textContent = visible ? '🙈' : '👁';
        if (label) label.textContent = text;
        button.title = text;
    }
    async function toggleSecret(item, code, button) {
        if (code.dataset.visible === '1') { hideSecret(item.id, code, button); return; }
        if (button) button.disabled = true;
        try { const secret = await getSecret(item); code.textContent = secret; code.dataset.visible = '1'; setSecretToggleState(button, true); window.clearTimeout(state.revealTimers.get(item.id)); state.revealTimers.set(item.id, window.setTimeout(() => hideSecret(item.id, code, button), 20000)); } catch (error) { toast(error.message, true); } finally { if (button) button.disabled = false; }
    }
    function hideSecret(id, code, button) { window.clearTimeout(state.revealTimers.get(id)); state.revealTimers.delete(id); code.textContent = '••••••••••••'; code.dataset.visible = '0'; setSecretToggleState(button, false); }
    function showVisibleChoicePopover(entries, anchor, title = 'Identifiant') {
        closeCredentialPopover();
        const popover = document.createElement('div');
        popover.className = 'genpw-credential-popover';
        popover.setAttribute('role', 'dialog');
        popover.setAttribute('aria-label', title);
        popover.dataset.genpwCredentialPopover = '1';

        const head = document.createElement('div');
        head.className = 'genpw-credential-popover-head';
        const caption = document.createElement('strong');
        caption.textContent = title;
        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'genpw-credential-popover-close';
        close.textContent = '×';
        close.title = 'Fermer';
        close.addEventListener('click', event => { event.stopPropagation(); closeCredentialPopover(); });
        head.append(caption, close);

        const list = document.createElement('div');
        list.style.display = 'grid';
        list.style.gap = '4px';
        entries.forEach((entry, index) => {
            const row = document.createElement('button');
            row.type = 'button';
            row.className = 'genpw-entry-menu-action';
            row.style.gridTemplateColumns = 'minmax(0,1fr)';
            row.style.textAlign = 'left';
            row.textContent = `${index + 1} = ${entry.value}`;
            row.title = `Copier ${entry.value}`;
            row.addEventListener('click', async event => {
                event.stopPropagation();
                await copyText(String(entry.value || ''), row);
                closeCredentialPopover();
            });
            list.appendChild(row);
        });
        popover.append(head, list);
        popover.addEventListener('pointerdown', event => event.stopPropagation());
        document.body.appendChild(popover);
        credentialPopover = popover;
        positionCredentialPopover(popover, anchor);
        credentialPopoverTimer = window.setTimeout(() => {
            if (credentialPopover === popover) closeCredentialPopover();
        }, 20000);
    }

    async function copyUserValues(item, button) {
        if (button) button.disabled = true;
        try {
            const identifiers = [];
            const seen = new Set();
            const addValue = value => {
                const clean = String(value || '').trim();
                if (!clean || seen.has(clean)) return;
                seen.add(clean);
                identifiers.push({ value: clean });
            };
            addValue(item.user);
            if ((item.kind || 'owned') !== 'shared') {
                const full = await api('entry_get', { id:item.id, kind:item.kind || 'owned' });
                (Array.isArray(full.extra_fields) ? full.extra_fields : []).forEach(field => {
                    if (String(field.type || '').toLowerCase() === 'user') addValue(field.value);
                });
            }
            if (!identifiers.length) throw new Error('Aucun identifiant disponible.');
            if (identifiers.length === 1) {
                await copyText(identifiers[0].value, button);
                return;
            }
            showVisibleChoicePopover(identifiers, button || root, 'Identifiants');
        } catch (error) {
            toast(error.message, true);
        } finally {
            if (button) button.disabled = false;
        }
    }

    function showPasswordChoicePopover(entries, anchor) {
        closeCredentialPopover();

        const popover = document.createElement('div');
        popover.className = 'genpw-credential-popover';
        popover.setAttribute('role', 'dialog');
        popover.setAttribute('aria-label', 'Choisir le mot de passe à copier');
        popover.dataset.genpwCredentialPopover = '1';

        const head = document.createElement('div');
        head.className = 'genpw-credential-popover-head';
        const caption = document.createElement('strong');
        caption.textContent = 'Mot de passe';
        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'genpw-credential-popover-close';
        close.textContent = '×';
        close.title = 'Fermer';
        close.addEventListener('click', event => { event.stopPropagation(); closeCredentialPopover(); });
        head.append(caption, close);

        const list = document.createElement('div');
        list.style.display = 'grid';
        list.style.gap = '4px';

        entries.forEach(entry => {
            const row = document.createElement('button');
            row.type = 'button';
            row.className = 'genpw-entry-menu-action';
            row.style.gridTemplateColumns = 'minmax(0,1fr)';
            row.style.textAlign = 'left';
            row.textContent = `${entry.label} = ********`;
            row.title = `Copier ${entry.label}`;
            row.addEventListener('click', async event => {
                event.stopPropagation();
                await copyText(String(entry.value || ''), row);
                closeCredentialPopover();
            });
            list.appendChild(row);
        });

        popover.append(head, list);
        popover.addEventListener('pointerdown', event => event.stopPropagation());
        document.body.appendChild(popover);
        credentialPopover = popover;
        positionCredentialPopover(popover, anchor);

        credentialPopoverTimer = window.setTimeout(() => {
            if (credentialPopover === popover) closeCredentialPopover();
        }, 20000);
    }

    async function copySecret(item, button) {
        if (button) button.disabled = true;
        try {
            const passwords = [];
            const mainSecret = await getSecret(item);
            if (mainSecret !== '') passwords.push({ label: 'Mot de passe', value: mainSecret });

            if ((item.kind || 'owned') !== 'shared') {
                const full = await api('entry_get', { id: item.id, kind: item.kind || 'owned' });
                const extras = Array.isArray(full.extra_fields) ? full.extra_fields : [];
                extras.forEach(field => {
                    if (!['password','secret','pin','api_key','ssh_key'].includes(String(field.type || '').toLowerCase())) return;
                    const value = String(field.value || '');
                    if (value === '') return;
                    const label = String(field.label || 'Mot de passe').trim() || 'Mot de passe';
                    passwords.push({ label, value });
                });
            }

            if (passwords.length === 0) throw new Error('Aucun mot de passe disponible.');
            if (passwords.length === 1) {
                await copyText(passwords[0].value, button);
                return;
            }
            showPasswordChoicePopover(passwords, button || root);
        } catch (error) {
            toast(error.message, true);
        } finally {
            if (button) button.disabled = false;
        }
    }

    async function copyMfaCode(item, button) {
        if (!item || !item.mfa_code_ready) return toast('Aucun secret TOTP/HOTP valide n’est configuré pour cette entrée.', true);
        if (button) button.disabled = true;
        try {
            const result = await api('mfa_code', { id:item.id, kind:item.kind || 'owned', advance:String(item.mfa_method || '') === 'hotp' });
            await copyText(String(result.code || ''), button);
        } catch (error) {
            toast(error.message, true);
        } finally {
            if (button) button.disabled = false;
        }
    }

    let credentialPopover = null;
    let credentialPopoverTimer = null;

    function closeCredentialPopover() {
        if (credentialPopoverTimer) window.clearTimeout(credentialPopoverTimer);
        credentialPopoverTimer = null;
        if (credentialPopover) credentialPopover.remove();
        credentialPopover = null;
    }

    function positionCredentialPopover(popover, anchor) {
        if (!popover || !anchor || !anchor.isConnected) return;
        const rect = anchor.getBoundingClientRect();
        const gap = 6;
        const width = Math.min(300, Math.max(220, popover.offsetWidth || 260));
        let left = rect.right - width;
        left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
        let top = rect.bottom + gap;
        const height = popover.offsetHeight || 112;
        if (top + height > window.innerHeight - 8 && rect.top - height - gap >= 8) {
            top = rect.top - height - gap;
        }
        popover.style.left = `${Math.round(left)}px`;
        popover.style.top = `${Math.round(Math.max(8, top))}px`;
    }

    function showCredentialPopover(label, value, anchor, sensitive = false) {
        closeCredentialPopover();

        const popover = document.createElement('div');
        popover.className = 'genpw-credential-popover';
        popover.setAttribute('role', 'dialog');
        popover.setAttribute('aria-label', label);
        popover.dataset.genpwCredentialPopover = '1';

        const head = document.createElement('div');
        head.className = 'genpw-credential-popover-head';
        const caption = document.createElement('strong');
        caption.textContent = label;
        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'genpw-credential-popover-close';
        close.textContent = '×';
        close.title = 'Fermer';
        close.addEventListener('click', event => { event.stopPropagation(); closeCredentialPopover(); });
        head.append(caption, close);

        const code = document.createElement('code');
        code.className = 'genpw-credential-popover-value';
        code.textContent = String(value || '');

        const actions = document.createElement('div');
        actions.className = 'genpw-credential-popover-actions';
        const copy = document.createElement('button');
        copy.type = 'button';
        copy.className = 'genpw-credential-popover-copy';
        copy.textContent = '📋 Copier';
        copy.addEventListener('click', async event => {
            event.stopPropagation();
            await copyText(String(value || ''), event.currentTarget);
        });
        actions.appendChild(copy);

        popover.append(head, code, actions);
        popover.addEventListener('pointerdown', event => event.stopPropagation());
        document.body.appendChild(popover);
        credentialPopover = popover;
        positionCredentialPopover(popover, anchor);

        const reposition = () => {
            if (credentialPopover === popover) positionCredentialPopover(popover, anchor);
        };
        window.addEventListener('resize', reposition, { once: true });

        if (sensitive) {
            credentialPopoverTimer = window.setTimeout(() => {
                if (credentialPopover !== popover) return;
                code.textContent = '';
                closeCredentialPopover();
            }, 20000);
        }
    }

    document.addEventListener('pointerdown', event => {
        if (credentialPopover && !credentialPopover.contains(event.target)) closeCredentialPopover();
    }, true);
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') closeCredentialPopover();
    });

    function closeEntryMenus() { root.querySelectorAll('.genpw-entry-menu[open]').forEach(menu => { menu.open = false; }); }
    document.addEventListener('pointerdown', event => { if (!root.contains(event.target)) closeEntryMenus(); }, true);

    function normaliseWebUrl(rawUrl, baseUrl = window.location.href) {
        const url = new URL(rawUrl, baseUrl);
        if (!['http:', 'https:'].includes(url.protocol)) throw new Error('URL invalide ou non autorisée.');
        return url;
    }
    async function ensureWebProxyReady() {
        if (webProxyCheckedVersion === MODULE_VERSION) return true;
        let response;
        try {
            const sep = webProxyUrl.includes('?') ? '&' : '?';
            response = await fetch(`${webProxyUrl}${sep}__dmdgp_health=1&_=${Date.now()}`, {
                method: 'GET', credentials: 'same-origin', cache: 'no-store'
            });
        } catch (_) {
            throw new Error('Le navigateur intégré DMD-GenPW est introuvable. Réinstallez le module complet.');
        }
        let data = null;
        try { data = await response.json(); } catch (_) {}
        const proxyVersion = data && data.proxy_version ? String(data.proxy_version) : '';
        if (proxyVersion && proxyVersion !== MODULE_VERSION) {
            throw new Error(`Le fichier dmd-genpw_web_proxy.php n’est pas à jour (attendu ${MODULE_VERSION}, présent ${proxyVersion}). Réinstallez le module complet.`);
        }
        if (response.status === 401 || (data && data.error === 'not_authenticated')) {
            throw new Error('La session DoMyDesk n’est pas reconnue par le navigateur intégré. Rechargez DoMyDesk puis réessayez.');
        }
        if (!response.ok || !data || data.ok !== true) {
            const detail = data && data.error ? ` (${String(data.error)})` : '';
            throw new Error(`Le navigateur intégré DMD-GenPW ne répond pas correctement${detail}.`);
        }
        if (!proxyVersion) {
            throw new Error('Le navigateur intégré DMD-GenPW ne fournit pas sa version. Réinstallez le module complet.');
        }
        webProxyCheckedVersion = proxyVersion;
        return true;
    }
    async function ensureWebSession() {
        if (webSessionToken && Date.now() < (webSessionExpiresAt - 5000)) return webSessionToken;
        const result = await api('web_session');
        const token = String(result.token || '');
        if (!/^[a-f0-9]{64}$/.test(token)) throw new Error('Session de navigation DMD-GenPW invalide.');
        webSessionToken = token;
        webSessionExpiresAt = Date.now() + (Math.max(30, Number(result.expires_in || (AUTO_LOCK_MINUTES * 60))) * 1000);
        return token;
    }
    async function signedWebProxyUrl(rawUrl, mode = 'full') {
        const url = normaliseWebUrl(rawUrl);
        await ensureWebSession();
        const result = await api('web_target', { web_token: webSessionToken, url: url.href });
        const signature = String(result.signature || '');
        if (!/^[a-f0-9]{64}$/.test(signature)) throw new Error('Autorisation de navigation invalide.');
        return `${webProxyUrl}?__dmdgp_session=${encodeURIComponent(webSessionToken)}&__dmdgp_target=${encodeURIComponent(url.href)}&__dmdgp_sig=${encodeURIComponent(signature)}${mode === 'compat' ? '&__dmdgp_mode=compat' : ''}`;
    }
    function webOriginIsAllowed(next, current) {
        if (next.origin === current.origin) return true;
        return state.items.some(item => {
            if (!item || !item.url) return false;
            try { return normaliseWebUrl(item.url).origin === next.origin; } catch (_) { return false; }
        });
    }
    function renderWebTabs() {
        if (!webTabsBar) return;
        webTabsBar.replaceChildren();
        webTabs.forEach(tab => {
            const tabButton = document.createElement('button'); tabButton.type = 'button'; tabButton.className = 'genpw-web-tab'; tabButton.setAttribute('role', 'tab'); tabButton.setAttribute('aria-selected', tab.id === activeWebTabId ? 'true' : 'false');
            const label = document.createElement('span'); label.className = 'genpw-web-tab-label'; label.textContent = tab.title || tab.url.hostname || t('website','Site web');
            const close = document.createElement('span'); close.className = 'genpw-web-tab-close'; close.textContent = '×'; close.title = t('close','Fermer');
            tabButton.append(label, close);
            tabButton.addEventListener('click', event => {
                if (event.target === close) { event.stopPropagation(); closeWebTab(tab.id); return; }
                activateWebTab(tab.id);
            });
            webTabsBar.appendChild(tabButton);
        });
    }
    function activateWebTab(id) {
        activeWebTabId = id;
        webTabs.forEach(tab => { tab.frame.hidden = tab.id !== id; tab.frame.style.display = tab.id === id ? 'block' : 'none'; });
        renderWebTabs();
        const active = webTabs.find(tab => tab.id === id);
        if (active && modalTitle) modalTitle.textContent = active.title || t('website','Site web');
    }
    function closeWebTab(id) {
        const index = webTabs.findIndex(tab => tab.id === id);
        if (index < 0) return;
        const [tab] = webTabs.splice(index, 1); tab.frame.src = 'about:blank'; tab.frame.remove();
        if (!webTabs.length) { closeModal(); return; }
        if (activeWebTabId === id) activateWebTab(webTabs[Math.min(index, webTabs.length - 1)].id); else renderWebTabs();
    }
    function resetWebTabs() {
        webTabs.forEach(tab => { try { tab.frame.src = 'about:blank'; } catch (_) {} tab.frame.remove(); });
        webTabs = []; activeWebTabId = null; if (webTabsBar) webTabsBar.replaceChildren();
    }
    function tabForMessageSource(source) {
        return webTabs.find(tab => tab.frame && tab.frame.contentWindow === source) || null;
    }
    function setWebBanner(message = '') {
        let banner = webFramesHost.querySelector('[data-role=web-runtime-error]');
        if (!message) { if (banner) banner.remove(); return; }
        if (!banner) {
            banner = document.createElement('div');
            banner.className = 'genpw-web-runtime-error';
            banner.dataset.role = 'web-runtime-error';
            webFramesHost.prepend(banner);
        }
        banner.textContent = message;
    }
    async function switchWebTabToCompat(tab, reason = '') {
        if (!tab || tab.mode === 'compat' || tab.compatLoading) return;
        tab.compatLoading = true;
        try {
            setWebBanner('↻ Chargement du site en mode compatibilité…');
            const proxyUrl = await signedWebProxyUrl(tab.url.href, 'compat');
            tab.mode = 'compat';
            tab.readySeen = false;
            tab.frame.src = proxyUrl;
        } catch (error) {
            setWebBanner(`⚠ ${error && error.message ? error.message : 'Navigation intégrée indisponible.'}`);
        } finally {
            tab.compatLoading = false;
        }
    }
    async function handleWebBridgeMessage(event) {
        const data = event && event.data;
        if (!data || data.dmdGenPw !== true || typeof data.type !== 'string') return;
        const tab = tabForMessageSource(event.source);
        if (!tab) return;

        if (data.type === 'ready' || data.type === 'navigate' || data.type === 'render-state' || data.type === 'history') {
            /* Une route SPA créée par history.pushState/replaceState n'est pas forcément
               une URL réellement servie par le serveur. Elle ne doit donc jamais devenir
               l'URL réseau utilisée lors d'un rechargement de la fenêtre du site. */
            if (data.type !== 'history') {
                try {
                    const networkUrl = data.networkUrl || data.url;
                    if (networkUrl) tab.url = normaliseWebUrl(String(networkUrl), tab.url.href);
                } catch (_) {}
            }
            if (String(data.title || '').trim()) tab.title = String(data.title).trim();
            if (data.mode === 'compat' || data.mode === 'full') tab.mode = data.mode;
            if (data.type !== 'history') tab.readySeen = true;
            renderWebTabs();
            if (tab.id === activeWebTabId && modalTitle) modalTitle.textContent = tab.title || t('website','Site web');

            const visibleTextLength = Number(data.visibleTextLength || 0);
            const textLength = Number(data.textLength || 0);
            const childCount = Number(data.childCount || 0);
            if (data.type === 'render-state') {
                /* Le rendu du site reste prioritaire. On n'effectue plus de bascule automatique
                   vers un second chargement qui peut perdre le chemin courant du site. */
                if (tab.mode === 'compat' && visibleTextLength === 0 && textLength === 0 && childCount === 0) {
                    setWebBanner('⚠ Le site répond, mais il ne renvoie aucun contenu affichable dans la navigation intégrée.');
                } else {
                    setWebBanner('');
                }
            }
            return;
        }
        if (data.type === 'open-tab' || data.type === 'navigate-request') {
            try {
                const next = normaliseWebUrl(String(data.url || ''), tab.url.href);
                if (!webOriginIsAllowed(next, tab.url)) throw new Error('Destination web non autorisée : ajoutez d’abord ce site dans GenPW.');
                const proxyUrl = await signedWebProxyUrl(next.href);
                const nextTitle = String(data.title || '').trim() || next.hostname;
                const newTab = data.type === 'open-tab' || data.newTab === true;
                if (newTab) {
                    addWebTab(next.href, nextTitle, true, proxyUrl);
                } else {
                    tab.url = next;
                    if (nextTitle) tab.title = nextTitle;
                    tab.mode = 'full'; tab.readySeen = false; tab.runtimeErrors = 0;
                    setWebBanner('↻ Chargement…');
                    tab.frame.src = proxyUrl;
                    renderWebTabs();
                    if (tab.id === activeWebTabId && modalTitle) modalTitle.textContent = tab.title || t('website','Site web');
                }
            } catch (error) { toast(error && error.message ? error.message : 'URL invalide ou non autorisée.', true); }
            return;
        }
        if (data.type === 'runtime-error' && data.message) {
            tab.runtimeErrors = (tab.runtimeErrors || 0) + 1;
            /* Une erreur JS distante ne doit jamais provoquer un changement d'URL ou
               remplacer une page qui s'affiche déjà. On conserve la navigation en cours. */
            return;
        }
        if (data.type === 'error' && data.message) toast(String(data.message), true);
    }
    window.addEventListener('message', handleWebBridgeMessage, false);

    function addWebTab(rawUrl, title = '', activate = true, proxySource = '') {
        const url = normaliseWebUrl(rawUrl);
        /* DoMyDesk : une seule page web par fenêtre, aucun système d'onglets. */
        resetWebTabs();
        const id = `web_${++webTabSequence}`;
        const frame = document.createElement('iframe');
        frame.className = 'genpw-frame';
        frame.title = title || url.hostname || 'Site web';
        frame.referrerPolicy = 'no-referrer';
        frame.setAttribute('allow', 'clipboard-read; clipboard-write; fullscreen');
        /* Le contenu distant passe par le relais du module. L'iframe reste sandboxée sans
           allow-popups : un target="_blank" ne peut plus créer un onglet Brave/Chrome.
           Le pont injecté par le relais transforme ces ouvertures en onglets DMD-GenPW. */
        frame.setAttribute('sandbox', 'allow-scripts allow-forms allow-downloads allow-modals allow-pointer-lock allow-presentation');
        if (!proxySource) throw new Error('Navigation web DMD-GenPW non autorisée.');
        const tab = { id, url, title: title || url.hostname, frame, mode: proxySource.includes('__dmdgp_mode=compat') ? 'compat' : 'full', readySeen: false, runtimeErrors: 0, compatLoading: false };
        webTabs.push(tab);
        webFramesHost.appendChild(frame);
        setWebBanner('↻ Chargement…');
        frame.addEventListener('load', () => {
            window.setTimeout(() => {
                /* Ne jamais remplacer automatiquement une page déjà chargée par le mode
                   compatibilité. Certains sites modernes déclenchent leur pont tardivement :
                   l'ancien fallback pouvait alors recharger une URL intermédiaire et afficher
                   un faux 404 alors que le site était correctement visible. */
                if (!tab.readySeen) setWebBanner('');
            }, 1800);
        });
        frame.src = proxySource;
        if (activate) activateWebTab(id); else { frame.hidden = true; frame.style.display = 'none'; renderWebTabs(); }
        return tab;
    }

    function openModal(title, mode) {
        const showWebsite = mode === 'web', showQr = mode === 'qr', showPanel = mode === 'panel';
        modalTitle.textContent = title; modalDialog.classList.toggle('is-qr', showQr); modalDialog.classList.toggle('is-panel', showPanel);
        webBrowser.hidden = !showWebsite; webBrowser.style.display = showWebsite ? 'flex' : 'none';
        qrImage.hidden = !showQr; qrImage.style.display = showQr ? 'block' : 'none';
        modalPanel.hidden = !showPanel; modalPanel.style.display = showPanel ? 'block' : 'none';

        modalDialog.hidden = false;
        modalDialog.setAttribute('aria-hidden', 'false');
        /* registerPopup installe le bring-to-front sur pointerdown. On le déclenche
           à l'ouverture, sans écraser les z-index du dashboard ou des autres modules. */
        try { modalDialog.dispatchEvent(new Event('pointerdown', { bubbles: true })); } catch (_) {}
        /* Si DoMyDesk a portalé la popup dans le workspace, on n'affiche surtout pas
           l'ancien overlay vide. Sinon on garde le fallback centré classique. */
        const managedByWorkspace = modalDialog.dataset.dmdWindowManaged === '1' || modalDialog.parentElement !== modal;
        modal.hidden = managedByWorkspace;
        modal.setAttribute('aria-hidden', managedByWorkspace ? 'true' : 'false');
    }
    function closeModal() {
        if (mfaImportCameraStream) {
            try { mfaImportCameraStream.getTracks().forEach(track => track.stop()); } catch (_) {}
            mfaImportCameraStream = null;
        }
        modal.hidden = true;
        modal.setAttribute('aria-hidden', 'true');
        modalDialog.hidden = true;
        modalDialog.setAttribute('aria-hidden', 'true');
        webBrowser.hidden = true; webBrowser.style.display = 'none'; resetWebTabs(); qrImage.hidden = true; qrImage.style.display = 'none'; qrImage.removeAttribute('src'); modalPanel.hidden = true; modalPanel.style.display = 'none'; modalPanel.replaceChildren(); modalDialog.classList.remove('is-qr','is-panel','is-category-manager','is-credential-details');
    }
    function myDeskNativeBridge() {
        try {
            if (window.chrome && window.chrome.webview && typeof window.chrome.webview.postMessage === 'function') {
                return window.chrome.webview;
            }
        } catch (_) {}
        return null;
    }

    function openWebsiteNative(rawUrl, title = '') {
        const url = normaliseWebUrl(rawUrl);
        const label = title || url.hostname || t('website','Site web');
        const requestId = 'dmdgp-web-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 9);
        const detail = {
            type: 'dmd:mydesk-webview-open',
            version: 1,
            requestId,
            module: 'DMD-GenPW',
            command: 'webview.open',
            action: 'browser.open',
            url: url.href,
            title: label,
            target: 'integrated',
            newWindow: true
        };

        // VRAI pont JavaScript -> hôte WebView2. On ne fait plus passer le site
        // distant par le proxy PHP quand DMD-GenPW tourne dans DMD-MyDesk.
        const bridge = myDeskNativeBridge();
        if (bridge) {
            bridge.postMessage(detail);
            return true;
        }

        // Compatibilité avec un shell MyDesk qui relaie les commandes depuis la page
        // par postMessage/CustomEvent plutôt que directement par chrome.webview.
        let relayed = false;
        try {
            if (window.parent && window.parent !== window) {
                window.parent.postMessage(detail, '*');
                relayed = true;
            }
        } catch (_) {}
        try {
            if (window.opener && !window.opener.closed) {
                window.opener.postMessage(detail, '*');
                relayed = true;
            }
        } catch (_) {}
        try {
            window.dispatchEvent(new CustomEvent('dmd:mydesk-webview-open', { detail }));
            relayed = true;
        } catch (_) {}

        // Si le shell n'expose pas directement chrome.webview, on envoie tout de
        // même l'événement de compatibilité puis on utilise NewWindowRequested. Dans
        // WebView2 ce window.open est interceptable par l'hôte ; dans un navigateur
        // classique il ouvre simplement un nouvel onglet, mais jamais le proxy PHP.
        const opened = window.open(url.href, '_blank', 'noopener,noreferrer');
        if (!opened) throw new Error('Impossible d’ouvrir le site.');
        return true;
    }

    function isNativeMyDeskWebView2() {
        return !!myDeskNativeBridge();
    }

    async function openWebsiteInternal(rawUrl, title) {
        try {
            const url = normaliseWebUrl(rawUrl);

            /* MyDesk conserve son comportement natif existant. */
            if (isNativeMyDeskWebView2()) {
                openWebsiteNative(url.href, title || url.hostname || t('website','Site web'));
                return;
            }
            if (MYDESK_FULL) {
                openWebsiteNative(url.href, title || url.hostname || t('website','Site web'));
                return;
            }

            /* DoMyDesk : charge directement le site dans la fenêtre web du dashboard.
               Cela conserve le rendu, les polices, les formulaires, cookies et
               redirections du site exactement comme dans le navigateur. */
            const webAlreadyOpen = modalDialog && !modalDialog.hidden && webBrowser && !webBrowser.hidden;
            if (!webAlreadyOpen) resetWebTabs();
            addWebTab(url.href, title || url.hostname || t('website','Site web'), true, url.href);
            openModal(title || t('website','Site web'), 'web');
        } catch (error) {
            toast(error && error.message ? error.message : 'URL invalide ou non autorisée.', true);
        }
    }

    function openWebsiteExternal(rawUrl) {
        try {
            const url = normaliseWebUrl(rawUrl);
            const opened = window.open(url.href, '_blank', 'noopener,noreferrer');
            if (!opened) throw new Error('La nouvelle fenêtre a été bloquée par le navigateur.');
        } catch (error) {
            toast(error && error.message ? error.message : 'Impossible d’ouvrir le lien.', true);
        }
    }

    function closeWebOpenChoice() {
        document.querySelectorAll('.genpw-web-choice-popover[data-genpw-owner="' + root.id + '"]').forEach(node => node.remove());
    }

    function openWebsite(rawUrl, title, anchor = null) {
        try {
            const url = normaliseWebUrl(rawUrl);
            const label = title || url.hostname || t('website','Site web');
            closeWebOpenChoice();

            const popover = el('div', 'genpw-web-choice-popover');
            popover.dataset.genpwOwner = root.id;
            popover.setAttribute('role', 'menu');
            popover.setAttribute('aria-label', 'Ouvrir le lien');

            const internalBtn = el('button', 'genpw-web-choice-action', '🖥️  Ouvrir dans DoMyDesk');
            internalBtn.type = 'button';
            internalBtn.setAttribute('role', 'menuitem');
            internalBtn.addEventListener('click', async event => {
                event.preventDefault();
                event.stopPropagation();
                closeWebOpenChoice();
                await openWebsiteInternal(url.href, label);
            });

            const externalBtn = el('button', 'genpw-web-choice-action', '↗  Ouvrir dans une nouvelle fenêtre');
            externalBtn.type = 'button';
            externalBtn.setAttribute('role', 'menuitem');
            externalBtn.addEventListener('click', event => {
                event.preventDefault();
                event.stopPropagation();
                closeWebOpenChoice();
                openWebsiteExternal(url.href);
            });

            popover.append(internalBtn, externalBtn);
            document.body.appendChild(popover);

            const rect = anchor && typeof anchor.getBoundingClientRect === 'function'
                ? anchor.getBoundingClientRect()
                : { left: Math.max(8, window.innerWidth / 2 - 120), right: Math.max(8, window.innerWidth / 2 + 120), top: Math.max(8, window.innerHeight / 2), bottom: Math.max(8, window.innerHeight / 2) };

            const pr = popover.getBoundingClientRect();
            const gap = 5;
            const left = Math.max(8, Math.min(window.innerWidth - pr.width - 8, rect.right - pr.width));
            let top = rect.bottom + gap;
            if (top + pr.height > window.innerHeight - 8) top = Math.max(8, rect.top - pr.height - gap);
            popover.style.left = left + 'px';
            popover.style.top = top + 'px';

            const dismiss = event => {
                if (!popover.contains(event.target) && event.target !== anchor) {
                    closeWebOpenChoice();
                    document.removeEventListener('pointerdown', dismiss, true);
                }
            };
            window.setTimeout(() => document.addEventListener('pointerdown', dismiss, true), 0);
        } catch (error) {
            toast(error && error.message ? error.message : 'URL invalide ou non autorisée.', true);
        }
    }
    async function showQr(item) {
        try { const result = await api('get_qr', { id: item.id, kind: item.kind || 'owned' }); qrImage.src = `${qrUrl}?t=${encodeURIComponent(result.token)}&_=${Date.now()}`; openModal(`QR · ${item.name || ''}`, 'qr'); } catch (error) { toast(error.message, true); }
    }

    function el(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; }
    async function openCategoryManager() {
        try {
            const result = await loadCategories();
            const custom = Array.isArray(result.custom) ? result.custom : [];
            const defaults = Array.isArray(result.defaults) ? result.defaults : state.defaultCategories;
            const wrap = el('div','genpw-category-manager');

            if (can('vault.create')) {
                const creator = el('div','genpw-category-create');
                const input = document.createElement('input');
                input.type = 'text'; input.maxLength = 40; input.className = 'genpw-input'; input.placeholder = t('category_new','Nouvelle catégorie'); input.autocomplete = 'off';
                const add = el('button','genpw-btn is-primary','＋ ' + t('category_add','Ajouter')); add.type = 'button';
                const create = async () => {
                    const name = input.value.trim(); if (!name) return input.focus();
                    add.disabled = true;
                    try {
                        const created = await api('category_create',{name});
                        applyCategoryPayload(created, created.name || name);
                        toast(t('category_created','Catégorie créée.'));
                        await loadList();
                        closeModal(); await openCategoryManager();
                    } catch (error) { toast(error.message,true); } finally { add.disabled = false; }
                };
                add.addEventListener('click',create); input.addEventListener('keydown',event=>{ if(event.key==='Enter') create(); });
                creator.append(input,add); wrap.appendChild(creator);
            }

            const list = el('div','genpw-category-list');
            const managed = [...new Set([...(defaults || []), ...(custom || [])])];
            managed.forEach(category => {
                const row = el('div','genpw-category-row');
                const input = document.createElement('input');
                input.type='text'; input.maxLength=40; input.className='genpw-input genpw-category-edit'; input.value=category; input.autocomplete='off';
                const actions = el('div','genpw-category-actions');
                if (can('vault.edit')) {
                    const rename = el('button','genpw-btn','✎ ' + t('category_rename','Renommer')); rename.type='button';
                    rename.addEventListener('click',async()=>{
                        const name=input.value.trim(); if(!name || name===category) return; rename.disabled=true;
                        try {
                            const changed=await api('category_rename',{old_name:category,name});
                            applyCategoryPayload(changed,name);
                            toast(t('category_renamed','Catégorie renommée.'));
                            await loadList(); closeModal(); await openCategoryManager();
                        } catch(error){toast(error.message,true)} finally{rename.disabled=false}
                    });
                    const del = el('button','genpw-btn is-danger','🗑 ' + t('category_delete','Supprimer')); del.type='button';
                    del.addEventListener('click',async()=>{
                        if(!window.confirm(t('category_delete_confirm','Supprimer cette catégorie ? Les identifiants qu’elle contient seront déplacés dans une autre catégorie.'))) return;
                        del.disabled=true;
                        try {
                            const changed=await api('category_delete',{name:category});
                            const fallback = changed && changed.result && changed.result.fallback ? changed.result.fallback : '';
                            applyCategoryPayload(changed,fallback);
                            toast(t('category_deleted','Catégorie supprimée.'));
                            await loadList(); closeModal(); await openCategoryManager();
                        } catch(error){toast(error.message,true)} finally{del.disabled=false}
                    });
                    actions.append(rename,del);
                }
                row.append(input,actions); list.appendChild(row);
            });
            wrap.appendChild(list);
            modalPanel.replaceChildren(wrap);
            openModal('📂 ' + t('categories','Catégories'),'panel');
            modalDialog.classList.add('is-category-manager');
        } catch (error) { toast(error.message,true); }
    }
    async function openShare(item) {
        try {
            const [usersResult, sharesResult, publicResult] = await Promise.all([
                api('share_users'),
                api('shares', { id: item.id }),
                api('public_shares', { id: item.id })
            ]);
            const users = Array.isArray(usersResult.users) ? usersResult.users : [];
            const shares = Array.isArray(sharesResult.shares) ? sharesResult.shares : [];
            const publicShares = Array.isArray(publicResult.shares) ? publicResult.shares : [];
            const wrap = el('div','genpw-panel-stack');
            const recipients = el('div','genpw-recipient-list');
            users.forEach(user => {
                const label = el('label','genpw-check'); const input = document.createElement('input'); input.type = 'checkbox'; input.value = user.email; label.append(input, document.createTextNode(` ${user.name || user.email} · ${user.email}`)); recipients.appendChild(label);
            });
            wrap.appendChild(el('strong','',t('recipients','Destinataires'))); wrap.appendChild(recipients);
            const shareOptions=el('div','genpw-form-grid');
            const modeSel=document.createElement('select'); modeSel.className='genpw-select';
            [['read','Lecture seule'],['write','Lecture + modification']].forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;modeSel.appendChild(o);});
            const expiry=document.createElement('input'); expiry.className='genpw-input'; expiry.type='number'; expiry.min='0'; expiry.max='525600'; expiry.value='1440';
            shareOptions.append(formField('Droit de partage',modeSel),formField('Expiration (minutes, 0 = aucune)',expiry));
            wrap.appendChild(shareOptions);
            const send = el('button','genpw-btn is-primary','↗ ' + t('share','Partager')); send.type = 'button'; send.addEventListener('click', async () => {
                const selected = [...recipients.querySelectorAll('input:checked')].map(input => input.value); if (!selected.length) return toast('Aucun destinataire sélectionné.', true);
                try { const result = await api('share', { id: item.id, recipients: selected, mode:modeSel.value, expires_minutes:Number(expiry.value||0) }); toast(`${result.shared_with ? result.shared_with.length : 0} partage(s).`); closeModal(); } catch (error) { toast(error.message, true); }
            });
            wrap.appendChild(send);
            wrap.appendChild(el('strong','genpw-panel-separator','Lien temporaire externe'));
            const publicBox=el('div','genpw-panel-stack');
            const durationSel=document.createElement('select'); durationSel.className='genpw-select';
            [['1h','1 heure'],['2h','2 heures'],['8h','8 heures'],['24h','24 heures'],['7d','7 jours'],['14d','14 jours'],['once','Une seule ouverture']].forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;durationSel.appendChild(o);});
            const pin=document.createElement('input'); pin.className='genpw-input'; pin.type='text'; pin.inputMode='numeric'; pin.maxLength=12; pin.placeholder='PIN optionnel (4 à 12 chiffres)';
            const pubGrid=el('div','genpw-form-grid');
            pubGrid.append(formField('Durée du lien',durationSel),formField('Protection PIN',pin));
            publicBox.appendChild(pubGrid);

            const fieldsWrap=el('div','genpw-share-all-fields','Toute la fiche sera partagée : champs principaux, MFA et tous les champs ajoutés manuellement.');
            publicBox.appendChild(fieldsWrap);

            const createLink=el('button','genpw-btn is-primary','🔗 Créer le lien temporaire'); createLink.type='button';
            createLink.addEventListener('click',async()=>{
                createLink.disabled=true;
                try{
                    const result=await api('public_share_create',{id:item.id,duration:durationSel.value,pin:pin.value});
                    const publicPath=apiUrl.replace(/dmd-genpw_api\.php(?:\?.*)?$/,'dmd-genpw_public_share.php');
                    const link=result.url ? new URL(result.url,window.location.href) : new URL(publicPath,window.location.href);
                    if(!result.url) link.searchParams.set('t',result.token);
                    const previous=publicBox.querySelector('.genpw-share-created');
                    if(previous) previous.remove();

                    const out=el('div','genpw-share-created');
                    const label=el('strong','genpw-share-created-title','Lien temporaire créé');
                    const row=el('div','genpw-share-created-row');

                    const urlField=document.createElement('input');
                    urlField.type='text';
                    urlField.readOnly=true;
                    urlField.className='genpw-input genpw-share-created-url';
                    urlField.value=link.href;
                    urlField.title=link.href;
                    urlField.addEventListener('click',()=>urlField.select());

                    const copy=el('button','genpw-btn is-primary','📋 Copier');
                    copy.type='button';
                    copy.addEventListener('click',()=>copyText(link.href,copy));

                    row.append(urlField,copy);
                    out.append(label,row);
                    publicBox.appendChild(out);
                    toast('Lien temporaire créé.');
                }catch(error){toast(error.message,true)}
                finally{createLink.disabled=false}
            });
            publicBox.appendChild(createLink);

            if(publicShares.length){
                const list=el('div','genpw-share-list');
                publicShares.forEach(share=>{
                    const active=!share.revoked_at && (!share.one_time || !share.used_at);
                    const info=[
                        share.one_time?'une seule ouverture':(share.expires_at?('expire '+share.expires_at):'sans expiration'),
                        share.pin?'PIN':'sans PIN',
                        share.used_at?('utilisé '+share.used_at):'',
                        share.revoked_at?'révoqué':''
                    ].filter(Boolean).join(' · ');
                    const line=el('div','genpw-share-line');
                    line.appendChild(el('span','',info));
                    if(active && can('vault.revoke')){
                        const revoke=el('button','genpw-btn is-danger','Révoquer'); revoke.type='button';
                        revoke.addEventListener('click',async()=>{
                            if(!window.confirm('Révoquer ce lien temporaire ?'))return;
                            try{await api('public_share_revoke',{share_id:share.share_id});line.remove();toast('Lien révoqué.')}catch(error){toast(error.message,true)}
                        });
                        line.appendChild(revoke);
                    }
                    list.appendChild(line);
                });
                publicBox.appendChild(list);
            }
            wrap.appendChild(publicBox);

            if (shares.length) {
                wrap.appendChild(el('strong','genpw-panel-separator',t('shares','Partages')));
                const current = el('div','genpw-share-list');
                shares.forEach(share => {
                    const info=[share.recipient || '', share.mode==='write'?'lecture+modification':'lecture seule', share.expires_at?('expire '+share.expires_at):'sans expiration'].filter(Boolean).join(' · ');
                    const line = el('div','genpw-share-line'); line.appendChild(el('span','',info));
                    if (can('vault.revoke')) { const revoke = el('button','genpw-btn is-danger',t('revoke','Retirer')); revoke.type='button'; revoke.addEventListener('click', async () => { if (!window.confirm(t('confirm_revoke','Retirer ce partage ?'))) return; try { await api('revoke_share',{share_id:share.share_id}); line.remove(); toast(t('revoke','Retiré')); } catch(error){ toast(error.message,true); } }); line.appendChild(revoke); }
                    current.appendChild(line);
                });
                wrap.appendChild(current);
            }
            modalPanel.appendChild(wrap); openModal(`${t('share','Partager')} · ${item.name}`, 'panel');
        } catch (error) { toast(error.message, true); }
    }

    function downloadPayload(result) {
        const binary = atob(result.content || ''); const bytes = new Uint8Array(binary.length); for (let i=0;i<binary.length;i++) bytes[i] = binary.charCodeAt(i);
        const blob = new Blob([bytes], { type: result.mime || 'application/octet-stream' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = result.filename || 'DMD-GenPW-export'; document.body.appendChild(a); a.click(); a.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    async function uploadImport(file, source, skipExisting, button) {
        if (!file) return toast('Sélectionnez un fichier à importer.', true);
        if (button) button.disabled = true;
        try {
            const previewForm = new FormData();
            previewForm.append('action', 'import_preview');
            previewForm.append('source', source || 'auto');
            previewForm.append('file', file, file.name);
            const previewResponse = await fetch(apiUrl, { method:'POST', credentials:'same-origin', cache:'no-store', headers:{'X-CSRF-Token':csrf}, body:previewForm });
            let preview; try { preview=await previewResponse.json(); } catch (_) { throw new Error('Prévisualisation import invalide.'); }
            if(!previewResponse.ok || preview.ok===false) throw new Error(preview.error || 'Prévisualisation impossible.');
            const sample=(preview.sample||[]).map(x=>`${x.duplicate?'⧉ ':'• '}${x.name}${x.user?' · '+x.user:''}`).join('\n');
            const msg=`${preview.source||'Import'}\n${preview.valid||0} entrée(s) valide(s)\n${preview.duplicates||0} doublon(s) détecté(s)\n${preview.unsupported||0} élément(s) non pris en charge${sample?'\n\nAperçu :\n'+sample:''}\n\nLancer l’import ?`;
            if(!window.confirm(msg)) return;

            const form = new FormData();
            form.append('action', 'import');
            form.append('source', source || 'auto');
            form.append('skip_existing', skipExisting ? '1' : '0');
            form.append('file', file, file.name);
            const response = await fetch(apiUrl, { method:'POST', credentials:'same-origin', cache:'no-store', headers:{'X-CSRF-Token':csrf}, body:form });
            let data; try { data = await response.json(); } catch (_) { throw new Error('Réponse serveur invalide (' + response.status + ').'); }
            if (!response.ok || data.error || data.ok === false) { if (data.locked || response.status === 423) setLocked(); throw new Error(data.error || 'Import impossible.'); }
            emitActivity(data);
            await loadList();
            const parts = [`${data.imported || 0} importée(s)`];
            if (data.duplicates) parts.push(`${data.duplicates} doublon(s) ignoré(s)`);
            if (data.unsupported) parts.push(`${data.unsupported} élément(s) sans secret exploitable`);
            if (data.invalid) parts.push(`${data.invalid} entrée(s) invalide(s)`);
            toast(`${data.source || 'Import'} · ${parts.join(' · ')}`);
            closeModal();
        } catch (error) { toast(error.message, true); } finally { if (button) button.disabled = false; }
    }
    function mfaBytesToBase32(bytes) {
        const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        let bits=0,value=0,out='';
        for (const byte of bytes) {
            value=(value<<8)|byte; bits+=8;
            while(bits>=5){ out+=alphabet[(value>>>(bits-5))&31]; bits-=5; }
        }
        if(bits>0) out+=alphabet[(value<<(5-bits))&31];
        return out;
    }
    function mfaBase64ToBytes(value) {
        let base64=String(value||'').trim().replace(/-/g,'+').replace(/_/g,'/').replace(/ /g,'+');
        while(base64.length%4) base64+='=';
        const raw=atob(base64); const bytes=new Uint8Array(raw.length);
        for(let i=0;i<raw.length;i++) bytes[i]=raw.charCodeAt(i);
        return bytes;
    }
    function mfaReadVarint(bytes,state) {
        let value=0,mult=1,count=0;
        while(state.i<bytes.length && count<10){ const b=bytes[state.i++]; value+=(b&0x7f)*mult; if((b&0x80)===0)return value; mult*=128; count++; }
        throw new Error('Données Google Authenticator invalides.');
    }
    function mfaReadBytes(bytes,state) {
        const length=mfaReadVarint(bytes,state); const end=state.i+length;
        if(length<0 || end>bytes.length) throw new Error('Données MFA tronquées.');
        const out=bytes.slice(state.i,end); state.i=end; return out;
    }
    function mfaSkipProto(bytes,state,wire) {
        if(wire===0){mfaReadVarint(bytes,state);return;}
        if(wire===1){state.i+=8;return;}
        if(wire===2){const n=mfaReadVarint(bytes,state);state.i+=n;return;}
        if(wire===5){state.i+=4;return;}
        throw new Error('Format protobuf MFA non pris en charge.');
    }
    function mfaDecodeText(bytes){ return new TextDecoder('utf-8',{fatal:false}).decode(bytes); }
    function mfaSplitName(name,issuer) {
        name=String(name||'').trim(); issuer=String(issuer||'').trim(); let account=name;
        if(name.includes(':')){
            const pos=name.indexOf(':'); const prefix=name.slice(0,pos).trim(); const rest=name.slice(pos+1).trim();
            if(!issuer) issuer=prefix;
            if(!issuer || prefix.toLocaleLowerCase()===issuer.toLocaleLowerCase()) account=rest;
        }
        return {issuer,account:account||name};
    }
    function mfaParseGoogleOtpParameter(bytes) {
        const state={i:0}; let secret=null,name='',issuer='',algorithm=1,digits=1,type=2,counter=0;
        while(state.i<bytes.length){
            const key=mfaReadVarint(bytes,state),field=Math.floor(key/8),wire=key&7;
            if(field===1&&wire===2) secret=mfaReadBytes(bytes,state);
            else if(field===2&&wire===2) name=mfaDecodeText(mfaReadBytes(bytes,state));
            else if(field===3&&wire===2) issuer=mfaDecodeText(mfaReadBytes(bytes,state));
            else if(field===4&&wire===0) algorithm=mfaReadVarint(bytes,state);
            else if(field===5&&wire===0) digits=mfaReadVarint(bytes,state);
            else if(field===6&&wire===0) type=mfaReadVarint(bytes,state);
            else if(field===7&&wire===0) counter=mfaReadVarint(bytes,state);
            else mfaSkipProto(bytes,state,wire);
        }
        if(!secret || !secret.length) throw new Error('Secret absent du transfert Google Authenticator.');
        if(![0,1,2,3].includes(algorithm)) throw new Error('Algorithme MFA non pris en charge dans ce transfert.');
        const labels=mfaSplitName(name,issuer);
        return {
            method:type===1?'hotp':'totp',source:mfaBytesToBase32(secret),encoding:'base32',
            algorithm:algorithm===2?'SHA256':(algorithm===3?'SHA512':'SHA1'),digits:digits===2?8:6,period:30,counter:Number(counter||0),
            issuer:labels.issuer,account:labels.account,recovery_codes:'',notes:'Import Google Authenticator'
        };
    }
    function mfaParseGoogleMigration(uri) {
        const url=new URL(String(uri||'').trim());
        if(url.protocol!=='otpauth-migration:') throw new Error('QR de migration Google invalide.');
        const data=url.searchParams.get('data'); if(!data) throw new Error('Données absentes du QR Google Authenticator.');
        const bytes=mfaBase64ToBytes(data),state={i:0},items=[]; let batchSize=1,batchIndex=0,batchId=0;
        while(state.i<bytes.length){
            const key=mfaReadVarint(bytes,state),field=Math.floor(key/8),wire=key&7;
            if(field===1&&wire===2) items.push(mfaParseGoogleOtpParameter(mfaReadBytes(bytes,state)));
            else if(field===3&&wire===0) batchSize=mfaReadVarint(bytes,state);
            else if(field===4&&wire===0) batchIndex=mfaReadVarint(bytes,state);
            else if(field===5&&wire===0) batchId=mfaReadVarint(bytes,state);
            else mfaSkipProto(bytes,state,wire);
        }
        return {items,batchSize:Number(batchSize||1),batchIndex:Number(batchIndex||0),batchId:Number(batchId||0)};
    }
    function mfaParseOtpAuth(uri) {
        const url=new URL(String(uri||'').trim());
        if(url.protocol!=='otpauth:') throw new Error('URI otpauth invalide.');
        const method=String(url.hostname||'').toLowerCase(); if(!['totp','hotp'].includes(method)) throw new Error('Type OTP non pris en charge.');
        const secret=String(url.searchParams.get('secret')||'').replace(/\s+/g,'').toUpperCase(); if(!secret) throw new Error('Secret absent de l’URI otpauth.');
        let label=decodeURIComponent(String(url.pathname||'').replace(/^\//,''));
        const issuer=String(url.searchParams.get('issuer')||'').trim(); const labels=mfaSplitName(label,issuer);
        const algorithm=String(url.searchParams.get('algorithm')||'SHA1').toUpperCase();
        if(!['SHA1','SHA256','SHA512'].includes(algorithm)) throw new Error(`Algorithme ${algorithm} non pris en charge.`);
        return {method,source:secret,encoding:'base32',algorithm,digits:Number(url.searchParams.get('digits')||6),period:Number(url.searchParams.get('period')||30),counter:Number(url.searchParams.get('counter')||0),issuer:labels.issuer,account:labels.account,recovery_codes:'',notes:'Import URI otpauth'};
    }
    function mfaNormalizeGeneric(row,sourceName='Import MFA') {
        if(!row || typeof row!=='object') return null;
        const info=row.info&&typeof row.info==='object'?row.info:{};
        const otp=row.otp&&typeof row.otp==='object'?row.otp:{};
        const directUri=String(row.otpauth_uri||row.uri||row.link||otp.link||'').trim();
        if(directUri.startsWith('otpauth://')) return mfaParseOtpAuth(directUri);
        const secret=String(row.secret||info.secret||otp.secret||'').replace(/\s+/g,'').trim(); if(!secret) return null;
        let method=String(row.type||row.method||info.type||otp.type||otp.tokenType||'totp').toLowerCase();
        method=method.includes('hotp')?'hotp':'totp';
        const issuer=String(row.issuer||otp.issuer||row.service||row.serviceName||'').trim();
        const account=String(row.account||otp.account||otp.label||row.label||row.name||'').trim();
        let algorithm=String(row.algorithm||row.algo||info.algo||otp.algorithm||'SHA1').toUpperCase().replace('-','');
        if(!['SHA1','SHA256','SHA512'].includes(algorithm)) algorithm='SHA1';
        return {method,source:secret,encoding:'base32',algorithm,digits:Number(row.digits||info.digits||otp.digits||6),period:Number(row.period||info.period||otp.period||30),counter:Number(row.counter||info.counter||otp.counter||0),issuer,account,recovery_codes:'',notes:`Import ${sourceName}`};
    }
    function mfaParseJsonExport(data) {
        const items=[]; let source='JSON MFA';
        if(data && typeof data==='object' && data.db && typeof data.db==='string') throw new Error('Ce coffre Aegis est chiffré. Exportez une copie non chiffrée pour la migration.');
        if(data && typeof data==='object' && data.db && typeof data.db==='object' && Array.isArray(data.db.entries)) {
            source='Aegis';
            data.db.entries.forEach(row=>{ if(!['totp','hotp'].includes(String(row.type||'').toLowerCase())) return; const v=mfaNormalizeGeneric(row,source); if(v)items.push(v); });
            return {items,source};
        }
        if(data && typeof data==='object' && Array.isArray(data.services)) {
            source='2FAS';
            data.services.forEach(row=>{ const v=mfaNormalizeGeneric(row,source); if(v)items.push(v); });
            return {items,source};
        }
        const candidates=Array.isArray(data)?data:(Array.isArray(data?.entries)?data.entries:(Array.isArray(data?.items)?data.items:[]));
        if(candidates.length){ candidates.forEach(row=>{const v=mfaNormalizeGeneric(row,source);if(v)items.push(v);}); return {items,source}; }
        const single=mfaNormalizeGeneric(data,source); if(single) items.push(single);
        return {items,source};
    }
    function mfaCsvRows(text) {
        const rows=[];let row=[],field='',quoted=false;const src=String(text||'');
        for(let i=0;i<src.length;i++){const c=src[i];if(quoted){if(c==='"'&&src[i+1]==='"'){field+='"';i++;}else if(c==='"')quoted=false;else field+=c;}else{if(c==='"')quoted=true;else if(c===','){row.push(field);field='';}else if(c==='\n'){row.push(field.replace(/\r$/,''));rows.push(row);row=[];field='';}else field+=c;}}
        if(field!==''||row.length){row.push(field.replace(/\r$/,''));rows.push(row);} return rows;
    }
    function mfaParseTextExport(text) {
        const raw=String(text||'').trim(); if(!raw) return {items:[],source:'Texte MFA'};
        try { return mfaParseJsonExport(JSON.parse(raw)); } catch(error) { if(raw.startsWith('{')||raw.startsWith('[')) throw error; }
        const uris=raw.match(/otpauth(?:-migration)?:\/\/[^\s<>'"]+/gi)||[]; const items=[]; let google=false;
        uris.forEach(uri=>{
            try {
                if(uri.toLowerCase().startsWith('otpauth-migration://')) { const parsed=mfaParseGoogleMigration(uri); items.push(...parsed.items); google=true; }
                else items.push(mfaParseOtpAuth(uri));
            } catch(_) {}
        });
        if(!items.length && raw.toLowerCase().startsWith('otpauth://')) items.push(mfaParseOtpAuth(raw));
        if(!items.length && raw.toLowerCase().startsWith('otpauth-migration://')) { const parsed=mfaParseGoogleMigration(raw); items.push(...parsed.items); google=true; }

        /* CSV générique : repère les colonnes usuelles d'exports MFA sans
           imposer un fournisseur particulier. */
        if(!items.length && /[,;\t]/.test(raw) && /\r?\n/.test(raw)) {
            const delim=(raw.split('\n',1)[0].match(/;/g)||[]).length>(raw.split('\n',1)[0].match(/,/g)||[]).length?';':',';
            const rows=raw.split(/\r?\n/).filter(Boolean).map(line=>{
                const out=[];let cur='',q=false;
                for(let i=0;i<line.length;i++){const c=line[i];if(c==='\"'){if(q&&line[i+1]==='\"'){cur+='\"';i++;}else q=!q;}else if(c===delim&&!q){out.push(cur);cur='';}else cur+=c;}out.push(cur);return out;
            });
            if(rows.length>1){
                const head=rows[0].map(v=>String(v||'').trim().toLowerCase());
                const idx=(names)=>{for(const n of names){const i=head.indexOf(n);if(i>=0)return i;}return -1;};
                const iSecret=idx(['secret','otp_secret','totp_secret','oath_secret_key','key','seed']);
                const iUri=idx(['otpauth','otpauth_uri','uri']);
                const iIssuer=idx(['issuer','service','provider','name']);
                const iAccount=idx(['account','username','email','login']);
                const iType=idx(['type','method']);
                const iAlgo=idx(['algorithm','algo']);
                const iDigits=idx(['digits']);
                const iPeriod=idx(['period']);
                const iCounter=idx(['counter']);
                for(const row of rows.slice(1)){
                    try{
                        const uri=iUri>=0?String(row[iUri]||'').trim():'';
                        if(uri.toLowerCase().startsWith('otpauth://')){items.push(mfaParseOtpAuth(uri));continue;}
                        const secret=iSecret>=0?String(row[iSecret]||'').replace(/[\s-]+/g,'').trim():'';
                        if(!secret)continue;
                        const method=iType>=0&&String(row[iType]||'').toLowerCase().includes('hotp')?'hotp':'totp';
                        let algorithm=iAlgo>=0?String(row[iAlgo]||'SHA1').toUpperCase().replace(/-/g,''):'SHA1';if(!['SHA1','SHA256','SHA512'].includes(algorithm))algorithm='SHA1';
                        items.push({method,source:secret,encoding:'base32',algorithm,digits:Number(iDigits>=0?row[iDigits]:6)||6,period:Number(iPeriod>=0?row[iPeriod]:30)||30,counter:Number(iCounter>=0?row[iCounter]:0)||0,issuer:iIssuer>=0?String(row[iIssuer]||'').trim():'',account:iAccount>=0?String(row[iAccount]||'').trim():'',recovery_codes:'',notes:'Import CSV MFA'});
                    }catch(_){}
                }
                if(items.length)return {items,source:'CSV MFA'};
            }
        }

        /* Une clé Base32 seule est un format valide pour un ajout manuel. */
        if(!items.length){
            const compact=raw.replace(/[\s-]+/g,'').toUpperCase();
            if(compact.length>=16 && /^[A-Z2-7]+=*$/.test(compact)) items.push({method:'totp',source:compact,encoding:'base32',algorithm:'SHA1',digits:6,period:30,counter:0,issuer:'',account:'',recovery_codes:'',notes:'Import clé secrète'});
        }
        return {items,source:google?'Google Authenticator':(items.length?'Import MFA':'URI otpauth')};
    }
    let mfaLocalQrPromise=null;
    async function mfaEnsureLocalQr() {
        if(window.DMDGenPWQR && typeof window.DMDGenPWQR.decode==='function') return window.DMDGenPWQR;
        if(mfaLocalQrPromise) return mfaLocalQrPromise;
        mfaLocalQrPromise=new Promise((resolve,reject)=>{
            if(!qrLocalUrl) return reject(new Error('Lecteur QR local absent du module.'));
            const existing=[...document.scripts].find(x=>x.src===new URL(qrLocalUrl,location.href).href);
            if(existing){
                const wait=()=>window.DMDGenPWQR&&typeof window.DMDGenPWQR.decode==='function'?resolve(window.DMDGenPWQR):reject(new Error('Lecteur QR local non initialisé.'));
                if(existing.dataset.loaded==='1')return wait();
                existing.addEventListener('load',wait,{once:true});existing.addEventListener('error',()=>reject(new Error('Chargement du lecteur QR local impossible.')),{once:true});return;
            }
            const script=document.createElement('script');script.src=qrLocalUrl;script.async=true;script.referrerPolicy='no-referrer';
            script.onload=()=>{script.dataset.loaded='1';if(window.DMDGenPWQR&&typeof window.DMDGenPWQR.decode==='function')resolve(window.DMDGenPWQR);else reject(new Error('Lecteur QR local invalide.'));};
            script.onerror=()=>reject(new Error('Chargement du lecteur QR local impossible.'));document.head.appendChild(script);
        });
        try{return await mfaLocalQrPromise;}catch(error){mfaLocalQrPromise=null;throw error;}
    }
    let mfaJsQrPromise=null;
    async function mfaEnsureJsQr() {
        if(typeof window.jsQR==='function') return window.jsQR;
        if(mfaJsQrPromise) return mfaJsQrPromise;
        const sources=[qrDecoderUrl,'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js','https://unpkg.com/jsqr@1.4.0/dist/jsQR.js'].filter(Boolean);
        mfaJsQrPromise=(async()=>{
            let lastError=null;
            for(const src of sources){
                try{
                    await new Promise((resolve,reject)=>{
                        const absolute=new URL(src,location.href).href;const existing=[...document.scripts].find(x=>x.src===absolute);
                        if(existing && typeof window.jsQR==='function') return resolve();
                        const script=document.createElement('script');script.src=src;script.async=true;script.referrerPolicy='no-referrer';
                        script.onload=()=>resolve();script.onerror=()=>reject(new Error('Chargement du décodeur QR de secours impossible.'));document.head.appendChild(script);
                    });
                    if(typeof window.jsQR==='function') return window.jsQR;
                }catch(error){lastError=error;}
            }
            throw lastError||new Error('Décodeur QR de secours indisponible.');
        })();
        try{return await mfaJsQrPromise;}catch(error){mfaJsQrPromise=null;throw error;}
    }
    async function mfaBitmapToImageData(bitmap,maxSide=2200,scaleUp=1) {
        const ow=Number(bitmap.width||0), oh=Number(bitmap.height||0);
        if(!ow||!oh) throw new Error('Image QR invalide.');
        const fit=Math.min(1,maxSide/Math.max(ow,oh));const scale=Math.max(0.25,fit*scaleUp);
        const width=Math.max(1,Math.round(ow*scale)), height=Math.max(1,Math.round(oh*scale));
        const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;const ctx=canvas.getContext('2d',{willReadFrequently:true});
        if(!ctx) throw new Error('Canvas QR indisponible.');ctx.imageSmoothingEnabled=false;ctx.drawImage(bitmap,0,0,width,height);return ctx.getImageData(0,0,width,height);
    }
    function mfaQrVariants(image) {
        const variants=[image];const gray=new Uint8ClampedArray(image.data.length);const hist=new Array(256).fill(0);
        for(let i=0;i<image.data.length;i+=4){const y=Math.max(0,Math.min(255,Math.round(image.data[i]*0.299+image.data[i+1]*0.587+image.data[i+2]*0.114)));hist[y]++;gray[i]=gray[i+1]=gray[i+2]=y;gray[i+3]=255;}
        variants.push({data:gray,width:image.width,height:image.height});let total=image.width*image.height,sum=0;for(let i=0;i<256;i++)sum+=i*hist[i];
        let sumB=0,wB=0,max=0,threshold=128;for(let t=0;t<256;t++){wB+=hist[t];if(!wB)continue;const wF=total-wB;if(!wF)break;sumB+=t*hist[t];const mB=sumB/wB,mF=(sum-sumB)/wF,between=wB*wF*(mB-mF)*(mB-mF);if(between>max){max=between;threshold=t;}}
        for(const delta of [-24,0,24]){const th=Math.max(0,Math.min(255,threshold+delta));const bw=new Uint8ClampedArray(gray.length),inv=new Uint8ClampedArray(gray.length);for(let i=0;i<gray.length;i+=4){const v=gray[i]>th?255:0,iv=255-v;bw[i]=bw[i+1]=bw[i+2]=v;bw[i+3]=255;inv[i]=inv[i+1]=inv[i+2]=iv;inv[i+3]=255;}variants.push({data:bw,width:image.width,height:image.height},{data:inv,width:image.width,height:image.height});}
        return variants;
    }
    async function mfaDecodeWithLocalQr(bitmap) {
        const decoder=await mfaEnsureLocalQr();const scales=[1,1.5,2];
        for(const scaleUp of scales){const image=await mfaBitmapToImageData(bitmap,2600,scaleUp);for(const variant of mfaQrVariants(image)){const value=String(decoder.decode(variant)||'').trim();if(value)return value;}}
        return '';
    }
    async function mfaDecodeWithJsQr(bitmap) {
        const jsQR=await mfaEnsureJsQr();const sizes=[1,1.5,2];
        for(const scaleUp of sizes){const image=await mfaBitmapToImageData(bitmap,2600,scaleUp);for(const variant of mfaQrVariants(image)){const result=jsQR(variant.data,variant.width,variant.height,{inversionAttempts:'attemptBoth'});const value=result&&result.data?String(result.data).trim():'';if(value)return value;}}
        return '';
    }
    function mfaQrValueUsable(value) {
        const v=String(value||'').trim();
        if(!v) return false;
        const low=v.toLowerCase();
        return low.startsWith('otpauth://') || low.startsWith('otpauth-migration://') || mfaLooksLikeMicrosoftPushEnrollment(v);
    }
    async function mfaDecodeQrImage(file) {
        const bitmap=await createImageBitmap(file);const errors=[];
        try {
            /* 1) API native Chromium quand elle existe. */
            if(typeof BarcodeDetector!=='undefined'){
                try{
                    const supported=typeof BarcodeDetector.getSupportedFormats==='function'?await BarcodeDetector.getSupportedFormats():['qr_code'];
                    if(!Array.isArray(supported)||supported.includes('qr_code')){
                        const detector=new BarcodeDetector({formats:['qr_code']});
                        const results=await detector.detect(bitmap);
                        const values=(results||[]).map(x=>String(x.rawValue||'').trim()).filter(mfaQrValueUsable);
                        if(values.length)return [...new Set(values)];
                    }
                }catch(error){errors.push(error);}
            }
            /* 2) jsQR : décodeur éprouvé chargé same-origin ou CDN. */
            try{const value=await mfaDecodeWithJsQr(bitmap);if(mfaQrValueUsable(value))return [value];}catch(error){errors.push(error);}
            /* 3) Décodeur local embarqué, uniquement si son résultat est un URI MFA valide.
               Il ne doit jamais court-circuiter jsQR avec une chaîne partiellement corrompue. */
            try{const value=await mfaDecodeWithLocalQr(bitmap);if(mfaQrValueUsable(value))return [value];}catch(error){errors.push(error);}
            throw new Error(`Aucun QR MFA TOTP/HOTP lisible dans ${file.name}. Essayez une capture nette ou collez l’URI / la clé secrète.`);
        } finally {if(bitmap&&bitmap.close)bitmap.close();}
    }
    async function mfaDecodeVideoFrame(video) {
        if(!video||video.readyState<2||!video.videoWidth||!video.videoHeight)return [];
        const maxSide=1200,scale=Math.min(1,maxSide/Math.max(video.videoWidth,video.videoHeight));const w=Math.max(1,Math.round(video.videoWidth*scale)),h=Math.max(1,Math.round(video.videoHeight*scale));
        const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d',{willReadFrequently:true});if(!ctx)return [];ctx.drawImage(video,0,0,w,h);const image=ctx.getImageData(0,0,w,h);
        if(typeof BarcodeDetector!=='undefined'){try{const detector=new BarcodeDetector({formats:['qr_code']});const results=await detector.detect(video);const values=(results||[]).map(x=>String(x.rawValue||'').trim()).filter(mfaQrValueUsable);if(values.length)return [...new Set(values)];}catch(_){} }
        try{const jsQR=await mfaEnsureJsQr();const result=jsQR(image.data,w,h,{inversionAttempts:'attemptBoth'});const v=result&&result.data?String(result.data).trim():'';if(mfaQrValueUsable(v))return [v];}catch(_){}
        try{const decoder=await mfaEnsureLocalQr();const v=String(decoder.decode(image)||'').trim();if(mfaQrValueUsable(v))return [v];}catch(_){}
        return [];
    }
    function openMfaImport() {
        const imported=[]; const fingerprints=new Set(); let detectedSource='Authenticator';
        const wrap=el('div','genpw-panel-stack genpw-mfa-import-panel');
        const info=el('div','genpw-import-info');
        info.innerHTML='<strong>Importer vos comptes MFA</strong><span>QR TOTP/HOTP, transfert Google Authenticator, URI otpauth://, clé secrète Base32, Aegis, 2FAS, JSON/CSV/TXT compatibles. Les QR Microsoft Authenticator Push sont détectés mais ne contiennent pas de secret TOTP exportable.</span><span>Chaque compte importé devient une fiche MFA qui génère directement son code.</span>';
        wrap.appendChild(info);

        const textField=el('label','genpw-field'); textField.appendChild(el('span','genpw-label','URI / export texte'));
        const text=document.createElement('textarea'); text.className='genpw-input genpw-textarea'; text.rows=3; text.placeholder='otpauth://… ou otpauth-migration://…'; textField.appendChild(text); wrap.appendChild(textField);
        const parseTextBtn=el('button','genpw-btn','Analyser le texte / URI'); parseTextBtn.type='button'; wrap.appendChild(parseTextBtn);

        const fileField=el('label','genpw-field'); fileField.appendChild(el('span','genpw-label','Fichiers / images QR'));
        const file=document.createElement('input'); file.className='genpw-input'; file.type='file'; file.multiple=true; file.accept='.json,.txt,.csv,.2fas,.aegis,image/png,image/jpeg,image/webp,application/json,text/plain,text/csv'; fileField.appendChild(file); wrap.appendChild(fileField);
        const readFilesBtn=el('button','genpw-btn','📷 Lire les fichiers / QR'); readFilesBtn.type='button'; wrap.appendChild(readFilesBtn);

        const cameraBox=el('div','genpw-mfa-camera'); const cameraActions=el('div','genpw-panel-actions');
        const cameraBtn=el('button','genpw-btn','📷 Scanner un QR avec la caméra'); cameraBtn.type='button';
        const stopCameraBtn=el('button','genpw-btn','Arrêter la caméra'); stopCameraBtn.type='button'; stopCameraBtn.hidden=true;
        const video=document.createElement('video'); video.className='genpw-mfa-camera-video'; video.autoplay=true; video.playsInline=true; video.hidden=true;
        cameraActions.append(cameraBtn,stopCameraBtn); cameraBox.append(cameraActions,video); wrap.appendChild(cameraBox);

        const status=el('div','genpw-security-note','Aucun compte détecté.'); wrap.appendChild(status);
        const list=el('div','genpw-mfa-import-list'); wrap.appendChild(list);
        const duplicate=el('label','genpw-check'); const duplicateInput=document.createElement('input'); duplicateInput.type='checkbox'; duplicateInput.checked=true; duplicate.append(duplicateInput,document.createTextNode(' Ignorer les comptes MFA déjà présents')); wrap.appendChild(duplicate);
        const actions=el('div','genpw-panel-actions'); const run=el('button','genpw-btn is-primary','🔐 Importer les comptes MFA'); run.type='button'; run.disabled=true; actions.appendChild(run); wrap.appendChild(actions);

        const fingerprint=item=>[item.method,String(item.source||'').replace(/\s+/g,'').toUpperCase(),String(item.issuer||'').toLowerCase(),String(item.account||'').toLowerCase()].join('|');
        const render=()=>{
            list.replaceChildren();
            imported.forEach((item,index)=>{
                const row=el('label','genpw-mfa-import-row'); const check=document.createElement('input'); check.type='checkbox'; check.checked=true; check.dataset.index=String(index);
                const body=el('span','genpw-mfa-import-row-main'); body.append(el('strong','',item.issuer||item.account||'Compte MFA'),el('span','',`${item.account||'Compte sans libellé'} · ${String(item.method||'totp').toUpperCase()} · ${item.digits||6} chiffres`));
                row.append(check,body); list.appendChild(row);
            });
            status.textContent=imported.length?`${imported.length} compte(s) MFA détecté(s). Sélectionnez ceux à importer.`:'Aucun compte détecté.';
            run.disabled=!imported.length;
        };
        const addParsed=(parsed)=>{
            if(parsed&&parsed.source) detectedSource=parsed.source;
            (parsed&&Array.isArray(parsed.items)?parsed.items:[]).forEach(item=>{ const fp=fingerprint(item); if(fingerprints.has(fp))return; fingerprints.add(fp); imported.push(item); });
            render();
        };
        const addUri=(value)=>{
            const raw=String(value||'').trim(); if(!raw)return;
            if(mfaLooksLikeMicrosoftPushEnrollment(raw)) throw new Error(mfaMicrosoftPushMessage());
            if(raw.toLowerCase().startsWith('otpauth-migration://')) { const parsed=mfaParseGoogleMigration(raw); addParsed({items:parsed.items,source:'Google Authenticator'}); if(parsed.batchSize>1) status.textContent+=` QR ${parsed.batchIndex+1}/${parsed.batchSize} du lot Google détecté.`; }
            else if(raw.toLowerCase().startsWith('otpauth://')) addParsed({items:[mfaParseOtpAuth(raw)],source:'QR otpauth'});
            else { const parsed=mfaParseTextExport(raw); if(!parsed.items.length && /mobileappcommunicator\.auth\.microsoft\.com\/activate/i.test(raw)) throw new Error(mfaMicrosoftPushMessage()); addParsed(parsed); }
        };
        parseTextBtn.addEventListener('click',()=>{try{addUri(text.value);if(!imported.length)throw new Error('Aucun compte MFA exploitable détecté.');}catch(e){toast(e.message,true)}});
        readFilesBtn.addEventListener('click',async()=>{
            const files=[...(file.files||[])]; if(!files.length)return toast('Sélectionnez au moins un fichier ou une image QR.',true);
            readFilesBtn.disabled=true;
            try{
                for(const f of files){
                    if(String(f.type||'').startsWith('image/')) { const values=await mfaDecodeQrImage(f); values.forEach(addUri); }
                    else { const raw=await f.text(); const parsed=mfaParseTextExport(raw);
                        if(f.name.toLowerCase().endsWith('.2fas')) parsed.source='2FAS'; addParsed(parsed); }
                }
                if(!imported.length) throw new Error('Aucun compte MFA exploitable détecté dans ces fichiers.');
            }catch(e){toast(e.message,true)} finally{readFilesBtn.disabled=false;}
        });
        const stopCamera=()=>{ if(mfaImportCameraStream){try{mfaImportCameraStream.getTracks().forEach(t=>t.stop())}catch(_){} mfaImportCameraStream=null;} video.srcObject=null;video.hidden=true;stopCameraBtn.hidden=true;cameraBtn.hidden=false; };
        stopCameraBtn.addEventListener('click',stopCamera);
        cameraBtn.addEventListener('click',async()=>{
            if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return toast('Accès caméra indisponible.',true);
            try{
                mfaImportCameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});
                video.srcObject=mfaImportCameraStream;video.hidden=false;stopCameraBtn.hidden=false;cameraBtn.hidden=true; await video.play();
                let busy=false;
                const scan=async()=>{
                    if(!mfaImportCameraStream||video.hidden)return;
                    if(!busy){
                        busy=true;
                        try{const values=await mfaDecodeVideoFrame(video);for(const value of values){try{addUri(value)}catch(e){toast(e.message,true);stopCamera();return;}}}catch(_){}finally{busy=false;}
                    }
                    if(mfaImportCameraStream)window.setTimeout(scan,450);
                }; scan();
            }catch(e){stopCamera();toast(e.message||'Impossible d’ouvrir la caméra.',true)}
        });
        run.addEventListener('click',async()=>{
            const selected=[...list.querySelectorAll('input[type="checkbox"]:checked')].map(cb=>imported[Number(cb.dataset.index)]).filter(Boolean);
            if(!selected.length)return toast('Sélectionnez au moins un compte MFA.',true);
            run.disabled=true;
            try{
                const result=await api('mfa_import_batch',{items:selected,source:detectedSource,skip_existing:duplicateInput.checked});
                emitActivity(result); await loadList();
                const parts=[`${result.imported||0} importé(s)`]; if(result.duplicates)parts.push(`${result.duplicates} doublon(s) ignoré(s)`); if(result.invalid)parts.push(`${result.invalid} invalide(s)`);
                toast(`MFA · ${parts.join(' · ')}`); closeModal();
            }catch(e){toast(e.message,true)} finally{run.disabled=false;}
        });
        render(); modalPanel.appendChild(wrap); openModal('Importer des comptes MFA', 'panel');
    }

    function openImport() {
        const wrap = el('div','genpw-panel-stack');
        const info = el('div','genpw-import-info');
        info.innerHTML = '<strong>LastPass, Bitwarden, KeePass, 1Password et CSV générique</strong><span>Formats : LastPass CSV · Bitwarden CSV/JSON non chiffré · KeePass CSV · 1Password CSV/1PUX · CSV générique.</span><span>Le fichier d’export est lu uniquement pendant l’import et n’est pas conservé par DMD-GenPW.</span>';
        wrap.appendChild(info);

        const sourceField = el('label','genpw-field');
        sourceField.appendChild(el('span','genpw-label','Source'));
        const source = document.createElement('select'); source.className='genpw-select';
        [['auto','Détection automatique'],['lastpass','LastPass'],['1password','1Password'],['bitwarden','Bitwarden'],['keepass','KeePass'],['generic','CSV générique']].forEach(([value,label])=>{ const option=document.createElement('option'); option.value=value; option.textContent=label; source.appendChild(option); });
        sourceField.appendChild(source); wrap.appendChild(sourceField);

        const fileField = el('label','genpw-field'); fileField.appendChild(el('span','genpw-label','Fichier du coffre'));
        const file = document.createElement('input'); file.className='genpw-input'; file.type='file'; file.accept='.csv,.json,.1pux,text/csv,application/json,application/zip'; fileField.appendChild(file); wrap.appendChild(fileField);

        const duplicate = el('label','genpw-check'); const duplicateInput=document.createElement('input'); duplicateInput.type='checkbox'; duplicateInput.checked=true; duplicate.append(duplicateInput,document.createTextNode(' Ignorer les doublons déjà présents (nom + URL + identifiant)')); wrap.appendChild(duplicate);

        const warning = el('div','genpw-security-note','⚠ Les exports LastPass, 1Password 1PUX/CSV et Bitwarden non chiffrés contiennent vos secrets en clair. Supprimez le fichier d’export après migration.'); wrap.appendChild(warning);
        const actions=el('div','genpw-panel-actions'); const run=el('button','genpw-btn is-primary','⇧ Importer le coffre'); run.type='button'; run.addEventListener('click',()=>uploadImport(file.files && file.files[0] ? file.files[0] : null, source.value, duplicateInput.checked, run)); actions.appendChild(run); wrap.appendChild(actions);
        modalPanel.appendChild(wrap); openModal('Importer un coffre', 'panel');
    }

    function openExport() {
        const wrap = el('div','genpw-panel-stack'); const include = el('label','genpw-check'); const checkbox = document.createElement('input'); checkbox.type='checkbox'; checkbox.disabled = !can('vault.export.secrets'); include.append(checkbox, document.createTextNode(' ' + t('include_secrets','Inclure les secrets'))); wrap.appendChild(include);
        const actions = el('div','genpw-panel-actions');
        [['json',t('export_json','JSON')],['csv',t('export_csv','CSV')]].forEach(([format,label]) => { const btn = el('button','genpw-btn is-primary',`⇩ ${label}`); btn.type='button'; btn.addEventListener('click',async()=>{ try { const result=await api('export',{format,include_secrets:checkbox.checked}); downloadPayload(result); toast(t('export','Exporter')); } catch(error){toast(error.message,true);} }); actions.appendChild(btn); });
        wrap.appendChild(actions); modalPanel.appendChild(wrap); openModal(t('export','Exporter'), 'panel');
    }
    async function openLogs() {
        try {
            const result = await api('logs',{limit:200}); const rows = Array.isArray(result.items) ? result.items : [];
            const wrap = el('div','genpw-panel-stack'); const tableWrap = el('div','genpw-log-list');
            if (!rows.length) tableWrap.appendChild(el('p','genpw-empty','Aucun journal.'));
            rows.forEach(row => { const line = el('div','genpw-log-line'); line.append(el('span','',String(row.datetime || '')),el('strong','',String(row.action || '')),el('span','',String(row.target || '')),el('span','',String(row.status || ''))); tableWrap.appendChild(line); });
            wrap.appendChild(tableWrap); const actions = el('div','genpw-panel-actions');
            if (can('logs.export')) { const exp=el('button','genpw-btn','⇩ '+t('export_logs','Exporter le journal')); exp.type='button'; exp.addEventListener('click',async()=>{try{downloadPayload(await api('logs_export'));}catch(error){toast(error.message,true);}}); actions.appendChild(exp); }
            if (can('logs.delete')) { const del=el('button','genpw-btn is-danger','🗑 '+t('clear_logs','Supprimer mon journal')); del.type='button'; del.addEventListener('click',async()=>{if(!window.confirm(t('confirm_logs','Supprimer votre journal DMD-GenPW ?')))return;try{await api('logs_delete');tableWrap.replaceChildren(el('p','genpw-empty','Aucun journal.'));toast(t('clear_logs','Journal supprimé'));}catch(error){toast(error.message,true);}}); actions.appendChild(del); }
            wrap.appendChild(actions); modalPanel.appendChild(wrap); openModal(t('logs','Journal'), 'panel');
        } catch (error) { toast(error.message, true); }
    }


    function formField(label, input) {
        const wrap=el('label','genpw-field'); wrap.appendChild(el('span','genpw-label',label)); wrap.appendChild(input); return wrap;
    }
    function textInput(value='', type='text') { const i=document.createElement('input'); i.className='genpw-input'; i.type=type; i.value=value||''; return i; }
    function downloadBase64(filename, mime, content) {
        const a=document.createElement('a'); a.download=filename||'fichier'; a.href='data:'+(mime||'application/octet-stream')+';base64,'+content; document.body.appendChild(a); a.click(); a.remove();
    }
    async function openEntryPro(item) {
        try {
            const [metaResult, historyResult, fullResult] = await Promise.all([
                api('pro_meta_get',{id:item.id}),
                api('history_list',{id:item.id}),
                api('entry_get',{id:item.id,kind:item.kind||'owned'})
            ]);
            const meta=metaResult.meta||{}, attachments=Array.isArray(metaResult.attachments)?metaResult.attachments:[], history=Array.isArray(historyResult.items)?historyResult.items:[], full=fullResult||{};
            const wrap=el('div','genpw-panel-stack');

            const grid=el('div','genpw-form-grid');
            const fav=document.createElement('input'); fav.type='checkbox'; fav.checked=!!meta.favorite;
            const favLabel=el('label','genpw-check'); favLabel.append(fav,document.createTextNode(' Favori / épinglé'));
            grid.appendChild(favLabel);

            const typeSel=document.createElement('select'); typeSel.className='genpw-select';
            [['generic','Générique'],['website','Site Web'],['server','Serveur'],['database','Base SQL'],['wifi','Wi-Fi'],['api','API'],['ssh','SSH'],['license','Licence'],['card','Carte']].forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;if(v===meta.profile_type)o.selected=true;typeSel.appendChild(o);});
            grid.appendChild(formField('Type de fiche',typeSel));

            const applyTemplate=el('button','genpw-btn','＋ Appliquer les champs du modèle');applyTemplate.type='button';
            applyTemplate.addEventListener('click',async()=>{try{
                const tr=await api('profile_templates');const tpl=(tr.templates||{})[typeSel.value]||[];
                const current=Array.isArray(full.extra_fields)?full.extra_fields.map(x=>Object.assign({},x)):[];
                const labels=new Set(current.map(x=>String(x.label||'').toLowerCase()));
                tpl.forEach(f=>{if(!labels.has(String(f.label||'').toLowerCase()))current.push({type:f.type,label:f.label,value:''});});
                await api('update',{id:item.id,name:item.name||'',cat:item.cat||'Autre',url:item.url||'',user:item.user||'',notes:item.notes||'',pw:'',extra_fields:current});
                toast('Modèle appliqué.');closeModal();await loadList();
            }catch(e){toast(e.message,true)}});
            grid.appendChild(applyTemplate);

            const tags=textInput((meta.tags||[]).join(', ')); grid.appendChild(formField('Tags',tags));
            const expires=textInput(meta.expires_at||'','date'); grid.appendChild(formField('Expiration',expires));
            const rotation=textInput(String(meta.rotation_days||0),'number'); rotation.min='0'; rotation.max='3650'; grid.appendChild(formField('Rotation (jours)',rotation));
            wrap.appendChild(grid);

            const maskTitle=el('strong','','Masquage par champ');wrap.appendChild(maskTitle);
            const masks=Object.assign({},meta.field_masks||{});
            const maskList=el('div','genpw-share-list');
            const maskRows=[
                ['user','Identifiant / e-mail'],
                ['url','Adresse / URL'],
                ['notes','Notes'],
                ['password','Mot de passe']
            ];
            (Array.isArray(full.extra_fields)?full.extra_fields:[]).forEach(f=>maskRows.push(['extra:'+String(f.id||f.label||f.type||''),String(f.label||extraFieldLabel(f.type))]));
            maskRows.forEach(([key,label])=>{
                const row=el('div','genpw-share-line');row.appendChild(el('span','',label));
                const sel=document.createElement('select');sel.className='genpw-select';sel.style.maxWidth='190px';
                [['visible','Visible'],['masked','Masqué'],['confirm','Confirmation avant affichage']].forEach(([v,l])=>{const o=document.createElement('option');o.value=v;o.textContent=l;if((masks[key]||((key==='password'||key.startsWith('extra:'))?'masked':'visible'))===v)o.selected=true;sel.appendChild(o);});
                sel.addEventListener('change',()=>{masks[key]=sel.value;});row.appendChild(sel);maskList.appendChild(row);
            });wrap.appendChild(maskList);

            const save=el('button','genpw-btn is-primary','💾 Enregistrer les options'); save.type='button';
            save.addEventListener('click',async()=>{try{
                await api('pro_meta_save',{id:item.id,favorite:fav.checked,tags:tags.value,expires_at:expires.value,rotation_days:Number(rotation.value||0),profile_type:typeSel.value,field_masks:masks});
                toast('Options enregistrées.'); await loadList();
            }catch(e){toast(e.message,true)}});
            wrap.appendChild(save);

            const attachTitle=el('strong','','Pièces jointes chiffrées'); wrap.appendChild(attachTitle);
            const attachList=el('div','genpw-share-list');
            const renderAttachments=()=>{
                attachList.replaceChildren();
                if(!attachments.length) attachList.appendChild(el('p','genpw-empty','Aucune pièce jointe.'));
                attachments.forEach(a=>{
                    const row=el('div','genpw-share-line'); row.appendChild(el('span','',`${a.name} · ${Math.ceil(Number(a.size||0)/1024)} Ko`));
                    const actions=el('div','genpw-panel-actions');
                    const get=el('button','genpw-btn','⇩ Télécharger');get.type='button';get.addEventListener('click',async()=>{try{const r=await api('attachment_get',{attachment_id:a.id});downloadBase64(r.attachment.name,r.attachment.mime,r.content)}catch(e){toast(e.message,true)}});
                    const del=el('button','genpw-btn is-danger','🗑');del.type='button';del.addEventListener('click',async()=>{try{await api('attachment_delete',{attachment_id:a.id});const idx=attachments.findIndex(x=>x.id===a.id);if(idx>=0)attachments.splice(idx,1);renderAttachments()}catch(e){toast(e.message,true)}});
                    actions.append(get,del); row.appendChild(actions); attachList.appendChild(row);
                });
            }; renderAttachments(); wrap.appendChild(attachList);
            const uploadRow=el('div','genpw-panel-actions'); const file=document.createElement('input');file.type='file';file.className='genpw-input';
            const upload=el('button','genpw-btn','＋ Ajouter');upload.type='button';upload.addEventListener('click',async()=>{if(!file.files||!file.files[0])return;const fd=new FormData();fd.append('action','attachment_add');fd.append('id',item.id);fd.append('file',file.files[0]);try{
                const resp=await fetch(apiUrl,{method:'POST',credentials:'same-origin',headers:{'X-CSRF-Token':csrf},body:fd});const data=await resp.json();if(!resp.ok||data.ok===false)throw new Error(data.error||'Upload impossible');attachments.push(data.attachment);renderAttachments();file.value='';toast('Pièce jointe chiffrée ajoutée.');
            }catch(e){toast(e.message,true)}});uploadRow.append(file,upload);wrap.appendChild(uploadRow);

            const histTitle=el('strong','','Historique des modifications'); wrap.appendChild(histTitle);
            const hist=el('div','genpw-log-list');
            if(!history.length) hist.appendChild(el('p','genpw-empty','Aucun historique.'));
            history.forEach(h=>{const row=el('div','genpw-share-line');row.appendChild(el('span','',`${h.at} · ${h.by} · ${h.event}`));const restore=el('button','genpw-btn','↶ Restaurer');restore.type='button';restore.addEventListener('click',async()=>{if(!confirm('Restaurer cette version ?'))return;try{await api('history_restore',{id:item.id,version:h.version});toast('Version restaurée.');closeModal();await loadList()}catch(e){toast(e.message,true)}});row.appendChild(restore);hist.appendChild(row);}); wrap.appendChild(hist);

            modalPanel.replaceChildren(wrap); openModal('🛡️ '+(item.name||'Entrée'),'panel');
        } catch(e){toast(e.message,true)}
    }

    async function openProCenter() {
        try {
            const [overview, audit, dupes, trash, settings] = await Promise.all([
                api('pro_overview'), api('security_audit',{check_pwned:false}), api('duplicates'), api('trash_list'), api('pro_settings_get')
            ]);
            const wrap=el('div','genpw-panel-stack');
            const s=overview.summary||{}, a=(audit.audit&&audit.audit.summary)||{};
            const dashboard=el('div','genpw-pro-dashboard');
            [['Entrées',s.entries||0],['Favoris',s.favorites||0],['Corbeille',s.trash||0],['Faibles',a.weak||0],['Réutilisés',a.reused||0],['Anciens',a.old||0],['Sans MFA',a.without_mfa||0]].forEach(([l,v])=>{const c=el('div','genpw-pro-stat');c.append(el('strong','',String(v)),el('span','',l));dashboard.appendChild(c);});wrap.appendChild(dashboard);

            const tools=el('div','genpw-panel-actions');
            const auditBtn=el('button','genpw-btn','🛡️ Audit détaillé');auditBtn.type='button';auditBtn.addEventListener('click',()=>{const list=el('div','genpw-log-list');(audit.audit.items||[]).filter(x=>x.issues&&x.issues.length).forEach(x=>list.appendChild(el('div','genpw-log-line',`${x.name} · ${x.issues.join(' · ')}`)));modalPanel.replaceChildren(list);openModal('Audit de sécurité','panel')});
            const dupBtn=el('button','genpw-btn','⧉ Doublons');dupBtn.type='button';dupBtn.addEventListener('click',()=>{const list=el('div','genpw-log-list');(dupes.items||[]).forEach(x=>list.appendChild(el('div','genpw-log-line',`${x.type} · ${x.value} · ${x.ids.length} entrées`)));modalPanel.replaceChildren(list);openModal('Détection des doublons','panel')});
            const hibpBtn=el('button','genpw-btn','🧬 Audit + HIBP');hibpBtn.type='button';hibpBtn.addEventListener('click',async()=>{try{const r=await api('security_audit',{check_pwned:true});const list=el('div','genpw-log-list');(r.audit.items||[]).filter(x=>x.issues&&x.issues.length).forEach(x=>list.appendChild(el('div','genpw-log-line',`${x.name} · ${x.issues.join(' · ')}`)));modalPanel.replaceChildren(list);openModal('Audit HIBP','panel')}catch(e){toast(e.message,true)}});
            tools.append(auditBtn,hibpBtn,dupBtn);wrap.appendChild(tools);

            const trashTitle=el('strong','','Corbeille');wrap.appendChild(trashTitle);
            const trashList=el('div','genpw-share-list'); const trashItems=Array.isArray(trash.items)?trash.items:[];
            if(!trashItems.length)trashList.appendChild(el('p','genpw-empty','Corbeille vide.'));
            trashItems.forEach(ti=>{const row=el('div','genpw-share-line');row.appendChild(el('span','',`${ti.name} · ${ti.deleted_at}`));const acts=el('div','genpw-panel-actions');const restore=el('button','genpw-btn','↶ Restaurer');restore.type='button';restore.addEventListener('click',async()=>{try{await api('trash_restore',{id:ti.id});row.remove();toast('Entrée restaurée.');await loadList()}catch(e){toast(e.message,true)}});const purge=el('button','genpw-btn is-danger','🗑 Définitif');purge.type='button';purge.addEventListener('click',async()=>{if(!confirm('Effacer définitivement ?'))return;try{await api('trash_purge',{ids:[ti.id]});row.remove()}catch(e){toast(e.message,true)}});acts.append(restore,purge);row.appendChild(acts);trashList.appendChild(row)});wrap.appendChild(trashList);

            const searchTitle=el('strong','','Recherche avancée');wrap.appendChild(searchTitle);
            const searchGrid=el('div','genpw-form-grid');const q=textInput();q.placeholder='Nom, URL, utilisateur, notes…';const tag=textInput();tag.placeholder='Tag';const category=textInput();category.placeholder='Catégorie';searchGrid.append(formField('Recherche',q),formField('Tag',tag),formField('Catégorie',category));wrap.appendChild(searchGrid);
            const runSearch=el('button','genpw-btn','🔎 Rechercher');runSearch.type='button';runSearch.addEventListener('click',async()=>{try{const r=await api('advanced_search',{q:q.value,tag:tag.value,category:category.value});const ids=new Set(r.ids||[]);renderList(state.items.filter(x=>ids.has(x.id)));closeModal();toast(`${ids.size} résultat(s).`)}catch(e){toast(e.message,true)}});wrap.appendChild(runSearch);

            const cfg=settings.settings||{}; const cfgTitle=el('strong','','Sécurité locale');wrap.appendChild(cfgTitle);
            const cfgGrid=el('div','genpw-form-grid');const reveal=textInput(String(cfg.reveal_seconds||20),'number');const clip=textInput(String(cfg.clipboard_seconds||20),'number');const lock=textInput(String(cfg.auto_lock_minutes||10),'number');
            cfgGrid.append(formField('Remasquer après (s)',reveal),formField('Effacer presse-papiers après (s)',clip),formField('Verrouillage après (min)',lock));wrap.appendChild(cfgGrid);
            const hibp=document.createElement('input');hibp.type='checkbox';hibp.checked=!!cfg.hibp_enabled;const hibpLabel=el('label','genpw-check');hibpLabel.append(hibp,document.createTextNode(' Vérification Have I Been Pwned (k-anonymity)'));wrap.appendChild(hibpLabel);
            const saveCfg=el('button','genpw-btn','💾 Enregistrer');saveCfg.type='button';saveCfg.addEventListener('click',async()=>{try{const r=await api('pro_settings_save',{reveal_seconds:Number(reveal.value),clipboard_seconds:Number(clip.value),auto_lock_minutes:Number(lock.value),hibp_enabled:hibp.checked});if(r&&r.settings)PRO_SETTINGS=Object.assign(PRO_SETTINGS,r.settings);toast('Réglages enregistrés.')}catch(e){toast(e.message,true)}});wrap.appendChild(saveCfg);

            const backupTitle=el('strong','','Sauvegarde chiffrée');wrap.appendChild(backupTitle);
            const backupActions=el('div','genpw-panel-actions');
            const auth=el('button','genpw-btn','🔐 Ré-authentifier');auth.type='button';auth.addEventListener('click',async()=>{try{await ensureSensitiveAuth();toast('Ré-authentification valide 5 minutes.')}catch(e){toast(e.message,true)}});
            const backup=el('button','genpw-btn','⇩ Sauvegarder');backup.type='button';backup.addEventListener('click',async()=>{try{const r=await api('backup_create');downloadBase64(r.filename,'application/octet-stream',r.content)}catch(e){toast(e.message,true)}});
            const restoreFile=document.createElement('input');restoreFile.type='file';restoreFile.className='genpw-input';restoreFile.accept='.dmdgp,application/octet-stream';
            const restore=el('button','genpw-btn is-danger','↶ Restaurer');restore.type='button';restore.addEventListener('click',async()=>{if(!restoreFile.files||!restoreFile.files[0])return toast('Sélectionnez une sauvegarde.',true);if(!confirm('Restaurer cette sauvegarde chiffrée et remplacer le coffre actuel ?'))return;try{await ensureSensitiveAuth();const bytes=new Uint8Array(await restoreFile.files[0].arrayBuffer());let binary='';bytes.forEach(b=>binary+=String.fromCharCode(b));const content=btoa(binary);const r=await api('backup_restore',{content});toast(`Sauvegarde restaurée · ${r.result&&r.result.entries||0} entrée(s).`);closeModal();await loadList()}catch(e){toast(e.message,true)}});
            backupActions.append(auth,backup,restoreFile,restore);wrap.appendChild(backupActions);

            modalPanel.replaceChildren(wrap);openModal('🛡️ Centre sécurité GenPW','panel');
        } catch(e){toast(e.message,true)}
    }

    async function deleteSelected() {
        if (!can('vault.delete')) return toast('Accès refusé.', true);
        const ids = [...root.querySelectorAll('.genpw-select-item:checked:not(:disabled)')].map(input => input.value);
        if (!ids.length) return toast('Aucune entrée sélectionnée.', true);
        if (!window.confirm(t('confirm_delete','Supprimer les éléments sélectionnés ?'))) return;
        try { const result = await api('delete', { ids }); toast(`${result.deleted || 0} supprimée(s).`); await loadList(); } catch (error) { toast(error.message, true); }
    }
    function decorateActionHub() { if (window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') { try { window.DMDActionHub.decorate(root); } catch (_) {} } }
    function announceResize() {
        const detail = { module: 'DMD-GenPW', element: root, width: root.scrollWidth, height: root.scrollHeight };
        try { root.dispatchEvent(new CustomEvent('dmd:module-content-resize', { bubbles: true, detail })); } catch (_) {}
        try { window.dispatchEvent(new CustomEvent('dmd:module-content-resize', { detail })); } catch (_) {}
    }

    byField('category').addEventListener('change', toggleCategoryFields);
    if (byField('mfa-method')) byField('mfa-method').addEventListener('change', updateMfaEditor);
    if (byAction('mfa-import-domydesk')) byAction('mfa-import-domydesk').addEventListener('click', importDomyDeskMfa);
    if (byAction('mfa-import-uri')) byAction('mfa-import-uri').addEventListener('click', openCurrentMfaManualImport);
    if (byAction('mfa-import-qr')) byAction('mfa-import-qr').addEventListener('click',()=>{const f=byField('mfa-qr-file');if(f){f.value='';f.click();}});
    if (byField('mfa-qr-file')) byField('mfa-qr-file').addEventListener('change',async event=>{const f=event.target.files&&event.target.files[0];if(!f)return;try{const kind=await importQrIntoCurrentEntry(f);if(kind==='otp')toast('QR MFA chargé dans la fiche.');}catch(e){toast(e.message,true)}});
    if (byAction('entry-attachment-add')) byAction('entry-attachment-add').addEventListener('click', queueEntryAttachments);
    if (entryAttachmentFileEl) entryAttachmentFileEl.addEventListener('change', queueEntryAttachments);

    if (byAction('mfa-load')) byAction('mfa-load').addEventListener('click', () => { const item=state.items.find(row=>row.id===state.editingId); if(item) loadMfaForEditing(item); });
    if (byAction('mfa-clear')) byAction('mfa-clear').addEventListener('click', async () => {
        const item=state.items.find(row=>row.id===state.editingId); if(!item || !item.mfa_configured) return;
        if (!window.confirm('Supprimer la double authentification enregistrée pour cette entrée ?')) return;
        try { await api('mfa_clear',{id:item.id}); toast('2FA supprimée de cette entrée.'); prepareMfaForItem({...item,mfa_configured:false,mfa_method:''}); await loadList(); }
        catch(error){ toast(error.message,true); }
    });
    byField('manual').addEventListener('input', event => updateStrength(event.target.value));
    byField('search').addEventListener('input', () => renderList(filteredItems()));
    byField('account-password').addEventListener('keydown', event => { if (event.key === 'Enter') unlockVault(); });
    if (byField('system-mfa-code')) byField('system-mfa-code').addEventListener('keydown', event => { if (event.key === 'Enter') unlockVault(); });
    byField('select-all').addEventListener('change', event => { root.querySelectorAll('.genpw-select-item:not(:disabled)').forEach(input => { input.checked = event.target.checked; const card=input.closest('.genpw-item'); if(card) card.classList.toggle('is-selected',input.checked); }); });
    byAction('generate').addEventListener('click', generatePassword);
    const extraAddType = byRole('extra-add-type');
    if (extraAddType) extraAddType.addEventListener('change', () => {
        const type = String(extraAddType.value || '');
        if (!type) return;
        addExtraFieldRow({ type });
        extraAddType.value = '';
    });
    byAction('use-manual').addEventListener('click', () => { const manual = byField('manual').value; if (!manual) return toast(t('empty_password','Mot de passe vide'), true); setPreview(manual); });
    byAction('copy-preview').addEventListener('click', event => copyText(state.preview, event.currentTarget));
    const entrySummary = entryPanel ? entryPanel.querySelector(':scope > .genpw-accordion-summary') : null;
    if (entrySummary) entrySummary.addEventListener('click', event => {
        if (!state.unlocked || !can('vault.create')) return;
        event.preventDefault();
        event.stopPropagation();
        startCreate();
    });
    byAction('save').addEventListener('click', saveEntry);
    byAction('unlock').addEventListener('click', unlockVault);
    byAction('refresh').addEventListener('click', loadList);
    byAction('delete-selected').addEventListener('click', deleteSelected);
    byAction('categories').addEventListener('click', openCategoryManager);
    byAction('import').addEventListener('click', openImport);
    if (byAction('mfa-import')) byAction('mfa-import').addEventListener('click', openMfaImport);
    byAction('export').addEventListener('click', openExport);
    byAction('logs').addEventListener('click', openLogs);
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && modal && !modal.hidden) closeModal(); });

    document.addEventListener('dmd:actionhub-action-complete', event => {
        if (!root.isConnected) return;
        const detail = event && event.detail ? event.detail : {};
        const result = detail.result && detail.result.data ? detail.result.data : {};
        if (result.module !== 'DMD-GenPW') return;
        if (result.locked) {
            setLocked();
            return;
        }
        if (result.command === 'edit-credential' && result.credential_id) {
            const item = state.items.find(candidate => candidate.id === result.credential_id && candidate.kind !== 'shared');
            if (item) editItem(item);
        }
    });


    document.addEventListener('dmd:actionhub-ui-action', async event => {
        if (!root.isConnected) return;
        const detail = event && event.detail && typeof event.detail === 'object' ? event.detail : {};
        if (String(detail.module || '') !== 'DMD-GenPW') return;
        const ui = detail.ui && typeof detail.ui === 'object' ? detail.ui : {};
        if (String(ui.type || '') !== 'genpw-open-credential') return;
        const credentialId = String(ui.credential_id || '');
        if (!credentialId) return;

        if (!state.unlocked) {
            accessPanel.open = true;
            announceResize();
            try {
                const unlockField = REQUIRE_SYSTEM_MFA ? byField('system-mfa-code') : byField('account-password');
                if (unlockField) unlockField.focus();
            } catch (_) {}
            return;
        }

        try {
            await loadList();
            const item = state.items.find(candidate => candidate.id === credentialId && candidate.kind !== 'shared');
            if (!item) return;
            editItem(item);
            document.dispatchEvent(new CustomEvent('dmd:actionhub-ui-action-handled', {
                detail: { module: 'DMD-GenPW', ui_type: 'genpw-open-credential', credential_id: credentialId }
            }));
        } catch (_) {}
    });

    if (!can('vault.create') && !can('vault.edit')) saveButton.hidden = true;
    if (!can('vault.unlock')) {
        byAction('unlock').hidden = true;
        if (byField('account-password')) byField('account-password').disabled = true;
        if (byField('system-mfa-code')) byField('system-mfa-code').disabled = true;
    }
    if (!can('vault.delete')) { byAction('delete-selected').hidden = true; byField('select-all').closest('.genpw-check').hidden = true; }
    if (!can('vault.list')) byAction('categories').hidden = true;
    if (!can('vault.create')) { byAction('import').hidden = true; if (byAction('mfa-import')) byAction('mfa-import').hidden = true; }
    if (!can('vault.export')) byAction('export').hidden = true;
    [entryPanel, accessPanel].forEach(panel => panel.addEventListener('toggle', announceResize));
    if (!can('logs.view')) byAction('logs').hidden = true;

    const myDeskCompactButton = document.querySelector('[data-dmdgp-mydesk-compact]');
    if (myDeskCompactButton) myDeskCompactButton.addEventListener('click', async () => {
        myDeskCompactButton.disabled = true;
        try { await api('mydesk_mode_save', { mode:'compact' }); } catch (_) {}
        try { window.resizeTo(360, 520); } catch (_) {}
        window.location.assign(<?= json_encode($myDeskCompactUrl, JSON_UNESCAPED_SLASHES) ?>);
    });

    resetMfaForm(); updateCategorySelect(DEFAULT_CATEGORY); toggleCategoryFields(); generatePassword(); decorateActionHub();
    if (window.ResizeObserver) { try { new ResizeObserver(() => announceResize()).observe(root); } catch (_) {} }
    api('pro_settings_get').then(r=>{if(r&&r.settings)PRO_SETTINGS=Object.assign(PRO_SETTINGS,r.settings)}).catch(()=>{});
    api('status').then(result => { if (result.unlocked) { setUnlocked(result.expires_in); loadList(); } else setLocked(); }).catch(() => setLocked());
})();
</script>
