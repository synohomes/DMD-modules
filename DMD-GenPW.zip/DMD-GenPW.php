<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/dmd-genpw_lib.php';

$email = dmd_genpw_email();
if (!is_string($email) || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    return;
}
if (!dmd_genpw_has_permission('module.view')) {
    echo '<div class="genpw-app"><section class="genpw-card">⛔ ' . htmlspecialchars(dmd_genpw_text('Accès DMD-GenPW refusé.','DMD-GenPW access denied.'), ENT_QUOTES, 'UTF-8') . '</section></div>';
    return;
}

$tr = dmd_genpw_strings();
$cfg = dmd_genpw_config($email);
$csrf = dmd_genpw_csrf();
$instanceId = 'dmd_genpw_' . bin2hex(random_bytes(5));
$cssVersion = is_file(__DIR__ . '/dmd-genpw.css') ? (string)filemtime(__DIR__ . '/dmd-genpw.css') : '1';
$moduleBase = dmd_genpw_module_web_path();
$themeUrl = dmd_genpw_user_theme_url($email);
$myDeskFull = isset($_GET['dmdgp_mydesk_full']) && (string)$_GET['dmdgp_mydesk_full'] === '1';
$myDeskCompactUrl = rtrim($moduleBase, '/') . '/dmd-genpw-mydesk.php?force_compact=1';
$myDeskCssVersion = is_file(__DIR__ . '/dmd-genpw-mydesk.css') ? (string)filemtime(__DIR__ . '/dmd-genpw-mydesk.css') : DMD_GENPW_VERSION;

$permissions = array();
foreach (array('vault.unlock','vault.list','vault.create','vault.edit','vault.delete','vault.reveal','vault.qr','vault.share','vault.revoke','vault.export','vault.export.secrets','logs.view','logs.export','logs.delete') as $permission) {
    $permissions[$permission] = dmd_genpw_has_permission($permission);
}

function dmdgp_h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function dmdgp_t($tr, $key, $fallback = '') {
    return isset($tr[$key]) ? (string)$tr[$key] : (string)$fallback;
}
?>
<?php if ($myDeskFull): ?><link rel="stylesheet" href="<?= dmdgp_h($themeUrl) ?>"><?php endif; ?>
<link rel="stylesheet" href="<?= dmdgp_h($moduleBase) ?>/dmd-genpw.css?v=<?= dmdgp_h($cssVersion) ?>">
<script>
(()=>{
    const href = <?= json_encode($moduleBase . '/dmd-genpw.css?v=' . $cssVersion, JSON_UNESCAPED_SLASHES) ?>;
    const id = 'dmd-genpw-style';
    let link = document.getElementById(id);
    if (!link) {
        link = document.createElement('link');
        link.id = id;
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }
    if (link.getAttribute('href') !== href) link.setAttribute('href', href);
})();
</script>

<?php if ($myDeskFull): ?>
<link rel="stylesheet" href="<?= dmdgp_h($moduleBase) ?>/dmd-genpw-mydesk.css?v=<?= dmdgp_h($myDeskCssVersion) ?>">
<script>
(() => {
    const href = <?= json_encode($moduleBase . '/dmd-genpw-mydesk.css?v=' . $myDeskCssVersion, JSON_UNESCAPED_SLASHES) ?>;
    let link = document.getElementById('dmd-genpw-mydesk-style');
    if (!link) { link = document.createElement('link'); link.id = 'dmd-genpw-mydesk-style'; link.rel = 'stylesheet'; document.head.appendChild(link); }
    if (link.getAttribute('href') !== href) link.setAttribute('href', href);

    function sourceWindow(){
        const candidates=[];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}
        for (const candidate of candidates) {
            try { if (candidate.document && candidate.location.origin === window.location.origin) return candidate; } catch (_) {}
        }
        return null;
    }
    function syncTheme(){
        const source=sourceWindow();
        if (!source) return;
        const names=[
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color','--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg','--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];
        const targets=[document.documentElement,document.body].filter(Boolean);
        [source.document.documentElement,source.document.body].filter(Boolean).forEach(sourceRoot=>{
            const cs=source.getComputedStyle(sourceRoot);
            names.forEach(name=>{ const value=cs.getPropertyValue(name); if(value&&value.trim()) targets.forEach(target=>target.style.setProperty(name,value.trim())); });
        });
        try {
            const bs=source.getComputedStyle(source.document.body);
            targets.forEach(target=>{ target.style.fontFamily=bs.fontFamily||''; });
            if(!getComputedStyle(document.documentElement).getPropertyValue('--background-color').trim()) document.documentElement.style.setProperty('--background-color',bs.backgroundColor||'#0b0f17');
            if(!getComputedStyle(document.documentElement).getPropertyValue('--text-color').trim()) document.documentElement.style.setProperty('--text-color',bs.color||'#e6eefc');
        } catch (_) {}
        document.documentElement.classList.add('dmdgp-mydesk-full-host');
        if(document.body) document.body.classList.add('dmdgp-mydesk-full-host');
    }
    syncTheme();
    window.addEventListener('load',syncTheme,{once:true});
    try {
        const w=Math.max(760,Math.min(1050,(screen.availWidth||1050)-40));
        const h=Math.max(560,Math.min(760,(screen.availHeight||760)-60));
        window.resizeTo(w,h);
    } catch (_) {}
})();
</script>
<div class="dmdgp-mydesk-fullbar">
    <strong>🔐 DMD-GenPW · mode complet</strong>
    <button type="button" data-dmdgp-mydesk-compact title="Revenir au mode compact">▣ Compact</button>
</div>
<?php endif; ?>

<div
    class="genpw-app"
    id="<?= dmdgp_h($instanceId) ?>"
    data-api="<?= dmdgp_h($moduleBase) ?>/dmd-genpw_api.php"
    data-qr="<?= dmdgp_h($moduleBase) ?>/dmd-genpw_qr.php"
    data-web-proxy="<?= dmdgp_h($moduleBase) ?>/dmd-genpw_web_proxy.php"
    data-csrf="<?= dmdgp_h($csrf) ?>"
    data-dmd-module-id="DMD-GenPW"
    data-dmd-context-type="credential_vault"
    data-dmd-context-id="DMD-GenPW:vault"
    data-dmd-context-name="DMD-GenPW"
    data-dmd-action-hub="1"
>
    <header class="genpw-head">
        <div class="genpw-title-wrap"><br>
            <p></p>
        </div>
        <span class="genpw-status" data-role="status"><?= dmdgp_h(dmdgp_t($tr, 'locked', 'Coffre verrouillé')) ?></span>
    </header>

    <div class="genpw-grid">
        <details class="genpw-card genpw-accordion" data-role="entry-panel" hidden aria-labelledby="<?= dmdgp_h($instanceId) ?>_generator_title">
            <summary class="genpw-accordion-summary">
                <span class="genpw-card-title" id="<?= dmdgp_h($instanceId) ?>_generator_title" data-role="entry-title"><?= dmdgp_h(dmdgp_t($tr, 'generator', 'Nouvelle entrée')) ?></span>
                <span class="genpw-accordion-arrow" aria-hidden="true">⌄</span>
            </summary>

            <div class="genpw-accordion-body">
            <div class="genpw-form-grid">
                <label class="genpw-field">
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'name', 'Nom')) ?></span>
                    <input class="genpw-input" type="text" data-field="name" maxlength="120" placeholder="Gmail personnel" autocomplete="off">
                </label>

                <label class="genpw-field">
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'category', 'Catégorie')) ?></span>
                    <select class="genpw-select" data-field="category">
                        <?php foreach (dmd_genpw_categories($email) as $category): ?>
                            <option value="<?= dmdgp_h($category) ?>"<?= $category === $cfg['default_category'] ? ' selected' : '' ?>><?= dmdgp_h(isset($tr['cat_' . $category]) ? $tr['cat_' . $category] : $category) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label class="genpw-field" data-role="url-field" hidden>
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'url', 'URL')) ?></span>
                    <input class="genpw-input" type="url" data-field="url" maxlength="2048" placeholder="https://exemple.fr" autocomplete="url">
                </label>

                <label class="genpw-field">
                    <span class="genpw-label" data-role="user-label"><?= dmdgp_h(dmdgp_t($tr, 'user', 'Identifiant / e-mail')) ?></span>
                    <input class="genpw-input" type="text" data-field="user" maxlength="255" placeholder="nom@exemple.fr" autocomplete="off">
                </label>

                <label class="genpw-field is-wide">
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'notes', 'Notes')) ?></span>
                    <textarea class="genpw-input genpw-textarea" data-field="notes" maxlength="12000" rows="3" placeholder="Notes, dossier d’origine, TOTP, informations importées…"></textarea>
                </label>

                <label class="genpw-field">
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'length', 'Longueur')) ?></span>
                    <input class="genpw-input" type="number" data-field="length" value="<?= (int)$cfg['default_length'] ?>" min="12" max="128" inputmode="numeric">
                </label>

                <div class="genpw-field">
                    <span class="genpw-label">Composition</span>
                    <label class="genpw-check">
                        <input type="checkbox" data-field="special"<?= $cfg['default_specials'] ? ' checked' : '' ?>>
                        <?= dmdgp_h(dmdgp_t($tr, 'specials', 'Caractères spéciaux')) ?>
                    </label>
                </div>

                <label class="genpw-field is-wide">
                    <span class="genpw-label" data-role="manual-label"><?= dmdgp_h(dmdgp_t($tr, 'manual', 'Mot de passe existant')) ?></span>
                    <div class="genpw-inline">
                        <input class="genpw-input" type="password" data-field="manual" maxlength="4096" placeholder="<?= dmdgp_h(dmdgp_t($tr, 'manual', 'Mot de passe existant')) ?>" autocomplete="new-password">
                        <button class="genpw-btn" type="button" data-action="use-manual"><?= dmdgp_h(dmdgp_t($tr, 'use', 'Utiliser')) ?></button>
                    </div>
                </label>

                <div class="genpw-field is-wide">
                    <span class="genpw-label">Mot de passe retenu</span>
                    <div class="genpw-inline">
                        <input class="genpw-preview" type="text" data-role="preview" readonly aria-label="Mot de passe retenu">
                        <button class="genpw-btn" type="button" data-action="generate">⚡ <?= dmdgp_h(dmdgp_t($tr, 'generate', 'Générer')) ?></button>
                        <button class="genpw-btn is-icon" type="button" data-action="copy-preview" title="<?= dmdgp_h(dmdgp_t($tr, 'copy', 'Copier')) ?>">📋</button>
                    </div>
                </div>

                <div class="genpw-field is-wide genpw-strength">
                    <div class="genpw-strength-meta">
                        <span data-role="strength-label"><?= dmdgp_h(dmdgp_t($tr, 'strength_none', 'Robustesse non évaluée')) ?></span>
                        <span data-role="strength-time">—</span>
                    </div>
                    <div class="genpw-strength-track" aria-hidden="true">
                        <div class="genpw-strength-fill" data-role="strength-bar"></div>
                    </div>
                </div>
            </div>

            <div class="genpw-actions">
                <button class="genpw-btn is-primary" type="button" data-action="save">💾 <?= dmdgp_h(dmdgp_t($tr, 'save', 'Enregistrer dans le coffre')) ?></button>
            </div>
            </div>
        </details>

        <details class="genpw-card genpw-accordion" data-role="access-panel" aria-labelledby="<?= dmdgp_h($instanceId) ?>_vault_title">
            <summary class="genpw-accordion-summary">
                <span class="genpw-card-title" id="<?= dmdgp_h($instanceId) ?>_vault_title"><?= dmdgp_h(dmdgp_t($tr, 'vault', 'Accès au coffre')) ?></span>
                <span class="genpw-accordion-arrow" aria-hidden="true">⌄</span>
            </summary>

            <div class="genpw-accordion-body">
            <div class="genpw-unlock" data-role="access-locked">
                <?php if (!empty($cfg['require_system_mfa'])): ?>
                <label class="genpw-field">
                    <span class="genpw-label">🛡️ <?= dmdgp_h(dmd_genpw_text('Code MFA DoMyDesk','DoMyDesk MFA code')) ?></span>
                    <input class="genpw-input" type="text" data-field="system-mfa-code" inputmode="numeric" pattern="[0-9]*" maxlength="8" autocomplete="one-time-code" placeholder="000000">
                </label>
                <p class="genpw-security-note">
                    <?= dmdgp_h(dmd_genpw_text('Utilise le MFA déjà configuré sur votre compte DoMyDesk. Quand cette protection est active, le code MFA suffit pour déverrouiller DMD-GenPW : le mot de passe n’est plus demandé. Aucun MFA séparé n’est créé pour DMD-GenPW.','Uses the MFA already configured on your DoMyDesk account. When this protection is enabled, the MFA code alone unlocks DMD-GenPW: no password is requested. No separate MFA is created for DMD-GenPW.')) ?>
                    <?php if (empty($cfg['system_mfa_enabled'])): ?>
                        <strong>⚠️ <?= dmdgp_h(dmd_genpw_text('MFA DoMyDesk actuellement désactivé.','DoMyDesk MFA is currently disabled.')) ?></strong>
                    <?php endif; ?>
                </p>
                <?php endif; ?>
                <label class="genpw-field"<?= !empty($cfg['require_system_mfa']) ? ' hidden' : '' ?>>
                    <span class="genpw-label"><?= dmdgp_h(dmdgp_t($tr, 'account_password', 'Mot de passe de verrouillage')) ?></span>
                    <input class="genpw-input" type="password" data-field="account-password" maxlength="4096" autocomplete="current-password" placeholder="<?= dmdgp_h(dmdgp_t($tr, 'unlock', 'Déverrouiller')) ?>">
                </label>
                <button class="genpw-btn is-primary" type="button" data-action="unlock">🔓 <?= dmdgp_h(dmdgp_t($tr, 'unlock', 'Déverrouiller')) ?></button>
                <p class="genpw-security-note"><?= dmdgp_h(dmdgp_t($tr, 'security_note', 'Le coffre se reverrouille automatiquement.')) ?> <strong><?= (int)$cfg['auto_lock_minutes'] ?> min</strong>.</p>
            </div>
            <div class="genpw-security-note" data-role="access-unlocked" hidden>
                🔓 <?= dmdgp_h(dmdgp_t($tr, 'unlocked_info', 'Coffre déverrouillé. Aucun nouveau mot de passe ne sera demandé avant le reverrouillage automatique.')) ?>
                <strong><?= (int)$cfg['auto_lock_minutes'] ?> min</strong>.
            </div>
            </div>
        </details>
    </div>

    <section class="genpw-vault" data-role="vault" hidden aria-label="Contenu du coffre">
        <div class="genpw-toolbar">
            <input class="genpw-input" type="search" data-field="search" placeholder="<?= dmdgp_h(dmdgp_t($tr, 'search', 'Rechercher…')) ?>" autocomplete="off">
            <button class="genpw-btn" type="button" data-action="refresh">↻ <?= dmdgp_h(dmdgp_t($tr, 'refresh', 'Actualiser')) ?></button>
        </div>

        <div class="genpw-bulk">
            <label class="genpw-check">
                <input type="checkbox" data-field="select-all">
                Tout sélectionner
            </label>
            <button class="genpw-btn is-danger" type="button" data-action="delete-selected">🗑 <?= dmdgp_h(dmdgp_t($tr, 'delete_selected', 'Supprimer la sélection')) ?></button>
        </div>

        <div class="genpw-tools">
            <button class="genpw-btn" type="button" data-action="categories">📂 <?= dmdgp_h(dmdgp_t($tr, 'categories', 'Catégories')) ?></button>
            <button class="genpw-btn" type="button" data-action="import">⇧ <?= dmdgp_h(dmdgp_t($tr, 'import', 'Importer')) ?></button>
            <button class="genpw-btn" type="button" data-action="export">⇩ <?= dmdgp_h(dmdgp_t($tr, 'export', 'Exporter')) ?></button>
            <button class="genpw-btn" type="button" data-action="logs">🧾 <?= dmdgp_h(dmdgp_t($tr, 'logs', 'Journal')) ?></button>
        </div>

        <div class="genpw-list" data-role="list"></div>
    </section>

    <div class="genpw-toast" data-role="toast" hidden aria-live="polite"></div>
</div>

<script>
(() => {
    'use strict';

    const root = document.getElementById(<?= json_encode($instanceId, JSON_UNESCAPED_SLASHES) ?>);
    if (!root || root.dataset.initialized === '1') return;
    root.dataset.initialized = '1';

    const TXT = <?= json_encode($tr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const PERMS = <?= json_encode($permissions, JSON_UNESCAPED_SLASHES) ?>;
    const DEFAULT_CATEGORY = <?= json_encode($cfg['default_category'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const INITIAL_CATEGORIES = <?= json_encode(dmd_genpw_categories($email), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const DEFAULT_CATEGORIES = <?= json_encode(dmd_genpw_active_default_categories($email), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const AUTO_LOCK_MINUTES = <?= (int)$cfg['auto_lock_minutes'] ?>;
    const MODULE_VERSION = <?= json_encode(DMD_GENPW_VERSION, JSON_UNESCAPED_SLASHES) ?>;
    const MYDESK_FULL = <?= $myDeskFull ? 'true' : 'false' ?>;
    const REQUIRE_SYSTEM_MFA = <?= !empty($cfg['require_system_mfa']) ? 'true' : 'false' ?>;
    const apiUrl = root.dataset.api;
    const qrUrl = root.dataset.qr;
    const webProxyUrl = root.dataset.webProxy;
    const csrf = root.dataset.csrf;
    const byRole = role => root.querySelector(`[data-role="${role}"]`);
    const byField = field => root.querySelector(`[data-field="${field}"]`);
    const byAction = action => root.querySelector(`[data-action="${action}"]`);

    const state = { preview: '', editingId: null, items: [], categories: Array.isArray(INITIAL_CATEGORIES) ? [...INITIAL_CATEGORIES] : [], defaultCategories: Array.isArray(DEFAULT_CATEGORIES) ? [...DEFAULT_CATEGORIES] : [], unlocked: false, toastTimer: null, autoLockTimer: null, revealTimers: new Map(), openCategories: new Set(), dragIds: [], suppressCardClickUntil: 0 };
    const statusEl = byRole('status');
    const vaultEl = byRole('vault');
    const entryPanel = byRole('entry-panel');
    const accessPanel = byRole('access-panel');
    const accessLockedEl = byRole('access-locked');
    const accessUnlockedEl = byRole('access-unlocked');
    const listEl = byRole('list');
    const previewEl = byRole('preview');
    const strengthBar = byRole('strength-bar');
    const strengthLabel = byRole('strength-label');
    const strengthTime = byRole('strength-time');
    let modal = null;
    let modalDialog = null;
    let modalTitle = null;
    let webBrowser = null;
    let webTabsBar = null;
    let webFramesHost = null;
    let webTabs = [];
    let activeWebTabId = null;
    let webTabSequence = 0;
    let webSessionToken = '';
    let webSessionExpiresAt = 0;
    let webProxyCheckedVersion = '';
    let qrImage = null;
    let modalPanel = null;
    const toastEl = byRole('toast');
    const entryTitleEl = byRole('entry-title');
    const saveButton = byAction('save');

    function t(key, fallback) { return Object.prototype.hasOwnProperty.call(TXT, key) ? TXT[key] : fallback; }
    function can(permission) { return PERMS[permission] !== false; }

    function mountExternalModal() {
        /* La popup ne doit jamais vivre dans le DOM draggable du module :
           sinon le clone/aperçu du dashboard peut embarquer la fenêtre complète. */
        document.querySelectorAll('[data-genpw-popup="1"][data-genpw-owner]').forEach(existing => {
            const ownerId = existing.getAttribute('data-genpw-owner') || '';
            const owner = ownerId ? document.getElementById(ownerId) : null;
            if (!owner || owner === root) existing.remove();
        });

        modal = document.createElement('div');
        modal.className = 'genpw-modal';
        modal.dataset.genpwPopup = '1';
        modal.dataset.genpwOwner = root.id;
        modal.hidden = true;
        modal.setAttribute('aria-hidden', 'true');

        modalDialog = document.createElement('div');
        modalDialog.className = 'genpw-modal-dialog';
        modalDialog.dataset.genpwPopup = '1';
        modalDialog.dataset.genpwOwner = root.id;
        modalDialog.hidden = true;
        modalDialog.setAttribute('aria-hidden', 'true');
        modalDialog.setAttribute('role', 'dialog');
        modalDialog.setAttribute('aria-modal', 'true');

        const head = document.createElement('div');
        head.className = 'genpw-modal-head';
        head.setAttribute('data-dmd-window-handle', '');

        modalTitle = document.createElement('h3');
        modalTitle.className = 'genpw-modal-title';
        modalTitle.id = `${root.id}_modal_title`;
        modalTitle.textContent = 'Aperçu';
        modalDialog.setAttribute('aria-labelledby', modalTitle.id);

        const closeButton = document.createElement('button');
        closeButton.className = 'genpw-btn';
        closeButton.type = 'button';
        closeButton.textContent = `✕ ${t('close', 'Fermer')}`;
        closeButton.addEventListener('click', closeModal);
        head.append(modalTitle, closeButton);

        const body = document.createElement('div');
        body.className = 'genpw-modal-body';

        webBrowser = document.createElement('div');
        webBrowser.className = 'genpw-web-browser';
        webBrowser.hidden = true;

        webTabsBar = document.createElement('div');
        webTabsBar.className = 'genpw-web-tabs';
        webTabsBar.setAttribute('role', 'tablist');
        webTabsBar.setAttribute('aria-label', t('web_tabs', 'Onglets web'));

        webFramesHost = document.createElement('div');
        webFramesHost.className = 'genpw-web-frames';
        webBrowser.append(webTabsBar, webFramesHost);

        qrImage = document.createElement('img');
        qrImage.className = 'genpw-qr-image';
        qrImage.alt = 'QR code à usage unique';
        qrImage.hidden = true;

        modalPanel = document.createElement('div');
        modalPanel.className = 'genpw-modal-panel';
        modalPanel.hidden = true;

        body.append(webBrowser, qrImage, modalPanel);
        modalDialog.append(head, body);
        modal.appendChild(modalDialog);
        document.body.appendChild(modal);

        modal.addEventListener('click', event => {
            if (event.target === modal) closeModal();
        });

        /* DMDWorkspace gère lui-même le z-index des fenêtres enregistrées.
           On ne modifie jamais les z-index des ancêtres/MyDesk depuis le module. */
        if (window.DMDWorkspace && typeof window.DMDWorkspace.registerPopup === 'function') {
            try {
                window.DMDWorkspace.registerPopup(modalDialog, {
                    key: `DMD-GenPW:${root.id}:popup`,
                    handle: '.genpw-modal-head'
                });
            } catch (_) {}
        }

        /* registerPopup peut portaliser la fenêtre. Le hidden est donc porté
           par le conteneur ET par la fenêtre elle-même. */
        modal.hidden = true;
        modalDialog.hidden = true;
        modalDialog.setAttribute('aria-hidden', 'true');
    }

    mountExternalModal();
    function toast(message, isError = false) {
        window.clearTimeout(state.toastTimer);
        toastEl.textContent = message;
        toastEl.classList.toggle('is-error', isError);
        toastEl.hidden = false;
        state.toastTimer = window.setTimeout(() => { toastEl.hidden = true; }, 3200);
    }
    function emitActivity(data) {
        if (!data || !data.activity) return;
        const detail = data.activity;
        try { window.dispatchEvent(new CustomEvent('dmd:resource-activity', { detail })); } catch (_) {}
        try { document.dispatchEvent(new CustomEvent('dmd:resource-activity', { detail })); } catch (_) {}
    }
    async function api(action, payload = {}) {
        const response = await fetch(apiUrl, {
            method: 'POST', credentials: 'same-origin', cache: 'no-store',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
            body: JSON.stringify({ action, ...payload })
        });
        let data;
        try { data = await response.json(); } catch (_) { throw new Error('Réponse serveur invalide (' + response.status + ').'); }
        if (!response.ok || data.error || data.ok === false) {
            if (data.locked || response.status === 423) setLocked();
            const error = new Error(data.error || t('error', 'Erreur'));
            error.data = data;
            throw error;
        }
        if (state.unlocked && !['status','bootstrap','unlock','lock'].includes(action)) scheduleAutoLock(AUTO_LOCK_MINUTES * 60);
        emitActivity(data);
        return data;
    }

    function scheduleAutoLock(seconds) {
        if (state.autoLockTimer) clearTimeout(state.autoLockTimer);
        state.autoLockTimer = null;
        if (!state.unlocked) return;
        const delay = Math.max(1, Number(seconds || (AUTO_LOCK_MINUTES * 60))) * 1000;
        state.autoLockTimer = setTimeout(() => setLocked(), delay);
    }
    function setUnlocked(expiresIn) {
        state.unlocked = true;
        statusEl.textContent = t('unlock', 'Déverrouillé').replace(/^Déverrouiller$/, 'Déverrouillé').replace(/^Unlock$/, 'Unlocked');
        statusEl.classList.add('is-unlocked');
        entryPanel.hidden = false;
        entryPanel.open = false;
        accessPanel.open = false;
        accessPanel.hidden = true;
        if (accessLockedEl) accessLockedEl.hidden = true;
        if (accessUnlockedEl) accessUnlockedEl.hidden = true;
        vaultEl.hidden = false;
        scheduleAutoLock(expiresIn);
        announceResize();
    }
    function setLocked() {
        state.unlocked = false;
        state.items = [];
        if (state.autoLockTimer) clearTimeout(state.autoLockTimer);
        state.autoLockTimer = null;
        statusEl.textContent = t('locked', 'Coffre verrouillé');
        statusEl.classList.remove('is-unlocked');
        entryPanel.open = false;
        entryPanel.hidden = true;
        accessPanel.hidden = false;
        accessPanel.open = false;
        if (accessLockedEl) accessLockedEl.hidden = false;
        if (accessUnlockedEl) accessUnlockedEl.hidden = true;
        vaultEl.hidden = true;
        listEl.replaceChildren();
        byField('select-all').checked = false;
        if (byField('account-password')) byField('account-password').value = '';
        webSessionToken = '';
        webSessionExpiresAt = 0;
        closeModal();
        announceResize();
    }

    function randomIndex(max) {
        if (!Number.isInteger(max) || max <= 0) throw new Error('Pool aléatoire invalide.');
        const limit = Math.floor(0x100000000 / max) * max;
        const buffer = new Uint32Array(1);
        do { window.crypto.getRandomValues(buffer); } while (buffer[0] >= limit);
        return buffer[0] % max;
    }
    function securePick(chars) { return chars[randomIndex(chars.length)]; }
    function secureShuffle(characters) {
        for (let index = characters.length - 1; index > 0; index--) {
            const swapIndex = randomIndex(index + 1);
            [characters[index], characters[swapIndex]] = [characters[swapIndex], characters[index]];
        }
        return characters.join('');
    }
    function generatePassword() {
        const lower = 'abcdefghijkmnopqrstuvwxyz';
        const upper = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        const numbers = '23456789';
        const special = '!@#$%&*?_+-=';
        const includeSpecial = byField('special').checked;
        const length = Math.max(12, Math.min(128, Number.parseInt(byField('length').value, 10) || 20));
        byField('length').value = String(length);
        const requiredPools = [lower, upper, numbers];
        if (includeSpecial) requiredPools.push(special);
        const fullPool = requiredPools.join('');
        const characters = requiredPools.map(securePick);
        while (characters.length < length) characters.push(securePick(fullPool));
        setPreview(secureShuffle(characters));
    }
    function setPreview(value) {
        state.preview = String(value || '');
        previewEl.value = state.preview;
        updateStrength(state.preview);
    }
    function updateStrength(password) {
        strengthBar.className = 'genpw-strength-fill';
        if (!password) { strengthLabel.textContent = t('strength_none', 'Robustesse non évaluée'); strengthTime.textContent = '—'; return; }
        let charset = 0;
        if (/[a-z]/.test(password)) charset += 26;
        if (/[A-Z]/.test(password)) charset += 26;
        if (/\d/.test(password)) charset += 10;
        if (/[^A-Za-z0-9]/.test(password)) charset += 32;
        let entropy = password.length * Math.log2(Math.max(charset, 1));
        if (/(.)\1{2,}/.test(password)) entropy -= 20;
        if (/1234|abcd|azerty|qwerty|password|admin/i.test(password)) entropy -= 35;
        entropy = Math.max(0, entropy);
        let level = 1, label = 'Faible';
        if (entropy >= 45) { level = 2; label = t('strength_medium', 'Moyen'); }
        if (entropy >= 70) { level = 3; label = 'Fort'; }
        if (entropy >= 95) { level = 4; label = t('strength_excellent', 'Excellent'); }
        strengthBar.classList.add(`level-${level}`);
        strengthLabel.textContent = `${label} · ~${Math.round(entropy)} bits`;
        strengthTime.textContent = formatCrackTime(entropy);
    }
    function formatCrackTime(entropy) {
        const log10Seconds = entropy * Math.LOG10E * Math.LN2 - 10;
        if (log10Seconds < 0) return t('time_instant', 'Moins d’une seconde');
        if (log10Seconds > 20) return t('millennia', 'Des millénaires');
        const seconds = 10 ** log10Seconds;
        const units = [[t('years','an(s)'),31557600],[t('days','jour(s)'),86400],[t('hours','heure(s)'),3600],[t('minutes','minute(s)'),60],[t('seconds','seconde(s)'),1]];
        for (const [name, divider] of units) if (seconds >= divider) return `~${Math.max(1, Math.floor(seconds / divider)).toLocaleString()} ${name}`;
        return t('time_instant', 'Moins d’une seconde');
    }
    function toggleCategoryFields() {
        const category = byField('category').value;
        byRole('url-field').hidden = category !== 'Site web';
        byRole('user-label').textContent = category === 'Wi-Fi' ? t('ssid','Nom du réseau (SSID)') : t('user','Identifiant / e-mail');
        byRole('manual-label').textContent = category === 'Wi-Fi' ? t('wifi_manual','Clé Wi-Fi existante') : t('manual','Mot de passe existant');
        byField('user').placeholder = category === 'Wi-Fi' ? t('ssid','Nom du réseau (SSID)') : 'nom@exemple.fr';
        announceResize();
    }
    async function copyText(text, button) {
        if (!text) return;
        try {
            if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
            else {
                const area = document.createElement('textarea');
                area.value = text; area.setAttribute('readonly', ''); area.style.position = 'fixed'; area.style.left = '-9999px';
                document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
            }
            if (button) { const original = button.innerHTML; button.textContent = '✓'; window.setTimeout(() => { button.innerHTML = original; }, 800); }
        } catch (_) { toast('Copie refusée par le navigateur.', true); }
    }

    function startEdit(item) {
        if (item.kind === 'shared' || !can('vault.edit')) return;
        state.editingId = item.id;
        entryTitleEl.textContent = t('edit','Modifier') + ' · ' + (item.name || '');
        saveButton.textContent = '💾 ' + t('update','Enregistrer les modifications');
        byField('name').value = item.name || '';
        byField('category').value = item.cat || 'Autre';
        byField('url').value = item.url || '';
        byField('user').value = item.user || '';
        byField('notes').value = item.notes || '';
        byField('manual').value = '';
        setPreview('');
        previewEl.placeholder = 'Laisser vide pour conserver le mot de passe actuel';
        toggleCategoryFields();
        entryPanel.hidden = false;
        entryPanel.open = true;
        entryPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    function resetEntryForm() {
        state.editingId = null;
        entryTitleEl.textContent = t('generator','Nouvelle entrée');
        saveButton.textContent = '💾 ' + t('save','Enregistrer dans le coffre');
        byField('name').value = '';
        byField('category').value = DEFAULT_CATEGORY;
        byField('url').value = '';
        byField('user').value = '';
        byField('notes').value = '';
        byField('manual').value = '';
        previewEl.placeholder = '';
        setPreview('');
        toggleCategoryFields();
    }
    async function saveEntry() {
        if (!state.unlocked) {
            toast(t('locked','Coffre verrouillé'), true);
            const unlockField = REQUIRE_SYSTEM_MFA ? byField('system-mfa-code') : byField('account-password');
            if (unlockField) unlockField.focus();
            return;
        }
        const editing = state.editingId !== null;
        if ((!editing && !can('vault.create')) || (editing && !can('vault.edit'))) return toast('Accès refusé.', true);
        if (!editing && !state.preview) return toast(t('empty_password','Mot de passe vide'), true);
        try {
            await api(editing ? 'update' : 'add', { id: editing ? state.editingId : undefined, name: byField('name').value, cat: byField('category').value, url: byField('url').value, user: byField('user').value, notes: byField('notes').value, pw: state.preview });
            toast(editing ? 'Entrée modifiée.' : 'Entrée enregistrée.');
            resetEntryForm();
            await loadList();
        } catch (error) { toast(error.message, true); }
    }
    async function unlockVault() {
        const passwordInput = byField('account-password');
        const mfaInput = byField('system-mfa-code');
        if (REQUIRE_SYSTEM_MFA) {
            if (!mfaInput || !String(mfaInput.value || '').trim()) {
                toast('Code MFA DoMyDesk requis.', true);
                if (mfaInput) mfaInput.focus();
                return;
            }
        } else if (!passwordInput || !passwordInput.value) {
            toast(t('empty_password','Mot de passe vide'), true);
            if (passwordInput) passwordInput.focus();
            return;
        }
        byAction('unlock').disabled = true;
        try {
            const result = await api('unlock', {
                pwd: REQUIRE_SYSTEM_MFA ? '' : (passwordInput ? passwordInput.value : ''),
                mfa_code: mfaInput ? mfaInput.value : ''
            });
            if (passwordInput) passwordInput.value = '';
            if (mfaInput) mfaInput.value = '';
            setUnlocked(result.expires_in); await loadList();
            toast(`${t('unlock','Déverrouiller')} · ${AUTO_LOCK_MINUTES} min`);
        } catch (error) { toast(error.message, true); } finally { byAction('unlock').disabled = false; }
    }
    function categoryLabel(category) {
        return TXT['cat_' + category] || category;
    }
    function updateCategorySelect(preferredValue = '') {
        const select = byField('category');
        if (!select) return;
        const current = preferredValue || select.value || DEFAULT_CATEGORY || 'Autre';
        const values = [...new Set((state.categories || []).filter(Boolean))];
        if (!values.includes(current)) values.push(current);
        select.replaceChildren();
        values.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = categoryLabel(category);
            select.appendChild(option);
        });
        select.value = values.includes(current) ? current : (values.includes(DEFAULT_CATEGORY) ? DEFAULT_CATEGORY : 'Autre');
        toggleCategoryFields();
    }
    function applyCategoryPayload(result, preferredValue = '') {
        if (result && Array.isArray(result.categories)) state.categories = [...result.categories];
        if (result && Array.isArray(result.defaults)) state.defaultCategories = [...result.defaults];
        updateCategorySelect(preferredValue);
    }
    async function loadCategories(preferredValue = '') {
        const result = await api('categories');
        applyCategoryPayload(result, preferredValue);
        return result;
    }
    async function loadList() {
        if (!can('vault.list')) return;
        try {
            const result = await api('list');
            state.items = Array.isArray(result.items) ? result.items : [];
            const discovered = state.items.map(item => String(item.cat || 'Autre')).filter(Boolean);
            state.categories = [...new Set([...(state.categories || []), ...discovered])];
            updateCategorySelect();
            renderList(filteredItems());
        } catch (error) { toast(error.message, true); }
    }
    function filteredItems() {
        const query = byField('search').value.trim().toLocaleLowerCase();
        if (!query) return state.items;
        return state.items.filter(item => [item.name, item.cat, item.user, item.url, item.notes, item.owner].some(value => String(value || '').toLocaleLowerCase().includes(query)));
    }
    function makeButton(text, title, handler, extraClass = '') {
        const button = document.createElement('button');
        button.type = 'button'; button.className = `genpw-btn is-icon ${extraClass}`.trim(); button.textContent = text; button.title = title; button.addEventListener('click', handler); return button;
    }
    function renderList(items) {
        listEl.replaceChildren(); byField('select-all').checked = false;
        if (!items.length) { const empty = document.createElement('p'); empty.className = 'genpw-empty'; empty.textContent = t('empty','Aucune entrée.'); listEl.appendChild(empty); announceResize(); return; }
        const groups = new Map();
        items.forEach(item => { const category = item.cat || 'Autre'; if (!groups.has(category)) groups.set(category, []); groups.get(category).push(item); });
        groups.forEach((groupItems, category) => {
            const details = document.createElement('details');
            details.className = 'genpw-folder';
            details.dataset.category = category;
            details.open = byField('search').value.trim() !== '' || state.openCategories.has(category);
            details.addEventListener('toggle', () => {
                if (details.open) state.openCategories.add(category); else state.openCategories.delete(category);
            });

            const summary = document.createElement('summary');
            summary.dataset.dropCategory = category;
            const title = document.createElement('span'); title.textContent = `📂 ${categoryLabel(category)}`;
            const count = document.createElement('span'); count.className = 'genpw-count'; count.textContent = `${groupItems.length} ${t('entries','entrée(s)')}`;
            summary.append(title, count);

            if (can('vault.edit')) {
                const markDrop = event => {
                    if (!state.dragIds.length) return;
                    event.preventDefault();
                    if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
                    details.classList.add('is-drop-target');
                };
                summary.addEventListener('dragenter', markDrop);
                summary.addEventListener('dragover', markDrop);
                summary.addEventListener('dragleave', event => {
                    if (!summary.contains(event.relatedTarget)) details.classList.remove('is-drop-target');
                });
                summary.addEventListener('drop', async event => {
                    event.preventDefault(); event.stopPropagation(); details.classList.remove('is-drop-target');
                    const ids = [...state.dragIds]; state.dragIds = [];
                    await moveItemsToCategory(ids, category);
                });
            }

            const body = document.createElement('div'); body.className = 'genpw-folder-body'; groupItems.forEach(item => body.appendChild(renderItem(item)));
            details.append(summary, body); listEl.appendChild(details);
        });
        decorateActionHub(); announceResize();
    }
    function renderItem(item) {
        const row = document.createElement('article');
        row.className = 'genpw-item' + (item.kind === 'shared' ? ' is-shared' : ''); row.dataset.id = item.id;
        row.dataset.dmdModuleId = 'DMD-GenPW'; row.dataset.dmdContextType = 'credential'; row.dataset.dmdContextId = `DMD-GenPW:credential:${item.id}`; row.dataset.dmdContextName = item.name || 'Identifiant'; row.dataset.dmdActionHub = '1';

        const checkbox = document.createElement('input'); checkbox.type = 'checkbox'; checkbox.className = 'genpw-select-item'; checkbox.value = item.id; checkbox.setAttribute('aria-label', `Sélectionner ${item.name}`);
        if (item.kind === 'shared' || !can('vault.delete')) { checkbox.disabled = true; checkbox.hidden = true; }

        const main = document.createElement('div'); main.className = 'genpw-item-main';
        const name = document.createElement('div'); name.className = 'genpw-item-name'; name.textContent = item.name || 'Sans nom'; name.title = item.name || 'Sans nom';
        main.appendChild(name);

        if (item.user) {
            const userLine = document.createElement('div');
            userLine.className = 'genpw-vignette-user'; userLine.title = `Identifiant : ${item.user}`;
            const userValue = document.createElement('span'); userValue.textContent = item.user;
            userLine.appendChild(userValue);
            main.appendChild(userLine);
        } else {
            const userLine = document.createElement('div'); userLine.className = 'genpw-vignette-user is-empty'; userLine.textContent = 'Aucun identifiant';
            main.appendChild(userLine);
        }

        const meta = document.createElement('div'); meta.className = 'genpw-item-meta';
        const compactNote = String(item.notes || '').replace(/\s+/g, ' ').trim();
        const compactUrl = String(item.url || '').replace(/^https?:\/\//i, '').replace(/\/$/, '');
        const bits = [item.date, compactNote || compactUrl].filter(Boolean);
        if (item.kind === 'shared') bits.push(`${t('shared_by','Partagé par')} ${item.owner || '—'}`);
        meta.textContent = bits.join(' · ') || categoryLabel(item.cat || 'Autre');
        meta.title = bits.join(' · ');
        main.appendChild(meta);

        const buttons = document.createElement('div'); buttons.className = 'genpw-item-buttons';
        if (can('vault.reveal')) {
            const reveal = document.createElement('button');
            reveal.type = 'button'; reveal.className = 'genpw-vignette-action'; reveal.title = t('reveal','Afficher le mot de passe'); reveal.setAttribute('aria-label', `${t('reveal','Afficher')} · ${item.name || ''}`); reveal.textContent = '👁';
            reveal.addEventListener('click', async event => {
                event.stopPropagation();
                if (reveal.disabled) return;
                reveal.disabled = true;
                try { showCredentialPopover('Mot de passe', await getSecret(item), reveal, true); }
                catch (error) { toast(error.message, true); }
                finally { reveal.disabled = false; }
            });
            buttons.appendChild(reveal);
        }

        const menu = document.createElement('details'); menu.className = 'genpw-entry-menu'; menu.dataset.genpwEntryMenu = '1';
        const trigger = document.createElement('summary'); trigger.className = 'genpw-entry-menu-trigger'; trigger.title = t('actions','Actions'); trigger.setAttribute('aria-label', `${t('actions','Actions')} · ${item.name || ''}`); trigger.textContent = '•••';
        const panel = document.createElement('div'); panel.className = 'genpw-entry-menu-panel';

        const menuAction = (icon, label, handler, extraClass = '') => {
            const button = document.createElement('button'); button.type = 'button'; button.className = `genpw-entry-menu-action ${extraClass}`.trim(); button.title = label;
            const iconEl = document.createElement('span'); iconEl.className = 'genpw-entry-menu-icon'; iconEl.textContent = icon;
            const labelEl = document.createElement('span'); labelEl.className = 'genpw-entry-menu-label'; labelEl.textContent = label;
            button.append(iconEl, labelEl);
            button.addEventListener('click', event => { menu.open = false; handler(event); });
            return button;
        };

        if (can('vault.reveal')) panel.appendChild(menuAction('📋', t('copy','Copier le mot de passe'), event => copySecret(item, event.currentTarget)));
        const hasEntryActions = (item.kind !== 'shared' && can('vault.edit')) || Boolean(item.user) || Boolean(item.url) || can('vault.qr') || (item.kind !== 'shared' && can('vault.share'));
        if (panel.childElementCount && hasEntryActions) { const separator = document.createElement('div'); separator.className = 'genpw-entry-menu-separator'; panel.appendChild(separator); }
        if (item.kind !== 'shared' && can('vault.edit')) panel.appendChild(menuAction('✏️', t('edit','Modifier'), () => startEdit(item)));
        if (item.user) panel.appendChild(menuAction('ID', t('copy_user','Copier l’identifiant'), event => copyText(item.user, event.currentTarget)));
        if (item.url) panel.appendChild(menuAction('🌐', t('website','Ouvrir le site'), () => openWebsite(item.url, item.name)));
        if (can('vault.qr')) panel.appendChild(menuAction('QR', t('qr','QR 60 s'), () => showQr(item)));
        if (item.kind !== 'shared' && can('vault.share')) panel.appendChild(menuAction('↗', t('share','Partager'), () => openShare(item)));

        menu.addEventListener('toggle', () => {
            if (!menu.open) return;
            root.querySelectorAll('.genpw-entry-menu[open]').forEach(other => { if (other !== menu) other.open = false; });
            const rect = trigger.getBoundingClientRect();
            menu.classList.toggle('opens-up', (window.innerHeight - rect.bottom) < 250 && rect.top > 250);
        });
        menu.append(trigger, panel); buttons.appendChild(menu);
        if (item.kind === 'shared') { const badge = document.createElement('span'); badge.className = 'genpw-share-badge'; badge.textContent = t('read_only','Lecture seule'); main.appendChild(badge); }
        row.append(checkbox, main, buttons);

        checkbox.addEventListener('click', event => event.stopPropagation());
        checkbox.addEventListener('change', () => row.classList.toggle('is-selected', checkbox.checked));

        if (item.kind !== 'shared' && can('vault.edit')) {
            row.draggable = true;
            row.title = 'Cliquer pour afficher les informations · Glisser vers une catégorie pour déplacer';
            row.addEventListener('dragstart', event => {
                if (event.target && event.target.closest && event.target.closest('button,input,a')) { event.preventDefault(); return; }
                const selectedIds = [...root.querySelectorAll('.genpw-select-item:checked:not(:disabled)')].map(input => input.value);
                state.dragIds = checkbox.checked && selectedIds.length ? selectedIds : [item.id];
                if (!checkbox.checked) {
                    root.querySelectorAll('.genpw-item.is-dragging').forEach(node => node.classList.remove('is-dragging'));
                }
                state.dragIds.forEach(id => { const card = root.querySelector(`.genpw-item[data-id="${id}"]`); if (card) card.classList.add('is-dragging'); });
                if (event.dataTransfer) {
                    event.dataTransfer.effectAllowed = 'move';
                    event.dataTransfer.setData('text/plain', state.dragIds.join(','));
                }
            });
            row.addEventListener('dragend', () => {
                state.suppressCardClickUntil = Date.now() + 250;
                state.dragIds = [];
                root.querySelectorAll('.genpw-item.is-dragging').forEach(node => node.classList.remove('is-dragging'));
                root.querySelectorAll('.genpw-folder.is-drop-target').forEach(node => node.classList.remove('is-drop-target'));
            });
        } else {
            row.title = 'Cliquer pour afficher les informations';
        }

        row.addEventListener('click', event => {
            if (Date.now() < state.suppressCardClickUntil) return;
            if (event.target && event.target.closest && event.target.closest('button,input,summary,a,.genpw-entry-menu')) return;
            openCredentialDetails(item);
        });
        return row;
    }

    async function moveItemsToCategory(ids, category) {
        const cleanIds = [...new Set((ids || []).map(String).filter(Boolean))];
        if (!cleanIds.length || !category) return;
        const movable = cleanIds.filter(id => {
            const item = state.items.find(candidate => candidate.id === id);
            return item && item.kind !== 'shared' && String(item.cat || 'Autre') !== String(category);
        });
        if (!movable.length) return;
        try {
            const result = await api('move_category', { ids: movable, category });
            state.openCategories.add(category);
            toast(`${result.moved || movable.length} identifiant(s) déplacé(s) vers ${categoryLabel(category)}.`);
            await loadList();
        } catch (error) { toast(error.message, true); }
    }

    function detailLine(label, value, options = {}) {
        const line = el('div','genpw-detail-line');
        const key = el('div','genpw-detail-label',label);
        const val = el(options.multiline ? 'div' : 'div','genpw-detail-value',value || '—');
        if (options.multiline) val.classList.add('is-multiline');
        line.append(key,val);
        return { line, value: val };
    }

    function openCredentialDetails(item) {
        modalPanel.replaceChildren();
        const wrap = el('div','genpw-credential-details');
        const grid = el('div','genpw-detail-grid');
        grid.appendChild(detailLine('Nom', item.name || 'Sans nom').line);
        grid.appendChild(detailLine('Catégorie', categoryLabel(item.cat || 'Autre')).line);
        grid.appendChild(detailLine('Identifiant / e-mail', item.user || '—').line);
        grid.appendChild(detailLine('Adresse / URL', item.url || '—').line);
        grid.appendChild(detailLine('Date', item.date || '—').line);
        if (item.kind === 'shared') grid.appendChild(detailLine('Partagé par', item.owner || '—').line);
        if (item.notes) grid.appendChild(detailLine('Notes', item.notes, { multiline: true }).line);

        const passwordLine = el('div','genpw-detail-line genpw-detail-password');
        const passwordLabel = el('div','genpw-detail-label','Mot de passe');
        const passwordValue = el('div','genpw-detail-value is-password','************');
        passwordValue.dataset.masked = '1';
        const passwordActions = el('div','genpw-detail-password-actions');
        if (can('vault.reveal')) {
            const reveal = el('button','genpw-btn','👁 Afficher'); reveal.type='button';
            const copy = el('button','genpw-btn','📋 Copier'); copy.type='button'; copy.hidden=true;
            let secret = '';
            reveal.addEventListener('click', async () => {
                if (passwordValue.dataset.masked === '0') {
                    passwordValue.textContent = '************'; passwordValue.dataset.masked='1'; reveal.textContent='👁 Afficher'; copy.hidden=true; secret=''; return;
                }
                reveal.disabled=true;
                try { secret = await getSecret(item); passwordValue.textContent = secret || '—'; passwordValue.dataset.masked='0'; reveal.textContent='🙈 Masquer'; copy.hidden=false; }
                catch(error){ toast(error.message,true); }
                finally { reveal.disabled=false; }
            });
            copy.addEventListener('click', event => { if (secret) copyText(secret,event.currentTarget); });
            passwordActions.append(reveal,copy);
        }
        passwordLine.append(passwordLabel,passwordValue,passwordActions);
        grid.appendChild(passwordLine);
        wrap.appendChild(grid);

        const actions = el('div','genpw-detail-actions');
        if (item.user) { const copyUser=el('button','genpw-btn','ID Copier l’identifiant'); copyUser.type='button'; copyUser.addEventListener('click',event=>copyText(item.user,event.currentTarget)); actions.appendChild(copyUser); }
        if (item.url) { const website=el('button','genpw-btn','🌐 Ouvrir le site'); website.type='button'; website.addEventListener('click',()=>openWebsite(item.url,item.name)); actions.appendChild(website); }
        if (item.kind !== 'shared' && can('vault.edit')) { const edit=el('button','genpw-btn is-primary','✏ Modifier'); edit.type='button'; edit.addEventListener('click',()=>{ closeModal(); startEdit(item); }); actions.appendChild(edit); }
        if (actions.childElementCount) wrap.appendChild(actions);

        modalPanel.appendChild(wrap);
        openModal(item.name || 'Identifiant','panel');
        modalDialog.classList.add('is-credential-details');
    }

    async function getSecret(item) { const result = await api('get_secret', { id: item.id, kind: item.kind || 'owned' }); return String(result.secret || ''); }
    function setSecretToggleState(button, visible) {
        if (!button) return;
        const icon = button.querySelector('.genpw-entry-menu-icon');
        const label = button.querySelector('.genpw-entry-menu-label');
        const text = visible ? t('hide','Masquer') : t('reveal','Afficher');
        if (icon) icon.textContent = visible ? '🙈' : '👁';
        if (label) label.textContent = text;
        button.title = text;
    }
    async function toggleSecret(item, code, button) {
        if (code.dataset.visible === '1') { hideSecret(item.id, code, button); return; }
        if (button) button.disabled = true;
        try { const secret = await getSecret(item); code.textContent = secret; code.dataset.visible = '1'; setSecretToggleState(button, true); window.clearTimeout(state.revealTimers.get(item.id)); state.revealTimers.set(item.id, window.setTimeout(() => hideSecret(item.id, code, button), 20000)); } catch (error) { toast(error.message, true); } finally { if (button) button.disabled = false; }
    }
    function hideSecret(id, code, button) { window.clearTimeout(state.revealTimers.get(id)); state.revealTimers.delete(id); code.textContent = '••••••••••••'; code.dataset.visible = '0'; setSecretToggleState(button, false); }
    async function copySecret(item, button) { button.disabled = true; try { await copyText(await getSecret(item), button); } catch (error) { toast(error.message, true); } finally { button.disabled = false; } }

    let credentialPopover = null;
    let credentialPopoverTimer = null;

    function closeCredentialPopover() {
        if (credentialPopoverTimer) window.clearTimeout(credentialPopoverTimer);
        credentialPopoverTimer = null;
        if (credentialPopover) credentialPopover.remove();
        credentialPopover = null;
    }

    function positionCredentialPopover(popover, anchor) {
        if (!popover || !anchor || !anchor.isConnected) return;
        const rect = anchor.getBoundingClientRect();
        const gap = 6;
        const width = Math.min(300, Math.max(220, popover.offsetWidth || 260));
        let left = rect.right - width;
        left = Math.max(8, Math.min(left, window.innerWidth - width - 8));
        let top = rect.bottom + gap;
        const height = popover.offsetHeight || 112;
        if (top + height > window.innerHeight - 8 && rect.top - height - gap >= 8) {
            top = rect.top - height - gap;
        }
        popover.style.left = `${Math.round(left)}px`;
        popover.style.top = `${Math.round(Math.max(8, top))}px`;
    }

    function showCredentialPopover(label, value, anchor, sensitive = false) {
        closeCredentialPopover();

        const popover = document.createElement('div');
        popover.className = 'genpw-credential-popover';
        popover.setAttribute('role', 'dialog');
        popover.setAttribute('aria-label', label);
        popover.dataset.genpwCredentialPopover = '1';

        const head = document.createElement('div');
        head.className = 'genpw-credential-popover-head';
        const caption = document.createElement('strong');
        caption.textContent = label;
        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'genpw-credential-popover-close';
        close.textContent = '×';
        close.title = 'Fermer';
        close.addEventListener('click', event => { event.stopPropagation(); closeCredentialPopover(); });
        head.append(caption, close);

        const code = document.createElement('code');
        code.className = 'genpw-credential-popover-value';
        code.textContent = String(value || '');

        const actions = document.createElement('div');
        actions.className = 'genpw-credential-popover-actions';
        const copy = document.createElement('button');
        copy.type = 'button';
        copy.className = 'genpw-credential-popover-copy';
        copy.textContent = '📋 Copier';
        copy.addEventListener('click', async event => {
            event.stopPropagation();
            await copyText(String(value || ''), event.currentTarget);
        });
        actions.appendChild(copy);

        popover.append(head, code, actions);
        popover.addEventListener('pointerdown', event => event.stopPropagation());
        document.body.appendChild(popover);
        credentialPopover = popover;
        positionCredentialPopover(popover, anchor);

        const reposition = () => {
            if (credentialPopover === popover) positionCredentialPopover(popover, anchor);
        };
        window.addEventListener('resize', reposition, { once: true });

        if (sensitive) {
            credentialPopoverTimer = window.setTimeout(() => {
                if (credentialPopover !== popover) return;
                code.textContent = '';
                closeCredentialPopover();
            }, 20000);
        }
    }

    document.addEventListener('pointerdown', event => {
        if (credentialPopover && !credentialPopover.contains(event.target)) closeCredentialPopover();
    }, true);
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape') closeCredentialPopover();
    });

    function closeEntryMenus() { root.querySelectorAll('.genpw-entry-menu[open]').forEach(menu => { menu.open = false; }); }
    document.addEventListener('pointerdown', event => { if (!root.contains(event.target)) closeEntryMenus(); }, true);

    function normaliseWebUrl(rawUrl, baseUrl = window.location.href) {
        const url = new URL(rawUrl, baseUrl);
        if (!['http:', 'https:'].includes(url.protocol)) throw new Error('URL invalide ou non autorisée.');
        return url;
    }
    async function ensureWebProxyReady() {
        if (webProxyCheckedVersion === MODULE_VERSION) return true;
        let response;
        try {
            const sep = webProxyUrl.includes('?') ? '&' : '?';
            response = await fetch(`${webProxyUrl}${sep}__dmdgp_health=1&_=${Date.now()}`, {
                method: 'GET', credentials: 'same-origin', cache: 'no-store'
            });
        } catch (_) {
            throw new Error('Le navigateur intégré DMD-GenPW est introuvable. Réinstallez le module complet.');
        }
        let data = null;
        try { data = await response.json(); } catch (_) {}
        const proxyVersion = data && data.proxy_version ? String(data.proxy_version) : '';
        if (proxyVersion && proxyVersion !== MODULE_VERSION) {
            throw new Error(`Le fichier dmd-genpw_web_proxy.php n’est pas à jour (attendu ${MODULE_VERSION}, présent ${proxyVersion}). Réinstallez le module complet.`);
        }
        if (response.status === 401 || (data && data.error === 'not_authenticated')) {
            throw new Error('La session DoMyDesk n’est pas reconnue par le navigateur intégré. Rechargez DoMyDesk puis réessayez.');
        }
        if (!response.ok || !data || data.ok !== true) {
            const detail = data && data.error ? ` (${String(data.error)})` : '';
            throw new Error(`Le navigateur intégré DMD-GenPW ne répond pas correctement${detail}.`);
        }
        if (!proxyVersion) {
            throw new Error('Le navigateur intégré DMD-GenPW ne fournit pas sa version. Réinstallez le module complet.');
        }
        webProxyCheckedVersion = proxyVersion;
        return true;
    }
    async function ensureWebSession() {
        if (webSessionToken && Date.now() < (webSessionExpiresAt - 5000)) return webSessionToken;
        const result = await api('web_session');
        const token = String(result.token || '');
        if (!/^[a-f0-9]{64}$/.test(token)) throw new Error('Session de navigation DMD-GenPW invalide.');
        webSessionToken = token;
        webSessionExpiresAt = Date.now() + (Math.max(30, Number(result.expires_in || (AUTO_LOCK_MINUTES * 60))) * 1000);
        return token;
    }
    async function signedWebProxyUrl(rawUrl, mode = 'full') {
        const url = normaliseWebUrl(rawUrl);
        await ensureWebSession();
        const result = await api('web_target', { web_token: webSessionToken, url: url.href });
        const signature = String(result.signature || '');
        if (!/^[a-f0-9]{64}$/.test(signature)) throw new Error('Autorisation de navigation invalide.');
        return `${webProxyUrl}?__dmdgp_session=${encodeURIComponent(webSessionToken)}&__dmdgp_target=${encodeURIComponent(url.href)}&__dmdgp_sig=${encodeURIComponent(signature)}${mode === 'compat' ? '&__dmdgp_mode=compat' : ''}`;
    }
    function webOriginIsAllowed(next, current) {
        if (next.origin === current.origin) return true;
        return state.items.some(item => {
            if (!item || !item.url) return false;
            try { return normaliseWebUrl(item.url).origin === next.origin; } catch (_) { return false; }
        });
    }
    function renderWebTabs() {
        if (!webTabsBar) return;
        webTabsBar.replaceChildren();
        webTabs.forEach(tab => {
            const tabButton = document.createElement('button'); tabButton.type = 'button'; tabButton.className = 'genpw-web-tab'; tabButton.setAttribute('role', 'tab'); tabButton.setAttribute('aria-selected', tab.id === activeWebTabId ? 'true' : 'false');
            const label = document.createElement('span'); label.className = 'genpw-web-tab-label'; label.textContent = tab.title || tab.url.hostname || t('website','Site web');
            const close = document.createElement('span'); close.className = 'genpw-web-tab-close'; close.textContent = '×'; close.title = t('close','Fermer');
            tabButton.append(label, close);
            tabButton.addEventListener('click', event => {
                if (event.target === close) { event.stopPropagation(); closeWebTab(tab.id); return; }
                activateWebTab(tab.id);
            });
            webTabsBar.appendChild(tabButton);
        });
    }
    function activateWebTab(id) {
        activeWebTabId = id;
        webTabs.forEach(tab => { tab.frame.hidden = tab.id !== id; tab.frame.style.display = tab.id === id ? 'block' : 'none'; });
        renderWebTabs();
        const active = webTabs.find(tab => tab.id === id);
        if (active && modalTitle) modalTitle.textContent = active.title || t('website','Site web');
    }
    function closeWebTab(id) {
        const index = webTabs.findIndex(tab => tab.id === id);
        if (index < 0) return;
        const [tab] = webTabs.splice(index, 1); tab.frame.src = 'about:blank'; tab.frame.remove();
        if (!webTabs.length) { closeModal(); return; }
        if (activeWebTabId === id) activateWebTab(webTabs[Math.min(index, webTabs.length - 1)].id); else renderWebTabs();
    }
    function resetWebTabs() {
        webTabs.forEach(tab => { try { tab.frame.src = 'about:blank'; } catch (_) {} tab.frame.remove(); });
        webTabs = []; activeWebTabId = null; if (webTabsBar) webTabsBar.replaceChildren();
    }
    function tabForMessageSource(source) {
        return webTabs.find(tab => tab.frame && tab.frame.contentWindow === source) || null;
    }
    function setWebBanner(message = '') {
        let banner = webFramesHost.querySelector('[data-role=web-runtime-error]');
        if (!message) { if (banner) banner.remove(); return; }
        if (!banner) {
            banner = document.createElement('div');
            banner.className = 'genpw-web-runtime-error';
            banner.dataset.role = 'web-runtime-error';
            webFramesHost.prepend(banner);
        }
        banner.textContent = message;
    }
    async function switchWebTabToCompat(tab, reason = '') {
        if (!tab || tab.mode === 'compat' || tab.compatLoading) return;
        tab.compatLoading = true;
        try {
            setWebBanner('↻ Chargement du site en mode compatibilité…');
            const proxyUrl = await signedWebProxyUrl(tab.url.href, 'compat');
            tab.mode = 'compat';
            tab.readySeen = false;
            tab.frame.src = proxyUrl;
        } catch (error) {
            setWebBanner(`⚠ ${error && error.message ? error.message : 'Navigation intégrée indisponible.'}`);
        } finally {
            tab.compatLoading = false;
        }
    }
    async function handleWebBridgeMessage(event) {
        const data = event && event.data;
        if (!data || data.dmdGenPw !== true || typeof data.type !== 'string') return;
        const tab = tabForMessageSource(event.source);
        if (!tab) return;

        if (data.type === 'ready' || data.type === 'navigate' || data.type === 'render-state') {
            try { if (data.url) tab.url = normaliseWebUrl(String(data.url), tab.url.href); } catch (_) {}
            if (String(data.title || '').trim()) tab.title = String(data.title).trim();
            if (data.mode === 'compat' || data.mode === 'full') tab.mode = data.mode;
            tab.readySeen = true;
            renderWebTabs();
            if (tab.id === activeWebTabId && modalTitle) modalTitle.textContent = tab.title || t('website','Site web');

            const visibleTextLength = Number(data.visibleTextLength || 0);
            const textLength = Number(data.textLength || 0);
            const childCount = Number(data.childCount || 0);
            if (data.type === 'render-state') {
                if (tab.mode !== 'compat' && visibleTextLength === 0 && (textLength > 0 || childCount > 0)) {
                    window.setTimeout(() => switchWebTabToCompat(tab, 'page-invisible'), 150);
                } else if (tab.mode === 'compat' && visibleTextLength === 0 && textLength === 0 && childCount === 0) {
                    setWebBanner('⚠ Le site répond, mais il ne renvoie aucun contenu affichable dans la navigation intégrée.');
                } else {
                    setWebBanner('');
                }
            }
            return;
        }
        if (data.type === 'open-tab' || data.type === 'navigate-request') {
            try {
                const next = normaliseWebUrl(String(data.url || ''), tab.url.href);
                if (!webOriginIsAllowed(next, tab.url)) throw new Error('Destination web non autorisée : ajoutez d’abord ce site dans GenPW.');
                const proxyUrl = await signedWebProxyUrl(next.href);
                const nextTitle = String(data.title || '').trim() || next.hostname;
                const newTab = data.type === 'open-tab' || data.newTab === true;
                if (newTab) {
                    addWebTab(next.href, nextTitle, true, proxyUrl);
                } else {
                    tab.url = next;
                    if (nextTitle) tab.title = nextTitle;
                    tab.mode = 'full'; tab.readySeen = false; tab.runtimeErrors = 0;
                    setWebBanner('↻ Chargement…');
                    tab.frame.src = proxyUrl;
                    renderWebTabs();
                    if (tab.id === activeWebTabId && modalTitle) modalTitle.textContent = tab.title || t('website','Site web');
                }
            } catch (error) { toast(error && error.message ? error.message : 'URL invalide ou non autorisée.', true); }
            return;
        }
        if (data.type === 'runtime-error' && data.message) {
            tab.runtimeErrors = (tab.runtimeErrors || 0) + 1;
            if (tab.mode !== 'compat' && tab.runtimeErrors <= 2) {
                window.setTimeout(() => switchWebTabToCompat(tab, 'runtime-error'), 120);
                return;
            }
            const active = webTabs.find(item => item.id === activeWebTabId);
            if (active && active.frame && event.source === active.frame.contentWindow) {
                setWebBanner(`⚠ ${String(data.message)}`);
            }
            return;
        }
        if (data.type === 'error' && data.message) toast(String(data.message), true);
    }
    window.addEventListener('message', handleWebBridgeMessage, false);

    function addWebTab(rawUrl, title = '', activate = true, proxySource = '') {
        const url = normaliseWebUrl(rawUrl);
        const id = `web_${++webTabSequence}`;
        const frame = document.createElement('iframe');
        frame.className = 'genpw-frame';
        frame.title = title || url.hostname || 'Site web';
        frame.referrerPolicy = 'no-referrer';
        frame.setAttribute('allow', 'clipboard-read; clipboard-write; fullscreen');
        /* Le contenu distant passe par le relais du module. L'iframe reste sandboxée sans
           allow-popups : un target="_blank" ne peut plus créer un onglet Brave/Chrome.
           Le pont injecté par le relais transforme ces ouvertures en onglets DMD-GenPW. */
        frame.setAttribute('sandbox', 'allow-scripts allow-forms allow-downloads allow-modals allow-pointer-lock allow-presentation');
        if (!proxySource) throw new Error('Navigation web DMD-GenPW non autorisée.');
        const tab = { id, url, title: title || url.hostname, frame, mode: proxySource.includes('__dmdgp_mode=compat') ? 'compat' : 'full', readySeen: false, runtimeErrors: 0, compatLoading: false };
        webTabs.push(tab);
        webFramesHost.appendChild(frame);
        setWebBanner('↻ Chargement…');
        frame.addEventListener('load', () => {
            window.setTimeout(() => {
                if (!tab.readySeen && tab.mode !== 'compat') switchWebTabToCompat(tab, 'bridge-timeout');
                else if (!tab.readySeen && tab.mode === 'compat') setWebBanner('⚠ Le site a répondu mais son contenu n’a pas pu être initialisé.');
            }, 1800);
        });
        frame.src = proxySource;
        if (activate) activateWebTab(id); else { frame.hidden = true; frame.style.display = 'none'; renderWebTabs(); }
        return tab;
    }

    function openModal(title, mode) {
        const showWebsite = mode === 'web', showQr = mode === 'qr', showPanel = mode === 'panel';
        modalTitle.textContent = title; modalDialog.classList.toggle('is-qr', showQr); modalDialog.classList.toggle('is-panel', showPanel);
        webBrowser.hidden = !showWebsite; webBrowser.style.display = showWebsite ? 'flex' : 'none';
        qrImage.hidden = !showQr; qrImage.style.display = showQr ? 'block' : 'none';
        modalPanel.hidden = !showPanel; modalPanel.style.display = showPanel ? 'block' : 'none';

        modalDialog.hidden = false;
        modalDialog.setAttribute('aria-hidden', 'false');
        /* registerPopup installe le bring-to-front sur pointerdown. On le déclenche
           à l'ouverture, sans écraser les z-index du dashboard ou des autres modules. */
        try { modalDialog.dispatchEvent(new Event('pointerdown', { bubbles: true })); } catch (_) {}
        /* Si DoMyDesk a portalé la popup dans le workspace, on n'affiche surtout pas
           l'ancien overlay vide. Sinon on garde le fallback centré classique. */
        const managedByWorkspace = modalDialog.dataset.dmdWindowManaged === '1' || modalDialog.parentElement !== modal;
        modal.hidden = managedByWorkspace;
        modal.setAttribute('aria-hidden', managedByWorkspace ? 'true' : 'false');
    }
    function closeModal() {
        modal.hidden = true;
        modal.setAttribute('aria-hidden', 'true');
        modalDialog.hidden = true;
        modalDialog.setAttribute('aria-hidden', 'true');
        webBrowser.hidden = true; webBrowser.style.display = 'none'; resetWebTabs(); qrImage.hidden = true; qrImage.style.display = 'none'; qrImage.removeAttribute('src'); modalPanel.hidden = true; modalPanel.style.display = 'none'; modalPanel.replaceChildren(); modalDialog.classList.remove('is-qr','is-panel','is-category-manager','is-credential-details');
    }
    async function openWebsite(rawUrl, title) {
        try {
            const url = normaliseWebUrl(rawUrl);
            await ensureWebProxyReady();
            await ensureWebSession();
            const webAlreadyOpen = modalDialog && !modalDialog.hidden && webBrowser && !webBrowser.hidden;
            if (!webAlreadyOpen) resetWebTabs();
            const proxyUrl = await signedWebProxyUrl(url.href);
            addWebTab(url.href, title || url.hostname || t('website','Site web'), true, proxyUrl);
            openModal(title || t('website','Site web'), 'web');
        } catch (error) { toast(error && error.message ? error.message : 'URL invalide ou non autorisée.', true); }
    }
    async function showQr(item) {
        try { const result = await api('get_qr', { id: item.id, kind: item.kind || 'owned' }); qrImage.src = `${qrUrl}?t=${encodeURIComponent(result.token)}&_=${Date.now()}`; openModal(`QR · ${item.name || ''}`, 'qr'); } catch (error) { toast(error.message, true); }
    }

    function el(tag, className, text) { const node = document.createElement(tag); if (className) node.className = className; if (text !== undefined) node.textContent = text; return node; }
    async function openCategoryManager() {
        try {
            const result = await loadCategories();
            const custom = Array.isArray(result.custom) ? result.custom : [];
            const defaults = Array.isArray(result.defaults) ? result.defaults : state.defaultCategories;
            const wrap = el('div','genpw-category-manager');

            if (can('vault.create')) {
                const creator = el('div','genpw-category-create');
                const input = document.createElement('input');
                input.type = 'text'; input.maxLength = 40; input.className = 'genpw-input'; input.placeholder = t('category_new','Nouvelle catégorie'); input.autocomplete = 'off';
                const add = el('button','genpw-btn is-primary','＋ ' + t('category_add','Ajouter')); add.type = 'button';
                const create = async () => {
                    const name = input.value.trim(); if (!name) return input.focus();
                    add.disabled = true;
                    try {
                        const created = await api('category_create',{name});
                        applyCategoryPayload(created, created.name || name);
                        toast(t('category_created','Catégorie créée.'));
                        await loadList();
                        closeModal(); await openCategoryManager();
                    } catch (error) { toast(error.message,true); } finally { add.disabled = false; }
                };
                add.addEventListener('click',create); input.addEventListener('keydown',event=>{ if(event.key==='Enter') create(); });
                creator.append(input,add); wrap.appendChild(creator);
            }

            const list = el('div','genpw-category-list');
            const managed = [...new Set([...(defaults || []), ...(custom || [])])];
            managed.forEach(category => {
                const row = el('div','genpw-category-row');
                const input = document.createElement('input');
                input.type='text'; input.maxLength=40; input.className='genpw-input genpw-category-edit'; input.value=category; input.autocomplete='off';
                const actions = el('div','genpw-category-actions');
                if (can('vault.edit')) {
                    const rename = el('button','genpw-btn','✎ ' + t('category_rename','Renommer')); rename.type='button';
                    rename.addEventListener('click',async()=>{
                        const name=input.value.trim(); if(!name || name===category) return; rename.disabled=true;
                        try {
                            const changed=await api('category_rename',{old_name:category,name});
                            applyCategoryPayload(changed,name);
                            toast(t('category_renamed','Catégorie renommée.'));
                            await loadList(); closeModal(); await openCategoryManager();
                        } catch(error){toast(error.message,true)} finally{rename.disabled=false}
                    });
                    const del = el('button','genpw-btn is-danger','🗑 ' + t('category_delete','Supprimer')); del.type='button';
                    del.addEventListener('click',async()=>{
                        if(!window.confirm(t('category_delete_confirm','Supprimer cette catégorie ? Les identifiants qu’elle contient seront déplacés dans une autre catégorie.'))) return;
                        del.disabled=true;
                        try {
                            const changed=await api('category_delete',{name:category});
                            const fallback = changed && changed.result && changed.result.fallback ? changed.result.fallback : '';
                            applyCategoryPayload(changed,fallback);
                            toast(t('category_deleted','Catégorie supprimée.'));
                            await loadList(); closeModal(); await openCategoryManager();
                        } catch(error){toast(error.message,true)} finally{del.disabled=false}
                    });
                    actions.append(rename,del);
                }
                row.append(input,actions); list.appendChild(row);
            });
            wrap.appendChild(list);
            modalPanel.replaceChildren(wrap);
            openModal('📂 ' + t('categories','Catégories'),'panel');
            modalDialog.classList.add('is-category-manager');
        } catch (error) { toast(error.message,true); }
    }
    async function openShare(item) {
        try {
            const [usersResult, sharesResult] = await Promise.all([api('share_users'), api('shares', { id: item.id })]);
            const users = Array.isArray(usersResult.users) ? usersResult.users : [];
            const shares = Array.isArray(sharesResult.shares) ? sharesResult.shares : [];
            const wrap = el('div','genpw-panel-stack');
            const recipients = el('div','genpw-recipient-list');
            users.forEach(user => {
                const label = el('label','genpw-check'); const input = document.createElement('input'); input.type = 'checkbox'; input.value = user.email; label.append(input, document.createTextNode(` ${user.name || user.email} · ${user.email}`)); recipients.appendChild(label);
            });
            wrap.appendChild(el('strong','',t('recipients','Destinataires'))); wrap.appendChild(recipients);
            const send = el('button','genpw-btn is-primary','↗ ' + t('share','Partager')); send.type = 'button'; send.addEventListener('click', async () => {
                const selected = [...recipients.querySelectorAll('input:checked')].map(input => input.value); if (!selected.length) return toast('Aucun destinataire sélectionné.', true);
                try { const result = await api('share', { id: item.id, recipients: selected }); toast(`${result.shared_with ? result.shared_with.length : 0} partage(s).`); closeModal(); } catch (error) { toast(error.message, true); }
            });
            wrap.appendChild(send);
            if (shares.length) {
                wrap.appendChild(el('strong','genpw-panel-separator',t('shares','Partages')));
                const current = el('div','genpw-share-list');
                shares.forEach(share => {
                    const line = el('div','genpw-share-line'); line.appendChild(el('span','',share.recipient || ''));
                    if (can('vault.revoke')) { const revoke = el('button','genpw-btn is-danger',t('revoke','Retirer')); revoke.type='button'; revoke.addEventListener('click', async () => { if (!window.confirm(t('confirm_revoke','Retirer ce partage ?'))) return; try { await api('revoke_share',{share_id:share.share_id}); line.remove(); toast(t('revoke','Retiré')); } catch(error){ toast(error.message,true); } }); line.appendChild(revoke); }
                    current.appendChild(line);
                });
                wrap.appendChild(current);
            }
            modalPanel.appendChild(wrap); openModal(`${t('share','Partager')} · ${item.name}`, 'panel');
        } catch (error) { toast(error.message, true); }
    }

    function downloadPayload(result) {
        const binary = atob(result.content || ''); const bytes = new Uint8Array(binary.length); for (let i=0;i<binary.length;i++) bytes[i] = binary.charCodeAt(i);
        const blob = new Blob([bytes], { type: result.mime || 'application/octet-stream' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = result.filename || 'DMD-GenPW-export'; document.body.appendChild(a); a.click(); a.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    async function uploadImport(file, source, skipExisting, button) {
        if (!file) return toast('Sélectionnez un fichier à importer.', true);
        const form = new FormData();
        form.append('action', 'import');
        form.append('source', source || 'auto');
        form.append('skip_existing', skipExisting ? '1' : '0');
        form.append('file', file, file.name);
        if (button) button.disabled = true;
        try {
            const response = await fetch(apiUrl, { method:'POST', credentials:'same-origin', cache:'no-store', headers:{'X-CSRF-Token':csrf}, body:form });
            let data; try { data = await response.json(); } catch (_) { throw new Error('Réponse serveur invalide (' + response.status + ').'); }
            if (!response.ok || data.error || data.ok === false) { if (data.locked || response.status === 423) setLocked(); throw new Error(data.error || 'Import impossible.'); }
            emitActivity(data);
            await loadList();
            const parts = [`${data.imported || 0} importée(s)`];
            if (data.duplicates) parts.push(`${data.duplicates} doublon(s) ignoré(s)`);
            if (data.unsupported) parts.push(`${data.unsupported} élément(s) sans secret exploitable`);
            if (data.invalid) parts.push(`${data.invalid} entrée(s) invalide(s)`);
            toast(`${data.source || 'Import'} · ${parts.join(' · ')}`);
            closeModal();
        } catch (error) { toast(error.message, true); } finally { if (button) button.disabled = false; }
    }
    function openImport() {
        const wrap = el('div','genpw-panel-stack');
        const info = el('div','genpw-import-info');
        info.innerHTML = '<strong>LastPass, 1Password et Bitwarden</strong><span>Formats : LastPass CSV · Bitwarden CSV/JSON non chiffré · 1Password CSV/1PUX.</span><span>Le fichier d’export est lu uniquement pendant l’import et n’est pas conservé par DMD-GenPW.</span>';
        wrap.appendChild(info);

        const sourceField = el('label','genpw-field');
        sourceField.appendChild(el('span','genpw-label','Source'));
        const source = document.createElement('select'); source.className='genpw-select';
        [['auto','Détection automatique'],['lastpass','LastPass'],['1password','1Password'],['bitwarden','Bitwarden']].forEach(([value,label])=>{ const option=document.createElement('option'); option.value=value; option.textContent=label; source.appendChild(option); });
        sourceField.appendChild(source); wrap.appendChild(sourceField);

        const fileField = el('label','genpw-field'); fileField.appendChild(el('span','genpw-label','Fichier du coffre'));
        const file = document.createElement('input'); file.className='genpw-input'; file.type='file'; file.accept='.csv,.json,.1pux,text/csv,application/json,application/zip'; fileField.appendChild(file); wrap.appendChild(fileField);

        const duplicate = el('label','genpw-check'); const duplicateInput=document.createElement('input'); duplicateInput.type='checkbox'; duplicateInput.checked=true; duplicate.append(duplicateInput,document.createTextNode(' Ignorer les doublons déjà présents (nom + URL + identifiant)')); wrap.appendChild(duplicate);

        const warning = el('div','genpw-security-note','⚠ Les exports LastPass, 1Password 1PUX/CSV et Bitwarden non chiffrés contiennent vos secrets en clair. Supprimez le fichier d’export après migration.'); wrap.appendChild(warning);
        const actions=el('div','genpw-panel-actions'); const run=el('button','genpw-btn is-primary','⇧ Importer le coffre'); run.type='button'; run.addEventListener('click',()=>uploadImport(file.files && file.files[0] ? file.files[0] : null, source.value, duplicateInput.checked, run)); actions.appendChild(run); wrap.appendChild(actions);
        modalPanel.appendChild(wrap); openModal('Importer un coffre', 'panel');
    }

    function openExport() {
        const wrap = el('div','genpw-panel-stack'); const include = el('label','genpw-check'); const checkbox = document.createElement('input'); checkbox.type='checkbox'; checkbox.disabled = !can('vault.export.secrets'); include.append(checkbox, document.createTextNode(' ' + t('include_secrets','Inclure les secrets'))); wrap.appendChild(include);
        const actions = el('div','genpw-panel-actions');
        [['json',t('export_json','JSON')],['csv',t('export_csv','CSV')]].forEach(([format,label]) => { const btn = el('button','genpw-btn is-primary',`⇩ ${label}`); btn.type='button'; btn.addEventListener('click',async()=>{ try { const result=await api('export',{format,include_secrets:checkbox.checked}); downloadPayload(result); toast(t('export','Exporter')); } catch(error){toast(error.message,true);} }); actions.appendChild(btn); });
        wrap.appendChild(actions); modalPanel.appendChild(wrap); openModal(t('export','Exporter'), 'panel');
    }
    async function openLogs() {
        try {
            const result = await api('logs',{limit:200}); const rows = Array.isArray(result.items) ? result.items : [];
            const wrap = el('div','genpw-panel-stack'); const tableWrap = el('div','genpw-log-list');
            if (!rows.length) tableWrap.appendChild(el('p','genpw-empty','Aucun journal.'));
            rows.forEach(row => { const line = el('div','genpw-log-line'); line.append(el('span','',String(row.datetime || '')),el('strong','',String(row.action || '')),el('span','',String(row.target || '')),el('span','',String(row.status || ''))); tableWrap.appendChild(line); });
            wrap.appendChild(tableWrap); const actions = el('div','genpw-panel-actions');
            if (can('logs.export')) { const exp=el('button','genpw-btn','⇩ '+t('export_logs','Exporter le journal')); exp.type='button'; exp.addEventListener('click',async()=>{try{downloadPayload(await api('logs_export'));}catch(error){toast(error.message,true);}}); actions.appendChild(exp); }
            if (can('logs.delete')) { const del=el('button','genpw-btn is-danger','🗑 '+t('clear_logs','Supprimer mon journal')); del.type='button'; del.addEventListener('click',async()=>{if(!window.confirm(t('confirm_logs','Supprimer votre journal DMD-GenPW ?')))return;try{await api('logs_delete');tableWrap.replaceChildren(el('p','genpw-empty','Aucun journal.'));toast(t('clear_logs','Journal supprimé'));}catch(error){toast(error.message,true);}}); actions.appendChild(del); }
            wrap.appendChild(actions); modalPanel.appendChild(wrap); openModal(t('logs','Journal'), 'panel');
        } catch (error) { toast(error.message, true); }
    }

    async function deleteSelected() {
        if (!can('vault.delete')) return toast('Accès refusé.', true);
        const ids = [...root.querySelectorAll('.genpw-select-item:checked:not(:disabled)')].map(input => input.value);
        if (!ids.length) return toast('Aucune entrée sélectionnée.', true);
        if (!window.confirm(t('confirm_delete','Supprimer les éléments sélectionnés ?'))) return;
        try { const result = await api('delete', { ids }); toast(`${result.deleted || 0} supprimée(s).`); await loadList(); } catch (error) { toast(error.message, true); }
    }
    function decorateActionHub() { if (window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') { try { window.DMDActionHub.decorate(root); } catch (_) {} } }
    function announceResize() {
        const detail = { module: 'DMD-GenPW', element: root, width: root.scrollWidth, height: root.scrollHeight };
        try { root.dispatchEvent(new CustomEvent('dmd:module-content-resize', { bubbles: true, detail })); } catch (_) {}
        try { window.dispatchEvent(new CustomEvent('dmd:module-content-resize', { detail })); } catch (_) {}
    }

    byField('category').addEventListener('change', toggleCategoryFields);
    byField('manual').addEventListener('input', event => updateStrength(event.target.value));
    byField('search').addEventListener('input', () => renderList(filteredItems()));
    byField('account-password').addEventListener('keydown', event => { if (event.key === 'Enter') unlockVault(); });
    if (byField('system-mfa-code')) byField('system-mfa-code').addEventListener('keydown', event => { if (event.key === 'Enter') unlockVault(); });
    byField('select-all').addEventListener('change', event => { root.querySelectorAll('.genpw-select-item:not(:disabled)').forEach(input => { input.checked = event.target.checked; const card=input.closest('.genpw-item'); if(card) card.classList.toggle('is-selected',input.checked); }); });
    byAction('generate').addEventListener('click', generatePassword);
    byAction('use-manual').addEventListener('click', () => { const manual = byField('manual').value; if (!manual) return toast(t('empty_password','Mot de passe vide'), true); setPreview(manual); });
    byAction('copy-preview').addEventListener('click', event => copyText(state.preview, event.currentTarget));
    byAction('save').addEventListener('click', saveEntry);
    byAction('unlock').addEventListener('click', unlockVault);
    byAction('refresh').addEventListener('click', loadList);
    byAction('delete-selected').addEventListener('click', deleteSelected);
    byAction('categories').addEventListener('click', openCategoryManager);
    byAction('import').addEventListener('click', openImport);
    byAction('export').addEventListener('click', openExport);
    byAction('logs').addEventListener('click', openLogs);
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && modal && !modal.hidden) closeModal(); });

    document.addEventListener('dmd:actionhub-action-complete', event => {
        if (!root.isConnected) return;
        const detail = event && event.detail ? event.detail : {};
        const result = detail.result && detail.result.data ? detail.result.data : {};
        if (result.module !== 'DMD-GenPW') return;
        if (result.locked) {
            setLocked();
            return;
        }
        if (result.command === 'edit-credential' && result.credential_id) {
            const item = state.items.find(candidate => candidate.id === result.credential_id && candidate.kind !== 'shared');
            if (item) editItem(item);
        }
    });


    document.addEventListener('dmd:actionhub-ui-action', async event => {
        if (!root.isConnected) return;
        const detail = event && event.detail && typeof event.detail === 'object' ? event.detail : {};
        if (String(detail.module || '') !== 'DMD-GenPW') return;
        const ui = detail.ui && typeof detail.ui === 'object' ? detail.ui : {};
        if (String(ui.type || '') !== 'genpw-open-credential') return;
        const credentialId = String(ui.credential_id || '');
        if (!credentialId) return;

        if (!state.unlocked) {
            accessPanel.open = true;
            announceResize();
            try {
                const unlockField = REQUIRE_SYSTEM_MFA ? byField('system-mfa-code') : byField('account-password');
                if (unlockField) unlockField.focus();
            } catch (_) {}
            return;
        }

        try {
            await loadList();
            const item = state.items.find(candidate => candidate.id === credentialId && candidate.kind !== 'shared');
            if (!item) return;
            editItem(item);
            document.dispatchEvent(new CustomEvent('dmd:actionhub-ui-action-handled', {
                detail: { module: 'DMD-GenPW', ui_type: 'genpw-open-credential', credential_id: credentialId }
            }));
        } catch (_) {}
    });

    if (!can('vault.create') && !can('vault.edit')) saveButton.hidden = true;
    if (!can('vault.unlock')) {
        byAction('unlock').hidden = true;
        if (byField('account-password')) byField('account-password').disabled = true;
        if (byField('system-mfa-code')) byField('system-mfa-code').disabled = true;
    }
    if (!can('vault.delete')) { byAction('delete-selected').hidden = true; byField('select-all').closest('.genpw-check').hidden = true; }
    if (!can('vault.list')) byAction('categories').hidden = true;
    if (!can('vault.create')) byAction('import').hidden = true;
    if (!can('vault.export')) byAction('export').hidden = true;
    [entryPanel, accessPanel].forEach(panel => panel.addEventListener('toggle', announceResize));
    if (!can('logs.view')) byAction('logs').hidden = true;

    const myDeskCompactButton = document.querySelector('[data-dmdgp-mydesk-compact]');
    if (myDeskCompactButton) myDeskCompactButton.addEventListener('click', async () => {
        myDeskCompactButton.disabled = true;
        try { await api('mydesk_mode_save', { mode:'compact' }); } catch (_) {}
        try { window.resizeTo(360, 520); } catch (_) {}
        window.location.assign(<?= json_encode($myDeskCompactUrl, JSON_UNESCAPED_SLASHES) ?>);
    });

    updateCategorySelect(DEFAULT_CATEGORY); toggleCategoryFields(); generatePassword(); decorateActionHub();
    if (window.ResizeObserver) { try { new ResizeObserver(() => announceResize()).observe(root); } catch (_) {} }
    api('status').then(result => { if (result.unlocked) { setUnlocked(result.expires_in); loadList(); } else setLocked(); }).catch(() => setLocked());
})();
</script>
