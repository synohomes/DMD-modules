<?php
declare(strict_types=1);

// Ce fichier est appelé directement par le navigateur : il doit rouvrir
// la même session PHP que le dashboard DoMyDesk avant de lire $_SESSION.
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/dmd-genpw_lib.php';

const DMD_GENPW_PROXY_MAX_BYTES = 33554432; // 32 MiB par réponse.
const DMD_GENPW_PROXY_TIMEOUT = 45;
const DMD_GENPW_PROXY_CONNECT_TIMEOUT = 15;
const DMD_GENPW_WEB_PROXY_VERSION = '1.4.0';

function dmdgp_proxy_fail(string $message, int $status = 400): void {
    http_response_code($status);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('Access-Control-Allow-Origin: null');
    header('Access-Control-Allow-Credentials: true');
    $safe = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><meta charset="utf-8"><title>DMD-GenPW</title>'
        . '<style>body{font-family:system-ui,sans-serif;padding:24px;background:#111827;color:#e5e7eb}'
        . 'main{max-width:760px;margin:auto;border:1px solid #374151;border-radius:12px;padding:18px;background:#0f172a}'
        . 'h1{font-size:18px;margin:0 0 10px}p{margin:0;line-height:1.5}</style>'
        . '<main><h1>DMD-GenPW</h1><p>' . $safe . '</p></main>';
    exit;
}

function dmdgp_proxy_origin(array $parts): string {
    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    $host = strtolower((string)($parts['host'] ?? ''));
    if ($scheme === '' || $host === '') return '';
    $port = isset($parts['port']) ? (int)$parts['port'] : (($scheme === 'https') ? 443 : 80);
    $default = ($scheme === 'https' && $port === 443) || ($scheme === 'http' && $port === 80);
    return $scheme . '://' . $host . ($default ? '' : ':' . $port);
}

function dmdgp_proxy_normalize_url(string $raw, ?string $base = null): ?string {
    $raw = trim(html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($raw === '') return null;

    if ($base !== null && !preg_match('~^[a-z][a-z0-9+.-]*:~i', $raw)) {
        $bp = parse_url($base);
        if (!is_array($bp) || empty($bp['scheme']) || empty($bp['host'])) return null;
        if (strpos($raw, '//') === 0) {
            $raw = $bp['scheme'] . ':' . $raw;
        } elseif ($raw[0] === '#') {
            $raw = preg_replace('/#.*$/', '', $base) . $raw;
        } elseif ($raw[0] === '?') {
            $raw = preg_replace('/[?#].*$/', '', $base) . $raw;
        } else {
            $root = $bp['scheme'] . '://' . $bp['host'] . (isset($bp['port']) ? ':' . (int)$bp['port'] : '');
            if ($raw[0] === '/') {
                $raw = $root . $raw;
            } else {
                $path = (string)($bp['path'] ?? '/');
                $dir = preg_replace('~/[^/]*$~', '/', $path);
                $raw = $root . $dir . $raw;
            }
        }
    }

    $parts = parse_url($raw);
    if (!is_array($parts)) return null;
    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    if (!in_array($scheme, array('http', 'https'), true) || empty($parts['host'])) return null;
    if (isset($parts['user']) || isset($parts['pass'])) return null;
    return $raw;
}

function dmdgp_proxy_allowed_origins(string $email): array {
    $origins = array();
    $dir = dmd_genpw_user_dir($email);
    foreach (array($dir . '/pw.json', $dir . '/shared.json') as $file) {
        $rows = dmd_genpw_read_json($file, array());
        foreach ($rows as $row) {
            if (!is_array($row)) continue;
            $url = dmdgp_proxy_normalize_url((string)($row['url'] ?? ''));
            if ($url === null) continue;
            $parts = parse_url($url);
            if (!is_array($parts)) continue;
            $origin = dmdgp_proxy_origin($parts);
            if ($origin !== '') $origins[$origin] = true;
        }
    }
    return $origins;
}

function dmdgp_proxy_ip_forbidden(string $ip): bool {
    if (filter_var($ip, FILTER_VALIDATE_IP) === false) return true;
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $long = ip2long($ip);
        if ($long === false) return true;
        $u = (int)sprintf('%u', $long);
        if (($u & 0xff000000) === 0x7f000000) return true;       // 127.0.0.0/8
        if (($u & 0xffff0000) === 0xa9fe0000) return true;       // 169.254.0.0/16 / metadata
        if (($u & 0xff000000) === 0x00000000) return true;       // 0.0.0.0/8
        if (($u & 0xf0000000) === 0xe0000000) return true;       // multicast / réservé haut
        return false; // IPv4 public + RFC1918 autorisés.
    }
    $lower = strtolower($ip);
    if ($lower === '::1' || $lower === '::') return true;
    if (preg_match('/^fe[89ab][0-9a-f]:/i', $lower)) return true;
    if (strpos($lower, 'ff') === 0) return true;
    return false; // IPv6 public + ULA autorisés.
}

function dmdgp_proxy_ip_is_private(string $ip): bool {
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $long = ip2long($ip);
        if ($long === false) return false;
        $u = (int)sprintf('%u', $long);
        return (($u & 0xff000000) === 0x0a000000)
            || (($u & 0xfff00000) === 0xac100000)
            || (($u & 0xffff0000) === 0xc0a80000);
    }
    $lower = strtolower($ip);
    return strpos($lower, 'fc') === 0 || strpos($lower, 'fd') === 0;
}

function dmdgp_proxy_private_target(array $parts): bool {
    $host = (string)($parts['host'] ?? '');
    if ($host === '') return false;
    if (filter_var($host, FILTER_VALIDATE_IP) !== false) return dmdgp_proxy_ip_is_private($host);
    $ips = @gethostbynamel($host);
    if (!is_array($ips) || !$ips) return false;
    foreach ($ips as $ip) if (!dmdgp_proxy_ip_is_private((string)$ip)) return false;
    return true;
}

function dmdgp_proxy_validate_target(string $url, string $token, array $allowedOrigins, string $signature, string $originCapability): array {
    $normalized = dmdgp_proxy_normalize_url($url);
    if ($normalized === null) dmdgp_proxy_fail('URL invalide ou protocole non autorisé.', 400);
    $parts = parse_url($normalized);
    if (!is_array($parts)) dmdgp_proxy_fail('URL invalide.', 400);
    $origin = dmdgp_proxy_origin($parts);
    if ($origin === '') dmdgp_proxy_fail('Origine distante invalide.', 400);

    $authorized = false;
    if ($signature !== '') $authorized = dmd_genpw_web_proxy_verify_target($token, $normalized, $signature);
    if (!$authorized && $originCapability !== '') $authorized = dmd_genpw_web_proxy_verify_origin_cap($token, $origin, $originCapability);
    if (!$authorized) dmdgp_proxy_fail('Navigation refusée : destination non autorisée par la session DMD-GenPW.', 403);

    $host = (string)($parts['host'] ?? '');
    if (filter_var($host, FILTER_VALIDATE_IP) !== false && dmdgp_proxy_ip_forbidden($host)) {
        dmdgp_proxy_fail('Navigation refusée vers cette adresse système.', 403);
    }
    return array($normalized, $parts, $origin);
}

function dmdgp_proxy_url(string $target, string $token, bool $signed = true, string $originCapability = ''): string {
    $script = (string)($_SERVER['SCRIPT_NAME'] ?? 'dmd-genpw_web_proxy.php');
    $query = array('__dmdgp_session'=>$token, '__dmdgp_target'=>$target);
    $mode = isset($GLOBALS['DMDGP_PROXY_MODE']) ? (string)$GLOBALS['DMDGP_PROXY_MODE'] : 'full';
    if ($mode === 'compat') $query['__dmdgp_mode'] = 'compat';
    if ($signed) {
        $sig = dmd_genpw_web_proxy_sign_target($token, $target);
        if ($sig !== '') $query['__dmdgp_sig'] = $sig;
    } elseif ($originCapability !== '') {
        $query['__dmdgp_cap'] = $originCapability;
    }
    return $script . '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
}

function dmdgp_proxy_absolute(string $value, string $base): ?string {
    $value = trim(html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($value === '' || $value[0] === '#') return null;
    if (preg_match('~^(?:data|blob|javascript|mailto|tel|about):~i', $value)) return null;
    return dmdgp_proxy_normalize_url($value, $base);
}

function dmdgp_proxy_attr(string $value, string $remoteUrl, string $token): string {
    $absolute = dmdgp_proxy_absolute($value, $remoteUrl);
    if ($absolute === null) return $value;
    return dmdgp_proxy_url($absolute, $token, true);
}

function dmdgp_proxy_rewrite_srcset(string $srcset, string $remoteUrl, string $token): string {
    $parts = preg_split('/\s*,\s*/', trim($srcset));
    if (!is_array($parts)) return $srcset;
    $rewritten = array();
    foreach ($parts as $item) {
        if ($item === '') continue;
        if (!preg_match('/^(\S+)(\s+.*)?$/s', $item, $m)) { $rewritten[] = $item; continue; }
        $rewritten[] = dmdgp_proxy_attr((string)$m[1], $remoteUrl, $token) . (isset($m[2]) ? (string)$m[2] : '');
    }
    return implode(', ', $rewritten);
}

function dmdgp_proxy_rewrite_css(string $css, string $remoteUrl, string $token): string {
    $result = preg_replace_callback('~url\(\s*([\'\"]?)(.*?)\1\s*\)~is', function ($m) use ($remoteUrl, $token) {
        $absolute = dmdgp_proxy_absolute(trim((string)$m[2]), $remoteUrl);
        if ($absolute === null) return $m[0];
        return 'url("' . dmdgp_proxy_url($absolute, $token, true) . '")';
    }, $css);
    if (!is_string($result)) $result = $css;
    $result2 = preg_replace_callback('~@import\s+([\'\"])(.*?)\1~is', function ($m) use ($remoteUrl, $token) {
        $absolute = dmdgp_proxy_absolute((string)$m[2], $remoteUrl);
        if ($absolute === null) return $m[0];
        return '@import ' . $m[1] . dmdgp_proxy_url($absolute, $token, true) . $m[1];
    }, $result);
    return is_string($result2) ? $result2 : $result;
}

function dmdgp_proxy_rewrite_tag(string $tag, string $remoteUrl, string $token): string {
    if (!preg_match('/^<\s*([a-z0-9:-]+)/i', $tag, $tm)) return $tag;
    $name = strtolower((string)$tm[1]);

    $attrs = array();
    if (in_array($name, array('a','area','link'), true)) $attrs[] = 'href';
    if (in_array($name, array('script','img','iframe','source','video','audio','track','embed','input'), true)) $attrs[] = 'src';
    if ($name === 'object') $attrs[] = 'data';
    if ($name === 'video') $attrs[] = 'poster';
    if ($name === 'form') $attrs[] = 'action';

    foreach ($attrs as $attr) {
        $tag = preg_replace_callback(
            '~(\s' . preg_quote($attr, '~') . '\s*=\s*)([\'\"])(.*?)\2~is',
            function ($m) use ($remoteUrl, $token, $attr, $name) {
                $raw = (string)$m[3];
                $absolute = dmdgp_proxy_absolute($raw, $remoteUrl);
                if ($absolute === null) return $m[0];
                $proxy = dmdgp_proxy_url($absolute, $token, true);
                $quote = (string)$m[2];
                if ($attr === 'action') {
                    return ' data-dmdgp-remote-action=' . $quote . htmlspecialchars($absolute, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $quote
                        . ' data-dmdgp-proxy-action=' . $quote . htmlspecialchars($proxy, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $quote
                        . $m[1] . $quote . htmlspecialchars($proxy, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $quote;
                }
                if ($attr === 'href' && in_array($name, array('a','area'), true)) {
                    return ' data-dmdgp-remote-href=' . $quote . htmlspecialchars($absolute, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $quote
                        . ' data-dmdgp-proxy-href=' . $quote . htmlspecialchars($proxy, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $quote
                        . $m[1] . $quote . htmlspecialchars($proxy, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $quote;
                }
                return $m[1] . $quote . htmlspecialchars($proxy, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $quote;
            },
            $tag
        ) ?? $tag;
    }

    if (in_array($name, array('img','source'), true)) {
        $tag = preg_replace_callback('~(\ssrcset\s*=\s*)([\'\"])(.*?)\2~is', function ($m) use ($remoteUrl, $token) {
            return $m[1] . $m[2] . htmlspecialchars(dmdgp_proxy_rewrite_srcset((string)$m[3], $remoteUrl, $token), ENT_QUOTES | ENT_HTML5, 'UTF-8') . $m[2];
        }, $tag) ?? $tag;
    }

    $tag = preg_replace_callback('~(\sstyle\s*=\s*)([\'\"])(.*?)\2~is', function ($m) use ($remoteUrl, $token) {
        $style = html_entity_decode((string)$m[3], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return $m[1] . $m[2] . htmlspecialchars(dmdgp_proxy_rewrite_css($style, $remoteUrl, $token), ENT_QUOTES | ENT_HTML5, 'UTF-8') . $m[2];
    }, $tag) ?? $tag;

    if (in_array($name, array('a','area','form'), true)) {
        $tag = preg_replace_callback('~\starget\s*=\s*([\'\"])(?:_blank|_new)\1~i', function () {
            return ' data-dmdgp-original-target="_blank" target="_self"';
        }, $tag) ?? $tag;
    }
    if (in_array($name, array('link','script'), true)) {
        // Les ressources passent par l'origine DoMyDesk : SRI/CORS d'origine ne sont plus applicables.
        $tag = preg_replace('~\sintegrity\s*=\s*([\'\"]).*?\1~is', '', $tag) ?? $tag;
        $tag = preg_replace('~\scrossorigin(?:\s*=\s*([\'\"]).*?\1)?~is', '', $tag) ?? $tag;
    }
    return $tag;
}

function dmdgp_proxy_rewrite_js(string $js, string $remoteUrl, string $token): string {
    // Les applications modernes (Vite/Webpack/ES modules) chargent souvent leurs
    // chunks par des imports relatifs au fichier JS. Comme le fichier est servi via
    // dmd-genpw_web_proxy.php, le navigateur résoudrait sinon ./chunk.js au mauvais
    // endroit et l'application finirait sur un écran vide.
    $rewriteLiteral = static function (string $raw) use ($remoteUrl, $token): string {
        $absolute = dmdgp_proxy_absolute($raw, $remoteUrl);
        if ($absolute === null) return $raw;
        return dmdgp_proxy_url($absolute, $token, true);
    };

    // import "./x.js" ; import ... from "./x.js" ; export ... from "./x.js"
    $out = preg_replace_callback(
        '~((?:^|[;{}\n\r]\s*)(?:import|export)\s+(?:(?:[^\"\'\n\r;]+?\s+from\s+)?))([\"\'])([^\"\']+)\2~m',
        static function ($m) use ($rewriteLiteral) {
            $raw = (string)$m[3];
            if (preg_match('~^(?:data|blob|javascript|node):~i', $raw)) return $m[0];
            return (string)$m[1] . (string)$m[2] . $rewriteLiteral($raw) . (string)$m[2];
        },
        $js
    );
    if (!is_string($out)) $out = $js;

    // import("./chunk.js") / import('./chunk.js')
    $out2 = preg_replace_callback(
        '~\bimport\s*\(\s*([\"\'])([^\"\']+)\1\s*\)~',
        static function ($m) use ($rewriteLiteral) {
            $raw = (string)$m[2];
            if (preg_match('~^(?:data|blob|javascript|node):~i', $raw)) return $m[0];
            return 'import(' . (string)$m[1] . $rewriteLiteral($raw) . (string)$m[1] . ')';
        },
        $out
    );
    if (is_string($out2)) $out = $out2;

    // Bundlers : new URL("./asset.svg", import.meta.url)
    $out3 = preg_replace_callback(
        '~new\s+URL\s*\(\s*([\"\'])([^\"\']+)\1\s*,\s*import\.meta\.url\s*\)~',
        static function ($m) use ($rewriteLiteral) {
            $raw = (string)$m[2];
            if (preg_match('~^(?:data|blob|javascript):~i', $raw)) return $m[0];
            $proxy = $rewriteLiteral($raw);
            return 'new URL(' . (string)$m[1] . $proxy . (string)$m[1] . ', location.href)';
        },
        $out
    );
    if (is_string($out3)) $out = $out3;

    return $out;
}

function dmdgp_proxy_cookie_string(string $cookieFile, string $remoteUrl): string {
    if (!is_file($cookieFile)) return '';
    $parts = parse_url($remoteUrl);
    if (!is_array($parts) || empty($parts['host'])) return '';
    $host = strtolower((string)$parts['host']);
    $path = (string)($parts['path'] ?? '/');
    if ($path === '' || $path[0] !== '/') $path = '/';
    $secureRequest = strtolower((string)($parts['scheme'] ?? '')) === 'https';
    $now = time(); $pairs = array();
    $lines = @file($cookieFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!is_array($lines)) return '';
    foreach ($lines as $line) {
        if ($line === '' || $line[0] === '#') continue; // HttpOnly inclus : jamais exposé au JS.
        $cols = explode("\t", $line);
        if (count($cols) < 7) continue;
        list($domain,$includeSub,$cookiePath,$secure,$expires,$name,$value) = array_slice($cols, 0, 7);
        $domain = ltrim(strtolower((string)$domain), '.');
        $hostMatch = $host === $domain || (strtoupper((string)$includeSub) === 'TRUE' && strlen($host) > strlen($domain) && substr($host, -strlen('.' . $domain)) === '.' . $domain);
        if (!$hostMatch) continue;
        $cookiePath = (string)$cookiePath;
        if ($cookiePath === '' || strpos($path, $cookiePath) !== 0) continue;
        if (strtoupper((string)$secure) === 'TRUE' && !$secureRequest) continue;
        $expiry = (int)$expires;
        if ($expiry > 0 && $expiry < $now) continue;
        if ((string)$name === '') continue;
        $pairs[(string)$name] = (string)$value;
    }
    $out = array();
    foreach ($pairs as $name=>$value) $out[] = $name . '=' . $value;
    return implode('; ', $out);
}

function dmdgp_proxy_cookie_write(string $cookieFile, string $remoteUrl, string $assignment): bool {
    $assignment = trim($assignment);
    if ($assignment === '' || strlen($assignment) > 8192) return false;
    $parts = parse_url($remoteUrl);
    if (!is_array($parts) || empty($parts['host'])) return false;
    $chunks = array_map('trim', explode(';', $assignment));
    $first = array_shift($chunks);
    if (!is_string($first) || strpos($first, '=') === false) return false;
    list($name,$value) = explode('=', $first, 2);
    $name = trim($name); $value = trim($value);
    if ($name === '' || preg_match('/[\x00-\x20\x7f()<>@,;:\\"\/\[\]?={}]/', $name)) return false;

    $host = strtolower((string)$parts['host']);
    $domain = $host; $includeSub = 'FALSE';
    $requestPath = (string)($parts['path'] ?? '/');
    if ($requestPath === '' || $requestPath[0] !== '/') $requestPath = '/';
    $lastSlash = strrpos($requestPath, '/');
    $cookiePath = ($lastSlash === false || $lastSlash === 0) ? '/' : substr($requestPath, 0, $lastSlash + 1);
    $secure = false; $expires = 0;

    foreach ($chunks as $chunk) {
        if ($chunk === '') continue;
        $eq = strpos($chunk, '=');
        $attr = strtolower(trim($eq === false ? $chunk : substr($chunk, 0, $eq)));
        $attrValue = trim($eq === false ? '' : substr($chunk, $eq + 1));
        if ($attr === 'domain' && $attrValue !== '') {
            $candidate = ltrim(strtolower($attrValue), '.');
            if ($host === $candidate || strlen($host) > strlen($candidate) && substr($host, -strlen('.' . $candidate)) === '.' . $candidate) {
                $domain = '.' . $candidate; $includeSub = 'TRUE';
            }
        } elseif ($attr === 'path' && $attrValue !== '' && $attrValue[0] === '/') {
            $cookiePath = $attrValue;
        } elseif ($attr === 'secure') {
            $secure = true;
        } elseif ($attr === 'max-age' && preg_match('/^-?\d+$/', $attrValue)) {
            $seconds = (int)$attrValue; $expires = $seconds <= 0 ? 1 : time() + min($seconds, 31536000);
        } elseif ($attr === 'expires' && $attrValue !== '') {
            $ts = strtotime($attrValue); if ($ts !== false) $expires = max(1, $ts);
        }
    }

    if (!function_exists('curl_init')) return false;
    $ch = curl_init($remoteUrl);
    if ($ch === false) return false;
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    $line = implode("\t", array($domain,$includeSub,$cookiePath,$secure ? 'TRUE' : 'FALSE',(string)$expires,$name,$value));
    $ok = curl_setopt($ch, CURLOPT_COOKIELIST, $line);
    @curl_setopt($ch, CURLOPT_COOKIELIST, 'FLUSH');
    curl_close($ch);
    @chmod($cookieFile, 0600);
    return (bool)$ok;
}

function dmdgp_proxy_rewrite_html(string $html, string $remoteUrl, string $token, string $mode = 'full'): string {
    $html = preg_replace('~<meta\b[^>]*http-equiv\s*=\s*([\'\"]?)content-security-policy\1[^>]*>~is', '', $html) ?? $html;
    $html = preg_replace('~<base\b[^>]*>~is', '', $html) ?? $html;

    if ($mode === 'compat') {
        // Mode de secours : conserver le HTML/CSS/formulaires/liens mais retirer le JS distant.
        // Cela évite qu'une application casse toute la page dans l'origine sandboxée et laisse
        // au minimum une navigation serveur utilisable dans la fenêtre GenPW.
        $html = preg_replace('~<script\b[^>]*>.*?</script\s*>~is', '', $html) ?? $html;
        $html = preg_replace('~\s+on[a-z0-9_-]+\s*=\s*([\'\"]).*?\1~is', '', $html) ?? $html;
        $html = preg_replace_callback('~<(html|body)\b([^>]*)\sstyle\s*=\s*([\'\"])(.*?)\3([^>]*)>~is', static function ($m) {
            $style = preg_replace('~(?:^|;)\s*(?:opacity\s*:\s*0|visibility\s*:\s*hidden|display\s*:\s*none)\s*;?~i', ';', (string)$m[4]);
            return '<' . $m[1] . $m[2] . ' style=' . $m[3] . $style . $m[3] . $m[5] . '>';
        }, $html) ?? $html;
    }

    $html = preg_replace_callback('~<(?:a|area|link|script|img|iframe|source|video|audio|track|embed|input|object|form)\b[^>]*>~is', function ($m) use ($remoteUrl, $token) {
        return dmdgp_proxy_rewrite_tag((string)$m[0], $remoteUrl, $token);
    }, $html) ?? $html;

    $html = preg_replace_callback('~<style\b([^>]*)>(.*?)</style>~is', function ($m) use ($remoteUrl, $token) {
        return '<style' . (string)$m[1] . '>' . dmdgp_proxy_rewrite_css((string)$m[2], $remoteUrl, $token) . '</style>';
    }, $html) ?? $html;

    $html = preg_replace_callback('~<meta\b([^>]*http-equiv\s*=\s*([\'\"]?)refresh\2[^>]*)>~is', function ($m) use ($remoteUrl, $token) {
        $tag = '<meta' . (string)$m[1] . '>';
        return preg_replace_callback('~(content\s*=\s*)([\'\"])(.*?)\2~is', function ($cm) use ($remoteUrl, $token) {
            $content = (string)$cm[3];
            if (!preg_match('~^(\s*\d+\s*;\s*url\s*=\s*)(.*)$~is', $content, $mm)) return $cm[0];
            $absolute = dmdgp_proxy_absolute(trim((string)$mm[2], " \t\r\n\"'"), $remoteUrl);
            if ($absolute === null) return $cm[0];
            $new = (string)$mm[1] . dmdgp_proxy_url($absolute, $token, true);
            return $cm[1] . $cm[2] . htmlspecialchars($new, ENT_QUOTES | ENT_HTML5, 'UTF-8') . $cm[2];
        }, $tag) ?? $tag;
    }, $html) ?? $html;

    $remoteParts = parse_url($remoteUrl);
    $remoteOrigin = is_array($remoteParts) ? dmdgp_proxy_origin($remoteParts) : '';
    $originCap = dmd_genpw_web_proxy_origin_cap($token, $remoteOrigin);
    $localStorage = $remoteOrigin !== '' ? dmd_genpw_web_storage_read($token, $remoteOrigin) : array();
    $cookieFile = $remoteOrigin !== '' ? dmd_genpw_web_cookie_file($token, $remoteOrigin) : '';
    $cookieString = $cookieFile !== '' ? dmdgp_proxy_cookie_string($cookieFile, $remoteUrl) : '';

    $remoteJson = json_encode($remoteUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $proxyJson = json_encode((string)($_SERVER['SCRIPT_NAME'] ?? 'dmd-genpw_web_proxy.php'), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $tokenJson = json_encode($token, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $capJson = json_encode($originCap, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $localJson = json_encode($localStorage, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $cookieJson = json_encode($cookieString, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    $modeJson = json_encode($mode === 'compat' ? 'compat' : 'full', JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

    $bridgeJs = <<<'JS'
(function(){
"use strict";
var REMOTE=__REMOTE__, PROXY=__PROXY__, TOKEN=__TOKEN__, CAP=__CAP__, LOCAL_INIT=__LOCAL__, COOKIE_INIT=__COOKIE__, MODE=__MODE__;
var NATIVE_FETCH=typeof window.fetch==="function"?window.fetch.bind(window):null;
var PROXYABS=(function(){try{return new URL(PROXY,location.href)}catch(e){return null}})();
var LOCAL_ORIGIN=(function(){try{return location.origin||""}catch(e){return ""}})();
function unproxy(raw){try{var u=new URL(String(raw||""),location.href);if(PROXYABS&&u.origin===PROXYABS.origin&&u.pathname===PROXYABS.pathname&&u.searchParams.has("__dmdgp_target"))return u.searchParams.get("__dmdgp_target")||String(raw||"")}catch(e){}return String(raw||"")}
function remoteOrigin(){try{return new URL(REMOTE).origin}catch(e){return ""}}
function abs(u){var raw=unproxy(u);try{var a=new URL(raw,REMOTE);if(LOCAL_ORIGIN&&a.origin===LOCAL_ORIGIN&&(!PROXYABS||a.pathname!==PROXYABS.pathname)){var ro=remoteOrigin();if(ro)return new URL(a.pathname+a.search+a.hash,ro+"/").href}return a.href}catch(e){return raw}}
function sameRemote(u){try{return new URL(abs(u)).origin===remoteOrigin()}catch(e){return false}}
function prox(u){var a=abs(u);if(!/^https?:/i.test(a)||!sameRemote(a))return a;return PROXY+"?__dmdgp_session="+encodeURIComponent(TOKEN)+"&__dmdgp_target="+encodeURIComponent(a)+"&__dmdgp_cap="+encodeURIComponent(CAP)+(MODE==="compat"?"&__dmdgp_mode=compat":"")}
function bridgeUrl(){return PROXY+"?__dmdgp_session="+encodeURIComponent(TOKEN)+"&__dmdgp_target="+encodeURIComponent(REMOTE)+"&__dmdgp_cap="+encodeURIComponent(CAP)+"&__dmdgp_bridge=storage"+(MODE==="compat"?"&__dmdgp_mode=compat":"")}
function send(type,data){try{parent.postMessage(Object.assign({dmdGenPw:true,type:type},data||{}),"*")}catch(e){}}
function setRemote(u){try{var a=abs(u);if(/^https?:/i.test(a)){REMOTE=a;var b=document.querySelector("base");if(b)b.href=a;return a}}catch(e){}return REMOTE}
function requestNav(u,newTab,title){var a=abs(u);if(!/^https?:/i.test(a))return;send(newTab?"open-tab":"navigate-request",{url:a,newTab:!!newTab,title:title||""})}
function fakeWindow(){var o={closed:false,close:function(){this.closed=true},focus:function(){},blur:function(){},postMessage:function(){}};try{Object.defineProperty(o,"location",{configurable:true,get:function(){return {assign:function(v){requestNav(v,true,"")},replace:function(v){requestNav(v,true,"")}}},set:function(v){requestNav(v,true,"")}})}catch(e){o.location=null}return o}
try{window.open=function(u){if(u)requestNav(u,true,"");return fakeWindow()}}catch(e){}

function makeStorage(initial,persist){
  var data={};Object.keys(initial||{}).forEach(function(k){data[String(k)]=String(initial[k])});var timer=0;
  function save(){if(!persist||!NATIVE_FETCH)return;clearTimeout(timer);timer=setTimeout(function(){try{NATIVE_FETCH(bridgeUrl(),{method:"POST",credentials:"omit",headers:{"Content-Type":"application/json"},body:JSON.stringify({kind:"local",data:data})}).catch(function(){})}catch(e){}},80)}
  var api={getItem:function(k){k=String(k);return Object.prototype.hasOwnProperty.call(data,k)?data[k]:null},setItem:function(k,v){data[String(k)]=String(v);save()},removeItem:function(k){delete data[String(k)];save()},clear:function(){data={};save()},key:function(i){var ks=Object.keys(data);i=Number(i)||0;return i>=0&&i<ks.length?ks[i]:null}};
  try{Object.defineProperty(api,"length",{enumerable:true,get:function(){return Object.keys(data).length}})}catch(e){}
  return api;
}
var localShim=makeStorage(LOCAL_INIT,true),sessionShim=makeStorage({},false);
try{var localOk=true;try{void window.localStorage.length}catch(e){localOk=false}if(!localOk)Object.defineProperty(window,"localStorage",{configurable:true,get:function(){return localShim}})}catch(e){}
try{var sessionOk=true;try{void window.sessionStorage.length}catch(e){sessionOk=false}if(!sessionOk)Object.defineProperty(window,"sessionStorage",{configurable:true,get:function(){return sessionShim}})}catch(e){}

var cookieMap={};
function parseCookies(raw){String(raw||"").split(";").forEach(function(part){var p=part.trim(),i=p.indexOf("=");if(i>0)cookieMap[p.slice(0,i).trim()]=p.slice(i+1)})}
function cookieText(){return Object.keys(cookieMap).map(function(k){return k+"="+cookieMap[k]}).join("; ")}
parseCookies(COOKIE_INIT);
try{var cookieOk=true;try{void document.cookie}catch(e){cookieOk=false}if(!cookieOk)Object.defineProperty(document,"cookie",{configurable:true,get:cookieText,set:function(v){var raw=String(v||""),first=raw.split(";",1)[0],i=first.indexOf("=");if(i>0){var n=first.slice(0,i).trim(),val=first.slice(i+1);if(n)cookieMap[n]=val}if(NATIVE_FETCH){try{NATIVE_FETCH(bridgeUrl(),{method:"POST",credentials:"omit",headers:{"Content-Type":"application/json"},body:JSON.stringify({kind:"cookie",value:raw})}).catch(function(){})}catch(e){}}}})}catch(e){}

try{if(NATIVE_FETCH){window.fetch=function(input,init){try{var opts=init?Object.assign({},init):{};if(typeof input==="string"||input instanceof URL){var a=abs(String(input));if(sameRemote(a)){opts.credentials="omit";return NATIVE_FETCH(prox(a),opts)}}else if(input&&input.url){var a2=abs(input.url);if(sameRemote(a2)){opts.credentials="omit";return NATIVE_FETCH(new Request(prox(a2),input),opts)}}}catch(e){}return NATIVE_FETCH(input,init)}}}catch(e){}
try{var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){var a=abs(u);this.__dmdgp=sameRemote(a);arguments[1]=this.__dmdgp?prox(a):a;return xo.apply(this,arguments)};XMLHttpRequest.prototype.send=function(b){try{if(this.__dmdgp)this.withCredentials=false}catch(e){}return xs.call(this,b)}}catch(e){}
try{var nb=navigator.sendBeacon&&navigator.sendBeacon.bind(navigator);if(nb)navigator.sendBeacon=function(u,d){var a=abs(u);return nb(sameRemote(a)?prox(a):a,d)}}catch(e){}
try{var NativeEventSource=window.EventSource;if(NativeEventSource){window.EventSource=function(u,o){var a=abs(u);return new NativeEventSource(sameRemote(a)?prox(a):a,o)};window.EventSource.prototype=NativeEventSource.prototype}}catch(e){}
try{var NativeWorker=window.Worker;if(NativeWorker){window.Worker=function(u,o){var a=abs(u);return new NativeWorker(sameRemote(a)?prox(a):a,o)};window.Worker.prototype=NativeWorker.prototype}}catch(e){}
try{if(navigator.serviceWorker&&navigator.serviceWorker.register){navigator.serviceWorker.register=function(){return Promise.reject(new Error("Service Worker désactivé dans DMD-GenPW"))}}}catch(e){}

function mark(node){if(!node||node.nodeType!==1)return;var els=[];if(node.matches&&node.matches("a[target],area[target],form[target]"))els.push(node);if(node.querySelectorAll)Array.prototype.push.apply(els,node.querySelectorAll("a[target],area[target],form[target]"));els.forEach(function(el){var t=(el.getAttribute("target")||"").toLowerCase();if(t==="_blank"||t==="_new"){el.setAttribute("data-dmdgp-original-target","_blank");el.setAttribute("target","_self")}})}
document.addEventListener("click",function(ev){if(ev.defaultPrevented||ev.button!==0||ev.metaKey||ev.ctrlKey||ev.shiftKey||ev.altKey)return;var a=ev.target&&ev.target.closest?ev.target.closest("a[href]"):null;if(!a)return;var remote=a.getAttribute("data-dmdgp-remote-href")||a.getAttribute("href")||a.href||"";var u=abs(remote);if(!/^https?:/i.test(u))return;ev.preventDefault();ev.stopPropagation();var t=(a.getAttribute("data-dmdgp-original-target")||a.getAttribute("target")||"").toLowerCase();requestNav(u,t==="_blank"||t==="_new",(a.textContent||"").trim())},true);
document.addEventListener("submit",function(ev){var f=ev.target;if(!f||String(f.tagName).toLowerCase()!=="form"||f.dataset.dmdgpPrepared==="1")return;try{var remote=f.getAttribute("data-dmdgp-remote-action")||f.getAttribute("action")||REMOTE;var action=abs(remote);var method=String(f.getAttribute("method")||"GET").toUpperCase();f.setAttribute("target","_self");if(method==="GET"){ev.preventDefault();ev.stopPropagation();var u=new URL(action),fd;try{fd=new FormData(f,ev.submitter||undefined)}catch(e){fd=new FormData(f)};fd.forEach(function(v,k){if(typeof v==="string")u.searchParams.append(k,v)});requestNav(u.href,false,document.title||"");return}f.dataset.dmdgpPrepared="1";f.setAttribute("action",f.getAttribute("data-dmdgp-proxy-action")||prox(action))}catch(e){ev.preventDefault();send("error",{message:"Impossible de transmettre ce formulaire."})}},true);
try{var hp=history.pushState,hr=history.replaceState;history.pushState=function(s,t,u){if(u!=null){var a=setRemote(u);send("navigate",{url:a,title:document.title||""});try{return hp.call(history,s,t)}catch(e){return null}}return hp.apply(history,arguments)};history.replaceState=function(s,t,u){if(u!=null){var a=setRemote(u);send("navigate",{url:a,title:document.title||""});try{return hr.call(history,s,t)}catch(e){return null}}return hr.apply(history,arguments)}}catch(e){}
try{window.addEventListener("error",function(ev){var msg="Erreur JavaScript du site";try{if(ev&&ev.message)msg=String(ev.message);if(ev&&ev.filename)msg+=" · "+String(ev.filename)+(ev.lineno?":"+ev.lineno:"")}catch(e){}send("runtime-error",{message:msg})},true)}catch(e){}
try{window.addEventListener("unhandledrejection",function(ev){var r=ev&&ev.reason,msg="Promesse rejetée par le site";try{if(r){msg=String(r.message||r)}}catch(e){}send("runtime-error",{message:msg})})}catch(e){}
try{new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes&&m.addedNodes.forEach(mark)})}).observe(document.documentElement||document,{subtree:true,childList:true})}catch(e){}
function renderState(type){var body=document.body,visible="",all="";try{visible=body?String(body.innerText||""):""}catch(e){}try{all=body?String(body.textContent||""):""}catch(e){}send(type,{url:REMOTE,title:document.title||"",mode:MODE,visibleTextLength:visible.trim().length,textLength:all.trim().length,childCount:body&&body.children?body.children.length:0})}function ready(){mark(document);renderState("ready");setTimeout(function(){renderState("render-state")},900)}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",ready,{once:true});else ready();
})();
JS;
    $bridgeJs = strtr($bridgeJs, array(
        '__REMOTE__'=>$remoteJson ?: '""',
        '__PROXY__'=>$proxyJson ?: '""',
        '__TOKEN__'=>$tokenJson ?: '""',
        '__CAP__'=>$capJson ?: '""',
        '__LOCAL__'=>$localJson ?: '{}',
        '__COOKIE__'=>$cookieJson ?: '""',
        '__MODE__'=>$modeJson ?: '"full"'
    ));

    $compatStyle = $mode === 'compat'
        ? '<style>html,body{visibility:visible!important;opacity:1!important}body{min-height:100vh!important}</style>'
        : '';
    $bridge = '<base href="' . htmlspecialchars($remoteUrl, ENT_QUOTES | ENT_HTML5, 'UTF-8') . '">' .
        '<meta name="dmd-genpw-remote-url" content="' . htmlspecialchars($remoteUrl, ENT_QUOTES | ENT_HTML5, 'UTF-8') . '">' .
        $compatStyle . '<script>' . $bridgeJs . '</script>';

    if (preg_match('~<head\b[^>]*>~i', $html, $m, PREG_OFFSET_CAPTURE)) {
        $pos = (int)$m[0][1] + strlen((string)$m[0][0]);
        return substr($html, 0, $pos) . $bridge . substr($html, $pos);
    }
    return $bridge . $html;
}

if ((string)($_GET['__dmdgp_health'] ?? '') === '1') {
    if (!dmd_genpw_logged_in()) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        echo json_encode(array('ok'=>false,'error'=>'not_authenticated','proxy_version'=>DMD_GENPW_WEB_PROXY_VERSION), JSON_UNESCAPED_SLASHES);
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    echo json_encode(array('ok'=>true,'proxy_version'=>DMD_GENPW_WEB_PROXY_VERSION,'module_version'=>DMD_GENPW_VERSION), JSON_UNESCAPED_SLASHES);
    exit;
}

if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'OPTIONS') {
    header('Access-Control-Allow-Origin: null');
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS');
    $requestedHeaders = trim((string)($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'] ?? ''));
    if ($requestedHeaders !== '') header('Access-Control-Allow-Headers: ' . $requestedHeaders);
    header('Access-Control-Max-Age: 300');
    http_response_code(204);
    exit;
}

$method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$proxyMode = ((string)($_GET['__dmdgp_mode'] ?? $_POST['__dmdgp_mode'] ?? 'full') === 'compat') ? 'compat' : 'full';
$GLOBALS['DMDGP_PROXY_MODE'] = $proxyMode;
$token = '';
if (isset($_GET['__dmdgp_session']) && is_scalar($_GET['__dmdgp_session'])) $token = (string)$_GET['__dmdgp_session'];
elseif (isset($_POST['__dmdgp_session']) && is_scalar($_POST['__dmdgp_session'])) $token = (string)$_POST['__dmdgp_session'];
$webSession = dmd_genpw_web_session_validate($token, true);
if (!is_array($webSession)) dmdgp_proxy_fail('Session de navigation DMD-GenPW expirée. Fermez puis rouvrez le site.', 401);
$email = (string)$webSession['email'];

$target = '';
if (isset($_GET['__dmdgp_target']) && is_scalar($_GET['__dmdgp_target'])) $target = (string)$_GET['__dmdgp_target'];
elseif (isset($_POST['__dmdgp_target']) && is_scalar($_POST['__dmdgp_target'])) $target = (string)$_POST['__dmdgp_target'];
if ($target === '') dmdgp_proxy_fail('Destination manquante.', 400);

$signature = isset($_GET['__dmdgp_sig']) && is_scalar($_GET['__dmdgp_sig']) ? (string)$_GET['__dmdgp_sig'] : '';
if ($signature === '' && isset($_POST['__dmdgp_sig']) && is_scalar($_POST['__dmdgp_sig'])) $signature = (string)$_POST['__dmdgp_sig'];
$originCapability = isset($_GET['__dmdgp_cap']) && is_scalar($_GET['__dmdgp_cap']) ? (string)$_GET['__dmdgp_cap'] : '';
if ($originCapability === '' && isset($_POST['__dmdgp_cap']) && is_scalar($_POST['__dmdgp_cap'])) $originCapability = (string)$_POST['__dmdgp_cap'];

$allowedOrigins = dmdgp_proxy_allowed_origins($email);
list($target, $targetParts, $origin) = dmdgp_proxy_validate_target($target, $token, $allowedOrigins, $signature, $originCapability);

if ((string)($_GET['__dmdgp_bridge'] ?? '') === 'storage') {
    if ($method !== 'POST') dmdgp_proxy_fail('Méthode de synchronisation invalide.', 405);
    $raw = file_get_contents('php://input');
    $payload = json_decode(is_string($raw) ? $raw : '', true);
    if (!is_array($payload)) dmdgp_proxy_fail('Données de synchronisation invalides.', 400);
    $kind = (string)($payload['kind'] ?? '');
    if ($kind === 'local') {
        dmd_genpw_web_storage_write($token, $origin, is_array($payload['data'] ?? null) ? $payload['data'] : array());
    } elseif ($kind === 'cookie') {
        $cookieValue = is_scalar($payload['value'] ?? null) ? (string)$payload['value'] : '';
        dmdgp_proxy_cookie_write(dmd_genpw_web_cookie_file($token, $origin), $target, $cookieValue);
    } else {
        dmdgp_proxy_fail('Type de synchronisation inconnu.', 400);
    }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Access-Control-Allow-Origin: null');
    header('Access-Control-Allow-Credentials: true');
    http_response_code(204);
    exit;
}

// Paramètres supplémentaires d'un éventuel formulaire GET natif.
if ($method === 'GET') {
    $extra = $_GET;
    foreach (array('__dmdgp_session','__dmdgp_target','__dmdgp_sig','__dmdgp_cap','__dmdgp_mode') as $control) unset($extra[$control]);
    if ($extra) {
        $query = http_build_query($extra, '', '&', PHP_QUERY_RFC3986);
        if ($query !== '') $target .= (strpos($target, '?') === false ? '?' : '&') . $query;
    }
}

if (!function_exists('curl_init')) dmdgp_proxy_fail('L’extension PHP cURL est requise pour la navigation intégrée DMD-GenPW.', 500);
$ch = curl_init();
if ($ch === false) dmdgp_proxy_fail('Impossible d’initialiser la navigation intégrée.', 500);

$responseHeaders = array();
$body = '';
$tooLarge = false;
$headersIn = function_exists('getallheaders') ? getallheaders() : array();
$forwardHeaders = array();
$blockedHeaders = array(
    'host'=>1,'cookie'=>1,'content-length'=>1,'content-type'=>1,'origin'=>1,'referer'=>1,
    'connection'=>1,'proxy-connection'=>1,'upgrade'=>1,'sec-fetch-site'=>1,'sec-fetch-mode'=>1,
    'sec-fetch-dest'=>1,'sec-fetch-user'=>1,'accept-encoding'=>1,
    'if-none-match'=>1,'if-modified-since'=>1,'if-match'=>1,'if-unmodified-since'=>1,'range'=>1
);
if (is_array($headersIn)) {
    foreach ($headersIn as $name=>$value) {
        $lname = strtolower((string)$name);
        if (isset($blockedHeaders[$lname]) || strpos($lname, 'x-dmdgp-') === 0) continue;
        if (!is_scalar($value)) continue;
        $forwardHeaders[] = $name . ': ' . (string)$value;
    }
}
$forwardHeaders[] = 'Accept-Encoding: gzip, deflate';
if (!in_array($method, array('GET', 'HEAD'), true)) {
    $forwardHeaders[] = 'Origin: ' . $origin;
    $forwardHeaders[] = 'Referer: ' . $target;
}

$cookieFile = dmd_genpw_web_cookie_file($token, $origin);
curl_setopt($ch, CURLOPT_URL, $target);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, false);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, DMD_GENPW_PROXY_CONNECT_TIMEOUT);
curl_setopt($ch, CURLOPT_TIMEOUT, DMD_GENPW_PROXY_TIMEOUT);
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_HTTPHEADER, $forwardHeaders);
curl_setopt($ch, CURLOPT_USERAGENT, (string)($_SERVER['HTTP_USER_AGENT'] ?? 'DoMyDesk DMD-GenPW/1.4.0'));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
curl_setopt($ch, CURLOPT_MAXREDIRS, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
$privateTarget = dmdgp_proxy_private_target($targetParts);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, !$privateTarget);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $privateTarget ? 0 : 2);
if (defined('CURLOPT_PROTOCOLS') && defined('CURLPROTO_HTTP') && defined('CURLPROTO_HTTPS')) curl_setopt($ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);

curl_setopt($ch, CURLOPT_HEADERFUNCTION, function ($curl, $line) use (&$responseHeaders) {
    $len = strlen($line);
    $trim = trim($line);
    if ($trim === '' || stripos($trim, 'HTTP/') === 0) return $len;
    $pos = strpos($line, ':');
    if ($pos !== false) {
        $name = strtolower(trim(substr($line, 0, $pos)));
        $value = trim(substr($line, $pos + 1));
        if ($name !== '') $responseHeaders[$name][] = $value;
    }
    return $len;
});

curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($curl, $chunk) use (&$body, &$tooLarge) {
    if (strlen($body) + strlen($chunk) > DMD_GENPW_PROXY_MAX_BYTES) {
        $tooLarge = true;
        return 0;
    }
    $body .= $chunk;
    return strlen($chunk);
});

if ($method === 'HEAD') {
    curl_setopt($ch, CURLOPT_NOBODY, true);
} elseif ($method !== 'GET') {
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    $contentTypeIn = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
    if (strpos($contentTypeIn, 'application/x-www-form-urlencoded') === false && strpos($contentTypeIn, 'multipart/form-data') === false) {
        if ($contentTypeIn !== '') {
            $forwardHeaders[] = 'Content-Type: ' . (string)($_SERVER['CONTENT_TYPE'] ?? 'application/octet-stream');
            curl_setopt($ch, CURLOPT_HTTPHEADER, $forwardHeaders);
        }
        $raw = file_get_contents('php://input');
        if (is_string($raw)) curl_setopt($ch, CURLOPT_POSTFIELDS, $raw);
    } else {
        $fields = $_POST;
        foreach (array('__dmdgp_session','__dmdgp_target','__dmdgp_sig','__dmdgp_cap','__dmdgp_mode') as $control) unset($fields[$control]);
        if (!empty($_FILES)) {
            foreach ($_FILES as $name=>$file) {
                if (!is_array($file) || !isset($file['tmp_name']) || is_array($file['tmp_name']) || !is_uploaded_file((string)$file['tmp_name'])) continue;
                $fields[$name] = new CURLFile((string)$file['tmp_name'], (string)($file['type'] ?? 'application/octet-stream'), (string)($file['name'] ?? 'upload.bin'));
            }
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        } else {
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields, '', '&', PHP_QUERY_RFC3986));
            $forwardHeaders[] = 'Content-Type: application/x-www-form-urlencoded';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $forwardHeaders);
        }
    }
}

$ok = curl_exec($ch);
$errno = curl_errno($ch);
$error = curl_error($ch);
$status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
$primaryIp = (string)curl_getinfo($ch, CURLINFO_PRIMARY_IP);
curl_close($ch);
@chmod($cookieFile, 0600);

if ($primaryIp !== '' && dmdgp_proxy_ip_forbidden($primaryIp)) dmdgp_proxy_fail('La destination a résolu vers une adresse système interdite.', 403);
if ($tooLarge) dmdgp_proxy_fail('La réponse distante dépasse la limite de 32 Mio de la navigation intégrée.', 413);
if ($ok === false || $errno !== 0) dmdgp_proxy_fail('Le site distant ne répond pas depuis le serveur DoMyDesk : ' . ($error !== '' ? $error : 'erreur réseau'), 502);

if ($status === 304) dmdgp_proxy_fail('Le site distant a renvoyé une réponse vide inattendue. Rechargez l’onglet.', 502);

if ($status >= 300 && $status < 400 && !empty($responseHeaders['location'][0])) {
    $next = dmdgp_proxy_normalize_url((string)$responseHeaders['location'][0], $effective !== '' ? $effective : $target);
    if ($next === null) dmdgp_proxy_fail('Redirection distante invalide.', 502);
    $nextParts = parse_url($next);
    if (is_array($nextParts) && isset($nextParts['host']) && filter_var((string)$nextParts['host'], FILTER_VALIDATE_IP) !== false && dmdgp_proxy_ip_forbidden((string)$nextParts['host'])) {
        dmdgp_proxy_fail('Redirection refusée vers une adresse système.', 403);
    }
    header('Location: ' . dmdgp_proxy_url($next, $token, true), true, $status);
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Access-Control-Allow-Origin: null');
    header('Access-Control-Allow-Credentials: true');
    exit;
}

$contentType = !empty($responseHeaders['content-type'][0]) ? (string)$responseHeaders['content-type'][0] : 'application/octet-stream';
$remoteForRewrite = $effective !== '' ? $effective : $target;
$probe = ltrim(substr($body, 0, 4096));
$looksHtml = preg_match('~^(?:<!doctype\s+html\b|<html\b|<head\b|<body\b|<meta\b|<title\b|<script\b|<style\b|<div\b)~i', $probe) === 1;
$isGenericType = trim($contentType) === ''
    || stripos($contentType, 'application/octet-stream') !== false
    || stripos($contentType, 'binary/octet-stream') !== false
    || stripos($contentType, 'text/plain') !== false;
if (stripos($contentType, 'text/html') !== false || stripos($contentType, 'application/xhtml+xml') !== false || ($isGenericType && $looksHtml)) {
    $body = dmdgp_proxy_rewrite_html($body, $remoteForRewrite, $token, $proxyMode);
    $contentType = 'text/html; charset=utf-8';
} elseif (stripos($contentType, 'text/css') !== false) {
    $body = dmdgp_proxy_rewrite_css($body, $remoteForRewrite, $token);
} elseif (
    stripos($contentType, 'javascript') !== false
    || stripos($contentType, 'ecmascript') !== false
    || preg_match('~(?:^|/)x?-?javascript(?:;|$)~i', $contentType)
) {
    // Ne jamais réécrire le code JavaScript avec des regex : cela pouvait corrompre
    // les bundles et provoquer exactement l'écran vide observé. Le pont injecté dans
    // le HTML gère fetch/XHR/window.open sans modifier les octets du script distant.
}

http_response_code($status > 0 ? $status : 200);
header('Content-Type: ' . $contentType);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
// Ne pas imposer nosniff ici : des interfaces NAS/IoT anciennes renvoient parfois un MIME erroné
// pour leurs scripts/CSS et le navigateur les bloquerait alors dans la navigation intégrée.
header('Referrer-Policy: no-referrer');
header('X-DMD-GenPW-Proxy: 1');
header('Access-Control-Allow-Origin: null');
header('Access-Control-Allow-Credentials: true');
if (!empty($responseHeaders['content-disposition'][0])) header('Content-Disposition: ' . (string)$responseHeaders['content-disposition'][0]);
if ($method !== 'HEAD') echo $body;
