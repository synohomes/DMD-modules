<?php
declare(strict_types=1);

if (!defined('DMD_GENPW_ID')) define('DMD_GENPW_ID', 'DMD-GenPW');

function dmd_genpw_module_web_path() {
    $documentRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? ''));
    $moduleRealDir = realpath(__DIR__);
    if ($documentRoot !== false && $moduleRealDir !== false) {
        $doc = rtrim(str_replace('\\', '/', $documentRoot), '/');
        $mod = rtrim(str_replace('\\', '/', $moduleRealDir), '/');
        if ($doc !== '' && ($mod === $doc || strpos($mod, $doc . '/') === 0)) {
            $relative = ltrim(substr($mod, strlen($doc)), '/');
            return '/' . $relative;
        }
    }

    /* MyDesk peut charger le point d'entrée via une route intermédiaire. Dans ce
       cas dirname(SCRIPT_NAME)/modules/... fabriquait une URL invalide. On garde
       d'abord un éventuel vrai chemin /modules/<module>/ déjà présent. */
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $folder = basename(__DIR__);
    $marker = '/modules/' . $folder;
    $pos = stripos($script, $marker);
    if ($pos !== false) {
        return substr($script, 0, $pos) . $marker;
    }

    /* DoMyDesk peut être installé sous /domydesk ou directement à la racine. */
    if (preg_match('~^(/[^/]+)(?:/|$)~', $script, $m) && strtolower($m[1]) === '/domydesk') {
        return '/domydesk/modules/' . rawurlencode($folder);
    }
    return '/modules/' . rawurlencode($folder);
}

function dmd_genpw_domydesk_web_base() {
    $module = dmd_genpw_module_web_path();
    $pos = strpos($module, '/modules/');
    if ($pos !== false) return rtrim(substr($module, 0, $pos), '/');
    return '';
}

function dmd_genpw_user_theme($email) {
    $theme = 'default';
    try {
        $profileDir = dmd_genpw_profile_dir($email);
        $data = dmd_genpw_read_json($profileDir . '/theme.json', array());
        $candidate = isset($data['theme']) && is_scalar($data['theme']) ? basename(trim((string)$data['theme'])) : '';
        if ($candidate !== '' && is_file(dmd_genpw_root() . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
    } catch (Throwable $e) {}
    return $theme;
}

function dmd_genpw_user_theme_url($email) {
    $base = dmd_genpw_domydesk_web_base();
    return $base . '/theme/' . rawurlencode(dmd_genpw_user_theme($email)) . '/style.css';
}

if (!defined('DMD_GENPW_VERSION')) define('DMD_GENPW_VERSION', '1.4.2');
if (!defined('DMD_GENPW_UNLOCK_DEFAULT')) define('DMD_GENPW_UNLOCK_DEFAULT', 300);
if (!defined('DMD_GENPW_MAX_UNLOCK_FAILURES')) define('DMD_GENPW_MAX_UNLOCK_FAILURES', 5);
if (!defined('DMD_GENPW_BLOCK_SECONDS')) define('DMD_GENPW_BLOCK_SECONDS', 300);

function dmd_genpw_root() {
    $root = realpath(__DIR__ . '/../..');
    return $root !== false ? $root : dirname(__DIR__, 2);
}

function dmd_genpw_boot_core() {
    $root = dmd_genpw_root();
    $files = array(
        $root . '/core/dmd_permissions.php',
        $root . '/core/dmd_mfa.php',
        $root . '/core/dmd_system_services.php',
        $root . '/core/dmd_activity.php',
        $root . '/core/dmd_module_logs.php',
        $root . '/core/dmd_module_events.php',
        $root . '/Quick-Session/dmd_quick_session.php',
        $root . '/core/dmd_quick_session.php'
    );
    foreach ($files as $file) {
        if (is_file($file)) require_once $file;
    }
}

function dmd_genpw_email() {
    return trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : (isset($_SESSION['email']) ? $_SESSION['email'] : (isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''))));
}

function dmd_genpw_logged_in() {
    return filter_var(dmd_genpw_email(), FILTER_VALIDATE_EMAIL) !== false;
}

function dmd_genpw_has_permission($permission) {
    if (!dmd_genpw_logged_in()) return false;
    dmd_genpw_boot_core();
    if (function_exists('dmd_current_user_has_module_permission')) {
        try {
            return (bool)dmd_current_user_has_module_permission(DMD_GENPW_ID, (string)$permission);
        } catch (Throwable $e) {
            return false;
        }
    }
    return false;
}

function dmd_genpw_user_has_permission($email, $permission) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return false;
    dmd_genpw_boot_core();
    if (function_exists('dmd_user_has_module_permission')) {
        try { return (bool)dmd_user_has_module_permission($email, DMD_GENPW_ID, (string)$permission); } catch (Throwable $e) { return false; }
    }
    return false;
}

function dmd_genpw_require_permission($permission) {
    if (!dmd_genpw_has_permission($permission)) {
        dmd_genpw_reply(array('ok' => false, 'error' => 'Accès refusé', 'permission' => (string)$permission), 403);
    }
}

function dmd_genpw_profiles_root() {
    return dmd_genpw_root() . '/users/profiles';
}

function dmd_genpw_profile_dir($email) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) throw new InvalidArgumentException('Utilisateur invalide.');
    $base = dmd_genpw_profiles_root();
    $candidate = $base . DIRECTORY_SEPARATOR . $email;
    if (!is_dir($candidate)) throw new RuntimeException('Profil utilisateur introuvable.');
    $realBase = realpath($base);
    $realCandidate = realpath($candidate);
    if ($realBase === false || $realCandidate === false || strpos($realCandidate, $realBase . DIRECTORY_SEPARATOR) !== 0) {
        throw new RuntimeException('Profil utilisateur invalide.');
    }
    return $realCandidate;
}

function dmd_genpw_atomic_write($path, $contents, $mode = 0600) {
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) throw new RuntimeException('Impossible de créer le stockage DMD-GenPW.');
    $tmp = tempnam($dir, '.dmd-genpw-');
    if ($tmp === false) throw new RuntimeException('Impossible de préparer l’écriture DMD-GenPW.');
    try {
        if (file_put_contents($tmp, $contents, LOCK_EX) === false) throw new RuntimeException('Impossible d’écrire les données DMD-GenPW.');
        @chmod($tmp, $mode);
        if (!@rename($tmp, $path)) {
            if (!@copy($tmp, $path)) throw new RuntimeException('Impossible de finaliser l’écriture DMD-GenPW.');
            @unlink($tmp);
        }
        @chmod($path, $mode);
    } finally {
        if (is_file($tmp)) @unlink($tmp);
    }
}

function dmd_genpw_protect_directory($dir) {
    if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) throw new RuntimeException('Impossible de créer le dossier sécurisé DMD-GenPW.');
    @chmod($dir, 0770);
    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) {
        dmd_genpw_atomic_write($ht, "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n", 0640);
    }
    $index = $dir . '/index.php';
    if (!is_file($index)) dmd_genpw_atomic_write($index, "<?php http_response_code(404); exit;\n", 0640);
}

function dmd_genpw_user_dir($email, $migrate = true) {
    $profile = dmd_genpw_profile_dir($email);
    $dir = $profile . '/' . DMD_GENPW_ID;
    $legacy = $profile . '/genpw';
    if ($migrate && !is_dir($dir) && is_dir($legacy)) {
        if (!@rename($legacy, $dir)) {
            @mkdir($dir, 0770, true);
            foreach (array('pw.json','key.bin','shared.json','config.json') as $name) {
                if (is_file($legacy . '/' . $name) && !is_file($dir . '/' . $name)) @copy($legacy . '/' . $name, $dir . '/' . $name);
            }
            if (is_dir($legacy . '/.private') && !is_dir($dir . '/.private')) @rename($legacy . '/.private', $dir . '/.private');
        }
    }
    dmd_genpw_protect_directory($dir);
    return $dir;
}

function dmd_genpw_system_dir() {
    $dir = dmd_genpw_root() . '/data/modules/' . DMD_GENPW_ID;
    dmd_genpw_protect_directory($dir);
    return $dir;
}

function dmd_genpw_web_sessions_dir() {
    $dir = dmd_genpw_system_dir() . '/private/web_sessions';
    dmd_genpw_protect_directory($dir);
    return $dir;
}

function dmd_genpw_web_proxy_key() {
    $dir = dmd_genpw_system_dir() . '/private';
    dmd_genpw_protect_directory($dir);
    $path = $dir . '/web_proxy.key';
    if (!is_file($path)) dmd_genpw_atomic_write($path, random_bytes(32), 0600);
    $key = @file_get_contents($path);
    if (!is_string($key) || strlen($key) !== 32) throw new RuntimeException('Clé du navigateur DMD-GenPW invalide.');
    return $key;
}

function dmd_genpw_web_session_token_valid($token) {
    return is_string($token) && preg_match('/^[a-f0-9]{64}$/D', $token) === 1;
}

function dmd_genpw_web_session_path($token) {
    if (!dmd_genpw_web_session_token_valid($token)) throw new InvalidArgumentException('Session web DMD-GenPW invalide.');
    return dmd_genpw_web_sessions_dir() . '/' . hash('sha256', $token) . '.json';
}

function dmd_genpw_web_session_user_agent_hash() {
    return hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
}

function dmd_genpw_web_session_create($email) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) throw new InvalidArgumentException('Utilisateur invalide.');
    $token = bin2hex(random_bytes(32));
    $now = time();
    $ttl = dmd_genpw_unlock_timeout($email);
    $record = array(
        'email'=>$email,
        'created_at'=>$now,
        'last_used'=>$now,
        'expires_at'=>$now + $ttl,
        'user_agent'=>dmd_genpw_web_session_user_agent_hash()
    );
    dmd_genpw_write_json(dmd_genpw_web_session_path($token), $record);
    return array('token'=>$token,'expires_in'=>$ttl,'record'=>$record);
}

function dmd_genpw_web_session_validate($token, $touch = true) {
    if (!dmd_genpw_web_session_token_valid($token)) return null;
    try { $path = dmd_genpw_web_session_path($token); } catch (Throwable $e) { return null; }
    $record = dmd_genpw_read_json($path, array());
    $email = isset($record['email']) ? trim((string)$record['email']) : '';
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) { @unlink($path); return null; }
    if (!hash_equals((string)($record['user_agent'] ?? ''), dmd_genpw_web_session_user_agent_hash())) return null;
    $now = time();
    if ((int)($record['expires_at'] ?? 0) < $now) { @unlink($path); return null; }
    if ($touch) {
        $record['last_used'] = $now;
        $record['expires_at'] = $now + dmd_genpw_unlock_timeout($email);
        try { dmd_genpw_write_json($path, $record); } catch (Throwable $e) { return null; }
    }
    $record['token'] = $token;
    return $record;
}

function dmd_genpw_web_session_revoke($token, $email = null) {
    if (!dmd_genpw_web_session_token_valid($token)) return false;
    try { $path = dmd_genpw_web_session_path($token); } catch (Throwable $e) { return false; }
    if ($email !== null) {
        $record = dmd_genpw_read_json($path, array());
        if (!isset($record['email']) || !hash_equals((string)$email, (string)$record['email'])) return false;
    }
    $deleted = !is_file($path) || @unlink($path);
    foreach (array('cookies','storage') as $bucket) {
        $dataDir = dmd_genpw_web_sessions_dir() . '/' . $bucket . '/' . hash('sha256', $token);
        if (is_dir($dataDir)) {
            $items = @scandir($dataDir);
            if (is_array($items)) foreach ($items as $name) if ($name !== '.' && $name !== '..') @unlink($dataDir . '/' . $name);
            @rmdir($dataDir);
        }
    }
    return $deleted;
}

function dmd_genpw_web_sessions_revoke_user($email) {
    $dir = dmd_genpw_web_sessions_dir();
    $items = @glob($dir . '/*.json');
    if (!is_array($items)) return 0;
    $count = 0;
    foreach ($items as $path) {
        $record = dmd_genpw_read_json($path, array());
        if (!isset($record['email']) || !hash_equals((string)$email, (string)$record['email'])) continue;
        $base = basename($path, '.json');
        if (@unlink($path)) $count++;
        foreach (array('cookies','storage') as $bucket) {
            $dataDir = $dir . '/' . $bucket . '/' . $base;
            if (is_dir($dataDir)) {
                $dataItems = @scandir($dataDir);
                if (is_array($dataItems)) foreach ($dataItems as $name) if ($name !== '.' && $name !== '..') @unlink($dataDir . '/' . $name);
                @rmdir($dataDir);
            }
        }
    }
    return $count;
}

function dmd_genpw_web_proxy_sign_target($token, $target) {
    if (!dmd_genpw_web_session_token_valid($token)) return '';
    return hash_hmac('sha256', 'target|' . $token . '|' . (string)$target, dmd_genpw_web_proxy_key());
}

function dmd_genpw_web_proxy_verify_target($token, $target, $signature) {
    if (!is_string($signature) || preg_match('/^[a-f0-9]{64}$/D', $signature) !== 1) return false;
    $expected = dmd_genpw_web_proxy_sign_target($token, $target);
    return $expected !== '' && hash_equals($expected, $signature);
}

function dmd_genpw_web_proxy_origin_cap($token, $origin) {
    if (!dmd_genpw_web_session_token_valid($token)) return '';
    return hash_hmac('sha256', 'origin|' . $token . '|' . strtolower((string)$origin), dmd_genpw_web_proxy_key());
}

function dmd_genpw_web_proxy_verify_origin_cap($token, $origin, $capability) {
    if (!is_string($capability) || preg_match('/^[a-f0-9]{64}$/D', $capability) !== 1) return false;
    $expected = dmd_genpw_web_proxy_origin_cap($token, $origin);
    return $expected !== '' && hash_equals($expected, $capability);
}

function dmd_genpw_web_cookie_file($token, $origin) {
    if (!dmd_genpw_web_session_token_valid($token)) throw new InvalidArgumentException('Session web invalide.');
    $dir = dmd_genpw_web_sessions_dir() . '/cookies/' . hash('sha256', $token);
    dmd_genpw_protect_directory($dir);
    $path = $dir . '/' . hash('sha256', strtolower((string)$origin)) . '.cookies';
    if (!is_file($path)) dmd_genpw_atomic_write($path, '', 0600);
    return $path;
}

function dmd_genpw_web_storage_file($token, $origin) {
    if (!dmd_genpw_web_session_token_valid($token)) throw new InvalidArgumentException('Session web invalide.');
    $dir = dmd_genpw_web_sessions_dir() . '/storage/' . hash('sha256', $token);
    dmd_genpw_protect_directory($dir);
    return $dir . '/' . hash('sha256', strtolower((string)$origin)) . '.json';
}

function dmd_genpw_web_storage_read($token, $origin) {
    $path = dmd_genpw_web_storage_file($token, $origin);
    $data = dmd_genpw_read_json($path, array());
    $out = array();
    foreach ($data as $key=>$value) {
        if (!is_string($key) || strlen($key) > 512 || !is_scalar($value)) continue;
        $out[$key] = substr((string)$value, 0, 262144);
        if (count($out) >= 512) break;
    }
    return $out;
}

function dmd_genpw_web_storage_write($token, $origin, $data) {
    if (!is_array($data)) $data = array();
    $out = array(); $total = 0;
    foreach ($data as $key=>$value) {
        if (!is_string($key) || strlen($key) > 512 || !is_scalar($value)) continue;
        $value = substr((string)$value, 0, 262144);
        $total += strlen($key) + strlen($value);
        if ($total > 1048576) break;
        $out[$key] = $value;
        if (count($out) >= 512) break;
    }
    dmd_genpw_write_json(dmd_genpw_web_storage_file($token, $origin), $out);
    return $out;
}

function dmd_genpw_read_json($path, $fallback = array()) {
    if (!is_file($path)) return $fallback;
    $raw = @file_get_contents($path);
    if (!is_string($raw) || trim($raw) === '') return $fallback;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
}

function dmd_genpw_write_json($path, $data) {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) throw new RuntimeException('Impossible d’encoder les données DMD-GenPW.');
    dmd_genpw_atomic_write($path, $json . "\n", 0600);
}

function dmd_genpw_mydesk_mode($email) {
    $file = dmd_genpw_user_dir($email) . '/mydesk.json';
    $data = dmd_genpw_read_json($file, array());
    $mode = strtolower(trim((string)(isset($data['mode']) ? $data['mode'] : 'compact')));
    return $mode === 'full' ? 'full' : 'compact';
}

function dmd_genpw_set_mydesk_mode($email, $mode) {
    $mode = strtolower(trim((string)$mode)) === 'full' ? 'full' : 'compact';
    dmd_genpw_write_json(dmd_genpw_user_dir($email) . '/mydesk.json', array(
        'mode'=>$mode,
        'updated_at'=>date(DATE_ATOM)
    ));
    return $mode;
}

function dmd_genpw_append_jsonl($path, $row) {
    dmd_genpw_protect_directory(dirname($path));
    $line = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($line) || file_put_contents($path, $line . "\n", FILE_APPEND | LOCK_EX) === false) throw new RuntimeException('Impossible d’écrire le journal DMD-GenPW.');
    @chmod($path, 0640);
}

function dmd_genpw_clean($value, $max) {
    $value = trim(is_scalar($value) ? (string)$value : '');
    return function_exists('mb_substr') ? mb_substr($value, 0, (int)$max, 'UTF-8') : substr($value, 0, (int)$max);
}

function dmd_genpw_valid_id($id) {
    $id = is_scalar($id) ? strtolower((string)$id) : '';
    return preg_match('/^[a-f0-9]{16}$/D', $id) ? $id : null;
}

function dmd_genpw_reply($payload, $status = 200) {
    http_response_code((int)$status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function dmd_genpw_csrf() {
    if (empty($_SESSION['dmd_genpw_csrf']) || !is_string($_SESSION['dmd_genpw_csrf'])) $_SESSION['dmd_genpw_csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['dmd_genpw_csrf'];
}

function dmd_genpw_profile($email) {
    dmd_genpw_boot_core();
    $profile = array();
    /* Les versions de DoMyDesk n'ont pas toutes rangé profile.json au même endroit.
       On fusionne les sources au lieu de considérer un tableau vide du Core comme définitif. */
    $dir = dmd_genpw_profile_dir($email);
    foreach (array($dir . '/profile.json', $dir . '/profile/profile.json') as $file) {
        if (is_file($file)) {
            $local = dmd_genpw_read_json($file, array());
            if (is_array($local) && $local) $profile = array_replace($profile, $local);
        }
    }
    if (function_exists('dmd_read_profile')) {
        try {
            $coreProfile = dmd_read_profile($email);
            if (is_array($coreProfile) && $coreProfile) $profile = array_replace($profile, $coreProfile);
        } catch (Throwable $e) {}
    }
    return $profile;
}

function dmd_genpw_language() {
    /* La langue appartient au SYSTEME DoMyDesk : aucun choix ni stockage de langue dans le module. */
    dmd_genpw_boot_core();
    $value = '';
    foreach (array('dmd_current_language','dmd_current_locale','dmd_system_language') as $fn) {
        if (function_exists($fn)) {
            try {
                $candidate = $fn();
                if (is_scalar($candidate) && trim((string)$candidate) !== '') { $value = (string)$candidate; break; }
            } catch (Throwable $e) {}
        }
    }
    if ($value === '') {
        $root = dmd_genpw_root();
        foreach (array($root . '/adm/settings.json', $root . '/adm/data/settings.json') as $file) {
            $settings = dmd_genpw_read_json($file, array());
            $candidates = array(
                isset($settings['language']) ? $settings['language'] : '',
                isset($settings['lang']) ? $settings['lang'] : '',
                isset($settings['locale']) ? $settings['locale'] : '',
                isset($settings['default_language']) ? $settings['default_language'] : '',
                isset($settings['system_language']) ? $settings['system_language'] : '',
                isset($settings['system']['language']) ? $settings['system']['language'] : '',
                isset($settings['system']['lang']) ? $settings['system']['lang'] : '',
                isset($settings['system']['locale']) ? $settings['system']['locale'] : ''
            );
            foreach ($candidates as $candidate) {
                if (is_scalar($candidate) && trim((string)$candidate) !== '') { $value = (string)$candidate; break 2; }
            }
        }
    }
    $value = trim((string)$value);
    if ($value === '') return 'fr';
    $value = basename(str_replace('\\', '/', $value));
    return $value !== '' ? $value : 'fr';
}

function dmd_genpw_i18n() {
    return array(
        'fr' => array(
            'title'=>'Coffre de mots de passe','subtitle'=>'Génération sécurisée, stockage chiffré et accès temporaire.','generator'=>'Nouvelle entrée','vault'=>'Accès au coffre','name'=>'Nom','category'=>'Catégorie','url'=>'URL','user'=>'Identifiant / e-mail','ssid'=>'Nom du réseau (SSID)','length'=>'Longueur','specials'=>'Caractères spéciaux','manual'=>'Mot de passe existant','wifi_manual'=>'Clé Wi-Fi existante','generate'=>'Générer','use'=>'Utiliser','copy'=>'Copier','save'=>'Enregistrer dans le coffre','update'=>'Enregistrer les modifications','notes'=>'Notes','strength'=>'Robustesse','locked'=>'Coffre verrouillé','unlock_help'=>'Saisissez le mot de passe de verrouillage défini dans le CFG DMD-GenPW. Si aucun mot de passe spécifique n’est défini, le mot de passe du compte DoMyDesk reste accepté.','account_password'=>'Mot de passe de verrouillage','unlock'=>'Déverrouiller','refresh'=>'Actualiser','lock'=>'Verrouiller','search'=>'Rechercher…','delete_selected'=>'Supprimer la sélection','empty'=>'Aucune entrée.','edit'=>'Modifier','reveal'=>'Afficher','hide'=>'Masquer','qr'=>'QR 60 s','share'=>'Partager','shares'=>'Partages','revoke'=>'Retirer','website'=>'Ouvrir le site','shared_by'=>'Partagé par','read_only'=>'Lecture seule','import'=>'Importer','export'=>'Exporter','export_json'=>'JSON','export_csv'=>'CSV','include_secrets'=>'Inclure les secrets','logs'=>'Journal','load_logs'=>'Afficher le journal','export_logs'=>'Exporter le journal','clear_logs'=>'Supprimer mon journal','recipients'=>'Destinataires','close'=>'Fermer','cancel'=>'Annuler','config'=>'Configuration','default_length'=>'Longueur par défaut','default_specials'=>'Caractères spéciaux par défaut','auto_lock'=>'Verrouillage automatique (minutes)','default_category'=>'Catégorie par défaut','save_config'=>'Enregistrer la configuration','saved'=>'Enregistré.','error'=>'Erreur','copied'=>'Copié.','confirm_delete'=>'Supprimer les éléments sélectionnés ?','confirm_revoke'=>'Retirer ce partage ?','confirm_logs'=>'Supprimer votre journal DMD-GenPW ?','config_user_note'=>'Les réglages ci-dessous sont propres à l’utilisateur.','system_language_note'=>'La langue est celle définie par le système DoMyDesk.','vault_password'=>'Mot de passe de verrouillage du coffre','vault_password_new'=>'Nouveau mot de passe de verrouillage','vault_password_confirm'=>'Confirmer le mot de passe','vault_password_set'=>'Un mot de passe de verrouillage spécifique est configuré.','vault_password_not_set'=>'Aucun mot de passe spécifique : le mot de passe du compte DoMyDesk est utilisé.','clear_vault_password'=>'Supprimer le mot de passe spécifique et revenir au mot de passe DoMyDesk','single_use'=>'usage unique','empty_password'=>'Mot de passe vide','strength_none'=>'Robustesse non évaluée','strength_very_weak'=>'Très faible (motif commun)','strength_medium'=>'Moyen','strength_excellent'=>'Excellent','time_instant'=>'Moins d’une seconde','millennia'=>'Des millénaires','years'=>'an(s)','days'=>'jour(s)','hours'=>'heure(s)','minutes'=>'minute(s)','seconds'=>'Quelques secondes','copy_user'=>'Copier l’identifiant','actions'=>'Actions','web_tabs'=>'Onglets web','security_note'=>'Le coffre se reverrouille automatiquement après la durée définie dans le CFG. Les mots de passe ne sont récupérés qu’au moment d’un affichage, d’une copie ou d’un QR code.','entries'=>'entrée(s)','categories'=>'Catégories','category_new'=>'Nouvelle catégorie','category_add'=>'Ajouter','category_system'=>'Système','category_custom'=>'Personnalisée','category_rename'=>'Renommer','category_delete'=>'Supprimer','category_delete_confirm'=>'Supprimer cette catégorie ? Les identifiants qu’elle contient seront déplacés dans une autre catégorie.','category_created'=>'Catégorie créée.','category_renamed'=>'Catégorie renommée.','category_deleted'=>'Catégorie supprimée.','cat_Mail'=>'Mail','cat_Site web'=>'Site web','cat_Réseau'=>'Réseau','cat_Serveur'=>'Serveur','cat_Application'=>'Application','cat_Wi-Fi'=>'Wi-Fi','cat_Autre'=>'Autre'
        ),
        'en' => array(
            'title'=>'Password vault','subtitle'=>'Secure generation, encrypted storage and temporary access.','generator'=>'New entry','vault'=>'Vault access','name'=>'Name','category'=>'Category','url'=>'URL','user'=>'Username / email','ssid'=>'Network name (SSID)','length'=>'Length','specials'=>'Special characters','manual'=>'Existing password','wifi_manual'=>'Existing Wi-Fi key','generate'=>'Generate','use'=>'Use','copy'=>'Copy','save'=>'Save to vault','update'=>'Save changes','notes'=>'Notes','strength'=>'Strength','locked'=>'Vault locked','unlock_help'=>'Enter the vault lock password defined in DMD-GenPW settings. If none is defined, your DoMyDesk account password remains accepted.','account_password'=>'Vault lock password','unlock'=>'Unlock','refresh'=>'Refresh','lock'=>'Lock','search'=>'Search…','delete_selected'=>'Delete selection','empty'=>'No entries.','edit'=>'Edit','reveal'=>'Reveal','hide'=>'Hide','qr'=>'QR 60 s','share'=>'Share','shares'=>'Shares','revoke'=>'Revoke','website'=>'Open website','shared_by'=>'Shared by','read_only'=>'Read only','import'=>'Import','export'=>'Export','export_json'=>'JSON','export_csv'=>'CSV','include_secrets'=>'Include secrets','logs'=>'Log','load_logs'=>'Show log','export_logs'=>'Export log','clear_logs'=>'Delete my log','recipients'=>'Recipients','close'=>'Close','cancel'=>'Cancel','config'=>'Settings','default_length'=>'Default length','default_specials'=>'Special characters by default','auto_lock'=>'Auto lock (minutes)','default_category'=>'Default category','save_config'=>'Save settings','saved'=>'Saved.','error'=>'Error','copied'=>'Copied.','confirm_delete'=>'Delete selected items?','confirm_revoke'=>'Revoke this share?','confirm_logs'=>'Delete your DMD-GenPW log?','config_user_note'=>'The settings below are specific to the user.','system_language_note'=>'Language is inherited from the DoMyDesk system setting.','vault_password'=>'Vault lock password','vault_password_new'=>'New lock password','vault_password_confirm'=>'Confirm password','vault_password_set'=>'A dedicated vault lock password is configured.','vault_password_not_set'=>'No dedicated password: the DoMyDesk account password is used.','clear_vault_password'=>'Remove the dedicated password and use the DoMyDesk password again','single_use'=>'single use','empty_password'=>'Password is empty','strength_none'=>'Strength not evaluated','strength_very_weak'=>'Very weak (common pattern)','strength_medium'=>'Medium','strength_excellent'=>'Excellent','time_instant'=>'Less than a second','millennia'=>'Millennia','years'=>'year(s)','days'=>'day(s)','hours'=>'hour(s)','minutes'=>'minute(s)','seconds'=>'A few seconds','copy_user'=>'Copy username','actions'=>'Actions','web_tabs'=>'Web tabs','security_note'=>'The vault locks automatically after the duration set in DMD-GenPW settings. Passwords are only fetched when they are revealed, copied or shown as a QR code.','entries'=>'entry/entries','categories'=>'Categories','category_new'=>'New category','category_add'=>'Add','category_system'=>'System','category_custom'=>'Custom','category_rename'=>'Rename','category_delete'=>'Delete','category_delete_confirm'=>'Delete this category? Credentials inside it will be moved to another category.','category_created'=>'Category created.','category_renamed'=>'Category renamed.','category_deleted'=>'Category deleted.','cat_Mail'=>'Mail','cat_Site web'=>'Website','cat_Réseau'=>'Network','cat_Serveur'=>'Server','cat_Application'=>'Application','cat_Wi-Fi'=>'Wi-Fi','cat_Autre'=>'Other'
        )
    );
}

function dmd_genpw_strings() {
    $all = dmd_genpw_i18n();
    $lang = dmd_genpw_language();
    $langLower = strtolower($lang);
    if (isset($all[$lang])) $strings = $all[$lang];
    elseif (strpos($langLower, 'en') === 0) $strings = $all['en'];
    else $strings = $all['fr'];

    /* Extension par le système de langues DoMyDesk :
       LANG/<dossier-systeme>/DMD-GenPW.json ou LANG/<dossier-systeme>/modules/DMD-GenPW.json.
       Aucun sélecteur ni préférence de langue n'est stocké dans le module. */
    $root = dmd_genpw_root();
    foreach (array('LANG','lang') as $langRootName) {
        $base = $root . '/' . $langRootName . '/' . basename($lang);
        foreach (array($base . '/DMD-GenPW.json', $base . '/modules/DMD-GenPW.json') as $file) {
            $override = dmd_genpw_read_json($file, array());
            if (isset($override['translations']) && is_array($override['translations'])) $override = $override['translations'];
            if (is_array($override) && $override) {
                foreach ($override as $key=>$value) if (is_scalar($value)) $strings[(string)$key] = (string)$value;
                return $strings;
            }
        }
    }
    return $strings;
}

function dmd_genpw_text($fr, $en) {
    return strpos(strtolower(dmd_genpw_language()), 'en') === 0 ? (string)$en : (string)$fr;
}

function dmd_genpw_default_categories() {
    /* Catégories proposées à la première utilisation. Elles restent ensuite
       entièrement gérables par l’utilisateur (renommage / suppression compris). */
    return array('Mail','Site web','Réseau','Serveur','Application','Wi-Fi','Autre');
}

function dmd_genpw_categories_file($email) {
    return dmd_genpw_user_dir($email) . '/categories.json';
}

function dmd_genpw_normalize_category_name($value) {
    $value = dmd_genpw_clean($value, 40);
    $value = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $value);
    $value = preg_replace('/\s+/u', ' ', (string)$value);
    return trim((string)$value);
}

function dmd_genpw_categories_state($email) {
    $stored = dmd_genpw_read_json(dmd_genpw_categories_file($email), array());
    if (!is_array($stored)) $stored = array();
    return $stored;
}

function dmd_genpw_hidden_default_categories($email) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return array();
    $stored = dmd_genpw_categories_state($email);
    $rows = isset($stored['hidden_defaults']) && is_array($stored['hidden_defaults']) ? $stored['hidden_defaults'] : array();
    $out = array();
    foreach ($rows as $row) {
        $name = dmd_genpw_normalize_category_name($row);
        if ($name === '' || !dmd_genpw_is_default_category($name)) continue;
        $duplicate = false;
        foreach ($out as $existing) if (strcasecmp($existing, $name) === 0) { $duplicate = true; break; }
        if (!$duplicate) $out[] = $name;
    }
    return $out;
}

function dmd_genpw_active_default_categories($email) {
    $hidden = dmd_genpw_hidden_default_categories($email);
    $out = array();
    foreach (dmd_genpw_default_categories() as $category) {
        $isHidden = false;
        foreach ($hidden as $disabled) if (strcasecmp($disabled, $category) === 0) { $isHidden = true; break; }
        if (!$isHidden) $out[] = $category;
    }
    return $out;
}

function dmd_genpw_custom_categories($email) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return array();
    $stored = dmd_genpw_categories_state($email);
    $rows = isset($stored['custom']) && is_array($stored['custom']) ? $stored['custom'] : $stored;
    $out = array();
    foreach ($rows as $row) {
        $name = dmd_genpw_normalize_category_name(is_array($row) ? (isset($row['name']) ? $row['name'] : '') : $row);
        if ($name === '') continue;
        $duplicate = false;
        foreach (array_merge(dmd_genpw_default_categories(), $out) as $existing) {
            if (strcasecmp($existing, $name) === 0) { $duplicate = true; break; }
        }
        if (!$duplicate) $out[] = $name;
        if (count($out) >= 100) break;
    }
    return $out;
}

function dmd_genpw_write_categories_state($email, $custom, $hiddenDefaults) {
    $cleanCustom = array();
    foreach ((array)$custom as $category) {
        $name = dmd_genpw_normalize_category_name($category);
        if ($name === '') continue;
        $duplicate = false;
        foreach (array_merge(dmd_genpw_default_categories(), $cleanCustom) as $existing) {
            if (strcasecmp($existing, $name) === 0) { $duplicate = true; break; }
        }
        if (!$duplicate) $cleanCustom[] = $name;
        if (count($cleanCustom) >= 100) break;
    }
    $cleanHidden = array();
    foreach ((array)$hiddenDefaults as $category) {
        $name = dmd_genpw_normalize_category_name($category);
        if ($name === '' || !dmd_genpw_is_default_category($name)) continue;
        $duplicate = false;
        foreach ($cleanHidden as $existing) if (strcasecmp($existing, $name) === 0) { $duplicate = true; break; }
        if (!$duplicate) $cleanHidden[] = $name;
    }
    dmd_genpw_write_json(dmd_genpw_categories_file($email), array(
        'custom'=>$cleanCustom,
        'hidden_defaults'=>$cleanHidden,
        'updated_at'=>date(DATE_ATOM)
    ));
    return $cleanCustom;
}

function dmd_genpw_write_custom_categories($email, $categories) {
    return dmd_genpw_write_categories_state($email, $categories, dmd_genpw_hidden_default_categories($email));
}

function dmd_genpw_set_default_category_hidden($email, $category, $hidden) {
    $category = dmd_genpw_normalize_category_name($category);
    if (!dmd_genpw_is_default_category($category)) return;
    $hiddenDefaults = dmd_genpw_hidden_default_categories($email);
    $next = array(); $found = false;
    foreach ($hiddenDefaults as $existing) {
        if (strcasecmp($existing, $category) === 0) { $found = true; if (!$hidden) continue; }
        $next[] = $existing;
    }
    if ($hidden && !$found) $next[] = $category;
    dmd_genpw_write_categories_state($email, dmd_genpw_custom_categories($email), $next);
}

function dmd_genpw_categories($email = null) {
    $categories = dmd_genpw_default_categories();
    if (is_string($email) && filter_var($email, FILTER_VALIDATE_EMAIL) !== false) {
        $categories = dmd_genpw_active_default_categories($email);
        $hiddenDefaults = dmd_genpw_hidden_default_categories($email);
        foreach (dmd_genpw_custom_categories($email) as $category) {
            $exists = false;
            foreach ($categories as $existing) if (strcasecmp($existing, $category) === 0) { $exists = true; break; }
            if (!$exists) $categories[] = $category;
        }
        /* Compatibilité : une ancienne entrée avec une catégorie personnalisée
           inconnue reste visible, mais une catégorie par défaut volontairement
           supprimée ne réapparaît pas dans le gestionnaire. */
        try {
            $dir = dmd_genpw_user_dir($email);
            foreach (array($dir . '/pw.json', $dir . '/shared.json') as $file) {
                foreach (dmd_genpw_read_json($file, array()) as $entry) {
                    if (!is_array($entry)) continue;
                    $category = dmd_genpw_normalize_category_name(isset($entry['cat']) ? $entry['cat'] : '');
                    if ($category === '') continue;
                    $hidden = false;
                    foreach ($hiddenDefaults as $disabled) if (strcasecmp($disabled, $category) === 0) { $hidden = true; break; }
                    if ($hidden) continue;
                    $exists = false;
                    foreach ($categories as $existing) if (strcasecmp($existing, $category) === 0) { $exists = true; break; }
                    if (!$exists) $categories[] = $category;
                }
            }
        } catch (Throwable $e) {}
    }
    if (!$categories) $categories = array('Autre');
    return $categories;
}

function dmd_genpw_is_default_category($category) {
    foreach (dmd_genpw_default_categories() as $default) if (strcasecmp($default, (string)$category) === 0) return true;
    return false;
}

function dmd_genpw_fallback_category($email, $excluding = '') {
    $categories = dmd_genpw_categories($email);
    foreach ($categories as $category) {
        if ($excluding !== '' && strcasecmp($category, $excluding) === 0) continue;
        if (strcasecmp($category, 'Autre') === 0) return $category;
    }
    foreach ($categories as $category) {
        if ($excluding !== '' && strcasecmp($category, $excluding) === 0) continue;
        return $category;
    }
    return 'Autre';
}

function dmd_genpw_create_category($email, $name) {
    $name = dmd_genpw_normalize_category_name($name);
    if ($name === '') throw new InvalidArgumentException('Le nom de la catégorie est vide.');
    foreach (dmd_genpw_categories($email) as $existing) {
        if (strcasecmp($existing, $name) === 0) throw new InvalidArgumentException('Cette catégorie existe déjà.');
    }
    /* Si l’utilisateur recrée une catégorie fournie à l’origine par DMD-GenPW,
       on la réactive au lieu de créer un doublon personnalisé. */
    if (dmd_genpw_is_default_category($name)) {
        dmd_genpw_set_default_category_hidden($email, $name, false);
        return $name;
    }
    $custom = dmd_genpw_custom_categories($email);
    $custom[] = $name;
    dmd_genpw_write_custom_categories($email, $custom);
    return $name;
}

function dmd_genpw_replace_category_in_file($file, $oldName, $newName) {
    $store = dmd_genpw_read_json($file, array());
    $changed = 0;
    foreach ($store as &$entry) {
        if (!is_array($entry)) continue;
        $category = isset($entry['cat']) ? (string)$entry['cat'] : 'Autre';
        if (strcasecmp($category, $oldName) !== 0) continue;
        $entry['cat'] = $newName;
        $entry['updated_at'] = date(DATE_ATOM);
        $entry['date'] = date('d/m/Y H:i');
        $changed++;
    }
    unset($entry);
    if ($changed > 0) dmd_genpw_write_json($file, $store);
    return $changed;
}

function dmd_genpw_rename_category($email, $oldName, $newName) {
    $oldName = dmd_genpw_normalize_category_name($oldName);
    $newName = dmd_genpw_normalize_category_name($newName);
    if ($oldName === '' || $newName === '') throw new InvalidArgumentException('Nom de catégorie invalide.');
    $active = dmd_genpw_categories($email);
    $resolvedOld = null;
    foreach ($active as $existing) if (strcasecmp($existing, $oldName) === 0) { $resolvedOld = $existing; break; }
    if ($resolvedOld === null) throw new OutOfBoundsException('Catégorie introuvable.');
    $oldName = $resolvedOld;
    if (strcasecmp($oldName, $newName) === 0) return array('old'=>$oldName,'name'=>$oldName,'changed'=>0);
    foreach ($active as $existing) {
        if (strcasecmp($existing, $oldName) !== 0 && strcasecmp($existing, $newName) === 0) throw new InvalidArgumentException('Cette catégorie existe déjà.');
    }

    $custom = dmd_genpw_custom_categories($email);
    if (dmd_genpw_is_default_category($oldName)) {
        dmd_genpw_set_default_category_hidden($email, $oldName, true);
    } else {
        $next = array();
        foreach ($custom as $category) if (strcasecmp($category, $oldName) !== 0) $next[] = $category;
        dmd_genpw_write_custom_categories($email, $next);
    }

    if (dmd_genpw_is_default_category($newName)) {
        dmd_genpw_set_default_category_hidden($email, $newName, false);
    } else {
        $custom = dmd_genpw_custom_categories($email);
        $custom[] = $newName;
        dmd_genpw_write_custom_categories($email, $custom);
    }

    $dir = dmd_genpw_user_dir($email);
    $changed = dmd_genpw_replace_category_in_file($dir . '/pw.json', $oldName, $newName);
    $cfgFile = $dir . '/config.json';
    $cfg = dmd_genpw_read_json($cfgFile, array());
    if (isset($cfg['default_category']) && strcasecmp((string)$cfg['default_category'], $oldName) === 0) {
        $cfg['default_category'] = $newName;
        dmd_genpw_write_json($cfgFile, $cfg);
    }
    return array('old'=>$oldName,'name'=>$newName,'changed'=>$changed);
}

function dmd_genpw_delete_category($email, $name) {
    $name = dmd_genpw_normalize_category_name($name);
    if ($name === '') throw new InvalidArgumentException('Catégorie invalide.');
    $active = dmd_genpw_categories($email);
    $resolved = null;
    foreach ($active as $existing) if (strcasecmp($existing, $name) === 0) { $resolved = $existing; break; }
    if ($resolved === null) throw new OutOfBoundsException('Catégorie introuvable.');
    $name = $resolved;
    if (count($active) <= 1) throw new InvalidArgumentException('Au moins une catégorie doit rester disponible.');
    $fallback = dmd_genpw_fallback_category($email, $name);

    if (dmd_genpw_is_default_category($name)) {
        dmd_genpw_set_default_category_hidden($email, $name, true);
    } else {
        $custom = dmd_genpw_custom_categories($email);
        $kept = array(); $found = false;
        foreach ($custom as $category) {
            if (strcasecmp($category, $name) === 0) { $found = true; continue; }
            $kept[] = $category;
        }
        if (!$found) throw new OutOfBoundsException('Catégorie personnalisée introuvable.');
        dmd_genpw_write_custom_categories($email, $kept);
    }

    $dir = dmd_genpw_user_dir($email);
    $changed = dmd_genpw_replace_category_in_file($dir . '/pw.json', $name, $fallback);
    $cfgFile = $dir . '/config.json';
    $cfg = dmd_genpw_read_json($cfgFile, array());
    if (isset($cfg['default_category']) && strcasecmp((string)$cfg['default_category'], $name) === 0) {
        $cfg['default_category'] = $fallback;
        dmd_genpw_write_json($cfgFile, $cfg);
    }
    return array('name'=>$name,'fallback'=>$fallback,'changed'=>$changed);
}

function dmd_genpw_config_raw($email) {
    $file = dmd_genpw_user_dir($email) . '/config.json';
    $stored = dmd_genpw_read_json($file, array());
    if (!is_array($stored)) $stored = array();

    /* Migration 1.3.3 : le mode de déverrouillage devient explicite.
       Les anciennes versions ne stockaient que require_system_mfa. Si le compte
       possède déjà un MFA DoMyDesk, on restaure une seule fois le comportement
       attendu par le module : MFA seul. Après cette migration, le CFG reste maître. */
    if (!array_key_exists('unlock_mode', $stored)) {
        $mfaAvailable = dmd_genpw_system_mfa_enabled($email);
        $stored['unlock_mode'] = $mfaAvailable ? 'mfa' : (!empty($stored['require_system_mfa']) ? 'mfa' : 'password');
        $stored['require_system_mfa'] = $stored['unlock_mode'] === 'mfa';
        dmd_genpw_write_json($file, $stored);
    }

    $defaults = array(
        'default_length'=>20,
        'default_specials'=>true,
        'auto_lock_minutes'=>5,
        'default_category'=>'Mail',
        'unlock_mode'=>'password',
        'require_system_mfa'=>false,
        'vault_password_hash'=>''
    );
    $cfg = array_merge($defaults, $stored);
    $cfg['default_length'] = max(12, min(128, (int)$cfg['default_length']));
    $cfg['default_specials'] = !empty($cfg['default_specials']);
    $cfg['auto_lock_minutes'] = max(1, min(60, (int)$cfg['auto_lock_minutes']));
    if (!in_array($cfg['default_category'], dmd_genpw_categories($email), true)) $cfg['default_category'] = dmd_genpw_fallback_category($email);
    $cfg['unlock_mode'] = ((string)$cfg['unlock_mode'] === 'mfa') ? 'mfa' : 'password';
    $cfg['require_system_mfa'] = $cfg['unlock_mode'] === 'mfa';
    $cfg['vault_password_hash'] = is_string($cfg['vault_password_hash']) ? $cfg['vault_password_hash'] : '';
    return $cfg;
}

function dmd_genpw_config($email) {
    $raw = dmd_genpw_config_raw($email);
    return array(
        'default_length'=>$raw['default_length'],
        'default_specials'=>$raw['default_specials'],
        'auto_lock_minutes'=>$raw['auto_lock_minutes'],
        'default_category'=>$raw['default_category'],
        'unlock_mode'=>$raw['unlock_mode'],
        'require_system_mfa'=>$raw['require_system_mfa'],
        'system_mfa_enabled'=>dmd_genpw_system_mfa_enabled($email),
        'vault_password_set'=>$raw['vault_password_hash'] !== ''
    );
}

function dmd_genpw_save_config($email, $cfg) {
    $raw = dmd_genpw_config_raw($email);
    if (isset($cfg['default_length'])) $raw['default_length'] = max(12, min(128, (int)$cfg['default_length']));
    if (array_key_exists('default_specials', $cfg)) $raw['default_specials'] = !empty($cfg['default_specials']);
    if (isset($cfg['auto_lock_minutes'])) $raw['auto_lock_minutes'] = max(1, min(60, (int)$cfg['auto_lock_minutes']));
    if (isset($cfg['default_category']) && in_array((string)$cfg['default_category'], dmd_genpw_categories($email), true)) $raw['default_category'] = (string)$cfg['default_category'];
    $previousRequireMfa = !empty($raw['require_system_mfa']);
    if (array_key_exists('require_system_mfa', $cfg)) {
        $requestedRequireMfa = !empty($cfg['require_system_mfa']);
        if ($requestedRequireMfa && !dmd_genpw_system_mfa_enabled($email)) {
            throw new InvalidArgumentException('Activez d’abord le MFA dans votre profil DoMyDesk avant de l’exiger pour DMD-GenPW.');
        }
        $raw['require_system_mfa'] = $requestedRequireMfa;
        $raw['unlock_mode'] = $requestedRequireMfa ? 'mfa' : 'password';
    }

    $newPassword = is_scalar(isset($cfg['vault_password']) ? $cfg['vault_password'] : null) ? (string)$cfg['vault_password'] : '';
    $confirmPassword = is_scalar(isset($cfg['vault_password_confirm']) ? $cfg['vault_password_confirm'] : null) ? (string)$cfg['vault_password_confirm'] : '';
    if (!empty($cfg['clear_vault_password'])) {
        $raw['vault_password_hash'] = '';
    } elseif ($newPassword !== '' || $confirmPassword !== '') {
        if (strlen($newPassword) < 4 || strlen($newPassword) > 4096) throw new InvalidArgumentException('Le mot de passe de verrouillage doit contenir entre 4 et 4096 caractères.');
        if (!hash_equals($newPassword, $confirmPassword)) throw new InvalidArgumentException('La confirmation du mot de passe de verrouillage ne correspond pas.');
        $hash = password_hash($newPassword, PASSWORD_DEFAULT);
        if (!is_string($hash) || $hash === '') throw new RuntimeException('Impossible de protéger le mot de passe de verrouillage.');
        $raw['vault_password_hash'] = $hash;
    }

    dmd_genpw_write_json(dmd_genpw_user_dir($email) . '/config.json', $raw);
    if ($previousRequireMfa !== !empty($raw['require_system_mfa'])) {
        unset($_SESSION['dmd_genpw_unlocked_at'], $_SESSION['dmd_genpw_qr_tokens']);
    }
    return dmd_genpw_config($email);
}

function dmd_genpw_system_mfa_enabled($email) {
    dmd_genpw_boot_core();
    if (!function_exists('dmd_mfa_enabled')) return false;
    try {
        if (function_exists('dmd_mfa_effective_policy') && dmd_mfa_effective_policy($email) === 'disabled') return false;
        return (bool)dmd_mfa_enabled($email);
    } catch (Throwable $e) { return false; }
}

function dmd_genpw_requires_system_mfa($email) {
    $raw = dmd_genpw_config_raw($email);
    if (empty($raw['require_system_mfa'])) return false;
    dmd_genpw_boot_core();
    try {
        if (function_exists('dmd_mfa_effective_policy') && dmd_mfa_effective_policy($email) === 'disabled') return false;
    } catch (Throwable $e) {
        return false;
    }
    return true;
}

function dmd_genpw_verify_system_mfa($email, $code) {
    dmd_genpw_boot_core();
    if (!function_exists('dmd_mfa_verify_totp')) return false;
    $code = preg_replace('/\D+/', '', is_scalar($code) ? (string)$code : '');
    if (strlen($code) !== 6) return false;
    try { return (bool)dmd_mfa_verify_totp($email, $code); } catch (Throwable $e) { return false; }
}

function dmd_genpw_verify_unlock_password($email, $password) {
    $raw = dmd_genpw_config_raw($email);
    if ($raw['vault_password_hash'] !== '') return password_verify((string)$password, $raw['vault_password_hash']);
    $profile = dmd_genpw_profile($email);
    foreach (array('motdepasse','password','mot_de_passe','password_hash') as $key) {
        if (!empty($profile[$key]) && is_string($profile[$key]) && password_verify((string)$password, $profile[$key])) return true;
    }
    return false;
}

function dmd_genpw_unlock_timeout($email) {
    $cfg = dmd_genpw_config($email);
    return max(60, (int)$cfg['auto_lock_minutes'] * 60);
}

function dmd_genpw_is_unlocked($email) {
    if (dmd_genpw_requires_system_mfa($email) && !dmd_genpw_system_mfa_enabled($email)) {
        unset($_SESSION['dmd_genpw_unlocked_at'], $_SESSION['dmd_genpw_qr_tokens']);
        return false;
    }
    $last = (int)(isset($_SESSION['dmd_genpw_unlocked_at']) ? $_SESSION['dmd_genpw_unlocked_at'] : 0);
    $timeout = dmd_genpw_unlock_timeout($email);
    if ($last <= 0 || (time() - $last) > $timeout) {
        unset($_SESSION['dmd_genpw_unlocked_at'], $_SESSION['dmd_genpw_qr_tokens']);
        return false;
    }
    return true;
}

function dmd_genpw_touch_unlock($email) {
    if (!dmd_genpw_is_unlocked($email)) dmd_genpw_reply(array('ok'=>false,'error'=>'Coffre verrouillé','locked'=>true), 423);
    $_SESSION['dmd_genpw_unlocked_at'] = time();
}

function dmd_genpw_resource($id, $name, $owner) {
    $label = dmd_genpw_clean($name !== '' ? $name : 'Identifiant', 120);
    return array(
        'id' => DMD_GENPW_ID . ':credential:' . $id,
        'type' => 'credential',
        'local_id' => $id,
        'name' => $label,
        'label' => $label,
        'owner' => $owner,
        'module' => DMD_GENPW_ID,
        'source' => DMD_GENPW_ID,
        'tags' => array('credential', 'vault')
    );
}

function dmd_genpw_vault_resource($email = '') {
    return array(
        'id' => DMD_GENPW_ID . ':vault',
        'type' => 'credential_vault',
        'name' => 'DMD-GenPW',
        'label' => 'DMD-GenPW',
        'owner' => $email,
        'module' => DMD_GENPW_ID,
        'source' => DMD_GENPW_ID,
        'tags' => array('credential_vault', 'security')
    );
}

function dmd_genpw_quick_session($email) {
    dmd_genpw_boot_core();
    if (function_exists('dmd_qs_get_active')) {
        try { $v = dmd_qs_get_active($email); return is_array($v) ? $v : null; } catch (Throwable $e) {}
    }
    return null;
}

function dmd_genpw_log($action, $target, $status, $details, $resource = null) {
    $email = dmd_genpw_email();
    $safe = is_array($details) ? $details : array();
    foreach (array('password','pwd','pw','secret','motdepasse','token') as $key) unset($safe[$key]);
    $qs = $email !== '' ? dmd_genpw_quick_session($email) : null;
    $row = array('datetime'=>date(DATE_ATOM),'module'=>DMD_GENPW_ID,'user'=>$email,'action'=>(string)$action,'target'=>(string)$target,'status'=>(string)$status,'details'=>$safe,'resource'=>$resource,'quick_session_active'=>$qs !== null);
    if (is_array($qs)) {
        foreach (array('id','session_id','uuid') as $key) if (!empty($qs[$key])) { $row['quick_session_id'] = (string)$qs[$key]; break; }
    }
    $dir = dmd_genpw_system_dir() . '/logs';
    dmd_genpw_append_jsonl($dir . '/' . date('Y-m') . '.jsonl', $row);

    /* Index d'activité ciblé, event-driven : aucune lecture périodique des logs.
       Une Quick-Session active reçoit uniquement les événements produits par l'action courante. */
    if ($resource !== null && is_array($resource)) {
        $activityDir = dmd_genpw_system_dir() . '/activity';
        dmd_genpw_append_jsonl($activityDir . '/' . date('Y-m') . '.jsonl', $row);
        if (!empty($row['quick_session_id'])) {
            $qsSafe = preg_replace('/[^a-zA-Z0-9_.-]/', '_', (string)$row['quick_session_id']);
            if ($qsSafe !== '') dmd_genpw_append_jsonl($activityDir . '/quick-session/' . $qsSafe . '.jsonl', $row);
        }
    }

    dmd_genpw_boot_core();

    /* Contrat DoMyDesk 1.2.x : publication ciblée vers le bus d'activité.
       Le journal propre à GenPW reste utilisé par son écran "Journal", donc
       on évite seulement le doublon du journal Core. */
    if ($resource !== null && is_array($resource) && function_exists('dmd_module_event')) {
        try {
            $detailsText = '';
            if ($safe) {
                $encoded = json_encode($safe, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                if (is_string($encoded)) $detailsText = $encoded;
            }
            $event = dmd_module_event(DMD_GENPW_ID, (string)$action, $resource, array(
                'email' => $email,
                'label' => (string)$action,
                'target' => (string)$target,
                'status' => (string)$status,
                'details' => $detailsText,
                'meta' => array('source' => 'DMD-GenPW'),
                'log' => false
            ));
            if (is_array($event) && !empty($event['event'])) $row['core_event'] = $event['event'];
        } catch (Throwable $e) {}
    }

    if (function_exists('dmd_system_log')) {
        try { dmd_system_log('module_' . str_replace('.', '_', (string)$action), DMD_GENPW_ID . ':' . (string)$target, (string)$status, 'DMD-GenPW : ' . (string)$action, $safe); } catch (Throwable $e) {}
    }
    return $row;
}

function dmd_genpw_recent_logs($email, $limit) {
    $limit = max(1, min(500, (int)$limit));
    $files = glob(dmd_genpw_system_dir() . '/logs/*.jsonl');
    if (!is_array($files)) $files = array();
    rsort($files, SORT_STRING);
    $rows = array();
    foreach ($files as $file) {
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) continue;
        for ($i = count($lines)-1; $i >= 0; $i--) {
            $row = json_decode($lines[$i], true);
            if (!is_array($row) || (string)(isset($row['user']) ? $row['user'] : '') !== $email) continue;
            $rows[] = $row;
            if (count($rows) >= $limit) return $rows;
        }
    }
    return $rows;
}

function dmd_genpw_clear_logs($email) {
    $files = glob(dmd_genpw_system_dir() . '/logs/*.jsonl');
    if (!is_array($files)) return 0;
    $removed = 0;
    foreach ($files as $file) {
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) continue;
        $keep = array();
        foreach ($lines as $line) {
            $row = json_decode($line, true);
            if (is_array($row) && (string)(isset($row['user']) ? $row['user'] : '') === $email) { $removed++; continue; }
            $keep[] = $line;
        }
        if ($keep) dmd_genpw_atomic_write($file, implode("\n", $keep) . "\n", 0640); else @unlink($file);
    }
    return $removed;
}

function dmd_genpw_notify($recipient, $type, $title, $message, $meta = array()) {
    dmd_genpw_boot_core();
    if (!function_exists('dmd_notify_user')) return false;
    try {
        dmd_notify_user($recipient, $type, $title, $message, array(
            'level'=>'info',
            'action_url'=>'dashboard.php',
            'action_label'=>'DMD-GenPW',
            'meta'=>array_merge(array('scope'=>'module','module'=>DMD_GENPW_ID), is_array($meta) ? $meta : array())
        ));
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

function dmd_genpw_available_users($self) {
    $root = dmd_genpw_profiles_root();
    $out = array();
    $folders = @scandir($root);
    if (!is_array($folders)) return $out;
    foreach ($folders as $folder) {
        if ($folder === '.' || $folder === '..' || $folder === $self || filter_var($folder, FILTER_VALIDATE_EMAIL) === false || !is_dir($root . '/' . $folder)) continue;
        if (!dmd_genpw_user_has_permission($folder, 'module.view')) continue;
        $profile = dmd_genpw_profile($folder);
        $label = trim((string)(isset($profile['prenom']) ? $profile['prenom'] : '') . ' ' . (string)(isset($profile['nom']) ? $profile['nom'] : ''));
        $out[] = array('email'=>$folder,'name'=>$label !== '' ? $label : $folder);
    }
    usort($out, function($a,$b){ return strcasecmp($a['name'],$b['name']); });
    return $out;
}

function dmd_genpw_share_index_file() { return dmd_genpw_system_dir() . '/shares.json'; }
function dmd_genpw_share_index() { return dmd_genpw_read_json(dmd_genpw_share_index_file(), array()); }
function dmd_genpw_write_share_index($index) { dmd_genpw_write_json(dmd_genpw_share_index_file(), $index); }
