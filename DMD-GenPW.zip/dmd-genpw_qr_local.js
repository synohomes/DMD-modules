/*
 * DMD-GenPW local QR decoder.
 * Dependency-free decoder intended for clean screenshots/captures of MFA QR codes.
 * It never sends image data outside the browser.
 */
(function(global){
'use strict';

function clamp(v,a,b){return v<a?a:(v>b?b:v);}
function dist(a,b){const dx=a.x-b.x,dy=a.y-b.y;return Math.hypot(dx,dy);}
function popcnt(v){v=v>>>0;let c=0;while(v){v&=v-1;c++;}return c;}
function bitReverse15(v){let r=0;for(let i=0;i<15;i++)r=(r<<1)|((v>>i)&1);return r;}

function grayAndThreshold(imageData, bias){
    const w=imageData.width|0,h=imageData.height|0,src=imageData.data;
    const gray=new Uint8Array(w*h); const hist=new Uint32Array(256);
    let p=0;
    for(let i=0;i<src.length;i+=4){
        const y=clamp(Math.round(src[i]*0.299+src[i+1]*0.587+src[i+2]*0.114),0,255);
        gray[p++]=y;hist[y]++;
    }
    const total=w*h;let sum=0;for(let i=0;i<256;i++)sum+=i*hist[i];
    let sumB=0,wB=0,maxVar=-1,threshold=128;
    for(let t=0;t<256;t++){
        wB+=hist[t];if(!wB)continue;const wF=total-wB;if(!wF)break;
        sumB+=t*hist[t];const mB=sumB/wB,mF=(sum-sumB)/wF;
        const between=wB*wF*(mB-mF)*(mB-mF);
        if(between>maxVar){maxVar=between;threshold=t;}
    }
    threshold=clamp(threshold+(bias||0),16,239);
    const bin=new Uint8Array(total);
    for(let i=0;i<total;i++) bin[i]=gray[i]<threshold?1:0;
    return {w,h,bin,gray,threshold};
}

function ratioOk(runs){
    const total=runs[0]+runs[1]+runs[2]+runs[3]+runs[4];
    if(total<7)return false;const m=total/7, tol=m*0.85;
    return Math.abs(runs[0]-m)<tol && Math.abs(runs[1]-m)<tol && Math.abs(runs[2]-3*m)<3*tol && Math.abs(runs[3]-m)<tol && Math.abs(runs[4]-m)<tol;
}
function centerFromRuns(end,runs){return end-runs[4]-runs[3]-runs[2]/2;}

function crossCheckVertical(bin,w,h,cx,cy,estimatedModule,maxRun){
    const x=clamp(Math.round(cx),0,w-1), y=clamp(Math.round(cy),0,h-1);
    if(!bin[y*w+x]) return null;
    let r2u=0,yy=y;while(yy>=0&&bin[yy*w+x]&&r2u<=maxRun){r2u++;yy--;}
    let r1=0;while(yy>=0&&!bin[yy*w+x]&&r1<=maxRun){r1++;yy--;}
    let r0=0;while(yy>=0&&bin[yy*w+x]&&r0<=maxRun){r0++;yy--;}
    let r2d=0;yy=y+1;while(yy<h&&bin[yy*w+x]&&r2d<=maxRun){r2d++;yy++;}
    let r3=0;while(yy<h&&!bin[yy*w+x]&&r3<=maxRun){r3++;yy++;}
    let r4=0;while(yy<h&&bin[yy*w+x]&&r4<=maxRun){r4++;yy++;}
    const runs=[r0,r1,r2u+r2d,r3,r4];
    if(!ratioOk(runs))return null;
    const total=runs.reduce((a,b)=>a+b,0),m=total/7;
    if(estimatedModule>0 && (m<estimatedModule*0.45||m>estimatedModule*2.2))return null;
    const center=yy-r4-r3-runs[2]/2;
    return {y:center,module:m};
}

function findFinderCandidates(bin,w,h){
    const candidates=[];
    const add=(x,y,module)=>{
        if(!Number.isFinite(x)||!Number.isFinite(y)||module<0.7)return;
        for(const c of candidates){
            const d=Math.hypot(c.x-x,c.y-y);
            if(d<=Math.max(3,module*2.2) && module/c.module>0.45 && module/c.module<2.2){
                const n=c.count+1;c.x=(c.x*c.count+x)/n;c.y=(c.y*c.count+y)/n;c.module=(c.module*c.count+module)/n;c.count=n;return;
            }
        }
        candidates.push({x,y,module,count:1});
    };
    for(let y=0;y<h;y++){
        let runs=[0,0,0,0,0],state=0,cur=bin[y*w]?1:0;
        // We only evaluate dark-white-dark-white-dark sequences.
        let runStart=0;const seq=[];
        for(let x=0;x<=w;x++){
            const v=x<w?bin[y*w+x]:2;
            if(x===0){cur=v;runStart=0;continue;}
            if(v===cur)continue;
            seq.push({v:cur,len:x-runStart,end:x});
            cur=v;runStart=x;
            if(seq.length>=5){
                const s=seq.slice(-5);
                if(s[0].v===1&&s[1].v===0&&s[2].v===1&&s[3].v===0&&s[4].v===1){
                    runs=s.map(q=>q.len);
                    if(ratioOk(runs)){
                        const end=s[4].end, cx=centerFromRuns(end,runs), module=runs.reduce((a,b)=>a+b,0)/7;
                        const vv=crossCheckVertical(bin,w,h,cx,y,module,Math.ceil(module*6));
                        if(vv) add(cx,vv.y,(module+vv.module)/2);
                    }
                }
            }
            if(seq.length>9)seq.splice(0,4);
        }
    }
    return candidates.filter(c=>c.count>=1).sort((a,b)=>(b.count*2+b.module)-(a.count*2+a.module)).slice(0,40);
}

function chooseFinderTriple(candidates){
    let best=null;
    const n=Math.min(candidates.length,24);
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)for(let k=j+1;k<n;k++){
        const pts=[candidates[i],candidates[j],candidates[k]];
        const mods=pts.map(p=>p.module);const minM=Math.min(...mods),maxM=Math.max(...mods);if(maxM/minM>2.0)continue;
        for(let t=0;t<3;t++){
            const tl=pts[t],a=pts[(t+1)%3],b=pts[(t+2)%3];
            const v1={x:a.x-tl.x,y:a.y-tl.y},v2={x:b.x-tl.x,y:b.y-tl.y};
            const d1=Math.hypot(v1.x,v1.y),d2=Math.hypot(v2.x,v2.y);if(d1<tl.module*8||d2<tl.module*8)continue;
            const cos=Math.abs((v1.x*v2.x+v1.y*v2.y)/(d1*d2));if(cos>0.38)continue;
            const ratio=d1/d2;if(ratio<0.45||ratio>2.2)continue;
            let tr=a,bl=b;let cross=v1.x*v2.y-v1.y*v2.x;
            if(cross<0){tr=b;bl=a;cross=-cross;}
            const diag=dist(tr,bl), expected=Math.hypot(d1,d2);const diagErr=Math.abs(diag-expected)/expected;
            if(diagErr>0.35)continue;
            const countScore=tl.count+tr.count+bl.count;
            const score=countScore*10 - cos*35 - Math.abs(Math.log(ratio))*12 - diagErr*20;
            if(!best||score>best.score)best={tl,tr,bl,score};
        }
    }
    return best;
}

function nearestDimension(tl,tr,bl){
    const module=(tl.module+tr.module+bl.module)/3;
    const span=(dist(tl,tr)+dist(tl,bl))/2;
    let dim=Math.round(span/module)+7;
    dim=clamp(dim,21,177);
    let best=21,bestErr=1e9;
    for(let d=21;d<=177;d+=4){const e=Math.abs(d-dim);if(e<bestErr){bestErr=e;best=d;}}
    return best;
}

function sampleMatrix(bin,w,h,triple,dimension,offsetX,offsetY){
    const {tl,tr,bl}=triple;const span=dimension-7;
    const ax={x:(tr.x-tl.x)/span,y:(tr.y-tl.y)/span};
    const ay={x:(bl.x-tl.x)/span,y:(bl.y-tl.y)/span};
    const out=new Uint8Array(dimension*dimension);
    const ox=Number(offsetX||0),oy=Number(offsetY||0);
    for(let y=0;y<dimension;y++)for(let x=0;x<dimension;x++){
        const lx=(x+0.5-3.5)+ox,ly=(y+0.5-3.5)+oy;
        const px=tl.x+ax.x*lx+ay.x*ly,py=tl.y+ax.y*lx+ay.y*ly;
        const ix=Math.round(px),iy=Math.round(py);
        if(ix<0||iy<0||ix>=w||iy>=h)out[y*dimension+x]=0;
        else out[y*dimension+x]=bin[iy*w+ix]?1:0;
    }
    return out;
}

function get(m,n,x,y){return (x>=0&&y>=0&&x<n&&y<n)?m[y*n+x]:0;}
function formatBitsCopies(m,n){
    let a=0;
    const pushA=(x,y)=>{a=(a<<1)|get(m,n,x,y);};
    for(let i=0;i<=5;i++)pushA(i,8);pushA(7,8);pushA(8,8);pushA(8,7);for(let j=5;j>=0;j--)pushA(8,j);
    let b=0;const pushB=(x,y)=>{b=(b<<1)|get(m,n,x,y);};
    for(let j=n-1;j>=n-7;j--)pushB(8,j);for(let i=n-8;i<n;i++)pushB(i,8);
    return [a,b];
}
function bchFormat(data){
    let v=(data&31)<<10;const gen=0x537;
    function msb(x){let p=-1;while(x){x>>>=1;p++;}return p;}
    while(msb(v)>=10)v^=gen<<(msb(v)-10);
    return (((data&31)<<10)|v)^0x5412;
}
function decodeFormat(m,n){
    const copies=formatBitsCopies(m,n);let best=null;
    for(const observed0 of copies){
        for(const observed of [observed0,bitReverse15(observed0)]){
            for(let data=0;data<32;data++){
                const code=bchFormat(data),d=popcnt((code^observed)&0x7fff);
                if(!best||d<best.distance)best={data,distance:d,mask:data&7};
            }
        }
    }
    return best&&best.distance<=5?best:null;
}

function alignmentCenters(version){
    if(version===1)return [];
    const num=Math.floor(version/7)+2, dimension=17+4*version;
    let step;
    if(version===32)step=26;
    else step=Math.ceil((dimension-13)/(num-1));
    if(step&1)step++;
    const r=new Array(num);r[0]=6;let pos=dimension-7;
    for(let i=num-1;i>=1;i--){r[i]=pos;pos-=step;}
    return r;
}
function functionMask(n){
    const version=(n-17)/4;const f=new Uint8Array(n*n);const mark=(x,y,w,h)=>{for(let yy=Math.max(0,y);yy<Math.min(n,y+h);yy++)for(let xx=Math.max(0,x);xx<Math.min(n,x+w);xx++)f[yy*n+xx]=1;};
    mark(0,0,9,9);mark(n-8,0,8,9);mark(0,n-8,9,8);
    mark(6,0,1,n);mark(0,6,n,1);
    // Format information + dark module.
    mark(8,0,1,9);mark(0,8,9,1);mark(n-8,8,8,1);mark(8,n-7,1,7);f[(n-8)*n+8]=1;
    if(version>=7){mark(n-11,0,3,6);mark(0,n-11,6,3);}
    const centers=alignmentCenters(version);
    for(let yi=0;yi<centers.length;yi++)for(let xi=0;xi<centers.length;xi++){
        if((xi===0&&yi===0)||(xi===centers.length-1&&yi===0)||(xi===0&&yi===centers.length-1))continue;
        mark(centers[xi]-2,centers[yi]-2,5,5);
    }
    return f;
}
function maskCondition(id,r,c){
    const p=r*c;
    switch(id){
        case 0:return ((r+c)&1)===0;
        case 1:return (r&1)===0;
        case 2:return c%3===0;
        case 3:return (r+c)%3===0;
        case 4:return ((Math.floor(r/2)+Math.floor(c/3))&1)===0;
        case 5:return (p%2+p%3)===0;
        case 6:return ((p%2+p%3)&1)===0;
        case 7:return (((r+c)%2+p%3)&1)===0;
        default:return false;
    }
}
function readCodewords(m,n,maskId){
    const f=functionMask(n),bits=[];let up=true;
    for(let right=n-1;right>0;right-=2){
        if(right===6)right--;
        for(let count=0;count<n;count++){
            const y=up?n-1-count:count;
            for(let dx=0;dx<2;dx++){
                const x=right-dx;if(f[y*n+x])continue;
                let bit=m[y*n+x];if(maskCondition(maskId,y,x))bit^=1;bits.push(bit);
            }
        }
        up=!up;
    }
    const out=[];for(let i=0;i+7<bits.length;i+=8){let v=0;for(let j=0;j<8;j++)v=(v<<1)|bits[i+j];out.push(v);}return Uint8Array.from(out);
}

function deinterleave(raw,blocks,ecPerBlock){
    const total=raw.length,totalData=total-blocks*ecPerBlock;if(totalData<=0)return null;
    const shortLen=Math.floor(totalData/blocks),longCount=totalData%blocks;
    if(shortLen<=0)return null;
    // QR block groups are ordered with the shorter blocks first.
    const lens=[];for(let b=0;b<blocks;b++)lens.push(shortLen+(b>=blocks-longCount?1:0));
    const data=lens.map(n=>new Uint8Array(n));let p=0,max=Math.max(...lens);
    for(let i=0;i<max;i++)for(let b=0;b<blocks;b++)if(i<lens[b]){if(p>=raw.length)return null;data[b][i]=raw[p++];}
    // remaining p starts the interleaved ECC area; not needed for clean images.
    const joined=new Uint8Array(totalData);let o=0;for(const d of data){joined.set(d,o);o+=d.length;}return joined;
}

class BitReader{
    constructor(bytes){this.bytes=bytes;this.bit=0;}
    remaining(){return this.bytes.length*8-this.bit;}
    read(n){if(n<0||n>31||this.remaining()<n)throw new Error('bits');let v=0;for(let i=0;i<n;i++){const p=this.bit++;v=(v<<1)|((this.bytes[p>>3]>>(7-(p&7)))&1);}return v>>>0;}
}
const ALNUM='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:';
function charCountBits(mode,version){const g=version<=9?0:(version<=26?1:2);if(mode===1)return [10,12,14][g];if(mode===2)return [9,11,13][g];if(mode===4)return [8,16,16][g];if(mode===8)return [8,10,12][g];return 0;}
function decodePayload(bytes,version){
    const br=new BitReader(bytes);let text='',segments=0,eci=3;
    while(br.remaining()>=4&&segments<64){
        const mode=br.read(4);if(mode===0)break;
        if(mode===7){ // ECI
            if(br.remaining()<8)throw new Error('eci');let v=br.read(8);if((v&0x80)===0)eci=v;else if((v&0xC0)===0x80){v=((v&0x3f)<<8)|br.read(8);eci=v;}else if((v&0xE0)===0xC0){v=((v&0x1f)<<16)|br.read(16);eci=v;}else throw new Error('eci');segments++;continue;
        }
        if(mode===5||mode===9){segments++;continue;} // FNC1
        if(mode===3){if(br.remaining()<16)throw new Error('sa');br.read(16);segments++;continue;}
        const cb=charCountBits(mode,version);if(!cb||br.remaining()<cb)throw new Error('mode');const count=br.read(cb);
        if(mode===1){
            let left=count;while(left>=3){if(br.remaining()<10)throw new Error('num');text+=String(br.read(10)).padStart(3,'0');left-=3;}if(left===2){if(br.remaining()<7)throw new Error('num');text+=String(br.read(7)).padStart(2,'0');}else if(left===1){if(br.remaining()<4)throw new Error('num');text+=String(br.read(4));}
        }else if(mode===2){
            let left=count;while(left>=2){if(br.remaining()<11)throw new Error('alnum');const v=br.read(11);if(Math.floor(v/45)>=45||v%45>=45)throw new Error('alnum');text+=ALNUM[Math.floor(v/45)]+ALNUM[v%45];left-=2;}if(left){if(br.remaining()<6)throw new Error('alnum');const v=br.read(6);if(v>=45)throw new Error('alnum');text+=ALNUM[v];}
        }else if(mode===4){
            if(count<0||count>4096||br.remaining()<count*8)throw new Error('byte');const arr=new Uint8Array(count);for(let i=0;i<count;i++)arr[i]=br.read(8);
            try{text+=new TextDecoder(eci===26?'utf-8':'utf-8',{fatal:false}).decode(arr);}catch(_){for(const b of arr)text+=String.fromCharCode(b);}
        }else if(mode===8){
            // Kanji is not expected for MFA URIs; consume safely and keep placeholders.
            if(br.remaining()<count*13)throw new Error('kanji');for(let i=0;i<count;i++){br.read(13);text+='?';}
        }
        segments++;
    }
    if(!segments||!text)return null;
    let printable=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c===9||c===10||c===13||(c>=32&&c<127))printable++;}
    if(printable/Math.max(1,text.length)<0.985)return null;
    return text;
}

function payloadScore(s){
    if(!s)return -1e9;let score=Math.min(80,s.length/2);
    const l=s.toLowerCase();
    if(l.startsWith('otpauth://'))score+=1000;
    else if(l.startsWith('otpauth-migration://'))score+=1000;
    else if(l.includes('mobileappcommunicator.auth.microsoft.com/activate'))score+=1000;
    else if(/^https?:\/\//i.test(s))score+=300;
    else if(/^[A-Z2-7]{16,}=*$/i.test(s.trim()))score+=250;
    else return -1e9;
    return score;
}
function tryRawPayloads(raw,version){
    let best=null;
    // Single-block cases first, then brute-force legitimate-looking block/ECC layouts.
    const seen=new Set();
    const candidates=[];
    for(let blocks=1;blocks<=Math.min(81,raw.length);blocks++){
        for(let ec=2;ec<=40;ec++){
            const td=raw.length-blocks*ec;if(td<=0)break;
            if(td<4)continue;
            // QR RS block ECC length is normally >=7. Keep 2..6 only as a last-resort tolerant path.
            const priority=(ec>=7?0:1)+(blocks===1?-0.25:0);
            candidates.push({blocks,ec,priority});
        }
    }
    candidates.sort((a,b)=>a.priority-b.priority||a.blocks-b.blocks||a.ec-b.ec);
    for(const c of candidates){
        const key=c.blocks+':'+c.ec;if(seen.has(key))continue;seen.add(key);
        const bytes=deinterleave(raw,c.blocks,c.ec);if(!bytes)continue;
        let text=null;try{text=decodePayload(bytes,version);}catch(_){continue;}
        const score=payloadScore(text)-c.priority*10;
        if(!best||score>best.score)best={text,score,blocks:c.blocks,ec:c.ec};
        if(score>=900)return best;
    }
    return best&&best.score>100?best:null;
}

function decodeBinary(binary){
    const {bin,w,h}=binary,cands=findFinderCandidates(bin,w,h);if(cands.length<3)return null;
    const triple=chooseFinderTriple(cands);if(!triple)return null;
    const baseDim=nearestDimension(triple.tl,triple.tr,triple.bl);
    let best=null;
    const dims=[];for(const d of [baseDim,baseDim-4,baseDim+4,baseDim-8,baseDim+8])if(d>=21&&d<=177&&!dims.includes(d))dims.push(d);
    for(const n of dims){
        const version=(n-17)/4;if(version<1||version>40||version%1)continue;
        for(const off of [[0,0],[-0.18,0],[0.18,0],[0,-0.18],[0,0.18],[-0.12,-0.12],[0.12,0.12]]){
            const matrix=sampleMatrix(bin,w,h,triple,n,off[0],off[1]);const fmt=decodeFormat(matrix,n);if(!fmt)continue;
            for(const maskId of [fmt.mask,0,1,2,3,4,5,6,7]){
                if(maskId!==fmt.mask && fmt.distance<=2)continue;
                const raw=readCodewords(matrix,n,maskId);const parsed=tryRawPayloads(raw,version);if(!parsed)continue;
                let score=parsed.score-fmt.distance*5-(maskId===fmt.mask?0:25);
                if(!best||score>best.score)best={text:parsed.text,score,dimension:n,formatDistance:fmt.distance};
                if(score>=950)return best;
            }
        }
    }
    return best;
}

function decode(imageData){
    if(!imageData||!imageData.data||!imageData.width||!imageData.height)return '';
    let best=null;
    for(const bias of [0,-18,18,-36,36]){
        const b=grayAndThreshold(imageData,bias);const result=decodeBinary(b);if(result&&(!best||result.score>best.score))best=result;if(best&&best.score>=950)break;
        // Also try inverted polarity for unusual screenshots.
        const inv=b.bin.slice();for(let i=0;i<inv.length;i++)inv[i]^=1;
        const invResult=decodeBinary({bin:inv,w:b.w,h:b.h});if(invResult&&(!best||invResult.score>best.score))best=invResult;if(best&&best.score>=950)break;
    }
    return best?best.text:'';
}

global.DMDGenPWQR={decode};
})(typeof window!=='undefined'?window:globalThis);
