<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-genpw_lib.php';
$tr = dmd_genpw_strings();
if (!dmd_genpw_has_permission('config.view')) {
    echo '<section class="dmd-genpw-cfg"><div class="dmdgp-cfg-card">' . htmlspecialchars(dmd_genpw_text('Accès à la configuration DMD-GenPW refusé.','Access to DMD-GenPW settings denied.'), ENT_QUOTES, 'UTF-8') . '</div></section>';
    return;
}
$cfg = dmd_genpw_config(dmd_genpw_email());
$csrf = dmd_genpw_csrf();
$base = dmd_genpw_module_web_path();
$uid = 'dmdgpcfg-'.bin2hex(random_bytes(4));
function dmdgpcfg_h($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
?>
<link rel="stylesheet" href="<?=dmdgpcfg_h($base)?>/dmd-genpw.css?v=<?=is_file(__DIR__.'/dmd-genpw.css')?(int)filemtime(__DIR__.'/dmd-genpw.css'):121?>">
<script>
(()=>{
 const href=<?=json_encode($base.'/dmd-genpw.css?v='.(is_file(__DIR__.'/dmd-genpw.css')?(int)filemtime(__DIR__.'/dmd-genpw.css'):121),JSON_UNESCAPED_SLASHES)?>;
 const id='dmd-genpw-style'; let link=document.getElementById(id);
 if(!link){link=document.createElement('link');link.id=id;link.rel='stylesheet';document.head.appendChild(link)}
 if(link.getAttribute('href')!==href)link.setAttribute('href',href);
})();
</script>
<section id="<?=dmdgpcfg_h($uid)?>" class="dmd-genpw-cfg" data-api="<?=dmdgpcfg_h($base)?>/dmd-genpw_api.php" data-csrf="<?=dmdgpcfg_h($csrf)?>">
  <div class="dmdgp-cfg-card">
    <div class="dmdgp-cfg-head">
      <h2>⚙️ <?=dmdgpcfg_h($tr['config'])?> · DMD-GenPW</h2>
      <p class="dmdgp-muted"><?=dmdgpcfg_h($tr['config_user_note'])?> <?=dmdgpcfg_h($tr['system_language_note'])?></p>
    </div>

    <div class="dmdgp-cfg-lock">
      <h3>🔐 <?=dmdgpcfg_h($tr['vault_password'])?></h3>
      <p class="dmdgp-muted" data-lock-state><?=dmdgpcfg_h($cfg['vault_password_set'] ? $tr['vault_password_set'] : $tr['vault_password_not_set'])?></p>
      <div class="dmdgp-cfg-grid">
        <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['vault_password_new'])?></label><input class="dmdgp-input" type="password" maxlength="4096" autocomplete="new-password" data-cfg="vault_password"></div>
        <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['vault_password_confirm'])?></label><input class="dmdgp-input" type="password" maxlength="4096" autocomplete="new-password" data-cfg="vault_password_confirm"></div>
      </div>
      <?php if ($cfg['vault_password_set']): ?>
      <label class="dmdgp-check"><input type="checkbox" data-cfg="clear_vault_password"> <?=dmdgpcfg_h($tr['clear_vault_password'])?></label>
      <?php endif; ?>
    </div>

    <div class="dmdgp-cfg-lock">
      <h3>🛡️ MFA DoMyDesk</h3>
      <label class="dmdgp-check">
        <input type="checkbox" data-cfg="require_system_mfa"<?=!empty($cfg['require_system_mfa'])?' checked':''?><?=empty($cfg['system_mfa_enabled']) && empty($cfg['require_system_mfa'])?' disabled':''?>>
        <?=dmdgpcfg_h(dmd_genpw_text('Déverrouiller DMD-GenPW uniquement avec le code MFA DoMyDesk (sans redemander le mot de passe).','Unlock DMD-GenPW using only the DoMyDesk MFA code (without asking for the password again).'))?>
      </label>
      <p class="dmdgp-muted">
        <?php if (!empty($cfg['system_mfa_enabled'])): ?>
          ✅ <?=dmdgpcfg_h(dmd_genpw_text('Le MFA de votre compte DoMyDesk est actif. DMD-GenPW réutilisera exactement ce compte MFA et le code MFA suffira à déverrouiller le coffre : aucun second QR code, aucun secret MFA stocké dans le module.','Your DoMyDesk account MFA is active. DMD-GenPW will reuse that exact MFA account and the MFA code alone will unlock the vault: no second QR code and no MFA secret stored in the module.'))?>
        <?php else: ?>
          ⚠️ <?=dmdgpcfg_h(dmd_genpw_text('Le MFA de votre compte DoMyDesk n’est pas actif. Activez-le d’abord dans votre profil DoMyDesk.','Your DoMyDesk account MFA is not active. Enable it first in your DoMyDesk profile.'))?>
        <?php endif; ?>
      </p>
    </div>

    <div class="dmdgp-cfg-grid">
      <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['default_length'])?></label><input class="dmdgp-input" type="number" min="12" max="128" data-cfg="default_length" value="<?=((int)$cfg['default_length'])?>"></div>
      <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['auto_lock'])?></label><input class="dmdgp-input" type="number" min="1" max="60" data-cfg="auto_lock_minutes" value="<?=((int)$cfg['auto_lock_minutes'])?>"></div>
      <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['default_category'])?></label><select class="dmdgp-select" data-cfg="default_category"><?php foreach(dmd_genpw_categories() as $cat):?><option value="<?=dmdgpcfg_h($cat)?>"<?=$cat===$cfg['default_category']?' selected':''?>><?=dmdgpcfg_h($tr['cat_'.$cat] ?? $cat)?></option><?php endforeach;?></select></div>
      <div class="dmdgp-field"><span class="dmdgp-label"><?=dmdgpcfg_h($tr['default_specials'])?></span><label class="dmdgp-check"><input type="checkbox" data-cfg="default_specials"<?=$cfg['default_specials']?' checked':''?>> <?=dmdgpcfg_h($tr['specials'])?></label></div>
    </div>
    <div class="dmdgp-inline"><button type="button" class="dmdgp-btn is-primary" data-save>💾 <?=dmdgpcfg_h($tr['save_config'])?></button></div>
    <div class="dmdgp-status" data-msg></div>
  </div>
</section>
<script>
(()=>{
 const root=document.getElementById(<?=json_encode($uid)?>); if(!root)return;
 const API=root.dataset.api,CSRF=root.dataset.csrf,msg=root.querySelector('[data-msg]');
 root.querySelector('[data-save]').addEventListener('click',async()=>{
   const f=n=>root.querySelector(`[data-cfg="${n}"]`);
   const payload={action:'config_save',default_length:f('default_length').value,auto_lock_minutes:f('auto_lock_minutes').value,default_category:f('default_category').value,default_specials:f('default_specials').checked,require_system_mfa:!!(f('require_system_mfa')&&f('require_system_mfa').checked),vault_password:f('vault_password').value,vault_password_confirm:f('vault_password_confirm').value,clear_vault_password:!!(f('clear_vault_password')&&f('clear_vault_password').checked)};
   try{
     const r=await fetch(API,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},body:JSON.stringify(payload)}),d=await r.json();
     if(!r.ok||!d.ok) throw new Error(d.error||'Erreur');
     f('vault_password').value='';f('vault_password_confirm').value='';
     msg.textContent=<?=json_encode($tr['saved'],JSON_UNESCAPED_UNICODE)?>;msg.className='dmdgp-status is-success';
     const st=root.querySelector('[data-lock-state]');if(st)st.textContent=d.config&&d.config.vault_password_set?<?=json_encode($tr['vault_password_set'],JSON_UNESCAPED_UNICODE)?>:<?=json_encode($tr['vault_password_not_set'],JSON_UNESCAPED_UNICODE)?>;
   }catch(e){msg.textContent=e.message;msg.className='dmdgp-status is-error'}
 });
})();
</script>
