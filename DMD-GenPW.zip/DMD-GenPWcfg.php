<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-genpw_lib.php';
$tr = dmd_genpw_strings();
if (!dmd_genpw_has_permission('config.view')) {
    echo '<section class="dmd-genpw-cfg"><div class="dmdgp-cfg-card">' . htmlspecialchars(dmd_genpw_text('Accès à la configuration DMD-GenPW refusé.','Access to DMD-GenPW settings denied.'), ENT_QUOTES, 'UTF-8') . '</div></section>';
    return;
}
$cfg = dmd_genpw_config(dmd_genpw_email());
$csrf = dmd_genpw_csrf();
$base = dmd_genpw_module_web_path();
$uid = 'dmdgpcfg-'.bin2hex(random_bytes(4));
function dmdgpcfg_h($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
?>
<link rel="stylesheet" href="<?=dmdgpcfg_h($base)?>/dmd-genpw.css?v=<?=is_file(__DIR__.'/dmd-genpw.css')?(int)filemtime(__DIR__.'/dmd-genpw.css'):121?>">
<script>
(()=>{
 const href=<?=json_encode($base.'/dmd-genpw.css?v='.(is_file(__DIR__.'/dmd-genpw.css')?(int)filemtime(__DIR__.'/dmd-genpw.css'):121),JSON_UNESCAPED_SLASHES)?>;
 const id='dmd-genpw-style'; let link=document.getElementById(id);
 if(!link){link=document.createElement('link');link.id=id;link.rel='stylesheet';document.head.appendChild(link)}
 if(link.getAttribute('href')!==href)link.setAttribute('href',href);
})();
</script>
<section id="<?=dmdgpcfg_h($uid)?>" class="dmd-genpw-cfg" data-api="<?=dmdgpcfg_h($base)?>/dmd-genpw_api.php" data-csrf="<?=dmdgpcfg_h($csrf)?>">
  <div class="dmdgp-cfg-card">
    <div class="dmdgp-cfg-head">
      <h2>⚙️ <?=dmdgpcfg_h($tr['config'])?> · DMD-GenPW</h2>
      <p class="dmdgp-muted"><?=dmdgpcfg_h($tr['config_user_note'])?> <?=dmdgpcfg_h($tr['system_language_note'])?></p>
    </div>

    <div class="dmdgp-cfg-lock">
      <h3>🔐 <?=dmdgpcfg_h($tr['vault_password'])?></h3>
      <p class="dmdgp-muted" data-lock-state><?=dmdgpcfg_h($cfg['vault_password_set'] ? $tr['vault_password_set'] : $tr['vault_password_not_set'])?></p>
      <div class="dmdgp-cfg-grid">
        <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['vault_password_new'])?></label><input class="dmdgp-input" type="password" maxlength="4096" autocomplete="new-password" data-cfg="vault_password"></div>
        <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['vault_password_confirm'])?></label><input class="dmdgp-input" type="password" maxlength="4096" autocomplete="new-password" data-cfg="vault_password_confirm"></div>
      </div>
      <?php if ($cfg['vault_password_set']): ?>
      <label class="dmdgp-check"><input type="checkbox" data-cfg="clear_vault_password"> <?=dmdgpcfg_h($tr['clear_vault_password'])?></label>
      <?php endif; ?>
    </div>

    <div class="dmdgp-cfg-lock">
      <h3>🛡️ MFA DoMyDesk</h3>
      <label class="dmdgp-check">
        <input type="checkbox" data-cfg="require_system_mfa"<?=!empty($cfg['require_system_mfa'])?' checked':''?><?=empty($cfg['system_mfa_enabled']) && empty($cfg['require_system_mfa'])?' disabled':''?>>
        <?=dmdgpcfg_h(dmd_genpw_text('Déverrouiller DMD-GenPW uniquement avec le code MFA DoMyDesk (sans redemander le mot de passe).','Unlock DMD-GenPW using only the DoMyDesk MFA code (without asking for the password again).'))?>
      </label>
      <p class="dmdgp-muted">
        <?php if (!empty($cfg['system_mfa_enabled'])): ?>
          ✅ <?=dmdgpcfg_h(dmd_genpw_text('Le MFA de votre compte DoMyDesk est actif. DMD-GenPW réutilisera exactement ce compte MFA et le code MFA suffira à déverrouiller le coffre : aucun second QR code, aucun secret MFA stocké dans le module.','Your DoMyDesk account MFA is active. DMD-GenPW will reuse that exact MFA account and the MFA code alone will unlock the vault: no second QR code and no MFA secret stored in the module.'))?>
        <?php else: ?>
          ⚠️ <?=dmdgpcfg_h(dmd_genpw_text('Le MFA de votre compte DoMyDesk n’est pas actif. Activez-le d’abord dans votre profil DoMyDesk.','Your DoMyDesk account MFA is not active. Enable it first in your DoMyDesk profile.'))?>
        <?php endif; ?>
      </p>
    </div>

    <div class="dmdgp-cfg-grid">
      <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['default_length'])?></label><input class="dmdgp-input" type="number" min="12" max="128" data-cfg="default_length" value="<?=((int)$cfg['default_length'])?>"></div>
      <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['auto_lock'])?></label><input class="dmdgp-input" type="number" min="1" max="60" data-cfg="auto_lock_minutes" value="<?=((int)$cfg['auto_lock_minutes'])?>"></div>
      <div class="dmdgp-field"><label><?=dmdgpcfg_h($tr['default_category'])?></label><select class="dmdgp-select" data-cfg="default_category"><?php foreach(dmd_genpw_categories(dmd_genpw_email()) as $cat):?><option value="<?=dmdgpcfg_h($cat)?>"<?=$cat===$cfg['default_category']?' selected':''?>><?=dmdgpcfg_h($tr['cat_'.$cat] ?? $cat)?></option><?php endforeach;?></select></div>
      <div class="dmdgp-field"><span class="dmdgp-label"><?=dmdgpcfg_h($tr['default_specials'])?></span><label class="dmdgp-check"><input type="checkbox" data-cfg="default_specials"<?=$cfg['default_specials']?' checked':''?>> <?=dmdgpcfg_h($tr['specials'])?></label></div>
    </div>
    <div class="dmdgp-cfg-lock">
      <h3>🛡️ Centre de sécurité GenPW</h3>
      <p class="dmdgp-muted">Audit du coffre, doublons, corbeille, sauvegarde et réglages de sécurité.</p>
      <div class="dmdgp-inline">
        <button type="button" class="dmdgp-btn" data-security-center>🛡️ Ouvrir le centre de sécurité</button>
      </div>
    </div>

    <div class="dmdgp-inline"><button type="button" class="dmdgp-btn is-primary" data-save>💾 <?=dmdgpcfg_h($tr['save_config'])?></button></div>
    <div class="dmdgp-status" data-msg></div>
  </div>
</section>
<script>
(()=>{
 const root=document.getElementById(<?=json_encode($uid)?>); if(!root)return;
 const API=root.dataset.api,CSRF=root.dataset.csrf,msg=root.querySelector('[data-msg]');
 const api=async(action,payload={})=>{
   const r=await fetch(API,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},body:JSON.stringify(Object.assign({action},payload))});
   const d=await r.json().catch(()=>({}));
   if(!r.ok||!d.ok)throw new Error(d.error||('HTTP '+r.status));
   return d;
 };
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
 const openSecurityCenter=async()=>{
   const existing=document.getElementById(root.id+'-security-center'); if(existing)existing.remove();
   const overlay=document.createElement('div'); overlay.id=root.id+'-security-center'; overlay.className='genpw-modal'; overlay.style.display='grid';
   const dialog=document.createElement('div'); dialog.className='genpw-modal-dialog is-panel';
   dialog.innerHTML='<div class="genpw-modal-head"><h3 class="genpw-modal-title">🛡️ Centre de sécurité GenPW</h3><button type="button" class="genpw-btn" data-close>✕ Fermer</button></div><div class="genpw-modal-body"><div class="genpw-panel-stack" data-body><p class="genpw-empty">Chargement…</p></div></div>';
   overlay.appendChild(dialog); document.body.appendChild(overlay);
   dialog.querySelector('[data-close]').addEventListener('click',()=>overlay.remove());
   overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.remove()});
   const body=dialog.querySelector('[data-body]');
   try{
     const [overview,audit,dupes,trash,settings]=await Promise.all([api('pro_overview'),api('security_audit',{check_pwned:false}),api('duplicates'),api('trash_list'),api('pro_settings_get')]);
     const sm=overview.summary||{}, au=(audit.audit&&audit.audit.summary)||{}, cfg=settings.settings||{};
     body.innerHTML='';
     const stats=document.createElement('div'); stats.className='genpw-pro-dashboard';
     [['Entrées',sm.entries||0],['Favoris',sm.favorites||0],['Corbeille',sm.trash||0],['Faibles',au.weak||0],['Réutilisés',au.reused||0],['Anciens',au.old||0],['Sans MFA',au.without_mfa||0]].forEach(([l,v])=>{const c=document.createElement('div');c.className='genpw-pro-stat';c.innerHTML='<strong>'+esc(v)+'</strong><span>'+esc(l)+'</span>';stats.appendChild(c)}); body.appendChild(stats);
     const tools=document.createElement('div');tools.className='genpw-panel-actions';
     const mk=(txt,fn,cls='genpw-btn')=>{const b=document.createElement('button');b.type='button';b.className=cls;b.textContent=txt;b.addEventListener('click',fn);return b};
     tools.appendChild(mk('🛡️ Audit détaillé',()=>{const list=(audit.audit&&audit.audit.items||[]).filter(x=>x.issues&&x.issues.length);alert(list.length?list.map(x=>x.name+' · '+x.issues.join(' · ')).join('\\n'):'Aucun problème détecté.')}));
     tools.appendChild(mk('⧉ Doublons',()=>{const list=dupes.items||[];alert(list.length?list.map(x=>x.type+' · '+x.value+' · '+x.ids.length+' entrées').join('\\n'):'Aucun doublon.')}));
     body.appendChild(tools);
     const tt=document.createElement('strong');tt.textContent='Corbeille';body.appendChild(tt);
     const tl=document.createElement('div');tl.className='genpw-share-list'; const items=trash.items||[];
     if(!items.length){tl.innerHTML='<p class="genpw-empty">Corbeille vide.</p>'} else items.forEach(it=>{const row=document.createElement('div');row.className='genpw-share-line';const span=document.createElement('span');span.textContent=(it.name||'Entrée')+' · '+(it.deleted_at||'');const acts=document.createElement('div');acts.className='genpw-panel-actions';acts.appendChild(mk('↶ Restaurer',async()=>{await api('trash_restore',{id:it.id});row.remove()}));acts.appendChild(mk('🗑 Définitif',async()=>{if(confirm('Effacer définitivement ?')){await api('trash_purge',{ids:[it.id]});row.remove()}},'genpw-btn is-danger'));row.append(span,acts);tl.appendChild(row)}); body.appendChild(tl);
     const st=document.createElement('strong');st.textContent='Sécurité locale';body.appendChild(st);
     const grid=document.createElement('div');grid.className='genpw-form-grid';
     const field=(label,val,min,max)=>{const w=document.createElement('label');w.className='genpw-field';w.innerHTML='<span class="genpw-label">'+esc(label)+'</span><input class="genpw-input" type="number" min="'+min+'" max="'+max+'" value="'+esc(val)+'">';return w};
     const fr=field('Remasquer après (s)',cfg.reveal_seconds||20,5,300),fc=field('Effacer presse-papiers après (s)',cfg.clipboard_seconds||20,0,300),fl=field('Verrouillage après (min)',cfg.auto_lock_minutes||10,1,120);grid.append(fr,fc,fl);body.appendChild(grid);
     const save=mk('💾 Enregistrer les réglages',async()=>{const vals=grid.querySelectorAll('input');await api('pro_settings_save',{reveal_seconds:Number(vals[0].value),clipboard_seconds:Number(vals[1].value),auto_lock_minutes:Number(vals[2].value),hibp_enabled:!!cfg.hibp_enabled});msg.textContent='Réglages de sécurité enregistrés.';msg.className='dmdgp-status is-success'});body.appendChild(save);
   }catch(e){body.innerHTML='<p class="genpw-empty">'+esc(e.message)+'</p>'}
 };
 const securityBtn=root.querySelector('[data-security-center]'); if(securityBtn)securityBtn.addEventListener('click',openSecurityCenter);
 root.querySelector('[data-save]').addEventListener('click',async()=>{
   const f=n=>root.querySelector(`[data-cfg="${n}"]`);
   const payload={action:'config_save',default_length:f('default_length').value,auto_lock_minutes:f('auto_lock_minutes').value,default_category:f('default_category').value,default_specials:f('default_specials').checked,require_system_mfa:!!(f('require_system_mfa')&&f('require_system_mfa').checked),vault_password:f('vault_password').value,vault_password_confirm:f('vault_password_confirm').value,clear_vault_password:!!(f('clear_vault_password')&&f('clear_vault_password').checked)};
   try{
     const r=await fetch(API,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},body:JSON.stringify(payload)}),d=await r.json();
     if(!r.ok||!d.ok) throw new Error(d.error||'Erreur');
     f('vault_password').value='';f('vault_password_confirm').value='';
     msg.textContent=<?=json_encode($tr['saved'],JSON_UNESCAPED_UNICODE)?>;msg.className='dmdgp-status is-success';
     const st=root.querySelector('[data-lock-state]');if(st)st.textContent=d.config&&d.config.vault_password_set?<?=json_encode($tr['vault_password_set'],JSON_UNESCAPED_UNICODE)?>:<?=json_encode($tr['vault_password_not_set'],JSON_UNESCAPED_UNICODE)?>;
   }catch(e){msg.textContent=e.message;msg.className='dmdgp-status is-error'}
 });
})();
</script>
