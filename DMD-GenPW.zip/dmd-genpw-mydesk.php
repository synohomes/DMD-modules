<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/dmd-genpw_lib.php';

$email = dmd_genpw_email();
if (!is_string($email) || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    echo '<div class="dmdgp-mydesk dmdgp-mydesk-denied">⛔ Connexion requise.</div>';
    return;
}
if (!dmd_genpw_has_permission('module.view')) {
    echo '<div class="dmdgp-mydesk dmdgp-mydesk-denied">⛔ Accès DMD-GenPW refusé.</div>';
    return;
}

$cfg = dmd_genpw_config($email);
$rawCfg = dmd_genpw_config_raw($email);
$csrf = dmd_genpw_csrf();
$moduleBase = dmd_genpw_module_web_path();
$themeUrl = dmd_genpw_user_theme_url($email);
$cssVersion = is_file(__DIR__ . '/dmd-genpw-mydesk.css') ? (string)filemtime(__DIR__ . '/dmd-genpw-mydesk.css') : DMD_GENPW_VERSION;
$uid = 'dmdgp_mydesk_' . bin2hex(random_bytes(5));
$compactUrl = rtrim($moduleBase, '/') . '/dmd-genpw-mydesk.php?force_compact=1';
$fullUrl = rtrim($moduleBase, '/') . '/DMD-GenPW.php?dmdgp_mydesk_full=1';
$preferredMode = dmd_genpw_mydesk_mode($email);
$dedicatedVaultPassword = !empty($rawCfg['vault_password_hash']);

$permissions = array();
foreach (array('vault.unlock','vault.list','vault.reveal','vault.create') as $permission) {
    $permissions[$permission] = dmd_genpw_has_permission($permission);
}

if ($preferredMode === 'full' && empty($_GET['force_compact'])) {
    echo '<script>(function(){try{var w=Math.min(1050,(screen.availWidth||1050)-40),h=Math.min(760,(screen.availHeight||760)-60);window.resizeTo(Math.max(760,w),Math.max(560,h));}catch(e){}window.location.replace(' . json_encode($fullUrl, JSON_UNESCAPED_SLASHES) . ');})();</script>';
    return;
}
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleBase, ENT_QUOTES, 'UTF-8') ?>/dmd-genpw-mydesk.css?v=<?= htmlspecialchars($cssVersion, ENT_QUOTES, 'UTF-8') ?>">
<script>
(() => {
    const href = <?= json_encode($moduleBase . '/dmd-genpw-mydesk.css?v=' . $cssVersion, JSON_UNESCAPED_SLASHES) ?>;
    const id = 'dmd-genpw-mydesk-style';
    let link = document.getElementById(id);
    if (!link) {
        link = document.createElement('link');
        link.id = id;
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }
    if (link.getAttribute('href') !== href) link.setAttribute('href', href);

    function themeSource(){
        const candidates = [];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}
        for (const candidate of candidates) {
            try { if (candidate.document && candidate.location.origin === window.location.origin) return candidate; } catch (_) {}
        }
        return null;
    }
    function syncTheme(){
        const source = themeSource();
        if (!source) return;
        const names = [
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color','--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg','--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];
        const sourceRoots = [source.document.documentElement, source.document.body].filter(Boolean);
        const targets = [document.documentElement, document.body].filter(Boolean);
        for (const sourceRoot of sourceRoots) {
            const cs = source.getComputedStyle(sourceRoot);
            for (const name of names) {
                const value = cs.getPropertyValue(name);
                if (value && value.trim()) targets.forEach(target => target.style.setProperty(name, value.trim()));
            }
        }
        try {
            const bodyStyle = source.getComputedStyle(source.document.body);
            targets.forEach(target => { target.style.fontFamily = bodyStyle.fontFamily || ''; });
            if (!getComputedStyle(document.documentElement).getPropertyValue('--background-color').trim()) document.documentElement.style.setProperty('--background-color', bodyStyle.backgroundColor || '#0b0f17');
            if (!getComputedStyle(document.documentElement).getPropertyValue('--text-color').trim()) document.documentElement.style.setProperty('--text-color', bodyStyle.color || '#e6eefc');
        } catch (_) {}
        document.documentElement.classList.add('dmdgp-mydesk-frame');
        if (document.body) document.body.classList.add('dmdgp-mydesk-frame');
    }
    syncTheme();
    window.addEventListener('load', syncTheme, { once:true });
})();
</script>

<section
    class="dmdgp-mydesk"
    id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
    data-api="<?= htmlspecialchars($moduleBase, ENT_QUOTES, 'UTF-8') ?>/dmd-genpw_api.php"
    data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"
    data-full-url="<?= htmlspecialchars($fullUrl, ENT_QUOTES, 'UTF-8') ?>"
    data-compact-url="<?= htmlspecialchars($compactUrl, ENT_QUOTES, 'UTF-8') ?>"
    data-require-mfa="<?= !empty($cfg['require_system_mfa']) ? '1' : '0' ?>"
    data-auto-lock="<?= (int)$cfg['auto_lock_minutes'] ?>"
    data-can-unlock="<?= !empty($permissions['vault.unlock']) ? '1' : '0' ?>"
    data-can-list="<?= !empty($permissions['vault.list']) ? '1' : '0' ?>"
    data-can-reveal="<?= !empty($permissions['vault.reveal']) ? '1' : '0' ?>"
    data-can-create="<?= !empty($permissions['vault.create']) ? '1' : '0' ?>"
    data-dmd-module-id="DMD-GenPW"
    data-dmd-context-type="credential_vault"
    data-dmd-context-id="DMD-GenPW:vault"
    data-dmd-context-name="DMD-GenPW"
>
    <header class="dmdgp-md-head">
        <div class="dmdgp-md-title">
            <span class="dmdgp-md-icon" aria-hidden="true">🔐</span>
            <span class="dmdgp-md-title-text"><strong>DMD-GenPW</strong><small>Coffre rapide</small></span>
        </div>
        <div class="dmdgp-md-actions">
            <span class="dmdgp-md-state" data-role="state" title="État du coffre"><i></i><span>Verrouillé</span></span>
            <button type="button" class="dmdgp-md-iconbtn" data-action="refresh" title="Actualiser" aria-label="Actualiser" hidden>↻</button>
            <button type="button" class="dmdgp-md-iconbtn" data-action="lock" title="Verrouiller" aria-label="Verrouiller" hidden>🔒</button>
        </div>
    </header>

    <div class="dmdgp-md-message" data-role="message" hidden></div>

    <section class="dmdgp-md-unlock" data-role="locked">
        <div class="dmdgp-md-lockmark" aria-hidden="true">🔒</div>
        <div class="dmdgp-md-locktext">
            <strong>Coffre verrouillé</strong>
            <span><?= !empty($cfg['require_system_mfa']) ? 'Saisissez votre code MFA DoMyDesk.' : ($dedicatedVaultPassword ? 'Mot de passe du coffre DMD-GenPW.' : 'Mot de passe de votre compte DoMyDesk.') ?></span>
        </div>
        <?php if (!empty($cfg['require_system_mfa'])): ?>
            <input class="dmdgp-md-input" type="text" data-field="mfa" inputmode="numeric" pattern="[0-9]*" maxlength="8" autocomplete="one-time-code" placeholder="Code MFA">
        <?php else: ?>
            <input class="dmdgp-md-input" type="password" data-field="password" maxlength="4096" autocomplete="current-password" placeholder="<?= $dedicatedVaultPassword ? 'Mot de passe du coffre' : 'Mot de passe DoMyDesk' ?>">
        <?php endif; ?>
        <button type="button" class="dmdgp-md-btn dmdgp-md-primary" data-action="unlock"<?= empty($permissions['vault.unlock']) ? ' disabled' : '' ?>>🔓 Déverrouiller</button>
        <small class="dmdgp-md-hint">Reverrouillage automatique : <?= (int)$cfg['auto_lock_minutes'] ?> min.</small>
    </section>

    <section class="dmdgp-md-vault" data-role="vault" hidden>
        <div class="dmdgp-md-vault-actions">
            <button type="button" class="dmdgp-md-btn dmdgp-md-primary dmdgp-md-create-btn" data-action="create-entry">＋ Nouvelle entrée</button>
        </div>

        <section class="dmdgp-md-create" data-role="create-form" hidden>
            <div class="dmdgp-md-create-head">
                <strong>Nouvelle entrée</strong>
                <button type="button" class="dmdgp-md-iconbtn" data-action="create-cancel" title="Fermer" aria-label="Fermer">✕</button>
            </div>

            <div class="dmdgp-md-create-grid">
                <label>Nom
                    <input class="dmdgp-md-input" type="text" data-create="name" maxlength="120" autocomplete="off">
                </label>

                <label>Catégorie
                    <select class="dmdgp-md-input" data-create="cat"></select>
                </label>

                <label>Identifiant / e-mail
                    <input class="dmdgp-md-input" type="text" data-create="user" maxlength="255" autocomplete="off">
                </label>

                <label>URL
                    <input class="dmdgp-md-input" type="url" data-create="url" maxlength="2048" autocomplete="off" placeholder="https://...">
                </label>

                <label class="is-wide">Mot de passe
                    <div class="dmdgp-md-create-secret">
                        <input class="dmdgp-md-input" type="password" data-create="pw" maxlength="4096" autocomplete="new-password">
                        <button type="button" class="dmdgp-md-iconbtn" data-action="create-pw-toggle" title="Afficher / masquer">👁</button>
                    </div>
                </label>

                <label class="is-wide">Notes
                    <textarea class="dmdgp-md-input dmdgp-md-textarea" data-create="notes" maxlength="12000"></textarea>
                </label>
            </div>

            <div class="dmdgp-md-create-section">
                <div class="dmdgp-md-create-section-head">
                    <strong>Champs supplémentaires</strong>
                    <select class="dmdgp-md-input dmdgp-md-create-field-type" data-create="field-type">
                        <option value="">＋ Ajouter un champ</option>
                        <option value="user">Identifiant</option>
                        <option value="password">Mot de passe</option>
                        <option value="web">Lien Web</option>
                        <option value="note">Note</option>
                        <option value="text">Texte</option>
                        <option value="email">E-mail</option>
                        <option value="phone">Téléphone</option>
                        <option value="date">Date</option>
                        <option value="number">Numéro</option>
                        <option value="secret">Secret</option>
                        <option value="pin">PIN</option>
                        <option value="api_key">Clé API</option>
                        <option value="ssh_key">Clé SSH</option>
                        <option value="other">Autres</option>
                    </select>
                </div>
                <div class="dmdgp-md-extra-list" data-role="create-extra-list"></div>
            </div>

            <div class="dmdgp-md-create-section">
                <strong>Double authentification</strong>
                <div class="dmdgp-md-create-grid">
                    <label>Méthode
                        <select class="dmdgp-md-input" data-create="mfa-method">
                            <option value="none">Aucune</option>
                            <option value="totp">TOTP</option>
                            <option value="hotp">HOTP</option>
                            <option value="email">Code e-mail</option>
                            <option value="sms">Code SMS</option>
                            <option value="push">Validation Push</option>
                            <option value="webauthn">Passkey / clé de sécurité</option>
                            <option value="other">Autre méthode</option>
                        </select>
                    </label>
                    <label>Secret / URI otpauth
                        <input class="dmdgp-md-input" type="text" data-create="mfa-source" autocomplete="off">
                    </label>
                    <label>Émetteur
                        <input class="dmdgp-md-input" type="text" data-create="mfa-issuer" maxlength="255">
                    </label>
                    <label>Compte
                        <input class="dmdgp-md-input" type="text" data-create="mfa-account" maxlength="255">
                    </label>
                </div>
            </div>

            <div class="dmdgp-md-create-section">
                <strong>Fichier joint</strong>
                <input class="dmdgp-md-input" type="file" data-create="files" multiple>
            </div>

            <div class="dmdgp-md-create-actions">
                <button type="button" class="dmdgp-md-btn" data-action="create-cancel">Annuler</button>
                <button type="button" class="dmdgp-md-btn dmdgp-md-primary" data-action="create-save">Enregistrer</button>
            </div>
        </section>

        <div class="dmdgp-md-searchbar">
            <span aria-hidden="true">⌕</span>
            <input class="dmdgp-md-search" type="search" data-field="search" placeholder="Rechercher un accès…" autocomplete="off">
            <kbd data-role="count">0</kbd>
        </div>
        <div class="dmdgp-md-list" data-role="list"></div>
        <div class="dmdgp-md-empty" data-role="empty" hidden>
            <strong>Aucun accès</strong>
            <span>La recherche ne retourne aucun identifiant.</span>
        </div>
    </section>
</section>

<script>
(() => {
    'use strict';
    const root = document.getElementById(<?= json_encode($uid, JSON_UNESCAPED_SLASHES) ?>);
    if (!root || root.dataset.ready === '1') return;
    root.dataset.ready = '1';

    const apiUrl = root.dataset.api;
    const fullUrl = root.dataset.fullUrl;
    const csrf = root.dataset.csrf;
    const requireMfa = root.dataset.requireMfa === '1';
    const autoLockMinutes = Math.max(1, Number(root.dataset.autoLock || 10));
    const canUnlock = root.dataset.canUnlock === '1';
    const canList = root.dataset.canList === '1';
    const canReveal = root.dataset.canReveal === '1';
    const canCreate = root.dataset.canCreate === '1';

    const el = {
        state: root.querySelector('[data-role="state"]'),
        stateText: root.querySelector('[data-role="state"] span'),
        locked: root.querySelector('[data-role="locked"]'),
        vault: root.querySelector('[data-role="vault"]'),
        list: root.querySelector('[data-role="list"]'),
        empty: root.querySelector('[data-role="empty"]'),
        count: root.querySelector('[data-role="count"]'),
        message: root.querySelector('[data-role="message"]'),
        search: root.querySelector('[data-field="search"]'),
        password: root.querySelector('[data-field="password"]'),
        mfa: root.querySelector('[data-field="mfa"]'),
        unlock: root.querySelector('[data-action="unlock"]'),
        lock: root.querySelector('[data-action="lock"]'),
        refresh: root.querySelector('[data-action="refresh"]'),
        modeFull: null,
        createButton: root.querySelector('[data-action="create-entry"]'),
        createForm: root.querySelector('[data-role="create-form"]'),
        createSave: root.querySelector('[data-action="create-save"]'),
        createExtraList: root.querySelector('[data-role="create-extra-list"]'),
        createFieldType: root.querySelector('[data-create="field-type"]')
    };

    const state = { unlocked: false, items: [], timers: new Map(), autoLockTimer: null, messageTimer: null, createExtra: [] };

    function requestWindowSize(mode) {
        const compact = mode !== 'full';
        const width = compact ? 360 : Math.max(760, Math.min(1050, (screen.availWidth || 1050) - 40));
        const height = compact ? 520 : Math.max(560, Math.min(760, (screen.availHeight || 760) - 60));
        try { window.resizeTo(width, height); } catch (_) {}
        const detail = { type:'dmd:mydesk-resize', module:'DMD-GenPW', mode:compact?'compact':'full', width, height };
        try { if (window.opener && !window.opener.closed) window.opener.postMessage(detail, window.location.origin); } catch (_) {}
        try { if (window.parent && window.parent !== window) window.parent.postMessage(detail, window.location.origin); } catch (_) {}
        try { window.dispatchEvent(new CustomEvent('dmd:mydesk-resize', { detail })); } catch (_) {}
        return { width, height };
    }

    function announceResize() {
        try { root.dispatchEvent(new CustomEvent('dmd:module-content-resize', { bubbles: true, detail: { module: 'DMD-GenPW' } })); } catch (_) {}
    }

    function notify(message, error = false) {
        window.clearTimeout(state.messageTimer);
        el.message.textContent = String(message || '');
        el.message.classList.toggle('is-error', error);
        el.message.hidden = !message;
        if (message) state.messageTimer = window.setTimeout(() => { el.message.hidden = true; }, 3200);
        announceResize();
    }

    function scheduleLock(seconds) {
        window.clearTimeout(state.autoLockTimer);
        if (!state.unlocked) return;
        const delay = Math.max(1, Number(seconds || autoLockMinutes * 60)) * 1000;
        state.autoLockTimer = window.setTimeout(showLocked, delay);
    }

    async function api(action, payload = {}) {
        const response = await fetch(apiUrl, {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
            body: JSON.stringify({ action, ...payload })
        });
        let data = null;
        try { data = await response.json(); } catch (_) { throw new Error('Réponse serveur invalide (' + response.status + ').'); }
        if (!response.ok || !data || data.ok === false || data.error) {
            if (response.status === 423 || (data && data.locked)) showLocked();
            throw new Error((data && data.error) || 'Action impossible.');
        }
        if (state.unlocked && !['status','unlock','lock'].includes(action)) scheduleLock(autoLockMinutes * 60);
        return data;
    }

    function showLocked() {
        state.unlocked = false;
        state.items = [];
        window.clearTimeout(state.autoLockTimer);
        state.autoLockTimer = null;
        state.timers.forEach(timer => window.clearTimeout(timer));
        state.timers.clear();
        el.state.classList.remove('is-unlocked');
        el.stateText.textContent = 'Verrouillé';
        el.locked.hidden = false;
        el.vault.hidden = true;
        el.lock.hidden = true;
        el.refresh.hidden = true;
        if (el.createButton) el.createButton.hidden = true;
        if (el.createForm) el.createForm.hidden = true;
        el.list.replaceChildren();
        if (el.password) el.password.value = '';
        if (el.mfa) el.mfa.value = '';
        announceResize();
    }

    function showUnlocked(seconds) {
        state.unlocked = true;
        el.state.classList.add('is-unlocked');
        el.stateText.textContent = 'Ouvert';
        el.locked.hidden = true;
        el.vault.hidden = false;
        el.lock.hidden = !canUnlock;
        el.refresh.hidden = !canList;
        if (el.createButton) el.createButton.hidden = !canCreate;
        scheduleLock(seconds);
        announceResize();
    }

    function categoryIcon(cat) {
        const key = String(cat || '').toLowerCase();
        if (key.includes('wifi') || key.includes('wi-fi')) return '📶';
        if (key.includes('mail') || key.includes('email')) return '✉️';
        if (key.includes('banque') || key.includes('bank')) return '🏦';
        if (key.includes('serveur') || key.includes('server')) return '🖥️';
        if (key.includes('social')) return '👥';
        return '🔑';
    }

    function filteredItems() {
        const q = String(el.search.value || '').trim().toLocaleLowerCase('fr');
        if (!q) return state.items;
        return state.items.filter(item => [item.name,item.cat,item.user,item.url,item.owner].join(' ').toLocaleLowerCase('fr').includes(q));
    }

    function button(label, title, action, className = '') {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = `dmdgp-md-rowbtn ${className}`.trim();
        b.textContent = label;
        b.title = title;
        b.setAttribute('aria-label', title);
        b.addEventListener('click', action);
        return b;
    }

    async function copyText(value, source) {
        const text = String(value || '');
        if (!text) return;
        try {
            await navigator.clipboard.writeText(text);
        } catch (_) {
            const area = document.createElement('textarea');
            area.value = text;
            area.setAttribute('readonly', '');
            area.style.position = 'fixed'; area.style.opacity = '0';
            document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
        }
        if (source) {
            const old = source.textContent;
            source.textContent = '✓';
            window.setTimeout(() => { if (source.isConnected) source.textContent = old; }, 800);
        }
    }

    async function getSecret(item) {
        const result = await api('get_secret', { id: item.id, kind: item.kind === 'shared' ? 'shared' : 'owned' });
        return String(result.secret || '');
    }

    async function getEntryDetails(item) {
        const result = await api('entry_get', {
            id: item.id,
            kind: item.kind === 'shared' ? 'shared' : 'owned'
        });
        return {
            entry: result && result.entry ? result.entry : {},
            fields: Array.isArray(result && result.extra_fields) ? result.extra_fields : []
        };
    }

    function closeChoiceMenu() {
        document.querySelectorAll('.dmdgp-md-choice-menu').forEach(node => node.remove());
    }

    function openChoiceMenu(anchor, choices) {
        closeChoiceMenu();
        if (!Array.isArray(choices) || !choices.length) return;

        const menu = document.createElement('div');
        menu.className = 'dmdgp-md-choice-menu';

        choices.forEach((choice, index) => {
            const row = document.createElement('button');
            row.type = 'button';
            row.className = 'dmdgp-md-choice-row';

            const label = document.createElement('span');
            label.className = 'dmdgp-md-choice-label';
            label.textContent = choice.hidden
                ? String(choice.label || ('Mot de passe ' + (index + 1)))
                : String(index + 1) + ' =';

            const value = document.createElement('span');
            value.className = 'dmdgp-md-choice-value';
            value.textContent = choice.hidden ? '••••••••' : String(choice.value || '');

            row.append(label, value);
            row.addEventListener('click', async () => {
                await copyText(String(choice.value || ''), anchor);
                closeChoiceMenu();
            });
            menu.appendChild(row);
        });

        document.body.appendChild(menu);

        const ar = anchor.getBoundingClientRect();
        const mr = menu.getBoundingClientRect();
        let left = ar.right - mr.width;
        let top = ar.bottom + 4;

        if (left < 6) left = 6;
        if (left + mr.width > window.innerWidth - 6) left = Math.max(6, window.innerWidth - mr.width - 6);
        if (top + mr.height > window.innerHeight - 6) top = Math.max(6, ar.top - mr.height - 4);

        menu.style.left = Math.round(left) + 'px';
        menu.style.top = Math.round(top) + 'px';

        setTimeout(() => {
            const outside = event => {
                if (!menu.contains(event.target) && event.target !== anchor) {
                    menu.remove();
                    document.removeEventListener('pointerdown', outside, true);
                }
            };
            document.addEventListener('pointerdown', outside, true);
        }, 0);
    }

    async function copyIdentifiers(item, source) {
        source.disabled = true;
        try {
            const details = await getEntryDetails(item);
            const choices = [];

            if (item.user) {
                choices.push({ label: 'Identifiant', value: String(item.user), hidden: false });
            }

            details.fields
                .filter(field => field && field.type === 'user' && String(field.value || '') !== '')
                .forEach(field => {
                    choices.push({
                        label: String(field.label || 'Identifiant'),
                        value: String(field.value || ''),
                        hidden: false
                    });
                });

            if (!choices.length) throw new Error('Aucun identifiant enregistré.');

            if (choices.length === 1) {
                await copyText(choices[0].value, source);
            } else {
                openChoiceMenu(source, choices);
            }
        } catch (error) {
            notify(error.message, true);
        } finally {
            source.disabled = false;
        }
    }

    async function copyPasswords(item, source) {
        source.disabled = true;
        try {
            const details = await getEntryDetails(item);
            const choices = [];

            const primary = await getSecret(item);
            if (primary) {
                choices.push({ label: 'Mot de passe', value: primary, hidden: true });
            }

            details.fields
                .filter(field => field && field.type === 'password' && String(field.value || '') !== '')
                .forEach(field => {
                    choices.push({
                        label: String(field.label || 'Mot de passe'),
                        value: String(field.value || ''),
                        hidden: true
                    });
                });

            if (!choices.length) throw new Error('Aucun mot de passe enregistré.');

            if (choices.length === 1) {
                await copyText(choices[0].value, source);
            } else {
                openChoiceMenu(source, choices);
            }
        } catch (error) {
            notify(error.message, true);
        } finally {
            source.disabled = false;
        }
    }

    async function copyMfaCode(item, source) {
        source.disabled = true;
        try {
            const result = await api('mfa_code', {
                id: item.id,
                kind: item.kind === 'shared' ? 'shared' : 'owned',
                advance: String(item.mfa_method || '') === 'hotp'
            });
            const code = String(result.code || '');
            if (!code) throw new Error('Aucun code MFA disponible.');
            await copyText(code, source);
        } catch (error) {
            notify(error.message, true);
        } finally {
            source.disabled = false;
        }
    }

    function hideSecret(item, secret, revealButton) {
        const timer = state.timers.get(item.id);
        if (timer) window.clearTimeout(timer);
        state.timers.delete(item.id);
        secret.textContent = '••••••••••••';
        secret.dataset.visible = '0';
        if (revealButton) { revealButton.textContent = '👁'; revealButton.title = 'Afficher le mot de passe'; }
    }

    async function toggleSecret(item, secret, revealButton) {
        if (secret.dataset.visible === '1') {
            hideSecret(item, secret, revealButton);
            return;
        }
        revealButton.disabled = true;
        try {
            secret.textContent = await getSecret(item);
            secret.dataset.visible = '1';
            revealButton.textContent = '🙈';
            revealButton.title = 'Masquer le mot de passe';
            const timer = window.setTimeout(() => hideSecret(item, secret, revealButton), 15000);
            state.timers.set(item.id, timer);
        } catch (error) {
            notify(error.message, true);
        } finally {
            revealButton.disabled = false;
        }
    }

    async function copySecret(item, source) {
        source.disabled = true;
        try { await copyText(await getSecret(item), source); }
        catch (error) { notify(error.message, true); }
        finally { source.disabled = false; }
    }

    function normaliseSiteUrl(raw) {
        const value = String(raw || '').trim();
        if (!value) throw new Error('URL vide.');
        const candidate = /^[a-z][a-z0-9+.-]*:\/\//i.test(value) ? value : ('https://' + value);
        const url = new URL(candidate);
        if (!/^https?:$/i.test(url.protocol)) throw new Error('Seuls HTTP et HTTPS sont autorisés.');
        return url;
    }

    function openWebsiteInMyDesk(rawUrl, title = '') {
        const url = normaliseSiteUrl(rawUrl);
        const opened = window.open(url.href, '_blank', 'noopener,noreferrer');
        if (!opened) throw new Error('Impossible d’ouvrir le site dans une nouvelle fenêtre.');
    }


    function closeRowMenu() {
        document.querySelectorAll('.dmdgp-md-row-menu').forEach(node => node.remove());
    }

    async function openEntryViewer(item) {
        closeChoiceMenu();
        closeRowMenu();

        const previous = document.querySelector('.dmdgp-md-viewer');
        if (previous) previous.remove();

        const overlay = document.createElement('div');
        overlay.className = 'dmdgp-md-viewer';

        const panel = document.createElement('section');
        panel.className = 'dmdgp-md-viewer-panel';

        const head = document.createElement('header');
        head.className = 'dmdgp-md-viewer-head';

        const title = document.createElement('strong');
        title.textContent = item.name || 'Entrée';

        const close = document.createElement('button');
        close.type = 'button';
        close.className = 'dmdgp-md-viewer-close';
        close.textContent = '✕';
        close.title = 'Fermer';
        close.addEventListener('click', () => overlay.remove());

        head.append(title, close);

        const body = document.createElement('div');
        body.className = 'dmdgp-md-viewer-body';
        body.innerHTML = '<div class="dmdgp-md-viewer-loading">Chargement…</div>';

        panel.append(head, body);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);

        overlay.addEventListener('pointerdown', event => {
            if (event.target === overlay) overlay.remove();
        });

        const addRow = (labelText, valueText, options = {}) => {
            const value = String(valueText ?? '');
            if (!value && !options.keepEmpty) return;

            const row = document.createElement('div');
            row.className = 'dmdgp-md-viewer-row';

            const label = document.createElement('span');
            label.className = 'dmdgp-md-viewer-label';
            label.textContent = labelText;

            const valueWrap = document.createElement('div');
            valueWrap.className = 'dmdgp-md-viewer-value';

            const valueEl = document.createElement(options.multiline ? 'div' : 'span');
            valueEl.className = 'dmdgp-md-viewer-text';
            valueEl.textContent = options.secret ? '••••••••' : value;
            if (options.multiline) valueEl.classList.add('is-multiline');
            valueWrap.appendChild(valueEl);

            const actions = document.createElement('div');
            actions.className = 'dmdgp-md-viewer-actions';

            if (options.secret) {
                let visible = false;
                const reveal = document.createElement('button');
                reveal.type = 'button';
                reveal.className = 'dmdgp-md-viewer-btn';
                reveal.textContent = '👁';
                reveal.title = 'Afficher / masquer';
                reveal.addEventListener('click', () => {
                    visible = !visible;
                    valueEl.textContent = visible ? value : '••••••••';
                });
                actions.appendChild(reveal);
            }

            const copy = document.createElement('button');
            copy.type = 'button';
            copy.className = 'dmdgp-md-viewer-btn';
            copy.textContent = '📋';
            copy.title = 'Copier';
            copy.addEventListener('click', () => copyText(value, copy));
            actions.appendChild(copy);

            if (options.web) {
                const web = document.createElement('button');
                web.type = 'button';
                web.className = 'dmdgp-md-viewer-btn';
                web.textContent = '🌐';
                web.title = 'Ouvrir';
                web.addEventListener('click', () => {
                    try { openWebsiteInMyDesk(value, item.name || 'Site web'); }
                    catch (error) { notify(error.message, true); }
                });
                actions.appendChild(web);
            }

            row.append(label, valueWrap, actions);
            body.appendChild(row);
        };

        try {
            const details = await getEntryDetails(item);
            const entry = details.entry || {};
            const fields = details.fields || [];

            body.replaceChildren();

            addRow('Nom', entry.name || item.name || '');
            addRow('Catégorie', entry.cat || item.cat || '');
            addRow('Identifiant / e-mail', entry.user || item.user || '');
            addRow('Adresse / URL', entry.url || item.url || '', { web: true });
            addRow('Notes', entry.notes || '', { multiline: true });

            if (!item.mfa_only) {
                const password = await getSecret(item);
                addRow('Mot de passe', password, { secret: true });
            }

            fields.forEach(field => {
                if (!field || !String(field.value || '')) return;
                const type = String(field.type || '').toLowerCase();
                const label = String(field.label || 'Champ');
                const secret = ['password','secret','pin','api_key','ssh_key'].includes(type);
                const web = type === 'web';
                const multiline = type === 'note' || type === 'textarea';
                addRow(label, String(field.value || ''), { secret, web, multiline });
            });

            if (item.mfa_code_ready) {
                const mfaRow = document.createElement('div');
                mfaRow.className = 'dmdgp-md-viewer-row';

                const mfaLabel = document.createElement('span');
                mfaLabel.className = 'dmdgp-md-viewer-label';
                mfaLabel.textContent = 'MFA';

                const mfaValue = document.createElement('div');
                mfaValue.className = 'dmdgp-md-viewer-value';
                mfaValue.textContent = 'Configurée';

                const mfaActions = document.createElement('div');
                mfaActions.className = 'dmdgp-md-viewer-actions';

                const copyMfa = document.createElement('button');
                copyMfa.type = 'button';
                copyMfa.className = 'dmdgp-md-viewer-btn';
                copyMfa.textContent = '📋';
                copyMfa.title = 'Copier le code MFA';
                copyMfa.addEventListener('click', () => copyMfaCode(item, copyMfa));

                mfaActions.appendChild(copyMfa);
                mfaRow.append(mfaLabel, mfaValue, mfaActions);
                body.appendChild(mfaRow);
            }
        } catch (error) {
            body.replaceChildren();
            const err = document.createElement('div');
            err.className = 'dmdgp-md-viewer-error';
            err.textContent = error.message || 'Impossible de charger la fiche.';
            body.appendChild(err);
        }
    }

    function openRowMenu(item, anchor) {
        closeChoiceMenu();
        closeRowMenu();

        const menu = document.createElement('div');
        menu.className = 'dmdgp-md-row-menu';

        const addAction = (label, handler) => {
            const b = document.createElement('button');
            b.type = 'button';
            b.className = 'dmdgp-md-row-menu-item';
            b.textContent = label;
            b.addEventListener('click', async () => {
                try { await handler(); }
                finally { closeRowMenu(); }
            });
            menu.appendChild(b);
        };

        addAction('👁 Consulter', async () => {
            await openEntryViewer(item);
        });

        if (item.url) {
            addAction('🌐 Ouvrir le site', async () => {
                openWebsiteInMyDesk(item.url, item.name || 'Site web');
            });
        }

        addAction('📋 Copier ID', async () => {
            await copyIdentifiers(item, anchor);
        });

        if (!item.mfa_only) {
            addAction('🔑 Copier PW', async () => {
                await copyPasswords(item, anchor);
            });
        }

        if (item.mfa_code_ready) {
            addAction('🔐 Copier MFA', async () => {
                await copyMfaCode(item, anchor);
            });
        }

        document.body.appendChild(menu);

        const ar = anchor.getBoundingClientRect();
        const mr = menu.getBoundingClientRect();
        let left = ar.right - mr.width;
        let top = ar.bottom + 4;

        if (left < 6) left = 6;
        if (left + mr.width > window.innerWidth - 6) left = Math.max(6, window.innerWidth - mr.width - 6);
        if (top + mr.height > window.innerHeight - 6) top = Math.max(6, ar.top - mr.height - 4);

        menu.style.left = Math.round(left) + 'px';
        menu.style.top = Math.round(top) + 'px';

        setTimeout(() => {
            const outside = event => {
                if (!menu.contains(event.target) && event.target !== anchor) {
                    menu.remove();
                    document.removeEventListener('pointerdown', outside, true);
                }
            };
            document.addEventListener('pointerdown', outside, true);
        }, 0);
    }

    function createField(name) {
        return root.querySelector(`[data-create="${name}"]`);
    }

    function resetCreateForm() {
        ['name','user','url','pw','notes','mfa-source','mfa-issuer','mfa-account'].forEach(name => {
            const node = createField(name);
            if (node) node.value = '';
        });
        const method = createField('mfa-method');
        if (method) method.value = 'none';
        const files = createField('files');
        if (files) files.value = '';
        state.createExtra = [];
        renderCreateExtra();
    }

    function closeCreateForm() {
        if (!el.createForm) return;
        el.createForm.hidden = true;
        el.search.closest('.dmdgp-md-searchbar').hidden = false;
        el.list.hidden = false;
        el.empty.hidden = filteredItems().length !== 0;
        if (el.createButton) el.createButton.hidden = !canCreate;
        resetCreateForm();
        announceResize();
    }

    async function openCreateForm() {
        if (!canCreate || !el.createForm) return;
        resetCreateForm();

        try {
            const result = await api('categories');
            const select = createField('cat');
            if (select) {
                select.replaceChildren();
                const cats = Array.isArray(result.categories) && result.categories.length ? result.categories : ['Autre'];
                cats.forEach(cat => {
                    const opt = document.createElement('option');
                    opt.value = String(cat);
                    opt.textContent = String(cat);
                    select.appendChild(opt);
                });
            }
        } catch (_) {
            const select = createField('cat');
            if (select && !select.options.length) {
                const opt = document.createElement('option');
                opt.value = 'Autre';
                opt.textContent = 'Autre';
                select.appendChild(opt);
            }
        }

        el.createForm.hidden = false;
        el.search.closest('.dmdgp-md-searchbar').hidden = true;
        el.list.hidden = true;
        el.empty.hidden = true;
        if (el.createButton) el.createButton.hidden = true;
        const name = createField('name');
        if (name) name.focus();
        announceResize();
    }

    function renderCreateExtra() {
        if (!el.createExtraList) return;
        el.createExtraList.replaceChildren();

        state.createExtra.forEach((field, index) => {
            const row = document.createElement('div');
            row.className = 'dmdgp-md-extra-row';

            const label = document.createElement('input');
            label.className = 'dmdgp-md-input';
            label.type = 'text';
            label.maxLength = 120;
            label.placeholder = 'Libellé';
            label.value = field.label || '';
            label.addEventListener('input', () => { field.label = label.value; });

            const value = field.type === 'note' ? document.createElement('textarea') : document.createElement('input');
            value.className = 'dmdgp-md-input';
            if (value.tagName === 'INPUT') {
                value.type = ['password','secret','pin','api_key','ssh_key'].includes(field.type) ? 'password'
                    : field.type === 'date' ? 'date'
                    : field.type === 'number' ? 'number'
                    : field.type === 'email' ? 'email'
                    : field.type === 'web' ? 'url'
                    : 'text';
            }
            value.placeholder = 'Valeur';
            value.value = field.value || '';
            value.addEventListener('input', () => { field.value = value.value; });

            const del = document.createElement('button');
            del.type = 'button';
            del.className = 'dmdgp-md-iconbtn';
            del.textContent = '✕';
            del.title = 'Supprimer le champ';
            del.addEventListener('click', () => {
                state.createExtra.splice(index, 1);
                renderCreateExtra();
            });

            row.append(label, value, del);
            el.createExtraList.appendChild(row);
        });
    }

    function addCreateExtra(type) {
        if (!type) return;
        const labels = {
            user:'Identifiant', password:'Mot de passe', web:'Lien Web', note:'Note',
            text:'Texte', email:'E-mail', phone:'Téléphone', date:'Date', number:'Numéro',
            secret:'Secret', pin:'PIN', api_key:'Clé API', ssh_key:'Clé SSH', other:'Autres'
        };
        state.createExtra.push({
            id: 'f_' + Math.random().toString(16).slice(2, 14),
            type,
            label: labels[type] || 'Autres',
            value: ''
        });
        renderCreateExtra();
    }

    async function uploadCreateFiles(entryId) {
        const input = createField('files');
        if (!input || !input.files || !input.files.length) return;

        for (const file of Array.from(input.files)) {
            const form = new FormData();
            form.append('action', 'attachment_add');
            form.append('id', entryId);
            form.append('file', file, file.name);

            const response = await fetch(apiUrl, {
                method: 'POST',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { 'X-CSRF-Token': csrf },
                body: form
            });

            let result = null;
            try { result = await response.json(); } catch (_) {}
            if (!response.ok || !result || result.ok === false) {
                throw new Error((result && result.error) || `Impossible d’ajouter ${file.name}.`);
            }
        }
    }

    async function saveCreateEntry() {
        if (!canCreate || !el.createSave) return;

        const name = String(createField('name')?.value || '').trim();
        const pw = String(createField('pw')?.value || '');
        if (!name) {
            notify('Le nom de la fiche est requis.', true);
            createField('name')?.focus();
            return;
        }
        if (!pw) {
            notify('Le mot de passe est requis.', true);
            createField('pw')?.focus();
            return;
        }

        el.createSave.disabled = true;
        try {
            const result = await api('add', {
                name,
                cat: String(createField('cat')?.value || 'Autre'),
                user: String(createField('user')?.value || ''),
                url: String(createField('url')?.value || ''),
                notes: String(createField('notes')?.value || ''),
                pw,
                extra_fields: state.createExtra.map(field => ({
                    id: field.id,
                    type: field.type,
                    label: String(field.label || ''),
                    value: String(field.value || '')
                }))
            });

            const entryId = String(result.id || '');
            if (!entryId) throw new Error('Entrée créée mais identifiant serveur manquant.');

            const method = String(createField('mfa-method')?.value || 'none');
            const source = String(createField('mfa-source')?.value || '').trim();

            if (method !== 'none') {
                await api('mfa_save', {
                    id: entryId,
                    mfa: {
                        method,
                        source,
                        encoding: 'auto',
                        algorithm: 'SHA1',
                        digits: 6,
                        period: 30,
                        counter: 0,
                        issuer: String(createField('mfa-issuer')?.value || ''),
                        account: String(createField('mfa-account')?.value || ''),
                        recovery_codes: '',
                        notes: ''
                    }
                });
            }

            await uploadCreateFiles(entryId);
            await loadList();
            closeCreateForm();
            notify('Entrée créée.');
        } catch (error) {
            notify(error.message || 'Création impossible.', true);
        } finally {
            el.createSave.disabled = false;
        }
    }

    function render() {
        const items = filteredItems();
        el.list.replaceChildren();
        el.count.textContent = String(items.length);
        el.empty.hidden = items.length !== 0;

        items.forEach(item => {
            const row = document.createElement('article');
            row.className = 'dmdgp-md-row';

            const icon = document.createElement('span');
            icon.className = 'dmdgp-md-rowicon';
            icon.textContent = categoryIcon(item.cat);

            const main = document.createElement('div');
            main.className = 'dmdgp-md-rowmain';
            const top = document.createElement('div'); top.className = 'dmdgp-md-rowtop';
            const name = document.createElement('strong'); name.textContent = item.name || 'Sans nom';
            const cat = document.createElement('span'); cat.className = 'dmdgp-md-cat'; cat.textContent = item.cat || 'Autre';
            top.append(name, cat);
            if (item.kind === 'shared') {
                const shared = document.createElement('span'); shared.className = 'dmdgp-md-shared'; shared.textContent = '↗'; shared.title = `Partagé par ${item.owner || 'un utilisateur'}`; top.appendChild(shared);
            }
            const meta = document.createElement('span'); meta.className = 'dmdgp-md-meta'; meta.textContent = item.user || item.url || 'Identifiant enregistré';
            const secret = document.createElement('code'); secret.className = 'dmdgp-md-secret'; secret.dataset.visible = '0'; secret.textContent = '••••••••••••';
            main.append(top, meta);
            if (!item.mfa_only) main.appendChild(secret);

            const actions = document.createElement('div'); actions.className = 'dmdgp-md-rowactions';

            if (canReveal && !item.mfa_only) {
                const reveal = button('👁', 'Afficher le mot de passe principal', event => toggleSecret(item, secret, event.currentTarget));
                actions.appendChild(reveal);
            }

            actions.appendChild(button('ID', 'Copier un identifiant', event => copyIdentifiers(item, event.currentTarget)));
            if (!item.mfa_only) actions.appendChild(button('PW', 'Copier un mot de passe', event => copyPasswords(item, event.currentTarget)));

            if (item.mfa_code_ready) {
                actions.appendChild(button('MFA', 'Copier le code MFA', event => copyMfaCode(item, event.currentTarget)));
            }

            if (item.url) {
                actions.appendChild(button('🌐', 'Ouvrir le site', () => {
                    try { openWebsiteInMyDesk(item.url, item.name || 'Site web'); }
                    catch (error) { notify(error.message, true); }
                }));
            }

            actions.appendChild(button('⋯', 'Plus d’actions', event => openRowMenu(item, event.currentTarget)));

            row.append(icon, main, actions);
            el.list.appendChild(row);
        });
        announceResize();
    }

    async function loadList() {
        if (!canList) {
            state.items = [];
            render();
            notify('Vous n’avez pas le droit de consulter le coffre.', true);
            return;
        }
        el.refresh.disabled = true;
        try {
            const result = await api('list');
            state.items = Array.isArray(result.items) ? result.items : [];
            render();
        } catch (error) {
            notify(error.message, true);
        } finally {
            el.refresh.disabled = false;
        }
    }

    async function unlock() {
        if (!canUnlock) return;
        el.unlock.disabled = true;
        try {
            const payload = requireMfa ? { mfa_code: String(el.mfa ? el.mfa.value : '') } : { pwd: String(el.password ? el.password.value : '') };
            const result = await api('unlock', payload);
            showUnlocked(result.expires_in);
            await loadList();
            if (el.search) el.search.focus();
        } catch (error) {
            notify(error.message, true);
        } finally {
            el.unlock.disabled = false;
        }
    }

    if (el.createButton) el.createButton.addEventListener('click', openCreateForm);
    root.querySelectorAll('[data-action="create-cancel"]').forEach(button => button.addEventListener('click', closeCreateForm));
    if (el.createSave) el.createSave.addEventListener('click', saveCreateEntry);
    if (el.createFieldType) el.createFieldType.addEventListener('change', event => {
        addCreateExtra(String(event.currentTarget.value || ''));
        event.currentTarget.value = '';
    });
    const pwToggle = root.querySelector('[data-action="create-pw-toggle"]');
    if (pwToggle) pwToggle.addEventListener('click', () => {
        const input = createField('pw');
        if (!input) return;
        input.type = input.type === 'password' ? 'text' : 'password';
        pwToggle.textContent = input.type === 'password' ? '👁' : '🙈';
    });

    el.unlock.addEventListener('click', unlock);
    if (el.password) el.password.addEventListener('keydown', event => { if (event.key === 'Enter') unlock(); });
    if (el.mfa) el.mfa.addEventListener('keydown', event => { if (event.key === 'Enter') unlock(); });
    el.search.addEventListener('input', render);
    el.refresh.addEventListener('click', loadList);
    el.lock.addEventListener('click', async () => {
        el.lock.disabled = true;
        try { await api('lock'); } catch (_) {}
        finally { el.lock.disabled = false; showLocked(); }
    });

    requestWindowSize('compact');
    api('status').then(result => {
        if (result.unlocked) {
            showUnlocked(result.expires_in);
            loadList();
        } else {
            showLocked();
        }
    }).catch(() => showLocked());
})();
</script>
