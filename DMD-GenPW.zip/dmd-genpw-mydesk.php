<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/dmd-genpw_lib.php';

$email = dmd_genpw_email();
if (!is_string($email) || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
    echo '<div class="dmdgp-mydesk dmdgp-mydesk-denied">⛔ Connexion requise.</div>';
    return;
}
if (!dmd_genpw_has_permission('module.view')) {
    echo '<div class="dmdgp-mydesk dmdgp-mydesk-denied">⛔ Accès DMD-GenPW refusé.</div>';
    return;
}

$cfg = dmd_genpw_config($email);
$rawCfg = dmd_genpw_config_raw($email);
$csrf = dmd_genpw_csrf();
$moduleBase = dmd_genpw_module_web_path();
$themeUrl = dmd_genpw_user_theme_url($email);
$cssVersion = is_file(__DIR__ . '/dmd-genpw-mydesk.css') ? (string)filemtime(__DIR__ . '/dmd-genpw-mydesk.css') : DMD_GENPW_VERSION;
$uid = 'dmdgp_mydesk_' . bin2hex(random_bytes(5));
$compactUrl = rtrim($moduleBase, '/') . '/dmd-genpw-mydesk.php?force_compact=1';
$fullUrl = rtrim($moduleBase, '/') . '/DMD-GenPW.php?dmdgp_mydesk_full=1';
$preferredMode = dmd_genpw_mydesk_mode($email);
$dedicatedVaultPassword = !empty($rawCfg['vault_password_hash']);

$permissions = array();
foreach (array('vault.unlock','vault.list','vault.reveal') as $permission) {
    $permissions[$permission] = dmd_genpw_has_permission($permission);
}

if ($preferredMode === 'full' && empty($_GET['force_compact'])) {
    echo '<script>(function(){try{var w=Math.min(1050,(screen.availWidth||1050)-40),h=Math.min(760,(screen.availHeight||760)-60);window.resizeTo(Math.max(760,w),Math.max(560,h));}catch(e){}window.location.replace(' . json_encode($fullUrl, JSON_UNESCAPED_SLASHES) . ');})();</script>';
    return;
}
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleBase, ENT_QUOTES, 'UTF-8') ?>/dmd-genpw-mydesk.css?v=<?= htmlspecialchars($cssVersion, ENT_QUOTES, 'UTF-8') ?>">
<script>
(() => {
    const href = <?= json_encode($moduleBase . '/dmd-genpw-mydesk.css?v=' . $cssVersion, JSON_UNESCAPED_SLASHES) ?>;
    const id = 'dmd-genpw-mydesk-style';
    let link = document.getElementById(id);
    if (!link) {
        link = document.createElement('link');
        link.id = id;
        link.rel = 'stylesheet';
        document.head.appendChild(link);
    }
    if (link.getAttribute('href') !== href) link.setAttribute('href', href);

    function themeSource(){
        const candidates = [];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}
        for (const candidate of candidates) {
            try { if (candidate.document && candidate.location.origin === window.location.origin) return candidate; } catch (_) {}
        }
        return null;
    }
    function syncTheme(){
        const source = themeSource();
        if (!source) return;
        const names = [
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color','--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg','--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];
        const sourceRoots = [source.document.documentElement, source.document.body].filter(Boolean);
        const targets = [document.documentElement, document.body].filter(Boolean);
        for (const sourceRoot of sourceRoots) {
            const cs = source.getComputedStyle(sourceRoot);
            for (const name of names) {
                const value = cs.getPropertyValue(name);
                if (value && value.trim()) targets.forEach(target => target.style.setProperty(name, value.trim()));
            }
        }
        try {
            const bodyStyle = source.getComputedStyle(source.document.body);
            targets.forEach(target => { target.style.fontFamily = bodyStyle.fontFamily || ''; });
            if (!getComputedStyle(document.documentElement).getPropertyValue('--background-color').trim()) document.documentElement.style.setProperty('--background-color', bodyStyle.backgroundColor || '#0b0f17');
            if (!getComputedStyle(document.documentElement).getPropertyValue('--text-color').trim()) document.documentElement.style.setProperty('--text-color', bodyStyle.color || '#e6eefc');
        } catch (_) {}
        document.documentElement.classList.add('dmdgp-mydesk-frame');
        if (document.body) document.body.classList.add('dmdgp-mydesk-frame');
    }
    syncTheme();
    window.addEventListener('load', syncTheme, { once:true });
})();
</script>

<section
    class="dmdgp-mydesk"
    id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>"
    data-api="<?= htmlspecialchars($moduleBase, ENT_QUOTES, 'UTF-8') ?>/dmd-genpw_api.php"
    data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>"
    data-full-url="<?= htmlspecialchars($fullUrl, ENT_QUOTES, 'UTF-8') ?>"
    data-compact-url="<?= htmlspecialchars($compactUrl, ENT_QUOTES, 'UTF-8') ?>"
    data-require-mfa="<?= !empty($cfg['require_system_mfa']) ? '1' : '0' ?>"
    data-auto-lock="<?= (int)$cfg['auto_lock_minutes'] ?>"
    data-can-unlock="<?= !empty($permissions['vault.unlock']) ? '1' : '0' ?>"
    data-can-list="<?= !empty($permissions['vault.list']) ? '1' : '0' ?>"
    data-can-reveal="<?= !empty($permissions['vault.reveal']) ? '1' : '0' ?>"
    data-dmd-module-id="DMD-GenPW"
    data-dmd-context-type="credential_vault"
    data-dmd-context-id="DMD-GenPW:vault"
    data-dmd-context-name="DMD-GenPW"
>
    <header class="dmdgp-md-head">
        <div class="dmdgp-md-title">
            <span class="dmdgp-md-icon" aria-hidden="true">🔐</span>
            <span class="dmdgp-md-title-text"><strong>DMD-GenPW</strong><small>Coffre rapide</small></span>
        </div>
        <div class="dmdgp-md-actions">
            <span class="dmdgp-md-state" data-role="state" title="État du coffre"><i></i><span>Verrouillé</span></span>
            <button type="button" class="dmdgp-md-iconbtn" data-action="refresh" title="Actualiser" aria-label="Actualiser" hidden>↻</button>
            <button type="button" class="dmdgp-md-iconbtn" data-action="lock" title="Verrouiller" aria-label="Verrouiller" hidden>🔒</button>
            <button type="button" class="dmdgp-md-iconbtn" data-action="mode-full" title="Mode complet" aria-label="Mode complet">⛶</button>
        </div>
    </header>

    <div class="dmdgp-md-message" data-role="message" hidden></div>

    <section class="dmdgp-md-unlock" data-role="locked">
        <div class="dmdgp-md-lockmark" aria-hidden="true">🔒</div>
        <div class="dmdgp-md-locktext">
            <strong>Coffre verrouillé</strong>
            <span><?= !empty($cfg['require_system_mfa']) ? 'Saisissez votre code MFA DoMyDesk.' : ($dedicatedVaultPassword ? 'Mot de passe du coffre DMD-GenPW.' : 'Mot de passe de votre compte DoMyDesk.') ?></span>
        </div>
        <?php if (!empty($cfg['require_system_mfa'])): ?>
            <input class="dmdgp-md-input" type="text" data-field="mfa" inputmode="numeric" pattern="[0-9]*" maxlength="8" autocomplete="one-time-code" placeholder="Code MFA">
        <?php else: ?>
            <input class="dmdgp-md-input" type="password" data-field="password" maxlength="4096" autocomplete="current-password" placeholder="<?= $dedicatedVaultPassword ? 'Mot de passe du coffre' : 'Mot de passe DoMyDesk' ?>">
        <?php endif; ?>
        <button type="button" class="dmdgp-md-btn dmdgp-md-primary" data-action="unlock"<?= empty($permissions['vault.unlock']) ? ' disabled' : '' ?>>🔓 Déverrouiller</button>
        <small class="dmdgp-md-hint">Reverrouillage automatique : <?= (int)$cfg['auto_lock_minutes'] ?> min.</small>
    </section>

    <section class="dmdgp-md-vault" data-role="vault" hidden>
        <div class="dmdgp-md-searchbar">
            <span aria-hidden="true">⌕</span>
            <input class="dmdgp-md-search" type="search" data-field="search" placeholder="Rechercher un accès…" autocomplete="off">
            <kbd data-role="count">0</kbd>
        </div>
        <div class="dmdgp-md-list" data-role="list"></div>
        <div class="dmdgp-md-empty" data-role="empty" hidden>
            <strong>Aucun accès</strong>
            <span>La recherche ne retourne aucun identifiant.</span>
        </div>
    </section>
</section>

<script>
(() => {
    'use strict';
    const root = document.getElementById(<?= json_encode($uid, JSON_UNESCAPED_SLASHES) ?>);
    if (!root || root.dataset.ready === '1') return;
    root.dataset.ready = '1';

    const apiUrl = root.dataset.api;
    const fullUrl = root.dataset.fullUrl;
    const csrf = root.dataset.csrf;
    const requireMfa = root.dataset.requireMfa === '1';
    const autoLockMinutes = Math.max(1, Number(root.dataset.autoLock || 10));
    const canUnlock = root.dataset.canUnlock === '1';
    const canList = root.dataset.canList === '1';
    const canReveal = root.dataset.canReveal === '1';

    const el = {
        state: root.querySelector('[data-role="state"]'),
        stateText: root.querySelector('[data-role="state"] span'),
        locked: root.querySelector('[data-role="locked"]'),
        vault: root.querySelector('[data-role="vault"]'),
        list: root.querySelector('[data-role="list"]'),
        empty: root.querySelector('[data-role="empty"]'),
        count: root.querySelector('[data-role="count"]'),
        message: root.querySelector('[data-role="message"]'),
        search: root.querySelector('[data-field="search"]'),
        password: root.querySelector('[data-field="password"]'),
        mfa: root.querySelector('[data-field="mfa"]'),
        unlock: root.querySelector('[data-action="unlock"]'),
        lock: root.querySelector('[data-action="lock"]'),
        refresh: root.querySelector('[data-action="refresh"]'),
        modeFull: root.querySelector('[data-action="mode-full"]')
    };

    const state = { unlocked: false, items: [], timers: new Map(), autoLockTimer: null, messageTimer: null };

    function requestWindowSize(mode) {
        const compact = mode !== 'full';
        const width = compact ? 360 : Math.max(760, Math.min(1050, (screen.availWidth || 1050) - 40));
        const height = compact ? 520 : Math.max(560, Math.min(760, (screen.availHeight || 760) - 60));
        try { window.resizeTo(width, height); } catch (_) {}
        const detail = { type:'dmd:mydesk-resize', module:'DMD-GenPW', mode:compact?'compact':'full', width, height };
        try { if (window.opener && !window.opener.closed) window.opener.postMessage(detail, window.location.origin); } catch (_) {}
        try { if (window.parent && window.parent !== window) window.parent.postMessage(detail, window.location.origin); } catch (_) {}
        try { window.dispatchEvent(new CustomEvent('dmd:mydesk-resize', { detail })); } catch (_) {}
        return { width, height };
    }

    function announceResize() {
        try { root.dispatchEvent(new CustomEvent('dmd:module-content-resize', { bubbles: true, detail: { module: 'DMD-GenPW' } })); } catch (_) {}
    }

    function notify(message, error = false) {
        window.clearTimeout(state.messageTimer);
        el.message.textContent = String(message || '');
        el.message.classList.toggle('is-error', error);
        el.message.hidden = !message;
        if (message) state.messageTimer = window.setTimeout(() => { el.message.hidden = true; }, 3200);
        announceResize();
    }

    function scheduleLock(seconds) {
        window.clearTimeout(state.autoLockTimer);
        if (!state.unlocked) return;
        const delay = Math.max(1, Number(seconds || autoLockMinutes * 60)) * 1000;
        state.autoLockTimer = window.setTimeout(showLocked, delay);
    }

    async function api(action, payload = {}) {
        const response = await fetch(apiUrl, {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf },
            body: JSON.stringify({ action, ...payload })
        });
        let data = null;
        try { data = await response.json(); } catch (_) { throw new Error('Réponse serveur invalide (' + response.status + ').'); }
        if (!response.ok || !data || data.ok === false || data.error) {
            if (response.status === 423 || (data && data.locked)) showLocked();
            throw new Error((data && data.error) || 'Action impossible.');
        }
        if (state.unlocked && !['status','unlock','lock'].includes(action)) scheduleLock(autoLockMinutes * 60);
        return data;
    }

    function showLocked() {
        state.unlocked = false;
        state.items = [];
        window.clearTimeout(state.autoLockTimer);
        state.autoLockTimer = null;
        state.timers.forEach(timer => window.clearTimeout(timer));
        state.timers.clear();
        el.state.classList.remove('is-unlocked');
        el.stateText.textContent = 'Verrouillé';
        el.locked.hidden = false;
        el.vault.hidden = true;
        el.lock.hidden = true;
        el.refresh.hidden = true;
        el.list.replaceChildren();
        if (el.password) el.password.value = '';
        if (el.mfa) el.mfa.value = '';
        announceResize();
    }

    function showUnlocked(seconds) {
        state.unlocked = true;
        el.state.classList.add('is-unlocked');
        el.stateText.textContent = 'Ouvert';
        el.locked.hidden = true;
        el.vault.hidden = false;
        el.lock.hidden = !canUnlock;
        el.refresh.hidden = !canList;
        scheduleLock(seconds);
        announceResize();
    }

    function categoryIcon(cat) {
        const key = String(cat || '').toLowerCase();
        if (key.includes('wifi') || key.includes('wi-fi')) return '📶';
        if (key.includes('mail') || key.includes('email')) return '✉️';
        if (key.includes('banque') || key.includes('bank')) return '🏦';
        if (key.includes('serveur') || key.includes('server')) return '🖥️';
        if (key.includes('réseau') || key.includes('network')) return '🌐';
        if (key.includes('social')) return '👥';
        return '🔑';
    }

    function filteredItems() {
        const q = String(el.search.value || '').trim().toLocaleLowerCase('fr');
        if (!q) return state.items;
        return state.items.filter(item => [item.name,item.cat,item.user,item.url,item.owner].join(' ').toLocaleLowerCase('fr').includes(q));
    }

    function button(label, title, action, className = '') {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = `dmdgp-md-rowbtn ${className}`.trim();
        b.textContent = label;
        b.title = title;
        b.setAttribute('aria-label', title);
        b.addEventListener('click', action);
        return b;
    }

    async function copyText(value, source) {
        const text = String(value || '');
        if (!text) return;
        try {
            await navigator.clipboard.writeText(text);
        } catch (_) {
            const area = document.createElement('textarea');
            area.value = text;
            area.setAttribute('readonly', '');
            area.style.position = 'fixed'; area.style.opacity = '0';
            document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
        }
        if (source) {
            const old = source.textContent;
            source.textContent = '✓';
            window.setTimeout(() => { if (source.isConnected) source.textContent = old; }, 800);
        }
    }

    async function getSecret(item) {
        const result = await api('get_secret', { id: item.id, kind: item.kind === 'shared' ? 'shared' : 'owned' });
        return String(result.secret || '');
    }

    function hideSecret(item, secret, revealButton) {
        const timer = state.timers.get(item.id);
        if (timer) window.clearTimeout(timer);
        state.timers.delete(item.id);
        secret.textContent = '••••••••••••';
        secret.dataset.visible = '0';
        if (revealButton) { revealButton.textContent = '👁'; revealButton.title = 'Afficher le mot de passe'; }
    }

    async function toggleSecret(item, secret, revealButton) {
        if (secret.dataset.visible === '1') {
            hideSecret(item, secret, revealButton);
            return;
        }
        revealButton.disabled = true;
        try {
            secret.textContent = await getSecret(item);
            secret.dataset.visible = '1';
            revealButton.textContent = '🙈';
            revealButton.title = 'Masquer le mot de passe';
            const timer = window.setTimeout(() => hideSecret(item, secret, revealButton), 15000);
            state.timers.set(item.id, timer);
        } catch (error) {
            notify(error.message, true);
        } finally {
            revealButton.disabled = false;
        }
    }

    async function copySecret(item, source) {
        source.disabled = true;
        try { await copyText(await getSecret(item), source); }
        catch (error) { notify(error.message, true); }
        finally { source.disabled = false; }
    }

    function render() {
        const items = filteredItems();
        el.list.replaceChildren();
        el.count.textContent = String(items.length);
        el.empty.hidden = items.length !== 0;

        items.forEach(item => {
            const row = document.createElement('article');
            row.className = 'dmdgp-md-row';

            const icon = document.createElement('span');
            icon.className = 'dmdgp-md-rowicon';
            icon.textContent = categoryIcon(item.cat);

            const main = document.createElement('div');
            main.className = 'dmdgp-md-rowmain';
            const top = document.createElement('div'); top.className = 'dmdgp-md-rowtop';
            const name = document.createElement('strong'); name.textContent = item.name || 'Sans nom';
            const cat = document.createElement('span'); cat.className = 'dmdgp-md-cat'; cat.textContent = item.cat || 'Autre';
            top.append(name, cat);
            if (item.kind === 'shared') {
                const shared = document.createElement('span'); shared.className = 'dmdgp-md-shared'; shared.textContent = '↗'; shared.title = `Partagé par ${item.owner || 'un utilisateur'}`; top.appendChild(shared);
            }
            const meta = document.createElement('span'); meta.className = 'dmdgp-md-meta'; meta.textContent = item.user || item.url || 'Identifiant enregistré';
            const secret = document.createElement('code'); secret.className = 'dmdgp-md-secret'; secret.dataset.visible = '0'; secret.textContent = '••••••••••••';
            main.append(top, meta, secret);

            const actions = document.createElement('div'); actions.className = 'dmdgp-md-rowactions';
            if (item.user) actions.appendChild(button('ID', 'Copier l’identifiant', event => copyText(item.user, event.currentTarget)));
            if (canReveal) {
                const reveal = button('👁', 'Afficher le mot de passe', event => toggleSecret(item, secret, event.currentTarget));
                actions.appendChild(reveal);
                actions.appendChild(button('📋', 'Copier le mot de passe', event => copySecret(item, event.currentTarget)));
            }
            if (item.url) actions.appendChild(button('🌐', 'Ouvrir le site', () => {
                try { window.open(item.url, '_blank', 'noopener,noreferrer'); } catch (_) { window.location.href = item.url; }
            }));

            row.append(icon, main, actions);
            el.list.appendChild(row);
        });
        announceResize();
    }

    async function loadList() {
        if (!canList) {
            state.items = [];
            render();
            notify('Vous n’avez pas le droit de consulter le coffre.', true);
            return;
        }
        el.refresh.disabled = true;
        try {
            const result = await api('list');
            state.items = Array.isArray(result.items) ? result.items : [];
            render();
        } catch (error) {
            notify(error.message, true);
        } finally {
            el.refresh.disabled = false;
        }
    }

    async function unlock() {
        if (!canUnlock) return;
        el.unlock.disabled = true;
        try {
            const payload = requireMfa ? { mfa_code: String(el.mfa ? el.mfa.value : '') } : { pwd: String(el.password ? el.password.value : '') };
            const result = await api('unlock', payload);
            showUnlocked(result.expires_in);
            await loadList();
            if (el.search) el.search.focus();
        } catch (error) {
            notify(error.message, true);
        } finally {
            el.unlock.disabled = false;
        }
    }

    el.unlock.addEventListener('click', unlock);
    if (el.password) el.password.addEventListener('keydown', event => { if (event.key === 'Enter') unlock(); });
    if (el.mfa) el.mfa.addEventListener('keydown', event => { if (event.key === 'Enter') unlock(); });
    el.search.addEventListener('input', render);
    el.refresh.addEventListener('click', loadList);
    el.lock.addEventListener('click', async () => {
        el.lock.disabled = true;
        try { await api('lock'); } catch (_) {}
        finally { el.lock.disabled = false; showLocked(); }
    });
    if (el.modeFull) el.modeFull.addEventListener('click', async () => {
        el.modeFull.disabled = true;
        try { await api('mydesk_mode_save', { mode:'full' }); } catch (_) {}
        requestWindowSize('full');
        window.location.assign(fullUrl);
    });

    requestWindowSize('compact');
    api('status').then(result => {
        if (result.unlocked) {
            showUnlocked(result.expires_in);
            loadList();
        } else {
            showLocked();
        }
    }).catch(() => showLocked());
})();
</script>
