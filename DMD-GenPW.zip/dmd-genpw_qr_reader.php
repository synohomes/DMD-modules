<?php
/*
 * DMD-GenPW - chargeur same-origin du lecteur QR jsQR 1.4.0.
 * Le contenu des QR n'est jamais envoyé à l'extérieur : seul le code de la
 * bibliothèque de décodage est téléchargé puis mis en cache côté serveur.
 */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-genpw_lib.php';
header('Content-Type: application/javascript; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=86400');

$email=dmd_genpw_email();
if (!is_string($email) || filter_var($email,FILTER_VALIDATE_EMAIL)===false || !dmd_genpw_has_permission('module.view')) {
    http_response_code(403);
    echo "console.error('DMD-GenPW: accès lecteur QR refusé.');\n";
    exit;
}

$version='1.4.0';
$cache=rtrim(sys_get_temp_dir(),DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR.'dmd-genpw-jsqr-'.$version.'.js';

function dmdgp_qr_valid_library($data) {
    if (!is_string($data)) return false;
    $len=strlen($data);
    if ($len<100000 || $len>500000) return false;
    return strpos($data,'jsQR')!==false && (strpos($data,'webpackUniversalModuleDefinition')!==false || strpos($data,'root["jsQR"]')!==false || strpos($data,"root['jsQR']")!==false);
}

function dmdgp_qr_fetch($url) {
    if (function_exists('curl_init')) {
        $ch=curl_init($url);
        curl_setopt_array($ch,array(
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_FOLLOWLOCATION=>true,
            CURLOPT_CONNECTTIMEOUT=>5,
            CURLOPT_TIMEOUT=>12,
            CURLOPT_USERAGENT=>'DMD-GenPW/QR-reader',
            CURLOPT_SSL_VERIFYPEER=>true,
            CURLOPT_SSL_VERIFYHOST=>2,
            CURLOPT_HTTPHEADER=>array('Accept: application/javascript,text/javascript,*/*;q=0.1')
        ));
        $data=curl_exec($ch);
        $status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        return $status>=200 && $status<300 && is_string($data)?$data:'';
    }
    if (filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN)) {
        $ctx=stream_context_create(array('http'=>array('timeout'=>12,'follow_location'=>1,'user_agent'=>'DMD-GenPW/QR-reader'),'ssl'=>array('verify_peer'=>true,'verify_peer_name'=>true)));
        $data=@file_get_contents($url,false,$ctx);
        return is_string($data)?$data:'';
    }
    return '';
}

$data='';
if (is_file($cache) && filesize($cache)>100000 && filemtime($cache)>time()-2592000) {
    $cached=@file_get_contents($cache);
    if (dmdgp_qr_valid_library($cached)) $data=$cached;
}

if ($data==='') {
    $urls=array(
        'https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js',
        'https://unpkg.com/jsqr@1.4.0/dist/jsQR.js',
        'https://raw.githubusercontent.com/cozmo/jsQR/v1.4.0/dist/jsQR.js'
    );
    foreach ($urls as $url) {
        $candidate=dmdgp_qr_fetch($url);
        if (!dmdgp_qr_valid_library($candidate)) continue;
        $data=$candidate;
        @file_put_contents($cache,$data,LOCK_EX);
        break;
    }
}

if ($data==='') {
    http_response_code(503);
    echo "console.error('DMD-GenPW: lecteur QR jsQR indisponible. Vérifiez que le NAS peut accéder à jsDelivr, unpkg ou GitHub.');\n";
    exit;
}

echo $data;
