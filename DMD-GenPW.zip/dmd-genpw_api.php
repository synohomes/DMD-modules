<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-genpw_crypto.php';
require_once __DIR__ . '/dmd-genpw_import.php';
require_once __DIR__ . '/dmd-genpw_pro.php';

function dmd_genpw_input() {
    $ct = strtolower((string)(isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : ''));
    if (strpos($ct, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $data = json_decode(is_string($raw) ? $raw : '', true);
        return is_array($data) ? $data : array();
    }
    return $_POST;
}

function dmd_genpw_check_csrf() {
    $session = dmd_genpw_csrf();
    $header = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? (string)$_SERVER['HTTP_X_CSRF_TOKEN'] : '';
    if ($header === '' || !hash_equals($session, $header)) dmd_genpw_reply(array('ok'=>false,'error'=>'Jeton de sécurité invalide'), 403);
}

function dmd_genpw_owned_file($email) { return dmd_genpw_user_dir($email) . '/pw.json'; }
function dmd_genpw_shared_file($email) { return dmd_genpw_user_dir($email) . '/shared.json'; }

function dmd_genpw_public_shares_file() {
    $dir = dmd_genpw_system_dir() . '/private';
    dmd_genpw_protect_directory($dir);
    return $dir . '/public_shares.json';
}
function dmd_genpw_public_shares_read() {
    return dmd_genpw_read_json(dmd_genpw_public_shares_file(), array());
}
function dmd_genpw_public_shares_write($rows) {
    dmd_genpw_write_json(dmd_genpw_public_shares_file(), is_array($rows) ? $rows : array());
}
function dmd_genpw_public_share_token() {
    return rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
}
function dmd_genpw_public_share_token_hash($token) {
    return hash('sha256', (string)$token);
}
function dmd_genpw_public_share_duration($value) {
    $allowed = array('1h'=>3600,'2h'=>7200,'8h'=>28800,'24h'=>86400,'7d'=>604800,'14d'=>1209600,'once'=>0);
    return isset($allowed[$value]) ? $allowed[$value] : 3600;
}
function dmd_genpw_public_share_fields($raw) {
    $allowed = array('name','cat','date','user','password','url','notes','mfa','extra');
    $out = array();
    foreach ((array)$raw as $field) {
        $field = strtolower(trim((string)$field));
        if (in_array($field, $allowed, true) && !in_array($field, $out, true)) $out[] = $field;
    }
    if (!in_array('name', $out, true)) array_unshift($out, 'name');
    return $out;
}

function dmd_genpw_public_share_blob_dir($shareId) {
    $shareId=preg_replace('/[^a-f0-9]/i','',(string)$shareId);
    $dir=dmd_genpw_system_dir().'/private/public_share_blobs/'.$shareId;
    dmd_genpw_protect_directory($dir);
    return $dir;
}
function dmd_genpw_public_share_key($token,$shareId,$pin='') {
    $material=(string)$token."\0".(string)$pin;
    $salt=(string)$shareId;
    if(function_exists('hash_hkdf')) {
        return hash_hkdf('sha256',$material,32,'DMD-GenPW public share v2',$salt);
    }
    return hash_hmac('sha256',"DMD-GenPW public share v2\0".$salt."\0".$material,$material,true);
}
function dmd_genpw_public_share_snapshot_aad($shareId) {
    return 'DMD-GenPW|public-share|v2|'.(string)$shareId.'|snapshot';
}
function dmd_genpw_public_share_attachment_aad($shareId,$attachmentId) {
    return 'DMD-GenPW|public-share|v2|'.(string)$shareId.'|attachment|'.(string)$attachmentId;
}
function dmd_genpw_public_share_rm_tree($path) {
    if(!is_dir($path)) return;
    foreach(scandir($path)?:array() as $name){
        if($name==='.'||$name==='..') continue;
        $p=$path.'/'.$name;
        if(is_dir($p)) dmd_genpw_public_share_rm_tree($p); else @unlink($p);
    }
    @rmdir($path);
}

function dmd_genpw_public_entry($id, $entry, $kind) {
    $meta=array('favorite'=>false,'tags'=>array(),'expires_at'=>'','profile_type'=>'generic','rotation_days'=>0,'last_rotated_at'=>'');
    if($kind==='owned' && function_exists('dmd_genpw_pro_meta')){
        try{$meta=dmd_genpw_pro_meta(dmd_genpw_email(),$id);}catch(Throwable $e){}
    }
    $rotationDue=false;
    if((int)($meta['rotation_days']??0)>0){
        $base=strtotime((string)($meta['last_rotated_at']??'')); if(!$base)$base=strtotime((string)($entry['updated_at']??$entry['created_at']??''));
        $rotationDue=$base && $base+((int)$meta['rotation_days']*86400)<time();
    }
    return array(
        'id'=>$id,
        'kind'=>$kind,
        'name'=>dmd_genpw_clean(isset($entry['name']) ? $entry['name'] : 'Sans nom',120),
        'cat'=>dmd_genpw_clean(isset($entry['cat']) ? $entry['cat'] : 'Autre',40),
        'date'=>dmd_genpw_clean(isset($entry['date']) ? $entry['date'] : '',40),
        'url'=>dmd_genpw_clean(isset($entry['url']) ? $entry['url'] : '',2048),
        'user'=>dmd_genpw_clean(isset($entry['user']) ? $entry['user'] : '',255),
        'notes'=>dmd_genpw_clean(isset($entry['notes']) ? $entry['notes'] : '',12000),
        'owner'=>dmd_genpw_clean(isset($entry['owner']) ? $entry['owner'] : '',255),
        'source_id'=>dmd_genpw_clean(isset($entry['source_id']) ? $entry['source_id'] : '',64),
        'shared_at'=>dmd_genpw_clean(isset($entry['shared_at']) ? $entry['shared_at'] : '',80),
        'read_only'=>$kind === 'shared' && (string)($entry['share_mode']??'read') !== 'write',
        'share_mode'=>$kind === 'shared' ? (string)($entry['share_mode']??'read') : '',
        'share_expires_at'=>$kind === 'shared' ? (string)($entry['share_expires_at']??'') : '',
        'mfa_configured'=>!empty($entry['mfa_data']) && !empty($entry['mfa_iv']) && !empty($entry['mfa_tag']) && in_array(strtolower((string)($entry['mfa_method']??'')),array('totp','hotp'),true),
        'mfa_code_ready'=>!empty($entry['mfa_data']) && !empty($entry['mfa_iv']) && !empty($entry['mfa_tag']) && in_array(strtolower((string)($entry['mfa_method']??'')),array('totp','hotp'),true),
        'mfa_method'=>dmd_genpw_clean(isset($entry['mfa_method']) ? $entry['mfa_method'] : '',20),
        'mfa_only'=>!empty($entry['mfa_only']),
        'fields_configured'=>!empty($entry['extra_data']) || !empty($entry['extra_cipher']) || !empty($entry['extra_fields']),
        'favorite'=>!empty($meta['favorite']),
        'tags'=>array_values((array)($meta['tags']??array())),
        'expires_at'=>(string)($meta['expires_at']??''),
        'profile_type'=>(string)($meta['profile_type']??'generic'),
        'rotation_days'=>(int)($meta['rotation_days']??0),
        'rotation_due'=>(bool)$rotationDue
    );
}

function dmd_genpw_validate_url($url) {
    if ($url === '') return '';
    $valid = filter_var($url, FILTER_VALIDATE_URL);
    $scheme = is_string($valid) ? strtolower((string)parse_url($valid, PHP_URL_SCHEME)) : '';
    if ($valid === false || !in_array($scheme, array('http','https'), true)) throw new InvalidArgumentException('L’URL doit commencer par http:// ou https://');
    return $url;
}

function dmd_genpw_clean_entry_input($input, $includeSecret) {
    $name = dmd_genpw_clean(isset($input['name']) ? $input['name'] : '',120);
    $cat = dmd_genpw_clean(isset($input['cat']) ? $input['cat'] : 'Autre',40);
    $url = dmd_genpw_validate_url(dmd_genpw_clean(isset($input['url']) ? $input['url'] : '',2048));
    $user = dmd_genpw_clean(isset($input['user']) ? $input['user'] : '',255);
    $notes = dmd_genpw_clean(isset($input['notes']) ? $input['notes'] : '',12000);
    if ($name === '') $name = 'Sans nom';
    if (!in_array($cat, dmd_genpw_categories(dmd_genpw_email()), true)) $cat = dmd_genpw_fallback_category(dmd_genpw_email());
    $out = array('name'=>$name,'cat'=>$cat,'url'=>$url,'user'=>$user,'notes'=>$notes);
    if ($includeSecret) {
        $secret = is_scalar(isset($input['pw']) ? $input['pw'] : null) ? (string)$input['pw'] : '';
        if ($secret === '' || strlen($secret) > 4096) throw new InvalidArgumentException('Le mot de passe à enregistrer est invalide.');
        $out['pw'] = $secret;
    }
    return $out;
}


function dmd_genpw_extra_clean($raw) {
    $rows=is_array($raw)?$raw:array();
    $out=array();
    $allowed=array('web','user','note','text','date','number','email','phone','password','secret','pin','api_key','ssh_key','other');
    $labels=array('web'=>'Lien Web','user'=>'Identifiant','note'=>'Note','text'=>'Texte','date'=>'Date','number'=>'Numéro','email'=>'E-mail','phone'=>'Téléphone','password'=>'Mot de passe','secret'=>'Secret','pin'=>'PIN','api_key'=>'Clé API','ssh_key'=>'Clé SSH','other'=>'Autres');
    foreach($rows as $row){
        if(!is_array($row)) continue;
        $type=strtolower(trim((string)($row['type']??'other')));
        if(!in_array($type,$allowed,true)) $type='other';
        $label=dmd_genpw_clean($row['label']??'',120);
        $value=is_scalar($row['value']??null)?(string)$row['value']:'';
        $sensitive=in_array($type,array('password','secret','pin','api_key','ssh_key'),true);
        $max=$type==='web'?2048:($sensitive?16384:12000);
        if(strlen($value)>$max) $value=substr($value,0,$max);
        if($type==='web' && trim($value)!=='') $value=dmd_genpw_validate_url(dmd_genpw_clean($value,2048));
        if($type==='date' && $value!=='' && !preg_match('/^\d{4}-\d{2}-\d{2}$/D',$value)) throw new InvalidArgumentException('Date de champ supplémentaire invalide.');
        if($type==='email' && trim($value)!=='' && filter_var($value,FILTER_VALIDATE_EMAIL)===false) throw new InvalidArgumentException('E-mail de champ supplémentaire invalide.');
        if($type==='number' && trim($value)!=='' && !is_numeric($value)) throw new InvalidArgumentException('Numéro de champ supplémentaire invalide.');
        if($label==='' && $value==='') continue;
        if($label==='') $label=$labels[$type]??'Autres';
        $fid=dmd_genpw_clean($row['id']??'',40);
        if(!preg_match('/^[a-zA-Z0-9_-]{1,40}$/D',$fid)) $fid='f_'.bin2hex(random_bytes(6));
        $out[]=array('id'=>$fid,'type'=>$type,'label'=>$label,'value'=>$value);
        if(count($out)>=50) break;
    }
    return $out;
}
function dmd_genpw_extra_fields_keys(){ return array('extra_v','extra_cipher','extra_iv','extra_tag','extra_data','extra_fields'); }
function dmd_genpw_extra_clear(&$entry){ foreach(dmd_genpw_extra_fields_keys() as $f) unset($entry[$f]); }
function dmd_genpw_extra_aad($email,$id){ return dmd_genpw_aad($email,$id).'|extra-fields'; }
function dmd_genpw_extra_field_aad($email,$id,$fieldId){ return dmd_genpw_aad($email,$id).'|extra-field|'.$fieldId; }
function dmd_genpw_extra_encrypt($email,$id,$fields){
    $fields=dmd_genpw_extra_clean($fields);
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
    $stored=array();
    foreach($fields as $field){
        $row=array('id'=>$field['id'],'type'=>$field['type'],'label'=>$field['label']);
        if(in_array($field['type'],array('password','secret','pin','api_key','ssh_key'),true)){
            $enc=dmd_genpw_encrypt((string)$field['value'],$key,dmd_genpw_extra_field_aad($email,$id,$field['id']));
            $row['v']=$enc['v']; $row['cipher']=$enc['cipher']; $row['iv']=$enc['iv']; $row['tag']=$enc['tag']; $row['data']=$enc['data'];
        } else {
            $row['value']=(string)$field['value'];
        }
        $stored[]=$row;
    }
    return array('extra_fields'=>$stored);
}
function dmd_genpw_extra_decrypt($email,$id,$entry){
    if(isset($entry['extra_fields']) && is_array($entry['extra_fields'])){
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
        $out=array();
        foreach($entry['extra_fields'] as $row){
            if(!is_array($row)) continue;
            $type=strtolower(trim((string)($row['type']??'other')));
            $fid=dmd_genpw_clean($row['id']??'',40);
            if(!preg_match('/^[a-zA-Z0-9_-]{1,40}$/D',$fid)) continue;
            $value='';
            if(in_array($type,array('password','secret','pin','api_key','ssh_key'),true)){
                if(!empty($row['data'])&&!empty($row['iv'])&&!empty($row['tag'])){
                    $wrapped=array('v'=>(int)($row['v']??2),'cipher'=>(string)($row['cipher']??'aes-256-gcm'),'iv'=>(string)$row['iv'],'tag'=>(string)$row['tag'],'data'=>(string)$row['data']);
                    $value=(string)dmd_genpw_decrypt($wrapped,$key,dmd_genpw_extra_field_aad($email,$id,$fid));
                }
            } else {
                $value=is_scalar($row['value']??null)?(string)$row['value']:'';
            }
            $out[]=array('id'=>$fid,'type'=>$type,'label'=>(string)($row['label']??''),'value'=>$value);
        }
        return dmd_genpw_extra_clean($out);
    }
    if(empty($entry['extra_data'])||empty($entry['extra_iv'])||empty($entry['extra_tag'])) return array();
    $wrapped=array('v'=>(int)($entry['extra_v']??2),'cipher'=>(string)($entry['extra_cipher']??'aes-256-gcm'),'iv'=>(string)$entry['extra_iv'],'tag'=>(string)$entry['extra_tag'],'data'=>(string)$entry['extra_data']);
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
    $plain=dmd_genpw_decrypt($wrapped,$key,dmd_genpw_extra_aad($email,$id));
    $rows=json_decode((string)$plain,true);
    return is_array($rows)?dmd_genpw_extra_clean($rows):array();
}

function dmd_genpw_mfa_encrypted_fields() {
    return array('mfa_v','mfa_cipher','mfa_iv','mfa_tag','mfa_data');
}

function dmd_genpw_mfa_clear_entry_fields(&$entry) {
    foreach (dmd_genpw_mfa_encrypted_fields() as $field) unset($entry[$field]);
    unset($entry['mfa_method']);
}

function dmd_genpw_mfa_aad($email, $id) {
    return dmd_genpw_aad($email, $id) . '|mfa';
}

function dmd_genpw_mfa_encrypt_config($email, $id, $config) {
    $json=json_encode($config,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) throw new RuntimeException('Configuration 2FA invalide.');
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
    $enc=dmd_genpw_encrypt($json,$key,dmd_genpw_mfa_aad($email,$id));
    return array(
        'mfa_v'=>$enc['v'],
        'mfa_cipher'=>$enc['cipher'],
        'mfa_iv'=>$enc['iv'],
        'mfa_tag'=>$enc['tag'],
        'mfa_data'=>$enc['data']
    );
}

function dmd_genpw_mfa_decrypt_config($email, $id, $entry) {
    if (empty($entry['mfa_data']) || empty($entry['mfa_iv']) || empty($entry['mfa_tag'])) return null;
    $wrapped=array(
        'v'=>isset($entry['mfa_v'])?(int)$entry['mfa_v']:2,
        'cipher'=>isset($entry['mfa_cipher'])?(string)$entry['mfa_cipher']:'aes-256-gcm',
        'iv'=>(string)$entry['mfa_iv'],
        'tag'=>(string)$entry['mfa_tag'],
        'data'=>(string)$entry['mfa_data']
    );
    $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
    $plain=dmd_genpw_decrypt($wrapped,$key,dmd_genpw_mfa_aad($email,$id));
    if (!is_string($plain)) throw new RuntimeException('Informations 2FA illisibles ou altérées.');
    $config=json_decode($plain,true);
    return is_array($config)?$config:null;
}

function dmd_genpw_mfa_parse_otpauth($value) {
    $value=trim((string)$value);
    if (stripos($value,'otpauth://')!==0) return null;
    $parts=parse_url($value);
    if (!is_array($parts)) throw new InvalidArgumentException('URI otpauth invalide.');
    $method=strtolower((string)($parts['host']??''));
    if (!in_array($method,array('totp','hotp'),true)) throw new InvalidArgumentException('Type otpauth non pris en charge.');
    $query=array(); parse_str((string)($parts['query']??''),$query);
    $secret=trim((string)($query['secret']??''));
    if ($secret==='') throw new InvalidArgumentException('Secret absent de l’URI otpauth.');
    $label=rawurldecode(ltrim((string)($parts['path']??''),'/'));
    $issuer=trim((string)($query['issuer']??''));
    $account=$label;
    if ($issuer!=='' && strpos($label,':')!==false) $account=trim(substr($label,strpos($label,':')+1));
    return array(
        'method'=>$method,
        'secret'=>$secret,
        'encoding'=>'base32',
        'algorithm'=>strtoupper((string)($query['algorithm']??'SHA1')),
        'digits'=>(int)($query['digits']??6),
        'period'=>(int)($query['period']??30),
        'counter'=>(int)($query['counter']??0),
        'issuer'=>$issuer,
        'account'=>$account,
        'otpauth_uri'=>$value
    );
}

function dmd_genpw_mfa_clean_config($raw, $existing = null) {
    $raw=is_array($raw)?$raw:array();
    $existing=is_array($existing)?$existing:array();
    $method=strtolower(trim((string)($raw['method']??($existing['method']??'none'))));
    $allowed=array('none','totp','hotp','email','sms','push','webauthn','other');
    if (!in_array($method,$allowed,true)) $method='other';
    if ($method==='none') return null;

    /* Tous les chemins d'import n'utilisent pas le même nom de champ.
       - formulaire : source
       - exports/API : secret
       - URI standard : otpauth_uri / uri
       Accepter les quatre évite qu'un import correctement décodé arrive ici
       avec un secret vide puis soit rejeté comme non configuré. */
    $sourceProvided=array_key_exists('source',$raw) || array_key_exists('secret',$raw) || array_key_exists('otpauth_uri',$raw) || array_key_exists('uri',$raw);
    $source='';
    foreach (array('source','otpauth_uri','uri','secret') as $sourceField) {
        if (!array_key_exists($sourceField,$raw)) continue;
        $candidate=trim((string)$raw[$sourceField]);
        if ($candidate!=='') { $source=$candidate; break; }
    }
    if ($source!=='' && (stripos($source,'mobileappcommunicator.auth.microsoft.com/activate')!==false || stripos($source,'phonefactor:/')===0)) {
        throw new InvalidArgumentException('Ce QR / cette URL est un enrôlement Microsoft Authenticator Push et ne contient pas un secret TOTP exploitable. Dans Microsoft/Entra, choisissez « Je veux utiliser une autre application d’authentification » ou « Configurer une autre application », puis importez le QR TOTP ou sa clé secrète dans DMD-GenPW.');
    }

    /* Import manuel tolérant : si le secret/URI a été collé par erreur dans
       Émetteur ou Compte, le reconnaître automatiquement au lieu de bloquer
       l'enregistrement. Un simple code TOTP temporaire à 6-10 chiffres n'est
       volontairement jamais considéré comme un secret permanent. */
    if ($source==='' && in_array($method,array('totp','hotp'),true)) {
        foreach (array('issuer','account') as $fallbackField) {
            $candidate=trim((string)($raw[$fallbackField]??''));
            if ($candidate==='') continue;

            $compact=preg_replace('/[\s-]+/','',$candidate);
            $looksOtpUri=stripos($candidate,'otpauth://')===0;
            $looksBase32=strlen($compact)>=16 && preg_match('/^[A-Z2-7]+=*$/i',$compact);
            $looksHex=strlen($compact)>=20 && strlen($compact)%2===0 && preg_match('/^[0-9a-f]+$/i',$compact);
            $looksBase64=strlen($compact)>=16 && preg_match('/^[A-Za-z0-9+\/=]+$/',$compact) && strpos($compact,'=')!==false;
            $looksTemporaryCode=preg_match('/^[0-9]{6,10}$/',$compact);

            if (!$looksTemporaryCode && ($looksOtpUri || $looksBase32 || $looksHex || $looksBase64)) {
                $source=$candidate;
                $raw[$fallbackField]='';
                break;
            }
        }
    }

    $parsed=$source!==''?dmd_genpw_mfa_parse_otpauth($source):null;
    if (is_array($parsed)) {
        $method=$parsed['method'];
        $secret=$parsed['secret'];
    } else {
        /* Quand le formulaire transmet explicitement source='', il s'agit d'une
           suppression/absence réelle du secret. Ne jamais recycler silencieusement
           l'ancien secret : c'est ce qui permettait à une mauvaise saisie de sembler
           validée alors que la fiche utilisait encore une ancienne clé. */
        $secret=$source!==''?$source:($sourceProvided?'':trim((string)($existing['secret']??'')));
    }

    $encoding=strtolower(trim((string)($raw['encoding']??($parsed['encoding']??($existing['encoding']??'auto')))));
    if (!in_array($encoding,array('auto','base32','hex','base64','raw'),true)) $encoding='auto';

    /* Un code affiché par un site/Authenticator (6 à 10 chiffres) est un code
       temporaire, jamais une clé d'enrôlement. L'accepter créait une fausse
       2FA qui générait ensuite des codes sans rapport avec le compte réel. */
    $secretCompact=preg_replace('/[\s-]+/','',(string)$secret);
    if (in_array($method,array('totp','hotp'),true) && preg_match('/^[0-9]{6,10}$/',$secretCompact)) {
        throw new InvalidArgumentException('Ce nombre est un code MFA temporaire, pas une clé secrète permanente. Importez le QR TOTP/otpauth ou la clé secrète fournie lors de l’enrôlement.');
    }

    $algorithm=strtoupper(trim((string)($raw['algorithm']??($parsed['algorithm']??($existing['algorithm']??'SHA1')))));
    if (!in_array($algorithm,array('SHA1','SHA256','SHA512'),true)) $algorithm='SHA1';
    $digits=(int)($raw['digits']??($parsed['digits']??($existing['digits']??6)));
    if ($digits<6 || $digits>10) $digits=6;
    $period=(int)($raw['period']??($parsed['period']??($existing['period']??30)));
    if ($period<15 || $period>300) $period=30;
    $counter=(int)($raw['counter']??($parsed['counter']??($existing['counter']??0)));
    if ($counter<0) $counter=0;

    if (in_array($method,array('totp','hotp'),true) && $secret==='') throw new InvalidArgumentException('Le secret permanent ou l’URI otpauth est requis pour cette 2FA.');
    if (strlen($secret)>8192) throw new InvalidArgumentException('Secret 2FA trop long.');
    if (in_array($method,array('totp','hotp'),true)) {
        $decoded=dmd_genpw_mfa_decode_secret($secret,$encoding);
        if (!is_string($decoded) || strlen($decoded)<10) throw new InvalidArgumentException('Clé MFA trop courte ou invalide. Un code temporaire ne peut pas servir de secret TOTP/HOTP.');
    }

    $issuer=dmd_genpw_clean((string)($raw['issuer']??($parsed['issuer']??($existing['issuer']??''))),255);
    $account=dmd_genpw_clean((string)($raw['account']??($parsed['account']??($existing['account']??''))),255);
    $notes=dmd_genpw_clean((string)($raw['notes']??($existing['notes']??'')),12000);
    $recoveryRaw=$raw['recovery_codes']??($existing['recovery_codes']??'');
    /* Ne jamais conserver les anciennes URL d'enrôlement Microsoft Push dans
       les métadonnées TOTP. Elles ne sont ni un émetteur, ni un compte, ni un
       code de récupération. */
    $isMsPush=function($v){
        $v=strtolower(trim((string)$v));
        return strpos($v,'mobileappcommunicator.auth.microsoft.com/activate')!==false || strpos($v,'phonefactor:/')===0;
    };
    if ($isMsPush($issuer)) $issuer='';
    if ($isMsPush($account)) $account='';
    if ($isMsPush($notes)) $notes='';
    if ($isMsPush($recoveryRaw)) $recoveryRaw='';
    if ($secret==='' && preg_match('/^[0-9]{6,10}$/',$issuer) && $issuer===$account && $issuer===trim((string)$recoveryRaw)) {
        $issuer=''; $account=''; $recoveryRaw='';
    }
    if (is_array($recoveryRaw)) $recoveryRaw=implode("\n",array_map('strval',$recoveryRaw));
    $recovery=dmd_genpw_clean((string)$recoveryRaw,12000);

    return array(
        'method'=>$method,'secret'=>$secret,'encoding'=>$encoding,'algorithm'=>$algorithm,
        'digits'=>$digits,'period'=>$period,'counter'=>$counter,'issuer'=>$issuer,'account'=>$account,
        'recovery_codes'=>$recovery,'notes'=>$notes,
        'otpauth_uri'=>is_array($parsed)?$parsed['otpauth_uri']:(string)($existing['otpauth_uri']??'')
    );
}

function dmd_genpw_mfa_base32_decode($secret) {
    $secret=strtoupper(preg_replace('/[^A-Z2-7]/i','',(string)$secret));
    if ($secret==='') return '';
    $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $buffer=0; $bits=0; $out='';
    for ($i=0,$len=strlen($secret);$i<$len;$i++) {
        $val=strpos($alphabet,$secret[$i]); if ($val===false) throw new InvalidArgumentException('Secret Base32 invalide.');
        $buffer=($buffer<<5)|$val; $bits+=5;
        while ($bits>=8) { $bits-=8; $out.=chr(($buffer>>$bits)&0xff); $buffer&=(1<<$bits)-1; }
    }
    return $out;
}

function dmd_genpw_mfa_decode_secret($secret, $encoding) {
    $secret=trim((string)$secret); $encoding=strtolower((string)$encoding);
    if ($encoding==='auto') {
        $compact=preg_replace('/[\s-]+/','',$secret);
        if ($compact!=='' && preg_match('/^[A-Z2-7]+=*$/i',$compact)) $encoding='base32';
        elseif ($compact!=='' && strlen($compact)%2===0 && preg_match('/^[0-9a-f]+$/i',$compact)) $encoding='hex';
        elseif ($compact!=='' && preg_match('/^[A-Za-z0-9+\/=]+$/',$compact) && strpos($compact,'=')!==false) $encoding='base64';
        else $encoding='raw';
    }
    if ($encoding==='base32') return dmd_genpw_mfa_base32_decode($secret);
    if ($encoding==='hex') { $v=@hex2bin(preg_replace('/\s+/','',$secret)); if ($v===false) throw new InvalidArgumentException('Secret hexadécimal invalide.'); return $v; }
    if ($encoding==='base64') { $v=base64_decode(preg_replace('/\s+/','',$secret),true); if ($v===false) throw new InvalidArgumentException('Secret Base64 invalide.'); return $v; }
    return $secret;
}

function dmd_genpw_mfa_hotp($secret, $counter, $digits, $algorithm) {
    $key=dmd_genpw_mfa_decode_secret($secret,(string)($GLOBALS['__dmdgp_mfa_encoding']??'auto'));
    if ($key==='') throw new InvalidArgumentException('Secret 2FA vide.');
    $counter=max(0,(int)$counter); $high=(int)floor($counter/4294967296); $low=(int)($counter%4294967296);
    $binary=pack('N2',$high,$low); $algo=strtolower((string)$algorithm);
    if (!in_array($algo,array('sha1','sha256','sha512'),true)) $algo='sha1';
    $hash=hash_hmac($algo,$binary,$key,true); $offset=ord($hash[strlen($hash)-1])&0x0f;
    if ($offset+3>=strlen($hash)) throw new RuntimeException('Calcul 2FA impossible.');
    $bin=((ord($hash[$offset])&0x7f)<<24)|((ord($hash[$offset+1])&0xff)<<16)|((ord($hash[$offset+2])&0xff)<<8)|(ord($hash[$offset+3])&0xff);
    $mod=10**max(6,min(10,(int)$digits));
    return str_pad((string)($bin%$mod),max(6,min(10,(int)$digits)),'0',STR_PAD_LEFT);
}

function dmd_genpw_mfa_generate_code($config) {
    if (!is_array($config)) throw new InvalidArgumentException('2FA non configurée.');
    $method=(string)($config['method']??'');
    if (!in_array($method,array('totp','hotp'),true)) throw new InvalidArgumentException('Cette méthode 2FA ne génère pas de code dans DMD-GenPW.');
    $GLOBALS['__dmdgp_mfa_encoding']=(string)($config['encoding']??'auto');
    try {
        if ($method==='totp') {
            $period=max(15,min(300,(int)($config['period']??30))); $now=time(); $counter=(int)floor($now/$period);
            $code=dmd_genpw_mfa_hotp((string)$config['secret'],$counter,(int)($config['digits']??6),(string)($config['algorithm']??'SHA1'));
            return array('code'=>$code,'method'=>'totp','remaining'=>$period-($now%$period),'counter'=>$counter);
        }
        $counter=max(0,(int)($config['counter']??0));
        $code=dmd_genpw_mfa_hotp((string)$config['secret'],$counter,(int)($config['digits']??6),(string)($config['algorithm']??'SHA1'));
        return array('code'=>$code,'method'=>'hotp','remaining'=>0,'counter'=>$counter);
    } finally { unset($GLOBALS['__dmdgp_mfa_encoding']); }
}


function dmd_genpw_mfa_is_ms_push_value($value) {
    $value=strtolower(trim((string)$value));
    return strpos($value,'mobileappcommunicator.auth.microsoft.com/activate')!==false || strpos($value,'phonefactor:/')===0;
}

/* Nettoyage automatique des fausses configurations créées par les anciennes
   versions de l'importeur MFA. On ne touche qu'aux cas objectivement
   inutilisables : code temporaire pris pour un secret, URL Microsoft Push
   rangée comme TOTP, ou "Autre méthode" vide. */
function dmd_genpw_mfa_repair_legacy_store($email) {
    $file=dmd_genpw_owned_file($email);
    $store=dmd_genpw_read_json($file,array());
    $changed=false;
    foreach ($store as $id=>&$entry) {
        if (dmd_genpw_valid_id($id)===null || !is_array($entry) || empty($entry['mfa_data'])) continue;
        try { $cfg=dmd_genpw_mfa_decrypt_config($email,(string)$id,$entry); }
        catch (Throwable $e) { continue; }
        if (!is_array($cfg)) continue;
        $method=strtolower(trim((string)($cfg['method']??'')));
        $secret=trim((string)($cfg['secret']??''));
        $invalid=false;
        if (in_array($method,array('totp','hotp'),true)) {
            $compact=preg_replace('/[\s-]+/','',$secret);
            if ($secret==='' || dmd_genpw_mfa_is_ms_push_value($secret) || preg_match('/^[0-9]{6,10}$/',$compact)) $invalid=true;
            foreach (array('issuer','account','recovery_codes','notes','otpauth_uri') as $f) { if (dmd_genpw_mfa_is_ms_push_value((string)($cfg[$f]??''))) $invalid=true; }
            if (!$invalid) {
                try {
                    $decoded=dmd_genpw_mfa_decode_secret($secret,(string)($cfg['encoding']??'auto'));
                    if (!is_string($decoded) || strlen($decoded)<10) $invalid=true;
                } catch (Throwable $e) { $invalid=true; }
            }
        }
        if ($invalid) {
            dmd_genpw_mfa_clear_entry_fields($entry);
            unset($entry['mfa_method']);
            $entry['updated_at']=date(DATE_ATOM);
            $entry['date']=date('d/m/Y H:i');
            $changed=true;
        }
    }
    unset($entry);
    if ($changed) dmd_genpw_write_json($file,$store);
    return $changed;
}

function dmd_genpw_mfa_copy_to_recipient($owner, $sourceId, $sourceEntry, $recipient, $shareId, &$targetEntry) {
    dmd_genpw_mfa_clear_entry_fields($targetEntry);
    $config=dmd_genpw_mfa_decrypt_config($owner,$sourceId,$sourceEntry);
    if (!is_array($config)) return;
    $targetEntry=array_merge($targetEntry,dmd_genpw_mfa_encrypt_config($recipient,$shareId,$config));
    $targetEntry['mfa_method']=(string)($config['method']??'');
}

function dmd_genpw_list_entries($email) {
    $items = array();
    foreach (array('owned'=>dmd_genpw_read_json(dmd_genpw_owned_file($email), array()), 'shared'=>dmd_genpw_read_json(dmd_genpw_shared_file($email), array())) as $kind=>$store) {
        foreach ($store as $id=>$entry) {
            if (dmd_genpw_valid_id($id) === null || !is_array($entry)) continue;
            $items[] = dmd_genpw_public_entry($id,$entry,$kind);
        }
    }
    usort($items, function($a,$b){ $c = strcasecmp($a['cat'],$b['cat']); return $c !== 0 ? $c : strcasecmp($a['name'],$b['name']); });
    return $items;
}

function dmd_genpw_store_for_kind($email, $kind, &$file) {
    $file = $kind === 'shared' ? dmd_genpw_shared_file($email) : dmd_genpw_owned_file($email);
    return dmd_genpw_read_json($file, array());
}

function dmd_genpw_decrypt_by_kind($email, $id, $kind, &$entry) {
    $file = '';
    $store = dmd_genpw_store_for_kind($email,$kind,$file);
    if (!isset($store[$id]) || !is_array($store[$id])) throw new OutOfBoundsException('Entrée introuvable.');
    $entry = $store[$id];
    $key = dmd_genpw_key(dmd_genpw_user_dir($email), $email);
    return dmd_genpw_decrypt_entry($store,$id,$key,$email,$file);
}

function dmd_genpw_share_rows_for_source($owner, $sourceId) {
    $index = dmd_genpw_share_index(); $rows = array();
    foreach ($index as $shareId=>$row) if (is_array($row) && (isset($row['owner']) ? $row['owner'] : '') === $owner && (isset($row['source_id']) ? $row['source_id'] : '') === $sourceId) { $row['share_id']=$shareId; $rows[]=$row; }
    return $rows;
}

function dmd_genpw_sync_shares($owner, $sourceId, $entry, $secret) {
    $index = dmd_genpw_share_index(); $updated = 0; $changedIndex = false;
    foreach ($index as $shareId=>&$row) {
        if (!is_array($row) || (isset($row['owner']) ? $row['owner'] : '') !== $owner || (isset($row['source_id']) ? $row['source_id'] : '') !== $sourceId) continue;
        $recipient = isset($row['recipient']) ? (string)$row['recipient'] : '';
        if (filter_var($recipient,FILTER_VALIDATE_EMAIL) === false) continue;
        try {
            $file = dmd_genpw_shared_file($recipient); $shared = dmd_genpw_read_json($file,array());
            if (!isset($shared[$shareId]) || !is_array($shared[$shareId])) continue;
            $key = dmd_genpw_key(dmd_genpw_user_dir($recipient),$recipient);
            $encrypted = dmd_genpw_encrypt($secret,$key,dmd_genpw_aad($recipient,$shareId));
            $base = $shared[$shareId];
            foreach (array('pw','iv','tag','data','cipher','v') as $f) unset($base[$f]);
            $shared[$shareId] = array_merge($base,array(
                'name'=>$entry['name'],'cat'=>$entry['cat'],'url'=>$entry['url'],'user'=>$entry['user'],'notes'=>$entry['notes'],
                'date'=>date('d/m/Y H:i'),'updated_at'=>date(DATE_ATOM)
            ),$encrypted);
            dmd_genpw_mfa_copy_to_recipient($owner,$sourceId,$entry,$recipient,$shareId,$shared[$shareId]);
            dmd_genpw_write_json($file,$shared);
            $row['updated_at']=date(DATE_ATOM); $changedIndex=true; $updated++;
            $en = strpos(strtolower(dmd_genpw_language()), 'en') === 0;
            dmd_genpw_notify($recipient,'credential_share_updated',$en ? 'Shared access updated' : 'Accès partagé mis à jour',(string)$entry['name'] . ($en ? ' was updated by ' : ' a été mis à jour par ') . $owner . '.',array('source_id'=>$sourceId,'share_id'=>$shareId));
        } catch (Throwable $e) { dmd_genpw_log('credential.share.sync',$sourceId,'error',array('recipient'=>$recipient,'message'=>$e->getMessage()),dmd_genpw_resource($sourceId,(string)$entry['name'],$owner)); }
    }
    unset($row);
    if ($changedIndex) dmd_genpw_write_share_index($index);
    return $updated;
}

function dmd_genpw_revoke_share_row($shareId, $notify) {
    $index = dmd_genpw_share_index();
    if (!isset($index[$shareId]) || !is_array($index[$shareId])) return false;
    $row = $index[$shareId]; $recipient = isset($row['recipient']) ? (string)$row['recipient'] : '';
    if (filter_var($recipient,FILTER_VALIDATE_EMAIL) !== false) {
        try { $file=dmd_genpw_shared_file($recipient); $shared=dmd_genpw_read_json($file,array()); unset($shared[$shareId]); dmd_genpw_write_json($file,$shared); } catch (Throwable $e) {}
        if ($notify) {
            $en = strpos(strtolower(dmd_genpw_language()), 'en') === 0;
            dmd_genpw_notify($recipient,'credential_share_revoked',$en ? 'Share revoked' : 'Partage retiré',(isset($row['label']) ? $row['label'] : ($en ? 'An access' : 'Un accès')) . ($en ? ' is no longer shared with you.' : ' n’est plus partagé avec vous.'),array('source_id'=>isset($row['source_id'])?$row['source_id']:'','share_id'=>$shareId));
        }
    }
    unset($index[$shareId]); dmd_genpw_write_share_index($index); return true;
}

function dmd_genpw_revoke_source_shares($owner,$sourceId,$label) {
    $index=dmd_genpw_share_index(); $ids=array();
    foreach ($index as $shareId=>$row) if (is_array($row) && (isset($row['owner'])?$row['owner']:'')===$owner && (isset($row['source_id'])?$row['source_id']:'')===$sourceId) $ids[]=$shareId;
    $count=0; foreach ($ids as $shareId) if (dmd_genpw_revoke_share_row($shareId,true)) $count++;
    return $count;
}

function dmd_genpw_propagate_category_for_owner($owner, $oldName, $newName) {
    $index = dmd_genpw_share_index();
    $changed = 0;
    foreach ($index as $shareId=>$row) {
        if (!is_array($row) || (isset($row['owner']) ? (string)$row['owner'] : '') !== $owner) continue;
        $recipient = isset($row['recipient']) ? (string)$row['recipient'] : '';
        if (filter_var($recipient, FILTER_VALIDATE_EMAIL) === false) continue;
        try {
            $file = dmd_genpw_shared_file($recipient);
            $shared = dmd_genpw_read_json($file, array());
            if (!isset($shared[$shareId]) || !is_array($shared[$shareId])) continue;
            $current = isset($shared[$shareId]['cat']) ? (string)$shared[$shareId]['cat'] : 'Autre';
            if (strcasecmp($current, $oldName) !== 0) continue;
            $shared[$shareId]['cat'] = $newName;
            $shared[$shareId]['updated_at'] = date(DATE_ATOM);
            $shared[$shareId]['date'] = date('d/m/Y H:i');
            dmd_genpw_write_json($file, $shared);
            $changed++;
        } catch (Throwable $e) {
            dmd_genpw_log('category.share.sync','category','error',array('recipient'=>$recipient,'message'=>$e->getMessage()));
        }
    }
    return $changed;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') dmd_genpw_reply(array('ok'=>false,'error'=>'Méthode refusée'),405);
if (!dmd_genpw_logged_in()) dmd_genpw_reply(array('ok'=>false,'error'=>'Utilisateur non connecté'),401);
dmd_genpw_check_csrf();
$input=dmd_genpw_input();
$action=dmd_genpw_clean(isset($input['action'])?$input['action']:'',50);
if ($action==='') dmd_genpw_reply(array('ok'=>false,'error'=>'Action manquante'),400);
$email=dmd_genpw_email();

$permissionMap=array(
    'bootstrap'=>'module.view','status'=>'module.view','unlock'=>'vault.unlock','lock'=>'vault.unlock','list'=>'vault.list','add'=>'vault.create','update'=>'vault.edit',
    'get_secret'=>'vault.reveal','get_qr'=>'vault.qr','delete'=>'vault.delete','share_users'=>'vault.share','share'=>'vault.share','shares'=>'vault.share','revoke_share'=>'vault.revoke','public_share_create'=>'vault.share','public_shares'=>'vault.share','public_share_revoke'=>'vault.revoke',
    'import'=>'vault.create','import_preview'=>'vault.create','export'=>'vault.export','logs'=>'logs.view','logs_export'=>'logs.export','logs_delete'=>'logs.delete','config_get'=>'config.view','config_save'=>'config.edit','mydesk_mode_get'=>'module.view','mydesk_mode_save'=>'module.view','web_session'=>'vault.list','web_target'=>'vault.list',
    'categories'=>'vault.list','category_create'=>'vault.create','category_rename'=>'vault.edit','category_delete'=>'vault.edit','move_category'=>'vault.edit',
    'entry_get'=>'vault.reveal','mfa_get'=>'vault.reveal','mfa_save'=>'vault.edit','mfa_clear'=>'vault.edit','mfa_code'=>'vault.reveal','system_mfa_import'=>'vault.edit','mfa_import_batch'=>'vault.create',
    'pro_overview'=>'vault.list','pro_meta_get'=>'vault.list','pro_meta_save'=>'vault.edit','favorite_toggle'=>'vault.edit',
    'history_list'=>'vault.list','history_restore'=>'vault.edit','trash_list'=>'vault.list','trash_restore'=>'vault.edit','trash_purge'=>'vault.delete',
    'duplicates'=>'vault.list','security_audit'=>'vault.list','advanced_search'=>'vault.list','pro_settings_get'=>'config.view','pro_settings_save'=>'config.edit',
    'sensitive_reauth'=>'vault.unlock','attachment_list'=>'vault.list','attachment_add'=>'vault.edit','attachment_get'=>'vault.reveal','attachment_delete'=>'vault.edit',
    'backup_create'=>'vault.export.secrets','backup_restore'=>'vault.edit','profile_templates'=>'vault.list','shared_update'=>'vault.edit','access_event'=>'vault.list','quicksession_attach'=>'vault.list'
);
if (!isset($permissionMap[$action])) dmd_genpw_reply(array('ok'=>false,'error'=>'Action inconnue'),400);
dmd_genpw_require_permission($permissionMap[$action]);

try {
    if ($action==='bootstrap') {
        $perms=array(); foreach (array_values(array_unique($permissionMap)) as $p) $perms[$p]=dmd_genpw_has_permission($p);
        dmd_genpw_reply(array('ok'=>true,'language'=>dmd_genpw_language(),'strings'=>dmd_genpw_strings(),'categories'=>dmd_genpw_categories($email),'config'=>dmd_genpw_config($email),'unlocked'=>dmd_genpw_is_unlocked($email),'permissions'=>$perms,'csrf'=>dmd_genpw_csrf()));
    }
    if ($action==='status') dmd_genpw_reply(array('ok'=>true,'unlocked'=>dmd_genpw_is_unlocked($email),'expires_in'=>dmd_genpw_is_unlocked($email)?max(0,dmd_genpw_unlock_timeout($email)-(time()-(int)$_SESSION['dmd_genpw_unlocked_at'])):0));
    if ($action==='mydesk_mode_get') dmd_genpw_reply(array('ok'=>true,'mode'=>dmd_genpw_mydesk_mode($email)));
    if ($action==='mydesk_mode_save') { $mode=dmd_genpw_set_mydesk_mode($email,isset($input['mode'])?$input['mode']:'compact'); dmd_genpw_reply(array('ok'=>true,'mode'=>$mode)); }
    if ($action==='unlock') {
        $blocked=(int)(isset($_SESSION['dmd_genpw_unlock_blocked_until'])?$_SESSION['dmd_genpw_unlock_blocked_until']:0);
        if ($blocked>time()) dmd_genpw_reply(array('ok'=>false,'error'=>'Trop de tentatives. Réessayez dans quelques minutes.','retry_after'=>$blocked-time()),429);

        $requireMfa=dmd_genpw_requires_system_mfa($email);
        if ($requireMfa && !dmd_genpw_system_mfa_enabled($email)) {
            dmd_genpw_reply(array('ok'=>false,'error'=>'Le MFA DoMyDesk est requis par DMD-GenPW mais il est désactivé sur votre compte. Réactivez-le dans votre profil ou désactivez cette option dans le CFG DMD-GenPW.'),409);
        }

        $authOk=false;
        $authMode=$requireMfa?'mfa':'password';
        if ($requireMfa) {
            $mfaCode=is_scalar(isset($input['mfa_code'])?$input['mfa_code']:null)?(string)$input['mfa_code']:'';
            $authOk=dmd_genpw_verify_system_mfa($email,$mfaCode);
        } else {
            $pwd=is_scalar(isset($input['pwd'])?$input['pwd']:null)?(string)$input['pwd']:'';
            if ($pwd==='' || strlen($pwd)>4096) dmd_genpw_reply(array('ok'=>false,'error'=>'Mot de passe invalide'),400);
            $authOk=dmd_genpw_verify_unlock_password($email,$pwd);
        }

        if ($authOk) {
            session_regenerate_id(true); $_SESSION['dmd_genpw_unlocked_at']=time(); unset($_SESSION['dmd_genpw_unlock_failures'],$_SESSION['dmd_genpw_unlock_blocked_until'],$_SESSION['dmd_genpw_qr_tokens']); dmd_genpw_web_sessions_revoke_user($email);
            dmd_genpw_log('vault.unlock','vault','success',array('system_mfa'=>$requireMfa,'unlock_method'=>$authMode),dmd_genpw_vault_resource($email));
            dmd_genpw_reply(array('ok'=>true,'expires_in'=>dmd_genpw_unlock_timeout($email),'system_mfa'=>$requireMfa,'unlock_method'=>$authMode));
        }
        $fails=(int)(isset($_SESSION['dmd_genpw_unlock_failures'])?$_SESSION['dmd_genpw_unlock_failures']:0)+1; $_SESSION['dmd_genpw_unlock_failures']=$fails;
        if ($fails>=DMD_GENPW_MAX_UNLOCK_FAILURES) { $_SESSION['dmd_genpw_unlock_blocked_until']=time()+DMD_GENPW_BLOCK_SECONDS; $_SESSION['dmd_genpw_unlock_failures']=0; }
        usleep(300000); dmd_genpw_log('vault.unlock','vault','denied',array('system_mfa'=>$requireMfa,'unlock_method'=>$authMode)); dmd_genpw_reply(array('ok'=>false,'error'=>$requireMfa?'Code MFA incorrect.':'Mot de passe incorrect'),401);
    }
    if ($action==='lock') { unset($_SESSION['dmd_genpw_unlocked_at'],$_SESSION['dmd_genpw_qr_tokens']); dmd_genpw_web_sessions_revoke_user($email); dmd_genpw_log('vault.lock','vault','success',array(),dmd_genpw_vault_resource($email)); dmd_genpw_reply(array('ok'=>true,'locked'=>true)); }
    if ($action==='config_get') dmd_genpw_reply(array('ok'=>true,'config'=>dmd_genpw_config($email),'language'=>dmd_genpw_language(),'strings'=>dmd_genpw_strings()));
    if ($action==='config_save') { $cfg=dmd_genpw_save_config($email,$input); dmd_genpw_log('config.update','config','success',array('config'=>$cfg)); dmd_genpw_reply(array('ok'=>true,'config'=>$cfg)); }

    dmd_genpw_touch_unlock($email);
    if ($action==='web_session') {
        dmd_genpw_web_sessions_revoke_user($email);
        $web=dmd_genpw_web_session_create($email);
        dmd_genpw_reply(array('ok'=>true,'token'=>$web['token'],'expires_in'=>$web['expires_in']));
    }
    if ($action==='web_target') {
        $token=is_scalar(isset($input['web_token'])?$input['web_token']:null)?(string)$input['web_token']:'';
        $target=is_scalar(isset($input['url'])?$input['url']:null)?trim((string)$input['url']):'';
        $web=dmd_genpw_web_session_validate($token,true);
        if (!is_array($web) || !hash_equals($email,(string)($web['email']??''))) dmd_genpw_reply(array('ok'=>false,'error'=>'Session de navigation expirée.'),401);
        $target=dmd_genpw_validate_url($target);
        $targetParts=parse_url($target); $targetScheme=strtolower((string)($targetParts['scheme']??'')); $targetHost=strtolower((string)($targetParts['host']??''));
        $targetPort=isset($targetParts['port'])?(int)$targetParts['port']:(($targetScheme==='https')?443:80);
        $targetOrigin=$targetScheme.'://'.$targetHost.((($targetScheme==='https'&&$targetPort===443)||($targetScheme==='http'&&$targetPort===80))?'':':'.$targetPort);
        $allowed=false;
        foreach (dmd_genpw_list_entries($email) as $row) {
            $saved=(string)($row['url']??''); if ($saved==='') continue; $sp=parse_url($saved); if (!is_array($sp)||empty($sp['scheme'])||empty($sp['host'])) continue;
            $ss=strtolower((string)$sp['scheme']); $sh=strtolower((string)$sp['host']); $spt=isset($sp['port'])?(int)$sp['port']:(($ss==='https')?443:80);
            $so=$ss.'://'.$sh.((($ss==='https'&&$spt===443)||($ss==='http'&&$spt===80))?'':':'.$spt);
            if (hash_equals($so,$targetOrigin)) { $allowed=true; break; }
        }
        if (!$allowed) dmd_genpw_reply(array('ok'=>false,'error'=>'Destination web non autorisée : ajoutez d’abord ce site dans GenPW.'),403);
        $sig=dmd_genpw_web_proxy_sign_target($token,$target);
        if ($sig==='') dmd_genpw_reply(array('ok'=>false,'error'=>'Impossible d’autoriser cette navigation.'),400);
        dmd_genpw_reply(array('ok'=>true,'url'=>$target,'signature'=>$sig));
    }
    $ownedFile=dmd_genpw_owned_file($email); $sharedFile=dmd_genpw_shared_file($email);
    $owned=dmd_genpw_read_json($ownedFile,array());

    if ($action==='pro_settings_get') dmd_genpw_reply(array('ok'=>true,'settings'=>dmd_genpw_pro_settings($email)));
    if ($action==='pro_settings_save') dmd_genpw_reply(array('ok'=>true,'settings'=>dmd_genpw_pro_save_settings($email,$input)));
    if ($action==='profile_templates') dmd_genpw_reply(array('ok'=>true,'templates'=>dmd_genpw_pro_profile_templates()));
    if ($action==='pro_meta_get') {
        $id=dmd_genpw_valid_id($input['id']??null); if($id===null||!isset($owned[$id]))throw new OutOfBoundsException('Entrée introuvable.');
        dmd_genpw_reply(array('ok'=>true,'meta'=>dmd_genpw_pro_meta($email,$id),'attachments'=>dmd_genpw_pro_attachment_list($email,$id)));
    }
    if ($action==='pro_meta_save') {
        $id=dmd_genpw_valid_id($input['id']??null); if($id===null||!isset($owned[$id]))throw new OutOfBoundsException('Entrée introuvable.');
        dmd_genpw_pro_snapshot($email,$id,$owned[$id],'metadata');
        dmd_genpw_reply(array('ok'=>true,'meta'=>dmd_genpw_pro_meta_save($email,$id,$input)));
    }
    if ($action==='favorite_toggle') {
        $id=dmd_genpw_valid_id($input['id']??null); if($id===null||!isset($owned[$id]))throw new OutOfBoundsException('Entrée introuvable.');
        $m=dmd_genpw_pro_meta($email,$id); $m=dmd_genpw_pro_meta_save($email,$id,array('favorite'=>!$m['favorite']));
        dmd_genpw_reply(array('ok'=>true,'favorite'=>$m['favorite'],'meta'=>$m));
    }
    if ($action==='history_list') {
        $id=dmd_genpw_valid_id($input['id']??null); if($id===null)throw new InvalidArgumentException('Identifiant invalide.');
        dmd_genpw_reply(array('ok'=>true,'items'=>dmd_genpw_pro_history_list($email,$id)));
    }
    if ($action==='history_restore') {
        $id=dmd_genpw_valid_id($input['id']??null);$version=(string)($input['version']??'');if($id===null||$version==='')throw new InvalidArgumentException('Version invalide.');
        $entry=dmd_genpw_pro_history_restore($email,$id,$version,$ownedFile); dmd_genpw_reply(array('ok'=>true,'entry'=>dmd_genpw_public_entry($id,$entry,'owned')));
    }
    if ($action==='trash_list') dmd_genpw_reply(array('ok'=>true,'items'=>dmd_genpw_pro_trash_list($email)));
    if ($action==='trash_restore') {
        $id=dmd_genpw_valid_id($input['id']??null);if($id===null)throw new InvalidArgumentException('Identifiant invalide.');
        $entry=dmd_genpw_pro_trash_restore($email,$id,$ownedFile);dmd_genpw_reply(array('ok'=>true,'entry'=>dmd_genpw_public_entry($id,$entry,'owned')));
    }
    if ($action==='trash_purge') {
        if(!dmd_genpw_pro_sensitive_ok($email) && !empty(dmd_genpw_pro_settings($email)['sensitive_reauth'])) throw new InvalidArgumentException('Ré-authentification MFA requise.');
        $ids=is_array($input['ids']??null)?$input['ids']:array();dmd_genpw_reply(array('ok'=>true,'purged'=>dmd_genpw_pro_trash_purge($email,$ids)));
    }
    if ($action==='duplicates') dmd_genpw_reply(array('ok'=>true,'items'=>dmd_genpw_pro_duplicates($email,$owned,$ownedFile)));
    if ($action==='security_audit') {
        $hibp=!empty($input['check_pwned']) && !empty(dmd_genpw_pro_settings($email)['hibp_enabled']);
        dmd_genpw_reply(array('ok'=>true,'audit'=>dmd_genpw_pro_security_audit($email,$owned,$ownedFile,$hibp)));
    }
    if ($action==='advanced_search') dmd_genpw_reply(array('ok'=>true,'ids'=>dmd_genpw_pro_advanced_search($email,$owned,$input)));
    if ($action==='sensitive_reauth') {
        $ok=dmd_genpw_pro_sensitive_auth($email,(string)($input['mfa_code']??''),(string)($input['password']??''));
        if(!$ok)dmd_genpw_reply(array('ok'=>false,'error'=>'Ré-authentification refusée.'),401);
        dmd_genpw_reply(array('ok'=>true,'valid_for'=>300));
    }
    if ($action==='attachment_list') {
        $id=dmd_genpw_valid_id($input['id']??null);if($id===null)throw new InvalidArgumentException('Identifiant invalide.');
        dmd_genpw_reply(array('ok'=>true,'items'=>dmd_genpw_pro_attachment_list($email,$id)));
    }
    if ($action==='attachment_add') {
        $id=dmd_genpw_valid_id($input['id']??null);if($id===null||!isset($owned[$id]))throw new OutOfBoundsException('Entrée introuvable.');
        if(!isset($_FILES['file'])||!is_array($_FILES['file'])||(int)($_FILES['file']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new InvalidArgumentException('Pièce jointe manquante.');
        $tmp=(string)$_FILES['file']['tmp_name'];$bytes=file_get_contents($tmp);if(!is_string($bytes))throw new RuntimeException('Lecture de la pièce jointe impossible.');
        $meta=dmd_genpw_pro_attachment_encrypt($email,$id,(string)($_FILES['file']['name']??'fichier'),(string)($_FILES['file']['type']??'application/octet-stream'),$bytes);
        dmd_genpw_reply(array('ok'=>true,'attachment'=>$meta));
    }
    if ($action==='attachment_get') {
        $aid=dmd_genpw_clean($input['attachment_id']??'',40);$r=dmd_genpw_pro_attachment_get($email,$aid);
        dmd_genpw_reply(array('ok'=>true,'attachment'=>$r['meta'],'content'=>base64_encode((string)$r['bytes'])));
    }
    if ($action==='attachment_delete') {
        $aid=dmd_genpw_clean($input['attachment_id']??'',40);dmd_genpw_pro_attachment_delete($email,$aid);dmd_genpw_reply(array('ok'=>true));
    }
    if ($action==='backup_create') {
        if(!dmd_genpw_pro_sensitive_ok($email) && !empty(dmd_genpw_pro_settings($email)['sensitive_reauth'])) throw new InvalidArgumentException('Ré-authentification MFA requise.');
        dmd_genpw_reply(array_merge(array('ok'=>true),dmd_genpw_pro_backup_create($email,$owned)));
    }
    if ($action==='backup_restore') {
        if(!dmd_genpw_pro_sensitive_ok($email) && !empty(dmd_genpw_pro_settings($email)['sensitive_reauth'])) throw new InvalidArgumentException('Ré-authentification MFA requise.');
        dmd_genpw_reply(array('ok'=>true,'result'=>dmd_genpw_pro_backup_restore($email,(string)($input['content']??''),$ownedFile)));
    }
    if ($action==='access_event') {
        $id=dmd_genpw_valid_id($input['id']??null);$event=dmd_genpw_clean($input['event']??'',60);
        if($id===null||$event==='')throw new InvalidArgumentException('Événement invalide.');
        $label=isset($owned[$id])&&is_array($owned[$id])?(string)($owned[$id]['name']??'Identifiant'):'Identifiant';
        dmd_genpw_log('credential.access.'.$event,$id,'success',array('source'=>'ui'),dmd_genpw_resource($id,$label,$email));
        dmd_genpw_reply(array('ok'=>true));
    }
    if ($action==='quicksession_attach') {
        $ids=is_array($input['ids']??null)?$input['ids']:array($input['id']??'');$clean=array();
        foreach($ids as $raw){$id=dmd_genpw_valid_id($raw);if($id!==null&&isset($owned[$id]))$clean[]=$id;}
        $_SESSION['dmd_genpw_quicksession_entries']=array_values(array_unique($clean));
        $resources=array();foreach($_SESSION['dmd_genpw_quicksession_entries'] as $id){$e=$owned[$id];$resources[]=array('id'=>$id,'name'=>(string)($e['name']??''),'category'=>(string)($e['cat']??''),'url'=>(string)($e['url']??''),'user'=>(string)($e['user']??''),'secrets_hidden'=>true);}
        dmd_genpw_log('quicksession.attach','vault','success',array('count'=>count($resources)),dmd_genpw_vault_resource($email));
        dmd_genpw_reply(array('ok'=>true,'resources'=>$resources));
    }
    if ($action==='pro_overview') {
        $meta=dmd_genpw_pro_meta_all($email);$fav=0;$expired=0;$tags=array();
        foreach($meta as $m){if(!is_array($m))continue;if(!empty($m['favorite']))$fav++;if(!empty($m['expires_at'])&&strtotime((string)$m['expires_at'])<time())$expired++;foreach((array)($m['tags']??array()) as $t)$tags[$t]=true;}
        dmd_genpw_reply(array('ok'=>true,'summary'=>array('entries'=>count($owned),'favorites'=>$fav,'expired'=>$expired,'tags'=>count($tags),'trash'=>count(dmd_genpw_pro_trash_list($email)))));
    }

    if ($action==='list') { dmd_genpw_mfa_repair_legacy_store($email); dmd_genpw_reply(array('ok'=>true,'items'=>dmd_genpw_list_entries($email))); }
    if ($action==='categories') {
        dmd_genpw_reply(array('ok'=>true,'categories'=>dmd_genpw_categories($email),'defaults'=>dmd_genpw_active_default_categories($email),'custom'=>dmd_genpw_custom_categories($email)));
    }
    if ($action==='category_create') {
        $name=dmd_genpw_create_category($email,isset($input['name'])?$input['name']:'');
        dmd_genpw_log('category.create','category','success',array('name'=>$name),dmd_genpw_vault_resource($email));
        dmd_genpw_reply(array('ok'=>true,'name'=>$name,'categories'=>dmd_genpw_categories($email),'defaults'=>dmd_genpw_active_default_categories($email),'custom'=>dmd_genpw_custom_categories($email)));
    }
    if ($action==='category_rename') {
        $result=dmd_genpw_rename_category($email,isset($input['old_name'])?$input['old_name']:'',isset($input['name'])?$input['name']:'');
        $result['shared_updated']=dmd_genpw_propagate_category_for_owner($email,$result['old'],$result['name']);
        dmd_genpw_log('category.rename','category','success',$result,dmd_genpw_vault_resource($email));
        dmd_genpw_reply(array('ok'=>true,'result'=>$result,'categories'=>dmd_genpw_categories($email),'defaults'=>dmd_genpw_active_default_categories($email),'custom'=>dmd_genpw_custom_categories($email)));
    }
    if ($action==='category_delete') {
        $result=dmd_genpw_delete_category($email,isset($input['name'])?$input['name']:'');
        $result['shared_updated']=dmd_genpw_propagate_category_for_owner($email,$result['name'],$result['fallback']);
        dmd_genpw_log('category.delete','category','success',$result,dmd_genpw_vault_resource($email));
        dmd_genpw_reply(array('ok'=>true,'result'=>$result,'categories'=>dmd_genpw_categories($email),'defaults'=>dmd_genpw_active_default_categories($email),'custom'=>dmd_genpw_custom_categories($email)));
    }
    if ($action==='move_category') {
        $category=dmd_genpw_clean(isset($input['category'])?$input['category']:'',40);
        if ($category==='' || !in_array($category,dmd_genpw_categories($email),true)) throw new InvalidArgumentException('Catégorie invalide.');
        $ids=isset($input['ids']) && is_array($input['ids']) ? array_values(array_unique($input['ids'])) : array();
        if (!$ids) throw new InvalidArgumentException('Aucun identifiant à déplacer.');
        if (count($ids)>500) throw new InvalidArgumentException('Trop d’identifiants sélectionnés.');

        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
        $changed=array(); $secrets=array();
        foreach ($ids as $rawId) {
            $id=dmd_genpw_valid_id(is_scalar($rawId)?(string)$rawId:'');
            if ($id===null || !isset($owned[$id]) || !is_array($owned[$id])) continue;
            $current=isset($owned[$id]['cat'])?(string)$owned[$id]['cat']:'Autre';
            if ($current===$category) continue;
            $secrets[$id]=dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile);
            $owned[$id]['cat']=$category;
            $owned[$id]['updated_at']=date(DATE_ATOM);
            $owned[$id]['date']=date('d/m/Y H:i');
            $changed[]=$id;
        }
        if ($changed) dmd_genpw_write_json($ownedFile,$owned);

        $sharedUpdated=0;
        foreach ($changed as $id) {
            $sharedUpdated+=dmd_genpw_sync_shares($email,$id,$owned[$id],$secrets[$id]);
            dmd_genpw_log('credential.category.move',$id,'success',array('category'=>$category),dmd_genpw_resource($id,(string)($owned[$id]['name']??'Identifiant'),$email));
        }
        dmd_genpw_reply(array('ok'=>true,'moved'=>count($changed),'category'=>$category,'shared_updated'=>$sharedUpdated));
    }
    if ($action==='import_preview') {
        if (!isset($_FILES['file']) || !is_array($_FILES['file'])) throw new InvalidArgumentException('Aucun fichier d’import reçu.');
        $upload=$_FILES['file']; if((int)($upload['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK) throw new InvalidArgumentException('Erreur de téléversement.');
        $tmp=(string)($upload['tmp_name']??'');$original=(string)($upload['name']??'import');
        $source=is_scalar($input['source']??null)?(string)$input['source']:'auto';
        $parsed=dmd_genpw_import_parse_file($tmp,$original,$source);
        $rows=is_array($parsed['items']??null)?$parsed['items']:array();
        $existing=array();
        foreach($owned as $existingEntry){if(!is_array($existingEntry))continue;$fp=strtolower(trim((string)($existingEntry['name']??'')))."\n".strtolower(trim((string)($existingEntry['url']??'')))."\n".strtolower(trim((string)($existingEntry['user']??'')));$existing[$fp]=true;}
        $duplicates=0;$valid=0;$sample=array();
        foreach($rows as $row){if(!is_array($row))continue;try{$v=dmd_genpw_clean_entry_input($row,true);}catch(Throwable $e){continue;}
            $fp=strtolower(trim((string)$v['name']))."\n".strtolower(trim((string)$v['url']))."\n".strtolower(trim((string)$v['user']));
            if(isset($existing[$fp]))$duplicates++;$valid++;if(count($sample)<10)$sample[]=array('name'=>$v['name'],'url'=>$v['url'],'user'=>$v['user'],'category'=>$v['cat'],'duplicate'=>isset($existing[$fp]));
        }
        dmd_genpw_reply(array('ok'=>true,'source'=>(string)($parsed['source']??'Import'),'total'=>count($rows),'valid'=>$valid,'duplicates'=>$duplicates,'unsupported'=>(int)($parsed['skipped']??0),'sample'=>$sample));
    }
    if ($action==='import') {
        if (!isset($_FILES['file']) || !is_array($_FILES['file'])) throw new InvalidArgumentException('Aucun fichier d’import reçu.');
        $upload=$_FILES['file'];
        $uploadError=(int)(isset($upload['error'])?$upload['error']:UPLOAD_ERR_NO_FILE);
        if ($uploadError!==UPLOAD_ERR_OK) {
            $messages=array(UPLOAD_ERR_INI_SIZE=>'Fichier trop volumineux pour PHP.',UPLOAD_ERR_FORM_SIZE=>'Fichier trop volumineux.',UPLOAD_ERR_PARTIAL=>'Téléversement incomplet.',UPLOAD_ERR_NO_FILE=>'Aucun fichier sélectionné.');
            throw new InvalidArgumentException(isset($messages[$uploadError])?$messages[$uploadError]:'Erreur de téléversement du fichier.');
        }
        $tmp=is_scalar(isset($upload['tmp_name'])?$upload['tmp_name']:null)?(string)$upload['tmp_name']:'';
        $original=is_scalar(isset($upload['name'])?$upload['name']:null)?(string)$upload['name']:'import';
        $source=is_scalar(isset($input['source'])?$input['source']:null)?(string)$input['source']:'auto';
        $skipExisting=!isset($input['skip_existing']) || !in_array(strtolower((string)$input['skip_existing']),array('0','false','no','off'),true);
        $parsed=dmd_genpw_import_parse_file($tmp,$original,$source);
        $rows=isset($parsed['items'])&&is_array($parsed['items'])?$parsed['items']:array();
        if (!$rows) throw new InvalidArgumentException('Aucune entrée exploitable trouvée dans cet export.');
        $existing=array();
        foreach ($owned as $existingId=>$existingEntry) {
            if (!is_array($existingEntry)) continue;
            $fingerprint=strtolower(trim((string)($existingEntry['name']??'')))."\n".strtolower(trim((string)($existingEntry['url']??'')))."\n".strtolower(trim((string)($existingEntry['user']??'')));
            $existing[$fingerprint]=true;
        }
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
        $imported=0;$duplicates=0;$invalid=0;$resources=array();
        foreach ($rows as $row) {
            if (!is_array($row)) { $invalid++; continue; }
            try { $v=dmd_genpw_clean_entry_input($row,true); } catch (Throwable $e) { $invalid++; continue; }
            $fingerprint=strtolower(trim((string)$v['name']))."\n".strtolower(trim((string)$v['url']))."\n".strtolower(trim((string)$v['user']));
            if ($skipExisting && isset($existing[$fingerprint])) { $duplicates++; continue; }
            do{$id=bin2hex(random_bytes(8));}while(isset($owned[$id]));
            $enc=dmd_genpw_encrypt($v['pw'],$key,dmd_genpw_aad($email,$id));
            $owned[$id]=array_merge(array('name'=>$v['name'],'cat'=>$v['cat'],'url'=>$v['url'],'user'=>$v['user'],'notes'=>$v['notes'],'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM),'date'=>date('d/m/Y H:i'),'imported_from'=>(string)($parsed['source']??'Import')),$enc);
            $existing[$fingerprint]=true;$imported++;
            if (count($resources)<20) $resources[]=dmd_genpw_resource($id,$v['name'],$email);
        }
        if ($imported>0) dmd_genpw_write_json($ownedFile,$owned);
        $sourceLabel=(string)($parsed['source']??'Import');
        $skippedSource=(int)($parsed['skipped']??0);
        dmd_genpw_log('vault.import','vault','success',array('source'=>$sourceLabel,'imported'=>$imported,'duplicates'=>$duplicates,'invalid'=>$invalid,'unsupported'=>$skippedSource,'filename'=>basename($original)),dmd_genpw_vault_resource($email));
        dmd_genpw_reply(array('ok'=>true,'source'=>$sourceLabel,'imported'=>$imported,'duplicates'=>$duplicates,'invalid'=>$invalid,'unsupported'=>$skippedSource,'total_detected'=>count($rows)+$skippedSource,'resources'=>$resources));
    }
    if ($action==='entry_get') {
        $id=dmd_genpw_valid_id($input['id']??null);
        $kind=(($input['kind']??'owned')==='shared')?'shared':'owned';
        if($id===null) throw new InvalidArgumentException('Identifiant invalide.');
        $file=''; $store=dmd_genpw_store_for_kind($email,$kind,$file);
        if(!isset($store[$id])||!is_array($store[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        $entry=$store[$id];
        $extra=$kind==='shared' ? array() : dmd_genpw_extra_decrypt($email,$id,$entry);
        dmd_genpw_reply(array('ok'=>true,'entry'=>dmd_genpw_public_entry($id,$entry,$kind),'extra_fields'=>$extra));
    }
    if ($action==='add') {
        $v=dmd_genpw_clean_entry_input($input,true); do{$id=bin2hex(random_bytes(8));}while(isset($owned[$id]));
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email); $enc=dmd_genpw_encrypt($v['pw'],$key,dmd_genpw_aad($email,$id));
        $owned[$id]=array_merge(array('name'=>$v['name'],'cat'=>$v['cat'],'url'=>$v['url'],'user'=>$v['user'],'notes'=>$v['notes'],'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM),'date'=>date('d/m/Y H:i')),$enc,dmd_genpw_extra_encrypt($email,$id,$input['extra_fields']??array()));
        dmd_genpw_write_json($ownedFile,$owned);
        dmd_genpw_pro_meta_save($email,$id,array(
            'tags'=>$input['tags']??array(),'favorite'=>!empty($input['favorite']),'expires_at'=>$input['expires_at']??'',
            'rotation_days'=>$input['rotation_days']??0,'profile_type'=>$input['profile_type']??'generic','field_masks'=>$input['field_masks']??array()
        ));
        dmd_genpw_pro_snapshot($email,$id,$owned[$id],'create');
        $r=dmd_genpw_resource($id,$v['name'],$email); $activity=dmd_genpw_log('credential.create',$id,'success',array('category'=>$v['cat']),$r);
        dmd_genpw_reply(array('ok'=>true,'id'=>$id,'resource'=>$r,'activity'=>$activity,'meta'=>dmd_genpw_pro_meta($email,$id)));
    }
    if ($action==='update') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); if ($id===null || !isset($owned[$id]) || !is_array($owned[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        dmd_genpw_pro_snapshot($email,$id,$owned[$id],'before_update');
        $v=dmd_genpw_clean_entry_input($input,false); $entry=$owned[$id];
        foreach (array('name','cat','url','user','notes') as $f) $entry[$f]=$v[$f]; $entry['updated_at']=date(DATE_ATOM); $entry['date']=date('d/m/Y H:i');
        $secret=''; $provided=is_scalar(isset($input['pw'])?$input['pw']:null)?(string)$input['pw']:''; $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
        if ($provided!=='') { if (strlen($provided)>4096) throw new InvalidArgumentException('Mot de passe invalide.'); $secret=$provided; foreach(array('pw','iv','tag','data','cipher','v') as $f) unset($entry[$f]); unset($entry['mfa_only']); $entry=array_merge($entry,dmd_genpw_encrypt($secret,$key,dmd_genpw_aad($email,$id))); dmd_genpw_pro_meta_save($email,$id,array('last_rotated_at'=>date(DATE_ATOM))); }
        else { $secret=dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile); }
        if (array_key_exists('extra_fields',$input)) { dmd_genpw_extra_clear($entry); $entry=array_merge($entry,dmd_genpw_extra_encrypt($email,$id,$input['extra_fields'])); }
        $owned[$id]=$entry; dmd_genpw_write_json($ownedFile,$owned);
        if (array_key_exists('tags',$input)||array_key_exists('favorite',$input)||array_key_exists('expires_at',$input)||array_key_exists('rotation_days',$input)||array_key_exists('profile_type',$input)||array_key_exists('field_masks',$input)) {
            dmd_genpw_pro_meta_save($email,$id,$input);
        }
        $synced=dmd_genpw_sync_shares($email,$id,$entry,$secret); $r=dmd_genpw_resource($id,$entry['name'],$email); $activity=dmd_genpw_log('credential.update',$id,'success',array('category'=>$entry['cat'],'shared_updated'=>$synced),$r);
        dmd_genpw_reply(array('ok'=>true,'id'=>$id,'shared_updated'=>$synced,'resource'=>$r,'activity'=>$activity,'meta'=>dmd_genpw_pro_meta($email,$id)));
    }
    if ($action==='mfa_import_batch') {
        $items=isset($input['items'])&&is_array($input['items'])?$input['items']:array();
        if (!$items) throw new InvalidArgumentException('Aucun compte MFA à importer.');
        if (count($items)>500) throw new InvalidArgumentException('Import limité à 500 comptes MFA à la fois.');
        $skipExisting=!isset($input['skip_existing']) || !in_array(strtolower((string)$input['skip_existing']),array('0','false','no','off'),true);
        $sourceLabel=dmd_genpw_clean((string)($input['source']??'Authenticator'),80);
        if ($sourceLabel==='') $sourceLabel='Authenticator';

        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
        $existing=array();
        foreach ($owned as $existingId=>$existingEntry) {
            if (!is_array($existingEntry) || empty($existingEntry['mfa_data'])) continue;
            try {
                $existingMfa=dmd_genpw_mfa_decrypt_config($email,(string)$existingId,$existingEntry);
                if (!is_array($existingMfa) || !in_array((string)($existingMfa['method']??''),array('totp','hotp'),true)) continue;
                $fp=hash('sha256',strtolower((string)$existingMfa['method'])."\0".strtoupper(preg_replace('/\s+/','',(string)($existingMfa['secret']??'')))."\0".strtolower((string)($existingMfa['issuer']??''))."\0".strtolower((string)($existingMfa['account']??'')));
                $existing[$fp]=true;
            } catch (Throwable $e) {}
        }

        $imported=0;$duplicates=0;$invalid=0;$resources=array();
        foreach ($items as $raw) {
            if (!is_array($raw)) { $invalid++; continue; }
            try {
                $config=dmd_genpw_mfa_clean_config($raw,null);
                if (!is_array($config) || !in_array((string)$config['method'],array('totp','hotp'),true)) { $invalid++; continue; }
                $fp=hash('sha256',strtolower((string)$config['method'])."\0".strtoupper(preg_replace('/\s+/','',(string)$config['secret']))."\0".strtolower((string)$config['issuer'])."\0".strtolower((string)$config['account']));
                if ($skipExisting && isset($existing[$fp])) { $duplicates++; continue; }

                $issuer=dmd_genpw_clean((string)$config['issuer'],120);
                $account=dmd_genpw_clean((string)$config['account'],255);
                $name=$issuer!==''?$issuer:($account!==''?$account:'Compte MFA');
                if ($issuer!=='' && $account!=='' && strcasecmp($issuer,$account)!==0) $name=$issuer.' · '.$account;
                $name=dmd_genpw_clean($name,120);
                if ($name==='') $name='Compte MFA';

                do{$id=bin2hex(random_bytes(8));}while(isset($owned[$id]));
                $enc=dmd_genpw_encrypt('',$key,dmd_genpw_aad($email,$id));
                $mfaCategory=in_array('Application',dmd_genpw_categories($email),true)?'Application':dmd_genpw_fallback_category($email);
                $entry=array_merge(array(
                    'name'=>$name,
                    'cat'=>$mfaCategory,
                    'url'=>'',
                    'user'=>$account,
                    'notes'=>'Import MFA · '.$sourceLabel,
                    'mfa_only'=>true,
                    'created_at'=>date(DATE_ATOM),
                    'updated_at'=>date(DATE_ATOM),
                    'date'=>date('d/m/Y H:i'),
                    'imported_from'=>$sourceLabel
                ),$enc,dmd_genpw_mfa_encrypt_config($email,$id,$config));
                $entry['mfa_method']=$config['method'];
                $owned[$id]=$entry;
                $existing[$fp]=true;
                $imported++;
                if (count($resources)<20) $resources[]=dmd_genpw_resource($id,$name,$email);
            } catch (Throwable $e) { $invalid++; }
        }
        if ($imported>0) dmd_genpw_write_json($ownedFile,$owned);
        dmd_genpw_log('vault.mfa.import','vault','success',array('source'=>$sourceLabel,'imported'=>$imported,'duplicates'=>$duplicates,'invalid'=>$invalid),dmd_genpw_vault_resource($email));
        dmd_genpw_reply(array('ok'=>true,'source'=>$sourceLabel,'imported'=>$imported,'duplicates'=>$duplicates,'invalid'=>$invalid,'resources'=>$resources));
    }
    if ($action==='system_mfa_import') {
        dmd_genpw_boot_core();
        if (!function_exists('dmd_mfa_read') || !function_exists('dmd_mfa_decrypt_secret')) {
            throw new RuntimeException('Le moteur MFA DoMyDesk n’est pas disponible.');
        }
        $systemMfa=dmd_mfa_read($email);
        if (empty($systemMfa['enabled']) || empty($systemMfa['secret_enc'])) {
            throw new RuntimeException('Aucun MFA DoMyDesk actif sur ce compte.');
        }
        $systemSecret=dmd_mfa_decrypt_secret((string)$systemMfa['secret_enc']);
        if (!is_string($systemSecret) || trim($systemSecret)==='') {
            throw new RuntimeException('Impossible de lire le secret MFA DoMyDesk.');
        }
        $mfa=array(
            'method'=>'totp',
            'secret'=>$systemSecret,
            'encoding'=>'base32',
            'algorithm'=>'SHA1',
            'digits'=>6,
            'period'=>30,
            'counter'=>0,
            'issuer'=>'DoMyDesk',
            'account'=>$email,
            'recovery_codes'=>'',
            'notes'=>'MFA DoMyDesk'
        );
        dmd_genpw_log('credential.mfa.import_domydesk','mfa','success',array('source'=>'DoMyDesk'));
        dmd_genpw_reply(array('ok'=>true,'mfa'=>$mfa));
    }
    if ($action==='mfa_get') {
        dmd_genpw_mfa_repair_legacy_store($email);
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); $kind=(isset($input['kind'])&&$input['kind']==='shared')?'shared':'owned';
        if ($id===null) throw new InvalidArgumentException('Identifiant invalide.');
        $file=''; $store=dmd_genpw_store_for_kind($email,$kind,$file);
        if (!isset($store[$id]) || !is_array($store[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        $config=dmd_genpw_mfa_decrypt_config($email,$id,$store[$id]);
        dmd_genpw_log('credential.mfa.view',$id,'success',array('kind'=>$kind,'configured'=>is_array($config)),dmd_genpw_resource($id,(string)($store[$id]['name']??'Identifiant'),$kind==='shared'?(string)($store[$id]['owner']??''):$email));
        dmd_genpw_reply(array('ok'=>true,'configured'=>is_array($config),'mfa'=>$config,'read_only'=>$kind==='shared'));
    }
    if ($action==='mfa_save') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null);
        if ($id===null || !isset($owned[$id]) || !is_array($owned[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        $existing=dmd_genpw_mfa_decrypt_config($email,$id,$owned[$id]);
        $config=dmd_genpw_mfa_clean_config(isset($input['mfa'])?$input['mfa']:array(),$existing);
        if (!is_array($config)) throw new InvalidArgumentException('Choisissez une méthode 2FA ou utilisez Supprimer la 2FA.');
        /* Validation forte avant écriture : une fiche TOTP/HOTP n'est marquée
           configurée que si GenPW sait réellement produire un code avec la clé. */
        if (in_array((string)($config['method']??''),array('totp','hotp'),true)) {
            $probe=dmd_genpw_mfa_generate_code($config);
            if (empty($probe['code']) || !preg_match('/^[0-9]{6,10}$/',(string)$probe['code'])) throw new InvalidArgumentException('Configuration MFA invalide : aucun code OTP valide ne peut être généré.');
        }
        dmd_genpw_mfa_clear_entry_fields($owned[$id]);
        $owned[$id]=array_merge($owned[$id],dmd_genpw_mfa_encrypt_config($email,$id,$config));
        $owned[$id]['mfa_method']=$config['method']; $owned[$id]['updated_at']=date(DATE_ATOM); $owned[$id]['date']=date('d/m/Y H:i');
        dmd_genpw_write_json($ownedFile,$owned);
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email); $secret=dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile);
        $synced=dmd_genpw_sync_shares($email,$id,$owned[$id],$secret);
        dmd_genpw_log('credential.mfa.update',$id,'success',array('method'=>$config['method'],'shared_updated'=>$synced),dmd_genpw_resource($id,(string)$owned[$id]['name'],$email));
        dmd_genpw_reply(array('ok'=>true,'configured'=>true,'method'=>$config['method'],'shared_updated'=>$synced));
    }
    if ($action==='mfa_clear') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null);
        if ($id===null || !isset($owned[$id]) || !is_array($owned[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        dmd_genpw_mfa_clear_entry_fields($owned[$id]); $owned[$id]['updated_at']=date(DATE_ATOM); $owned[$id]['date']=date('d/m/Y H:i');
        dmd_genpw_write_json($ownedFile,$owned);
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email); $secret=dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile);
        $synced=dmd_genpw_sync_shares($email,$id,$owned[$id],$secret);
        dmd_genpw_log('credential.mfa.clear',$id,'success',array('shared_updated'=>$synced),dmd_genpw_resource($id,(string)$owned[$id]['name'],$email));
        dmd_genpw_reply(array('ok'=>true,'configured'=>false,'shared_updated'=>$synced));
    }
    if ($action==='mfa_code') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); $kind=(isset($input['kind'])&&$input['kind']==='shared')?'shared':'owned';
        if ($id===null) throw new InvalidArgumentException('Identifiant invalide.');
        $file=''; $store=dmd_genpw_store_for_kind($email,$kind,$file);
        if (!isset($store[$id]) || !is_array($store[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        $config=dmd_genpw_mfa_decrypt_config($email,$id,$store[$id]); $result=dmd_genpw_mfa_generate_code($config);
        if ($result['method']==='hotp' && !empty($input['advance'])) {
            $config['counter']=(int)$result['counter']+1; dmd_genpw_mfa_clear_entry_fields($store[$id]);
            $store[$id]=array_merge($store[$id],dmd_genpw_mfa_encrypt_config($email,$id,$config)); $store[$id]['mfa_method']='hotp';
            dmd_genpw_write_json($file,$store); $result['next_counter']=$config['counter'];
        }
        dmd_genpw_log('credential.mfa.code',$id,'success',array('kind'=>$kind,'method'=>$result['method']),dmd_genpw_resource($id,(string)($store[$id]['name']??'Identifiant'),$kind==='shared'?(string)($store[$id]['owner']??''):$email));
        dmd_genpw_reply(array_merge(array('ok'=>true),$result));
    }
    if ($action==='get_secret') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); $kind=(isset($input['kind'])&&$input['kind']==='shared')?'shared':'owned'; if($id===null) throw new InvalidArgumentException('Identifiant invalide.');
        $entry=array(); $secret=dmd_genpw_decrypt_by_kind($email,$id,$kind,$entry); dmd_genpw_log('credential.reveal',$id,'success',array('kind'=>$kind),dmd_genpw_resource($id,(string)(isset($entry['name'])?$entry['name']:'Identifiant'),$kind==='shared'?(string)(isset($entry['owner'])?$entry['owner']:''):$email));
        dmd_genpw_reply(array('ok'=>true,'secret'=>$secret));
    }
    if ($action==='get_qr') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); $kind=(isset($input['kind'])&&$input['kind']==='shared')?'shared':'owned'; if($id===null) throw new InvalidArgumentException('Identifiant invalide.');
        $entry=array(); $secret=dmd_genpw_decrypt_by_kind($email,$id,$kind,$entry); $payload=$secret;
        if ((isset($entry['cat'])?$entry['cat']:'')==='Wi-Fi') { $ssid=dmd_genpw_clean(!empty($entry['user'])?$entry['user']:(isset($entry['name'])?$entry['name']:''),255); $esc=function($s){return str_replace(array('\\',';',',',':','"'),array('\\\\','\\;','\\,','\\:','\\"'),$s);}; $payload='WIFI:T:WPA;S:'.$esc($ssid).';P:'.$esc($secret).';;'; }
        $tokens=is_array(isset($_SESSION['dmd_genpw_qr_tokens'])?$_SESSION['dmd_genpw_qr_tokens']:null)?$_SESSION['dmd_genpw_qr_tokens']:array(); $now=time(); foreach($tokens as $t=>$v) if(!is_array($v)||(int)(isset($v['exp'])?$v['exp']:0)<=$now) unset($tokens[$t]); while(count($tokens)>=5) array_shift($tokens);
        $token=bin2hex(random_bytes(24)); $tokens[$token]=array('payload'=>$payload,'exp'=>$now+60); $_SESSION['dmd_genpw_qr_tokens']=$tokens; dmd_genpw_log('credential.qr',$id,'success',array('kind'=>$kind),dmd_genpw_resource($id,(string)(isset($entry['name'])?$entry['name']:'Identifiant'),$email));
        dmd_genpw_reply(array('ok'=>true,'token'=>$token,'expires_in'=>60));
    }
    if ($action==='shared_update') {
        $shareId=dmd_genpw_valid_id($input['id']??null); if($shareId===null)throw new InvalidArgumentException('Partage invalide.');
        $shared=dmd_genpw_read_json($sharedFile,array());
        if(!isset($shared[$shareId])||!is_array($shared[$shareId]))throw new OutOfBoundsException('Partage introuvable.');
        $share=$shared[$shareId];
        if((string)($share['share_mode']??'read')!=='write')throw new InvalidArgumentException('Partage en lecture seule.');
        $exp=(string)($share['share_expires_at']??''); if($exp!==''&&strtotime($exp)!==false&&strtotime($exp)<time())throw new InvalidArgumentException('Partage expiré.');
        $owner=(string)($share['owner']??'');$sourceId=dmd_genpw_valid_id($share['source_id']??null);
        if(filter_var($owner,FILTER_VALIDATE_EMAIL)===false||$sourceId===null)throw new RuntimeException('Partage invalide.');
        $ownerFile=dmd_genpw_owned_file($owner);$ownerStore=dmd_genpw_read_json($ownerFile,array());
        if(!isset($ownerStore[$sourceId])||!is_array($ownerStore[$sourceId]))throw new OutOfBoundsException('Entrée source introuvable.');
        dmd_genpw_pro_snapshot($owner,$sourceId,$ownerStore[$sourceId],'shared_write_before_update');
        $v=dmd_genpw_clean_entry_input($input,false);$entry=$ownerStore[$sourceId];
        foreach(array('name','cat','url','user','notes') as $f)$entry[$f]=$v[$f];
        $ownerKey=dmd_genpw_key(dmd_genpw_user_dir($owner),$owner);
        $provided=is_scalar($input['pw']??null)?(string)$input['pw']:'';
        if($provided!==''){
            if(strlen($provided)>4096)throw new InvalidArgumentException('Mot de passe invalide.');
            foreach(array('pw','iv','tag','data','cipher','v') as $f)unset($entry[$f]);
            $entry=array_merge($entry,dmd_genpw_encrypt($provided,$ownerKey,dmd_genpw_aad($owner,$sourceId)));
            dmd_genpw_pro_meta_save($owner,$sourceId,array('last_rotated_at'=>date(DATE_ATOM)));
        }
        if(array_key_exists('extra_fields',$input)){dmd_genpw_extra_clear($entry);$entry=array_merge($entry,dmd_genpw_extra_encrypt($owner,$sourceId,$input['extra_fields']));}
        $entry['updated_at']=date(DATE_ATOM);$entry['date']=date('d/m/Y H:i');
        $ownerStore[$sourceId]=$entry;dmd_genpw_write_json($ownerFile,$ownerStore);
        $secret=$provided!==''?$provided:dmd_genpw_decrypt_entry($ownerStore,$sourceId,$ownerKey,$owner,$ownerFile);
        dmd_genpw_sync_shares($owner,$sourceId,$entry,$secret);
        dmd_genpw_log('credential.shared.update',$sourceId,'success',array('recipient'=>$email),dmd_genpw_resource($sourceId,(string)$entry['name'],$owner));
        dmd_genpw_reply(array('ok'=>true,'id'=>$shareId));
    }
    if ($action==='share_users') dmd_genpw_reply(array('ok'=>true,'users'=>dmd_genpw_available_users($email)));
    if ($action==='public_share_create') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null);
        if($id===null||!isset($owned[$id])||!is_array($owned[$id])) throw new OutOfBoundsException('Entrée introuvable.');

        $duration=strtolower(trim((string)($input['duration']??'1h')));
        $seconds=dmd_genpw_public_share_duration($duration);
        $oneTime=$duration==='once';

        $pin=is_scalar($input['pin']??null)?trim((string)$input['pin']):'';
        if($pin!=='' && !preg_match('/^[0-9]{4,12}$/D',$pin)) throw new InvalidArgumentException('Le PIN doit contenir entre 4 et 12 chiffres.');

        $token=dmd_genpw_public_share_token();
        $shareId=bin2hex(random_bytes(12));
        $now=time();
        $shareKey=dmd_genpw_public_share_key($token,$shareId,$pin);

        /* Snapshot indépendant du coffre original. */
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
        $entry=$owned[$id];
        $password=dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile);
        $extra=dmd_genpw_extra_decrypt($email,$id,$entry);
        $mfa=dmd_genpw_mfa_decrypt_config($email,$id,$entry);

        $attachmentMeta=array();
        foreach(dmd_genpw_pro_attachment_list($email,$id) as $meta){
            if(!is_array($meta)) continue;
            $aid=(string)($meta['id']??'');
            if(!preg_match('/^[a-f0-9]{24}$/D',$aid)) continue;
            $r=dmd_genpw_pro_attachment_get($email,$aid);
            $bytes=(string)($r['bytes']??'');
            $cleanMeta=is_array($r['meta']??null)?$r['meta']:$meta;
            $blobId=bin2hex(random_bytes(12));
            $enc=dmd_genpw_encrypt($bytes,$shareKey,dmd_genpw_public_share_attachment_aad($shareId,$blobId));
            dmd_genpw_write_json(dmd_genpw_public_share_blob_dir($shareId).'/'.$blobId.'.json',$enc);
            $attachmentMeta[]=array(
                'id'=>$blobId,
                'name'=>(string)($cleanMeta['name']??'fichier'),
                'mime'=>(string)($cleanMeta['mime']??'application/octet-stream'),
                'size'=>(int)($cleanMeta['size']??strlen($bytes))
            );
        }

        $snapshot=array(
            'v'=>2,
            'name'=>(string)($entry['name']??''),
            'cat'=>(string)($entry['cat']??''),
            'date'=>(string)($entry['date']??''),
            'user'=>(string)($entry['user']??''),
            'url'=>(string)($entry['url']??''),
            'notes'=>(string)($entry['notes']??''),
            'password'=>(string)$password,
            'extra_fields'=>array_values(is_array($extra)?$extra:array()),
            'mfa'=>is_array($mfa)?$mfa:null,
            'attachments'=>$attachmentMeta,
            'created_at'=>date(DATE_ATOM,$now)
        );
        $snapshotJson=json_encode($snapshot,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        if(!is_string($snapshotJson)) throw new RuntimeException('Impossible de préparer le partage.');
        $snapshotEnc=dmd_genpw_encrypt($snapshotJson,$shareKey,dmd_genpw_public_share_snapshot_aad($shareId));

        $rows=dmd_genpw_public_shares_read();
        $rows[$shareId]=array(
            'v'=>2,
            'id'=>$shareId,
            'token_hash'=>dmd_genpw_public_share_token_hash($token),
            'label'=>(string)($entry['name']??'Entrée'),
            'source_id'=>$id,
            'created_at'=>date(DATE_ATOM,$now),
            'expires_at'=>$oneTime?'':date(DATE_ATOM,$now+$seconds),
            'one_time'=>$oneTime,
            'used_at'=>'',
            'revoked_at'=>'',
            'pin_hash'=>$pin!==''?password_hash($pin,PASSWORD_DEFAULT):'',
            'snapshot'=>$snapshotEnc
        );
        dmd_genpw_public_shares_write($rows);

        dmd_genpw_log('credential.public_share.create',$id,'success',array(
            'share_id'=>$shareId,
            'version'=>2,
            'duration'=>$duration,
            'one_time'=>$oneTime,
            'pin'=>$pin!=='',
            'attachments'=>count($attachmentMeta)
        ),dmd_genpw_resource($id,(string)($entry['name']??'Entrée'),$email));

        $https=!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS'])!=='off';
        $scheme=$https?'https':'http';
        $host=preg_replace('/[^A-Za-z0-9.\-:\[\]]/','',(string)($_SERVER['HTTP_HOST']??''));
        $basePath=rtrim(str_replace('\\','/',dirname((string)($_SERVER['SCRIPT_NAME']??'/'))),'/');
        $shareUrl=$host!=='' ? ($scheme.'://'.$host.$basePath.'/dmd-genpw_public_share.php?id='.rawurlencode($shareId).'#'.rawurlencode($token)) : '';

        dmd_genpw_reply(array(
            'ok'=>true,
            'share_id'=>$shareId,
            'token'=>$token,
            'url'=>$shareUrl,
            'duration'=>$duration,
            'expires_at'=>$rows[$shareId]['expires_at'],
            'one_time'=>$oneTime,
            'encrypted_snapshot'=>true
        ));
    }
    if ($action==='public_shares') {
        $source=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null);
        if($source===null) throw new InvalidArgumentException('Identifiant invalide.');
        $out=array();
        foreach(dmd_genpw_public_shares_read() as $sid=>$row){
            if(!is_array($row)) continue;
            if((string)($row['owner']??'')!==$email || (string)($row['source_id']??'')!==$source) continue;
            $out[]=array(
                'share_id'=>(string)$sid,
                'created_at'=>(string)($row['created_at']??''),
                'expires_at'=>(string)($row['expires_at']??''),
                'one_time'=>!empty($row['one_time']),
                'used_at'=>(string)($row['used_at']??''),
                'revoked_at'=>(string)($row['revoked_at']??''),
                'pin'=>!empty($row['pin_hash']),
                'fields'=>array_values((array)($row['fields']??array()))
            );
        }
        dmd_genpw_reply(array('ok'=>true,'shares'=>$out));
    }
    if ($action==='public_share_revoke') {
        $shareId=dmd_genpw_clean($input['share_id']??'',64);
        $rows=dmd_genpw_public_shares_read();
        if($shareId===''||!isset($rows[$shareId])||!is_array($rows[$shareId])||(string)($rows[$shareId]['owner']??'')!==$email) throw new OutOfBoundsException('Lien de partage introuvable.');
        $source=(string)($rows[$shareId]['source_id']??'');
        $rows[$shareId]['revoked_at']=date(DATE_ATOM);
        dmd_genpw_public_shares_write($rows);
        dmd_genpw_public_share_rm_tree(dmd_genpw_public_share_blob_dir($shareId));
        dmd_genpw_log('credential.public_share.revoke',$source,'success',array('share_id'=>$shareId),isset($owned[$source])?dmd_genpw_resource($source,(string)($owned[$source]['name']??'Entrée'),$email):null);
        dmd_genpw_reply(array('ok'=>true));
    }
    if ($action==='share') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); if($id===null||!isset($owned[$id])||!is_array($owned[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        $recipients=isset($input['recipients'])?$input['recipients']:array(); if(!is_array($recipients)) $recipients=array($recipients); $recipients=array_values(array_unique(array_filter(array_map('strval',$recipients))));
        $shareMode=((string)($input['mode']??'read')==='write')?'write':'read';
        $minutes=max(0,min(525600,(int)($input['expires_minutes']??0)));
        $shareExpiresAt=$minutes>0?date(DATE_ATOM,time()+$minutes*60):'';
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email); $secret=dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile); $entry=$owned[$id]; $index=dmd_genpw_share_index(); $done=array();
        foreach($recipients as $recipient) {
            if($recipient===$email||filter_var($recipient,FILTER_VALIDATE_EMAIL)===false) continue;
            dmd_genpw_profile_dir($recipient);
            if (!dmd_genpw_user_has_permission($recipient, 'module.view')) continue;
            $existing=''; foreach($index as $sid=>$row) if(is_array($row)&&(isset($row['owner'])?$row['owner']:'')===$email&&(isset($row['source_id'])?$row['source_id']:'')===$id&&(isset($row['recipient'])?$row['recipient']:'')===$recipient){$existing=$sid;break;}
            $shareId=$existing!==''?$existing:bin2hex(random_bytes(8)); $file=dmd_genpw_shared_file($recipient); $shared=dmd_genpw_read_json($file,array()); $recipientKey=dmd_genpw_key(dmd_genpw_user_dir($recipient),$recipient); $enc=dmd_genpw_encrypt($secret,$recipientKey,dmd_genpw_aad($recipient,$shareId));
            $shared[$shareId]=array_merge(array('name'=>$entry['name'],'cat'=>$entry['cat'],'url'=>$entry['url'],'user'=>$entry['user'],'notes'=>isset($entry['notes'])?$entry['notes']:'','date'=>date('d/m/Y H:i'),'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM),'owner'=>$email,'source_id'=>$id,'shared_at'=>date(DATE_ATOM),'share_mode'=>$shareMode,'share_expires_at'=>$shareExpiresAt),$enc);
            dmd_genpw_mfa_copy_to_recipient($email,$id,$entry,$recipient,$shareId,$shared[$shareId]);
            dmd_genpw_write_json($file,$shared); $index[$shareId]=array('owner'=>$email,'recipient'=>$recipient,'source_id'=>$id,'recipient_id'=>$shareId,'label'=>$entry['name'],'created_at'=>isset($index[$shareId]['created_at'])?$index[$shareId]['created_at']:date(DATE_ATOM),'updated_at'=>date(DATE_ATOM),'mode'=>$shareMode,'expires_at'=>$shareExpiresAt); $done[]=$recipient;
            $en = strpos(strtolower(dmd_genpw_language()), 'en') === 0;
            dmd_genpw_notify($recipient,'credential_shared',$en ? 'New shared access' : 'Nouvel accès partagé',(string)$entry['name'].($en ? ' was shared with you by ' : ' a été partagé avec vous par ').$email.'.',array('source_id'=>$id,'share_id'=>$shareId));
        }
        dmd_genpw_write_share_index($index); $r=dmd_genpw_resource($id,(string)$entry['name'],$email); $activity=dmd_genpw_log('credential.share',$id,'success',array('recipients'=>$done),$r); dmd_genpw_reply(array('ok'=>true,'shared_with'=>$done,'activity'=>$activity));
    }
    if ($action==='shares') {
        $source=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); if($source===null) throw new InvalidArgumentException('Identifiant invalide.'); $rows=array();
        foreach(dmd_genpw_share_rows_for_source($email,$source) as $row) $rows[]=array('share_id'=>$row['share_id'],'recipient'=>$row['recipient'],'created_at'=>isset($row['created_at'])?$row['created_at']:'','updated_at'=>isset($row['updated_at'])?$row['updated_at']:'','mode'=>(string)($row['mode']??'read'),'expires_at'=>(string)($row['expires_at']??'')); dmd_genpw_reply(array('ok'=>true,'shares'=>$rows));
    }
    if ($action==='revoke_share') {
        $shareId=dmd_genpw_valid_id(isset($input['share_id'])?$input['share_id']:null); if($shareId===null) throw new InvalidArgumentException('Partage invalide.'); $idx=dmd_genpw_share_index(); if(!isset($idx[$shareId])||!is_array($idx[$shareId])||(isset($idx[$shareId]['owner'])?$idx[$shareId]['owner']:'')!==$email) throw new OutOfBoundsException('Partage introuvable.'); $source=(string)$idx[$shareId]['source_id']; $recipient=(string)$idx[$shareId]['recipient']; dmd_genpw_revoke_share_row($shareId,true); dmd_genpw_log('credential.share.revoke',$source,'success',array('recipient'=>$recipient),isset($owned[$source])?dmd_genpw_resource($source,(string)$owned[$source]['name'],$email):null); dmd_genpw_reply(array('ok'=>true));
    }
    if ($action==='delete') {
        $ids=isset($input['ids'])?$input['ids']:array(); if(!is_array($ids))$ids=array($ids);
        if(count($ids)>1 && !dmd_genpw_pro_sensitive_ok($email) && !empty(dmd_genpw_pro_settings($email)['sensitive_reauth'])) throw new InvalidArgumentException('Ré-authentification MFA requise pour une suppression multiple.');
        $deleted=0;$revoked=0;
        foreach(array_unique($ids) as $candidate){
            $id=dmd_genpw_valid_id($candidate);
            if($id!==null&&isset($owned[$id])&&is_array($owned[$id])){
                $label=(string)($owned[$id]['name']??'Identifiant');
                dmd_genpw_pro_snapshot($email,$id,$owned[$id],'before_trash');
                dmd_genpw_pro_trash_move($email,$id,$owned[$id]);
                $revoked+=dmd_genpw_revoke_source_shares($email,$id,$label);
                unset($owned[$id]);$deleted++;
                dmd_genpw_log('credential.trash',$id,'success',array('shares_revoked'=>$revoked),dmd_genpw_resource($id,$label,$email));
            }
        }
        if($deleted)dmd_genpw_write_json($ownedFile,$owned);
        dmd_genpw_reply(array('ok'=>true,'deleted'=>$deleted,'trashed'=>$deleted,'shares_revoked'=>$revoked));
    }
    if ($action==='export') {
        $format=(isset($input['format'])&&$input['format']==='csv')?'csv':'json'; $include=!empty($input['include_secrets']); if($include){dmd_genpw_require_permission('vault.export.secrets'); if(!dmd_genpw_pro_sensitive_ok($email) && !empty(dmd_genpw_pro_settings($email)['sensitive_reauth'])) throw new InvalidArgumentException('Ré-authentification MFA requise.');}
        $rows=array(); foreach(dmd_genpw_list_entries($email) as $item){$row=$item;if($include){$entry=array();$row['secret']=dmd_genpw_decrypt_by_kind($email,$item['id'],$item['kind'],$entry);$row['mfa']=dmd_genpw_mfa_decrypt_config($email,$item['id'],$entry);} $rows[]=$row;}
        dmd_genpw_log('vault.export','vault','success',array('format'=>$format,'include_secrets'=>$include,'count'=>count($rows)),dmd_genpw_vault_resource($email));
        if($format==='json'){$content=json_encode($rows,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$mime='application/json';$name='DMD-GenPW-'.date('Ymd-His').'.json';}
        else{$fp=fopen('php://temp','r+');$headers=array('name','category','url','user','notes','kind','owner','date');if($include){$headers[]='secret';$headers[]='mfa_json';}fputcsv($fp,$headers,';');foreach($rows as $r){$line=array($r['name'],$r['cat'],$r['url'],$r['user'],$r['notes'],$r['kind'],$r['owner'],$r['date']);if($include){$line[]=$r['secret'];$line[]=json_encode($r['mfa']??null,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}fputcsv($fp,$line,';');}rewind($fp);$content=stream_get_contents($fp);fclose($fp);$mime='text/csv';$name='DMD-GenPW-'.date('Ymd-His').'.csv';}
        dmd_genpw_reply(array('ok'=>true,'filename'=>$name,'mime'=>$mime,'content'=>base64_encode((string)$content)));
    }
    if ($action==='logs') dmd_genpw_reply(array('ok'=>true,'items'=>dmd_genpw_recent_logs($email,isset($input['limit'])?(int)$input['limit']:200)));
    if ($action==='logs_export') { $rows=dmd_genpw_recent_logs($email,500); dmd_genpw_reply(array('ok'=>true,'filename'=>'DMD-GenPW-logs-'.date('Ymd-His').'.json','mime'=>'application/json','content'=>base64_encode((string)json_encode($rows,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)))); }
    if ($action==='logs_delete') {
        $n=dmd_genpw_clear_logs($email);
        dmd_genpw_boot_core();
        if (function_exists('dmd_system_log')) {
            try { dmd_system_log('module_logs_deleted', DMD_GENPW_ID, 'success', 'Journal utilisateur DMD-GenPW supprimé.', array('user'=>$email,'removed'=>$n)); } catch (Throwable $e) {}
        }
        dmd_genpw_reply(array('ok'=>true,'removed'=>$n));
    }
} catch (InvalidArgumentException $e) { dmd_genpw_reply(array('ok'=>false,'error'=>$e->getMessage()),400); }
catch (OutOfBoundsException $e) { dmd_genpw_reply(array('ok'=>false,'error'=>$e->getMessage()),404); }
catch (Throwable $e) { error_log('[DMD-GenPW] '.$e->getMessage()); dmd_genpw_reply(array('ok'=>false,'error'=>'Erreur interne DMD-GenPW'),500); }
