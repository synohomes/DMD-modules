<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-genpw_crypto.php';

function dmd_genpw_input() {
    $ct = strtolower((string)(isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : ''));
    if (strpos($ct, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $data = json_decode(is_string($raw) ? $raw : '', true);
        return is_array($data) ? $data : array();
    }
    return $_POST;
}

function dmd_genpw_check_csrf() {
    $session = dmd_genpw_csrf();
    $header = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? (string)$_SERVER['HTTP_X_CSRF_TOKEN'] : '';
    if ($header === '' || !hash_equals($session, $header)) dmd_genpw_reply(array('ok'=>false,'error'=>'Jeton de sécurité invalide'), 403);
}

function dmd_genpw_owned_file($email) { return dmd_genpw_user_dir($email) . '/pw.json'; }
function dmd_genpw_shared_file($email) { return dmd_genpw_user_dir($email) . '/shared.json'; }

function dmd_genpw_public_entry($id, $entry, $kind) {
    return array(
        'id'=>$id,
        'kind'=>$kind,
        'name'=>dmd_genpw_clean(isset($entry['name']) ? $entry['name'] : 'Sans nom',120),
        'cat'=>dmd_genpw_clean(isset($entry['cat']) ? $entry['cat'] : 'Autre',40),
        'date'=>dmd_genpw_clean(isset($entry['date']) ? $entry['date'] : '',40),
        'url'=>dmd_genpw_clean(isset($entry['url']) ? $entry['url'] : '',2048),
        'user'=>dmd_genpw_clean(isset($entry['user']) ? $entry['user'] : '',255),
        'notes'=>dmd_genpw_clean(isset($entry['notes']) ? $entry['notes'] : '',2000),
        'owner'=>dmd_genpw_clean(isset($entry['owner']) ? $entry['owner'] : '',255),
        'source_id'=>dmd_genpw_clean(isset($entry['source_id']) ? $entry['source_id'] : '',64),
        'shared_at'=>dmd_genpw_clean(isset($entry['shared_at']) ? $entry['shared_at'] : '',80),
        'read_only'=>$kind === 'shared'
    );
}

function dmd_genpw_validate_url($url) {
    if ($url === '') return '';
    $valid = filter_var($url, FILTER_VALIDATE_URL);
    $scheme = is_string($valid) ? strtolower((string)parse_url($valid, PHP_URL_SCHEME)) : '';
    if ($valid === false || !in_array($scheme, array('http','https'), true)) throw new InvalidArgumentException('L’URL doit commencer par http:// ou https://');
    return $url;
}

function dmd_genpw_clean_entry_input($input, $includeSecret) {
    $name = dmd_genpw_clean(isset($input['name']) ? $input['name'] : '',120);
    $cat = dmd_genpw_clean(isset($input['cat']) ? $input['cat'] : 'Autre',40);
    $url = dmd_genpw_validate_url(dmd_genpw_clean(isset($input['url']) ? $input['url'] : '',2048));
    $user = dmd_genpw_clean(isset($input['user']) ? $input['user'] : '',255);
    $notes = dmd_genpw_clean(isset($input['notes']) ? $input['notes'] : '',2000);
    if ($name === '') $name = 'Sans nom';
    if (!in_array($cat, dmd_genpw_categories(), true)) $cat = 'Autre';
    $out = array('name'=>$name,'cat'=>$cat,'url'=>$url,'user'=>$user,'notes'=>$notes);
    if ($includeSecret) {
        $secret = is_scalar(isset($input['pw']) ? $input['pw'] : null) ? (string)$input['pw'] : '';
        if ($secret === '' || strlen($secret) > 4096) throw new InvalidArgumentException('Le mot de passe à enregistrer est invalide.');
        $out['pw'] = $secret;
    }
    return $out;
}

function dmd_genpw_list_entries($email) {
    $items = array();
    foreach (array('owned'=>dmd_genpw_read_json(dmd_genpw_owned_file($email), array()), 'shared'=>dmd_genpw_read_json(dmd_genpw_shared_file($email), array())) as $kind=>$store) {
        foreach ($store as $id=>$entry) {
            if (dmd_genpw_valid_id($id) === null || !is_array($entry)) continue;
            $items[] = dmd_genpw_public_entry($id,$entry,$kind);
        }
    }
    usort($items, function($a,$b){ $c = strcasecmp($a['cat'],$b['cat']); return $c !== 0 ? $c : strcasecmp($a['name'],$b['name']); });
    return $items;
}

function dmd_genpw_store_for_kind($email, $kind, &$file) {
    $file = $kind === 'shared' ? dmd_genpw_shared_file($email) : dmd_genpw_owned_file($email);
    return dmd_genpw_read_json($file, array());
}

function dmd_genpw_decrypt_by_kind($email, $id, $kind, &$entry) {
    $file = '';
    $store = dmd_genpw_store_for_kind($email,$kind,$file);
    if (!isset($store[$id]) || !is_array($store[$id])) throw new OutOfBoundsException('Entrée introuvable.');
    $entry = $store[$id];
    $key = dmd_genpw_key(dmd_genpw_user_dir($email), $email);
    return dmd_genpw_decrypt_entry($store,$id,$key,$email,$file);
}

function dmd_genpw_share_rows_for_source($owner, $sourceId) {
    $index = dmd_genpw_share_index(); $rows = array();
    foreach ($index as $shareId=>$row) if (is_array($row) && (isset($row['owner']) ? $row['owner'] : '') === $owner && (isset($row['source_id']) ? $row['source_id'] : '') === $sourceId) { $row['share_id']=$shareId; $rows[]=$row; }
    return $rows;
}

function dmd_genpw_sync_shares($owner, $sourceId, $entry, $secret) {
    $index = dmd_genpw_share_index(); $updated = 0; $changedIndex = false;
    foreach ($index as $shareId=>&$row) {
        if (!is_array($row) || (isset($row['owner']) ? $row['owner'] : '') !== $owner || (isset($row['source_id']) ? $row['source_id'] : '') !== $sourceId) continue;
        $recipient = isset($row['recipient']) ? (string)$row['recipient'] : '';
        if (filter_var($recipient,FILTER_VALIDATE_EMAIL) === false) continue;
        try {
            $file = dmd_genpw_shared_file($recipient); $shared = dmd_genpw_read_json($file,array());
            if (!isset($shared[$shareId]) || !is_array($shared[$shareId])) continue;
            $key = dmd_genpw_key(dmd_genpw_user_dir($recipient),$recipient);
            $encrypted = dmd_genpw_encrypt($secret,$key,dmd_genpw_aad($recipient,$shareId));
            $base = $shared[$shareId];
            foreach (array('pw','iv','tag','data','cipher','v') as $f) unset($base[$f]);
            $shared[$shareId] = array_merge($base,array(
                'name'=>$entry['name'],'cat'=>$entry['cat'],'url'=>$entry['url'],'user'=>$entry['user'],'notes'=>$entry['notes'],
                'date'=>date('d/m/Y H:i'),'updated_at'=>date(DATE_ATOM)
            ),$encrypted);
            dmd_genpw_write_json($file,$shared);
            $row['updated_at']=date(DATE_ATOM); $changedIndex=true; $updated++;
            $en = strpos(strtolower(dmd_genpw_language()), 'en') === 0;
            dmd_genpw_notify($recipient,'credential_share_updated',$en ? 'Shared access updated' : 'Accès partagé mis à jour',(string)$entry['name'] . ($en ? ' was updated by ' : ' a été mis à jour par ') . $owner . '.',array('source_id'=>$sourceId,'share_id'=>$shareId));
        } catch (Throwable $e) { dmd_genpw_log('credential.share.sync',$sourceId,'error',array('recipient'=>$recipient,'message'=>$e->getMessage()),dmd_genpw_resource($sourceId,(string)$entry['name'],$owner)); }
    }
    unset($row);
    if ($changedIndex) dmd_genpw_write_share_index($index);
    return $updated;
}

function dmd_genpw_revoke_share_row($shareId, $notify) {
    $index = dmd_genpw_share_index();
    if (!isset($index[$shareId]) || !is_array($index[$shareId])) return false;
    $row = $index[$shareId]; $recipient = isset($row['recipient']) ? (string)$row['recipient'] : '';
    if (filter_var($recipient,FILTER_VALIDATE_EMAIL) !== false) {
        try { $file=dmd_genpw_shared_file($recipient); $shared=dmd_genpw_read_json($file,array()); unset($shared[$shareId]); dmd_genpw_write_json($file,$shared); } catch (Throwable $e) {}
        if ($notify) {
            $en = strpos(strtolower(dmd_genpw_language()), 'en') === 0;
            dmd_genpw_notify($recipient,'credential_share_revoked',$en ? 'Share revoked' : 'Partage retiré',(isset($row['label']) ? $row['label'] : ($en ? 'An access' : 'Un accès')) . ($en ? ' is no longer shared with you.' : ' n’est plus partagé avec vous.'),array('source_id'=>isset($row['source_id'])?$row['source_id']:'','share_id'=>$shareId));
        }
    }
    unset($index[$shareId]); dmd_genpw_write_share_index($index); return true;
}

function dmd_genpw_revoke_source_shares($owner,$sourceId,$label) {
    $index=dmd_genpw_share_index(); $ids=array();
    foreach ($index as $shareId=>$row) if (is_array($row) && (isset($row['owner'])?$row['owner']:'')===$owner && (isset($row['source_id'])?$row['source_id']:'')===$sourceId) $ids[]=$shareId;
    $count=0; foreach ($ids as $shareId) if (dmd_genpw_revoke_share_row($shareId,true)) $count++;
    return $count;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') dmd_genpw_reply(array('ok'=>false,'error'=>'Méthode refusée'),405);
if (!dmd_genpw_logged_in()) dmd_genpw_reply(array('ok'=>false,'error'=>'Utilisateur non connecté'),401);
dmd_genpw_check_csrf();
$input=dmd_genpw_input();
$action=dmd_genpw_clean(isset($input['action'])?$input['action']:'',50);
if ($action==='') dmd_genpw_reply(array('ok'=>false,'error'=>'Action manquante'),400);
$email=dmd_genpw_email();

$permissionMap=array(
    'bootstrap'=>'module.view','status'=>'module.view','unlock'=>'vault.unlock','lock'=>'vault.unlock','list'=>'vault.list','add'=>'vault.create','update'=>'vault.edit',
    'get_secret'=>'vault.reveal','get_qr'=>'vault.qr','delete'=>'vault.delete','share_users'=>'vault.share','share'=>'vault.share','shares'=>'vault.share','revoke_share'=>'vault.revoke',
    'export'=>'vault.export','logs'=>'logs.view','logs_export'=>'logs.export','logs_delete'=>'logs.delete','config_get'=>'config.view','config_save'=>'config.edit','mydesk_mode_get'=>'module.view','mydesk_mode_save'=>'module.view','web_session'=>'vault.list','web_target'=>'vault.list'
);
if (!isset($permissionMap[$action])) dmd_genpw_reply(array('ok'=>false,'error'=>'Action inconnue'),400);
dmd_genpw_require_permission($permissionMap[$action]);

try {
    if ($action==='bootstrap') {
        $perms=array(); foreach (array_values(array_unique($permissionMap)) as $p) $perms[$p]=dmd_genpw_has_permission($p);
        dmd_genpw_reply(array('ok'=>true,'language'=>dmd_genpw_language(),'strings'=>dmd_genpw_strings(),'categories'=>dmd_genpw_categories(),'config'=>dmd_genpw_config($email),'unlocked'=>dmd_genpw_is_unlocked($email),'permissions'=>$perms,'csrf'=>dmd_genpw_csrf()));
    }
    if ($action==='status') dmd_genpw_reply(array('ok'=>true,'unlocked'=>dmd_genpw_is_unlocked($email),'expires_in'=>dmd_genpw_is_unlocked($email)?max(0,dmd_genpw_unlock_timeout($email)-(time()-(int)$_SESSION['dmd_genpw_unlocked_at'])):0));
    if ($action==='mydesk_mode_get') dmd_genpw_reply(array('ok'=>true,'mode'=>dmd_genpw_mydesk_mode($email)));
    if ($action==='mydesk_mode_save') { $mode=dmd_genpw_set_mydesk_mode($email,isset($input['mode'])?$input['mode']:'compact'); dmd_genpw_reply(array('ok'=>true,'mode'=>$mode)); }
    if ($action==='unlock') {
        $blocked=(int)(isset($_SESSION['dmd_genpw_unlock_blocked_until'])?$_SESSION['dmd_genpw_unlock_blocked_until']:0);
        if ($blocked>time()) dmd_genpw_reply(array('ok'=>false,'error'=>'Trop de tentatives. Réessayez dans quelques minutes.','retry_after'=>$blocked-time()),429);

        $requireMfa=dmd_genpw_requires_system_mfa($email);
        if ($requireMfa && !dmd_genpw_system_mfa_enabled($email)) {
            dmd_genpw_reply(array('ok'=>false,'error'=>'Le MFA DoMyDesk est requis par DMD-GenPW mais il est désactivé sur votre compte. Réactivez-le dans votre profil ou désactivez cette option dans le CFG DMD-GenPW.'),409);
        }

        $authOk=false;
        $authMode=$requireMfa?'mfa':'password';
        if ($requireMfa) {
            $mfaCode=is_scalar(isset($input['mfa_code'])?$input['mfa_code']:null)?(string)$input['mfa_code']:'';
            $authOk=dmd_genpw_verify_system_mfa($email,$mfaCode);
        } else {
            $pwd=is_scalar(isset($input['pwd'])?$input['pwd']:null)?(string)$input['pwd']:'';
            if ($pwd==='' || strlen($pwd)>4096) dmd_genpw_reply(array('ok'=>false,'error'=>'Mot de passe invalide'),400);
            $authOk=dmd_genpw_verify_unlock_password($email,$pwd);
        }

        if ($authOk) {
            session_regenerate_id(true); $_SESSION['dmd_genpw_unlocked_at']=time(); unset($_SESSION['dmd_genpw_unlock_failures'],$_SESSION['dmd_genpw_unlock_blocked_until'],$_SESSION['dmd_genpw_qr_tokens']); dmd_genpw_web_sessions_revoke_user($email);
            dmd_genpw_log('vault.unlock','vault','success',array('system_mfa'=>$requireMfa,'unlock_method'=>$authMode),dmd_genpw_vault_resource($email));
            dmd_genpw_reply(array('ok'=>true,'expires_in'=>dmd_genpw_unlock_timeout($email),'system_mfa'=>$requireMfa,'unlock_method'=>$authMode));
        }
        $fails=(int)(isset($_SESSION['dmd_genpw_unlock_failures'])?$_SESSION['dmd_genpw_unlock_failures']:0)+1; $_SESSION['dmd_genpw_unlock_failures']=$fails;
        if ($fails>=DMD_GENPW_MAX_UNLOCK_FAILURES) { $_SESSION['dmd_genpw_unlock_blocked_until']=time()+DMD_GENPW_BLOCK_SECONDS; $_SESSION['dmd_genpw_unlock_failures']=0; }
        usleep(300000); dmd_genpw_log('vault.unlock','vault','denied',array('system_mfa'=>$requireMfa,'unlock_method'=>$authMode)); dmd_genpw_reply(array('ok'=>false,'error'=>$requireMfa?'Code MFA incorrect.':'Mot de passe incorrect'),401);
    }
    if ($action==='lock') { unset($_SESSION['dmd_genpw_unlocked_at'],$_SESSION['dmd_genpw_qr_tokens']); dmd_genpw_web_sessions_revoke_user($email); dmd_genpw_log('vault.lock','vault','success',array(),dmd_genpw_vault_resource($email)); dmd_genpw_reply(array('ok'=>true,'locked'=>true)); }
    if ($action==='config_get') dmd_genpw_reply(array('ok'=>true,'config'=>dmd_genpw_config($email),'language'=>dmd_genpw_language(),'strings'=>dmd_genpw_strings()));
    if ($action==='config_save') { $cfg=dmd_genpw_save_config($email,$input); dmd_genpw_log('config.update','config','success',array('config'=>$cfg)); dmd_genpw_reply(array('ok'=>true,'config'=>$cfg)); }

    dmd_genpw_touch_unlock($email);
    if ($action==='web_session') {
        dmd_genpw_web_sessions_revoke_user($email);
        $web=dmd_genpw_web_session_create($email);
        dmd_genpw_reply(array('ok'=>true,'token'=>$web['token'],'expires_in'=>$web['expires_in']));
    }
    if ($action==='web_target') {
        $token=is_scalar(isset($input['web_token'])?$input['web_token']:null)?(string)$input['web_token']:'';
        $target=is_scalar(isset($input['url'])?$input['url']:null)?trim((string)$input['url']):'';
        $web=dmd_genpw_web_session_validate($token,true);
        if (!is_array($web) || !hash_equals($email,(string)($web['email']??''))) dmd_genpw_reply(array('ok'=>false,'error'=>'Session de navigation expirée.'),401);
        $target=dmd_genpw_validate_url($target);
        $targetParts=parse_url($target); $targetScheme=strtolower((string)($targetParts['scheme']??'')); $targetHost=strtolower((string)($targetParts['host']??''));
        $targetPort=isset($targetParts['port'])?(int)$targetParts['port']:(($targetScheme==='https')?443:80);
        $targetOrigin=$targetScheme.'://'.$targetHost.((($targetScheme==='https'&&$targetPort===443)||($targetScheme==='http'&&$targetPort===80))?'':':'.$targetPort);
        $allowed=false;
        foreach (dmd_genpw_list_entries($email) as $row) {
            $saved=(string)($row['url']??''); if ($saved==='') continue; $sp=parse_url($saved); if (!is_array($sp)||empty($sp['scheme'])||empty($sp['host'])) continue;
            $ss=strtolower((string)$sp['scheme']); $sh=strtolower((string)$sp['host']); $spt=isset($sp['port'])?(int)$sp['port']:(($ss==='https')?443:80);
            $so=$ss.'://'.$sh.((($ss==='https'&&$spt===443)||($ss==='http'&&$spt===80))?'':':'.$spt);
            if (hash_equals($so,$targetOrigin)) { $allowed=true; break; }
        }
        if (!$allowed) dmd_genpw_reply(array('ok'=>false,'error'=>'Destination web non autorisée : ajoutez d’abord ce site dans GenPW.'),403);
        $sig=dmd_genpw_web_proxy_sign_target($token,$target);
        if ($sig==='') dmd_genpw_reply(array('ok'=>false,'error'=>'Impossible d’autoriser cette navigation.'),400);
        dmd_genpw_reply(array('ok'=>true,'url'=>$target,'signature'=>$sig));
    }
    $ownedFile=dmd_genpw_owned_file($email); $sharedFile=dmd_genpw_shared_file($email);
    $owned=dmd_genpw_read_json($ownedFile,array());

    if ($action==='list') dmd_genpw_reply(array('ok'=>true,'items'=>dmd_genpw_list_entries($email)));
    if ($action==='add') {
        $v=dmd_genpw_clean_entry_input($input,true); do{$id=bin2hex(random_bytes(8));}while(isset($owned[$id]));
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email); $enc=dmd_genpw_encrypt($v['pw'],$key,dmd_genpw_aad($email,$id));
        $owned[$id]=array_merge(array('name'=>$v['name'],'cat'=>$v['cat'],'url'=>$v['url'],'user'=>$v['user'],'notes'=>$v['notes'],'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM),'date'=>date('d/m/Y H:i')),$enc);
        dmd_genpw_write_json($ownedFile,$owned); $r=dmd_genpw_resource($id,$v['name'],$email); $activity=dmd_genpw_log('credential.create',$id,'success',array('category'=>$v['cat']),$r);
        dmd_genpw_reply(array('ok'=>true,'id'=>$id,'resource'=>$r,'activity'=>$activity));
    }
    if ($action==='update') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); if ($id===null || !isset($owned[$id]) || !is_array($owned[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        $v=dmd_genpw_clean_entry_input($input,false); $entry=$owned[$id];
        foreach (array('name','cat','url','user','notes') as $f) $entry[$f]=$v[$f]; $entry['updated_at']=date(DATE_ATOM); $entry['date']=date('d/m/Y H:i');
        $secret=''; $provided=is_scalar(isset($input['pw'])?$input['pw']:null)?(string)$input['pw']:''; $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email);
        if ($provided!=='') { if (strlen($provided)>4096) throw new InvalidArgumentException('Mot de passe invalide.'); $secret=$provided; foreach(array('pw','iv','tag','data','cipher','v') as $f) unset($entry[$f]); $entry=array_merge($entry,dmd_genpw_encrypt($secret,$key,dmd_genpw_aad($email,$id))); }
        else { $secret=dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile); }
        $owned[$id]=$entry; dmd_genpw_write_json($ownedFile,$owned); $synced=dmd_genpw_sync_shares($email,$id,$entry,$secret); $r=dmd_genpw_resource($id,$entry['name'],$email); $activity=dmd_genpw_log('credential.update',$id,'success',array('category'=>$entry['cat'],'shared_updated'=>$synced),$r);
        dmd_genpw_reply(array('ok'=>true,'id'=>$id,'shared_updated'=>$synced,'resource'=>$r,'activity'=>$activity));
    }
    if ($action==='get_secret') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); $kind=(isset($input['kind'])&&$input['kind']==='shared')?'shared':'owned'; if($id===null) throw new InvalidArgumentException('Identifiant invalide.');
        $entry=array(); $secret=dmd_genpw_decrypt_by_kind($email,$id,$kind,$entry); dmd_genpw_log('credential.reveal',$id,'success',array('kind'=>$kind),dmd_genpw_resource($id,(string)(isset($entry['name'])?$entry['name']:'Identifiant'),$kind==='shared'?(string)(isset($entry['owner'])?$entry['owner']:''):$email));
        dmd_genpw_reply(array('ok'=>true,'secret'=>$secret));
    }
    if ($action==='get_qr') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); $kind=(isset($input['kind'])&&$input['kind']==='shared')?'shared':'owned'; if($id===null) throw new InvalidArgumentException('Identifiant invalide.');
        $entry=array(); $secret=dmd_genpw_decrypt_by_kind($email,$id,$kind,$entry); $payload=$secret;
        if ((isset($entry['cat'])?$entry['cat']:'')==='Wi-Fi') { $ssid=dmd_genpw_clean(!empty($entry['user'])?$entry['user']:(isset($entry['name'])?$entry['name']:''),255); $esc=function($s){return str_replace(array('\\',';',',',':','"'),array('\\\\','\\;','\\,','\\:','\\"'),$s);}; $payload='WIFI:T:WPA;S:'.$esc($ssid).';P:'.$esc($secret).';;'; }
        $tokens=is_array(isset($_SESSION['dmd_genpw_qr_tokens'])?$_SESSION['dmd_genpw_qr_tokens']:null)?$_SESSION['dmd_genpw_qr_tokens']:array(); $now=time(); foreach($tokens as $t=>$v) if(!is_array($v)||(int)(isset($v['exp'])?$v['exp']:0)<=$now) unset($tokens[$t]); while(count($tokens)>=5) array_shift($tokens);
        $token=bin2hex(random_bytes(24)); $tokens[$token]=array('payload'=>$payload,'exp'=>$now+60); $_SESSION['dmd_genpw_qr_tokens']=$tokens; dmd_genpw_log('credential.qr',$id,'success',array('kind'=>$kind),dmd_genpw_resource($id,(string)(isset($entry['name'])?$entry['name']:'Identifiant'),$email));
        dmd_genpw_reply(array('ok'=>true,'token'=>$token,'expires_in'=>60));
    }
    if ($action==='share_users') dmd_genpw_reply(array('ok'=>true,'users'=>dmd_genpw_available_users($email)));
    if ($action==='share') {
        $id=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); if($id===null||!isset($owned[$id])||!is_array($owned[$id])) throw new OutOfBoundsException('Entrée introuvable.');
        $recipients=isset($input['recipients'])?$input['recipients']:array(); if(!is_array($recipients)) $recipients=array($recipients); $recipients=array_values(array_unique(array_filter(array_map('strval',$recipients))));
        $key=dmd_genpw_key(dmd_genpw_user_dir($email),$email); $secret=dmd_genpw_decrypt_entry($owned,$id,$key,$email,$ownedFile); $entry=$owned[$id]; $index=dmd_genpw_share_index(); $done=array();
        foreach($recipients as $recipient) {
            if($recipient===$email||filter_var($recipient,FILTER_VALIDATE_EMAIL)===false) continue;
            dmd_genpw_profile_dir($recipient);
            if (!dmd_genpw_user_has_permission($recipient, 'module.view')) continue;
            $existing=''; foreach($index as $sid=>$row) if(is_array($row)&&(isset($row['owner'])?$row['owner']:'')===$email&&(isset($row['source_id'])?$row['source_id']:'')===$id&&(isset($row['recipient'])?$row['recipient']:'')===$recipient){$existing=$sid;break;}
            $shareId=$existing!==''?$existing:bin2hex(random_bytes(8)); $file=dmd_genpw_shared_file($recipient); $shared=dmd_genpw_read_json($file,array()); $recipientKey=dmd_genpw_key(dmd_genpw_user_dir($recipient),$recipient); $enc=dmd_genpw_encrypt($secret,$recipientKey,dmd_genpw_aad($recipient,$shareId));
            $shared[$shareId]=array_merge(array('name'=>$entry['name'],'cat'=>$entry['cat'],'url'=>$entry['url'],'user'=>$entry['user'],'notes'=>isset($entry['notes'])?$entry['notes']:'','date'=>date('d/m/Y H:i'),'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM),'owner'=>$email,'source_id'=>$id,'shared_at'=>date(DATE_ATOM)),$enc);
            dmd_genpw_write_json($file,$shared); $index[$shareId]=array('owner'=>$email,'recipient'=>$recipient,'source_id'=>$id,'recipient_id'=>$shareId,'label'=>$entry['name'],'created_at'=>isset($index[$shareId]['created_at'])?$index[$shareId]['created_at']:date(DATE_ATOM),'updated_at'=>date(DATE_ATOM)); $done[]=$recipient;
            $en = strpos(strtolower(dmd_genpw_language()), 'en') === 0;
            dmd_genpw_notify($recipient,'credential_shared',$en ? 'New shared access' : 'Nouvel accès partagé',(string)$entry['name'].($en ? ' was shared with you by ' : ' a été partagé avec vous par ').$email.'.',array('source_id'=>$id,'share_id'=>$shareId));
        }
        dmd_genpw_write_share_index($index); $r=dmd_genpw_resource($id,(string)$entry['name'],$email); $activity=dmd_genpw_log('credential.share',$id,'success',array('recipients'=>$done),$r); dmd_genpw_reply(array('ok'=>true,'shared_with'=>$done,'activity'=>$activity));
    }
    if ($action==='shares') {
        $source=dmd_genpw_valid_id(isset($input['id'])?$input['id']:null); if($source===null) throw new InvalidArgumentException('Identifiant invalide.'); $rows=array();
        foreach(dmd_genpw_share_rows_for_source($email,$source) as $row) $rows[]=array('share_id'=>$row['share_id'],'recipient'=>$row['recipient'],'created_at'=>isset($row['created_at'])?$row['created_at']:'','updated_at'=>isset($row['updated_at'])?$row['updated_at']:''); dmd_genpw_reply(array('ok'=>true,'shares'=>$rows));
    }
    if ($action==='revoke_share') {
        $shareId=dmd_genpw_valid_id(isset($input['share_id'])?$input['share_id']:null); if($shareId===null) throw new InvalidArgumentException('Partage invalide.'); $idx=dmd_genpw_share_index(); if(!isset($idx[$shareId])||!is_array($idx[$shareId])||(isset($idx[$shareId]['owner'])?$idx[$shareId]['owner']:'')!==$email) throw new OutOfBoundsException('Partage introuvable.'); $source=(string)$idx[$shareId]['source_id']; $recipient=(string)$idx[$shareId]['recipient']; dmd_genpw_revoke_share_row($shareId,true); dmd_genpw_log('credential.share.revoke',$source,'success',array('recipient'=>$recipient),isset($owned[$source])?dmd_genpw_resource($source,(string)$owned[$source]['name'],$email):null); dmd_genpw_reply(array('ok'=>true));
    }
    if ($action==='delete') {
        $ids=isset($input['ids'])?$input['ids']:array(); if(!is_array($ids))$ids=array($ids); $deleted=0;$revoked=0;
        foreach(array_unique($ids) as $candidate){$id=dmd_genpw_valid_id($candidate);if($id!==null&&isset($owned[$id])){$label=(string)(isset($owned[$id]['name'])?$owned[$id]['name']:'Identifiant');$revoked+=dmd_genpw_revoke_source_shares($email,$id,$label);unset($owned[$id]);$deleted++;dmd_genpw_log('credential.delete',$id,'success',array('shares_revoked'=>$revoked),dmd_genpw_resource($id,$label,$email));}}
        if($deleted)dmd_genpw_write_json($ownedFile,$owned);dmd_genpw_reply(array('ok'=>true,'deleted'=>$deleted,'shares_revoked'=>$revoked));
    }
    if ($action==='export') {
        $format=(isset($input['format'])&&$input['format']==='csv')?'csv':'json'; $include=!empty($input['include_secrets']); if($include){dmd_genpw_require_permission('vault.export.secrets');}
        $rows=array(); foreach(dmd_genpw_list_entries($email) as $item){$row=$item;if($include){$entry=array();$row['secret']=dmd_genpw_decrypt_by_kind($email,$item['id'],$item['kind'],$entry);} $rows[]=$row;}
        dmd_genpw_log('vault.export','vault','success',array('format'=>$format,'include_secrets'=>$include,'count'=>count($rows)),dmd_genpw_vault_resource($email));
        if($format==='json'){$content=json_encode($rows,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);$mime='application/json';$name='DMD-GenPW-'.date('Ymd-His').'.json';}
        else{$fp=fopen('php://temp','r+');$headers=array('name','category','url','user','notes','kind','owner','date');if($include)$headers[]='secret';fputcsv($fp,$headers,';');foreach($rows as $r){$line=array($r['name'],$r['cat'],$r['url'],$r['user'],$r['notes'],$r['kind'],$r['owner'],$r['date']);if($include)$line[]=$r['secret'];fputcsv($fp,$line,';');}rewind($fp);$content=stream_get_contents($fp);fclose($fp);$mime='text/csv';$name='DMD-GenPW-'.date('Ymd-His').'.csv';}
        dmd_genpw_reply(array('ok'=>true,'filename'=>$name,'mime'=>$mime,'content'=>base64_encode((string)$content)));
    }
    if ($action==='logs') dmd_genpw_reply(array('ok'=>true,'items'=>dmd_genpw_recent_logs($email,isset($input['limit'])?(int)$input['limit']:200)));
    if ($action==='logs_export') { $rows=dmd_genpw_recent_logs($email,500); dmd_genpw_reply(array('ok'=>true,'filename'=>'DMD-GenPW-logs-'.date('Ymd-His').'.json','mime'=>'application/json','content'=>base64_encode((string)json_encode($rows,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)))); }
    if ($action==='logs_delete') {
        $n=dmd_genpw_clear_logs($email);
        dmd_genpw_boot_core();
        if (function_exists('dmd_system_log')) {
            try { dmd_system_log('module_logs_deleted', DMD_GENPW_ID, 'success', 'Journal utilisateur DMD-GenPW supprimé.', array('user'=>$email,'removed'=>$n)); } catch (Throwable $e) {}
        }
        dmd_genpw_reply(array('ok'=>true,'removed'=>$n));
    }
} catch (InvalidArgumentException $e) { dmd_genpw_reply(array('ok'=>false,'error'=>$e->getMessage()),400); }
catch (OutOfBoundsException $e) { dmd_genpw_reply(array('ok'=>false,'error'=>$e->getMessage()),404); }
catch (Throwable $e) { error_log('[DMD-GenPW] '.$e->getMessage()); dmd_genpw_reply(array('ok'=>false,'error'=>'Erreur interne DMD-GenPW'),500); }
