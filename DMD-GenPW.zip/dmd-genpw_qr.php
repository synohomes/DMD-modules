<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
require_once __DIR__ . '/dmd-genpw_lib.php';
dmd_genpw_require_permission('vault.qr');
if (!dmd_genpw_is_unlocked(dmd_genpw_email())) { http_response_code(423); exit; }
$token = isset($_GET['t']) && is_scalar($_GET['t']) ? (string)$_GET['t'] : '';
if (!preg_match('/^[a-f0-9]{48}$/D',$token)) { http_response_code(404); exit; }
$tokens = is_array(isset($_SESSION['dmd_genpw_qr_tokens']) ? $_SESSION['dmd_genpw_qr_tokens'] : null) ? $_SESSION['dmd_genpw_qr_tokens'] : array();
$item = isset($tokens[$token]) && is_array($tokens[$token]) ? $tokens[$token] : null;
unset($tokens[$token]); $_SESSION['dmd_genpw_qr_tokens']=$tokens;
if (!$item || (int)(isset($item['exp'])?$item['exp']:0) < time() || !isset($item['payload'])) { http_response_code(404); exit; }
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0'); header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/phpqrcode.php';
if (function_exists('imagecreate')) {
    header('Content-Type: image/png');
    QRcode::png((string)$item['payload'], false, QR_ECLEVEL_M, 6, 2);
} else {
    /* Fallback sans extension GD : le navigateur affiche le SVG dans le même <img>. */
    header('Content-Type: image/svg+xml; charset=UTF-8');
    QRcode::svg((string)$item['payload'], false, QR_ECLEVEL_M, 6, 2);
}
