<?php
declare(strict_types=1);

require_once __DIR__ . '/dmd-3dprint_lib.php';

dmd3d_require_login();
$action = strtolower(trim((string)($_GET['action'] ?? $_POST['action'] ?? 'bootstrap')));
$input = dmd3d_input();

try {
    switch ($action) {
        case 'model_image':
            dmd3d_require_permission('module.view');
            $type = strtolower(trim((string)($_GET['type'] ?? '')));
            if (!in_array($type, ['printer', 'plug'], true)) {
                throw new InvalidArgumentException('Type d’équipement invalide.');
            }
            $device = dmd3d_find_device($type, (string)($_GET['id'] ?? ''));
            if ($device === null) {
                http_response_code(404);
                exit;
            }
            dmd3d_require_device_access($type, $device);
            dmd3d_output_model_image($type, $device);

        case 'bootstrap':
            $configScope = strtolower(trim((string)($_GET['scope'] ?? ''))) === 'config';
            dmd3d_require_permission($configScope ? 'config.view' : 'module.view');
            $printers = dmd3d_load_printers();
            $plugs = dmd3d_load_plugs();
            if (!$configScope) {
                $printers = dmd3d_filter_accessible_devices('printer', $printers);
                $plugs = dmd3d_filter_accessible_devices('plug', $plugs);
            }
            $resources = [];
            foreach ($printers as $printer) {
                $resources[] = dmd3d_resource('printer', $printer);
            }
            foreach ($plugs as $plug) {
                $resources[] = dmd3d_resource('plug', $plug);
            }
            $publicPrinters = [];
            foreach ($printers as $printer) {
                $publicPrinters[] = $configScope ? dmd3d_public_device_with_access('printer', $printer) : dmd3d_public_device($printer);
            }
            $publicPlugs = [];
            foreach ($plugs as $plug) {
                $publicPlugs[] = $configScope ? dmd3d_public_device_with_access('plug', $plug) : dmd3d_public_device($plug);
            }
            dmd3d_response([
                'ok' => true,
                'module' => [
                    'id' => DMD3D_MODULE_ID,
                    'name' => DMD3D_MODULE_NAME,
                    'version' => DMD3D_MODULE_VERSION,
                ],
                'csrf' => dmd3d_csrf_token(),
                'is_admin' => dmd3d_is_admin(),
                'permissions' => dmd3d_permission_snapshot(),
                'resources' => $resources,
                'imprimantes' => $publicPrinters,
                'prises' => $publicPlugs,
                'acl_users' => $configScope ? dmd3d_acl_users_catalog() : [],
                'modeles_imprimantes' => dmd3d_scan_models('printer'),
                'modeles_prises' => dmd3d_scan_models('plug'),
            ]);

        case 'camera_webrtc':
            dmd3d_require_permission('camera.view');
            dmd3d_require_csrf($input);
            $printer = dmd3d_find_device('printer', (string)($input['printer_id'] ?? ''));
            if ($printer === null) {
                throw new InvalidArgumentException('Imprimante introuvable.');
            }
            dmd3d_require_device_access('printer', $printer);
            if (empty($printer['enabled'])) {
                throw new RuntimeException('Imprimante désactivée.');
            }
            $result = dmd3d_call_driver('printer', $printer, 'camera_webrtc', [
                'offer' => trim((string)($input['offer'] ?? '')),
            ]);
            $answer = trim((string)($result['answer'] ?? ''));
            if ($answer === '') {
                throw new RuntimeException('Le pilote de cette imprimante n’a renvoyé aucune réponse WebRTC.');
            }
            dmd3d_response(['ok' => true, 'answer' => $answer]);

        case 'printer_status':
            dmd3d_require_permission('printer.status');
            $printer = dmd3d_find_device('printer', (string)($input['printer_id'] ?? $_GET['printer_id'] ?? ''));
            if ($printer === null) {
                throw new InvalidArgumentException('Imprimante introuvable.');
            }
            dmd3d_require_device_access('printer', $printer);
            if (empty($printer['enabled'])) {
                dmd3d_response(['ok' => true, 'status' => ['online' => false, 'state' => 'disabled', 'message' => 'Imprimante désactivée.']]);
            }
            $result = dmd3d_call_driver('printer', $printer, 'status', []);
            if (empty($result['camera_url']) && !empty($printer['camera_url'])) {
                $result['camera_url'] = $printer['camera_url'];
            }
            $result = dmd3d_sanitize_public_payload($result, dmd3d_has_permission('camera.view'));
            dmd3d_response(['ok' => true, 'status' => $result]);

        case 'printer_details':
            dmd3d_require_permission('printer.details');
            $printer = dmd3d_find_device('printer', (string)($input['printer_id'] ?? $_GET['printer_id'] ?? ''));
            if ($printer === null) {
                throw new InvalidArgumentException('Imprimante introuvable.');
            }
            dmd3d_require_device_access('printer', $printer);
            if (empty($printer['enabled'])) {
                throw new RuntimeException('Imprimante désactivée.');
            }
            $details = dmd3d_call_driver('printer', $printer, 'details', []);
            $details = dmd3d_sanitize_public_payload($details, dmd3d_has_permission('camera.view'));
            dmd3d_response(['ok' => true, 'details' => $details]);

        case 'plug_status':
            dmd3d_require_permission('plug.view');
            $plug = dmd3d_find_device('plug', (string)($input['plug_id'] ?? $_GET['plug_id'] ?? ''));
            if ($plug === null) {
                throw new InvalidArgumentException('Prise introuvable.');
            }
            dmd3d_require_device_access('plug', $plug);
            if (empty($plug['enabled'])) {
                dmd3d_response(['ok' => true, 'status' => ['online' => false, 'state' => 'disabled', 'message' => 'Prise désactivée.']]);
            }
            $plugStatus = dmd3d_sanitize_public_payload(dmd3d_call_driver('plug', $plug, 'status', []), false);
            dmd3d_response(['ok' => true, 'status' => $plugStatus]);

        case 'printer_command':
            dmd3d_require_csrf($input);
            $printer = dmd3d_find_device('printer', (string)($input['printer_id'] ?? ''));
            if ($printer === null) {
                throw new InvalidArgumentException('Imprimante introuvable.');
            }
            dmd3d_require_device_access('printer', $printer);
            $command = strtolower(trim((string)($input['command'] ?? '')));
            $permissions = [
                'start' => 'printer.start',
                'pause' => 'printer.pause',
                'resume' => 'printer.resume',
                'stop' => 'printer.stop',
                'light_on' => 'printer.light',
                'light_off' => 'printer.light',
                'fan' => 'printer.fan',
            ];
            if (!isset($permissions[$command])) {
                throw new InvalidArgumentException('Commande d’imprimante interdite.');
            }
            dmd3d_require_permission($permissions[$command]);
            $payload = [
                'value' => isset($input['value']) ? max(0, min(100, (int)$input['value'])) : null,
                'fan' => dmd3d_clean_text($input['fan'] ?? 'part', 40),
                'file' => dmd3d_clean_text($input['file'] ?? '', 255),
            ];
            $result = dmd3d_call_driver('printer', $printer, $command, $payload);
            dmd3d_record_event('printer.' . $command, 'printer', $printer, 'ok', $payload);
            dmd3d_response(['ok' => true, 'result' => $result]);

        case 'plug_command':
            dmd3d_require_permission('plug.power');
            dmd3d_require_csrf($input);
            $plug = dmd3d_find_device('plug', (string)($input['plug_id'] ?? ''));
            if ($plug === null) {
                throw new InvalidArgumentException('Prise introuvable.');
            }
            dmd3d_require_device_access('plug', $plug);
            $command = strtolower(trim((string)($input['command'] ?? '')));
            if (!in_array($command, ['power_on', 'power_off'], true)) {
                throw new InvalidArgumentException('Commande de prise interdite.');
            }
            $result = dmd3d_call_driver('plug', $plug, $command, []);
            dmd3d_record_event('plug.' . $command, 'plug', $plug, 'ok');
            dmd3d_response(['ok' => true, 'result' => $result]);

        case 'upload_print_file':
            dmd3d_require_permission('printer.upload');
            dmd3d_require_csrf($_POST);
            $printer = dmd3d_find_device('printer', (string)($_POST['printer_id'] ?? ''));
            if ($printer === null) {
                throw new InvalidArgumentException('Imprimante introuvable.');
            }
            dmd3d_require_device_access('printer', $printer);
            if (!isset($_FILES['print_file']) || !is_array($_FILES['print_file'])) {
                throw new InvalidArgumentException('Sélectionne un fichier STL, 3MF ou G-code.');
            }
            $file = dmd3d_store_print_file($_FILES['print_file'], $printer);
            $startAfterUpload = filter_var($_POST['start_after_upload'] ?? false, FILTER_VALIDATE_BOOL);
            $printableExtensions = ['gcode', 'gco', 'gc'];
            if ($startAfterUpload && !in_array($file['extension'], $printableExtensions, true)) {
                @unlink($file['path']);
                throw new InvalidArgumentException('Le démarrage automatique est réservé aux fichiers G-code. Un STL ou un projet 3MF doit d’abord être découpé par un slicer.');
            }
            if ($startAfterUpload) {
                dmd3d_require_permission('printer.start');
            }
            $payload = [
                'name' => $file['name'],
                'stored_name' => $file['stored_name'],
                'path' => $file['path'],
                'extension' => $file['extension'],
                'size' => $file['size'],
                'start_after_upload' => $startAfterUpload,
            ];
            try {
                $result = dmd3d_call_driver('printer', $printer, 'upload_file', $payload);
            } catch (Throwable $driverError) {
                @unlink($file['path']);
                throw $driverError;
            }
            dmd3d_record_event('printer.upload_file', 'printer', $printer, 'ok', [
                'file' => $file['name'],
                'extension' => $file['extension'],
                'size' => $file['size'],
                'start_after_upload' => $startAfterUpload,
            ]);
            dmd3d_response(['ok' => true, 'file' => ['name' => $file['name'], 'stored_name' => $file['stored_name']], 'result' => $result]);

        case 'save_printer':
            dmd3d_require_permission('config.printer.save');
            dmd3d_require_csrf($input);
            $item = dmd3d_save_device('printer', $input);
            $saved = dmd3d_find_device('printer', (string)($item['id'] ?? '')) ?? $item;
            $accessChange = null;
            if (array_key_exists('access_mode', $input)) {
                $accessChange = dmd3d_save_resource_access('printer', $saved, (string)$input['access_mode'], $input['access_users'] ?? []);
            }
            dmd3d_record_event('config.printer.save', 'printer', $saved, 'ok', $accessChange && !empty($accessChange['changed']) ? [
                'resource_access' => $accessChange['rule'],
                'users_added' => $accessChange['added'],
                'users_removed' => $accessChange['removed'],
            ] : []);
            $item['resource_access'] = dmd3d_resource_access_rule('printer', $saved);
            dmd3d_response(['ok' => true, 'item' => $item]);

        case 'save_plug':
            dmd3d_require_permission('config.plug.save');
            dmd3d_require_csrf($input);
            $item = dmd3d_save_device('plug', $input);
            $saved = dmd3d_find_device('plug', (string)($item['id'] ?? '')) ?? $item;
            $accessChange = null;
            if (array_key_exists('access_mode', $input)) {
                $accessChange = dmd3d_save_resource_access('plug', $saved, (string)$input['access_mode'], $input['access_users'] ?? []);
            }
            dmd3d_record_event('config.plug.save', 'plug', $saved, 'ok', $accessChange && !empty($accessChange['changed']) ? [
                'resource_access' => $accessChange['rule'],
                'users_added' => $accessChange['added'],
                'users_removed' => $accessChange['removed'],
            ] : []);
            $item['resource_access'] = dmd3d_resource_access_rule('plug', $saved);
            dmd3d_response(['ok' => true, 'item' => $item]);

        case 'delete_printer':
            dmd3d_require_permission('config.printer.delete');
            dmd3d_require_csrf($input);
            $printer = dmd3d_find_device('printer', (string)($input['id'] ?? ''));
            if ($printer === null) {
                throw new InvalidArgumentException('Imprimante introuvable.');
            }
            dmd3d_delete_device('printer', (string)$printer['id']);
            dmd3d_record_event('config.printer.delete', 'printer', $printer, 'ok');
            dmd3d_response(['ok' => true]);

        case 'delete_plug':
            dmd3d_require_permission('config.plug.delete');
            dmd3d_require_csrf($input);
            $plug = dmd3d_find_device('plug', (string)($input['id'] ?? ''));
            if ($plug === null) {
                throw new InvalidArgumentException('Prise introuvable.');
            }
            dmd3d_delete_device('plug', (string)$plug['id']);
            dmd3d_record_event('config.plug.delete', 'plug', $plug, 'ok');
            dmd3d_response(['ok' => true]);

        case 'test_printer':
            dmd3d_require_permission('config.printer.test');
            dmd3d_require_csrf($input);
            $printer = dmd3d_find_device('printer', (string)($input['id'] ?? ''));
            if ($printer === null) {
                throw new InvalidArgumentException('Imprimante introuvable.');
            }
            $result = dmd3d_call_driver('printer', $printer, 'status', []);
            dmd3d_record_event('config.printer.test', 'printer', $printer, 'ok');
            dmd3d_response(['ok' => true, 'result' => $result]);

        case 'test_plug':
            dmd3d_require_permission('config.plug.test');
            dmd3d_require_csrf($input);
            $plug = dmd3d_find_device('plug', (string)($input['id'] ?? ''));
            if ($plug === null) {
                throw new InvalidArgumentException('Prise introuvable.');
            }
            $result = dmd3d_call_driver('plug', $plug, 'status', []);
            dmd3d_record_event('config.plug.test', 'plug', $plug, 'ok');
            dmd3d_response(['ok' => true, 'result' => $result]);

        case 'install_model':
            dmd3d_require_permission('model.install');
            dmd3d_require_csrf($_POST);
            $type = (string)($_POST['model_type'] ?? '');
            if (!in_array($type, ['printer', 'plug'], true)) {
                throw new InvalidArgumentException('Type de modèle invalide.');
            }
            $model = dmd3d_install_model(
                $type,
                (string)($_POST['model_name'] ?? ''),
                filter_var($_POST['replace'] ?? false, FILTER_VALIDATE_BOOL)
            );
            dmd3d_record_event('model.install', $type === 'printer' ? 'printer_model' : 'plug_model', [
                'id' => (string)($model['id'] ?? ''),
                'name' => (string)($model['name'] ?? $model['id'] ?? 'Modèle'),
            ], 'ok', ['source' => 'upload']);
            dmd3d_response(['ok' => true, 'model' => $model]);

        case 'delete_model':
            dmd3d_require_permission('model.delete');
            dmd3d_require_csrf($input);
            $type = (string)($input['model_type'] ?? '');
            if (!in_array($type, ['printer', 'plug'], true)) {
                throw new InvalidArgumentException('Type de modèle invalide.');
            }
            $modelId = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($input['model'] ?? '')) ?: '';
            dmd3d_delete_model($type, $modelId);
            dmd3d_record_event('model.delete', $type === 'printer' ? 'printer_model' : 'plug_model', [
                'id' => $modelId,
                'name' => $modelId,
            ], 'ok');
            dmd3d_response(['ok' => true]);

        default:
            dmd3d_response(['ok' => false, 'message' => 'Action inconnue.'], 404);
    }
} catch (InvalidArgumentException $error) {
    dmd3d_response(['ok' => false, 'message' => $error->getMessage()], 422);
} catch (RuntimeException $error) {
    dmd3d_response(['ok' => false, 'message' => $error->getMessage()], 409);
} catch (Throwable $error) {
    error_log('[DMD-3DPRINT] ' . $error->getMessage());
    dmd3d_response(['ok' => false, 'message' => 'Erreur interne du module. Consulte les journaux PHP.'], 500);
}
