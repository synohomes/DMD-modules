<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/dmd-3dprint_lib.php';

if (!dmd3d_has_permission('module.view')) {
    echo '<section class="dmd3d"><div class="dmd3d-empty">Accès à DMD-3DPRINT refusé.</div></section>';
    return;
}

$scriptPath = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
$moduleMarker = '/modules/dmd-3dprint/';
$markerPosition = strpos($scriptPath, $moduleMarker);
if ($markerPosition !== false) {
    $moduleBaseUrl = substr($scriptPath, 0, $markerPosition) . '/modules/dmd-3dprint';
} else {
    $scriptDirectory = str_replace('\\', '/', dirname($scriptPath));
    if (substr($scriptDirectory, -4) === '/adm') {
        $scriptDirectory = str_replace('\\', '/', dirname($scriptDirectory));
    }
    $moduleBaseUrl = rtrim($scriptDirectory, '/') . '/modules/dmd-3dprint';
}
if ($moduleBaseUrl === '') {
    $moduleBaseUrl = '/modules/dmd-3dprint';
}
$moduleCssUrl = $moduleBaseUrl . '/dmd-3dprint.css?v=130';
$moduleApiUrl = $moduleBaseUrl . '/dmd-3dprint_api.php';
$instanceId = 'dmd3d-' . bin2hex(random_bytes(4));
$mfaInstance = bin2hex(random_bytes(24));
$mfaState = dmd3d_mfa_state($mfaInstance);
$mfaGateVisible = !empty($mfaState['required']);
$initialCsrf = dmd3d_csrf_token();
?>
<link rel="stylesheet" href="<?= htmlspecialchars($moduleCssUrl, ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($moduleBaseUrl . '/dmd-3dprint_models.css?v=122', ENT_QUOTES, 'UTF-8') ?>">
<script src="<?= htmlspecialchars($moduleBaseUrl . '/dmd-3dprint_models.js?v=122', ENT_QUOTES, 'UTF-8') ?>"></script>

<section id="<?= htmlspecialchars($instanceId, ENT_QUOTES, 'UTF-8') ?>" class="dmd3d" data-dmd3d-main data-dmd-module-id="dmd-3dprint" data-dmd-module-name="DMD-3DPRINT">
    <?php if ($mfaGateVisible): ?>
    <div class="dmd3d-mfa-gate" data-mfa-gate>
        <section class="dmd3d-card dmd3d-mfa-card">
            <div class="dmd3d-section-title">
                <div><h3>🔐 Validation MFA DoMyDesk</h3><p class="dmd3d-muted">DMD-3DPRINT réutilise uniquement le MFA déjà configuré sur ton compte DoMyDesk.</p></div>
                <span class="dmd3d-status"><?= !empty($mfaState['admin_required']) ? 'Obligatoire' : 'Activé' ?></span>
            </div>
            <?php if (empty($mfaState['core_available'])): ?>
                <div class="dmd3d-inline-message is-error">Le moteur MFA central DoMyDesk est indisponible.</div>
            <?php elseif (empty($mfaState['configured'])): ?>
                <div class="dmd3d-inline-message is-error">Le MFA n’est pas encore configuré sur ton compte DoMyDesk.</div>
                <?php if (!empty($mfaState['setup_allowed'])): ?><div class="dmd3d-actions"><a class="dmd3d-button" href="<?= htmlspecialchars((string)$mfaState['setup_url'], ENT_QUOTES, 'UTF-8') ?>">Configurer mon MFA DoMyDesk</a></div><?php endif; ?>
            <?php else: ?>
                <form class="dmd3d-mfa-form" data-mfa-form autocomplete="off">
                    <div class="dmd3d-field"><label>Code Authenticator ou code de secours</label><input name="code" autocomplete="one-time-code" inputmode="numeric" maxlength="32" required placeholder="000000"></div>
                    <div class="dmd3d-actions"><button type="submit" class="dmd3d-button">Ouvrir DMD-3DPRINT</button></div>
                </form>
                <div class="dmd3d-inline-message" data-mfa-message aria-live="polite"></div>
            <?php endif; ?>
        </section>
    </div>
    <?php endif; ?>
    <div data-module-content<?= $mfaGateVisible ? ' hidden' : '' ?>>
    <header class="dmd3d-header">
        <div>
            <p class="dmd3d-kicker">DoMyDesk 1.2.0</p>
            <h2>DMD-3DPRINT</h2>
            <p class="dmd3d-muted">Clique sur une imprimante pour ouvrir sa fenêtre de contrôle.</p>
        </div>
        <button type="button" class="dmd3d-button" data-refresh>Actualiser</button>
    </header>

    <div class="dmd3d-summary">
        <article><span>Imprimantes</span><strong data-total>0</strong></article>
        <article><span>Actives</span><strong data-enabled>0</strong></article>
        <article><span>Prises</span><strong data-plugs>0</strong></article>
    </div>

    <div class="dmd3d-printer-grid" data-printer-grid>
        <p class="dmd3d-empty">Chargement…</p>
    </div>

    </div>
    <div class="dmd3d-toast" data-toast hidden></div>
</section>

<script>
(() => {
    const root = document.getElementById(<?= json_encode($instanceId, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>);
    if (!root || root.dataset.ready === '1') return;
    root.dataset.ready = '1';

    const api = <?= json_encode($moduleApiUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const moduleIcon = <?= json_encode($moduleBaseUrl . '/icon.png', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const state = {csrf:<?= json_encode($initialCsrf, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>, mfaInstance:<?= json_encode($mfaInstance, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>, mfaUnlocked:<?= $mfaGateVisible ? 'false' : 'true' ?>, printers:[], plugs:[], permissions:{}, resources:[], windows:new Map(), z:9000, healthTimer:null};
    const q = selector => root.querySelector(selector);
    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

    function revealModule() {
        const gate = q('[data-mfa-gate]');
        const content = q('[data-module-content]');
        if (gate) gate.hidden = true;
        if (content) content.hidden = false;
        state.mfaUnlocked = true;
    }

    const mfaForm = q('[data-mfa-form]');
    if (mfaForm) {
        mfaForm.addEventListener('submit', async event => {
            event.preventDefault();
            const button = mfaForm.querySelector('button[type="submit"]');
            const message = q('[data-mfa-message]');
            const code = String(mfaForm.elements.code?.value || '').trim();
            if (button) button.disabled = true;
            if (message) { message.textContent = 'Vérification…'; message.classList.remove('is-error','is-success'); }
            try {
                const data = await request('mfa_verify', {
                    method:'POST', headers:{'Content-Type':'application/json'},
                    body:JSON.stringify({csrf:state.csrf, code, mfa_instance:state.mfaInstance})
                });
                if (message) { message.textContent = data.message || 'MFA validé.'; message.classList.add('is-success'); }
                revealModule();
                load().then(() => startHealthMonitor()).catch(error => toast(error.message, true));
            } catch (error) {
                if (message) { message.textContent = error.message || String(error); message.classList.add('is-error'); }
            } finally {
                if (button) button.disabled = false;
            }
        });
    }

    function toast(message, error = false) {
        const el = q('[data-toast]');
        el.textContent = message;
        el.hidden = false;
        el.classList.toggle('is-error', error);
        clearTimeout(el._timer);
        el._timer = setTimeout(() => { el.hidden = true; }, 5000);
    }

    async function request(action, options = {}) {
        const separator = action.indexOf('&');
        const actionName = separator >= 0 ? action.slice(0, separator) : action;
        const extraQuery = separator >= 0 ? '&' + action.slice(separator + 1) : '';
        const requestOptions = {...options, headers:{...(options.headers || {}), 'X-DMD3D-MFA-INSTANCE':state.mfaInstance}};
        const response = await fetch(`${api}?action=${encodeURIComponent(actionName)}${extraQuery}`, {credentials:'same-origin', cache:'no-store', ...requestOptions});
        const text = await response.text();
        let data;
        try { data = JSON.parse(text); }
        catch (error) { throw new Error(`API inaccessible (${response.status}) : ${api} — ${text.slice(0, 160) || 'réponse vide'}`); }
        if (!response.ok || !data.ok) throw new Error(data.message || `Erreur HTTP ${response.status}`);
        return data;
    }

    function sendJson(action, payload) {
        return request(action, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...payload, csrf:state.csrf})});
    }

    function printerLabel(item) {
        return [item.brand, item.device_model].filter(Boolean).join(' ') || item.model || 'Modèle non renseigné';
    }

    function plugName(id) {
        return state.plugs.find(item => item.id === id)?.name || 'Aucune prise';
    }

    function modelImageUrl(type, device) {
        if (!device || !device.id || !device.model) return '';
        const stamp = encodeURIComponent(device.updated_at || device.model || '1');
        return `${api}?action=model_image&type=${encodeURIComponent(type)}&id=${encodeURIComponent(device.id)}&v=${stamp}`;
    }

    function bindModelImages(scope) {
        scope.querySelectorAll('img[data-model-image]').forEach(image => {
            image.addEventListener('error', () => { image.hidden = true; }, {once:true});
        });
    }

    function can(permission) {
        return state.permissions[permission] === true;
    }

    function resourceFor(type, localId) {
        const expected = type === 'plug' ? 'smart_plug' : 'printer';
        return state.resources.find(item => item.type === expected && item.local_id === localId) || null;
    }

    function decorateActionHub(scope = root) {
        try {
            if (window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') {
                window.DMDActionHub.decorate(scope);
            }
        } catch (error) {}
    }

    function syncWindowActionHubContext(win) {
        const printerId = selectedPrinterId(win);
        const printer = state.printers.find(item => item.id === printerId) || null;
        if (printer) {
            win.dataset.dmdContextType = 'printer';
            win.dataset.dmdContextId = (resourceFor('printer', printer.id) || {}).id || `dmd-3dprint:printer:${printer.id}`;
            win.dataset.dmdContextName = printer.name || 'Imprimante 3D';
        }

        const plugField = win.querySelector('[data-plug-context]');
        const plugId = selectedPlugId(win);
        const plug = state.plugs.find(item => item.id === plugId) || null;
        if (plugField) {
            if (plug) {
                plugField.dataset.dmdModuleId = 'dmd-3dprint';
                plugField.dataset.dmdContextType = 'smart_plug';
                plugField.dataset.dmdContextId = (resourceFor('plug', plug.id) || {}).id || `dmd-3dprint:smart_plug:${plug.id}`;
                plugField.dataset.dmdContextName = plug.name || 'Prise connectée';
                plugField.dataset.dmdActionHub = '1';
            } else {
                delete plugField.dataset.dmdModuleId;
                delete plugField.dataset.dmdContextType;
                delete plugField.dataset.dmdContextId;
                delete plugField.dataset.dmdContextName;
                delete plugField.dataset.dmdActionHub;
            }
        }

        decorateActionHub(win);
    }

    function renderCards() {
        q('[data-total]').textContent = state.printers.length;
        q('[data-enabled]').textContent = state.printers.filter(item => item.enabled !== false).length;
        q('[data-plugs]').textContent = state.plugs.length;
        q('[data-printer-grid]').innerHTML = state.printers.length ? state.printers.map(item => `
            <button type="button" class="dmd3d-printer-card" data-open-printer="${esc(item.id)}" data-dmd-module-id="dmd-3dprint" data-dmd-context-type="printer" data-dmd-context-id="${esc((resourceFor('printer', item.id) || {}).id || `dmd-3dprint:printer:${item.id}`)}" data-dmd-context-name="${esc(item.name)}" data-dmd-action-hub="1">
                <span class="dmd3d-printer-icon">🖨️</span>
                <span class="dmd3d-printer-copy"><strong>${esc(item.name)}</strong><small>${esc(printerLabel(item))}</small><small>${esc(item.host || 'Adresse non renseignée')}</small></span>
                <span class="dmd3d-printer-side"><span class="dmd3d-status ${item.enabled === false ? 'is-offline' : 'is-online'}">${item.enabled === false ? 'Désactivée' : 'Active'}</span><small>${esc(plugName(item.plug_id))}</small></span>
            </button>`).join('') : '<div class="dmd3d-empty">Aucune imprimante enregistrée dans le CFG.</div>';
    }

    async function load() {
        const data = await request('bootstrap');
        state.csrf = data.csrf || '';
        state.printers = data.imprimantes || [];
        state.plugs = data.prises || [];
        state.permissions = data.permissions || {};
        state.resources = data.resources || [];
        renderCards();
        decorateActionHub(root);
    }


    async function monitorHealth() {
        if (!can('printer.status') || document.visibilityState !== 'visible') return;
        try { await request('health_check'); }
        catch (error) { console.debug('[DMD-3DPrint health]', error); }
    }

    function startHealthMonitor() {
        if (state.healthTimer) return;
        window.setTimeout(monitorHealth, 1500);
        state.healthTimer = window.setInterval(monitorHealth, 30000);
    }

    function optionList(items, selected, emptyLabel) {
        return `<option value="">${esc(emptyLabel)}</option>` + items.map(item => `<option value="${esc(item.id)}"${item.id === selected ? ' selected' : ''}>${esc(item.name)}</option>`).join('');
    }

    function formatTime(value) {
        if (value === null || value === undefined || value === '') return '—';
        if (typeof value === 'string' && value.includes(':')) return value;
        const seconds = Math.max(0, Math.round(Number(value) || 0));
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    }

    function metric(value, unit = '') {
        return value === null || value === undefined || value === '' ? '—' : `${value}${unit}`;
    }

    function formatBytes(value) {
        const bytes = Number(value);
        if (!Number.isFinite(bytes) || bytes < 0) return '—';
        if (bytes < 1024) return `${bytes} o`;
        const units = ['Ko', 'Mo', 'Go'];
        let size = bytes / 1024;
        let index = 0;
        while (size >= 1024 && index < units.length - 1) { size /= 1024; index++; }
        return `${size.toFixed(size >= 10 ? 1 : 2)} ${units[index]}`;
    }

    function formatDate(value) {
        const timestamp = Number(value);
        if (!Number.isFinite(timestamp) || timestamp <= 0) return '—';
        return new Date(timestamp * 1000).toLocaleString('fr-FR');
    }


    function filamentCssColor(value) {
        const raw = String(value || '').trim();
        const themeFallback = getComputedStyle(root).getPropertyValue('--muted-color').trim()
            || getComputedStyle(root).getPropertyValue('--text-color').trim();
        if (raw === '') return themeFallback;
        if (/^#?[0-9a-f]{6}$/i.test(raw)) return raw.startsWith('#') ? raw : `#${raw}`;
        if (/^#?[0-9a-f]{8}$/i.test(raw)) {
            const hex = raw.replace('#', '');
            return `#${hex.slice(2, 8)}`;
        }
        if (/^0x[0-9a-f]{6,8}$/i.test(raw)) return `#${raw.slice(-6)}`;
        if (window.CSS && CSS.supports && CSS.supports('color', raw)) return raw;
        return themeFallback;
    }


    function renderCfs(win, cfsData) {
        const panel = win.querySelector('[data-cfs-panel]');
        const slotsBox = win.querySelector('[data-cfs-slots]');
        const sync = win.querySelector('[data-cfs-sync]');
        if (!panel || !slotsBox || !sync) return;

        const source = Array.isArray(cfsData)
            ? {available:cfsData.length > 0, slots:cfsData}
            : (cfsData && typeof cfsData === 'object' ? cfsData : {});
        const slots = Array.isArray(source.slots) ? source.slots : [];
        const external = source.external && typeof source.external === 'object'
            ? source.external
            : {label:'Porte-bobine', present:false, identified:false, active:false, type:'', color:''};
        const available = source.available !== false && (slots.length > 0 || source.state);

        if (!available) {
            panel.classList.add('is-unavailable');
            sync.textContent = 'CFS non détecté';
            slotsBox.innerHTML = '<div class="dmd3d-cfs-empty">Aucune information de filament remontée par l’imprimante.</div>';
            return;
        }

        panel.classList.remove('is-unavailable');
        const syncedAt = Number(source.synced_at || 0);
        sync.textContent = syncedAt > 0
            ? `Synchronisé à ${new Date(syncedAt * 1000).toLocaleTimeString('fr-FR', {hour:'2-digit', minute:'2-digit', second:'2-digit'})}`
            : 'Synchronisé avec l’imprimante';

        const slotMarkup = slot => {
            const present = slot.present === true;
            const identified = present && slot.identified !== false && Boolean(slot.type || slot.color);
            const active = slot.active === true;
            const label = slot.label || '?';
            const type = !present ? 'Vide' : (slot.type || 'Non identifié');
            return `
                <article class="dmd3d-cfs-slot${active ? ' is-active' : ''}${present ? '' : ' is-empty'}${present && !identified ? ' is-unknown' : ''}" data-cfs-color="${esc(slot.color || '')}">
                    <strong class="dmd3d-cfs-slot-label">${esc(label)}</strong>
                    <div class="dmd3d-cfs-spool" aria-hidden="true"><span></span>${present && !identified ? '<b>?</b>' : ''}</div>
                    <small>${esc(type)}</small>
                    ${active ? '<em>Actif</em>' : ''}
                </article>`;
        };

        const groups = new Map();
        slots.forEach((slot, index) => {
            const unit = String(slot.unit || '').trim()
                || ((String(slot.label || '').match(/^(\d+)/) || [])[1] ? `T${String(slot.label).match(/^(\d+)/)[1]}` : 'T1');
            if (!groups.has(unit)) groups.set(unit, []);
            groups.get(unit).push({...slot, _position:index});
        });

        const groupMarkup = [...groups.entries()].map(([unit, unitSlots]) => {
            const number = unit.replace(/\D+/g, '') || '1';
            const title = groups.size > 1 ? `<strong class="dmd3d-cfs-unit-title">CFS ${esc(number)}</strong>` : '';
            return `<section class="dmd3d-cfs-unit">${title}<div class="dmd3d-cfs-unit-slots">${unitSlots.map(slotMarkup).join('')}</div></section>`;
        }).join('');

        const externalPresent = external.present === true;
        const externalIdentified = externalPresent && external.identified !== false && Boolean(external.type || external.color);
        const externalType = !externalPresent ? '—' : (external.type || 'Non identifié');
        const externalMarkup = `
            <article class="dmd3d-cfs-external${external.active === true ? ' is-active' : ''}${externalPresent ? '' : ' is-empty'}${externalPresent && !externalIdentified ? ' is-unknown' : ''}" data-cfs-color="${esc(external.color || '')}">
                <strong>${esc(external.label || 'Porte-bobine')}</strong>
                <div class="dmd3d-cfs-spool dmd3d-cfs-spool-external" aria-hidden="true"><span></span>${!externalIdentified ? '<b>?</b>' : ''}</div>
                <small>${esc(externalType)}</small>
                ${external.active === true ? '<em>Actif</em>' : ''}
            </article>`;

        const meta = [];
        if (source.auto_refill !== null && source.auto_refill !== undefined) {
            meta.push(`<span class="dmd3d-cfs-badge${source.auto_refill ? ' is-on' : ''}">AUTO ${source.auto_refill ? 'ON' : 'OFF'}</span>`);
        }
        if (source.humidity !== null && source.humidity !== undefined && source.humidity !== '') {
            meta.push(`<span class="dmd3d-cfs-badge">💧 ${esc(source.humidity)} %</span>`);
        }
        if (source.temperature !== null && source.temperature !== undefined && source.temperature !== '') {
            meta.push(`<span class="dmd3d-cfs-badge">🌡️ ${esc(source.temperature)} °C</span>`);
        }

        slotsBox.innerHTML = `
            <div class="dmd3d-cfs-layout">
                ${externalMarkup}
                <div class="dmd3d-cfs-banks">
                    ${groupMarkup || '<div class="dmd3d-cfs-empty">Aucun CFS connecté.</div>'}
                    ${meta.length ? `<div class="dmd3d-cfs-meta">${meta.join('')}</div>` : ''}
                </div>
            </div>`;

        slotsBox.querySelectorAll('[data-cfs-color]').forEach(item => {
            const muted = getComputedStyle(root).getPropertyValue('--muted-color').trim() || 'currentColor';
            const fallback = item.classList.contains('is-empty') || item.classList.contains('is-unknown') ? muted : 'currentColor';
            item.style.setProperty('--filament-color', item.dataset.cfsColor ? filamentCssColor(item.dataset.cfsColor) : fallback);
        });
    }

    function renderPrinterFiles(win, files) {
        const safeFiles = Array.isArray(files) ? files : [];
        win._printerFiles = safeFiles;

        const badge = win.querySelector('[data-tool-count="files"]');
        if (badge) badge.textContent = String(safeFiles.length);

        const popup = win._toolPopups instanceof Map ? win._toolPopups.get('files') : null;
        if (!popup) return;

        const body = popup.querySelector('[data-printer-files]');
        const count = popup.querySelector('[data-printer-files-count]');
        if (count) count.textContent = String(safeFiles.length);
        if (!body) return;

        body.innerHTML = safeFiles.length ? safeFiles.map(file => `
            <tr>
                <td data-label="Fichier"><strong>${esc(file.name || file.path || 'Fichier')}</strong><small>${esc(file.path || '')}</small></td>
                <td data-label="Taille">${esc(formatBytes(file.size))}</td>
                <td data-label="Modifié">${esc(formatDate(file.modified))}</td>
                <td data-label="Action"><button type="button" class="dmd3d-button dmd3d-file-start" data-start-file="${esc(file.path || '')}">Imprimer</button></td>
            </tr>`).join('') : '<tr><td colspan="4" class="dmd3d-files-empty">Aucun fichier G-code trouvé dans l’imprimante.</td></tr>';
    }

    function getScrollPad() {
        let pad = document.getElementById('dmd3d-scroll-pad');
        if (!pad) {
            pad = document.createElement('div');
            pad.id = 'dmd3d-scroll-pad';
            pad.setAttribute('aria-hidden', 'true');
            /* Hors du flux : le pad ne doit jamais créer un scroll à lui seul. */
            pad.style.cssText = 'position:absolute;left:0;top:0;width:1px;height:1px;pointer-events:none;visibility:hidden;';
            document.body.appendChild(pad);
        }
        return pad;
    }

    function updateScrollArea() {
        const windows = Array.from(document.querySelectorAll('.dmd3d-window'))
            .filter(item => document.body.contains(item));

        /* Aucune fenêtre détachée = DMD-3DPRINT ne doit pas modifier le scroll du dashboard. */
        if (!windows.length) {
            const oldPad = document.getElementById('dmd3d-scroll-pad');
            if (oldPad) oldPad.remove();
            return;
        }

        const viewportW = document.documentElement.clientWidth;
        const viewportH = document.documentElement.clientHeight;
        let needW = viewportW;
        let needH = viewportH;

        windows.forEach(item => {
            const rect = item.getBoundingClientRect();
            const right = window.scrollX + rect.right + 48;
            const bottom = window.scrollY + rect.bottom + 48;
            needW = Math.max(needW, right);
            needH = Math.max(needH, bottom);
        });

        const pad = getScrollPad();
        /* N'étendre la zone scrollable que si une fenêtre dépasse réellement du viewport. */
        pad.style.width = needW > viewportW ? `${Math.ceil(needW)}px` : '1px';
        pad.style.height = needH > viewportH ? `${Math.ceil(needH)}px` : '1px';
    }

    function watchWindow(win) {
        if (window.ResizeObserver) {
            win._dmd3dResizeObserver = new ResizeObserver(updateScrollArea);
            win._dmd3dResizeObserver.observe(win);
        }
        updateScrollArea();
    }

    function unwatchWindow(win) {
        if (win && win._dmd3dResizeObserver) {
            win._dmd3dResizeObserver.disconnect();
            win._dmd3dResizeObserver = null;
        }
        setTimeout(updateScrollArea, 0);
    }

    function bringToFront(win) {
        win.style.zIndex = String(++state.z);
    }

    function makeDraggable(win) {
        const head = win.querySelector('[data-window-head]');
        let drag = null;
        head.addEventListener('pointerdown', event => {
            if (event.target.closest('button,select,input')) return;
            bringToFront(win);
            const rect = win.getBoundingClientRect();
            drag = {x:event.clientX - rect.left, y:event.clientY - rect.top};
            head.setPointerCapture(event.pointerId);
        });
        head.addEventListener('pointermove', event => {
            if (!drag) return;
            const left = Math.max(0, event.clientX - drag.x + window.scrollX);
            const top = Math.max(0, event.clientY - drag.y + window.scrollY);
            win.style.left = `${left}px`;
            win.style.top = `${top}px`;
            updateScrollArea();
        });
        const stop = event => { if (drag && head.hasPointerCapture(event.pointerId)) head.releasePointerCapture(event.pointerId); drag = null; updateScrollArea(); };
        head.addEventListener('pointerup', stop);
        head.addEventListener('pointercancel', stop);
        win.addEventListener('pointerdown', () => bringToFront(win));
    }

    function stopCamera(win) {
        closeCameraPopup(win);
        if (win._cameraTimeout) {
            clearTimeout(win._cameraTimeout);
            win._cameraTimeout = null;
        }
        if (win._cameraPeer) {
            try {
                win._cameraPeer.ontrack = null;
                win._cameraPeer.onconnectionstatechange = null;
                win._cameraPeer.oniceconnectionstatechange = null;
                win._cameraPeer.close();
            } catch (error) {}
            win._cameraPeer = null;
        }
        win._cameraPrinterId = '';
        win._cameraTransport = '';
        const video = win.querySelector('[data-camera] video');
        if (video) {
            try { video.pause(); } catch (error) {}
            video.onloadeddata = null;
            video.onplaying = null;
            video.onerror = null;
            video.srcObject = null;
            video.removeAttribute('src');
            video.hidden = true;
        }
    }

    function closeCameraPopup(win) {
        const popup = win._cameraPopup;
        if (!popup) return;

        const popupVideo = popup.querySelector('video');
        if (popupVideo) {
            try { popupVideo.pause(); } catch (error) {}
            popupVideo.srcObject = null;
            popupVideo.removeAttribute('src');
        }

        unwatchWindow(popup);
        popup.remove();
        win._cameraPopup = null;
    }

    function openCameraPopup(win) {
        const sourceVideo = win.querySelector('[data-camera] video');
        if (!sourceVideo || sourceVideo.hidden || (!sourceVideo.srcObject && !sourceVideo.currentSrc && !sourceVideo.src)) {
            statusMessage(win, 'La caméra doit être connectée avant de pouvoir l’agrandir.', true);
            return;
        }

        if (win._cameraPopup && document.body.contains(win._cameraPopup)) {
            bringToFront(win._cameraPopup);
            return;
        }

        const popup = document.createElement('section');
        popup.className = 'dmd3d-window dmd3d-camera-window';
        const popupWidth = Math.min(1180, Math.max(520, window.innerWidth - 80));
        const popupHeight = Math.min(760, Math.max(390, window.innerHeight - 100));
        popup.style.width = `${popupWidth}px`;
        popup.style.height = `${popupHeight}px`;
        popup.style.left = `${Math.max(10, window.scrollX + (window.innerWidth - popupWidth) / 2)}px`;
        popup.style.top = `${Math.max(10, window.scrollY + (window.innerHeight - popupHeight) / 2)}px`;
        popup.innerHTML = `
            <header class="dmd3d-window-head" data-window-head>
                <div><strong>Caméra intérieure</strong><small>Vue agrandie — pas de plein écran</small></div>
                <button type="button" class="dmd3d-close" data-close-camera-popup>✕</button>
            </header>
            <div class="dmd3d-camera-window-body">
                <video controls muted autoplay playsinline controlsList="nofullscreen nodownload noremoteplayback"></video>
            </div>`;

        document.body.appendChild(popup);
        win._cameraPopup = popup;
        makeDraggable(popup);
        watchWindow(popup);
        bringToFront(popup);

        const popupVideo = popup.querySelector('video');
        if (sourceVideo.srcObject) {
            popupVideo.srcObject = sourceVideo.srcObject;
        } else {
            popupVideo.src = sourceVideo.currentSrc || sourceVideo.src;
        }
        try { popupVideo.currentTime = sourceVideo.currentTime || 0; } catch (error) {}
        popupVideo.play().catch(() => {});

        popup.querySelector('[data-close-camera-popup]').addEventListener('click', () => closeCameraPopup(win));
    }

    function bindCameraPopup(win) {
        const sourceVideo = win.querySelector('[data-camera] video');
        const enlargeButton = win.querySelector('[data-camera-popout]');

        enlargeButton.addEventListener('click', () => openCameraPopup(win));

        sourceVideo.addEventListener('webkitbeginfullscreen', event => {
            if (event.cancelable) event.preventDefault();
            setTimeout(() => openCameraPopup(win), 0);
        });

        const fullscreenHandler = () => {
            if (document.fullscreenElement !== sourceVideo) return;
            document.exitFullscreen()
                .catch(() => {})
                .finally(() => openCameraPopup(win));
        };

        document.addEventListener('fullscreenchange', fullscreenHandler);
        win._cameraFullscreenHandler = fullscreenHandler;
    }

    function toolMessage(popup, text, error = false) {
        const el = popup.querySelector('[data-tool-message]');
        if (!el) return;
        el.textContent = text || '';
        el.classList.toggle('is-error', error);
    }

    function closeToolPopup(win, type) {
        if (!(win._toolPopups instanceof Map)) return;
        const popup = win._toolPopups.get(type);
        if (!popup) return;
        unwatchWindow(popup);
        popup.remove();
        win._toolPopups.delete(type);
    }

    function closeAllToolPopups(win) {
        if (!(win._toolPopups instanceof Map)) return;
        [...win._toolPopups.keys()].forEach(type => closeToolPopup(win, type));
    }

    function selectedPrinterId(win) {
        return win.querySelector('[data-printer-select]')?.value || '';
    }

    function selectedPlugId(win) {
        return win.querySelector('[data-plug-select]')?.value || '';
    }

    function updatePrintToolPopup(win) {
        const popup = win._toolPopups instanceof Map ? win._toolPopups.get('print') : null;
        if (!popup) return;
        const s = win._printerStatus || {};
        const current = popup.querySelector('[data-tool-current-file]');
        const progress = popup.querySelector('[data-tool-progress]');
        const label = popup.querySelector('[data-tool-progress-label]');
        if (current) current.textContent = s.file || s.filename || s.current_file || 'Aucun fichier en cours';
        const rawProgress = Number(s.progress ?? s.percent ?? 0);
        const percent = Math.max(0, Math.min(100, rawProgress * (rawProgress <= 1 ? 100 : 1)));
        if (progress) progress.value = percent;
        if (label) label.textContent = `${Math.round(percent)} %`;
    }

    const fanCatalog = [
        {id:'part', label:'Ventilateur de pièce', icon:'🌀', aliases:['part','PART']},
        {id:'aux', label:'Ventilateur auxiliaire', icon:'💨', aliases:['aux','AUX']},
        {id:'chamber', label:'Ventilateur de chambre', icon:'🌡️', aliases:['chamber','CHAMBER']},
        {id:'filter', label:'Ventilateur de filtration', icon:'🧼', aliases:['filter','FILTER']}
    ];

    function fanValueFromStatus(fans, definition) {
        return definition.aliases.map(key => fans[key]).find(value => value !== undefined && value !== null);
    }

    function updateFanToolPopup(win) {
        const popup = win._toolPopups instanceof Map ? win._toolPopups.get('fans') : null;
        if (!popup) return;
        const list = popup.querySelector('[data-fan-list]');
        if (!list) return;
        const fans = win._printerStatus?.fans || {};
        let available = fanCatalog.filter(definition => fanValueFromStatus(fans, definition) !== undefined);
        if (!available.length) available = fanCatalog.slice(0, 3);
        const signature = available.map(item => item.id).join('|');

        if (list.dataset.signature !== signature) {
            list.dataset.signature = signature;
            list.innerHTML = available.map(definition => `
                <article class="dmd3d-fan-control" data-fan-row="${esc(definition.id)}">
                    <div class="dmd3d-fan-control-head">
                        <span class="dmd3d-fan-icon">${definition.icon}</span>
                        <strong>${esc(definition.label)}</strong>
                        <output data-fan-output>0 %</output>
                    </div>
                    <input type="range" min="0" max="100" step="1" value="0" data-fan-range data-fan="${esc(definition.id)}" aria-label="${esc(definition.label)}">
                    <small>La commande est envoyée quand tu relâches le curseur.</small>
                </article>`).join('');
        }

        available.forEach(definition => {
            const row = list.querySelector(`[data-fan-row="${definition.id}"]`);
            if (!row) return;
            const range = row.querySelector('[data-fan-range]');
            const output = row.querySelector('[data-fan-output]');
            const raw = fanValueFromStatus(fans, definition);
            const percent = Math.max(0, Math.min(100, Number(raw) || 0));
            if (document.activeElement !== range) range.value = String(percent);
            output.textContent = `${Math.round(Number(range.value) || percent)} %`;
        });
    }

    function updateLightToolPopup(win) {
        const popup = win._toolPopups instanceof Map ? win._toolPopups.get('light') : null;
        const mainState = win.querySelector('[data-tool-light-state]');
        const s = win._printerStatus || {};
        const raw = s.light_on ?? s.light?.on ?? s.light ?? null;
        const known = raw !== null && raw !== undefined && raw !== '';
        const isOn = raw === true || raw === 1 || String(raw).toLowerCase() === 'on';
        const text = known ? (isOn ? 'Allumée' : 'Éteinte') : 'État indisponible';
        if (mainState) mainState.textContent = text;
        if (!popup) return;
        const stateLabel = popup.querySelector('[data-light-state]');
        const toggle = popup.querySelector('[data-light-toggle]');
        if (stateLabel) stateLabel.textContent = text;
        if (toggle) {
            toggle.dataset.on = isOn ? '1' : '0';
            toggle.setAttribute('aria-pressed', isOn ? 'true' : 'false');
            toggle.classList.toggle('is-on', isOn);
            const label = toggle.querySelector('b');
            if (label) label.textContent = isOn ? 'Éteindre' : 'Allumer';
        }
    }

    function plugDetailValue(item) {
        if (!item || item.value === null || item.value === undefined || item.value === '') return '—';
        const value = typeof item.value === 'boolean' ? (item.value ? 'Oui' : 'Non') : String(item.value);
        const unit = String(item.unit || '').trim();
        return unit !== '' ? `${value} ${unit}` : value;
    }

    function renderPlugDetails(popup, sections) {
        const target = popup.querySelector('[data-plug-details]');
        if (!target) return;

        const safeSections = Array.isArray(sections) ? sections : [];
        if (!safeSections.length) {
            target.innerHTML = '<div class="dmd3d-empty">Aucune information détaillée supplémentaire n’est remontée par cette prise.</div>';
            return;
        }

        target.innerHTML = safeSections.map(section => {
            const items = Array.isArray(section.items) ? section.items : [];
            if (!items.length) return '';
            const icon = section.icon || 'ℹ️';
            return `
                <section class="dmd3d-plug-detail-section">
                    <div class="dmd3d-section-title">
                        <h3>${esc(icon)} ${esc(section.title || 'Informations')}</h3>
                        <span class="dmd3d-count">${items.length}</span>
                    </div>
                    <div class="dmd3d-electric-grid">
                        ${items.map(item => `
                            <article>
                                <span>•</span>
                                <div>
                                    <small>${esc(item.label || 'Information')}</small>
                                    <strong>${esc(plugDetailValue(item))}</strong>
                                </div>
                            </article>`).join('')}
                    </div>
                </section>`;
        }).join('');
    }

    function updatePlugToolPopup(win) {
        const popup = win._toolPopups instanceof Map ? win._toolPopups.get('plug') : null;
        const mainState = win.querySelector('[data-tool-plug-state]');
        const plugId = selectedPlugId(win);
        const plug = state.plugs.find(item => item.id === plugId) || null;
        const s = win._plugStatus || {};

        let stateText = 'Aucune prise';
        let isOn = false;
        if (plugId) {
            isOn = s.power === true || String(s.state || '').toLowerCase() === 'on';
            stateText = isOn
                ? 'Allumée'
                : (s.power === false || String(s.state || '').toLowerCase() === 'off' ? 'Éteinte' : (s.state || 'Connectée'));
        }
        if (mainState) mainState.textContent = stateText;
        if (!popup) return;

        const set = (selector, value) => {
            const el = popup.querySelector(selector);
            if (el) el.textContent = value;
        };
        set('[data-plug-name]', plug?.name || 'Aucune prise sélectionnée');
        set('[data-plug-model]', plug ? ([plug.brand, plug.device_model].filter(Boolean).join(' ') || plug.model || '') : '');
        set('[data-plug-state]', stateText);
        set('[data-voltage]', plugId ? metric(s.voltage ?? s.volts, ' V') : '—');
        set('[data-power]', plugId ? metric(s.power_w ?? s.watts ?? s.power, ' W') : '—');
        set('[data-current]', plugId ? metric(s.current ?? s.amps, ' A') : '—');
        set('[data-apparent-power]', plugId ? metric(s.apparent_power, ' VA') : '—');
        set('[data-reactive-power]', plugId ? metric(s.reactive_power, ' var') : '—');
        set('[data-factor]', plugId ? metric(s.factor, '') : '—');
        set('[data-frequency]', plugId ? metric(s.frequency, ' Hz') : '—');
        set('[data-energy]', plugId ? metric(s.energy_total ?? s.energy ?? s.energy_kwh ?? s.consumption, ' kWh') : '—');
        set('[data-energy-today]', plugId ? metric(s.energy_today ?? s.today, ' kWh') : '—');
        set('[data-energy-yesterday]', plugId ? metric(s.energy_yesterday ?? s.yesterday, ' kWh') : '—');
        set('[data-energy-period]', plugId ? metric(s.energy_period ?? s.period, ' Wh') : '—');
        set('[data-measurement-time]', plugId ? (s.measurement_time || '—') : '—');
        set('[data-uptime]', plugId ? (s.uptime || (s.uptime_seconds !== null && s.uptime_seconds !== undefined ? `${s.uptime_seconds} s` : '—')) : '—');
        set('[data-ip-address]', plugId ? (s.ip_address || '—') : '—');
        set('[data-wifi]', plugId ? [s.wifi_ssid, s.wifi_rssi !== null && s.wifi_rssi !== undefined ? `${s.wifi_rssi} %` : '', s.wifi_signal !== null && s.wifi_signal !== undefined ? `${s.wifi_signal} dBm` : ''].filter(Boolean).join(' · ') || '—' : '—');
        set('[data-firmware]', plugId ? [s.firmware_version, s.hardware].filter(Boolean).join(' · ') || '—' : '—');

        renderPlugDetails(popup, s.details_sections);

        const image = popup.querySelector('[data-plug-image]');
        if (image) {
            const source = modelImageUrl('plug', plug);
            if (source) {
                image.hidden = false;
                if (image.getAttribute('src') !== source) image.src = source;
            } else {
                image.hidden = true;
                image.removeAttribute('src');
            }
        }

        const toggle = popup.querySelector('[data-plug-toggle]');
        if (toggle) {
            toggle.disabled = !plugId;
            toggle.dataset.on = isOn ? '1' : '0';
            toggle.setAttribute('aria-pressed', isOn ? 'true' : 'false');
            toggle.classList.toggle('is-on', isOn);
            const label = toggle.querySelector('b');
            if (label) label.textContent = isOn ? 'Éteindre la prise' : 'Allumer la prise';
        }
    }


    function renderPrinterDetails(popup, sections) {
        const target = popup.querySelector('[data-printer-info-details]');
        if (!target) return;

        const safeSections = Array.isArray(sections) ? sections : [];
        if (!safeSections.length) {
            target.innerHTML = '<div class="dmd3d-empty">Aucune information détaillée n’est remontée par le pilote de cette imprimante.</div>';
            return;
        }

        target.innerHTML = safeSections.map(section => {
            const items = Array.isArray(section.items) ? section.items : [];
            if (!items.length) return '';
            const icon = section.icon || 'ℹ️';
            return `
                <section class="dmd3d-plug-detail-section">
                    <div class="dmd3d-section-title">
                        <h3>${esc(icon)} ${esc(section.title || 'Informations')}</h3>
                        <span class="dmd3d-count">${items.length}</span>
                    </div>
                    <div class="dmd3d-electric-grid">
                        ${items.map(item => `
                            <article>
                                <span>•</span>
                                <div>
                                    <small>${esc(item.label || 'Information')}</small>
                                    <strong>${esc(plugDetailValue(item))}</strong>
                                </div>
                            </article>`).join('')}
                    </div>
                </section>`;
        }).join('');
    }

    async function loadPrinterInfoPopup(win, popup) {
        const printerId = selectedPrinterId(win);
        if (!printerId || !popup) return;

        const printer = state.printers.find(item => item.id === printerId) || null;
        const set = (selector, value) => {
            const el = popup.querySelector(selector);
            if (el) el.textContent = value || '—';
        };

        set('[data-printer-info-name]', printer?.name || 'Imprimante');
        set('[data-printer-info-model]', printer ? ([printer.brand, printer.device_model].filter(Boolean).join(' ') || printer.model || '') : '');
        set('[data-printer-info-state]', 'Chargement…');
        renderPrinterDetails(popup, []);
        toolMessage(popup, 'Récupération des informations complètes de l’imprimante…');

        const image = popup.querySelector('[data-printer-info-image]');
        if (image) {
            const source = modelImageUrl('printer', printer);
            if (source) {
                image.hidden = false;
                if (image.getAttribute('src') !== source) image.src = source;
            } else {
                image.hidden = true;
                image.removeAttribute('src');
            }
        }

        try {
            const data = await request(`printer_details&printer_id=${encodeURIComponent(printerId)}`);
            const details = data.details && typeof data.details === 'object' ? data.details : {};
            const summary = details.summary && typeof details.summary === 'object' ? details.summary : {};

            set('[data-printer-info-name]', summary.name || printer?.name || 'Imprimante');
            set('[data-printer-info-model]', summary.model || ([printer?.brand, printer?.device_model].filter(Boolean).join(' ') || printer?.model || ''));
            set('[data-printer-info-state]', summary.state || 'En ligne');
            renderPrinterDetails(popup, details.details_sections);

            const sectionCount = Array.isArray(details.details_sections) ? details.details_sections.length : 0;
            toolMessage(popup, `${sectionCount} rubrique${sectionCount > 1 ? 's' : ''} d’informations chargée${sectionCount > 1 ? 's' : ''}.`);
        } catch (error) {
            set('[data-printer-info-state]', 'Indisponible');
            renderPrinterDetails(popup, []);
            toolMessage(popup, error.message, true);
        }
    }

    function toolPopupDefinition(type) {
        const definitions = {
            upload: {
                title: 'Envoyer un fichier',
                subtitle: 'Fichiers d’impression et modèles 3D',
                className: 'dmd3d-tool-upload',
                width: 620,
                height: 450,
                content: `
                    <div class="dmd3d-format-info">
                        <article><span>✅</span><div><strong>G-code</strong><small>.gcode, .gco et .gc — prêt à envoyer et à imprimer.</small></div></article>
                        <article><span>📦</span><div><strong>3MF</strong><small>Projet d’impression : selon son contenu, il peut encore nécessiter un découpage.</small></div></article>
                        <article><span>🧊</span><div><strong>STL</strong><small>Modèle 3D uniquement : il doit être découpé par un slicer avant impression.</small></div></article>
                    </div>
                    <form data-upload-form enctype="multipart/form-data" class="dmd3d-tool-form">
                        <div class="dmd3d-field"><label>Fichier</label><input type="file" name="print_file" accept=".stl,.3mf,.gcode,.gco,.gc" required></div>
                        <div class="dmd3d-upload-file-state" data-upload-file-state>Sélectionne un fichier.</div>
                        <label class="dmd3d-checkbox"><input type="checkbox" name="start_after_upload"> Démarrer après l’envoi</label>
                        <button type="submit" class="dmd3d-button">Envoyer à l’imprimante</button>
                    </form>`
            },
            print: {
                title: 'Contrôler l’impression',
                subtitle: 'Pause, reprise et arrêt',
                className: 'dmd3d-tool-print',
                width: 500,
                height: 330,
                content: `
                    <strong class="dmd3d-current-file" data-tool-current-file>Aucun fichier en cours</strong>
                    <progress class="dmd3d-progress" data-tool-progress max="100" value="0"></progress>
                    <div class="dmd3d-progress-line"><strong data-tool-progress-label>0 %</strong></div>
                    <div class="dmd3d-button-grid">
                        <button type="button" class="dmd3d-button" data-printer-command="pause">Pause</button>
                        <button type="button" class="dmd3d-button" data-printer-command="resume">Reprendre</button>
                        <button type="button" class="dmd3d-button dmd3d-danger" data-printer-command="stop">Arrêter</button>
                    </div>`
            },
            light: {
                title: 'Lumière intérieure',
                subtitle: 'État et commande de l’éclairage',
                className: 'dmd3d-tool-light',
                width: 460,
                height: 250,
                content: `
                    <div class="dmd3d-power-card">
                        <span class="dmd3d-power-card-icon">💡</span>
                        <div><small>Éclairage intérieur</small><strong data-light-state>État indisponible</strong></div>
                        <button type="button" class="dmd3d-power-toggle" data-light-toggle aria-pressed="false"><span></span><b>Allumer</b></button>
                    </div>`
            },
            fans: {
                title: 'Ventilateurs',
                subtitle: 'Réglage direct de chaque ventilateur',
                className: 'dmd3d-tool-fans',
                width: 620,
                height: 440,
                content: `<div class="dmd3d-fan-list" data-fan-list><p class="dmd3d-empty">Chargement des ventilateurs…</p></div>`
            },
            files: {
                title: 'Fichiers de l’imprimante',
                subtitle: 'Bibliothèque G-code complète',
                className: 'dmd3d-tool-files',
                width: 920,
                height: 620,
                content: `
                    <div class="dmd3d-section-title"><h3>Fichiers disponibles</h3><span class="dmd3d-count" data-printer-files-count>0</span></div>
                    <div class="dmd3d-files-wrap"><table class="dmd3d-files-table"><thead><tr><th>Fichier</th><th>Taille</th><th>Modifié</th><th>Action</th></tr></thead><tbody data-printer-files><tr><td colspan="4" class="dmd3d-files-empty">Chargement…</td></tr></tbody></table></div>`
            },
            printer_info: {
                title: 'Informations de l’imprimante',
                subtitle: 'État, matériel, firmware, configuration et impression',
                className: 'dmd3d-tool-printer-info',
                width: 1120,
                height: 760,
                content: `
                    <div class="dmd3d-plug-hero">
                        <img alt="Modèle de l’imprimante" data-printer-info-image data-model-image hidden>
                        <div><strong data-printer-info-name>Imprimante</strong><small data-printer-info-model></small><span class="dmd3d-status" data-printer-info-state>Chargement…</span></div>
                        <button type="button" class="dmd3d-button" data-refresh-printer-info>↻ Actualiser</button>
                    </div>
                    <div data-printer-info-details><div class="dmd3d-empty">Chargement des informations de l’imprimante…</div></div>`
            },
            plug: {
                title: 'Prise connectée',
                subtitle: 'Toutes les informations disponibles',
                className: 'dmd3d-tool-plug',
                width: 1040,
                height: 720,
                content: `
                    <div class="dmd3d-plug-hero">
                        <img alt="Modèle de la prise" data-plug-image data-model-image hidden>
                        <div><strong data-plug-name>Aucune prise sélectionnée</strong><small data-plug-model></small><span class="dmd3d-status" data-plug-state>—</span></div>
                        <button type="button" class="dmd3d-power-toggle dmd3d-plug-toggle" data-plug-toggle aria-pressed="false"><span></span><b>Allumer la prise</b></button>
                    </div>
                    <div class="dmd3d-section-title"><h3>Résumé électrique</h3></div>
                    <div class="dmd3d-electric-grid dmd3d-plug-metrics">
                        <article><span>⚡</span><div><small>Tension</small><strong data-voltage>—</strong></div></article>
                        <article><span>💡</span><div><small>Puissance active</small><strong data-power>—</strong></div></article>
                        <article><span>🔌</span><div><small>Intensité</small><strong data-current>—</strong></div></article>
                        <article><span>🔺</span><div><small>Puissance apparente</small><strong data-apparent-power>—</strong></div></article>
                        <article><span>〰️</span><div><small>Puissance réactive</small><strong data-reactive-power>—</strong></div></article>
                        <article><span>📐</span><div><small>Facteur de puissance</small><strong data-factor>—</strong></div></article>
                        <article><span>〽️</span><div><small>Fréquence</small><strong data-frequency>—</strong></div></article>
                        <article><span>📊</span><div><small>Consommation totale</small><strong data-energy>—</strong></div></article>
                        <article><span>📅</span><div><small>Aujourd’hui</small><strong data-energy-today>—</strong></div></article>
                        <article><span>🗓️</span><div><small>Hier</small><strong data-energy-yesterday>—</strong></div></article>
                        <article><span>⏲️</span><div><small>Depuis la dernière mesure</small><strong data-energy-period>—</strong></div></article>
                        <article><span>🕒</span><div><small>Date de la mesure</small><strong data-measurement-time>—</strong></div></article>
                        <article><span>⏱️</span><div><small>Fonctionnement</small><strong data-uptime>—</strong></div></article>
                        <article><span>🌐</span><div><small>Adresse IP</small><strong data-ip-address>—</strong></div></article>
                        <article><span>📶</span><div><small>Wi-Fi</small><strong data-wifi>—</strong></div></article>
                        <article><span>🧩</span><div><small>Firmware et matériel</small><strong data-firmware>—</strong></div></article>
                    </div>
                    <div data-plug-details></div>`
            }
        };
        return definitions[type] || null;
    }

    function positionToolPopup(win, popup, definition) {
        const mainRect = win.getBoundingClientRect();
        const width = Math.min(definition.width, Math.max(340, window.innerWidth - 30));
        const height = Math.min(definition.height, Math.max(250, window.innerHeight - 40));
        const cascade = win._toolPopups.size * 24;
        popup.style.width = `${width}px`;
        popup.style.height = `${height}px`;
        popup.style.left = `${Math.max(8, window.scrollX + mainRect.left + 55 + cascade)}px`;
        popup.style.top = `${Math.max(8, window.scrollY + mainRect.top + 55 + cascade)}px`;
    }

    async function runPrinterCommand(win, popup, button) {
        const printerId = selectedPrinterId(win);
        if (!printerId) return;
        const command = button.dataset.printerCommand;
        if (command === 'stop' && !confirm('Arrêter l’impression en cours ?')) return;
        button.disabled = true;
        try {
            await sendJson('printer_command', {printer_id:printerId, command});
            toolMessage(popup, 'Commande envoyée.');
            statusMessage(win, 'Commande envoyée.');
            setTimeout(() => refreshPrinter(win), 500);
        } catch (error) {
            toolMessage(popup, error.message, true);
            statusMessage(win, error.message, true);
        } finally {
            button.disabled = false;
        }
    }

    function bindToolPopup(win, popup, type) {
        popup.querySelector('[data-close-tool-popup]').addEventListener('click', () => closeToolPopup(win, type));


        const refreshPrinterInfo = popup.querySelector('[data-refresh-printer-info]');
        if (refreshPrinterInfo) {
            refreshPrinterInfo.addEventListener('click', () => loadPrinterInfoPopup(win, popup));
        }

        popup.querySelectorAll('[data-printer-command]').forEach(button => {
            button.addEventListener('click', () => runPrinterCommand(win, popup, button));
        });

        const fanList = popup.querySelector('[data-fan-list]');
        if (fanList) {
            fanList.addEventListener('input', event => {
                const range = event.target.closest('[data-fan-range]');
                if (!range) return;
                const row = range.closest('[data-fan-row]');
                const output = row?.querySelector('[data-fan-output]');
                if (output) output.textContent = `${range.value} %`;
            });
            fanList.addEventListener('change', async event => {
                const range = event.target.closest('[data-fan-range]');
                if (!range) return;
                const printerId = selectedPrinterId(win);
                if (!printerId) return;
                range.disabled = true;
                try {
                    await sendJson('printer_command', {
                        printer_id:printerId,
                        command:'fan',
                        fan:range.dataset.fan,
                        value:Number(range.value)
                    });
                    toolMessage(popup, `${range.closest('[data-fan-row]')?.querySelector('strong')?.textContent || 'Ventilateur'} : ${range.value} %.`);
                    statusMessage(win, 'Vitesse du ventilateur envoyée.');
                    setTimeout(() => refreshPrinter(win), 450);
                } catch (error) {
                    toolMessage(popup, error.message, true);
                    statusMessage(win, error.message, true);
                } finally {
                    range.disabled = false;
                }
            });
        }

        const lightToggle = popup.querySelector('[data-light-toggle]');
        if (lightToggle) {
            lightToggle.addEventListener('click', async () => {
                const printerId = selectedPrinterId(win);
                if (!printerId) return;
                const isOn = lightToggle.dataset.on === '1';
                lightToggle.disabled = true;
                try {
                    await sendJson('printer_command', {printer_id:printerId, command:isOn ? 'light_off' : 'light_on'});
                    toolMessage(popup, isOn ? 'Lumière éteinte.' : 'Lumière allumée.');
                    statusMessage(win, isOn ? 'Lumière éteinte.' : 'Lumière allumée.');
                    win._printerStatus = {...(win._printerStatus || {}), light_on:!isOn};
                    updateLightToolPopup(win);
                    setTimeout(() => refreshPrinter(win), 500);
                } catch (error) {
                    toolMessage(popup, error.message, true);
                    statusMessage(win, error.message, true);
                } finally {
                    lightToggle.disabled = false;
                }
            });
        }

        const filesBody = popup.querySelector('[data-printer-files]');
        if (filesBody) {
            filesBody.addEventListener('click', async event => {
                const button = event.target.closest('[data-start-file]');
                if (!button) return;
                const printerId = selectedPrinterId(win);
                const file = button.dataset.startFile || '';
                if (!printerId || !file) return;
                if (!confirm(`Lancer l’impression de « ${file} » ?`)) return;
                button.disabled = true;
                try {
                    await sendJson('printer_command', {printer_id:printerId, command:'start', file});
                    toolMessage(popup, `Impression lancée : ${file}`);
                    statusMessage(win, `Impression lancée : ${file}`);
                    setTimeout(() => refreshPrinter(win), 700);
                } catch (error) {
                    toolMessage(popup, error.message, true);
                    statusMessage(win, error.message, true);
                } finally {
                    button.disabled = false;
                }
            });
        }

        const plugToggle = popup.querySelector('[data-plug-toggle]');
        if (plugToggle) {
            plugToggle.addEventListener('click', async () => {
                const plugId = selectedPlugId(win);
                if (!plugId) {
                    toolMessage(popup, 'Aucune prise sélectionnée.', true);
                    return;
                }
                const isOn = plugToggle.dataset.on === '1';
                if (isOn && !confirm('Éteindre la prise ? Vérifie qu’aucune impression n’est en cours.')) return;
                plugToggle.disabled = true;
                try {
                    await sendJson('plug_command', {plug_id:plugId, command:isOn ? 'power_off' : 'power_on'});
                    toolMessage(popup, isOn ? 'Prise éteinte.' : 'Prise allumée.');
                    statusMessage(win, isOn ? 'Prise éteinte.' : 'Prise allumée.');
                    win._plugStatus = {...(win._plugStatus || {}), state:isOn ? 'off' : 'on', power:!isOn};
                    updatePlugToolPopup(win);
                    setTimeout(() => refreshPlug(win), 500);
                } catch (error) {
                    toolMessage(popup, error.message, true);
                    statusMessage(win, error.message, true);
                } finally {
                    plugToggle.disabled = false;
                }
            });
        }

        const uploadForm = popup.querySelector('[data-upload-form]');
        if (uploadForm) {
            const fileInput = uploadForm.elements.print_file;
            const startCheckbox = uploadForm.elements.start_after_upload;
            const fileState = popup.querySelector('[data-upload-file-state]');
            const updateSelectedFile = () => {
                const file = fileInput.files && fileInput.files[0] ? fileInput.files[0] : null;
                const extension = file ? String(file.name.split('.').pop() || '').toLowerCase() : '';
                const printable = ['gcode','gco','gc'].includes(extension);
                startCheckbox.disabled = !printable;
                if (!printable) startCheckbox.checked = false;
                if (!file) fileState.textContent = 'Sélectionne un fichier.';
                else if (printable) fileState.textContent = '✅ G-code prêt à être envoyé et éventuellement démarré.';
                else if (extension === 'stl') fileState.textContent = '🧊 STL : envoi possible, mais conversion en G-code nécessaire avant impression.';
                else if (extension === '3mf') fileState.textContent = '📦 3MF : envoi possible, mais ce projet peut nécessiter un découpage avant impression.';
                else fileState.textContent = 'Format non reconnu.';
            };
            fileInput.addEventListener('change', updateSelectedFile);
            updateSelectedFile();
            uploadForm.addEventListener('submit', async event => {
                event.preventDefault();
                const printerId = selectedPrinterId(win);
                if (!printerId) return;
                const button = uploadForm.querySelector('button[type="submit"]');
                const body = new FormData(uploadForm);
                body.set('printer_id', printerId);
                body.set('csrf', state.csrf);
                body.set('start_after_upload', uploadForm.elements.start_after_upload.checked ? '1' : '0');
                button.disabled = true;
                toolMessage(popup, 'Envoi du fichier en cours…');
                statusMessage(win, 'Envoi du fichier en cours…');
                try {
                    const data = await request('upload_print_file', {method:'POST', body});
                    const message = `${data.file?.name || 'Fichier'} envoyé à l’imprimante.`;
                    toolMessage(popup, message);
                    statusMessage(win, message);
                    uploadForm.reset();
                    setTimeout(() => refreshPrinter(win), 700);
                } catch (error) {
                    toolMessage(popup, error.message, true);
                    statusMessage(win, error.message, true);
                } finally {
                    button.disabled = false;
                }
            });
        }
    }

    function openToolPopup(win, type) {
        if (!(win._toolPopups instanceof Map)) win._toolPopups = new Map();
        const existing = win._toolPopups.get(type);
        if (existing && document.body.contains(existing)) {
            bringToFront(existing);
            return;
        }

        const definition = toolPopupDefinition(type);
        if (!definition) return;
        const printer = state.printers.find(item => item.id === selectedPrinterId(win));
        const popup = document.createElement('section');
        popup.className = `dmd3d-window dmd3d-tool-window ${definition.className}`;
        popup.innerHTML = `
            <header class="dmd3d-window-head" data-window-head>
                <div><strong>${esc(definition.title)}</strong><small>${esc(printer?.name || '')} — ${esc(definition.subtitle)}</small></div>
                <button type="button" class="dmd3d-close" data-close-tool-popup>✕</button>
            </header>
            <div class="dmd3d-tool-window-body">
                ${definition.content}
                <div class="dmd3d-inline-message" data-tool-message aria-live="polite"></div>
            </div>`;

        document.body.appendChild(popup);
        win._toolPopups.set(type, popup);
        positionToolPopup(win, popup, definition);
        makeDraggable(popup);
        watchWindow(popup);
        bringToFront(popup);
        bindToolPopup(win, popup, type);
        bindModelImages(popup);

        if (type === 'files') renderPrinterFiles(win, win._printerFiles || []);
        if (type === 'fans') updateFanToolPopup(win);
        if (type === 'print') updatePrintToolPopup(win);
        if (type === 'light') updateLightToolPopup(win);
        if (type === 'plug') updatePlugToolPopup(win);
        if (type === 'printer_info') loadPrinterInfoPopup(win, popup);
    }

    function encodeBase64Json(value) {
        return btoa(unescape(encodeURIComponent(JSON.stringify(value))));
    }

    function decodeBase64Json(value) {
        return JSON.parse(decodeURIComponent(escape(atob(value))));
    }

    function webRtcCameraEndpoint(endpoint = '') {
        const raw = String(endpoint || '').trim();
        if (raw === '') return '';
        try {
            return new URL(raw, window.location.href).toString();
        } catch (error) {
            return '';
        }
    }

    async function postWebRtcOfferDirect(endpoint, offer) {
        const response = await fetch(endpoint, {
            method: 'POST',
            mode: 'cors',
            cache: 'no-store',
            credentials: 'omit',
            headers: {'Content-Type': 'text/plain'},
            body: offer
        });

        const answer = (await response.text()).trim();
        if (!response.ok) throw new Error(`caméra HTTP ${response.status}`);
        if (answer === '') throw new Error('réponse WebRTC vide');
        return answer;
    }

    async function startWebRtcCamera(win, printerId, cameraEndpoint = '') {
        const box = win.querySelector('[data-camera]');
        const empty = win.querySelector('[data-camera-empty]');
        const video = box.querySelector('video');

        if (
            win._cameraPeer
            && win._cameraPrinterId === printerId
            && ['new', 'connecting', 'connected'].includes(win._cameraPeer.connectionState)
        ) return;

        stopCamera(win);
        win._cameraPrinterId = printerId;
        empty.hidden = false;
        empty.textContent = 'Connexion directe à la caméra…';
        video.hidden = true;

        const endpoint = webRtcCameraEndpoint(cameraEndpoint);
        const peer = new RTCPeerConnection({
            iceServers: [{urls: 'stun:stun.l.google.com:19302'}]
        });
        win._cameraPeer = peer;

        let streamReceived = false;
        const showVideo = () => {
            if (win._cameraPeer !== peer) return;
            streamReceived = true;
            video.hidden = false;
            empty.hidden = true;
        };

        video.onloadeddata = showVideo;
        video.onplaying = showVideo;
        video.onerror = () => {
            if (win._cameraPeer !== peer) return;
            empty.hidden = false;
            empty.textContent = 'Le flux vidéo a été reçu mais ne peut pas être lu.';
        };

        peer.ontrack = event => {
            const stream = event.streams && event.streams[0]
                ? event.streams[0]
                : new MediaStream([event.track]);
            video.srcObject = stream;
            video.play().catch(() => {});
        };

        peer.oniceconnectionstatechange = () => {
            if (win._cameraPeer !== peer || streamReceived) return;
            if (peer.iceConnectionState === 'checking') {
                empty.textContent = 'Connexion au flux vidéo…';
            } else if (peer.iceConnectionState === 'connected' || peer.iceConnectionState === 'completed') {
                empty.textContent = 'Flux connecté, attente de la première image…';
            } else if (peer.iceConnectionState === 'failed') {
                empty.textContent = 'Connexion ICE à la caméra impossible.';
            }
        };

        peer.onconnectionstatechange = () => {
            if (win._cameraPeer !== peer) return;
            if (peer.connectionState === 'connected' && !streamReceived) {
                empty.hidden = false;
                empty.textContent = 'Caméra connectée, attente de la première image…';
            } else if (['failed', 'disconnected', 'closed'].includes(peer.connectionState) && !streamReceived) {
                video.hidden = true;
                empty.hidden = false;
                empty.textContent = peer.connectionState === 'failed'
                    ? 'Connexion WebRTC à la caméra impossible.'
                    : 'Caméra déconnectée.';
            }
        };

        peer.addTransceiver('video', {direction: 'sendrecv'});
        const offer = await peer.createOffer();
        await peer.setLocalDescription(offer);

        await new Promise(resolve => {
            if (peer.iceGatheringState === 'complete') {
                resolve();
                return;
            }
            const done = () => {
                if (peer.iceGatheringState === 'complete') {
                    peer.removeEventListener('icegatheringstatechange', done);
                    resolve();
                }
            };
            peer.addEventListener('icegatheringstatechange', done);
            setTimeout(() => {
                peer.removeEventListener('icegatheringstatechange', done);
                resolve();
            }, 6000);
        });

        if (win._cameraPeer !== peer || !peer.localDescription) return;

        const encodedOffer = encodeBase64Json({
            type: 'offer',
            sdp: peer.localDescription.sdp
        });

        let encodedAnswer = '';
        let directError = null;
        if (endpoint !== '') {
            try {
                encodedAnswer = await postWebRtcOfferDirect(endpoint, encodedOffer);
                win._cameraTransport = 'direct';
            } catch (error) {
                directError = error;
            }
        }

        if (encodedAnswer === '') {
            empty.textContent = endpoint === ''
                ? 'Négociation via le pilote de l’imprimante…'
                : 'Accès direct bloqué, tentative via DoMyDesk…';
            const data = await sendJson('camera_webrtc', {
                printer_id: printerId,
                offer: encodedOffer
            });
            encodedAnswer = String(data.answer || '').trim();
            win._cameraTransport = 'proxy';
        }

        if (encodedAnswer === '') throw directError || new Error('réponse WebRTC vide');

        const answer = decodeBase64Json(encodedAnswer);
        await peer.setRemoteDescription(new RTCSessionDescription(answer));

        win._cameraTimeout = setTimeout(() => {
            if (win._cameraPeer !== peer || streamReceived || video.readyState >= 2) return;
            const viaProxy = win._cameraTransport === 'proxy';
            stopCamera(win);
            empty.hidden = false;
            empty.textContent = viaProxy
                ? 'Le navigateur n’a pas pu joindre directement la caméra. Vérifie l’accès réseau local.'
                : 'La caméra répond, mais aucune image n’arrive. Clique sur ↻ pour réessayer.';
        }, 15000);
    }

    function cameraRender(win, url, printerId, mode = '', endpoint = '') {
        const box = win.querySelector('[data-camera]');
        const empty = win.querySelector('[data-camera-empty]');
        const lower = String(url || '').toLowerCase();
        const isWebRtc = mode === 'webrtc_base64';

        box.querySelectorAll('img,iframe').forEach(item => {
            item.hidden = true;
            item.removeAttribute('src');
        });

        if (isWebRtc && printerId) {
            startWebRtcCamera(win, printerId, endpoint).catch(error => {
                stopCamera(win);
                empty.hidden = false;
                empty.textContent = `Caméra indisponible : ${error.message}`;
            });
            return;
        }

        stopCamera(win);
        if (!url) {
            empty.hidden = false;
            empty.textContent = 'Caméra indisponible pour cette imprimante.';
            return;
        }

        empty.hidden = true;
        if (lower.includes('.m3u8') || lower.includes('.mp4')) {
            const video = box.querySelector('video');
            video.src = url;
            video.hidden = false;
            video.play().catch(() => {});
        } else if (lower.includes('mjpeg') || lower.includes('snapshot') || lower.match(/\.(jpg|jpeg|png)(\?|$)/)) {
            const img = box.querySelector('img');
            img.src = url;
            img.hidden = false;
        } else {
            const frame = box.querySelector('iframe');
            frame.src = url;
            frame.hidden = false;
        }
    }

    function capabilityEnabled(capabilities, key) {
        if (!capabilities || typeof capabilities !== 'object' || !(key in capabilities)) return true;
        const value = capabilities[key];
        if (Array.isArray(value)) return value.length > 0;
        return value !== false && value !== null;
    }

    function applyCapabilities(win, status) {
        const capabilities = status && typeof status.capabilities === 'object' ? status.capabilities : null;
        const tools = {
            upload: 'upload',
            print: 'print_control',
            light: 'light',
            fans: 'fans',
            files: 'files',
            plug: 'plug'
        };
        for (const [tool, capability] of Object.entries(tools)) {
            const button = win.querySelector(`[data-open-tool="${tool}"]`);
            const enabled = capabilityEnabled(capabilities, capability);
            if (button) button.hidden = !enabled;
            if (!enabled) closeToolPopup(win, tool);
        }

        const cameraCard = win.querySelector('[data-capability-card="camera"]');
        if (cameraCard) cameraCard.hidden = !capabilityEnabled(capabilities, 'camera');
        const cfsPanel = win.querySelector('[data-capability-card="cfs"]');
        if (cfsPanel) cfsPanel.hidden = !capabilityEnabled(capabilities, 'cfs');

        const printerInfoButton = win.querySelector('[data-printer-info-button]');
        const printerInfoEnabled = Boolean(capabilities && capabilities.details === true);
        if (printerInfoButton) printerInfoButton.hidden = !printerInfoEnabled;
        if (!printerInfoEnabled) closeToolPopup(win, 'printer_info');
    }

    function statusMessage(win, text, error = false) {
        const el = win.querySelector('[data-window-message]');
        el.textContent = text || '';
        el.classList.toggle('is-error', error);
    }

    async function refreshPrinter(win) {
        const printerId = selectedPrinterId(win);
        if (!printerId) return;
        try {
            const data = await request(`printer_status&printer_id=${encodeURIComponent(printerId)}`);
            const s = data.status || {};
            win._printerStatus = s;
            win.querySelector('[data-online]').textContent = (s.online ?? s.connected) === false ? 'Hors ligne' : (s.state || s.status || 'En ligne');
            win.querySelector('[data-file]').textContent = s.file || s.filename || s.current_file || 'Aucun fichier en cours';
            const rawProgress = Number(s.progress ?? s.percent ?? 0);
            const progress = Math.max(0, Math.min(100, rawProgress * (rawProgress <= 1 ? 100 : 1)));
            win.querySelector('[data-progress]').value = progress;
            win.querySelector('[data-progress-label]').textContent = `${Math.round(progress)} %`;
            win.querySelector('[data-elapsed]').textContent = formatTime(s.elapsed ?? s.time_elapsed ?? s.print_duration);
            win.querySelector('[data-total-time]').textContent = formatTime(s.total ?? s.time_total ?? s.total_time);
            win.querySelector('[data-remaining]').textContent = formatTime(s.remaining ?? s.time_remaining ?? s.remaining_time);
            const temps = s.temperatures || {};
            win.querySelector('[data-nozzle]').textContent = metric(s.nozzle ?? s.temp_nozzle ?? temps.nozzle ?? temps.extruder, ' °C');
            const nozzleInfo = s.nozzle_info && typeof s.nozzle_info === 'object' ? s.nozzle_info : {};
            const nozzleDiameter = nozzleInfo.diameter_mm ?? s.nozzle_diameter ?? null;
            const nozzleMaterial = String(nozzleInfo.material ?? s.nozzle_material ?? '').trim();
            const nozzleModel = String(nozzleInfo.model ?? s.nozzle_model ?? '').trim();
            const nozzleDetails = [];
            if (nozzleDiameter !== null && nozzleDiameter !== undefined && nozzleDiameter !== '' && Number.isFinite(Number(nozzleDiameter))) {
                nozzleDetails.push(`Ø ${Number(nozzleDiameter).toLocaleString('fr-FR', {maximumFractionDigits: 3})} mm`);
            }
            if (nozzleMaterial !== '') nozzleDetails.push(nozzleMaterial);
            if (nozzleModel !== '') nozzleDetails.push(nozzleModel);
            const nozzleDetailsElement = win.querySelector('[data-nozzle-details]');
            if (nozzleDetailsElement) {
                nozzleDetailsElement.textContent = nozzleDetails.length ? nozzleDetails.join(' · ') : 'Diamètre non détecté';
                nozzleDetailsElement.title = nozzleDetails.join(' — ');
            }
            win.querySelector('[data-bed]').textContent = metric(s.bed ?? s.temp_bed ?? temps.bed, ' °C');
            win.querySelector('[data-chamber]').textContent = metric(s.chamber ?? s.temp_chamber ?? temps.chamber, ' °C');
            applyCapabilities(win, s);
            renderCfs(win, s.cfs || {available:Array.isArray(s.filaments) && s.filaments.length > 0, slots:s.filaments || []});
            cameraRender(win, s.camera_url || '', printerId, s.camera_mode || '', s.camera_endpoint || '');
            renderPrinterFiles(win, s.files || s.file_list || []);
            updatePrintToolPopup(win);
            updateFanToolPopup(win);
            updateLightToolPopup(win);
            statusMessage(win, s.message || 'État actualisé.');
        } catch (error) {
            win.querySelector('[data-online]').textContent = 'Pilote indisponible';
            statusMessage(win, error.message, true);
        }
    }

    async function refreshPlug(win) {
        const plugId = selectedPlugId(win);
        if (!plugId) {
            win._plugStatus = {};
            updatePlugToolPopup(win);
            return;
        }
        try {
            const data = await request(`plug_status&plug_id=${encodeURIComponent(plugId)}`);
            win._plugStatus = data.status || {};
            updatePlugToolPopup(win);
        } catch (error) {
            win._plugStatus = {};
            updatePlugToolPopup(win);
            statusMessage(win, error.message, true);
        }
    }

    function refreshWindow(win) {
        refreshPrinter(win);
        refreshPlug(win);
    }

    function bindWindow(win) {
        makeDraggable(win);
        bindCameraPopup(win);
        win._toolPopups = new Map();

        win.querySelector('[data-close-window]').addEventListener('click', () => {
            clearInterval(win._timer);
            if (win._cameraFullscreenHandler) {
                document.removeEventListener('fullscreenchange', win._cameraFullscreenHandler);
                win._cameraFullscreenHandler = null;
            }
            closeAllToolPopups(win);
            stopCamera(win);
            state.windows.delete(win.dataset.windowKey);
            unwatchWindow(win);
            win.remove();
        });

        win.querySelector('[data-refresh-window]').addEventListener('click', () => refreshWindow(win));
        win.querySelector('[data-printer-select]').addEventListener('change', () => {
            stopCamera(win);
            syncWindowActionHubContext(win);
            refreshPrinter(win);
        });
        win.querySelector('[data-plug-select]').addEventListener('change', () => {
            syncWindowActionHubContext(win);
            refreshPlug(win);
        });
        win.querySelector('[data-printer-info-button]')?.addEventListener('click', () => openToolPopup(win, 'printer_info'));
        win.querySelector('[data-tool-grid]').addEventListener('click', event => {
            const button = event.target.closest('[data-open-tool]');
            if (button) openToolPopup(win, button.dataset.openTool);
        });
    }

    function openWindow(printerId) {
        const key = `${root.id}:${printerId}`;
        if (state.windows.has(key)) {
            const existing = state.windows.get(key);
            bringToFront(existing);
            return;
        }
        const printer = state.printers.find(item => item.id === printerId);
        if (!printer) return;

        const win = document.createElement('section');
        win.className = 'dmd3d-window dmd3d-control-window';
        win.dataset.windowKey = key;
        win.dataset.dmdModuleId = 'dmd-3dprint';
        win.dataset.dmdContextType = 'printer';
        win.dataset.dmdContextId = (resourceFor('printer', printer.id) || {}).id || `dmd-3dprint:printer:${printer.id}`;
        win.dataset.dmdContextName = printer.name;
        win.dataset.dmdActionHub = '1';
        const offset = state.windows.size * 28;
        win.style.left = `${Math.max(20, window.scrollX + 80 + offset)}px`;
        win.style.top = `${Math.max(20, window.scrollY + 80 + offset)}px`;
        win.innerHTML = `
            <header class="dmd3d-window-head" data-window-head>
                <div class="dmd3d-window-drag-identity" data-window-drag-handle title="Maintenir et déplacer la fenêtre">
                    <img class="dmd3d-window-drag-icon" src="${esc(moduleIcon)}" alt="" draggable="false">
                    <strong>${esc(printer.name)}</strong>
                </div>
                <div class="dmd3d-actions"><button type="button" class="dmd3d-button" data-refresh-window>↻</button><button type="button" class="dmd3d-close" data-close-window>✕</button></div>
            </header>
            <div class="dmd3d-window-body">
                <div class="dmd3d-window-selection">
                    <div class="dmd3d-field"><label>Imprimante</label><select data-printer-select>${optionList(state.printers, printer.id, 'Aucune imprimante')}</select></div>
                    <div class="dmd3d-field" data-plug-context><label>Prise</label><select data-plug-select>${optionList(state.plugs, printer.plug_id || '', 'Aucune prise')}</select></div>
                    <span class="dmd3d-status" data-online>Chargement…</span>
                </div>

                <div class="dmd3d-window-grid dmd3d-control-overview">
                    <section class="dmd3d-card" data-capability-card="camera">
                        <div class="dmd3d-section-title dmd3d-camera-title"><div class="dmd3d-section-title-device"><h3>Caméra intérieure</h3>${printer.model ? `<img src="${esc(modelImageUrl('printer', printer))}" alt="${esc(printer.name)}" class="dmd3d-equipment-thumb" data-model-image>` : ''}</div><button type="button" class="dmd3d-button" data-printer-info-button hidden title="Afficher toutes les informations utiles de l’imprimante">ℹ Informations</button><button type="button" class="dmd3d-button dmd3d-camera-popout-button" data-camera-popout title="Ouvrir la caméra dans une grande fenêtre">⛶ Agrandir</button></div>
                        <div class="dmd3d-camera" data-camera><div class="dmd3d-camera-empty" data-camera-empty>Chargement…</div><img alt="Caméra" hidden><video controls muted autoplay playsinline controlsList="nofullscreen nodownload noremoteplayback" hidden></video><iframe title="Caméra de l’imprimante" loading="lazy" hidden></iframe></div>
                    </section>
                    <section class="dmd3d-card dmd3d-print-summary">
                        <div class="dmd3d-section-title"><h3>Impression en cours</h3></div>
                        <strong class="dmd3d-current-file" data-file>Aucun fichier en cours</strong>
                        <progress class="dmd3d-progress" data-progress max="100" value="0"></progress>
                        <div class="dmd3d-progress-line"><strong data-progress-label>0 %</strong></div>
                        <div class="dmd3d-metrics dmd3d-metrics-three"><article><span>Écoulé</span><strong data-elapsed>—</strong></article><article><span>Total</span><strong data-total-time>—</strong></article><article><span>Restant</span><strong data-remaining>—</strong></article></div>
                        <div class="dmd3d-metrics dmd3d-metrics-three"><article><span>Buse</span><strong data-nozzle>—</strong><span data-nozzle-details>Diamètre non détecté</span></article><article><span>Plateau</span><strong data-bed>—</strong></article><article><span>Chambre</span><strong data-chamber>—</strong></article></div>
                        <div class="dmd3d-cfs-panel" data-cfs-panel data-capability-card="cfs">
                            <div class="dmd3d-cfs-head"><strong>Filaments et porte-bobine</strong><small data-cfs-sync>Synchronisation…</small></div>
                            <div class="dmd3d-cfs-slots" data-cfs-slots><div class="dmd3d-cfs-empty">Chargement des filaments…</div></div>
                        </div>
                    </section>
                </div>

                <div class="dmd3d-tool-grid" data-tool-grid>
                    <button type="button" class="dmd3d-tool-button" data-open-tool="upload"><span class="dmd3d-tool-icon">📤</span><span><strong>Envoyer un fichier</strong><small>STL, 3MF ou G-code</small></span><b>›</b></button>
                    <button type="button" class="dmd3d-tool-button" data-dmd3d-models><span class="dmd3d-tool-icon">🧊</span><span><strong>Voir les modèles</strong><small>Sources 3D — STL / 3MF</small></span><b>›</b></button>
                    <button type="button" class="dmd3d-tool-button" data-open-tool="print"><span class="dmd3d-tool-icon">🎮</span><span><strong>Contrôler l’impression</strong><small>Pause, reprise et arrêt</small></span><b>›</b></button>
                    <button type="button" class="dmd3d-tool-button" data-open-tool="light"><span class="dmd3d-tool-icon">💡</span><span><strong>Lumière</strong><small data-tool-light-state>État indisponible</small></span><b>›</b></button>
                    <button type="button" class="dmd3d-tool-button" data-open-tool="fans"><span class="dmd3d-tool-icon">🌀</span><span><strong>Ventilateurs</strong><small>Type et vitesse</small></span><b>›</b></button>
                    <button type="button" class="dmd3d-tool-button" data-open-tool="files"><span class="dmd3d-tool-icon">📁</span><span><strong>Fichiers de l’imprimante</strong><small>Bibliothèque G-code</small></span><em data-tool-count="files">0</em></button>
                    <button type="button" class="dmd3d-tool-button" data-open-tool="plug"><span class="dmd3d-tool-icon">🔌</span><span><strong>Prise connectée</strong><small data-tool-plug-state>Aucune prise</small></span><b>›</b></button>
                </div>

                <div class="dmd3d-inline-message" data-window-message aria-live="polite"></div>
            </div>`;

        document.body.appendChild(win);
        bindModelImages(win);
        bringToFront(win);
        bindWindow(win);
        state.windows.set(key, win);
        syncWindowActionHubContext(win);
        watchWindow(win);
        refreshWindow(win);
        win._timer = setInterval(() => { if (document.visibilityState === 'visible' && document.body.contains(win)) refreshWindow(win); }, 7500);
    }

    document.addEventListener('dmd:actionhub-ui-action', event => {
        const detail = event && event.detail && typeof event.detail === 'object' ? event.detail : {};
        if (String(detail.module || '') !== 'dmd-3dprint') return;

        const ui = detail.ui && typeof detail.ui === 'object' ? detail.ui : detail;
        if (String(ui.type || '') !== 'dmd3d.open_camera') return;

        const printerId = String(ui.printer_id || '').trim();
        if (!printerId) return;

        openWindow(printerId);
        document.dispatchEvent(new CustomEvent('dmd:actionhub-ui-action-handled', {
            detail: { module: 'dmd-3dprint', ui_type: 'dmd3d.open_camera', printer_id: printerId }
        }));

        window.setTimeout(() => {
            const key = `${root.id}:${printerId}`;
            const win = state.windows.get(key);
            if (!win) return;
            bringToFront(win);
            const camera = win.querySelector('[data-camera]');
            if (camera && typeof camera.scrollIntoView === 'function') camera.scrollIntoView({behavior:'smooth', block:'center'});
        }, 220);
    });

    root.addEventListener('click', event => {
        const open = event.target.closest('[data-open-printer]');
        if (open) openWindow(open.dataset.openPrinter);
        if (event.target.closest('[data-refresh]')) load().then(() => toast('Liste actualisée.')).catch(error => toast(error.message, true));
    });

    window.addEventListener('resize', updateScrollArea, {passive:true});
    if (state.mfaUnlocked) {
        load().then(() => startHealthMonitor()).catch(error => toast(error.message, true));
    }
})();
</script>
