<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



declare(strict_types=1);

require_once __DIR__ . '/dmd-3dprint_lib.php';

if (!function_exists('dmd3d_ah_driver_handlers')) {
    function dmd3d_ah_driver_handlers(string $type, array $device): array {
        $model = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($device['model'] ?? ''));
        if ($model === '') return array();

        try {
            $modelDir = dmd3d_model_base($type) . '/' . $model;
            if (!is_dir($modelDir)) return array();
            $manifest = dmd3d_read_json($modelDir . '/manifest.json', array());
            $entry = dmd3d_model_entry($modelDir, $manifest);
            if ($entry === null) return array();

            $loaded = dmd3d_include_driver(
                $modelDir . '/' . $entry,
                $type,
                $device,
                '__actionhub_catalog__',
                array(),
                dmd3d_driver_context($type, $device)
            );
            $returned = $loaded['returned'] ?? null;
        } catch (Throwable $e) {
            return array();
        }

        if (is_callable($returned)) return array('*');
        if (!is_array($returned)) return array();

        $handlers = array();
        foreach ($returned as $key => $callable) {
            if (is_string($key) && $key !== 'handle' && is_callable($callable)) $handlers[] = $key;
        }
        if (isset($returned['handle']) && is_callable($returned['handle'])) $handlers[] = '*';
        return array_values(array_unique($handlers));
    }
}

if (!function_exists('dmd3d_ah_supports')) {
    function dmd3d_ah_supports(array $handlers, array $wanted): bool {
        if (in_array('*', $handlers, true)) return true;
        foreach ($wanted as $name) if (in_array($name, $handlers, true)) return true;
        return false;
    }
}

if (!function_exists('dmd3d_ah_devices')) {
    function dmd3d_ah_devices(string $type, string $email): array {
        $items = $type === 'printer' ? dmd3d_load_printers() : dmd3d_load_plugs();
        $out = array();

        foreach ($items as $item) {
            if (!is_array($item) || empty($item['id'])) continue;
            if (array_key_exists('enabled', $item) && $item['enabled'] === false) continue;
            if (!dmd3d_user_can_access_device($type, $item, $email)) continue;
            $item['_actionhub_handlers'] = dmd3d_ah_driver_handlers($type, $item);
            $out[] = $item;
        }
        return $out;
    }
}

if (!function_exists('dmd3d_ah_filter')) {
    function dmd3d_ah_filter(array $devices, array $handlers): array {
        return array_values(array_filter($devices, static function ($device) use ($handlers) {
            return is_array($device) && dmd3d_ah_supports((array)($device['_actionhub_handlers'] ?? array()), $handlers);
        }));
    }
}

if (!function_exists('dmd3d_ah_options')) {
    function dmd3d_ah_options(array $devices): array {
        $options = array();
        foreach ($devices as $device) {
            $id = trim((string)($device['id'] ?? ''));
            if ($id === '') continue;
            $name = trim((string)($device['name'] ?? $id));
            $model = trim((string)($device['device_model'] ?? ($device['model'] ?? '')));
            $options[] = array('value' => $id, 'label' => $name . ($model !== '' ? ' · ' . $model : ''));
        }
        return $options;
    }
}

if (!function_exists('dmd3d_ah_action')) {
    function dmd3d_ah_action(
        string $id, string $label, string $group, string $permission,
        string $deviceType, string $driverAction, array $deviceOptions,
        bool $scenario, string $scope = 'module', array $resourceTypes = array(),
        array $extraInputs = array(), bool $dangerous = false, string $confirm = '',
        string $icon = '⚡', string $description = '', string $uiAction = '',
        array $metaExtra = array(), bool $includeDeviceInput = true
    ): array {
        $inputs = array();
        if ($scope === 'module' && $includeDeviceInput) {
            $inputs[] = array(
                'id' => $deviceType === 'plug' ? 'plug_id' : 'printer_id',
                'label' => $deviceType === 'plug' ? 'Prise' : 'Imprimante',
                'type' => 'select',
                'required' => true,
                'options' => $deviceOptions,
            );
        }
        foreach ($extraInputs as $input) $inputs[] = $input;

        return array(
            'id' => $id,
            'label' => $label,
            'description' => $description,
            'icon' => $icon,
            'group' => $group,
            'permission' => $permission,
            'scope' => $scope,
            'scenario' => $scenario,
            'resource_types' => $resourceTypes,
            'inputs' => $inputs,
            'dangerous' => $dangerous,
            'confirm' => $confirm,
            'meta' => array_merge(array(
                'dmd3d_device_type' => $deviceType,
                'dmd3d_driver_action' => $driverAction,
                'dmd3d_ui_action' => $uiAction,
            ), $metaExtra),
        );
    }
}


if (!function_exists('dmd3d_ah_linked_plug')) {
    function dmd3d_ah_linked_plug(array $printer, string $email, string $requiredAction = ''): ?array {
        $plugId = trim((string)($printer['plug_id'] ?? ''));
        if ($plugId === '') return null;
        $plug = dmd3d_find_device('plug', $plugId);
        if (!$plug || (array_key_exists('enabled',$plug) && $plug['enabled'] === false)) return null;
        if (!dmd3d_user_can_access_device('plug', $plug, $email)) return null;
        if ($requiredAction !== '' && !dmd3d_ah_supports(dmd3d_ah_driver_handlers('plug',$plug), [$requiredAction])) return null;
        return $plug;
    }
}

if (!function_exists('dmd3d_ah_printers_with_linked_power')) {
    function dmd3d_ah_printers_with_linked_power(array $printers, string $email, string $action): array {
        return array_values(array_filter($printers, static function ($printer) use ($email,$action) {
            return is_array($printer) && dmd3d_ah_linked_plug($printer,$email,$action) !== null;
        }));
    }
}

if (!function_exists('dmd3d_ah_file_options')) {
    function dmd3d_ah_file_options(array $printer): array {
        try { $result = dmd3d_call_driver('printer',$printer,'list_files',[]); }
        catch (Throwable $error) { return []; }
        $options = [];
        foreach ((array)($result['files'] ?? []) as $file) {
            if (!is_array($file)) continue;
            $path = trim((string)($file['path'] ?? ''));
            if ($path === '') continue;
            $name = trim((string)($file['name'] ?? basename(str_replace('\\','/',$path))));
            $options[] = ['value'=>$path,'label'=>$name !== '' ? $name : $path];
            if (count($options) >= 250) break;
        }
        return $options;
    }
}

if (!function_exists('dmd3d_ah_resource_local_id')) {
    function dmd3d_ah_resource_local_id(array $resource): string {
        $parts = explode(':', trim((string)($resource['id'] ?? '')));
        return preg_replace('/[^A-Za-z0-9_-]/', '', (string)end($parts)) ?: '';
    }
}

if (!function_exists('dmd3d_actionhub_catalog')) {
    function dmd3d_actionhub_catalog(array $context): array {
        $email = trim((string)($context['email'] ?? ''));
        $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;

        $printers = dmd3d_ah_devices('printer', $email);
        $plugs = dmd3d_ah_devices('plug', $email);

        $camera = dmd3d_ah_filter($printers, array('camera_webrtc', 'camera_snapshot', 'camera_frame'));
        $lightOn = dmd3d_ah_filter($printers, array('light_on'));
        $lightOff = dmd3d_ah_filter($printers, array('light_off'));
        $pause = dmd3d_ah_filter($printers, array('pause'));
        $resume = dmd3d_ah_filter($printers, array('resume'));
        $stop = dmd3d_ah_filter($printers, array('stop'));
        $fan = dmd3d_ah_filter($printers, array('fan'));
        $start = dmd3d_ah_filter($printers, array('start','list_files'));
        $printerPowerOn = dmd3d_ah_printers_with_linked_power($printers,$email,'power_on');
        $printerPowerOff = dmd3d_ah_printers_with_linked_power($printers,$email,'power_off');
        $powerOn = dmd3d_ah_filter($plugs, array('power_on'));
        $powerOff = dmd3d_ah_filter($plugs, array('power_off'));

        if ($resource) {
            $actions = array();
            $type = (string)($resource['type'] ?? '');
            $id = dmd3d_ah_resource_local_id($resource);

            if ($type === 'printer') {
                $printer = dmd3d_find_device('printer', $id);
                if ($printer && dmd3d_user_can_access_device('printer', $printer, $email)) {
                    $h = dmd3d_ah_driver_handlers('printer', $printer);
                    if (dmd3d_ah_linked_plug($printer,$email,'power_on'))
                        $actions[] = dmd3d_ah_action('resource.printer.power_on','Allumer l’imprimante','Imprimante','plug.power','printer','__linked_plug_on__',[],false,'resource',['printer'],[],false,'','⏻','Allume la prise associée à cette imprimante.');
                    if (dmd3d_ah_linked_plug($printer,$email,'power_off'))
                        $actions[] = dmd3d_ah_action('resource.printer.power_off','Éteindre l’imprimante','Imprimante','plug.power','printer','__linked_plug_off__',[],false,'resource',['printer'],[],true,'Éteindre complètement cette imprimante ?','⏻','Éteint la prise associée à cette imprimante.');
                    if (dmd3d_ah_supports($h,['start','list_files'])) {
                        $fileOptions = dmd3d_ah_file_options($printer);
                        if ($fileOptions) $actions[] = dmd3d_ah_action(
                            'resource.printer.start','Nouvelle impression','Imprimante','printer.start',
                            'printer','start',[],false,'resource',['printer'],
                            [['id'=>'file','label'=>'Fichier G-code','type'=>'select','required'=>true,'options'=>$fileOptions]],
                            false,'','🖨️','Lance un fichier G-code déjà présent dans l’imprimante.'
                        );
                    }
                    if (dmd3d_ah_supports($h, array('camera_webrtc','camera_snapshot','camera_frame')))
                        $actions[] = dmd3d_ah_action('resource.printer.camera','Afficher la caméra','Imprimante','camera.view','printer','__ui_camera__',array(),false,'resource',array('printer'),array(),false,'','📷','','open_camera');
                    if (dmd3d_ah_supports($h, array('light_on')))
                        $actions[] = dmd3d_ah_action('resource.printer.light_on','Allumer la lumière','Imprimante','printer.light','printer','light_on',array(),false,'resource',array('printer'),array(),false,'','💡');
                    if (dmd3d_ah_supports($h, array('light_off')))
                        $actions[] = dmd3d_ah_action('resource.printer.light_off','Éteindre la lumière','Imprimante','printer.light','printer','light_off',array(),false,'resource',array('printer'),array(),false,'','🌑');
                    if (dmd3d_ah_supports($h, array('pause')))
                        $actions[] = dmd3d_ah_action('resource.printer.pause','Mettre en pause','Imprimante','printer.pause','printer','pause',array(),false,'resource',array('printer'),array(),false,'','⏸');
                    if (dmd3d_ah_supports($h, array('resume')))
                        $actions[] = dmd3d_ah_action('resource.printer.resume','Reprendre','Imprimante','printer.resume','printer','resume',array(),false,'resource',array('printer'),array(),false,'','▶');
                    if (dmd3d_ah_supports($h, array('stop')))
                        $actions[] = dmd3d_ah_action('resource.printer.stop','Arrêter','Imprimante','printer.stop','printer','stop',array(),false,'resource',array('printer'),array(),true,'Arrêter l’impression en cours ?','⏹');
                }
            } elseif ($type === 'smart_plug') {
                $plug = dmd3d_find_device('plug', $id);
                if ($plug && dmd3d_user_can_access_device('plug', $plug, $email)) {
                    $h = dmd3d_ah_driver_handlers('plug', $plug);
                    if (dmd3d_ah_supports($h, array('power_on')))
                        $actions[] = dmd3d_ah_action('resource.plug.power_on','Allumer la prise','Prise','plug.power','plug','power_on',array(),false,'resource',array('smart_plug'),array(),false,'','🔌');
                    if (dmd3d_ah_supports($h, array('power_off')))
                        $actions[] = dmd3d_ah_action('resource.plug.power_off','Éteindre la prise','Prise','plug.power','plug','power_off',array(),false,'resource',array('smart_plug'),array(),true,'Éteindre cette prise ?','⏻');
                }
            }
            return array('replace' => true, 'actions' => $actions);
        }

        $actions = array();
        if ($printerPowerOn) $actions[] = dmd3d_ah_action(
            'scenario.printer.power_on','Allumer l’imprimante','Imprimante','plug.power',
            'printer','__linked_plug_on__',dmd3d_ah_options($printerPowerOn),true,'module',
            [],[],false,'','⏻','Allume automatiquement la prise associée à l’imprimante.'
        );
        if ($printerPowerOff) $actions[] = dmd3d_ah_action(
            'scenario.printer.power_off','Éteindre l’imprimante','Imprimante','plug.power',
            'printer','__linked_plug_off__',dmd3d_ah_options($printerPowerOff),true,'module',
            [],[],true,'Éteindre complètement l’imprimante sélectionnée ?','⏻','Éteint automatiquement la prise associée à l’imprimante.'
        );
        $startCount = count($start);
        foreach ($start as $startPrinter) {
            $fileOptions = dmd3d_ah_file_options($startPrinter);
            if (!$fileOptions) continue;
            $printerId = (string)($startPrinter['id'] ?? '');
            $printerName = trim((string)($startPrinter['name'] ?? 'Imprimante'));
            $label = $startCount > 1 ? 'Nouvelle impression — ' . $printerName : 'Nouvelle impression';
            $actions[] = dmd3d_ah_action(
                'scenario.printer.start.' . dmd3d_health_safe_id($printerId),
                $label,'Imprimante','printer.start','printer','start',[],true,'module',[],
                [['id'=>'file','label'=>'Fichier G-code — '.$printerName,'type'=>'select','required'=>true,'options'=>$fileOptions]],
                false,'','🖨️','Lance un fichier G-code déjà présent dans '.$printerName.'.','',
                ['fixed_device_id'=>$printerId],false
            );
        }
        if ($powerOn) $actions[] = dmd3d_ah_action('scenario.plug.power_on','Allumer la prise','Prise','plug.power','plug','power_on',dmd3d_ah_options($powerOn),true,'module',array(),array(),false,'','🔌','Allume une prise connectée.');
        if ($powerOff) $actions[] = dmd3d_ah_action('scenario.plug.power_off','Éteindre la prise','Prise','plug.power','plug','power_off',dmd3d_ah_options($powerOff),true,'module',array(),array(),true,'Éteindre cette prise connectée ?','⏻','Éteint une prise connectée.');
        if ($camera) $actions[] = dmd3d_ah_action('scenario.printer.camera','Afficher la caméra','Imprimante','camera.view','printer','__ui_camera__',dmd3d_ah_options($camera),true,'module',array(),array(),false,'','📷','Ouvre le contrôle de l’imprimante sur sa caméra.','open_camera');
        if ($lightOn) $actions[] = dmd3d_ah_action('scenario.printer.light_on','Allumer la lumière','Imprimante','printer.light','printer','light_on',dmd3d_ah_options($lightOn),true,'module',array(),array(),false,'','💡','Allume l’éclairage de l’imprimante.');
        if ($lightOff) $actions[] = dmd3d_ah_action('scenario.printer.light_off','Éteindre la lumière','Imprimante','printer.light','printer','light_off',dmd3d_ah_options($lightOff),true,'module',array(),array(),false,'','🌑','Éteint l’éclairage de l’imprimante.');
        if ($pause) $actions[] = dmd3d_ah_action('scenario.printer.pause','Mettre en pause','Imprimante','printer.pause','printer','pause',dmd3d_ah_options($pause),true,'module',array(),array(),false,'','⏸','Met l’impression en pause.');
        if ($resume) $actions[] = dmd3d_ah_action('scenario.printer.resume','Reprendre l’impression','Imprimante','printer.resume','printer','resume',dmd3d_ah_options($resume),true,'module',array(),array(),false,'','▶','Reprend une impression en pause.');
        if ($stop) $actions[] = dmd3d_ah_action('scenario.printer.stop','Arrêter l’impression','Imprimante','printer.stop','printer','stop',dmd3d_ah_options($stop),true,'module',array(),array(),true,'Arrêter l’impression en cours ?','⏹','Arrête l’impression en cours.');

        if ($fan) {
            $actions[] = dmd3d_ah_action(
                'scenario.printer.fan','Régler un ventilateur','Imprimante','printer.fan',
                'printer','fan',dmd3d_ah_options($fan),true,'module',array(),
                array(
                    array('id'=>'fan','label'=>'Ventilateur','type'=>'select','required'=>true,'default'=>'part','options'=>array(
                        array('value'=>'part','label'=>'Pièce'),
                        array('value'=>'aux','label'=>'Auxiliaire'),
                        array('value'=>'chamber','label'=>'Chambre')
                    )),
                    array('id'=>'value','label'=>'Vitesse (%)','type'=>'number','required'=>true,'default'=>50)
                ),
                false,'','🌀','Règle un ventilateur pris en charge par le modèle.'
            );
        }

        return array('replace' => true, 'actions' => $actions);
    }
}

if (!function_exists('dmd3d_actionhub_handle')) {
    function dmd3d_actionhub_handle(array $context): array {
        $email = trim((string)($context['email'] ?? ''));
        $action = is_array($context['action'] ?? null) ? $context['action'] : array();
        $payload = is_array($context['payload'] ?? null) ? $context['payload'] : array();
        $resource = is_array($context['resource'] ?? null) ? $context['resource'] : null;
        $meta = is_array($action['meta'] ?? null) ? $action['meta'] : array();

        $deviceType = (string)($meta['dmd3d_device_type'] ?? '');
        $driverAction = (string)($meta['dmd3d_driver_action'] ?? '');
        $uiAction = (string)($meta['dmd3d_ui_action'] ?? '');

        if (!in_array($deviceType, array('printer','plug'), true))
            return array('ok'=>false,'error'=>'invalid_device_type','message'=>'Type d’équipement DMD-3DPrint invalide.');

        $fixedDeviceId = trim((string)($meta['fixed_device_id'] ?? ''));
        $localId = ($action['scope'] ?? 'resource') === 'resource'
            ? ($resource ? dmd3d_ah_resource_local_id($resource) : '')
            : ($fixedDeviceId !== '' ? $fixedDeviceId : trim((string)($payload[$deviceType === 'plug' ? 'plug_id' : 'printer_id'] ?? '')));

        $localId = preg_replace('/[^A-Za-z0-9_-]/', '', $localId) ?: '';
        $device = $localId !== '' ? dmd3d_find_device($deviceType, $localId) : null;

        if (!$device)
            return array('ok'=>false,'error'=>'device_not_found','message'=>$deviceType === 'plug' ? 'Prise introuvable.' : 'Imprimante introuvable.');

        if (!dmd3d_user_can_access_device($deviceType, $device, $email))
            return array('ok'=>false,'error'=>'resource_denied','message'=>'Accès refusé à cet équipement.');

        if ($deviceType === 'printer' && in_array($driverAction,['__linked_plug_on__','__linked_plug_off__'],true)) {
            $plugCommand = $driverAction === '__linked_plug_on__' ? 'power_on' : 'power_off';
            $plug = dmd3d_ah_linked_plug($device,$email,$plugCommand);
            if (!$plug) return ['ok'=>false,'error'=>'linked_plug_unavailable','message'=>'Aucune prise compatible et accessible n’est associée à cette imprimante.'];
            try {
                $plugResult = dmd3d_call_driver('plug',$plug,$plugCommand,[]);
                if ($plugCommand === 'power_off') dmd3d_health_expect_offline($device,900);
                else dmd3d_health_clear_expected_offline($device);
            } catch (Throwable $e) {
                dmd3d_record_event('printer.'.($plugCommand === 'power_on' ? 'power_on' : 'power_off'),'printer',$device,'error',['message'=>$e->getMessage()]);
                return ['ok'=>false,'error'=>'driver_failed','message'=>$e->getMessage()];
            }
            $eventAction = $plugCommand === 'power_on' ? 'printer.power_on' : 'printer.power_off';
            dmd3d_record_event($eventAction,'printer',$device,'ok',[
                'plug_id'=>(string)($plug['id'] ?? ''),
                'plug_name'=>(string)($plug['name'] ?? ''),
                'source'=>'actionhub'
            ]);
            return [
                'ok'=>true,
                'message'=>$plugCommand === 'power_on' ? 'Imprimante allumée via sa prise associée.' : 'Imprimante éteinte via sa prise associée.',
                'data'=>['device_id'=>$localId,'device_name'=>(string)($device['name'] ?? $localId),'plug_id'=>(string)($plug['id'] ?? ''),'plug_name'=>(string)($plug['name'] ?? ''),'result'=>$plugResult,'reload'=>true],
                'event_emitted'=>true
            ];
        }

        $handlers = dmd3d_ah_driver_handlers($deviceType, $device);

        if ($uiAction === 'open_camera') {
            if (!dmd3d_ah_supports($handlers, array('camera_webrtc','camera_snapshot','camera_frame')))
                return array('ok'=>false,'error'=>'unsupported','message'=>'Ce modèle ne déclare pas de caméra exploitable.');

            dmd3d_record_event('printer.camera_open','printer',$device,'ok',array('source'=>'actionhub'));
            return array(
                'ok'=>true,
                'message'=>'Caméra prête à être affichée.',
                'data'=>array('ui'=>array(
                    'type'=>'dmd3d.open_camera',
                    'module'=>DMD3D_MODULE_ID,
                    'printer_id'=>$localId
                )),
                'event_emitted'=>true
            );
        }

        if ($driverAction === '' || !dmd3d_ah_supports($handlers, array($driverAction)))
            return array('ok'=>false,'error'=>'unsupported','message'=>'Cette action n’est pas prise en charge par le modèle sélectionné.');

        $driverPayload = $payload;
        unset($driverPayload['printer_id'], $driverPayload['plug_id']);

        try {
            $result = dmd3d_call_driver($deviceType, $device, $driverAction, $driverPayload);
        } catch (Throwable $e) {
            dmd3d_record_event(($deviceType === 'plug' ? 'plug.' : 'printer.') . $driverAction,$deviceType,$device,'error',array('message'=>$e->getMessage()));
            return array('ok'=>false,'error'=>'driver_failed','message'=>$e->getMessage());
        }

        dmd3d_record_event(($deviceType === 'plug' ? 'plug.' : 'printer.') . $driverAction,$deviceType,$device,'ok',$driverPayload);

        return array(
            'ok'=>true,
            'message'=>trim((string)($result['message'] ?? 'Action DMD-3DPrint exécutée.')),
            'data'=>array(
                'device_id'=>$localId,
                'device_name'=>trim((string)($device['name'] ?? $localId)),
                'driver_action'=>$driverAction,
                'reload'=>true
            ),
            'event_emitted'=>true
        );
    }
}
