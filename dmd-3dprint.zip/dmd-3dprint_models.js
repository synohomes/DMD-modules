(() => {
    if (window.DMD3DModels && window.DMD3DModels.__ready) return;

    const currentScript = document.currentScript;
    const scriptUrl = currentScript && currentScript.src ? currentScript.src : '';
    const endpoint = scriptUrl
        ? scriptUrl.replace(/\/dmd-3dprint_models\.js(?:\?.*)?$/i, '/dmd-3dprint_models.php')
        : 'dmd-3dprint_models.php';

    const state = { browser: null, detail: null, external: null, z: 12000, endpoint, sources: [], source: 'printables', canManageSources: false, sourceCsrf: '' };
    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({
        '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;'
    }[c]));

    function maxZ() {
        let max = state.z;
        document.querySelectorAll('.dmd3d-window').forEach(item => {
            const z = Number.parseInt(window.getComputedStyle(item).zIndex || '0', 10);
            if (Number.isFinite(z)) max = Math.max(max, z);
        });
        state.z = max + 1;
        return state.z;
    }

    function bringToFront(win) {
        if (win) win.style.zIndex = String(maxZ());
    }

    function getScrollPad() {
        let pad = document.getElementById('dmd3d-scroll-pad');
        if (!pad) {
            pad = document.createElement('div');
            pad.id = 'dmd3d-scroll-pad';
            pad.setAttribute('aria-hidden', 'true');
            pad.style.cssText = 'position:absolute;left:0;top:0;width:1px;height:1px;pointer-events:none;visibility:hidden;';
            document.body.appendChild(pad);
        }
        return pad;
    }

    function updateScrollArea() {
        const windows = Array.from(document.querySelectorAll('.dmd3d-window')).filter(item => document.body.contains(item));
        if (!windows.length) {
            document.getElementById('dmd3d-scroll-pad')?.remove();
            return;
        }
        const viewportW = document.documentElement.clientWidth;
        const viewportH = document.documentElement.clientHeight;
        let needW = viewportW;
        let needH = viewportH;
        windows.forEach(item => {
            const rect = item.getBoundingClientRect();
            needW = Math.max(needW, window.scrollX + rect.right + 48);
            needH = Math.max(needH, window.scrollY + rect.bottom + 48);
        });
        const pad = getScrollPad();
        pad.style.width = needW > viewportW ? `${Math.ceil(needW)}px` : '1px';
        pad.style.height = needH > viewportH ? `${Math.ceil(needH)}px` : '1px';
    }

    function makeDraggable(win) {
        const head = win.querySelector('[data-models-window-head]');
        if (!head) return;
        let drag = null;
        head.addEventListener('pointerdown', event => {
            if (event.target.closest('button,a,input,select')) return;
            bringToFront(win);
            const rect = win.getBoundingClientRect();
            drag = { x: event.clientX - rect.left, y: event.clientY - rect.top };
            head.setPointerCapture(event.pointerId);
        });
        head.addEventListener('pointermove', event => {
            if (!drag) return;
            win.style.left = `${Math.max(0, event.clientX - drag.x + window.scrollX)}px`;
            win.style.top = `${Math.max(0, event.clientY - drag.y + window.scrollY)}px`;
            updateScrollArea();
        });
        const stop = event => {
            if (drag && head.hasPointerCapture(event.pointerId)) head.releasePointerCapture(event.pointerId);
            drag = null;
            updateScrollArea();
        };
        head.addEventListener('pointerup', stop);
        head.addEventListener('pointercancel', stop);
        win.addEventListener('pointerdown', () => bringToFront(win));
    }

    function watchWindow(win) {
        makeDraggable(win);
        bringToFront(win);
        updateScrollArea();
        if (window.ResizeObserver) {
            win._modelsResizeObserver = new ResizeObserver(updateScrollArea);
            win._modelsResizeObserver.observe(win);
        }
    }

    function removeWindow(win) {
        if (!win) return;
        if (win._modelsResizeObserver) win._modelsResizeObserver.disconnect();
        win.remove();
        setTimeout(updateScrollArea, 0);
    }

    function showMessage(popup, message, error = false) {
        const box = popup.querySelector('[data-models-message]');
        if (!box) return;
        box.textContent = message || '';
        box.classList.toggle('is-error', error);
    }

    async function jsonRequest(url) {
        const response = await fetch(url, {
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Accept': 'application/json' }
        });
        const text = await response.text();
        let data;
        try { data = JSON.parse(text); }
        catch (error) { throw new Error(`Réponse invalide du connecteur Printables (${response.status}).`); }
        if (!response.ok || !data.ok) throw new Error(data.message || `Erreur HTTP ${response.status}`);
        return data;
    }

    async function postJson(payload) {
        const response = await fetch(state.endpoint, {
            method: 'POST',
            credentials: 'same-origin',
            cache: 'no-store',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
            body: JSON.stringify(payload || {})
        });
        const text = await response.text();
        let data;
        try { data = JSON.parse(text); }
        catch (error) { throw new Error(`Réponse invalide du navigateur de modèles (${response.status}).`); }
        if (!response.ok || !data.ok) throw new Error(data.message || `Erreur HTTP ${response.status}`);
        return data;
    }

    function renderSourceOptions(popup) {
        const select = popup.querySelector('[data-models-source]');
        if (!select) return;
        const current = state.sources.some(item => item.id === state.source) ? state.source : 'printables';
        select.innerHTML = state.sources.map(item => `<option value="${esc(item.id)}">${esc(item.name)}</option>`).join('');
        select.value = current;
        state.source = select.value || 'printables';
        const manageButton = popup.querySelector('[data-models-source-manage]');
        if (manageButton) manageButton.hidden = !state.canManageSources;
        renderSourceList(popup);
    }

    function renderSourceList(popup) {
        const list = popup.querySelector('[data-models-source-list]');
        if (!list) return;
        const removable = state.sources.filter(item => !item.locked);
        list.innerHTML = removable.length ? removable.map(item => `
            <div class="dmd3d-source-row">
                <span><strong>${esc(item.name)}</strong><small>${esc(item.search_url)}</small></span>
                <button type="button" class="dmd3d-button" data-models-source-delete="${esc(item.id)}">Supprimer</button>
            </div>`).join('') : '<small class="dmd3d-muted">Aucune source personnalisée.</small>';
    }

    async function loadSources(popup) {
        const data = await jsonRequest(`${state.endpoint}?action=sources`);
        state.sources = Array.isArray(data.sources) ? data.sources : [];
        state.canManageSources = !!data.can_manage;
        state.sourceCsrf = String(data.csrf || '');
        renderSourceOptions(popup);
    }

    function toggleSourceManager(popup) {
        const panel = popup.querySelector('[data-models-source-panel]');
        if (!panel) return;
        panel.hidden = !panel.hidden;
        if (!panel.hidden) popup.querySelector('[data-models-source-name]')?.focus();
    }

    async function addSource(popup) {
        const nameInput = popup.querySelector('[data-models-source-name]');
        const urlInput = popup.querySelector('[data-models-source-url]');
        const name = String(nameInput?.value || '').trim();
        const searchUrl = String(urlInput?.value || '').trim();
        if (!name || !searchUrl) {
            showMessage(popup, 'Indique un nom et une adresse HTTPS.', true);
            return;
        }
        try {
            const data = await postJson({ action: 'source_add', csrf: state.sourceCsrf, name, search_url: searchUrl });
            state.sources = Array.isArray(data.sources) ? data.sources : state.sources;
            if (nameInput) nameInput.value = '';
            if (urlInput) urlInput.value = '';
            renderSourceOptions(popup);
            showMessage(popup, 'Source ajoutée.');
        } catch (error) {
            showMessage(popup, error.message || 'Impossible d’ajouter la source.', true);
        }
    }

    async function deleteSource(popup, id) {
        try {
            const data = await postJson({ action: 'source_delete', csrf: state.sourceCsrf, id });
            state.sources = Array.isArray(data.sources) ? data.sources : state.sources;
            if (state.source === id) state.source = 'printables';
            renderSourceOptions(popup);
            showMessage(popup, 'Source supprimée.');
        } catch (error) {
            showMessage(popup, error.message || 'Impossible de supprimer la source.', true);
        }
    }

    function renderModels(popup, models) {
        const grid = popup.querySelector('[data-models-grid]');
        if (!grid) return;
        if (!Array.isArray(models) || !models.length) {
            grid.innerHTML = '<div class="dmd3d-models-empty">Aucun modèle trouvé pour cette recherche.</div>';
            return;
        }
        grid.innerHTML = models.map(model => `
            <button type="button" class="dmd3d-model-card" data-model-url="${esc(model.url)}" data-model-title="${esc(model.title || '')}" data-model-author="${esc(model.author || '')}" data-model-image-url="${esc(model.image || '')}">
                <span class="dmd3d-model-image">
                    ${model.image ? `<img src="${esc(model.image)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : '<span>🧊</span>'}
                </span>
                <span class="dmd3d-model-copy">
                    <strong title="${esc(model.title)}">${esc(model.title)}</strong>
                    <small>${model.author ? `par ${esc(model.author)}` : 'Auteur non indiqué'}</small>
                </span>
                <span class="dmd3d-button dmd3d-model-open">Voir le modèle</span>
            </button>
        `).join('');
        grid.querySelectorAll('img').forEach(image => {
            image.addEventListener('error', () => {
                const host = image.closest('.dmd3d-model-image');
                image.remove();
                if (host && !host.querySelector('span')) host.insertAdjacentHTML('beforeend', '<span>🧊</span>');
            }, { once: true });
        });
    }

    async function search(popup, query) {
        const input = popup.querySelector('[data-models-query]');
        const button = popup.querySelector('[data-models-search]');
        const grid = popup.querySelector('[data-models-grid]');
        const sourceSelect = popup.querySelector('[data-models-source]');
        query = String(query || '').trim();
        state.source = String(sourceSelect?.value || state.source || 'printables');
        const sourceName = state.sources.find(item => item.id === state.source)?.name || 'la source';
        if (!query) {
            showMessage(popup, 'Entre un mot-clé pour chercher un modèle STL / 3MF.', false);
            input?.focus();
            return;
        }
        button.disabled = true;
        grid.innerHTML = `<div class="dmd3d-models-empty">Recherche sur ${esc(sourceName)}…</div>`;
        showMessage(popup, 'Recherche en cours…');
        try {
            const data = await jsonRequest(`${state.endpoint}?action=search&source=${encodeURIComponent(state.source)}&q=${encodeURIComponent(query)}`);
            if (data.external_url) {
                grid.innerHTML = `
                    <div class="dmd3d-external-source-card">
                        <strong>${esc(data.source || sourceName)}</strong>
                        <span>Recherche « ${esc(query)} »</span>
                        <button type="button" class="dmd3d-button" data-external-url="${esc(data.external_url)}">Ouvrir cette source</button>
                    </div>`;
                showMessage(popup, 'Cette source utilise son moteur de recherche officiel.');
                return;
            }
            renderModels(popup, data.models || []);
            const count = Array.isArray(data.models) ? data.models.length : 0;
            showMessage(popup, `${count} modèle${count > 1 ? 's' : ''} affiché${count > 1 ? 's' : ''}. Clique sur un modèle pour voir sa fiche et ses fichiers.`);
        } catch (error) {
            grid.innerHTML = '<div class="dmd3d-models-empty">Impossible de charger les modèles.</div>';
            showMessage(popup, error.message || 'Erreur de la source.', true);
        } finally {
            button.disabled = false;
        }
    }

    function closeDetail() {
        removeWindow(state.detail);
        state.detail = null;
    }

    function closeExternal() {
        removeWindow(state.external);
        state.external = null;
    }

    function openExternalSource(url, sourceName, anchor) {
        closeExternal();
        if (!/^https:\/\//i.test(String(url || ''))) return;
        const win = document.createElement('section');
        win.className = 'dmd3d-window dmd3d-model-external-window';
        win.setAttribute('role', 'dialog');
        win.innerHTML = `
            <header class="dmd3d-window-head" data-models-window-head>
                <div><strong>${esc(sourceName || 'Source 3D')}</strong><small>Recherche externe</small></div>
                <div class="dmd3d-external-head-actions">
                    <a class="dmd3d-button" href="${esc(url)}" target="_blank" rel="noopener noreferrer" title="Ouvrir dans le navigateur">↗</a>
                    <button type="button" class="dmd3d-close" data-external-close title="Fermer">✕</button>
                </div>
            </header>
            <div class="dmd3d-model-external-body">
                <iframe src="${esc(url)}" title="${esc(sourceName || 'Source 3D')}"></iframe>
                <p>Si le site refuse l’affichage intégré, utilise le bouton ↗ en haut à droite.</p>
            </div>`;
        const width = Math.min(1120, Math.max(620, window.innerWidth - 70));
        const height = Math.min(780, Math.max(440, window.innerHeight - 90));
        const rect = anchor?.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
        win.style.width = `${width}px`;
        win.style.height = `${height}px`;
        win.style.left = `${Math.max(8, window.scrollX + (rect ? rect.left + 30 : (window.innerWidth - width) / 2))}px`;
        win.style.top = `${Math.max(8, window.scrollY + (rect ? rect.top + 30 : (window.innerHeight - height) / 2))}px`;
        document.body.appendChild(win);
        state.external = win;
        watchWindow(win);
        win.querySelector('[data-external-close]').addEventListener('click', closeExternal);
    }

    function fileMarkup(file) {
        const downloadable = !!file.downloadable || !!file.url;
        const action = file.kind === 'pack'
            ? `<button type="button" class="dmd3d-button" data-model-download-pack="${esc(file.id || '')}" data-model-id="${esc(file.model_id || '')}" data-model-filename="${esc(file.name || 'modele-3d.zip')}">Télécharger</button>`
            : (file.url
                ? `<button type="button" class="dmd3d-button" data-model-download="${esc(file.url)}" data-model-filename="${esc(file.name || 'modele-3d')}">Télécharger</button>`
                : '<span class="dmd3d-model-file-meta">Dans le pack</span>');
        return `
            <article class="dmd3d-model-file">
                <span class="dmd3d-model-file-type">${esc(file.extension || 'FICHIER')}</span>
                <div><strong title="${esc(file.name || 'Fichier')}">${esc(file.name || 'Fichier')}</strong><small>${esc(file.folder || file.file_type || file.extension || '')}</small></div>
                ${downloadable ? action : action}
            </article>`;
    }

    async function downloadModelFile(win, button) {
        const remoteUrl = String(button.dataset.modelDownload || '');
        const packId = String(button.dataset.modelDownloadPack || '');
        const modelId = String(button.dataset.modelId || '');
        if (!remoteUrl && !(packId && modelId)) return;
        const original = button.textContent;
        button.disabled = true;
        button.textContent = 'Téléchargement…';
        try {
            const downloadUrl = packId && modelId
                ? `${state.endpoint}?action=download_pack&model_id=${encodeURIComponent(modelId)}&pack_id=${encodeURIComponent(packId)}&name=${encodeURIComponent(button.dataset.modelFilename || 'modele-3d.zip')}`
                : `${state.endpoint}?action=download&url=${encodeURIComponent(remoteUrl)}`;
            const response = await fetch(downloadUrl, {
                credentials: 'same-origin',
                cache: 'no-store'
            });
            const contentType = String(response.headers.get('content-type') || '').toLowerCase();
            if (!response.ok || contentType.includes('application/json')) {
                let message = `Téléchargement impossible (HTTP ${response.status}).`;
                try {
                    const payload = await response.json();
                    if (payload && payload.message) message = payload.message;
                } catch (error) {}
                throw new Error(message);
            }
            const blob = await response.blob();
            if (!blob.size) throw new Error('Le fichier téléchargé est vide.');
            const objectUrl = URL.createObjectURL(blob);
            const anchor = document.createElement('a');
            anchor.href = objectUrl;
            anchor.download = button.dataset.modelFilename || 'modele-3d';
            anchor.style.display = 'none';
            document.body.appendChild(anchor);
            anchor.click();
            anchor.remove();
            setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
            const message = win.querySelector('[data-detail-download-message]');
            if (message) {
                message.textContent = `Téléchargement lancé : ${button.dataset.modelFilename || 'fichier'}`;
                message.classList.remove('is-error');
            }
        } catch (error) {
            const message = win.querySelector('[data-detail-download-message]');
            if (message) {
                message.textContent = error.message || 'Téléchargement impossible.';
                message.classList.add('is-error');
            }
        } finally {
            button.disabled = false;
            button.textContent = original;
        }
    }

    function renderDetail(win, model) {
        const images = Array.isArray(model.images) ? model.images : [];
        const files = Array.isArray(model.files) ? model.files : [];
        const mainImage = images[0] || '';
        win.querySelector('[data-detail-title]').textContent = model.title || 'Modèle 3D';
        win.querySelector('[data-detail-subtitle]').textContent = model.author ? `par ${model.author}` : (model.source || 'Printables');
        win.querySelector('[data-detail-body]').innerHTML = `
            <div class="dmd3d-model-detail-layout">
                <section class="dmd3d-model-gallery">
                    <div class="dmd3d-model-main-image" data-main-image>
                        ${mainImage ? `<img src="${esc(mainImage)}" alt="${esc(model.title || '')}" referrerpolicy="no-referrer">` : '<span>🧊</span>'}
                    </div>
                    <div class="dmd3d-model-thumbs">
                        ${images.map((image, index) => `<button type="button" class="${index === 0 ? 'is-active' : ''}" data-detail-image="${esc(image)}"><img src="${esc(image)}" alt="" loading="lazy" referrerpolicy="no-referrer"></button>`).join('')}
                    </div>
                </section>
                <section class="dmd3d-model-information">
                    <div class="dmd3d-model-detail-head">
                        <div><h3>${esc(model.title || 'Modèle 3D')}</h3><small>${model.author ? `Créé par ${esc(model.author)}` : 'Auteur non indiqué'} · Source : ${esc(model.source || 'Printables')}</small></div>
                    </div>
                    <p class="dmd3d-model-description">${esc(model.description || 'Aucune description publique disponible.')}</p>
                    <div class="dmd3d-section-title"><h3>Fichiers téléchargeables</h3><span class="dmd3d-count">${files.length}</span></div>
                    <div class="dmd3d-model-files">
                        ${files.length ? files.map(fileMarkup).join('') : `<div class="dmd3d-models-empty">Aucun fichier STL/3MF directement téléchargeable n’a été exposé par Printables pour ce modèle.</div>`}
                    </div>
                    <div class="dmd3d-inline-message" data-detail-download-message aria-live="polite"></div>
                </section>
            </div>`;

        win.querySelectorAll('[data-detail-image]').forEach(button => {
            button.addEventListener('click', () => {
                const target = win.querySelector('[data-main-image]');
                target.innerHTML = `<img src="${esc(button.dataset.detailImage || '')}" alt="${esc(model.title || '')}" referrerpolicy="no-referrer">`;
                win.querySelectorAll('[data-detail-image]').forEach(item => item.classList.toggle('is-active', item === button));
            });
        });
        win.querySelectorAll('[data-model-download], [data-model-download-pack]').forEach(button => {
            button.addEventListener('click', () => downloadModelFile(win, button));
        });
    }

    async function openDetail(card, anchor) {
        const modelUrl = String(card?.dataset?.modelUrl || '');
        closeDetail();
        const win = document.createElement('section');
        win.className = 'dmd3d-window dmd3d-model-detail-window';
        win.setAttribute('role', 'dialog');
        win.innerHTML = `
            <header class="dmd3d-window-head" data-models-window-head>
                <div><strong data-detail-title>Chargement du modèle…</strong><small data-detail-subtitle>Printables</small></div>
                <button type="button" class="dmd3d-close" data-detail-close title="Fermer">✕</button>
            </header>
            <div class="dmd3d-model-detail-body" data-detail-body>
                <div class="dmd3d-models-empty">Chargement des images et des fichiers…</div>
            </div>`;

        const width = Math.min(1060, Math.max(600, window.innerWidth - 80));
        const height = Math.min(760, Math.max(440, window.innerHeight - 100));
        const rect = anchor?.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
        win.style.width = `${width}px`;
        win.style.height = `${height}px`;
        win.style.left = `${Math.max(8, window.scrollX + (rect ? rect.left + 42 : (window.innerWidth - width) / 2))}px`;
        win.style.top = `${Math.max(8, window.scrollY + (rect ? rect.top + 42 : (window.innerHeight - height) / 2))}px`;
        document.body.appendChild(win);
        state.detail = win;
        watchWindow(win);
        win.querySelector('[data-detail-close]').addEventListener('click', closeDetail);

        try {
            const params = new URLSearchParams({
                action: 'detail',
                source: state.source || 'printables',
                url: modelUrl,
                title: String(card?.dataset?.modelTitle || ''),
                author: String(card?.dataset?.modelAuthor || ''),
                image: String(card?.dataset?.modelImageUrl || '')
            });
            const data = await jsonRequest(`${state.endpoint}?${params.toString()}`);
            if (!state.detail || state.detail !== win) return;
            renderDetail(win, data.model || {});
        } catch (error) {
            win.querySelector('[data-detail-body]').innerHTML = `<div class="dmd3d-models-empty is-error">${esc(error.message || 'Impossible de charger la fiche du modèle.')}</div>`;
        }
    }

    function closeBrowser() {
        closeDetail();
        closeExternal();
        removeWindow(state.browser);
        state.browser = null;
    }

    function openBrowser(anchor) {
        if (state.browser && document.body.contains(state.browser)) {
            bringToFront(state.browser);
            state.browser.querySelector('[data-models-query]')?.focus();
            return state.browser;
        }
        const popup = document.createElement('section');
        popup.className = 'dmd3d-window dmd3d-models-window';
        popup.setAttribute('role', 'dialog');
        popup.innerHTML = `
            <header class="dmd3d-window-head" data-models-window-head>
                <div><strong>Voir les modèles</strong><small>Sources 3D — DMD-3DPRINT</small></div>
                <button type="button" class="dmd3d-close" data-models-close title="Fermer">✕</button>
            </header>
            <div class="dmd3d-models-body">
                <form class="dmd3d-models-search" data-models-form>
                    <select data-models-source aria-label="Source de modèles"><option value="printables">Printables</option></select>
                    <input type="search" maxlength="100" autocomplete="off" placeholder="Ex. Raspberry Pi, Benchy, support casque…" data-models-query>
                    <button type="submit" class="dmd3d-button" data-models-search>Rechercher</button>
                    <button type="button" class="dmd3d-button" data-models-source-manage hidden>+ Source</button>
                </form>
                <section class="dmd3d-source-manager" data-models-source-panel hidden>
                    <div class="dmd3d-source-add">
                        <input type="text" maxlength="80" placeholder="Nom de la source" data-models-source-name>
                        <input type="url" maxlength="500" placeholder="https://cults3d.com/fr" data-models-source-url>
                        <button type="button" class="dmd3d-button" data-models-source-save>Ajouter</button>
                    </div>
                    <div class="dmd3d-source-list" data-models-source-list></div>
                </section>
                <div class="dmd3d-models-grid" data-models-grid>
                    <div class="dmd3d-models-empty">Entre un mot-clé pour afficher les modèles.</div>
                </div>
                <div class="dmd3d-inline-message" data-models-message aria-live="polite"></div>
            </div>`;

        const width = Math.min(980, Math.max(520, window.innerWidth - 70));
        const height = Math.min(720, Math.max(420, window.innerHeight - 90));
        const rect = anchor?.getBoundingClientRect ? anchor.getBoundingClientRect() : null;
        popup.style.width = `${width}px`;
        popup.style.height = `${height}px`;
        popup.style.left = `${Math.max(8, window.scrollX + (rect ? rect.left + 35 : (window.innerWidth - width) / 2))}px`;
        popup.style.top = `${Math.max(8, window.scrollY + (rect ? rect.top + 35 : (window.innerHeight - height) / 2))}px`;
        document.body.appendChild(popup);
        state.browser = popup;
        watchWindow(popup);

        popup.querySelector('[data-models-close]').addEventListener('click', closeBrowser);
        popup.querySelector('[data-models-form]').addEventListener('submit', event => {
            event.preventDefault();
            search(popup, popup.querySelector('[data-models-query]').value);
        });
        popup.querySelector('[data-models-source]').addEventListener('change', event => {
            state.source = String(event.target.value || 'printables');
        });
        popup.querySelector('[data-models-source-manage]').addEventListener('click', () => toggleSourceManager(popup));
        popup.querySelector('[data-models-source-save]').addEventListener('click', () => addSource(popup));
        popup.querySelector('[data-models-source-list]').addEventListener('click', event => {
            const button = event.target.closest('[data-models-source-delete]');
            if (button) deleteSource(popup, button.dataset.modelsSourceDelete || '');
        });
        popup.querySelector('[data-models-grid]').addEventListener('click', event => {
            const external = event.target.closest('[data-external-url]');
            if (external) {
                const sourceName = state.sources.find(item => item.id === state.source)?.name || 'Source 3D';
                openExternalSource(external.dataset.externalUrl || '', sourceName, popup);
                return;
            }
            const card = event.target.closest('[data-model-url]');
            if (card) openDetail(card, popup);
        });
        loadSources(popup).catch(error => showMessage(popup, error.message || 'Impossible de charger les sources.', true));
        popup.querySelector('[data-models-query]').focus();
        return popup;
    }

    document.addEventListener('click', event => {
        const button = event.target.closest('[data-dmd3d-models]');
        if (!button) return;
        event.preventDefault();
        openBrowser(button.closest('.dmd3d-control-window') || button.closest('.dmd3d-window') || null);
    });

    window.addEventListener('resize', updateScrollArea, { passive: true });
    window.DMD3DModels = { __ready: true, open: openBrowser, close: closeBrowser };
})();
