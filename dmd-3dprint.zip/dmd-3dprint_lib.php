<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
define('DMD3D_MODULE_ID', 'dmd-3dprint');
define('DMD3D_MODULE_NAME', 'DMD-3DPRINT');
define('DMD3D_MODULE_VERSION', '1.2.0');
define('DMD3D_ROOT', __DIR__);
define('DMD3D_DOMYDESK_ROOT', realpath(__DIR__ . '/../..') ?: dirname(__DIR__, 2));
define('DMD3D_DATA_ROOT', DMD3D_DOMYDESK_ROOT . '/data/modules/' . DMD3D_MODULE_ID);
define('DMD3D_PRINTER_MODELS_DIR', DMD3D_DATA_ROOT . '/models/imprimantes');
define('DMD3D_PLUG_MODELS_DIR', DMD3D_DATA_ROOT . '/models/prises');
define('DMD3D_UPLOADS_DIR', DMD3D_DATA_ROOT . '/uploads');
define('DMD3D_REGISTERS_DIR', DMD3D_DATA_ROOT . '/registers');
define('DMD3D_LOGS_DIR', DMD3D_DATA_ROOT . '/logs');
define('DMD3D_ACTIVITY_DIR', DMD3D_DATA_ROOT . '/activity');
define('DMD3D_ACCESS_DIR', DMD3D_DATA_ROOT . '/access');
define('DMD3D_SECURE_DIR', DMD3D_DATA_ROOT . '/secure');
define('DMD3D_PRINTERS_FILE', DMD3D_REGISTERS_DIR . '/imprimantes.json');
define('DMD3D_PLUGS_FILE', DMD3D_REGISTERS_DIR . '/prise.json');
define('DMD3D_RESOURCE_ACL_FILE', DMD3D_ACCESS_DIR . '/resources.json');
define('DMD3D_MODEL_SOURCES_FILE', DMD3D_DATA_ROOT . '/model_sources.json');

$dmd3dPermissions = DMD3D_DOMYDESK_ROOT . '/core/dmd_permissions.php';
if (is_file($dmd3dPermissions)) {
    require_once $dmd3dPermissions;
}
$dmd3dQuickSession = DMD3D_DOMYDESK_ROOT . '/core/dmd_quick_session.php';
if (is_file($dmd3dQuickSession)) {
    require_once $dmd3dQuickSession;
}
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool
    {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}
if (!function_exists('str_starts_with')) {
    function str_starts_with(string $haystack, string $needle): bool
    {
        return $needle === '' || substr($haystack, 0, strlen($needle)) === $needle;
    }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with(string $haystack, string $needle): bool
    {
        return $needle === '' || substr($haystack, -strlen($needle)) === $needle;
    }
}

function dmd3d_copy_tree(string $source, string $destination): void
{
    if (!is_dir($source)) {
        return;
    }
    if (!is_dir($destination) && !mkdir($destination, 0750, true) && !is_dir($destination)) {
        throw new RuntimeException('Impossible de créer le stockage persistant.');
    }
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $item) {
        $relative = substr($item->getPathname(), strlen($source) + 1);
        $target = $destination . '/' . str_replace('\\', '/', $relative);
        if ($item->isDir()) {
            if (!is_dir($target) && !mkdir($target, 0750, true) && !is_dir($target)) {
                throw new RuntimeException('Impossible de migrer un dossier du module.');
            }
        } elseif (!is_file($target)) {
            $parent = dirname($target);
            if (!is_dir($parent) && !mkdir($parent, 0750, true) && !is_dir($parent)) {
                throw new RuntimeException('Impossible de migrer un fichier du module.');
            }
            if (!copy($item->getPathname(), $target)) {
                throw new RuntimeException('Impossible de migrer les données existantes du module.');
            }
            @chmod($target, 0640);
        }
    }
}

function dmd3d_migrate_legacy_storage(): void
{
    $marker = DMD3D_DATA_ROOT . '/.migration-1.2.0.json';
    if (is_file($marker)) {
        return;
    }

    $migrated = [];
    $legacyRegisters = DMD3D_ROOT . '/registers';
    foreach ([
        [$legacyRegisters . '/imprimantes.json', DMD3D_PRINTERS_FILE, 'registers/imprimantes.json'],
        [$legacyRegisters . '/prise.json', DMD3D_PLUGS_FILE, 'registers/prise.json'],
    ] as $pair) {
        if (is_file($pair[0]) && !is_file($pair[1])) {
            if (!copy($pair[0], $pair[1])) {
                throw new RuntimeException('Impossible de migrer ' . $pair[2] . '.');
            }
            @chmod($pair[1], 0640);
            $migrated[] = $pair[2];
        }
    }

    foreach ([
        [DMD3D_ROOT . '/imprimantes', DMD3D_PRINTER_MODELS_DIR, 'imprimantes'],
        [DMD3D_ROOT . '/prises', DMD3D_PLUG_MODELS_DIR, 'prises'],
        [DMD3D_ROOT . '/uploads', DMD3D_UPLOADS_DIR, 'uploads'],
    ] as $pair) {
        if (is_dir($pair[0])) {
            dmd3d_copy_tree($pair[0], $pair[1]);
            $migrated[] = $pair[2];
        }
    }

    dmd3d_write_json($marker, [
        'version' => '1.2.0',
        'date' => date(DATE_ATOM),
        'source' => 'modules/dmd-3dprint',
        'destination' => 'data/modules/dmd-3dprint',
        'copied' => array_values(array_unique($migrated)),
    ]);
}

function dmd3d_bootstrap_storage(): void
{
    foreach ([
        DMD3D_DATA_ROOT,
        DMD3D_PRINTER_MODELS_DIR,
        DMD3D_PLUG_MODELS_DIR,
        DMD3D_UPLOADS_DIR,
        DMD3D_REGISTERS_DIR,
        DMD3D_LOGS_DIR,
        DMD3D_ACTIVITY_DIR,
        DMD3D_ACCESS_DIR,
        DMD3D_SECURE_DIR,
    ] as $dir) {
        if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('Impossible de créer le dossier persistant : ' . basename($dir));
        }
    }

    $deny = DMD3D_DATA_ROOT . '/.htaccess';
    if (!is_file($deny)) {
        @file_put_contents($deny, "Require all denied
Order allow,deny
Deny from all
Options -Indexes
", LOCK_EX);
        @chmod($deny, 0640);
    }

    dmd3d_migrate_legacy_storage();

    if (!is_file(DMD3D_PRINTERS_FILE)) {
        dmd3d_write_json(DMD3D_PRINTERS_FILE, ['imprimantes' => []]);
    }
    if (!is_file(DMD3D_PLUGS_FILE)) {
        dmd3d_write_json(DMD3D_PLUGS_FILE, ['prises' => []]);
    }
    if (!is_file(DMD3D_RESOURCE_ACL_FILE)) {
        dmd3d_write_json(DMD3D_RESOURCE_ACL_FILE, ['version' => 1, 'resources' => []]);
    }
    if (!is_file(DMD3D_MODEL_SOURCES_FILE)) {
        dmd3d_write_json(DMD3D_MODEL_SOURCES_FILE, [
            'version' => 1,
            'sources' => [
                [
                    'id' => 'printables',
                    'name' => 'Printables',
                    'type' => 'printables',
                    'search_url' => 'https://www.printables.com/search/models?q={query}',
                    'locked' => true,
                ],
            ],
        ]);
    }

    dmd3d_upgrade_register_secrets();
}

function dmd3d_read_json(string $file, array $fallback): array
{
    if (!is_file($file)) {
        return $fallback;
    }

    $raw = file_get_contents($file);
    if ($raw === false || trim($raw) === '') {
        return $fallback;
    }

    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : $fallback;
}

function dmd3d_write_json(string $file, array $data): void
{
    $directory = dirname($file);
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        throw new RuntimeException('Impossible de créer le dossier de stockage.');
    }

    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        throw new RuntimeException('Impossible de convertir les données JSON.');
    }

    $temp = $file . '.tmp-' . bin2hex(random_bytes(5));
    if (file_put_contents($temp, $json . PHP_EOL, LOCK_EX) === false) {
        throw new RuntimeException('Impossible d’écrire le fichier temporaire.');
    }
    @chmod($temp, 0640);

    if (!rename($temp, $file)) {
        @unlink($temp);
        throw new RuntimeException('Impossible de remplacer le registre JSON.');
    }
}

function dmd3d_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function dmd3d_input(): array
{
    $contentType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
    if (str_contains($contentType, 'application/json')) {
        $raw = file_get_contents('php://input');
        $decoded = json_decode((string)$raw, true);
        return is_array($decoded) ? $decoded : [];
    }
    return $_POST;
}

function dmd3d_is_admin(): bool
{
    $values = [
        $_SESSION['role_system'] ?? null,
        $_SESSION['role'] ?? null,
        $_SESSION['user']['role_system'] ?? null,
        $_SESSION['user']['role'] ?? null,
    ];

    foreach ($values as $value) {
        if (in_array(strtolower(trim((string)$value)), ['admin', 'administrator', 'superadmin'], true)) {
            return true;
        }
    }
    return false;
}

function dmd3d_is_logged_in(): bool
{
    if (dmd3d_is_admin()) {
        return true;
    }
    return !empty($_SESSION['user']['email'])
        || !empty($_SESSION['email'])
        || !empty($_SESSION['user_email'])
        || !empty($_SESSION['user']['id'])
        || !empty($_SESSION['user_id'])
        || !empty($_SESSION['logged_in'])
        || !empty($_SESSION['authenticated']);
}

function dmd3d_require_login(): void
{
    if (!dmd3d_is_logged_in()) {
        dmd3d_response(['ok' => false, 'message' => 'Connexion requise.'], 401);
    }
}

function dmd3d_require_admin(): void
{
    if (!dmd3d_is_admin()) {
        dmd3d_response(['ok' => false, 'message' => 'Accès administrateur requis.'], 403);
    }
}


function dmd3d_user_email(): string
{
    return trim((string)(
        $_SESSION['user']['email']
        ?? $_SESSION['email']
        ?? $_SESSION['user_email']
        ?? ''
    ));
}

function dmd3d_has_permission(string $permission): bool
{
    if (!dmd3d_is_logged_in()) {
        return false;
    }

    if (!function_exists('dmd_current_user_has_module_permission')) {
        return false;
    }

    try {
        return (bool)dmd_current_user_has_module_permission(DMD3D_MODULE_ID, $permission);
    } catch (Throwable $error) {
        error_log('[DMD-3DPRINT] Permission Core: ' . $error->getMessage());
        return false;
    }
}

function dmd3d_require_permission(string $permission): void
{
    if (!dmd3d_has_permission($permission)) {
        dmd3d_response([
            'ok' => false,
            'message' => 'Permission DoMyDesk refusée : ' . $permission . '.',
            'permission' => $permission,
        ], 403);
    }
}

function dmd3d_crypto_key(): string
{
    $file = DMD3D_SECURE_DIR . '/dmd-3dprint.key';
    if (!is_file($file)) {
        $raw = random_bytes(32);
        if (file_put_contents($file, base64_encode($raw), LOCK_EX) === false) {
            throw new RuntimeException('Impossible de créer la clé de chiffrement DMD-3DPRINT.');
        }
        @chmod($file, 0600);
    }
    $encoded = trim((string)file_get_contents($file));
    $key = base64_decode($encoded, true);
    if (!is_string($key) || strlen($key) !== 32) {
        throw new RuntimeException('Clé de chiffrement DMD-3DPRINT invalide.');
    }
    return $key;
}

function dmd3d_encrypt_secret(string $plain): string
{
    if ($plain === '') {
        return '';
    }
    if (!function_exists('openssl_encrypt')) {
        throw new RuntimeException('OpenSSL est requis pour enregistrer les identifiants DMD-3DPRINT.');
    }
    $key = dmd3d_crypto_key();
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    if ($cipher === false) {
        throw new RuntimeException('Échec du chiffrement DMD-3DPRINT.');
    }
    $mac = hash_hmac('sha256', $iv . $cipher, $key, true);
    return 'enc:v1:' . base64_encode($iv) . ':' . base64_encode($cipher) . ':' . base64_encode($mac);
}

function dmd3d_decrypt_secret(string $encoded): string
{
    if ($encoded === '') {
        return '';
    }
    if (strpos($encoded, 'enc:v1:') !== 0) {
        return $encoded;
    }
    if (!function_exists('openssl_decrypt')) {
        throw new RuntimeException('OpenSSL est requis pour lire les identifiants DMD-3DPRINT.');
    }
    $parts = explode(':', $encoded, 5);
    if (count($parts) !== 5) {
        throw new RuntimeException('Secret DMD-3DPRINT corrompu.');
    }
    $iv = base64_decode($parts[2], true);
    $cipher = base64_decode($parts[3], true);
    $mac = base64_decode($parts[4], true);
    if (!is_string($iv) || !is_string($cipher) || !is_string($mac) || strlen($iv) !== 16) {
        throw new RuntimeException('Secret DMD-3DPRINT invalide.');
    }
    $key = dmd3d_crypto_key();
    $expected = hash_hmac('sha256', $iv . $cipher, $key, true);
    if (!hash_equals($expected, $mac)) {
        throw new RuntimeException('Intégrité du secret DMD-3DPRINT invalide.');
    }
    $plain = openssl_decrypt($cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    if ($plain === false) {
        throw new RuntimeException('Impossible de déchiffrer un secret DMD-3DPRINT.');
    }
    return $plain;
}

function dmd3d_seal_device_secrets(array $device): array
{
    foreach (['password', 'api_key', 'token', 'secret'] as $field) {
        $encField = $field . '_enc';
        $plain = trim((string)($device[$field] ?? ''));
        $encoded = trim((string)($device[$encField] ?? ''));

        if ($plain !== '') {
            $encoded = dmd3d_encrypt_secret($plain);
        } elseif ($encoded !== '' && strpos($encoded, 'enc:v1:') !== 0) {
            $encoded = dmd3d_encrypt_secret($encoded);
        }

        unset($device[$field]);
        $device[$encField] = $encoded;
    }
    return $device;
}

function dmd3d_upgrade_register_secrets(): void
{
    foreach ([
        [DMD3D_PRINTERS_FILE, 'imprimantes'],
        [DMD3D_PLUGS_FILE, 'prises'],
    ] as $definition) {
        $file = $definition[0];
        $rootKey = $definition[1];
        $data = dmd3d_read_json($file, [$rootKey => []]);
        $items = is_array($data[$rootKey] ?? null) ? array_values($data[$rootKey]) : [];
        $changed = false;

        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }
            $sealed = dmd3d_seal_device_secrets($item);
            if ($sealed !== $item) {
                $items[$index] = $sealed;
                $changed = true;
            }
        }

        if ($changed) {
            dmd3d_write_json($file, [$rootKey => array_values($items)]);
        }
    }
}

function dmd3d_decode_device_secrets(array $device): array
{
    foreach (['password', 'api_key', 'token', 'secret'] as $field) {
        $encField = $field . '_enc';
        if (!empty($device[$encField])) {
            $device[$field] = dmd3d_decrypt_secret((string)$device[$encField]);
        }
    }
    return $device;
}

function dmd3d_resource(string $type, array $device): array
{
    $resourceTypes = [
        'printer' => ['type' => 'printer', 'fallback' => 'Imprimante 3D'],
        'plug' => ['type' => 'smart_plug', 'fallback' => 'Prise'],
        'printer_model' => ['type' => 'printer_model', 'fallback' => 'Modèle imprimante'],
        'plug_model' => ['type' => 'smart_plug_model', 'fallback' => 'Modèle prise'],
    ];
    $meta = $resourceTypes[$type] ?? $resourceTypes['printer'];
    $resourceType = $meta['type'];
    $id = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($device['id'] ?? '')) ?: 'unknown';
    return [
        'type' => $resourceType,
        'id' => DMD3D_MODULE_ID . ':' . $resourceType . ':' . $id,
        'local_id' => $id,
        'name' => dmd3d_clean_text($device['name'] ?? $meta['fallback'], 120),
        'module' => DMD3D_MODULE_ID,
    ];
}

function dmd3d_sanitize_public_payload($value, bool $allowCamera = true)
{
    if (!is_array($value)) {
        return $value;
    }

    $clean = [];
    foreach ($value as $key => $item) {
        $name = strtolower((string)$key);
        $sensitive = strpos($name, 'password') !== false
            || strpos($name, 'token') !== false
            || strpos($name, 'secret') !== false
            || strpos($name, 'api_key') !== false
            || strpos($name, 'apikey') !== false;
        $camera = strpos($name, 'camera') !== false || strpos($name, 'webrtc') !== false;
        if ($sensitive || (!$allowCamera && $camera)) {
            continue;
        }
        $clean[$key] = is_array($item) ? dmd3d_sanitize_public_payload($item, $allowCamera) : $item;
    }
    return $clean;
}

function dmd3d_sanitize_log_details(array $details): array
{
    $clean = [];
    foreach ($details as $key => $value) {
        $keyText = strtolower((string)$key);
        if (strpos($keyText, 'password') !== false || strpos($keyText, 'token') !== false
            || strpos($keyText, 'secret') !== false || strpos($keyText, 'api_key') !== false) {
            continue;
        }
        if (is_scalar($value) || $value === null) {
            $clean[(string)$key] = is_string($value) ? dmd3d_clean_text($value, 1000) : $value;
        } elseif (is_array($value)) {
            $clean[(string)$key] = dmd3d_sanitize_log_details($value);
        }
    }
    return $clean;
}

function dmd3d_quick_session_label(string $action, array $resource): string
{
    $labels = [
        'printer.start' => 'Impression démarrée',
        'printer.pause' => 'Impression mise en pause',
        'printer.resume' => 'Impression reprise',
        'printer.stop' => 'Impression arrêtée',
        'printer.light_on' => 'Lumière allumée',
        'printer.light_off' => 'Lumière éteinte',
        'printer.fan' => 'Ventilation modifiée',
        'printer.upload_file' => 'Fichier envoyé à l’imprimante',
        'plug.power_on' => 'Prise allumée',
        'plug.power_off' => 'Prise éteinte',
        'config.printer.save' => 'Configuration imprimante enregistrée',
        'config.printer.delete' => 'Imprimante supprimée',
        'config.printer.test' => 'Connexion imprimante testée',
        'config.plug.save' => 'Configuration prise enregistrée',
        'config.plug.delete' => 'Prise supprimée',
        'config.plug.test' => 'Connexion prise testée',
        'model.install' => 'Modèle matériel installé',
        'model.delete' => 'Modèle matériel supprimé',
    ];

    $label = $labels[$action] ?? str_replace(['.', '_'], ' ', $action);
    $name = trim((string)($resource['name'] ?? ''));
    return $name !== '' ? $label . ' · ' . $name : $label;
}

function dmd3d_try_quick_session_sink(array $event): bool
{
    if (!function_exists('dmd_qs_get_active') || !function_exists('dmd_qs_add_timeline_event')) {
        return false;
    }

    $email = dmd3d_user_email();
    if ($email === '') {
        return false;
    }

    try {
        $active = dmd_qs_get_active($email);
        if (!is_array($active) || $active === []) {
            return false;
        }

        $resource = is_array($event['resource'] ?? null) ? $event['resource'] : [];
        $result = strtolower(trim((string)($event['result'] ?? 'ok')));
        $status = in_array($result, ['ok', 'success', 'online', 'on'], true) ? 'success' : $result;
        if ($status === '') {
            $status = 'success';
        }

        $details = is_array($event['details'] ?? null) ? $event['details'] : [];
        $detailsText = '';
        if ($details !== []) {
            $encoded = json_encode($details, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (is_string($encoded)) {
                $detailsText = $encoded;
            }
        }

        dmd_qs_add_timeline_event($email, [
            'module' => DMD3D_MODULE_ID,
            'action' => (string)($event['action'] ?? ''),
            'label' => dmd3d_quick_session_label((string)($event['action'] ?? ''), $resource),
            'target' => (string)($resource['name'] ?? ($event['target'] ?? '')),
            'status' => $status,
            'details' => $detailsText,
            'resource' => $resource,
        ]);

        return true;
    } catch (Throwable $error) {
        error_log('[DMD-3DPRINT] Quick-Session: ' . $error->getMessage());
        return false;
    }
}

function dmd3d_record_event(string $action, string $type, array $device, string $result = 'ok', array $details = []): void
{
    $resource = dmd3d_resource($type, $device);
    $event = [
        'date' => date(DATE_ATOM),
        'user' => dmd3d_user_email(),
        'module' => DMD3D_MODULE_ID,
        'module_name' => DMD3D_MODULE_NAME,
        'action' => $action,
        'target' => $resource['name'],
        'result' => $result,
        'resource' => $resource,
        'details' => dmd3d_sanitize_log_details($details),
    ];

    $logFile = DMD3D_LOGS_DIR . '/' . date('Y-m') . '.jsonl';
    $line = json_encode($event, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($line !== false) {
        @file_put_contents($logFile, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
        @chmod($logFile, 0640);
    }

    $indexFile = DMD3D_ACTIVITY_DIR . '/resources.json';
    $index = dmd3d_read_json($indexFile, ['version' => 1, 'resources' => []]);
    if (!is_array($index['resources'] ?? null)) {
        $index['resources'] = [];
    }
    $index['resources'][$resource['id']] = [
        'type' => $resource['type'],
        'id' => $resource['id'],
        'name' => $resource['name'],
        'last_action' => $action,
        'last_result' => $result,
        'last_user' => $event['user'],
        'updated_at' => $event['date'],
    ];
    dmd3d_write_json($indexFile, $index);

    dmd3d_try_quick_session_sink($event);
}

function dmd3d_resource_access_key(string $type, array $device): string
{
    return (string)(dmd3d_resource($type, $device)['id'] ?? '');
}

function dmd3d_read_resource_access(): array
{
    $data = dmd3d_read_json(DMD3D_RESOURCE_ACL_FILE, ['version' => 1, 'resources' => []]);
    if (!isset($data['resources']) || !is_array($data['resources'])) {
        $data['resources'] = [];
    }
    $data['version'] = 1;
    return $data;
}

function dmd3d_resource_access_rule(string $type, array $device): array
{
    $key = dmd3d_resource_access_key($type, $device);
    $data = dmd3d_read_resource_access();
    $raw = $key !== '' && isset($data['resources'][$key]) && is_array($data['resources'][$key])
        ? $data['resources'][$key]
        : [];
    $mode = strtolower(trim((string)($raw['mode'] ?? 'everyone')));
    if (!in_array($mode, ['everyone', 'selected'], true)) {
        $mode = 'everyone';
    }
    $users = [];
    foreach ((array)($raw['users'] ?? []) as $email) {
        $email = strtolower(trim((string)$email));
        if ($email !== '' && !in_array($email, $users, true)) {
            $users[] = $email;
        }
    }
    sort($users, SORT_NATURAL | SORT_FLAG_CASE);
    return ['mode' => $mode, 'users' => $users];
}

function dmd3d_acl_user_exists(string $email): bool
{
    $email = trim($email);
    if ($email === '') {
        return false;
    }
    if (function_exists('dmd_safe_user_key')) {
        $safe = (string)dmd_safe_user_key($email);
        if ($safe === '') {
            return false;
        }
    } else {
        if (strpos($email, '..') !== false || strpos($email, '/') !== false || strpos($email, '\\') !== false || basename($email) !== $email) {
            return false;
        }
        $safe = $email;
    }
    return is_dir(DMD3D_DOMYDESK_ROOT . '/users/profiles/' . $safe);
}

function dmd3d_normalize_acl_users($users): array
{
    if (is_string($users)) {
        $decoded = json_decode($users, true);
        $users = is_array($decoded) ? $decoded : [$users];
    }
    if (!is_array($users)) {
        $users = [];
    }
    $out = [];
    foreach ($users as $email) {
        $email = strtolower(trim((string)$email));
        if ($email === '' || !dmd3d_acl_user_exists($email) || in_array($email, $out, true)) {
            continue;
        }
        $out[] = $email;
    }
    sort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return $out;
}

function dmd3d_save_resource_access(string $type, array $device, string $mode, $users = []): array
{
    $key = dmd3d_resource_access_key($type, $device);
    if ($key === '') {
        throw new InvalidArgumentException('Ressource invalide pour le partage.');
    }
    $mode = strtolower(trim($mode));
    if (!in_array($mode, ['everyone', 'selected'], true)) {
        throw new InvalidArgumentException('Mode de partage invalide.');
    }
    $data = dmd3d_read_resource_access();
    $before = dmd3d_resource_access_rule($type, $device);
    $normalizedUsers = $mode === 'selected' ? dmd3d_normalize_acl_users($users) : [];
    if ($mode === 'everyone') {
        unset($data['resources'][$key]);
    } else {
        $data['resources'][$key] = [
            'mode' => 'selected',
            'users' => $normalizedUsers,
            'updated_at' => date(DATE_ATOM),
            'updated_by' => dmd3d_user_email(),
        ];
    }
    dmd3d_write_json(DMD3D_RESOURCE_ACL_FILE, $data);
    $after = ['mode' => $mode, 'users' => $normalizedUsers];
    return [
        'rule' => $after,
        'changed' => $before !== $after,
        'added' => array_values(array_diff($after['users'], $before['users'])),
        'removed' => array_values(array_diff($before['users'], $after['users'])),
    ];
}

function dmd3d_delete_resource_access(string $type, array $device): void
{
    $key = dmd3d_resource_access_key($type, $device);
    if ($key === '') {
        return;
    }
    $data = dmd3d_read_resource_access();
    if (array_key_exists($key, $data['resources'])) {
        unset($data['resources'][$key]);
        dmd3d_write_json(DMD3D_RESOURCE_ACL_FILE, $data);
    }
}

function dmd3d_user_can_access_device(string $type, array $device, ?string $email = null): bool
{
    if (dmd3d_is_admin()) {
        return true;
    }
    $email = strtolower(trim((string)($email ?? dmd3d_user_email())));
    if ($email === '') {
        return false;
    }
    $rule = dmd3d_resource_access_rule($type, $device);
    return $rule['mode'] === 'everyone' || in_array($email, $rule['users'], true);
}

function dmd3d_require_device_access(string $type, array $device): void
{
    if (!dmd3d_user_can_access_device($type, $device)) {
        $resource = dmd3d_resource($type, $device);
        dmd3d_response([
            'ok' => false,
            'message' => 'Accès refusé à cette ressource.',
            'resource' => (string)($resource['id'] ?? ''),
        ], 403);
    }
}

function dmd3d_filter_accessible_devices(string $type, array $devices): array
{
    return array_values(array_filter($devices, static function ($device) use ($type) {
        return is_array($device) && dmd3d_user_can_access_device($type, $device);
    }));
}

function dmd3d_acl_users_catalog(): array
{
    $profilesRoot = DMD3D_DOMYDESK_ROOT . '/users/profiles';
    $users = [];
    if (!is_dir($profilesRoot)) {
        return $users;
    }
    foreach (glob($profilesRoot . '/*', GLOB_ONLYDIR) ?: [] as $dir) {
        $folder = basename($dir);
        $profile = function_exists('dmd_read_profile') ? dmd_read_profile($folder) : [];
        $email = strtolower(trim((string)($profile['email'] ?? $folder)));
        if ($email === '' || !dmd3d_acl_user_exists($email)) {
            continue;
        }
        $first = trim((string)($profile['prenom'] ?? ''));
        $last = trim((string)($profile['nom'] ?? ''));
        $pseudo = trim((string)($profile['pseudo'] ?? ''));
        $name = trim($first . ' ' . $last);
        if ($name === '') {
            $name = $pseudo !== '' ? $pseudo : $email;
        }
        $users[] = [
            'email' => $email,
            'name' => dmd3d_clean_text($name, 120),
            'role_system' => dmd3d_clean_text($profile['role_system'] ?? 'user', 40),
            'module_access' => function_exists('dmd_user_can_use_module') ? (bool)dmd_user_can_use_module($email, DMD3D_MODULE_ID) : false,
        ];
    }
    usort($users, static function ($a, $b) {
        return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? ''));
    });
    return $users;
}

function dmd3d_public_device_with_access(string $type, array $device): array
{
    $public = dmd3d_public_device($device);
    $public['resource_access'] = dmd3d_resource_access_rule($type, $device);
    return $public;
}

function dmd3d_permission_snapshot(): array
{
    $permissions = [
        'module.view',
        'printer.status', 'printer.details', 'camera.view',
        'printer.start', 'printer.pause', 'printer.resume', 'printer.stop',
        'printer.light', 'printer.fan', 'printer.upload',
        'plug.view', 'plug.power',
        'config.view', 'config.printer.save', 'config.printer.delete', 'config.printer.test',
        'config.plug.save', 'config.plug.delete', 'config.plug.test',
        'model.install', 'model.delete', 'logs.view', 'logs.delete',
    ];
    $result = [];
    foreach ($permissions as $permission) {
        $result[$permission] = dmd3d_has_permission($permission);
    }
    return $result;
}

function dmd3d_csrf_token(): string
{
    if (empty($_SESSION['dmd3d_csrf']) || !is_string($_SESSION['dmd3d_csrf'])) {
        $_SESSION['dmd3d_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['dmd3d_csrf'];
}

function dmd3d_require_csrf(array $input = []): void
{
    $received = (string)($input['csrf'] ?? $_POST['csrf'] ?? $_SERVER['HTTP_X_DMD3D_CSRF'] ?? '');
    if ($received === '' || !hash_equals(dmd3d_csrf_token(), $received)) {
        dmd3d_response(['ok' => false, 'message' => 'Jeton de sécurité invalide. Recharge le module.'], 419);
    }
}

function dmd3d_clean_text($value, int $max = 255): string
{
    $value = trim((string)$value);
    if (function_exists('mb_substr')) {
        return mb_substr($value, 0, $max);
    }
    return substr($value, 0, $max);
}

function dmd3d_clean_host($value): string
{
    $host = trim((string)$value);
    if ($host === '' || strlen($host) > 253 || !preg_match('/^[A-Za-z0-9._:\-\[\]]+$/', $host)) {
        throw new InvalidArgumentException('Adresse IP ou nom DNS invalide.');
    }
    return $host;
}

function dmd3d_clean_protocol($value): string
{
    $protocol = strtolower(trim((string)$value));
    return in_array($protocol, ['http', 'https'], true) ? $protocol : 'http';
}

function dmd3d_clean_port($value, int $default = 80): int
{
    $port = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]);
    return $port === false ? $default : (int)$port;
}

function dmd3d_slug(string $value): string
{
    $value = trim($value);
    if (function_exists('iconv')) {
        $converted = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if ($converted !== false) {
            $value = $converted;
        }
    }
    $value = preg_replace('/[^A-Za-z0-9_-]+/', '-', $value) ?? '';
    $value = trim($value, '-_');
    if ($value === '' || strlen($value) > 100) {
        throw new InvalidArgumentException('Nom de modèle invalide.');
    }
    return $value;
}

function dmd3d_safe_relative_path(string $path): bool
{
    $path = str_replace('\\', '/', $path);
    return $path !== ''
        && !str_starts_with($path, '/')
        && !preg_match('/^[A-Za-z]:\//', $path)
        && !preg_match('#(^|/)\.\.(/|$)#', $path)
        && !str_contains($path, "\0");
}

function dmd3d_model_base(string $type): string
{
    if ($type === 'printer') {
        return DMD3D_PRINTER_MODELS_DIR;
    }
    if ($type === 'plug') {
        return DMD3D_PLUG_MODELS_DIR;
    }
    throw new InvalidArgumentException('Type de modèle inconnu.');
}

function dmd3d_model_entry(string $directory, array $manifest = []): ?string
{
    $entry = trim((string)($manifest['entry'] ?? ''));
    if ($entry !== '' && dmd3d_safe_relative_path($entry) && is_file($directory . '/' . $entry)) {
        return str_replace('\\', '/', $entry);
    }

    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS)
    );
    $matches = [];
    foreach ($iterator as $file) {
        if ($file->isFile() && strtolower($file->getExtension()) === 'php') {
            $relative = substr($file->getPathname(), strlen($directory) + 1);
            $matches[] = str_replace('\\', '/', $relative);
        }
    }
    if ($matches === []) {
        return null;
    }

    sort($matches, SORT_NATURAL | SORT_FLAG_CASE);
    $folderName = strtolower(basename($directory));
    $preferredNames = ['driver.php', $folderName . '.php', 'index.php'];
    foreach ($preferredNames as $preferred) {
        foreach ($matches as $match) {
            if (strtolower(basename($match)) === $preferred) {
                return $match;
            }
        }
    }

    return $matches[0];
}

function dmd3d_count_model_files(string $directory): int
{
    if (!is_dir($directory)) {
        return 0;
    }
    $count = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $count++;
        }
    }
    return $count;
}

function dmd3d_scan_models(string $type): array
{
    $base = dmd3d_model_base($type);
    if (!is_dir($base)) {
        return [];
    }

    $models = [];
    foreach (scandir($base) ?: [] as $folder) {
        if ($folder === '.' || $folder === '..' || str_starts_with($folder, '.install-')) {
            continue;
        }
        $directory = $base . '/' . $folder;
        if (!is_dir($directory) || !preg_match('/^[A-Za-z0-9_-]+$/', $folder)) {
            continue;
        }

        $manifest = dmd3d_read_json($directory . '/manifest.json', []);
        $entry = dmd3d_model_entry($directory, $manifest);
        $models[] = [
            'id' => $folder,
            'name' => dmd3d_clean_text($manifest['name'] ?? str_replace(['-', '_'], ' ', $folder), 120),
            'version' => dmd3d_clean_text($manifest['version'] ?? '', 40),
            'entry' => $entry,
            'ready' => $entry !== null,
            'file_count' => dmd3d_count_model_files($directory),
            'capabilities' => is_array($manifest['capabilities'] ?? null) ? $manifest['capabilities'] : [],
            'fields' => is_array($manifest['fields'] ?? null) ? $manifest['fields'] : [],
        ];
    }

    usort($models, static function (array $a, array $b): int { return strnatcasecmp((string)$a['name'], (string)$b['name']); });
    return $models;
}

function dmd3d_model_exists(string $type, string $model): bool
{
    $model = preg_replace('/[^A-Za-z0-9_-]/', '', $model) ?: '';
    return $model !== '' && is_dir(dmd3d_model_base($type) . '/' . $model);
}


function dmd3d_find_model_image(string $type, string $model): ?array
{
    $model = preg_replace('/[^A-Za-z0-9_-]/', '', $model) ?: '';
    if ($model === '') {
        return null;
    }
    $directory = dmd3d_model_base($type) . '/' . $model;
    if (!is_dir($directory)) {
        return null;
    }

    $manifest = dmd3d_read_json($directory . '/manifest.json', []);
    $preferred = trim((string)($manifest['image'] ?? $manifest['icon'] ?? ''));
    $candidates = [];
    if ($preferred !== '' && dmd3d_safe_relative_path($preferred)) {
        $candidates[] = $directory . '/' . $preferred;
    }

    foreach (scandir($directory) ?: [] as $name) {
        if ($name === '.' || $name === '..') continue;
        $path = $directory . '/' . $name;
        if (is_file($path) && preg_match('/\.(jpe?g|png|webp)$/i', $name)) {
            $candidates[] = $path;
        }
    }

    foreach (array_unique($candidates) as $path) {
        if (!is_file($path)) continue;
        $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $mime = [
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
            'webp' => 'image/webp',
        ][$extension] ?? null;
        if ($mime === null) continue;
        return [
            'path' => $path,
            'mime' => $mime,
            'mtime' => (int)(filemtime($path) ?: 0),
            'size' => (int)(filesize($path) ?: 0),
        ];
    }
    return null;
}

function dmd3d_output_model_image(string $type, array $device): void
{
    $image = dmd3d_find_model_image($type, (string)($device['model'] ?? ''));
    if ($image === null) {
        http_response_code(404);
        exit;
    }
    header('Content-Type: ' . $image['mime']);
    header('Content-Length: ' . $image['size']);
    header('Cache-Control: private, max-age=3600');
    header('X-Content-Type-Options: nosniff');
    if ($image['mtime'] > 0) {
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $image['mtime']) . ' GMT');
    }
    readfile($image['path']);
    exit;
}

function dmd3d_load_printers(): array
{
    $data = dmd3d_read_json(DMD3D_PRINTERS_FILE, ['imprimantes' => []]);
    $items = is_array($data['imprimantes'] ?? null) ? array_values($data['imprimantes']) : [];
    return array_map('dmd3d_decode_device_secrets', $items);
}

function dmd3d_load_plugs(): array
{
    $data = dmd3d_read_json(DMD3D_PLUGS_FILE, ['prises' => []]);
    $items = is_array($data['prises'] ?? null) ? array_values($data['prises']) : [];
    return array_map('dmd3d_decode_device_secrets', $items);
}

function dmd3d_find_device(string $type, string $id): ?array
{
    $items = $type === 'printer' ? dmd3d_load_printers() : dmd3d_load_plugs();
    foreach ($items as $item) {
        if ((string)($item['id'] ?? '') === $id) {
            return $item;
        }
    }
    return null;
}

function dmd3d_public_device(array $device): array
{
    foreach (['password', 'api_key', 'token', 'secret'] as $field) {
        $encField = $field . '_enc';
        $hasValue = (array_key_exists($field, $device) && trim((string)$device[$field]) !== '')
            || (array_key_exists($encField, $device) && trim((string)$device[$encField]) !== '');
        $device['has_' . $field] = $hasValue;
        unset($device[$field], $device[$encField]);
    }
    return $device;
}

function dmd3d_parse_options($value): array
{
    if (is_array($value)) {
        return $value;
    }
    $value = trim((string)$value);
    if ($value === '') {
        return [];
    }
    $decoded = json_decode($value, true);
    if (!is_array($decoded)) {
        throw new InvalidArgumentException('Les paramètres supplémentaires doivent être un objet JSON valide.');
    }
    return $decoded;
}

function dmd3d_save_device(string $type, array $input): array
{
    $isPrinter = $type === 'printer';
    $file = $isPrinter ? DMD3D_PRINTERS_FILE : DMD3D_PLUGS_FILE;
    $rootKey = $isPrinter ? 'imprimantes' : 'prises';
    $stored = dmd3d_read_json($file, [$rootKey => []]);
    $items = is_array($stored[$rootKey] ?? null) ? array_values($stored[$rootKey]) : [];

    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', trim((string)($input['id'] ?? ''))) ?: bin2hex(random_bytes(8));
    $existing = null;
    foreach ($items as $item) {
        if (($item['id'] ?? '') === $id) {
            $existing = dmd3d_decode_device_secrets($item);
            break;
        }
    }

    $name = dmd3d_clean_text($input['name'] ?? '', 120);
    if ($name === '') {
        throw new InvalidArgumentException('Le nom de l’équipement est obligatoire.');
    }

    $model = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($input['model'] ?? '')) ?: '';
    if ($model !== '' && !dmd3d_model_exists($type, $model)) {
        throw new InvalidArgumentException('Le dossier de modèle sélectionné est absent.');
    }

    $protocol = dmd3d_clean_protocol($input['protocol'] ?? 'http');
    $defaultPort = $protocol === 'https' ? 443 : 80;

    $device = [
        'id' => $id,
        'name' => $name,
        'brand' => dmd3d_clean_text($input['brand'] ?? '', 100),
        'device_model' => dmd3d_clean_text($input['device_model'] ?? '', 120),
        'model' => $model,
        'host' => dmd3d_clean_host($input['host'] ?? ''),
        'protocol' => $protocol,
        'port' => dmd3d_clean_port($input['port'] ?? $defaultPort, $defaultPort),
        'username' => dmd3d_clean_text($input['username'] ?? '', 160),
        'enabled' => filter_var($input['enabled'] ?? false, FILTER_VALIDATE_BOOL),
        'options' => dmd3d_parse_options($input['options'] ?? []),
        'notes' => dmd3d_clean_text($input['notes'] ?? '', 2000),
        'updated_at' => date(DATE_ATOM),
    ];

    foreach (['password', 'api_key', 'token'] as $secretField) {
        $newValue = trim((string)($input[$secretField] ?? ''));
        $plain = $newValue;
        if ($plain === '' && is_array($existing)) {
            $plain = (string)($existing[$secretField] ?? '');
            if ($plain === '' && !empty($existing[$secretField . '_enc'])) {
                $plain = dmd3d_decrypt_secret((string)$existing[$secretField . '_enc']);
            }
        }
        $device[$secretField . '_enc'] = $plain !== '' ? dmd3d_encrypt_secret($plain) : '';
    }

    $device = dmd3d_seal_device_secrets($device);

    if ($isPrinter) {
        $plugId = preg_replace('/[^a-zA-Z0-9_-]/', '', trim((string)($input['plug_id'] ?? ''))) ?: '';
        if ($plugId !== '' && dmd3d_find_device('plug', $plugId) === null) {
            throw new InvalidArgumentException('La prise associée n’existe plus.');
        }
        $device['plug_id'] = $plugId;
        $device['camera_url'] = dmd3d_clean_text($input['camera_url'] ?? '', 1000);
    }

    $replaced = false;
    foreach ($items as $index => $item) {
        if (($item['id'] ?? '') === $id) {
            $device['created_at'] = (string)($item['created_at'] ?? date(DATE_ATOM));
            $items[$index] = $device;
            $replaced = true;
            break;
        }
    }
    if (!$replaced) {
        $device['created_at'] = date(DATE_ATOM);
        $items[] = $device;
    }

    dmd3d_write_json($file, [$rootKey => array_values($items)]);
    return dmd3d_public_device($device);
}

function dmd3d_delete_device(string $type, string $id): void
{
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', $id) ?: '';
    if ($id === '') {
        throw new InvalidArgumentException('Identifiant invalide.');
    }

    if ($type === 'plug') {
        foreach (dmd3d_load_printers() as $printer) {
            if (($printer['plug_id'] ?? '') === $id) {
                throw new RuntimeException('Cette prise est encore associée à l’imprimante « ' . ($printer['name'] ?? '') . ' ».');
            }
        }
    }

    $isPrinter = $type === 'printer';
    $file = $isPrinter ? DMD3D_PRINTERS_FILE : DMD3D_PLUGS_FILE;
    $rootKey = $isPrinter ? 'imprimantes' : 'prises';
    $items = $isPrinter ? dmd3d_load_printers() : dmd3d_load_plugs();
    $deletedDevice = null;
    foreach ($items as $item) {
        if (($item['id'] ?? '') === $id) {
            $deletedDevice = $item;
            break;
        }
    }
    $items = array_values(array_filter($items, static function (array $item) use ($id): bool { return ($item['id'] ?? '') !== $id; }));
    dmd3d_write_json($file, [$rootKey => $items]);
    if (is_array($deletedDevice)) {
        dmd3d_delete_resource_access($type, $deletedDevice);
    }
}

function dmd3d_driver_context(string $type, array $device): array
{
    $model = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($device['model'] ?? '')) ?: '';
    return [
        'module_root' => DMD3D_ROOT,
        'model_root' => dmd3d_model_base($type) . '/' . $model,
        'uploads_root' => DMD3D_UPLOADS_DIR,
        'type' => $type,
        'model' => $model,
        'base_url' => dmd3d_device_base_url($device),
        'http_request' => static function (
            string $url,
            string $method = 'GET',
            ?string $body = null,
            array $headers = [],
            float $timeout = 3.0
        ): array {
            return dmd3d_http_request($url, $method, $body, $headers, $timeout);
        },
    ];
}

function dmd3d_normalize_driver_result($result): array
{
    if (is_array($result)) {
        if (!array_key_exists('ok', $result)) {
            $result['ok'] = array_key_exists('success', $result) ? (bool)$result['success'] : true;
        }
        return $result;
    }
    if (is_bool($result)) {
        return ['ok' => $result];
    }
    if ($result === null) {
        return ['ok' => true];
    }
    return ['ok' => true, 'value' => $result];
}

function dmd3d_device_base_url(array $device, ?int $forcedPort = null): string
{
    $protocol = dmd3d_clean_protocol($device['protocol'] ?? 'http');
    $host = trim((string)($device['host'] ?? ''));
    if ($host === '') {
        throw new RuntimeException('Adresse de l’équipement absente.');
    }
    $port = $forcedPort ?? dmd3d_clean_port($device['port'] ?? ($protocol === 'https' ? 443 : 80), $protocol === 'https' ? 443 : 80);
    $defaultPort = ($protocol === 'https' && $port === 443) || ($protocol === 'http' && $port === 80);
    return $protocol . '://' . $host . ($defaultPort ? '' : ':' . $port);
}

function dmd3d_http_request(string $url, string $method = 'GET', ?string $body = null, array $headers = [], float $timeout = 3.0): array
{
    $method = strtoupper($method);
    if (function_exists('curl_init')) {
        $handle = curl_init($url);
        if ($handle === false) {
            throw new RuntimeException('Impossible d’initialiser la requête réseau.');
        }
        curl_setopt_array($handle, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT_MS => max(300, (int)round($timeout * 500)),
            CURLOPT_TIMEOUT_MS => max(500, (int)round($timeout * 1000)),
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HTTPHEADER => $headers,
        ]);
        if ($body !== null) {
            curl_setopt($handle, CURLOPT_POSTFIELDS, $body);
        }
        $responseBody = curl_exec($handle);
        $error = curl_error($handle);
        $status = (int)curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
        curl_close($handle);
        if ($responseBody === false) {
            throw new RuntimeException('Équipement inaccessible : ' . ($error !== '' ? $error : 'erreur réseau'));
        }
    } else {
        $headerText = implode("\r\n", $headers);
        $context = stream_context_create(['http' => [
            'method' => $method,
            'timeout' => $timeout,
            'ignore_errors' => true,
            'header' => $headerText,
            'content' => $body ?? '',
        ]]);
        $responseBody = @file_get_contents($url, false, $context);
        if ($responseBody === false) {
            throw new RuntimeException('Équipement inaccessible : aucune réponse réseau.');
        }
        $status = 0;
        foreach (($http_response_header ?? []) as $line) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $line, $match)) {
                $status = (int)$match[1];
                break;
            }
        }
    }

    $decoded = json_decode((string)$responseBody, true);
    return [
        'ok' => $status === 0 || ($status >= 200 && $status < 300),
        'status' => $status,
        'body' => (string)$responseBody,
        'json' => is_array($decoded) ? $decoded : null,
    ];
}

function dmd3d_normalize_file_list($files): array
{
    if (!is_array($files)) {
        return [];
    }
    $normalized = [];
    foreach ($files as $file) {
        if (!is_array($file)) {
            continue;
        }
        $path = trim((string)($file['path'] ?? $file['filename'] ?? $file['name'] ?? ''));
        if ($path === '') {
            continue;
        }
        $normalized[] = [
            'path' => $path,
            'name' => basename(str_replace('\\', '/', $path)),
            'size' => isset($file['size']) && is_numeric($file['size']) ? (int)$file['size'] : null,
            'modified' => isset($file['modified']) && is_numeric($file['modified']) ? (int)$file['modified'] : null,
        ];
    }
    usort($normalized, static function (array $a, array $b): int {
        return (int)($b['modified'] ?? 0) <=> (int)($a['modified'] ?? 0);
    });
    return $normalized;
}

function dmd3d_driver_is_handler_map(array $returned): bool
{
    foreach ($returned as $key => $value) {
        if (($key === 'handle' || is_string($key)) && is_callable($value)) {
            return true;
        }
    }
    return false;
}

function dmd3d_include_driver(string $driverFile, string $type, array $device, string $action, array $payload, array $context): array
{
    $loader = static function () use ($driverFile, $type, $device, $action, $payload, $context): array {
        $host = (string)($device['host'] ?? '');
        $protocol = (string)($device['protocol'] ?? 'http');
        $port = (int)($device['port'] ?? ($protocol === 'https' ? 443 : 80));
        $options = is_array($device['options'] ?? null) ? $device['options'] : [];
        $modelRoot = (string)$context['model_root'];
        $moduleRoot = (string)$context['module_root'];
        $uploadsRoot = (string)$context['uploads_root'];

        /* Compatibilité avec les anciens fichiers de modèles, sans logique constructeur dans le noyau. */
        if ($type === 'printer') {
            if (!defined('PRINTER_ID')) define('PRINTER_ID', (string)($device['id'] ?? ''));
            if (!defined('PRINTER_NAME')) define('PRINTER_NAME', (string)($device['name'] ?? 'Imprimante'));
            if (!defined('PRINTER_IP')) define('PRINTER_IP', $host);
        } else {
            if (!defined('PRISE_NAME')) define('PRISE_NAME', (string)($device['name'] ?? 'Prise'));
            if (!defined('PRISE_IP')) define('PRISE_IP', $host);
        }
        $ip_prise = $host;

        ob_start();
        try {
            $returned = include $driverFile;
            $variables = get_defined_vars();
        } finally {
            $output = (string)ob_get_clean();
        }

        $legacyKeys = [
            'online', 'is_online', 'connected', 'state', 'status', 'status_label', 'message',
            'file', 'filename', 'current_file', 'progress', 'percent',
            'elapsed', 'time_elapsed', 'print_duration', 'total', 'time_total', 'total_time',
            'remaining', 'time_remaining', 'remaining_time',
            'nozzle', 'temp_nozzle', 'bed', 'temp_bed', 'chamber', 'temp_chamber',
            'temperatures', 'fans', 'fan_data', 'light_on', 'light_value',
            'cfs', 'filaments', 'camera_url', 'camera_mode', 'camera_endpoint',
            'files', 'file_list', 'capabilities',
            'prise_on', 'power_state', 'voltage', 'volts', 'watts', 'power', 'power_w',
            'amps', 'current', 'energy', 'today', 'energy_today', 'consumption',
            'apparent_power', 'reactive_power', 'factor',
        ];
        $legacy = [];
        foreach ($legacyKeys as $key) {
            if (array_key_exists($key, $variables)) {
                $legacy[$key] = $variables[$key];
            }
        }

        return ['returned' => $returned, 'output' => $output, 'legacy' => $legacy];
    };

    return $loader();
}

function dmd3d_legacy_driver_status(array $legacy, string $output, string $type): ?array
{
    $trimmedOutput = trim($output);
    if ($trimmedOutput !== '') {
        $decoded = json_decode($trimmedOutput, true);
        if (is_array($decoded)) {
            return dmd3d_normalize_driver_result($decoded);
        }
    }

    if ($legacy === []) {
        return null;
    }

    $onlineValue = $legacy['online'] ?? $legacy['is_online'] ?? $legacy['connected'] ?? null;
    if (is_resource($onlineValue)) {
        @fclose($onlineValue);
        $onlineValue = true;
    }

    if ($type === 'plug') {
        $state = $legacy['state'] ?? $legacy['power_state'] ?? null;
        if ($state === null && array_key_exists('prise_on', $legacy)) {
            $state = $legacy['prise_on'] ? 'on' : 'off';
        }
        return [
            'ok' => true,
            'online' => $onlineValue === null ? true : (bool)$onlineValue,
            'state' => dmd3d_clean_text((string)($state ?? 'connected'), 120),
            'voltage' => $legacy['voltage'] ?? $legacy['volts'] ?? null,
            'power_w' => $legacy['power_w'] ?? $legacy['watts'] ?? $legacy['power'] ?? null,
            'current' => $legacy['current'] ?? $legacy['amps'] ?? null,
            'energy' => $legacy['energy'] ?? $legacy['consumption'] ?? $legacy['today'] ?? null,
            'energy_today' => $legacy['energy_today'] ?? $legacy['today'] ?? null,
            'apparent_power' => $legacy['apparent_power'] ?? null,
            'reactive_power' => $legacy['reactive_power'] ?? null,
            'factor' => $legacy['factor'] ?? null,
            'message' => dmd3d_clean_text((string)($legacy['message'] ?? ''), 500),
            'legacy' => true,
        ];
    }

    $status = [
        'ok' => true,
        'online' => $onlineValue === null ? true : (bool)$onlineValue,
        'state' => dmd3d_clean_text((string)($legacy['state'] ?? $legacy['status'] ?? $legacy['status_label'] ?? ''), 120),
        'file' => dmd3d_clean_text((string)($legacy['file'] ?? $legacy['filename'] ?? $legacy['current_file'] ?? ''), 255),
        'progress' => $legacy['progress'] ?? $legacy['percent'] ?? null,
        'elapsed' => $legacy['elapsed'] ?? $legacy['time_elapsed'] ?? $legacy['print_duration'] ?? null,
        'total' => $legacy['total'] ?? $legacy['time_total'] ?? $legacy['total_time'] ?? null,
        'remaining' => $legacy['remaining'] ?? $legacy['time_remaining'] ?? $legacy['remaining_time'] ?? null,
        'nozzle' => $legacy['nozzle'] ?? $legacy['temp_nozzle'] ?? null,
        'bed' => $legacy['bed'] ?? $legacy['temp_bed'] ?? null,
        'chamber' => $legacy['chamber'] ?? $legacy['temp_chamber'] ?? null,
        'temperatures' => is_array($legacy['temperatures'] ?? null) ? $legacy['temperatures'] : [],
        'fans' => is_array($legacy['fans'] ?? null) ? $legacy['fans'] : (is_array($legacy['fan_data'] ?? null) ? $legacy['fan_data'] : []),
        'light_on' => $legacy['light_on'] ?? null,
        'light_value' => $legacy['light_value'] ?? null,
        'cfs' => is_array($legacy['cfs'] ?? null) ? $legacy['cfs'] : null,
        'filaments' => is_array($legacy['filaments'] ?? null) ? $legacy['filaments'] : [],
        'camera_url' => dmd3d_clean_text((string)($legacy['camera_url'] ?? ''), 1000),
        'camera_mode' => dmd3d_clean_text((string)($legacy['camera_mode'] ?? ''), 80),
        'camera_endpoint' => dmd3d_clean_text((string)($legacy['camera_endpoint'] ?? ''), 1000),
        'files' => dmd3d_normalize_file_list($legacy['files'] ?? $legacy['file_list'] ?? []),
        'capabilities' => is_array($legacy['capabilities'] ?? null) ? $legacy['capabilities'] : [],
        'message' => dmd3d_clean_text((string)($legacy['message'] ?? ''), 500),
        'legacy' => true,
    ];

    return $status;
}

function dmd3d_call_driver(string $type, array $device, string $action, array $payload = []): array
{
    if (!in_array($type, ['printer', 'plug'], true)) {
        throw new InvalidArgumentException('Type de pilote invalide.');
    }

    $model = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($device['model'] ?? '')) ?: '';
    if ($model === '') {
        throw new RuntimeException('Aucun dossier de modèle n’est associé à cet équipement.');
    }

    $modelDir = dmd3d_model_base($type) . '/' . $model;
    if (!is_dir($modelDir)) {
        throw new RuntimeException('Le dossier du modèle « ' . $model . ' » est absent.');
    }

    $manifest = dmd3d_read_json($modelDir . '/manifest.json', []);
    $entry = dmd3d_model_entry($modelDir, $manifest);
    if ($entry === null) {
        throw new RuntimeException('Aucun fichier PHP de pilote n’a été détecté dans « ' . $model . ' ».');
    }

    $driverFile = $modelDir . '/' . $entry;
    $context = dmd3d_driver_context($type, $device);
    $loaded = dmd3d_include_driver($driverFile, $type, $device, $action, $payload, $context);
    $returned = $loaded['returned'];

    if (is_callable($returned)) {
        return dmd3d_normalize_driver_result($returned($action, $device, $payload, $context));
    }

    if (is_array($returned)) {
        if (isset($returned[$action]) && is_callable($returned[$action])) {
            return dmd3d_normalize_driver_result($returned[$action]($device, $payload, $context));
        }
        if (isset($returned['handle']) && is_callable($returned['handle'])) {
            return dmd3d_normalize_driver_result($returned['handle']($action, $device, $payload, $context));
        }
        if ($action === 'status' && !dmd3d_driver_is_handler_map($returned) && $returned !== []) {
            return dmd3d_normalize_driver_result($returned);
        }
    }

    if (is_object($returned)) {
        if (method_exists($returned, $action)) {
            return dmd3d_normalize_driver_result($returned->{$action}($device, $payload, $context));
        }
        if (method_exists($returned, 'handle')) {
            return dmd3d_normalize_driver_result($returned->handle($action, $device, $payload, $context));
        }
    }

    if ($action === 'status') {
        $legacyStatus = dmd3d_legacy_driver_status(
            is_array($loaded['legacy'] ?? null) ? $loaded['legacy'] : [],
            (string)($loaded['output'] ?? ''),
            $type
        );
        if ($legacyStatus !== null) {
            return $legacyStatus;
        }
    }

    throw new RuntimeException(
        'Le pilote « ' . $entry . ' » du dossier « ' . $model . ' » ne fournit pas l’action « ' . $action . ' ».'
    );
}

function dmd3d_rrmdir(string $directory): void
{
    if (!is_dir($directory)) {
        return;
    }
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );
    foreach ($iterator as $item) {
        if ($item->isDir()) {
            @rmdir($item->getPathname());
        } else {
            @unlink($item->getPathname());
        }
    }
    @rmdir($directory);
}

function dmd3d_upload_error_message(int $code): string
{
    $messages = [
        UPLOAD_ERR_INI_SIZE => 'Le fichier dépasse la limite upload_max_filesize configurée dans PHP.',
        UPLOAD_ERR_FORM_SIZE => 'Le fichier dépasse la limite autorisée par le formulaire.',
        UPLOAD_ERR_PARTIAL => 'Le fichier n’a été envoyé que partiellement.',
        UPLOAD_ERR_NO_FILE => 'Aucun fichier ZIP n’a été reçu.',
        UPLOAD_ERR_NO_TMP_DIR => 'Le dossier temporaire PHP est absent.',
        UPLOAD_ERR_CANT_WRITE => 'PHP ne peut pas écrire le fichier temporaire.',
        UPLOAD_ERR_EXTENSION => 'Une extension PHP a interrompu l’upload.',
    ];
    return $messages[$code] ?? ('Échec de l’upload du fichier ZIP (code ' . $code . ').');
}

function dmd3d_open_archive(string $path): array
{
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        $result = $zip->open($path);
        if ($result === true) {
            $entries = [];
            for ($index = 0; $index < $zip->numFiles; $index++) {
                $stat = $zip->statIndex($index);
                if (!is_array($stat)) {
                    continue;
                }
                $name = str_replace('\\', '/', (string)($stat['name'] ?? ''));
                $entries[] = [
                    'name' => $name,
                    'source' => $name,
                    'size' => (int)($stat['size'] ?? 0),
                    'directory' => str_ends_with($name, '/'),
                ];
            }
            return ['engine' => 'ziparchive', 'handle' => $zip, 'entries' => $entries, 'path' => $path];
        }
    }

    if (class_exists('PharData')) {
        $pharPath = $path;
        $cleanupPath = '';
        try {
            if (strtolower(pathinfo($pharPath, PATHINFO_EXTENSION)) !== 'zip') {
                $cleanupPath = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
                    . DIRECTORY_SEPARATOR . 'dmd3d-' . bin2hex(random_bytes(8)) . '.zip';
                if (!copy($path, $cleanupPath)) {
                    throw new RuntimeException('Impossible de préparer le ZIP temporaire pour PharData.');
                }
                $pharPath = $cleanupPath;
            }

            $phar = new PharData($pharPath);
            $entries = [];
            $iterator = new RecursiveIteratorIterator($phar, RecursiveIteratorIterator::SELF_FIRST);
            foreach ($iterator as $file) {
                $name = str_replace('\\', '/', $iterator->getSubPathName());
                if ($name === '') {
                    continue;
                }
                $entries[] = [
                    'name' => $name,
                    'source' => $name,
                    'size' => $file->isDir() ? 0 : (int)$file->getSize(),
                    'directory' => $file->isDir(),
                ];
            }
            if ($entries !== []) {
                return [
                    'engine' => 'phardata',
                    'handle' => $phar,
                    'entries' => $entries,
                    'path' => $pharPath,
                    'cleanup_path' => $cleanupPath,
                ];
            }
        } catch (Throwable $error) {
            if ($cleanupPath !== '' && is_file($cleanupPath)) {
                @unlink($cleanupPath);
            }
        }
    }

    throw new RuntimeException('Le ZIP est illisible. Active ZipArchive ou PharData dans PHP et vérifie que le fichier est une vraie archive ZIP.');
}

function dmd3d_close_archive(array $archive): void
{
    if (($archive['engine'] ?? '') === 'ziparchive' && isset($archive['handle']) && $archive['handle'] instanceof ZipArchive) {
        $archive['handle']->close();
    }
    $cleanupPath = (string)($archive['cleanup_path'] ?? '');
    if ($cleanupPath !== '' && is_file($cleanupPath)) {
        @unlink($cleanupPath);
    }
}

function dmd3d_archive_stream(array $archive, string $source)
{
    if (($archive['engine'] ?? '') === 'ziparchive') {
        return $archive['handle']->getStream($source);
    }
    if (($archive['engine'] ?? '') === 'phardata') {
        return @fopen('phar://' . $archive['path'] . '/' . ltrim($source, '/'), 'rb');
    }
    return false;
}

function dmd3d_common_archive_root(array $entries): string
{
    $root = null;
    foreach ($entries as $entry) {
        $name = trim(str_replace('\\', '/', (string)($entry['name'] ?? '')), '/');
        if ($name === '') {
            continue;
        }
        $first = explode('/', $name, 2)[0];
        if ($root === null) {
            $root = $first;
        } elseif ($root !== $first) {
            return '';
        }
    }
    return $root === null ? '' : $root . '/';
}

function dmd3d_install_model(string $type, string $name, bool $replace): array
{
    if (!isset($_FILES['model_zip']) || !is_array($_FILES['model_zip'])) {
        throw new InvalidArgumentException('Sélectionne un fichier ZIP.');
    }

    $upload = $_FILES['model_zip'];
    $errorCode = (int)($upload['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($errorCode !== UPLOAD_ERR_OK) {
        throw new RuntimeException(dmd3d_upload_error_message($errorCode));
    }
    if (!is_uploaded_file((string)($upload['tmp_name'] ?? '')) && PHP_SAPI !== 'cli') {
        throw new RuntimeException('Le fichier temporaire reçu n’est pas un upload PHP valide.');
    }
    if ((int)($upload['size'] ?? 0) <= 0) {
        throw new InvalidArgumentException('Le fichier ZIP est vide.');
    }
    if ((int)($upload['size'] ?? 0) > 100 * 1024 * 1024) {
        throw new InvalidArgumentException('Le ZIP dépasse 100 Mo.');
    }

    $slug = dmd3d_slug($name);
    $base = dmd3d_model_base($type);
    $target = $base . '/' . $slug;
    if (is_dir($target) && !$replace) {
        throw new RuntimeException('Ce dossier de modèle existe déjà. Coche « remplacer » pour l’écraser.');
    }

    $archive = dmd3d_open_archive((string)$upload['tmp_name']);
    $entries = is_array($archive['entries'] ?? null) ? $archive['entries'] : [];
    if ($entries === [] || count($entries) > 2000) {
        dmd3d_close_archive($archive);
        throw new InvalidArgumentException('Le ZIP est vide ou contient trop de fichiers.');
    }

    $expandedSize = 0;
    $realFiles = 0;
    foreach ($entries as $entry) {
        $entryName = str_replace('\\', '/', (string)($entry['name'] ?? ''));
        if (!dmd3d_safe_relative_path($entryName)) {
            dmd3d_close_archive($archive);
            throw new InvalidArgumentException('Chemin interdit détecté dans le ZIP : ' . $entryName);
        }
        $expandedSize += (int)($entry['size'] ?? 0);
        if ($expandedSize > 300 * 1024 * 1024) {
            dmd3d_close_archive($archive);
            throw new InvalidArgumentException('Le contenu décompressé dépasse 300 Mo.');
        }
        if (empty($entry['directory'])) {
            $realFiles++;
            $baseName = strtolower(basename($entryName));
            if (in_array($baseName, ['.htaccess', '.user.ini'], true)) {
                dmd3d_close_archive($archive);
                throw new InvalidArgumentException('Le fichier ' . $baseName . ' est interdit dans un modèle.');
            }
        }
    }
    if ($realFiles === 0) {
        dmd3d_close_archive($archive);
        throw new InvalidArgumentException('Le ZIP ne contient aucun fichier.');
    }

    $temporary = $base . '/.install-' . bin2hex(random_bytes(6));
    if (!mkdir($temporary, 0750, true) && !is_dir($temporary)) {
        dmd3d_close_archive($archive);
        throw new RuntimeException('Impossible de préparer le dossier temporaire du modèle.');
    }

    $commonRoot = dmd3d_common_archive_root($entries);
    try {
        foreach ($entries as $entry) {
            $sourceName = str_replace('\\', '/', (string)($entry['source'] ?? $entry['name'] ?? ''));
            $entryName = str_replace('\\', '/', (string)($entry['name'] ?? ''));
            $relative = $commonRoot !== '' && str_starts_with($entryName, $commonRoot)
                ? substr($entryName, strlen($commonRoot))
                : $entryName;
            $relative = ltrim($relative, '/');
            if ($relative === '') {
                continue;
            }

            $destination = $temporary . '/' . $relative;
            if (!empty($entry['directory'])) {
                if (!is_dir($destination) && !mkdir($destination, 0750, true) && !is_dir($destination)) {
                    throw new RuntimeException('Impossible de créer un sous-dossier du modèle.');
                }
                continue;
            }

            $parent = dirname($destination);
            if (!is_dir($parent) && !mkdir($parent, 0750, true) && !is_dir($parent)) {
                throw new RuntimeException('Impossible de créer un sous-dossier du modèle.');
            }

            $source = dmd3d_archive_stream($archive, $sourceName);
            if ($source === false) {
                throw new RuntimeException('Impossible de lire « ' . $entryName . ' » dans le ZIP.');
            }
            $output = fopen($destination, 'wb');
            if ($output === false) {
                fclose($source);
                throw new RuntimeException('Impossible d’écrire « ' . $relative . ' » dans le dossier du modèle.');
            }
            stream_copy_to_stream($source, $output);
            fclose($source);
            fclose($output);
            @chmod($destination, 0640);
        }
    } catch (Throwable $error) {
        dmd3d_close_archive($archive);
        dmd3d_rrmdir($temporary);
        throw $error;
    }
    dmd3d_close_archive($archive);

    if (is_dir($target)) {
        dmd3d_rrmdir($target);
    }
    if (!rename($temporary, $target)) {
        dmd3d_rrmdir($temporary);
        throw new RuntimeException('Le ZIP a été lu, mais le dossier final n’a pas pu être créé. Vérifie les droits de ' . basename($base) . '/.');
    }

    foreach (dmd3d_scan_models($type) as $model) {
        if (($model['id'] ?? '') === $slug) {
            return $model;
        }
    }
    throw new RuntimeException('Les fichiers ont été copiés, mais le dossier n’apparaît pas dans la liste.');
}

function dmd3d_delete_model(string $type, string $model): void
{
    $model = preg_replace('/[^A-Za-z0-9_-]/', '', $model) ?: '';
    if ($model === '') {
        throw new InvalidArgumentException('Modèle invalide.');
    }

    $devices = $type === 'printer' ? dmd3d_load_printers() : dmd3d_load_plugs();
    foreach ($devices as $device) {
        if (($device['model'] ?? '') === $model) {
            throw new RuntimeException('Le modèle est encore utilisé par « ' . ($device['name'] ?? '') . ' ».');
        }
    }

    $directory = dmd3d_model_base($type) . '/' . $model;
    if (is_dir($directory)) {
        dmd3d_rrmdir($directory);
    }
}

function dmd3d_store_print_file(array $upload, array $printer): array
{
    if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Échec de l’envoi du fichier d’impression.');
    }
    if ((int)($upload['size'] ?? 0) > 600 * 1024 * 1024) {
        throw new InvalidArgumentException('Le fichier dépasse 600 Mo.');
    }

    $original = basename((string)($upload['name'] ?? 'fichier'));
    $extension = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    if (!in_array($extension, ['stl', '3mf', 'gcode', 'gco', 'gc'], true)) {
        throw new InvalidArgumentException('Formats autorisés : STL, 3MF et G-code.');
    }

    $safeBase = preg_replace('/[^A-Za-z0-9._-]/', '_', pathinfo($original, PATHINFO_FILENAME)) ?: 'fichier';
    $storedName = date('Ymd-His') . '_' . substr((string)$printer['id'], 0, 12) . '_' . $safeBase . '.' . $extension;
    $destination = DMD3D_UPLOADS_DIR . '/' . $storedName;
    if (!move_uploaded_file((string)$upload['tmp_name'], $destination)) {
        throw new RuntimeException('Impossible de déplacer le fichier dans le stockage persistant DMD-3DPRINT.');
    }
    @chmod($destination, 0640);

    return [
        'name' => $original,
        'stored_name' => $storedName,
        'path' => $destination,
        'extension' => $extension,
        'size' => (int)($upload['size'] ?? 0),
    ];
}

dmd3d_bootstrap_storage();
