<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/dmd-3dprint_lib.php';

const DMD3D_PRINTER_CATALOG_URL = 'https://raw.githubusercontent.com/synohomes/3dprints/refs/heads/main/imprimantes.json';
const DMD3D_PLUG_CATALOG_URL = 'https://raw.githubusercontent.com/synohomes/3dprints/refs/heads/main/prises.json';

function dmd3d_catalog_is_admin(): bool
{
    return dmd3d_has_permission('model.install');
}

function dmd3d_catalog_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function dmd3d_catalog_remote_host_allowed(string $url): bool
{
    $parts = parse_url($url);
    if (!is_array($parts) || !in_array(strtolower((string)($parts['scheme'] ?? '')), ['https'], true)) {
        return false;
    }

    $host = strtolower((string)($parts['host'] ?? ''));
    $allowed = [
        'raw.githubusercontent.com',
        'github.com',
        'www.github.com',
        'objects.githubusercontent.com',
        'release-assets.githubusercontent.com',
    ];

    return in_array($host, $allowed, true) || str_ends_with($host, '.githubusercontent.com');
}

function dmd3d_catalog_fetch(string $url, int $maxBytes = 20971520): string
{
    if (!dmd3d_catalog_remote_host_allowed($url)) {
        throw new RuntimeException('Adresse distante refusée. Seuls les liens HTTPS GitHub sont autorisés.');
    }

    $data = false;

    if (function_exists('curl_init')) {
        $curl = curl_init($url);
        if ($curl === false) {
            throw new RuntimeException('Impossible d’initialiser le téléchargement.');
        }

        curl_setopt_array($curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 35,
            CURLOPT_USERAGENT => 'DoMyDesk-DMD-3DPRINT/1.0',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FAILONERROR => false,
        ]);

        $data = curl_exec($curl);
        $status = (int)curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        $error = curl_error($curl);
        curl_close($curl);

        if (!is_string($data) || $status < 200 || $status >= 300) {
            throw new RuntimeException('Téléchargement GitHub impossible' . ($status ? ' (HTTP ' . $status . ')' : '') . ($error !== '' ? ' : ' . $error : '.'));
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 35,
                'follow_location' => 1,
                'max_redirects' => 5,
                'header' => "User-Agent: DoMyDesk-DMD-3DPRINT/1.0\r\nAccept: application/json, application/zip, */*\r\n",
            ],
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);
        $data = @file_get_contents($url, false, $context);
        if (!is_string($data)) {
            throw new RuntimeException('Téléchargement GitHub impossible. Vérifie allow_url_fopen ou active cURL dans PHP.');
        }
    }

    if ($data === '') {
        throw new RuntimeException('GitHub a renvoyé un fichier vide.');
    }
    if (strlen($data) > $maxBytes) {
        throw new RuntimeException('Le fichier distant dépasse la taille maximale autorisée.');
    }

    return $data;
}

function dmd3d_catalog_array_is_list(array $items): bool
{
    $expected = 0;
    foreach ($items as $key => $_value) {
        if ($key !== $expected) {
            return false;
        }
        $expected++;
    }
    return true;
}

function dmd3d_catalog_first(array $item, array $keys, string $default = ''): string
{
    foreach ($keys as $key) {
        if (array_key_exists($key, $item) && is_scalar($item[$key])) {
            $value = trim((string)$item[$key]);
            if ($value !== '') {
                return $value;
            }
        }
    }
    return $default;
}

function dmd3d_catalog_folder(string $value): string
{
    $value = trim($value);
    $value = preg_replace('/[^A-Za-z0-9_-]+/', '_', $value) ?? '';
    $value = trim($value, '_-');
    if ($value === '') {
        throw new RuntimeException('Le profil GitHub ne contient pas de nom de dossier valide.');
    }
    return substr($value, 0, 100);
}

function dmd3d_catalog_prepare_json(string $raw): string
{
    /*
     * Nettoie uniquement l'enveloppe du fichier.
     * Les URLs https:// présentes dans les valeurs ne sont jamais modifiées.
     */
    $raw = str_replace(
        ["\xEF\xBB\xBF", "\xE2\x80\x8B", "\xE2\x80\x8C", "\xE2\x80\x8D", "\xC2\xA0"],
        ['', '', '', '', ' '],
        $raw
    );
    $raw = trim($raw);

    if (preg_match('/^```(?:json)?\s*(.*?)\s*```$/is', $raw, $match) === 1) {
        $raw = trim((string)$match[1]);
    }

    if (str_starts_with(ltrim($raw), '<')) {
        if (preg_match('/<pre[^>]*>(.*?)<\/pre>/is', $raw, $match) === 1) {
            $raw = html_entity_decode(strip_tags((string)$match[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        } else {
            throw new RuntimeException(
                'GitHub n’a pas renvoyé le JSON brut. Vérifie le lien raw.githubusercontent.com.'
            );
        }
    }

    return trim($raw);
}

function dmd3d_catalog_json_flags(): int
{
    return defined('JSON_INVALID_UTF8_SUBSTITUTE')
        ? JSON_INVALID_UTF8_SUBSTITUTE
        : 0;
}

function dmd3d_catalog_sanitize_json_text(string $json): string
{
    $json = str_replace(
        ["\xEF\xBB\xBF", "\xE2\x80\x8B", "\xE2\x80\x8C", "\xE2\x80\x8D", "\xC2\xA0"],
        ['', '', '', '', ' '],
        $json
    );

    $output = '';
    $inString = false;
    $escaped = false;
    $length = strlen($json);

    for ($i = 0; $i < $length; $i++) {
        $char = $json[$i];
        $ord = ord($char);

        if ($inString) {
            if ($escaped) {
                $output .= $char;
                $escaped = false;
                continue;
            }

            if ($char === '\\') {
                $output .= $char;
                $escaped = true;
                continue;
            }

            if ($char === '"') {
                $output .= $char;
                $inString = false;
                continue;
            }

            /*
             * Un caractère de contrôle brut est interdit dans une chaîne JSON.
             * On le transforme au lieu de rejeter tout le catalogue.
             */
            if ($ord < 32) {
                if ($char === "\n") {
                    $output .= '\\n';
                } elseif ($char === "\r") {
                    $output .= '\\r';
                } elseif ($char === "\t") {
                    $output .= '\\t';
                } else {
                    $output .= sprintf('\\u%04x', $ord);
                }
                continue;
            }

            $output .= $char;
            continue;
        }

        if ($char === '"') {
            $output .= $char;
            $inString = true;
            continue;
        }

        if ($ord < 32) {
            $output .= ' ';
            continue;
        }

        $output .= $char;
    }

    return trim($output);
}

function dmd3d_catalog_remove_json_comments(string $json): string
{
    $output = '';
    $inString = false;
    $escaped = false;
    $length = strlen($json);

    for ($i = 0; $i < $length; $i++) {
        $char = $json[$i];
        $next = $i + 1 < $length ? $json[$i + 1] : '';

        if ($inString) {
            $output .= $char;

            if ($escaped) {
                $escaped = false;
            } elseif ($char === '\\') {
                $escaped = true;
            } elseif ($char === '"') {
                $inString = false;
            }
            continue;
        }

        if ($char === '"') {
            $output .= $char;
            $inString = true;
            continue;
        }

        if ($char === '/' && $next === '/') {
            $i += 2;
            while ($i < $length && $json[$i] !== "\n" && $json[$i] !== "\r") {
                $i++;
            }
            $output .= ' ';
            continue;
        }

        if ($char === '/' && $next === '*') {
            $i += 2;
            while ($i + 1 < $length && !($json[$i] === '*' && $json[$i + 1] === '/')) {
                $i++;
            }
            $i++;
            $output .= ' ';
            continue;
        }

        $output .= $char;
    }

    return $output;
}

function dmd3d_catalog_remove_trailing_commas(string $json): string
{
    $output = '';
    $inString = false;
    $escaped = false;
    $length = strlen($json);

    for ($i = 0; $i < $length; $i++) {
        $char = $json[$i];

        if ($inString) {
            $output .= $char;

            if ($escaped) {
                $escaped = false;
            } elseif ($char === '\\') {
                $escaped = true;
            } elseif ($char === '"') {
                $inString = false;
            }
            continue;
        }

        if ($char === '"') {
            $output .= $char;
            $inString = true;
            continue;
        }

        if ($char === ',') {
            $nextIndex = $i + 1;
            while ($nextIndex < $length && ord($json[$nextIndex]) <= 32) {
                $nextIndex++;
            }

            if (
                $nextIndex < $length
                && ($json[$nextIndex] === '}' || $json[$nextIndex] === ']')
            ) {
                continue;
            }
        }

        $output .= $char;
    }

    return $output;
}

function dmd3d_catalog_extract_objects(string $json): array
{
    /*
     * Dernier recours : récupère les objets {...} équilibrés de la liste.
     * Cela permet de supporter un caractère parasite placé entre deux profils.
     */
    $objects = [];
    $buffer = '';
    $depth = 0;
    $inString = false;
    $escaped = false;
    $collecting = false;
    $length = strlen($json);

    for ($i = 0; $i < $length; $i++) {
        $char = $json[$i];

        if (!$collecting) {
            if ($char !== '{') {
                continue;
            }

            $collecting = true;
            $depth = 1;
            $buffer = '{';
            $inString = false;
            $escaped = false;
            continue;
        }

        $buffer .= $char;

        if ($inString) {
            if ($escaped) {
                $escaped = false;
            } elseif ($char === '\\') {
                $escaped = true;
            } elseif ($char === '"') {
                $inString = false;
            }
            continue;
        }

        if ($char === '"') {
            $inString = true;
            continue;
        }

        if ($char === '{') {
            $depth++;
        } elseif ($char === '}') {
            $depth--;

            if ($depth === 0) {
                $objects[] = $buffer;
                $buffer = '';
                $collecting = false;
            }
        }
    }

    return $objects;
}

function dmd3d_catalog_try_decode(string $json): ?array
{
    $decoded = json_decode($json, true, 512, dmd3d_catalog_json_flags());
    return is_array($decoded) ? $decoded : null;
}

function dmd3d_catalog_decode_json(string $raw): array
{
    $json = dmd3d_catalog_prepare_json($raw);

    $decoded = dmd3d_catalog_try_decode($json);
    if (is_array($decoded)) {
        return $decoded;
    }

    $relaxed = dmd3d_catalog_sanitize_json_text($json);
    $relaxed = dmd3d_catalog_remove_json_comments($relaxed);
    $relaxed = dmd3d_catalog_remove_trailing_commas($relaxed);

    /*
     * Ignore un éventuel caractère parasite avant/après le tableau JSON.
     */
    $firstArray = strpos($relaxed, '[');
    $lastArray = strrpos($relaxed, ']');
    if ($firstArray !== false && $lastArray !== false && $lastArray > $firstArray) {
        $arrayOnly = substr($relaxed, $firstArray, $lastArray - $firstArray + 1);
        $decoded = dmd3d_catalog_try_decode($arrayOnly);

        if (is_array($decoded)) {
            return $decoded;
        }
    }

    $decoded = dmd3d_catalog_try_decode($relaxed);
    if (is_array($decoded)) {
        return $decoded;
    }

    /*
     * Supporte la liste directe utilisée comme marketmodules, même si un
     * caractère invisible ou parasite se trouve entre deux objets.
     */
    $profiles = [];
    foreach (dmd3d_catalog_extract_objects($relaxed) as $objectJson) {
        $profile = dmd3d_catalog_try_decode(
            dmd3d_catalog_remove_trailing_commas(
                dmd3d_catalog_sanitize_json_text($objectJson)
            )
        );

        if (is_array($profile)) {
            $profiles[] = $profile;
        }
    }

    if ($profiles !== []) {
        return $profiles;
    }

    $snippet = preg_replace('/\s+/', ' ', substr($json, 0, 260)) ?? '';
    throw new RuntimeException(
        'JSON GitHub illisible : ' . json_last_error_msg()
        . ($snippet !== '' ? ' — début reçu : ' . $snippet : '')
    );
}

function dmd3d_catalog_normalize(string $json, string $type): array
{
    $decoded = dmd3d_catalog_decode_json($json);

    $items = $decoded;
    foreach (['profiles', 'profils', 'items', $type === 'printer' ? 'imprimantes' : 'prises'] as $key) {
        if (isset($decoded[$key]) && is_array($decoded[$key])) {
            $items = $decoded[$key];
            break;
        }
    }

    // Accepte également {"catalogue":{"profiles":[...]}}.
    if (isset($decoded['catalogue']) && is_array($decoded['catalogue'])) {
        $catalogue = $decoded['catalogue'];
        foreach (['profiles', 'profils', 'items', $type === 'printer' ? 'imprimantes' : 'prises'] as $key) {
            if (isset($catalogue[$key]) && is_array($catalogue[$key])) {
                $items = $catalogue[$key];
                break;
            }
        }
    }

    // Accepte un profil unique directement à la racine.
    $profileKeys = ['constructeur', 'fabricant', 'marque', 'brand', 'vendor', 'modele', 'modèle', 'model', 'nom', 'name'];
    if (!dmd3d_catalog_array_is_list($items) && count(array_intersect($profileKeys, array_keys($items))) > 0) {
        $items = [$items];
    } elseif (!dmd3d_catalog_array_is_list($items)) {
        $items = array_values(array_filter($items, 'is_array'));
    }

    $result = [];
    foreach ($items as $index => $item) {
        if (!is_array($item)) {
            continue;
        }

        $constructeur = dmd3d_catalog_first($item, ['constructeur', 'fabricant', 'marque', 'brand', 'vendor'], 'Inconnu');
        $modele = dmd3d_catalog_first($item, ['modele', 'modèle', 'model', 'nom', 'name'], 'Profil sans nom');
        $description = dmd3d_catalog_first($item, ['description', 'resume', 'résumé', 'summary']);
        $software = dmd3d_catalog_first($item, ['software', 'firmware', 'logiciel', 'version_software', 'systeme'], 'Non précisé');
        $image = dmd3d_catalog_first($item, ['image', 'image_url', 'illustration', 'preview']);
        $link = dmd3d_catalog_first($item, ['lien', 'url', 'download', 'download_url', 'zip']);
        $version = dmd3d_catalog_first($item, ['version_profil', 'profile_version', 'version'], '1.0.0');
        $rawId = dmd3d_catalog_first($item, ['id', 'slug'], strtolower($constructeur . '-' . $modele));
        $folderRaw = dmd3d_catalog_first($item, ['dossier', 'folder', 'repertoire'], $modele);

        if ($link === '') {
            continue;
        }

        try {
            $folder = dmd3d_catalog_folder($folderRaw);
        } catch (Throwable) {
            continue;
        }

        $id = preg_replace('/[^a-z0-9_-]+/i', '-', $rawId) ?? '';
        $id = trim(strtolower($id), '-_');
        if ($id === '') {
            $id = substr(hash('sha256', $constructeur . '|' . $modele . '|' . $link . '|' . $index), 0, 20);
        }

        $result[] = [
            'id' => $id,
            'constructeur' => $constructeur,
            'modele' => $modele,
            'description' => $description,
            'image' => $image,
            'software' => $software,
            'version_profil' => $version,
            'dossier' => $folder,
            'lien' => $link,
            'sha256' => dmd3d_catalog_first($item, ['sha256', 'hash']),
        ];
    }

    return $result;
}

function dmd3d_catalog_profiles(string $type): array
{
    $url = $type === 'printer' ? DMD3D_PRINTER_CATALOG_URL : DMD3D_PLUG_CATALOG_URL;
    return dmd3d_catalog_normalize(dmd3d_catalog_fetch($url, 1048576), $type);
}

function dmd3d_catalog_remove_tree(string $path): void
{
    if (!file_exists($path)) {
        return;
    }
    if (is_link($path) || is_file($path)) {
        @unlink($path);
        return;
    }

    $items = scandir($path);
    if (is_array($items)) {
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') {
                continue;
            }
            dmd3d_catalog_remove_tree($path . DIRECTORY_SEPARATOR . $item);
        }
    }
    @rmdir($path);
}

function dmd3d_catalog_install_zip(array $profile, string $type): array
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('L’extension PHP ZipArchive est nécessaire pour installer un profil.');
    }

    $link = (string)($profile['lien'] ?? '');
    if (!dmd3d_catalog_remote_host_allowed($link)) {
        throw new RuntimeException('Le lien ZIP du profil n’est pas un lien GitHub HTTPS autorisé.');
    }

    $zipData = dmd3d_catalog_fetch($link, 26214400);
    if (!str_starts_with($zipData, "PK")) {
        throw new RuntimeException('Le lien du profil ne renvoie pas une archive ZIP valide.');
    }

    $folder = dmd3d_catalog_folder((string)($profile['dossier'] ?? ''));
    $base = dmd3d_model_base($type);
    if (!is_dir($base) && !mkdir($base, 0775, true) && !is_dir($base)) {
        throw new RuntimeException('Impossible de créer le dossier des profils.');
    }

    $token = bin2hex(random_bytes(6));
    $zipPath = $base . DIRECTORY_SEPARATOR . '.dmd3d-' . $token . '.zip';
    $stage = $base . DIRECTORY_SEPARATOR . '.dmd3d-stage-' . $token;
    $destination = $base . DIRECTORY_SEPARATOR . $folder;
    $backup = $base . DIRECTORY_SEPARATOR . '.dmd3d-backup-' . $folder . '-' . $token;

    if (file_put_contents($zipPath, $zipData, LOCK_EX) === false) {
        throw new RuntimeException('Impossible d’enregistrer temporairement le ZIP.');
    }

    $zip = new ZipArchive();
    $opened = $zip->open($zipPath);
    if ($opened !== true) {
        @unlink($zipPath);
        throw new RuntimeException('Impossible d’ouvrir le ZIP du profil.');
    }

    $entries = [];
    $totalSize = 0;
    $allowedExtensions = ['php', 'json', 'png', 'jpg', 'jpeg', 'webp', 'svg', 'css', 'js', 'txt', 'md', 'cfg', 'conf', 'ini', 'yaml', 'yml'];

    try {
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            $name = str_replace('\\', '/', (string)($stat['name'] ?? ''));
            if ($name === '' || str_ends_with($name, '/')) {
                continue;
            }
            if (str_contains($name, "\0") || str_starts_with($name, '/') || preg_match('~^[A-Za-z]:/~', $name)) {
                throw new RuntimeException('Le ZIP contient un chemin interdit.');
            }

            $parts = array_values(array_filter(explode('/', $name), static function (string $part): bool { return $part !== '' && $part !== '.'; }));
            if ($parts === [] || in_array('..', $parts, true)) {
                throw new RuntimeException('Le ZIP contient une tentative de sortie de dossier.');
            }

            $basename = end($parts);
            if ($basename === false || str_starts_with($basename, '.')) {
                throw new RuntimeException('Le ZIP contient un fichier caché interdit.');
            }

            $extension = strtolower(pathinfo($basename, PATHINFO_EXTENSION));
            if (!in_array($extension, $allowedExtensions, true)) {
                throw new RuntimeException('Extension refusée dans le profil : .' . ($extension !== '' ? $extension : '(aucune)'));
            }

            $size = (int)($stat['size'] ?? 0);
            $totalSize += max(0, $size);
            if ($totalSize > 52428800) {
                throw new RuntimeException('Le contenu décompressé dépasse 50 Mo.');
            }

            $entries[] = ['index' => $i, 'parts' => $parts, 'size' => $size];
        }

        if ($entries === []) {
            throw new RuntimeException('Le ZIP ne contient aucun fichier exploitable.');
        }

        $firstRoot = $entries[0]['parts'][0] ?? '';
        $stripRoot = $firstRoot !== '';
        foreach ($entries as $entry) {
            if (count($entry['parts']) < 2 || ($entry['parts'][0] ?? '') !== $firstRoot) {
                $stripRoot = false;
                break;
            }
        }

        if (!mkdir($stage, 0775, true) && !is_dir($stage)) {
            throw new RuntimeException('Impossible de préparer le dossier temporaire.');
        }

        $phpFound = false;
        $fileCount = 0;
        $entryFile = '';

        foreach ($entries as $entry) {
            $parts = $entry['parts'];
            if ($stripRoot) {
                array_shift($parts);
            }
            if ($parts === []) {
                continue;
            }

            $relative = implode(DIRECTORY_SEPARATOR, $parts);
            $target = $stage . DIRECTORY_SEPARATOR . $relative;
            $parent = dirname($target);
            if (!is_dir($parent) && !mkdir($parent, 0775, true) && !is_dir($parent)) {
                throw new RuntimeException('Impossible de créer un sous-dossier du profil.');
            }

            $stream = $zip->getStream((string)$zip->getNameIndex((int)$entry['index']));
            if (!is_resource($stream)) {
                throw new RuntimeException('Impossible de lire un fichier du ZIP.');
            }
            $out = fopen($target, 'wb');
            if (!is_resource($out)) {
                fclose($stream);
                throw new RuntimeException('Impossible d’écrire un fichier du profil.');
            }
            stream_copy_to_stream($stream, $out);
            fclose($stream);
            fclose($out);
            @chmod($target, 0644);
            $fileCount++;

            if (strtolower(pathinfo($target, PATHINFO_EXTENSION)) === 'php') {
                $phpFound = true;
                if ($entryFile === '') {
                    $entryFile = basename($target);
                }
            }
        }

        if (!$phpFound) {
            throw new RuntimeException('Aucun pilote PHP n’a été trouvé dans le ZIP.');
        }

        if (file_exists($destination)) {
            if (!rename($destination, $backup)) {
                throw new RuntimeException('Impossible de sauvegarder temporairement l’ancien profil.');
            }
        }

        if (!rename($stage, $destination)) {
            if (is_dir($backup)) {
                @rename($backup, $destination);
            }
            throw new RuntimeException('Impossible d’installer le nouveau profil.');
        }

        if (is_dir($backup)) {
            dmd3d_catalog_remove_tree($backup);
        }

        return [
            'id' => $folder,
            'name' => (string)($profile['constructeur'] ?? '') . ' ' . (string)($profile['modele'] ?? ''),
            'file_count' => $fileCount,
            'entry' => $entryFile,
            'version_profil' => (string)($profile['version_profil'] ?? ''),
        ];
    } finally {
        $zip->close();
        @unlink($zipPath);
        if (is_dir($stage)) {
            dmd3d_catalog_remove_tree($stage);
        }
    }
}

if (isset($_GET['dmd3d_catalog_action'])) {
    if (!dmd3d_has_permission('config.view')) {
        dmd3d_catalog_json(['ok' => false, 'message' => 'Permission DoMyDesk refusée : config.view.'], 403);
    }

    $action = (string)$_GET['dmd3d_catalog_action'];
    try {
        if ($action === 'list') {
            $printers = [];
            $plugs = [];
            $errors = ['printer' => '', 'plug' => ''];

            try {
                $printers = dmd3d_catalog_profiles('printer');
            } catch (Throwable $error) {
                $errors['printer'] = $error->getMessage();
            }

            try {
                $plugs = dmd3d_catalog_profiles('plug');
            } catch (Throwable $error) {
                $errors['plug'] = $error->getMessage();
            }

            dmd3d_catalog_json([
                'ok' => true,
                'imprimantes' => $printers,
                'prises' => $plugs,
                'catalog_errors' => $errors,
            ]);
        }

        if ($action === 'install') {
            if (!dmd3d_has_permission('model.install')) {
                dmd3d_catalog_json(['ok' => false, 'message' => 'Permission DoMyDesk refusée : model.install.'], 403);
            }
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                dmd3d_catalog_json(['ok' => false, 'message' => 'Méthode refusée.'], 405);
            }

            $payload = json_decode((string)file_get_contents('php://input'), true);
            if (!is_array($payload)) {
                throw new RuntimeException('Requête JSON invalide.');
            }

            $csrf = (string)($payload['csrf'] ?? '');
            $sessionCsrf = (string)($_SESSION['dmd3d_catalog_csrf'] ?? '');
            if ($sessionCsrf === '' || !hash_equals($sessionCsrf, $csrf)) {
                dmd3d_catalog_json(['ok' => false, 'message' => 'Jeton de sécurité invalide. Recharge la page.'], 403);
            }

            $type = (string)($payload['type'] ?? '');
            if (!in_array($type, ['printer', 'plug'], true)) {
                throw new RuntimeException('Type de profil invalide.');
            }

            $id = strtolower(trim((string)($payload['id'] ?? '')));
            $profiles = dmd3d_catalog_profiles($type);
            $profile = null;
            foreach ($profiles as $candidate) {
                if (strtolower((string)($candidate['id'] ?? '')) === $id) {
                    $profile = $candidate;
                    break;
                }
            }
            if (!is_array($profile)) {
                throw new RuntimeException('Profil introuvable dans le catalogue GitHub actuel.');
            }

            $model = dmd3d_catalog_install_zip($profile, $type);
            dmd3d_record_event('model.install', $type === 'printer' ? 'printer_model' : 'plug_model', [
                'id' => (string)($model['id'] ?? ''),
                'name' => trim((string)($profile['constructeur'] ?? '') . ' ' . (string)($profile['modele'] ?? '')) ?: (string)($model['id'] ?? 'Modèle'),
            ], 'ok', ['source' => 'github', 'version_profil' => (string)($profile['version_profil'] ?? '')]);
            dmd3d_catalog_json([
                'ok' => true,
                'message' => 'Profil installé dans le stockage persistant DMD-3DPRINT.',
                'model' => $model,
            ]);
        }

        dmd3d_catalog_json(['ok' => false, 'message' => 'Action inconnue.'], 404);
    } catch (Throwable $error) {
        dmd3d_catalog_json(['ok' => false, 'message' => $error->getMessage()], 400);
    }
}
$scriptPath = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
$moduleMarker = '/modules/dmd-3dprint/';
$markerPosition = strpos($scriptPath, $moduleMarker);
if ($markerPosition !== false) {
    $moduleBaseUrl = substr($scriptPath, 0, $markerPosition) . '/modules/dmd-3dprint';
} else {
    $scriptDirectory = str_replace('\\', '/', dirname($scriptPath));
    if (substr($scriptDirectory, -4) === '/adm') {
        $scriptDirectory = str_replace('\\', '/', dirname($scriptDirectory));
    }
    $moduleBaseUrl = rtrim($scriptDirectory, '/') . '/modules/dmd-3dprint';
}
if ($moduleBaseUrl === '') {
    $moduleBaseUrl = '/modules/dmd-3dprint';
}
$moduleCssUrl = $moduleBaseUrl . '/dmd-3dprint.css?v=120';
$moduleApiUrl = $moduleBaseUrl . '/dmd-3dprint_api.php';
$catalogEndpointUrl = $moduleBaseUrl . '/dmd-3dprintcfg.php';

$isAdmin = dmd3d_has_permission('config.view');
$canInstallModels = dmd3d_has_permission('model.install');
if (empty($_SESSION['dmd3d_catalog_csrf']) || !is_string($_SESSION['dmd3d_catalog_csrf'])) {
    $_SESSION['dmd3d_catalog_csrf'] = bin2hex(random_bytes(24));
}
$catalogCsrf = (string)$_SESSION['dmd3d_catalog_csrf'];
$instanceId = 'dmd3dcfg-' . bin2hex(random_bytes(4));
?>
<link rel="stylesheet" href="<?= htmlspecialchars($moduleCssUrl, ENT_QUOTES, 'UTF-8') ?>">


<?php if (!$isAdmin): ?>
<section class="dmd3d"><div class="dmd3d-card"><strong>Permission DoMyDesk refusée : config.view.</strong></div></section>
<?php return; endif; ?>

<section id="<?= htmlspecialchars($instanceId, ENT_QUOTES, 'UTF-8') ?>" class="dmd3d dmd3d-cfg" data-dmd3d-cfg data-dmd-module-id="dmd-3dprint" data-dmd-module-name="DMD-3DPRINT">
    <header class="dmd3d-header">
        <div>
            <p class="dmd3d-kicker">CONFIGURATION DMD-3DPRINT</p>
            <h2>Imprimantes, prises et fichiers modèles</h2>
            <p class="dmd3d-muted">Les équipements sont conservés hors du module dans <code>data/modules/dmd-3dprint/registers/</code>.</p>
        </div>
        <button type="button" class="dmd3d-button" data-refresh>Actualiser</button>
    </header>

    <div class="dmd3d-tabs" role="tablist">
        <button type="button" class="dmd3d-tab is-active" data-tab="devices">Équipements</button>
        <button type="button" class="dmd3d-tab" data-tab="models">Fichiers des modèles</button>
    </div>

    <div class="dmd3d-tab-panel is-active" data-panel="devices">
        <div class="dmd3d-toolbar">
            <div>
                <strong>Équipements enregistrés</strong>
                <p class="dmd3d-muted">Ajoute une imprimante, puis associe-lui éventuellement une prise.</p>
            </div>
            <div class="dmd3d-actions">
                <button type="button" class="dmd3d-button" data-open-plug>＋ Ajouter une prise</button>
                <button type="button" class="dmd3d-button" data-open-printer>＋ Ajouter une imprimante</button>
            </div>
        </div>

        <section class="dmd3d-card">
            <div class="dmd3d-section-title"><h3>Imprimantes enregistrées</h3><span class="dmd3d-counter" data-printer-count>0</span></div>
            <div class="dmd3d-table-wrap">
                <table class="dmd3d-table">
                    <thead><tr><th>Nom</th><th>Marque / modèle</th><th>Connexion</th><th>Fichiers modèle</th><th>Prise</th><th>État</th><th>Actions</th></tr></thead>
                    <tbody data-printer-table><tr><td colspan="7" class="dmd3d-empty">Chargement…</td></tr></tbody>
                </table>
            </div>
        </section>

        <section class="dmd3d-card">
            <div class="dmd3d-section-title"><h3>Prises enregistrées</h3><span class="dmd3d-counter" data-plug-count>0</span></div>
            <div class="dmd3d-table-wrap">
                <table class="dmd3d-table">
                    <thead><tr><th>Nom</th><th>Marque / modèle</th><th>Connexion</th><th>Fichiers modèle</th><th>État</th><th>Actions</th></tr></thead>
                    <tbody data-plug-table><tr><td colspan="6" class="dmd3d-empty">Chargement…</td></tr></tbody>
                </table>
            </div>
        </section>
    </div>

    <div class="dmd3d-tab-panel" data-panel="models">
        <section class="dmd3d-card">
            <div class="dmd3d-section-title">
                <div><h3>Uploader les fichiers correspondant à un modèle</h3><p class="dmd3d-muted">Le ZIP est extrait dans le stockage persistant <code>data/modules/dmd-3dprint/models/</code>.</p></div>
            </div>
            <form class="dmd3d-form dmd3d-model-upload" data-model-form enctype="multipart/form-data">
                <div class="dmd3d-field"><label>Type</label><select name="model_type" required><option value="printer">Modèle d’imprimante</option><option value="plug">Modèle de prise</option></select></div>
                <div class="dmd3d-field"><label>Nom du dossier du modèle</label><input name="model_name" maxlength="100" required placeholder="nom-du-modele"></div>
                <div class="dmd3d-field dmd3d-wide"><label>Fichier ZIP</label><input name="model_zip" type="file" accept=".zip,application/zip" required></div>
                <label class="dmd3d-checkbox dmd3d-wide"><input name="replace" type="checkbox" value="1"> Remplacer le dossier s’il existe déjà</label>
                <div class="dmd3d-actions dmd3d-wide"><button type="submit" class="dmd3d-button">Uploader et extraire</button></div>
            </form>
            <div class="dmd3d-inline-message" data-upload-message aria-live="polite"></div>
        </section>

        <div class="dmd3d-catalog-grid">
            <section class="dmd3d-card">
                <div class="dmd3d-section-title">
                    <div><h3>Profils d’imprimantes disponibles sur GitHub</h3><p class="dmd3d-muted dmd3d-catalog-source"><?= htmlspecialchars(DMD3D_PRINTER_CATALOG_URL, ENT_QUOTES, 'UTF-8') ?></p></div>
                    <span class="dmd3d-counter" data-printer-catalog-count>0</span>
                </div>
                <div class="dmd3d-table-wrap">
                    <table class="dmd3d-table dmd3d-catalog-table">
                        <thead><tr><th>Constructeur</th><th>Modèle</th><th>Actions</th></tr></thead>
                        <tbody data-printer-catalog><tr><td colspan="3" class="dmd3d-empty">Chargement du catalogue GitHub…</td></tr></tbody>
                    </table>
                </div>
            </section>

            <section class="dmd3d-card">
                <div class="dmd3d-section-title">
                    <div><h3>Profils de prises disponibles sur GitHub</h3><p class="dmd3d-muted dmd3d-catalog-source"><?= htmlspecialchars(DMD3D_PLUG_CATALOG_URL, ENT_QUOTES, 'UTF-8') ?></p></div>
                    <span class="dmd3d-counter" data-plug-catalog-count>0</span>
                </div>
                <div class="dmd3d-table-wrap">
                    <table class="dmd3d-table dmd3d-catalog-table">
                        <thead><tr><th>Constructeur</th><th>Modèle</th><th>Actions</th></tr></thead>
                        <tbody data-plug-catalog><tr><td colspan="3" class="dmd3d-empty">Chargement du catalogue GitHub…</td></tr></tbody>
                    </table>
                </div>
            </section>
        </div>


        <div class="dmd3d-cfg-grid">
            <section class="dmd3d-card">
                <div class="dmd3d-section-title"><h3>Modèles d’imprimantes uploadés</h3><span class="dmd3d-counter" data-printer-model-count>0</span></div>
                <div class="dmd3d-register-list" data-printer-model-list><p class="dmd3d-empty">Aucun dossier.</p></div>
            </section>
            <section class="dmd3d-card">
                <div class="dmd3d-section-title"><h3>Modèles de prises uploadés</h3><span class="dmd3d-counter" data-plug-model-count>0</span></div>
                <div class="dmd3d-register-list" data-plug-model-list><p class="dmd3d-empty">Aucun dossier.</p></div>
            </section>
        </div>
    </div>

    <div class="dmd3d-toast" data-toast hidden></div>

    <div class="dmd3d-modal" data-catalog-modal hidden>
        <div class="dmd3d-modal-backdrop" data-close-modal></div>
        <section class="dmd3d-dialog dmd3d-catalog-info-dialog" role="dialog" aria-modal="true" aria-labelledby="<?= htmlspecialchars($instanceId, ENT_QUOTES, 'UTF-8') ?>-catalog-title">
            <header class="dmd3d-dialog-head">
                <h3 id="<?= htmlspecialchars($instanceId, ENT_QUOTES, 'UTF-8') ?>-catalog-title" data-catalog-modal-title>Informations du profil</h3>
                <button type="button" class="dmd3d-close" data-close-modal>✕</button>
            </header>
            <div class="dmd3d-catalog-info-body">
                <div class="dmd3d-catalog-info-image-wrap">
                    <img class="dmd3d-catalog-info-image" data-catalog-modal-image alt="">
                    <span class="dmd3d-catalog-info-empty-image" data-catalog-modal-no-image hidden>Aucune image disponible</span>
                </div>
                <div class="dmd3d-catalog-info-details">
                    <div class="dmd3d-catalog-info-line"><span>Constructeur</span><strong data-catalog-modal-maker>—</strong></div>
                    <div class="dmd3d-catalog-info-line"><span>Modèle</span><strong data-catalog-modal-model>—</strong></div>
                    <div class="dmd3d-catalog-info-line"><span>Software</span><strong data-catalog-modal-software>—</strong></div>
                    <div class="dmd3d-catalog-info-line"><span>Version du profil</span><strong data-catalog-modal-version>—</strong></div>
                    <div class="dmd3d-catalog-info-line"><span>Dossier</span><strong data-catalog-modal-folder>—</strong></div>
                    <div class="dmd3d-catalog-info-line"><span>Description</span><p class="dmd3d-catalog-info-description" data-catalog-modal-description>—</p></div>
                </div>
            </div>
            <footer class="dmd3d-catalog-info-actions">
                <button type="button" class="dmd3d-button" data-close-modal>Fermer</button>
                <button type="button" class="dmd3d-button" data-catalog-modal-install>Installer</button>
            </footer>
        </section>
    </div>

    <div class="dmd3d-modal" data-printer-modal hidden>
        <div class="dmd3d-modal-backdrop" data-close-modal></div>
        <section class="dmd3d-dialog" role="dialog" aria-modal="true">
            <header class="dmd3d-dialog-head"><h3 data-printer-form-title>Ajouter une imprimante</h3><button type="button" class="dmd3d-close" data-close-modal>✕</button></header>
            <form class="dmd3d-form dmd3d-dialog-body" data-printer-form>
                <input type="hidden" name="id">
                <div class="dmd3d-field"><label>Nom de l’imprimante *</label><input name="name" required maxlength="120" placeholder="Imprimante atelier"></div>
                <div class="dmd3d-field"><label>Marque</label><input name="brand" maxlength="100" placeholder="Marque"></div>
                <div class="dmd3d-field"><label>Modèle physique</label><input name="device_model" maxlength="120" placeholder="Modèle"></div>
                <div class="dmd3d-field"><label>Dossier des fichiers du modèle</label><select name="model" data-printer-model-select><option value="">Aucun dossier sélectionné</option></select></div>
                <div class="dmd3d-field"><label>Adresse IP ou DNS *</label><input name="host" required maxlength="253" placeholder="10.10.3.123"></div>
                <div class="dmd3d-field-pair"><div class="dmd3d-field"><label>Protocole</label><select name="protocol"><option value="http">HTTP</option><option value="https">HTTPS</option></select></div><div class="dmd3d-field"><label>Port</label><input name="port" type="number" min="1" max="65535" value="80" required></div></div>
                <div class="dmd3d-field"><label>Prise associée</label><select name="plug_id" data-plug-select><option value="">Aucune prise</option></select></div>
                <div class="dmd3d-field"><label>URL caméra facultative</label><input name="camera_url" type="url" maxlength="1000" placeholder="http://ip:port/stream"></div>
                <div class="dmd3d-field"><label>Identifiant</label><input name="username" maxlength="160" autocomplete="off"></div>
                <div class="dmd3d-field"><label>Mot de passe</label><input name="password" type="password" autocomplete="new-password" placeholder="Vide = conserver"></div>
                <div class="dmd3d-field"><label>Clé API</label><input name="api_key" type="password" autocomplete="new-password" placeholder="Vide = conserver"></div>
                <div class="dmd3d-field"><label>Jeton</label><input name="token" type="password" autocomplete="new-password" placeholder="Vide = conserver"></div>
                <div class="dmd3d-field dmd3d-wide"><label>Accès à cette imprimante</label><select name="access_mode" data-access-mode><option value="everyone">Tous les utilisateurs autorisés au module</option><option value="selected">Uniquement les utilisateurs sélectionnés</option></select></div>
                <div class="dmd3d-field dmd3d-wide" data-access-users-wrap><label>Utilisateurs autorisés</label><select name="access_users" data-access-users multiple size="6"></select><p class="dmd3d-muted">Le partage de l’imprimante ne remplace pas les permissions d’action DoMyDesk : elles restent obligatoires.</p></div>
                <div class="dmd3d-field dmd3d-wide"><label>Options supplémentaires du pilote (JSON)</label><textarea name="options" rows="3" placeholder="{}"></textarea></div>
                <div class="dmd3d-field dmd3d-wide"><label>Notes</label><textarea name="notes" rows="3"></textarea></div>
                <label class="dmd3d-checkbox dmd3d-wide"><input name="enabled" type="checkbox" checked> Imprimante active</label>
                <footer class="dmd3d-dialog-actions dmd3d-wide"><button type="button" class="dmd3d-button" data-close-modal>Annuler</button><button type="submit" class="dmd3d-button">Enregistrer l’imprimante</button></footer>
            </form>
        </section>
    </div>

    <div class="dmd3d-modal" data-plug-modal hidden>
        <div class="dmd3d-modal-backdrop" data-close-modal></div>
        <section class="dmd3d-dialog" role="dialog" aria-modal="true">
            <header class="dmd3d-dialog-head"><h3 data-plug-form-title>Ajouter une prise</h3><button type="button" class="dmd3d-close" data-close-modal>✕</button></header>
            <form class="dmd3d-form dmd3d-dialog-body" data-plug-form>
                <input type="hidden" name="id">
                <div class="dmd3d-field"><label>Nom de la prise *</label><input name="name" required maxlength="120" placeholder="Prise imprimante atelier"></div>
                <div class="dmd3d-field"><label>Marque</label><input name="brand" maxlength="100" placeholder="Tapo"></div>
                <div class="dmd3d-field"><label>Modèle physique</label><input name="device_model" maxlength="120" placeholder="P110"></div>
                <div class="dmd3d-field"><label>Dossier des fichiers du modèle</label><select name="model" data-plug-model-select><option value="">Aucun dossier sélectionné</option></select></div>
                <div class="dmd3d-field"><label>Adresse IP ou DNS *</label><input name="host" required maxlength="253" placeholder="10.10.3.124"></div>
                <div class="dmd3d-field-pair"><div class="dmd3d-field"><label>Protocole</label><select name="protocol"><option value="http">HTTP</option><option value="https">HTTPS</option></select></div><div class="dmd3d-field"><label>Port</label><input name="port" type="number" min="1" max="65535" value="80" required></div></div>
                <div class="dmd3d-field"><label>Identifiant</label><input name="username" maxlength="160" autocomplete="off"></div>
                <div class="dmd3d-field"><label>Mot de passe</label><input name="password" type="password" autocomplete="new-password" placeholder="Vide = conserver"></div>
                <div class="dmd3d-field"><label>Clé API</label><input name="api_key" type="password" autocomplete="new-password" placeholder="Vide = conserver"></div>
                <div class="dmd3d-field"><label>Jeton</label><input name="token" type="password" autocomplete="new-password" placeholder="Vide = conserver"></div>
                <div class="dmd3d-field dmd3d-wide"><label>Accès à cette prise</label><select name="access_mode" data-access-mode><option value="everyone">Tous les utilisateurs autorisés au module</option><option value="selected">Uniquement les utilisateurs sélectionnés</option></select></div>
                <div class="dmd3d-field dmd3d-wide" data-access-users-wrap><label>Utilisateurs autorisés</label><select name="access_users" data-access-users multiple size="6"></select><p class="dmd3d-muted">Le partage de la prise ne remplace pas les permissions d’action DoMyDesk : elles restent obligatoires.</p></div>
                <div class="dmd3d-field dmd3d-wide"><label>Options supplémentaires du pilote (JSON)</label><textarea name="options" rows="3" placeholder="{}"></textarea></div>
                <div class="dmd3d-field dmd3d-wide"><label>Notes</label><textarea name="notes" rows="3"></textarea></div>
                <label class="dmd3d-checkbox dmd3d-wide"><input name="enabled" type="checkbox" checked> Prise active</label>
                <footer class="dmd3d-dialog-actions dmd3d-wide"><button type="button" class="dmd3d-button" data-close-modal>Annuler</button><button type="submit" class="dmd3d-button">Enregistrer la prise</button></footer>
            </form>
        </section>
    </div>
</section>

<script>
(() => {
    const root = document.getElementById(<?= json_encode($instanceId, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>);
    if (!root || root.dataset.ready === '1') return;
    root.dataset.ready = '1';


    const api = <?= json_encode($moduleApiUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const canInstallModels = <?= $canInstallModels ? 'true' : 'false' ?>;
    const catalogApi = <?= json_encode($catalogEndpointUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const catalogCsrf = <?= json_encode($catalogCsrf, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    const state = {csrf:'', printers:[], plugs:[], printerModels:[], plugModels:[], printerCatalog:[], plugCatalog:[], aclUsers:[]};
    const q = selector => root.querySelector(selector);
    const qa = selector => [...root.querySelectorAll(selector)];
    const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));

    function toast(message, error = false) {
        const el = q('[data-toast]');
        el.textContent = message;
        el.hidden = false;
        el.classList.toggle('is-error', error);
        clearTimeout(el._timer);
        el._timer = setTimeout(() => { el.hidden = true; }, 5500);
    }

    async function request(action, options = {}) {
        const separator = action.indexOf('&');
        const actionName = separator >= 0 ? action.slice(0, separator) : action;
        const extraQuery = separator >= 0 ? '&' + action.slice(separator + 1) : '';
        const response = await fetch(`${api}?action=${encodeURIComponent(actionName)}${extraQuery}`, {credentials:'same-origin', cache:'no-store', ...options});
        const text = await response.text();
        let data;
        try { data = JSON.parse(text); }
        catch (error) { throw new Error(`API inaccessible (${response.status}) : ${api} — ${text.slice(0, 160) || 'réponse vide'}`); }
        if (!response.ok || !data.ok) throw new Error(data.message || `Erreur HTTP ${response.status}`);
        return data;
    }

    function sendJson(action, payload) {
        return request(action, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({...payload, csrf:state.csrf})});
    }

    async function catalogRequest(action, payload = null) {
        const options = {credentials:'same-origin', cache:'no-store'};
        if (payload !== null) {
            options.method = 'POST';
            options.headers = {'Content-Type':'application/json'};
            options.body = JSON.stringify({...payload, csrf:catalogCsrf});
        }
        const response = await fetch(`${catalogApi}?dmd3d_catalog_action=${encodeURIComponent(action)}`, options);
        const text = await response.text();
        let data;
        try { data = JSON.parse(text); }
        catch (error) { throw new Error(`Catalogue GitHub inaccessible (${response.status}) : ${text.slice(0, 180) || 'réponse vide'}`); }
        if (!response.ok || !data.ok) throw new Error(data.message || `Erreur HTTP ${response.status}`);
        return data;
    }

    function modelLabel(type, id) {
        if (!id) return 'Aucun';
        const source = type === 'printer' ? state.printerModels : state.plugModels;
        const item = source.find(model => model.id === id);
        return item ? item.name : id;
    }

    function plugLabel(id) {
        if (!id) return 'Aucune';
        return state.plugs.find(item => item.id === id)?.name || 'Prise supprimée';
    }

    function renderDeviceTables() {
        q('[data-printer-count]').textContent = state.printers.length;
        q('[data-plug-count]').textContent = state.plugs.length;

        q('[data-printer-table]').innerHTML = state.printers.length ? state.printers.map(item => `
            <tr>
                <td><strong>${esc(item.name)}</strong></td>
                <td>${esc([item.brand, item.device_model].filter(Boolean).join(' ') || '—')}</td>
                <td><code>${esc(item.protocol || 'http')}://${esc(item.host)}:${esc(item.port || '')}</code></td>
                <td>${esc(modelLabel('printer', item.model))}</td>
                <td>${esc(plugLabel(item.plug_id))}</td>
                <td><span class="dmd3d-status ${item.enabled === false ? 'is-offline' : 'is-online'}">${item.enabled === false ? 'Désactivée' : 'Active'}</span></td>
                <td><div class="dmd3d-table-actions"><button class="dmd3d-button" data-test="printer:${esc(item.id)}">Tester</button><button class="dmd3d-button" data-edit="printer:${esc(item.id)}">Modifier</button><button class="dmd3d-button dmd3d-danger" data-delete="printer:${esc(item.id)}">Supprimer</button></div></td>
            </tr>`).join('') : '<tr><td colspan="7" class="dmd3d-empty">Aucune imprimante enregistrée.</td></tr>';

        q('[data-plug-table]').innerHTML = state.plugs.length ? state.plugs.map(item => `
            <tr>
                <td><strong>${esc(item.name)}</strong></td>
                <td>${esc([item.brand, item.device_model].filter(Boolean).join(' ') || '—')}</td>
                <td><code>${esc(item.protocol || 'http')}://${esc(item.host)}:${esc(item.port || '')}</code></td>
                <td>${esc(modelLabel('plug', item.model))}</td>
                <td><span class="dmd3d-status ${item.enabled === false ? 'is-offline' : 'is-online'}">${item.enabled === false ? 'Désactivée' : 'Active'}</span></td>
                <td><div class="dmd3d-table-actions"><button class="dmd3d-button" data-test="plug:${esc(item.id)}">Tester</button><button class="dmd3d-button" data-edit="plug:${esc(item.id)}">Modifier</button><button class="dmd3d-button dmd3d-danger" data-delete="plug:${esc(item.id)}">Supprimer</button></div></td>
            </tr>`).join('') : '<tr><td colspan="6" class="dmd3d-empty">Aucune prise enregistrée.</td></tr>';
    }

    function modelCard(type, item) {
        return `<article class="dmd3d-register-item">
            <div><strong>${esc(item.name || item.id)}</strong><span>Dossier : ${esc(item.id)}</span><small>${Number(item.file_count || 0)} fichier(s) · ${item.ready ? `pilote détecté : ${esc(item.entry || '')}` : 'fichiers uploadés, aucun pilote PHP détecté'}</small></div>
            <button type="button" class="dmd3d-button dmd3d-danger" data-delete-model="${esc(type)}:${esc(item.id)}">Supprimer</button>
        </article>`;
    }

    function renderModels() {
        q('[data-printer-model-count]').textContent = state.printerModels.length;
        q('[data-plug-model-count]').textContent = state.plugModels.length;
        q('[data-printer-model-list]').innerHTML = state.printerModels.length ? state.printerModels.map(item => modelCard('printer', item)).join('') : '<p class="dmd3d-empty">Aucun dossier dans imprimantes/.</p>';
        q('[data-plug-model-list]').innerHTML = state.plugModels.length ? state.plugModels.map(item => modelCard('plug', item)).join('') : '<p class="dmd3d-empty">Aucun dossier dans prises/.</p>';
    }

    function isCatalogInstalled(type, item) {
        const source = type === 'printer' ? state.printerModels : state.plugModels;
        return source.some(model => String(model.id || '').toLowerCase() === String(item.dossier || '').toLowerCase());
    }

    function catalogRows(type, items) {
        if (!items.length) return '<tr><td colspan="3" class="dmd3d-empty">Aucun profil publié dans ce catalogue.</td></tr>';
        return items.map(item => {
            const installed = isCatalogInstalled(type, item);
            const label = installed ? 'Mettre à jour' : 'Installer';
            return `<tr class="dmd3d-catalog-row">
                <td><strong>${esc(item.constructeur || '—')}</strong></td>
                <td><strong>${esc(item.modele || '—')}</strong></td>
                <td>
                    <div class="dmd3d-catalog-actions">
                        <button type="button" class="dmd3d-button dmd3d-catalog-eye" data-view-catalog="${esc(type)}:${esc(item.id)}" title="Voir les informations" aria-label="Voir les informations">👁</button>
                        ${canInstallModels ? `<button type="button" class="dmd3d-button" data-install-catalog="${esc(type)}:${esc(item.id)}">${label}</button>` : ''}
                    </div>
                </td>
            </tr>`;
        }).join('');
    }

    function renderCatalogs() {
        q('[data-printer-catalog-count]').textContent = state.printerCatalog.length;
        q('[data-plug-catalog-count]').textContent = state.plugCatalog.length;
        q('[data-printer-catalog]').innerHTML = catalogRows('printer', state.printerCatalog);
        q('[data-plug-catalog]').innerHTML = catalogRows('plug', state.plugCatalog);
    }

    async function loadCatalogs() {
        q('[data-printer-catalog]').innerHTML = '<tr><td colspan="3" class="dmd3d-empty">Chargement du catalogue GitHub…</td></tr>';
        q('[data-plug-catalog]').innerHTML = '<tr><td colspan="3" class="dmd3d-empty">Chargement du catalogue GitHub…</td></tr>';
        try {
            const data = await catalogRequest('list');
            state.printerCatalog = Array.isArray(data.imprimantes) ? data.imprimantes : [];
            state.plugCatalog = Array.isArray(data.prises) ? data.prises : [];
            renderCatalogs();

            const errors = data.catalog_errors && typeof data.catalog_errors === 'object' ? data.catalog_errors : {};
            if (errors.printer) {
                q('[data-printer-catalog]').innerHTML = `<tr><td colspan="3" class="dmd3d-empty">${esc(errors.printer)}</td></tr>`;
            }
            if (errors.plug) {
                q('[data-plug-catalog]').innerHTML = `<tr><td colspan="3" class="dmd3d-empty">${esc(errors.plug)}</td></tr>`;
            }
            if (errors.printer || errors.plug) {
                toast('Un catalogue GitHub contient une erreur. Le détail est affiché dans sa propre liste.', true);
            }
        } catch (error) {
            state.printerCatalog = [];
            state.plugCatalog = [];
            q('[data-printer-catalog]').innerHTML = `<tr><td colspan="3" class="dmd3d-empty">${esc(error.message)}</td></tr>`;
            q('[data-plug-catalog]').innerHTML = `<tr><td colspan="3" class="dmd3d-empty">${esc(error.message)}</td></tr>`;
            throw error;
        }
    }

    function fillSelect(select, items, emptyText) {
        const value = select.value;
        select.innerHTML = `<option value="">${esc(emptyText)}</option>` + items.map(item => `<option value="${esc(item.id)}">${esc(item.name || item.id)}</option>`).join('');
        if ([...select.options].some(option => option.value === value)) select.value = value;
    }

    function fillForms() {
        fillSelect(q('[data-printer-model-select]'), state.printerModels, 'Aucun dossier sélectionné');
        fillSelect(q('[data-plug-model-select]'), state.plugModels, 'Aucun dossier sélectionné');
        fillSelect(q('[data-plug-select]'), state.plugs, 'Aucune prise');
    }

    async function load() {
        const data = await request('bootstrap&scope=config');
        state.csrf = data.csrf || '';
        state.printers = data.imprimantes || [];
        state.plugs = data.prises || [];
        state.aclUsers = Array.isArray(data.acl_users) ? data.acl_users : [];
        state.printerModels = data.modeles_imprimantes || [];
        state.plugModels = data.modeles_prises || [];
        renderDeviceTables();
        renderModels();
        fillForms();
    }

    async function fullLoad() {
        await load();
        await loadCatalogs();
    }

    const catalogModal = q('[data-catalog-modal]');
    const catalogModalTitle = q('[data-catalog-modal-title]');
    const catalogModalImage = q('[data-catalog-modal-image]');
    const catalogModalNoImage = q('[data-catalog-modal-no-image]');
    const catalogModalMaker = q('[data-catalog-modal-maker]');
    const catalogModalModel = q('[data-catalog-modal-model]');
    const catalogModalSoftware = q('[data-catalog-modal-software]');
    const catalogModalVersion = q('[data-catalog-modal-version]');
    const catalogModalFolder = q('[data-catalog-modal-folder]');
    const catalogModalDescription = q('[data-catalog-modal-description]');
    const catalogModalInstall = q('[data-catalog-modal-install]');
    if (catalogModalInstall && !canInstallModels) catalogModalInstall.hidden = true;

    function findCatalogProfile(type, id) {
        const source = type === 'printer' ? state.printerCatalog : state.plugCatalog;
        return source.find(item => String(item.id) === String(id)) || null;
    }

    function openCatalogModal(type, item) {
        if (!item) return;

        const installed = isCatalogInstalled(type, item);
        const title = `${item.constructeur || ''} ${item.modele || ''}`.trim() || 'Informations du profil';

        catalogModalTitle.textContent = title;
        catalogModalMaker.textContent = item.constructeur || '—';
        catalogModalModel.textContent = item.modele || '—';
        catalogModalSoftware.textContent = item.software || 'Non précisé';
        catalogModalVersion.textContent = item.version_profil || 'Non précisée';
        catalogModalFolder.textContent = item.dossier || '—';
        catalogModalDescription.textContent = item.description || 'Aucune description.';

        if (item.image) {
            catalogModalImage.src = item.image;
            catalogModalImage.alt = title;
            catalogModalImage.hidden = false;
            catalogModalNoImage.hidden = true;
        } else {
            catalogModalImage.removeAttribute('src');
            catalogModalImage.alt = '';
            catalogModalImage.hidden = true;
            catalogModalNoImage.hidden = false;
        }

        catalogModalInstall.dataset.installCatalog = `${type}:${item.id}`;
        catalogModalInstall.textContent = installed ? 'Mettre à jour' : 'Installer';

        catalogModal.hidden = false;
        document.body.classList.add('dmd3d-modal-open');
    }

    function fillAccessUsers(form, selected = []) {
        const select = form.elements.access_users;
        if (!select) return;
        const wanted = new Set((Array.isArray(selected) ? selected : []).map(value => String(value).toLowerCase()));
        select.innerHTML = state.aclUsers.map(user => {
            const email = String(user.email || '').toLowerCase();
            const name = user.name || email;
            const moduleInfo = user.module_access ? '' : ' · module non autorisé';
            return `<option value="${esc(email)}" ${wanted.has(email) ? 'selected' : ''}>${esc(name)} — ${esc(email)}${esc(moduleInfo)}</option>`;
        }).join('');
    }

    function syncAccessFields(form) {
        const mode = form.elements.access_mode ? form.elements.access_mode.value : 'everyone';
        const select = form.elements.access_users;
        const wrap = form.querySelector('[data-access-users-wrap]');
        if (select) select.disabled = mode !== 'selected';
        if (wrap) wrap.hidden = mode !== 'selected';
    }

    function openModal(type, device = null) {
        const modal = q(type === 'printer' ? '[data-printer-modal]' : '[data-plug-modal]');
        const form = q(type === 'printer' ? '[data-printer-form]' : '[data-plug-form]');
        const title = q(type === 'printer' ? '[data-printer-form-title]' : '[data-plug-form-title]');
        form.reset();
        form.elements.id.value = '';
        form.elements.port.value = '80';
        form.elements.options.value = '{}';
        form.elements.enabled.checked = true;
        if (form.elements.access_mode) form.elements.access_mode.value = 'everyone';
        fillAccessUsers(form, []);
        syncAccessFields(form);
        title.textContent = type === 'printer' ? 'Ajouter une imprimante' : 'Ajouter une prise';
        if (device) {
            title.textContent = `Modifier ${device.name}`;
            for (const [key, value] of Object.entries(device)) {
                const field = form.elements[key];
                if (!field || ['password','api_key','token'].includes(key)) continue;
                if (field.type === 'checkbox') field.checked = Boolean(value);
                else if (key === 'options') field.value = JSON.stringify(value || {}, null, 2);
                else field.value = value ?? '';
            }
            const access = device.resource_access && typeof device.resource_access === 'object' ? device.resource_access : {mode:'everyone', users:[]};
            if (form.elements.access_mode) form.elements.access_mode.value = access.mode === 'selected' ? 'selected' : 'everyone';
            fillAccessUsers(form, Array.isArray(access.users) ? access.users : []);
            syncAccessFields(form);
        }
        modal.hidden = false;
        document.body.classList.add('dmd3d-modal-open');
        setTimeout(() => form.elements.name.focus(), 30);
    }

    function closeModals() {
        qa('.dmd3d-modal').forEach(modal => { modal.hidden = true; });
        document.body.classList.remove('dmd3d-modal-open');
    }

    function formPayload(form) {
        const data = Object.fromEntries(new FormData(form).entries());
        data.enabled = form.elements.enabled.checked;
        data.options = form.elements.options.value.trim() || '{}';
        data.access_mode = form.elements.access_mode ? form.elements.access_mode.value : 'everyone';
        data.access_users = form.elements.access_users
            ? [...form.elements.access_users.options].filter(option => option.selected).map(option => option.value)
            : [];
        return data;
    }

    qa('[data-tab]').forEach(button => button.addEventListener('click', () => {
        qa('[data-tab]').forEach(item => item.classList.toggle('is-active', item === button));
        qa('[data-panel]').forEach(panel => panel.classList.toggle('is-active', panel.dataset.panel === button.dataset.tab));
    }));

    q('[data-model-form]').addEventListener('submit', async event => {
        event.preventDefault();
        const form = event.currentTarget;
        const button = form.querySelector('button[type="submit"]');
        const message = q('[data-upload-message]');
        const body = new FormData(form);
        body.set('csrf', state.csrf);
        body.set('replace', form.elements.replace.checked ? '1' : '0');
        button.disabled = true;
        message.textContent = 'Upload et extraction en cours…';
        message.classList.remove('is-error', 'is-success');
        try {
            const data = await request('install_model', {method:'POST', body});
            const model = data.model || {};
            message.textContent = `Upload réussi : ${model.file_count || 0} fichier(s) extrait(s) dans ${form.elements.model_type.value === 'printer' ? 'imprimantes' : 'prises'}/${model.id}/.`;
            message.classList.add('is-success');
            form.reset();
            await fullLoad();
        } catch (error) {
            message.textContent = `Échec : ${error.message}`;
            message.classList.add('is-error');
            toast(error.message, true);
        } finally { button.disabled = false; }
    });

    q('[data-printer-form]').addEventListener('submit', async event => {
        event.preventDefault();
        const button = event.currentTarget.querySelector('button[type="submit"]');
        button.disabled = true;
        try { await sendJson('save_printer', formPayload(event.currentTarget)); closeModals(); await fullLoad(); toast('Imprimante enregistrée.'); }
        catch (error) { toast(error.message, true); }
        finally { button.disabled = false; }
    });

    q('[data-plug-form]').addEventListener('submit', async event => {
        event.preventDefault();
        const button = event.currentTarget.querySelector('button[type="submit"]');
        button.disabled = true;
        try { await sendJson('save_plug', formPayload(event.currentTarget)); closeModals(); await fullLoad(); toast('Prise enregistrée.'); }
        catch (error) { toast(error.message, true); }
        finally { button.disabled = false; }
    });

    root.addEventListener('click', async event => {
        if (event.target.closest('[data-refresh]')) { try { await fullLoad(); toast('Configuration actualisée.'); } catch (error) { toast(error.message, true); } return; }
        if (event.target.closest('[data-open-printer]')) { openModal('printer'); return; }
        if (event.target.closest('[data-open-plug]')) { openModal('plug'); return; }
        if (event.target.closest('[data-close-modal]')) { closeModals(); return; }

        const edit = event.target.closest('[data-edit]');
        if (edit) {
            const [type, id] = edit.dataset.edit.split(':');
            const source = type === 'printer' ? state.printers : state.plugs;
            const device = source.find(item => item.id === id);
            if (device) openModal(type, device);
            return;
        }

        const remove = event.target.closest('[data-delete]');
        if (remove) {
            const [type, id] = remove.dataset.delete.split(':');
            if (!confirm(`Supprimer cet équipement ?`)) return;
            try { await sendJson(type === 'printer' ? 'delete_printer' : 'delete_plug', {id}); await fullLoad(); toast('Équipement supprimé.'); }
            catch (error) { toast(error.message, true); }
            return;
        }

        const test = event.target.closest('[data-test]');
        if (test) {
            const [type, id] = test.dataset.test.split(':');
            test.disabled = true;
            try {
                const data = await sendJson(type === 'printer' ? 'test_printer' : 'test_plug', {id});
                const result = data.result || {};
                toast(result.message || ((result.online ?? result.connected ?? result.ok) === false ? 'Équipement hors ligne.' : 'Le pilote a répondu.'));
            } catch (error) { toast(error.message, true); }
            finally { test.disabled = false; }
            return;
        }

        const viewCatalog = event.target.closest('[data-view-catalog]');
        if (viewCatalog) {
            const [type, id] = viewCatalog.dataset.viewCatalog.split(':');
            const profile = findCatalogProfile(type, id);
            if (!profile) {
                toast('Profil GitHub introuvable.', true);
                return;
            }
            openCatalogModal(type, profile);
            return;
        }

        const installCatalog = event.target.closest('[data-install-catalog]');
        if (installCatalog) {
            const [type, id] = installCatalog.dataset.installCatalog.split(':');
            const source = type === 'printer' ? state.printerCatalog : state.plugCatalog;
            const profile = source.find(item => item.id === id);
            if (!profile) { toast('Profil GitHub introuvable.', true); return; }
            const installed = isCatalogInstalled(type, profile);
            const actionLabel = installed ? 'mettre à jour' : 'installer';
            if (!confirm(`${actionLabel.charAt(0).toUpperCase() + actionLabel.slice(1)} le profil ${profile.constructeur} ${profile.modele} dans ${type === 'printer' ? 'imprimantes' : 'prises'}/${profile.dossier}/ ?`)) return;
            installCatalog.disabled = true;
            installCatalog.textContent = installed ? 'Mise à jour…' : 'Installation…';
            try {
                const data = await catalogRequest('install', {type, id});
                await fullLoad();
                toast(data.message || 'Profil GitHub installé.');
            } catch (error) {
                toast(error.message, true);
                installCatalog.disabled = false;
                installCatalog.textContent = installed ? 'Mettre à jour' : 'Installer';
            }
            return;
        }

        const deleteModel = event.target.closest('[data-delete-model]');
        if (deleteModel) {
            const [type, model] = deleteModel.dataset.deleteModel.split(':');
            if (!confirm(`Supprimer le dossier ${model} et tous ses fichiers ?`)) return;
            try { await sendJson('delete_model', {model_type:type, model}); await fullLoad(); toast('Dossier du modèle supprimé.'); }
            catch (error) { toast(error.message, true); }
        }
    });

    qa('[data-access-mode]').forEach(select => select.addEventListener('change', () => syncAccessFields(select.form)));

    q('[data-printer-form] [name="protocol"]').addEventListener('change', event => { const port = q('[data-printer-form] [name="port"]'); if (port.value === '80' || port.value === '443') port.value = event.target.value === 'https' ? '443' : '80'; });
    q('[data-plug-form] [name="protocol"]').addEventListener('change', event => { const port = q('[data-plug-form] [name="port"]'); if (port.value === '80' || port.value === '443') port.value = event.target.value === 'https' ? '443' : '80'; });

    fullLoad().catch(error => toast(error.message, true));
})();
</script>
