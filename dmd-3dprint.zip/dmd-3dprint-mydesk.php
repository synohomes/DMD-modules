<?php

/* * =====================================================================
                                DoMyDesk
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.

Vue DMD-MyDesk de DMD-3DPRINT.
Dans MyDesk, le module est présenté comme une application autonome :
la première imprimante est ouverte directement et l'interface de contrôle
occupe tout le WebView, sans reproduire le tableau de bord du site DoMyDesk.

* * ===================================================================== * */

declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/dmd-3dprint_lib.php';

$scriptPath = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
$moduleMarker = '/modules/dmd-3dprint/';
$markerPosition = strpos($scriptPath, $moduleMarker);
if ($markerPosition !== false) {
    $webRoot = rtrim(substr($scriptPath, 0, $markerPosition), '/');
    $moduleBaseUrl = $webRoot . '/modules/dmd-3dprint';
} else {
    $moduleBaseUrl = '/modules/dmd-3dprint';
    $webRoot = '';
}

$email = dmd3d_user_email();
$themeName = 'default';
if ($email !== '') {
    if (function_exists('dmd_safe_user_key')) {
        $safeUser = dmd_safe_user_key($email);
    } else {
        $safeUser = preg_replace('/[^a-zA-Z0-9._-]/', '_', strtolower($email));
    }
    $themeFile = DMD3D_DOMYDESK_ROOT . '/users/profiles/' . $safeUser . '/theme.json';
    if (is_file($themeFile)) {
        $themeData = json_decode((string)@file_get_contents($themeFile), true);
        if (is_array($themeData) && !empty($themeData['theme'])) {
            $candidate = basename((string)$themeData['theme']);
            if (is_file(DMD3D_DOMYDESK_ROOT . '/theme/' . $candidate . '/style.css')) {
                $themeName = $candidate;
            }
        }
    }
}

$themeUrl = ($webRoot !== '' ? $webRoot : '') . '/theme/' . rawurlencode($themeName) . '/style.css';
$myDeskCssVersion = is_file(__DIR__ . '/dmd-3dprint-mydesk.css')
    ? (string)filemtime(__DIR__ . '/dmd-3dprint-mydesk.css')
    : DMD3D_MODULE_VERSION;
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<?php require __DIR__ . '/dmd-3dprint.php'; ?>
<link rel="stylesheet" href="<?= htmlspecialchars($moduleBaseUrl . '/dmd-3dprint-mydesk.css?v=' . $myDeskCssVersion, ENT_QUOTES, 'UTF-8') ?>">
<script>
(() => {
    const html = document.documentElement;

    function markHost() {
        html.classList.add('dmd3d-mydesk-host');
        if (document.body) document.body.classList.add('dmd3d-mydesk-host');
    }

    function sourceWindow() {
        const candidates = [];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}
        for (const candidate of candidates) {
            try {
                if (candidate.document && candidate.location.origin === window.location.origin) return candidate;
            } catch (_) {}
        }
        return null;
    }

    function syncTheme() {
        const source = sourceWindow();
        if (!source) return;
        const names = [
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg',
            '--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft',
            '--border-color','--danger-color','--success-color','--warning-color','--shadow-color',
            '--radius-sm','--radius','--radius-lg',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow',
            '--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color',
            '--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg',
            '--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];
        const targets = [document.documentElement, document.body].filter(Boolean);
        [source.document.documentElement, source.document.body].filter(Boolean).forEach(sourceRoot => {
            const style = source.getComputedStyle(sourceRoot);
            names.forEach(name => {
                const value = style.getPropertyValue(name);
                if (value && value.trim()) targets.forEach(target => target.style.setProperty(name, value.trim()));
            });
        });
        try {
            const bodyStyle = source.getComputedStyle(source.document.body);
            targets.forEach(target => { target.style.fontFamily = bodyStyle.fontFamily || ''; });
        } catch (_) {}
    }

    function prepareAppWindow(win) {
        if (!(win instanceof HTMLElement) || !win.classList.contains('dmd3d-control-window')) return;
        if (win.dataset.mydeskAppPrepared === '1') return;
        win.dataset.mydeskAppPrepared = '1';
        win.classList.add('dmd3d-mydesk-app-window');
        win.style.removeProperty('left');
        win.style.removeProperty('top');
        win.style.removeProperty('width');
        win.style.removeProperty('height');
        if (document.body) document.body.classList.add('dmd3d-mydesk-app-open');

        // Dans MyDesk, la barre haute est une barre d'application, pas une poignée de fenêtre interne.
        const head = win.querySelector('[data-window-head]');
        if (head) {
            head.addEventListener('pointerdown', event => {
                event.stopImmediatePropagation();
            }, true);
        }
    }

    function prepareOverlayWindow(win) {
        if (!(win instanceof HTMLElement) || !win.classList.contains('dmd3d-window')) return;
        if (win.classList.contains('dmd3d-control-window')) {
            prepareAppWindow(win);
            return;
        }
        win.classList.add('dmd3d-mydesk-overlay-window');
    }

    let autoOpenDone = false;
    function autoOpenFirstPrinter() {
        if (autoOpenDone || document.querySelector('.dmd3d-control-window')) return;
        const root = document.querySelector('[data-dmd3d-main]');
        if (!root || root.querySelector('[data-mfa-gate]:not([hidden])')) return;
        const first = root.querySelector('[data-open-printer]');
        if (!first) return;
        autoOpenDone = true;
        first.click();
    }

    function scan() {
        document.querySelectorAll('.dmd3d-window').forEach(prepareOverlayWindow);
        autoOpenFirstPrinter();
    }

    const observer = new MutationObserver(() => scan());
    markHost();
    syncTheme();

    const start = () => {
        markHost();
        scan();
        if (document.body) observer.observe(document.body, {childList:true, subtree:true, attributes:true, attributeFilter:['hidden']});
        // Le bootstrap du module est asynchrone : ces passages couvrent le premier rendu sans imposer de délai fixe au module.
        [60, 180, 450, 900, 1600].forEach(delay => window.setTimeout(scan, delay));
    };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
    else start();

    window.addEventListener('load', () => { syncTheme(); scan(); }, {once:true});
})();
</script>
