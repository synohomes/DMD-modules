<?php
declare(strict_types=1);

require_once __DIR__ . '/dmd-3dprint_lib.php';

dmd3d_require_login();
dmd3d_require_permission('module.view');

function dmd3d_models_json(array $payload, int $status = 200): void
{
    dmd3d_response($payload, $status);
}

function dmd3d_models_abs_url(string $url): string
{
    $url = trim(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    $url = str_replace(['\\u002F', '\\u002f', '\\/'], ['/', '/', '/'], $url);
    if ($url === '' || stripos($url, 'data:') === 0 || stripos($url, 'javascript:') === 0) {
        return '';
    }
    if (preg_match('#^https?://#i', $url) === 1) {
        return $url;
    }
    if (strpos($url, '//') === 0) {
        return 'https:' . $url;
    }
    if (strpos($url, '/media/prints/') === 0) {
        return 'https://media.printables.com' . $url;
    }
    if (isset($url[0]) && $url[0] === '/') {
        return 'https://www.printables.com' . $url;
    }
    return 'https://www.printables.com/' . ltrim($url, '/');
}

function dmd3d_models_srcset_best(string $srcset): string
{
    $parts = preg_split('/\s*,\s*/', trim($srcset)) ?: [];
    $best = '';
    foreach ($parts as $part) {
        $bits = preg_split('/\s+/', trim((string)$part)) ?: [];
        if (!empty($bits[0])) {
            $best = (string)$bits[0];
        }
    }
    return $best;
}

function dmd3d_models_http_get(string $url): string
{
    $headers = [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: fr-FR,fr;q=0.9,en;q=0.7',
        'Cache-Control: no-cache',
    ];

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        if ($ch === false) {
            throw new RuntimeException('Impossible d’initialiser la connexion à Printables.');
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 4,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 22,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING => '',
            CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; DoMyDesk-DMD-3DPRINT/1.2.0)',
            CURLOPT_HTTPHEADER => $headers,
        ]);
        $body = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if (!is_string($body) || $body === '') {
            throw new RuntimeException('Printables est inaccessible' . ($error !== '' ? ' : ' . $error : '.'));
        }
        if ($status === 429 || stripos($body, 'too many requests') !== false) {
            throw new RuntimeException('Printables limite temporairement les recherches. Réessaie plus tard.');
        }
        if ($status < 200 || $status >= 400) {
            throw new RuntimeException('Printables a renvoyé une erreur HTTP ' . $status . '.');
        }
        return $body;
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 22,
            'ignore_errors' => true,
            'header' => implode("\r\n", array_merge($headers, [
                'User-Agent: Mozilla/5.0 (compatible; DoMyDesk-DMD-3DPRINT/1.2.0)',
            ])),
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);
    $body = @file_get_contents($url, false, $context);
    if (!is_string($body) || $body === '') {
        throw new RuntimeException('Printables est inaccessible depuis le serveur DoMyDesk.');
    }
    if (stripos($body, 'too many requests') !== false) {
        throw new RuntimeException('Printables limite temporairement les recherches. Réessaie plus tard.');
    }
    return $body;
}

function dmd3d_models_dom(string $html): array
{
    if (!class_exists('DOMDocument')) {
        throw new RuntimeException('Extension PHP DOM absente : impossible de lire Printables.');
    }
    $previous = libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_NOWARNING | LIBXML_NOERROR);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    if (!$loaded) {
        throw new RuntimeException('Réponse Printables illisible.');
    }
    return [$dom, new DOMXPath($dom)];
}

function dmd3d_models_node_text(?DOMNode $node): string
{
    if (!$node) {
        return '';
    }
    $text = preg_replace('/\s+/u', ' ', trim((string)$node->textContent));
    return trim((string)$text);
}

function dmd3d_models_valid_model_url(string $url): bool
{
    return preg_match('#^https://www\.printables\.com/(?:[a-z]{2}/)?model/\d+(?:[-/]|$)#i', $url) === 1;
}

function dmd3d_models_normalize_model_url(string $url): string
{
    $url = dmd3d_models_abs_url($url);
    $parts = parse_url($url);
    if (!is_array($parts) || strtolower((string)($parts['host'] ?? '')) !== 'www.printables.com') {
        return '';
    }
    $path = (string)($parts['path'] ?? '');
    $path = preg_replace('#/files/?$#i', '', $path) ?: $path;
    $normalized = 'https://www.printables.com' . rtrim($path, '/');
    return dmd3d_models_valid_model_url($normalized) ? $normalized : '';
}

function dmd3d_models_valid_image_url(string $url): bool
{
    $parts = parse_url($url);
    if (!is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https') {
        return false;
    }
    $host = strtolower((string)($parts['host'] ?? ''));
    $path = strtolower((string)($parts['path'] ?? ''));
    if ($host !== 'media.printables.com' && $host !== 'www.printables.com') {
        return false;
    }
    if (strpos($path, '/media/prints/') === false) {
        return false;
    }
    return preg_match('/\.(?:jpe?g|png|webp|avif)(?:$|\?)/i', $url) === 1 || strpos($path, '/thumbs/') !== false;
}

function dmd3d_models_image_from_scope(DOMXPath $xpath, DOMNode $scope): string
{
    $nodes = $xpath->query('.//img|.//source[@srcset]', $scope);
    if (!$nodes) {
        return '';
    }
    foreach ($nodes as $node) {
        if (!($node instanceof DOMElement)) {
            continue;
        }
        $candidates = [];
        $srcset = trim($node->getAttribute('srcset'));
        if ($srcset !== '') {
            $candidates[] = dmd3d_models_srcset_best($srcset);
        }
        foreach (['src', 'data-src', 'data-lazy-src', 'data-original'] as $attribute) {
            $candidate = trim($node->getAttribute($attribute));
            if ($candidate !== '') {
                $candidates[] = $candidate;
            }
        }
        foreach ($candidates as $candidate) {
            $absolute = dmd3d_models_abs_url((string)$candidate);
            if ($absolute !== '' && dmd3d_models_valid_image_url($absolute)) {
                return $absolute;
            }
        }
    }
    return '';
}

function dmd3d_models_card_scope(DOMXPath $xpath, DOMElement $anchor): DOMNode
{
    $current = $anchor->parentNode;
    $fallback = $current ?: $anchor;
    for ($i = 0; $i < 10 && $current; $i++) {
        if ($current instanceof DOMElement) {
            $links = $xpath->query('.//h5/a[contains(@href, "/model/")]', $current);
            $count = $links ? $links->length : 0;
            if ($count === 1) {
                $fallback = $current;
                if (dmd3d_models_image_from_scope($xpath, $current) !== '') {
                    return $current;
                }
            } elseif ($count > 1) {
                break;
            }
        }
        $current = $current->parentNode;
    }
    return $fallback;
}

function dmd3d_models_parse_search(string $html, int $limit): array
{
    [$dom, $xpath] = dmd3d_models_dom($html);
    unset($dom);

    $anchors = $xpath->query('//h5/a[contains(@href, "/model/")]');
    if (!$anchors || $anchors->length === 0) {
        $anchors = $xpath->query('//a[contains(@href, "/model/") and (@title or @aria-label)]');
    }
    if (!$anchors) {
        return [];
    }

    $results = [];
    $seen = [];
    foreach ($anchors as $anchor) {
        if (!($anchor instanceof DOMElement)) {
            continue;
        }
        $url = dmd3d_models_normalize_model_url($anchor->getAttribute('href'));
        if ($url === '' || !preg_match('#/model/(\d+)#i', $url, $match)) {
            continue;
        }
        $id = (string)$match[1];
        if (isset($seen[$id])) {
            continue;
        }

        $title = dmd3d_models_node_text($anchor);
        if ($title === '') {
            $title = trim($anchor->getAttribute('title'));
        }
        if ($title === '') {
            $title = trim($anchor->getAttribute('aria-label'));
        }
        if ($title === '' || preg_match('/^\d+[.,]?\d*[KMB]?$/i', $title) === 1) {
            continue;
        }

        $scope = dmd3d_models_card_scope($xpath, $anchor);
        $image = dmd3d_models_image_from_scope($xpath, $scope);
        $author = '';
        $authorNodes = $xpath->query('.//a[starts-with(@href, "/@")]', $scope);
        if ($authorNodes && $authorNodes->length > 0) {
            $author = dmd3d_models_node_text($authorNodes->item(0));
        }

        $results[] = [
            'id' => $id,
            'title' => $title,
            'author' => $author,
            'url' => $url,
            'image' => $image,
        ];
        $seen[$id] = true;
        if (count($results) >= $limit) {
            break;
        }
    }
    return $results;
}

function dmd3d_models_meta(DOMXPath $xpath, string $property, string $attribute = 'property'): string
{
    $nodes = $xpath->query('//meta[translate(@' . $attribute . ', "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz")="' . strtolower($property) . '"]/@content');
    if (!$nodes || $nodes->length === 0) {
        return '';
    }
    return trim((string)$nodes->item(0)->nodeValue);
}

function dmd3d_models_clean_title(string $title): string
{
    $title = html_entity_decode(trim($title), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $title = preg_replace('/\s*[|–-]\s*(?:Download[^|]+|Printables\.com).*$/iu', '', $title) ?: $title;
    return trim($title);
}

function dmd3d_models_collect_embedded_urls(string $html, string $host): array
{
    $decoded = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $decoded = str_replace(['\\u002F', '\\u002f', '\\u0026', '\\/', '\\"'], ['/', '/', '&', '/', '"'], $decoded);
    $pattern = '#https://' . preg_quote($host, '#') . '/[^\s"\'<>\\]+#i';
    preg_match_all($pattern, $decoded, $matches);
    $urls = [];
    foreach (($matches[0] ?? []) as $url) {
        $url = rtrim((string)$url, '.,;:)]}');
        $url = str_replace('\\u0026', '&', $url);
        if ($url !== '') {
            $urls[] = $url;
        }
    }
    return array_values(array_unique($urls));
}

function dmd3d_models_collect_images(string $html, DOMXPath $xpath, int $limit = 16): array
{
    $images = [];
    $add = function (string $candidate) use (&$images, $limit): void {
        if (count($images) >= $limit) {
            return;
        }
        $url = dmd3d_models_abs_url($candidate);
        if ($url !== '' && dmd3d_models_valid_image_url($url) && !in_array($url, $images, true)) {
            $images[] = $url;
        }
    };

    $add(dmd3d_models_meta($xpath, 'og:image'));
    $nodes = $xpath->query('//main//img|//main//source[@srcset]|//img[contains(@src, "media/prints/")]|//source[contains(@srcset, "media/prints/")]');
    if ($nodes) {
        foreach ($nodes as $node) {
            if (!($node instanceof DOMElement)) {
                continue;
            }
            $srcset = trim($node->getAttribute('srcset'));
            if ($srcset !== '') {
                $add(dmd3d_models_srcset_best($srcset));
            }
            foreach (['src', 'data-src', 'data-lazy-src', 'data-original'] as $attribute) {
                $value = trim($node->getAttribute($attribute));
                if ($value !== '') {
                    $add($value);
                }
            }
            if (count($images) >= $limit) {
                break;
            }
        }
    }
    foreach (dmd3d_models_collect_embedded_urls($html, 'media.printables.com') as $candidate) {
        $add($candidate);
        if (count($images) >= $limit) {
            break;
        }
    }
    return $images;
}

function dmd3d_models_file_extension(string $url): string
{
    $path = (string)(parse_url($url, PHP_URL_PATH) ?: '');
    return strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
}

function dmd3d_models_valid_file_url(string $url): bool
{
    $parts = parse_url($url);
    if (!is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https') {
        return false;
    }
    if (strtolower((string)($parts['host'] ?? '')) !== 'files.printables.com') {
        return false;
    }
    if (strpos((string)($parts['path'] ?? ''), '/media/prints/') !== 0) {
        return false;
    }
    return in_array(dmd3d_models_file_extension($url), [
        'stl', '3mf', 'obj', 'step', 'stp', 'zip', 'scad', 'f3d', 'amf', 'gcode', 'gco', 'gc',
        'blend', 'fcstd', 'iges', 'igs', 'dxf', 'dwg', 'pdf', 'txt', 'svg', 'sla', 'zpr'
    ], true);
}

function dmd3d_models_filename(string $url): string
{
    $path = (string)(parse_url($url, PHP_URL_PATH) ?: '');
    $name = rawurldecode((string)basename($path));
    $name = preg_replace('/[^\pL\pN._()\[\] -]+/u', '_', $name) ?: 'modele-3d';
    return trim($name) !== '' ? trim($name) : 'modele-3d';
}

function dmd3d_models_collect_files(string $html, DOMXPath $xpath): array
{
    $urls = [];
    $anchors = $xpath->query('//a[@href]');
    if ($anchors) {
        foreach ($anchors as $anchor) {
            if (!($anchor instanceof DOMElement)) {
                continue;
            }
            $url = dmd3d_models_abs_url($anchor->getAttribute('href'));
            if ($url !== '' && dmd3d_models_valid_file_url($url)) {
                $urls[] = $url;
            }
        }
    }
    foreach (dmd3d_models_collect_embedded_urls($html, 'files.printables.com') as $candidate) {
        if (dmd3d_models_valid_file_url($candidate)) {
            $urls[] = $candidate;
        }
    }

    $files = [];
    $seen = [];
    foreach ($urls as $url) {
        $key = preg_replace('/[?#].*$/', '', $url) ?: $url;
        if (isset($seen[$key])) {
            continue;
        }
        $files[] = [
            'name' => dmd3d_models_filename($url),
            'extension' => strtoupper(dmd3d_models_file_extension($url)),
            'url' => $url,
        ];
        $seen[$key] = true;
    }
    usort($files, function (array $a, array $b): int {
        $order = ['3MF' => 1, 'STL' => 2, 'STEP' => 3, 'STP' => 4, 'OBJ' => 5, 'ZIP' => 6];
        $left = $order[$a['extension']] ?? 50;
        $right = $order[$b['extension']] ?? 50;
        if ($left === $right) {
            return strcasecmp($a['name'], $b['name']);
        }
        return $left <=> $right;
    });
    return $files;
}

function dmd3d_models_parse_detail(string $modelUrl, string $mainHtml, string $filesHtml): array
{
    [$mainDom, $mainXpath] = dmd3d_models_dom($mainHtml);
    unset($mainDom);
    [$filesDom, $filesXpath] = dmd3d_models_dom($filesHtml !== '' ? $filesHtml : $mainHtml);
    unset($filesDom);

    $title = dmd3d_models_clean_title(dmd3d_models_meta($mainXpath, 'og:title'));
    if ($title === '') {
        $titleNodes = $mainXpath->query('//h1');
        $title = $titleNodes && $titleNodes->length ? dmd3d_models_node_text($titleNodes->item(0)) : 'Modèle 3D';
    }
    $description = dmd3d_models_meta($mainXpath, 'og:description');
    if ($description === '') {
        $description = dmd3d_models_meta($mainXpath, 'description', 'name');
    }
    $author = dmd3d_models_meta($mainXpath, 'author', 'name');
    if ($author === '') {
        $authorNodes = $mainXpath->query('//a[starts-with(@href, "/@")]');
        if ($authorNodes && $authorNodes->length > 0) {
            $author = dmd3d_models_node_text($authorNodes->item(0));
        }
    }

    $images = dmd3d_models_collect_images($mainHtml, $mainXpath, 16);
    $files = dmd3d_models_collect_files($filesHtml !== '' ? $filesHtml : $mainHtml, $filesXpath);
    if (!$files && $filesHtml !== $mainHtml) {
        $files = dmd3d_models_collect_files($mainHtml, $mainXpath);
    }

    return [
        'title' => $title,
        'description' => trim($description),
        'author' => trim($author),
        'url' => $modelUrl,
        'files_url' => $modelUrl . '/files',
        'images' => $images,
        'files' => $files,
    ];
}


function dmd3d_models_sources(): array
{
    $data = dmd3d_read_json(DMD3D_MODEL_SOURCES_FILE, ['version' => 1, 'sources' => []]);
    $sources = [];
    foreach (($data['sources'] ?? []) as $source) {
        if (!is_array($source)) {
            continue;
        }
        $id = strtolower(trim((string)($source['id'] ?? '')));
        $name = trim((string)($source['name'] ?? ''));
        $type = strtolower(trim((string)($source['type'] ?? 'external')));
        $searchUrl = trim((string)($source['search_url'] ?? ''));
        if ($id === '' || $name === '' || $searchUrl === '') {
            continue;
        }
        $sources[] = [
            'id' => $id,
            'name' => $name,
            'type' => $type === 'printables' ? 'printables' : 'external',
            'search_url' => $searchUrl,
            'locked' => !empty($source['locked']),
        ];
    }
    $hasPrintables = false;
    foreach ($sources as $source) {
        if ($source['id'] === 'printables') {
            $hasPrintables = true;
            break;
        }
    }
    if (!$hasPrintables) {
        array_unshift($sources, [
            'id' => 'printables',
            'name' => 'Printables',
            'type' => 'printables',
            'search_url' => 'https://www.printables.com/search/models?q={query}',
            'locked' => true,
        ]);
    }
    return $sources;
}

function dmd3d_models_source(string $id): ?array
{
    $id = strtolower(trim($id));
    foreach (dmd3d_models_sources() as $source) {
        if ($source['id'] === $id) {
            return $source;
        }
    }
    return null;
}

function dmd3d_models_source_url_valid(string $url): bool
{
    $probe = str_replace('{query}', 'test', trim($url));
    $parts = parse_url($probe);
    if (!is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https') {
        return false;
    }
    $host = strtolower(trim((string)($parts['host'] ?? '')));
    if ($host === '' || $host === 'localhost' || $host === '127.0.0.1' || $host === '::1') {
        return false;
    }
    return true;
}

function dmd3d_models_source_search_url(string $url): string
{
    $url = trim($url);
    if (!dmd3d_models_source_url_valid($url)) {
        return '';
    }

    if (strpos($url, '{query}') !== false) {
        return $url;
    }

    $parts = parse_url($url);
    if (!is_array($parts)) {
        return '';
    }

    $host = strtolower(trim((string)($parts['host'] ?? '')));
    $path = '/' . ltrim((string)($parts['path'] ?? ''), '/');
    $path = rtrim($path, '/');

    // URL simple Cults : l’administrateur peut saisir uniquement https://cults3d.com/fr
    // et DoMyDesk construit la route de recherche officielle par mot-clé.
    if ($host === 'cults3d.com' || $host === 'www.cults3d.com') {
        $locale = 'fr';
        if (preg_match('#^/([a-z]{2})(?:/|$)#i', $path, $match) === 1) {
            $locale = strtolower((string)$match[1]);
        }
        return 'https://cults3d.com/' . $locale . '/mot-clefs/{query}';
    }

    // Pour une autre source, une URL avancée avec {query} reste possible.
    // Si seule l’adresse du site est fournie, on utilise une recherche ?q= standard.
    $base = $url;
    $fragmentPos = strpos($base, '#');
    if ($fragmentPos !== false) {
        $base = substr($base, 0, $fragmentPos);
    }
    $separator = strpos($base, '?') === false ? '?' : '&';
    return $base . $separator . 'q={query}';
}

function dmd3d_models_save_sources(array $sources): void
{
    dmd3d_write_json(DMD3D_MODEL_SOURCES_FILE, [
        'version' => 1,
        'sources' => array_values($sources),
    ]);
}

function dmd3d_models_add_source(array $input): array
{
    dmd3d_require_permission('model.install');
    dmd3d_require_csrf($input);

    $name = trim((string)($input['name'] ?? ''));
    $searchUrl = trim((string)($input['search_url'] ?? ''));
    if ($name === '' || strlen($name) > 80) {
        throw new InvalidArgumentException('Nom de source invalide.');
    }
    $searchUrl = dmd3d_models_source_search_url($searchUrl);
    if ($searchUrl === '') {
        throw new InvalidArgumentException('URL de source invalide. Utilise une adresse HTTPS.');
    }
    $id = strtolower($name);
    $id = preg_replace('/[^a-z0-9]+/', '-', $id) ?: '';
    $id = trim($id, '-');
    if ($id === '' || $id === 'printables') {
        $id = 'source-' . substr(bin2hex(random_bytes(4)), 0, 8);
    }

    $sources = dmd3d_models_sources();
    $used = [];
    foreach ($sources as $source) {
        $used[$source['id']] = true;
    }
    $base = $id;
    $n = 2;
    while (isset($used[$id])) {
        $id = $base . '-' . $n;
        $n++;
    }
    $sources[] = [
        'id' => $id,
        'name' => $name,
        'type' => 'external',
        'search_url' => $searchUrl,
        'locked' => false,
    ];
    dmd3d_models_save_sources($sources);
    return $sources;
}

function dmd3d_models_delete_source(array $input): array
{
    dmd3d_require_permission('model.install');
    dmd3d_require_csrf($input);
    $id = strtolower(trim((string)($input['id'] ?? '')));
    if ($id === '' || $id === 'printables') {
        throw new InvalidArgumentException('Cette source ne peut pas être supprimée.');
    }
    $sources = [];
    foreach (dmd3d_models_sources() as $source) {
        if ($source['id'] !== $id || !empty($source['locked'])) {
            $sources[] = $source;
        }
    }
    dmd3d_models_save_sources($sources);
    return $sources;
}

function dmd3d_models_graphql(string $operationName, string $query, array $variables): array
{
    if (!function_exists('curl_init')) {
        throw new RuntimeException('Extension PHP cURL absente : accès API Printables impossible.');
    }
    $payload = json_encode([
        'operationName' => $operationName,
        'query' => $query,
        'variables' => $variables,
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if (!is_string($payload)) {
        throw new RuntimeException('Impossible de préparer la requête Printables.');
    }

    $ch = curl_init('https://api.printables.com/graphql/');
    if ($ch === false) {
        throw new RuntimeException('Impossible d’initialiser la connexion API Printables.');
    }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/151 Safari/537.36',
        CURLOPT_HTTPHEADER => [
            'Accept: application/graphql-response+json, application/graphql+json, application/json',
            'Accept-Language: fr-FR,fr;q=0.9,en;q=0.7',
            'Content-Type: application/json',
            'Origin: https://www.printables.com',
            'Referer: https://www.printables.com/',
            'graphql-client-version: v4.5.0',
        ],
    ]);
    $body = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if (!is_string($body) || $body === '') {
        throw new RuntimeException('API Printables inaccessible' . ($error !== '' ? ' : ' . $error : '.'));
    }
    if ($status < 200 || $status >= 300) {
        throw new RuntimeException('API Printables a renvoyé HTTP ' . $status . '.');
    }
    $decoded = json_decode($body, true);
    if (!is_array($decoded)) {
        throw new RuntimeException('Réponse API Printables illisible.');
    }
    if (!empty($decoded['errors'])) {
        $message = 'Erreur API Printables.';
        if (isset($decoded['errors'][0]['message'])) {
            $message = trim((string)$decoded['errors'][0]['message']);
        }
        throw new RuntimeException($message !== '' ? $message : 'Erreur API Printables.');
    }
    return is_array($decoded['data'] ?? null) ? $decoded['data'] : [];
}

function dmd3d_models_printables_id(string $url): string
{
    $url = dmd3d_models_normalize_model_url($url);
    if ($url === '' || preg_match('#/model/(\d+)#i', $url, $match) !== 1) {
        return '';
    }
    return (string)$match[1];
}

function dmd3d_models_extension_from_name(string $name): string
{
    $ext = strtolower((string)pathinfo($name, PATHINFO_EXTENSION));
    return $ext !== '' ? strtoupper($ext) : 'FICHIER';
}

function dmd3d_models_printables_detail(string $modelUrl, array $fallback = []): array
{
    $modelId = dmd3d_models_printables_id($modelUrl);
    if ($modelId === '') {
        throw new InvalidArgumentException('Modèle Printables invalide.');
    }
    $query = <<<'GQL'
query ModelFiles($id: ID!) {
  model: print(id: $id) {
    id
    name
    slug
    filesType
    gcodes { id name folder note __typename }
    stls { id name folder note __typename }
    slas { id name folder note __typename }
    otherFiles { id name folder note __typename }
    downloadPacks { id name fileSize fileType __typename }
    __typename
  }
}
GQL;
    $data = dmd3d_models_graphql('ModelFiles', $query, ['id' => $modelId]);
    $model = is_array($data['model'] ?? null) ? $data['model'] : [];
    if (!$model) {
        throw new RuntimeException('Modèle Printables introuvable.');
    }

    $files = [];
    $seen = [];
    foreach (['stls', 'gcodes', 'slas', 'otherFiles'] as $group) {
        foreach (($model[$group] ?? []) as $file) {
            if (!is_array($file)) {
                continue;
            }
            $id = trim((string)($file['id'] ?? ''));
            $name = trim((string)($file['name'] ?? ''));
            if ($id === '' || $name === '' || isset($seen[$group . ':' . $id])) {
                continue;
            }
            $files[] = [
                'id' => $id,
                'name' => $name,
                'extension' => dmd3d_models_extension_from_name($name),
                'folder' => trim((string)($file['folder'] ?? '')),
                'note' => trim((string)($file['note'] ?? '')),
                'url' => '',
                'downloadable' => false,
                'kind' => 'file',
            ];
            $seen[$group . ':' . $id] = true;
        }
    }
    foreach (($model['downloadPacks'] ?? []) as $pack) {
        if (!is_array($pack)) {
            continue;
        }
        $id = trim((string)($pack['id'] ?? ''));
        $name = trim((string)($pack['name'] ?? ''));
        if ($id === '') {
            continue;
        }
        $files[] = [
            'id' => $id,
            'name' => $name !== '' ? $name : 'Pack Printables',
            'extension' => 'ZIP',
            'size' => (int)($pack['fileSize'] ?? 0),
            'file_type' => trim((string)($pack['fileType'] ?? '')),
            'url' => '',
            'downloadable' => true,
            'kind' => 'pack',
            'model_id' => $modelId,
        ];
    }

    $images = [];
    $fallbackImage = trim((string)($fallback['image'] ?? ''));
    if ($fallbackImage !== '' && dmd3d_models_valid_image_url($fallbackImage)) {
        $images[] = $fallbackImage;
    }
    $title = trim((string)($model['name'] ?? ''));
    if ($title === '') {
        $title = trim((string)($fallback['title'] ?? 'Modèle 3D'));
    }
    return [
        'id' => $modelId,
        'title' => $title,
        'description' => trim((string)($fallback['description'] ?? '')),
        'author' => trim((string)($fallback['author'] ?? '')),
        'url' => $modelUrl,
        'files_url' => $modelUrl . '/files',
        'images' => $images,
        'files' => $files,
        'source' => 'Printables',
    ];
}

function dmd3d_models_printables_download_pack(string $modelId, string $packId): string
{
    if (!preg_match('/^\d+$/', $modelId) || !preg_match('/^\d+$/', $packId)) {
        throw new InvalidArgumentException('Pack Printables invalide.');
    }
    $query = <<<'GQL'
mutation GetDownloadLink($printId: ID!, $ids: [ID!]!, $ft: DownloadFileTypeEnum!) {
  getDownloadLink(printId: $printId, source: model_detail, files: [{fileType: $ft, ids: $ids}]) {
    ok
    errors { field messages code __typename }
    output { link ttl __typename }
    __typename
  }
}
GQL;
    $data = dmd3d_models_graphql('GetDownloadLink', $query, [
        'printId' => $modelId,
        'ids' => [$packId],
        'ft' => 'pack',
    ]);
    $result = is_array($data['getDownloadLink'] ?? null) ? $data['getDownloadLink'] : [];
    $link = trim((string)($result['output']['link'] ?? ''));
    if (empty($result['ok']) || $link === '') {
        throw new RuntimeException('Printables n’a pas fourni de lien de téléchargement pour ce pack.');
    }
    return $link;
}

function dmd3d_models_stream_remote(string $url, string $fallbackName = 'modele-3d.zip'): void
{
    $parts = parse_url($url);
    $host = strtolower((string)($parts['host'] ?? ''));
    if (!is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https' || ($host !== 'files.printables.com' && !str_ends_with($host, '.printables.com'))) {
        throw new RuntimeException('Lien de téléchargement Printables refusé.');
    }
    if (!function_exists('curl_init')) {
        throw new RuntimeException('Extension PHP cURL absente : téléchargement impossible.');
    }
    $temporary = tempnam(sys_get_temp_dir(), 'dmd3dp_');
    if (!is_string($temporary) || $temporary === '') {
        throw new RuntimeException('Impossible de préparer le téléchargement.');
    }
    $handle = fopen($temporary, 'wb');
    if ($handle === false) {
        @unlink($temporary);
        throw new RuntimeException('Impossible de préparer le fichier temporaire.');
    }
    $ch = curl_init($url);
    if ($ch === false) {
        fclose($handle);
        @unlink($temporary);
        throw new RuntimeException('Impossible d’initialiser le téléchargement.');
    }
    curl_setopt_array($ch, [
        CURLOPT_FILE => $handle,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 4,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 180,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; DoMyDesk-DMD-3DPRINT/1.2.0)',
    ]);
    $ok = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $contentType = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $error = curl_error($ch);
    curl_close($ch);
    fclose($handle);
    $size = (int)@filesize($temporary);
    if ($ok === false || $status < 200 || $status >= 400 || $size <= 0) {
        @unlink($temporary);
        throw new RuntimeException('Téléchargement Printables impossible' . ($error !== '' ? ' : ' . $error : '.'));
    }
    $name = preg_replace('/[^\pL\pN._()\[\] -]+/u', '_', $fallbackName) ?: 'modele-3d.zip';
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: ' . ($contentType !== '' ? $contentType : 'application/zip'));
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename="' . addcslashes($name, '"\\') . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    header('Cache-Control: private, no-store, max-age=0');
    readfile($temporary);
    @unlink($temporary);
    exit;
}

function dmd3d_models_stream_download(string $url): void
{
    if (!dmd3d_models_valid_file_url($url)) {
        throw new InvalidArgumentException('Lien de téléchargement Printables refusé.');
    }
    if (!function_exists('curl_init')) {
        throw new RuntimeException('Extension PHP cURL absente : téléchargement direct impossible sans quitter DoMyDesk.');
    }

    $temporary = tempnam(sys_get_temp_dir(), 'dmd3d_');
    if (!is_string($temporary) || $temporary === '') {
        throw new RuntimeException('Impossible de préparer le téléchargement.');
    }
    $handle = fopen($temporary, 'wb');
    if ($handle === false) {
        @unlink($temporary);
        throw new RuntimeException('Impossible de préparer le fichier temporaire.');
    }

    $tooLarge = false;
    $ch = curl_init($url);
    if ($ch === false) {
        fclose($handle);
        @unlink($temporary);
        throw new RuntimeException('Impossible d’initialiser le téléchargement.');
    }
    curl_setopt_array($ch, [
        CURLOPT_FILE => $handle,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 4,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 180,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_ENCODING => '',
        CURLOPT_USERAGENT => 'Mozilla/5.0 (compatible; DoMyDesk-DMD-3DPRINT/1.2.0)',
        CURLOPT_HEADERFUNCTION => function ($curl, string $line) use (&$tooLarge): int {
            if (stripos($line, 'Content-Length:') === 0) {
                $length = (int)trim(substr($line, 15));
                if ($length > 300 * 1024 * 1024) {
                    $tooLarge = true;
                    return 0;
                }
            }
            return strlen($line);
        },
    ]);
    $ok = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $contentType = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $error = curl_error($ch);
    curl_close($ch);
    fclose($handle);

    $size = (int)@filesize($temporary);
    if ($tooLarge || $size > 300 * 1024 * 1024) {
        @unlink($temporary);
        throw new RuntimeException('Ce fichier dépasse la limite de téléchargement de 300 Mo.');
    }
    if ($ok === false || $status < 200 || $status >= 400 || $size <= 0) {
        @unlink($temporary);
        throw new RuntimeException('Téléchargement Printables impossible' . ($error !== '' ? ' : ' . $error : '.'));
    }

    $filename = dmd3d_models_filename($url);
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: ' . ($contentType !== '' ? $contentType : 'application/octet-stream'));
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename="' . addcslashes($filename, '"\\') . '"; filename*=UTF-8\'\'' . rawurlencode($filename));
    header('Cache-Control: private, no-store, max-age=0');
    readfile($temporary);
    @unlink($temporary);
    exit;
}

try {
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    $action = trim((string)($_GET['action'] ?? ($_POST['action'] ?? 'search')));

    if ($method === 'POST') {
        $input = dmd3d_input();
        $action = trim((string)($input['action'] ?? $action));
        if ($action === 'source_add') {
            dmd3d_models_json(['ok' => true, 'sources' => dmd3d_models_add_source($input)]);
        }
        if ($action === 'source_delete') {
            dmd3d_models_json(['ok' => true, 'sources' => dmd3d_models_delete_source($input)]);
        }
        dmd3d_models_json(['ok' => false, 'message' => 'Action refusée.'], 405);
    }

    if ($method !== 'GET') {
        dmd3d_models_json(['ok' => false, 'message' => 'Méthode HTTP refusée.'], 405);
    }

    if ($action === 'sources') {
        dmd3d_models_json([
            'ok' => true,
            'sources' => dmd3d_models_sources(),
            'can_manage' => dmd3d_has_permission('model.install'),
            'csrf' => dmd3d_has_permission('model.install') ? dmd3d_csrf_token() : '',
        ]);
    }

    if ($action === 'download') {
        dmd3d_models_stream_download(trim((string)($_GET['url'] ?? '')));
    }
    if ($action === 'download_pack') {
        $modelId = trim((string)($_GET['model_id'] ?? ''));
        $packId = trim((string)($_GET['pack_id'] ?? ''));
        $name = trim((string)($_GET['name'] ?? 'modele-3d.zip'));
        $signed = dmd3d_models_printables_download_pack($modelId, $packId);
        dmd3d_models_stream_remote($signed, $name !== '' ? $name : 'modele-3d.zip');
    }

    $sourceId = strtolower(trim((string)($_GET['source'] ?? 'printables')));
    $source = dmd3d_models_source($sourceId);
    if (!$source) {
        throw new InvalidArgumentException('Source de modèles inconnue.');
    }

    if ($action === 'detail') {
        if ($source['type'] !== 'printables') {
            throw new InvalidArgumentException('Cette source s’ouvre directement sur son site.');
        }
        $modelUrl = dmd3d_models_normalize_model_url(trim((string)($_GET['url'] ?? '')));
        if ($modelUrl === '') {
            throw new InvalidArgumentException('Modèle Printables invalide.');
        }
        $fallback = [
            'title' => trim((string)($_GET['title'] ?? '')),
            'author' => trim((string)($_GET['author'] ?? '')),
            'image' => trim((string)($_GET['image'] ?? '')),
        ];
        dmd3d_models_json([
            'ok' => true,
            'model' => dmd3d_models_printables_detail($modelUrl, $fallback),
        ]);
    }

    $query = trim((string)($_GET['q'] ?? ''));
    if ($query === '') {
        dmd3d_models_json(['ok' => true, 'query' => '', 'source' => $source['name'], 'models' => []]);
    }
    $queryLength = function_exists('mb_strlen') ? mb_strlen($query, 'UTF-8') : strlen($query);
    if ($queryLength > 100) {
        throw new InvalidArgumentException('Recherche trop longue.');
    }

    if ($source['type'] === 'external') {
        $sourceUrl = str_replace('{query}', rawurlencode($query), (string)$source['search_url']);
        dmd3d_models_json([
            'ok' => true,
            'query' => $query,
            'source' => $source['name'],
            'source_id' => $source['id'],
            'external_url' => $sourceUrl,
            'models' => [],
        ]);
    }

    $sourceUrl = 'https://www.printables.com/search/models?q=' . rawurlencode($query);
    $html = dmd3d_models_http_get($sourceUrl);
    dmd3d_models_json([
        'ok' => true,
        'query' => $query,
        'source' => 'Printables',
        'source_id' => 'printables',
        'source_url' => $sourceUrl,
        'models' => dmd3d_models_parse_search($html, 30),
    ]);
} catch (InvalidArgumentException $error) {
    dmd3d_models_json(['ok' => false, 'message' => $error->getMessage()], 422);
} catch (RuntimeException $error) {
    dmd3d_models_json(['ok' => false, 'message' => $error->getMessage()], 409);
} catch (Throwable $error) {
    error_log('[DMD-3DPRINT MODELS] ' . $error->getMessage());
    dmd3d_models_json(['ok' => false, 'message' => 'Erreur interne du navigateur de modèles.'], 500);
}
