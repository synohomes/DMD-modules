<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!function_exists('dmdtk_root')) {
    function dmdtk_root() {
        return dirname(__DIR__, 2);
    }
}

$__dmdtkPermissions = dmdtk_root() . '/core/dmd_permissions.php';
$__dmdtkSystem = dmdtk_root() . '/core/dmd_system_services.php';
if (is_file($__dmdtkPermissions)) require_once $__dmdtkPermissions;
if (is_file($__dmdtkSystem)) require_once $__dmdtkSystem;
unset($__dmdtkPermissions, $__dmdtkSystem);

if (!function_exists('dmdtk_module_id')) {
    function dmdtk_module_id() { return 'dmd-ticketing'; }
}

if (!function_exists('dmdtk_now')) {
    function dmdtk_now() { return date('c'); }
}

if (!function_exists('dmdtk_user_email')) {
    function dmdtk_user_email() {
        return trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : ''));
    }
}

if (!function_exists('dmdtk_profile')) {
    function dmdtk_profile($email) {
        $email = trim((string)$email);
        if ($email === '') return array();
        if (function_exists('dmd_read_profile')) {
            $p = dmd_read_profile($email);
            if (is_array($p)) return $p;
        }
        $file = dmdtk_root() . '/users/profiles/' . $email . '/profile/profile.json';
        if (!is_file($file)) $file = dmdtk_root() . '/users/profiles/' . $email . '/profile.json';
        return dmdtk_read_json($file, array());
    }
}

if (!function_exists('dmdtk_system_role')) {
    function dmdtk_system_role($email) {
        $p = dmdtk_profile($email);
        return strtolower(trim((string)(isset($p['role_system']) ? $p['role_system'] : (isset($_SESSION['user']['role_system']) ? $_SESSION['user']['role_system'] : 'user'))));
    }
}

if (!function_exists('dmdtk_is_admin')) {
    function dmdtk_is_admin($email) {
        return in_array(dmdtk_system_role($email), array('admin', 'superadmin', 'administrator'), true);
    }
}

if (!function_exists('dmdtk_has_module_access')) {
    function dmdtk_has_module_access($email) {
        $email = trim((string)$email);
        if ($email === '') return false;
        if (function_exists('dmd_user_can_use_module')) {
            return (bool)dmd_user_can_use_module($email, dmdtk_module_id());
        }
        return true;
    }
}

if (!function_exists('dmdtk_user_can')) {
    function dmdtk_user_can($email, $capability) {
        $email = trim((string)$email);
        $capability = trim((string)$capability);
        if ($email === '' || $capability === '' || !dmdtk_has_module_access($email)) return false;

        if (function_exists('dmd_user_can_module_capability')) {
            return (bool)dmd_user_can_module_capability($email, dmdtk_module_id(), $capability);
        }
        if (function_exists('dmd_user_can_module_action')) {
            return (bool)dmd_user_can_module_action($email, dmdtk_module_id(), $capability);
        }
        if (dmdtk_is_admin($email)) return true;

        return in_array($capability, array(
            'view', 'ticket.create', 'ticket.reply', 'ticket.status', 'ticket.share',
            'ticket.delete_own', 'ticket.sync', 'attachment.upload'
        ), true);
    }
}

if (!function_exists('dmdtk_protect_dir')) {
    function dmdtk_protect_dir($dir) {
        if (!is_dir($dir)) return;
        $file = rtrim((string)$dir, '/\\') . '/.htaccess';
        if (!is_file($file)) {
            @file_put_contents($file, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
            @chmod($file, 0640);
        }
    }
}

if (!function_exists('dmdtk_system_root')) {
    function dmdtk_system_root($create) {
        $dir = dmdtk_root() . '/data/modules/' . dmdtk_module_id();
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}

if (!function_exists('dmdtk_profiles_root')) {
    function dmdtk_profiles_root() {
        return dmdtk_root() . '/users/profiles';
    }
}

if (!function_exists('dmdtk_user_root')) {
    function dmdtk_user_root($email, $create) {
        $email = trim((string)$email);
        if ($email === '' || strpos($email, '/') !== false || strpos($email, '\\') !== false || strpos($email, "\0") !== false) return '';
        $profile = dmdtk_profiles_root() . '/' . $email;
        if (!is_dir($profile)) return '';
        $dir = $profile . '/' . dmdtk_module_id();
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}

if (!function_exists('dmdtk_ticket_dir')) {
    function dmdtk_ticket_dir($email, $create) {
        $root = dmdtk_user_root($email, $create);
        if ($root === '') return '';
        $dir = $root . '/tickets';
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) @chmod($dir, 0750);
        return $dir;
    }
}

if (!function_exists('dmdtk_files_dir')) {
    function dmdtk_files_dir($email, $ticketId, $create) {
        $root = dmdtk_user_root($email, $create);
        if ($root === '') return '';
        $base = $root . '/files';
        if ($create && !is_dir($base)) @mkdir($base, 0750, true);
        $ticketId = preg_replace('~[^A-Za-z0-9._-]+~', '_', (string)$ticketId);
        if ($ticketId === '') return '';
        $dir = $base . '/' . $ticketId;
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) @chmod($dir, 0750);
        return $dir;
    }
}

if (!function_exists('dmdtk_config_file')) {
    function dmdtk_config_file() { return dmdtk_system_root(true) . '/config.json'; }
}
if (!function_exists('dmdtk_index_file')) {
    function dmdtk_index_file() { return dmdtk_system_root(true) . '/index.json'; }
}
if (!function_exists('dmdtk_outbox_file')) {
    function dmdtk_outbox_file() { return dmdtk_system_root(true) . '/outbox.json'; }
}
if (!function_exists('dmdtk_migration_file')) {
    function dmdtk_migration_file() { return dmdtk_system_root(true) . '/migration_legacy_ticketing.json'; }
}

if (!function_exists('dmdtk_read_json')) {
    function dmdtk_read_json($file, $fallback) {
        if (!is_file($file)) return $fallback;
        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') return $fallback;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $fallback;
    }
}

if (!function_exists('dmdtk_write_json')) {
    function dmdtk_write_json($file, $data) {
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;
        $tmp = $file . '.tmp-' . getmypid() . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
        @chmod($file, 0640);
        return true;
    }
}

if (!function_exists('dmdtk_default_config')) {
    function dmdtk_default_config() {
        return array(
            'categories' => array('Support', 'Bug', 'Amélioration', 'Demande', 'Incident'),
            'priorities' => array('Basse', 'Normale', 'Haute', 'Urgente')
        );
    }
}

if (!function_exists('dmdtk_config')) {
    function dmdtk_config() {
        $d = dmdtk_read_json(dmdtk_config_file(), array());
        $def = dmdtk_default_config();
        return array(
            'categories' => !empty($d['categories']) && is_array($d['categories']) ? array_values($d['categories']) : $def['categories'],
            'priorities' => !empty($d['priorities']) && is_array($d['priorities']) ? array_values($d['priorities']) : $def['priorities'],
            'updated_at' => isset($d['updated_at']) ? $d['updated_at'] : '',
            'updated_by' => isset($d['updated_by']) ? $d['updated_by'] : ''
        );
    }
}

if (!function_exists('dmdtk_index')) {
    function dmdtk_index() {
        $index = dmdtk_read_json(dmdtk_index_file(), array());
        return is_array($index) ? $index : array();
    }
}

if (!function_exists('dmdtk_ticket_summary_index')) {
    function dmdtk_ticket_summary_index($ticket) {
        $share = isset($ticket['share']) && is_array($ticket['share']) ? $ticket['share'] : array();
        return array(
            'owner' => (string)(isset($ticket['owner']) ? $ticket['owner'] : ''),
            'status' => (string)(isset($ticket['status']) ? $ticket['status'] : 'open'),
            'share' => array(
                'all' => !empty($share['all']),
                'users' => isset($share['users']) && is_array($share['users']) ? array_values($share['users']) : array(),
                'roles' => isset($share['roles']) && is_array($share['roles']) ? array_values($share['roles']) : array()
            ),
            'updated_at' => (string)(isset($ticket['updated_at']) ? $ticket['updated_at'] : ''),
            'created_at' => (string)(isset($ticket['created_at']) ? $ticket['created_at'] : ''),
            'domyco_requested' => !empty($ticket['send_to_domydesk']) || !empty($ticket['meta']['domydesk']['requested'])
        );
    }
}

if (!function_exists('dmdtk_index_mutate')) {
    function dmdtk_index_mutate($callback) {
        $lockFile = dmdtk_system_root(true) . '/index.lock';
        $fh = @fopen($lockFile, 'c+');
        if (!$fh) return false;
        $ok = false;
        if (@flock($fh, LOCK_EX)) {
            $index = dmdtk_read_json(dmdtk_index_file(), array());
            if (!is_array($index)) $index = array();
            $result = call_user_func($callback, $index);
            if (is_array($result)) $index = $result;
            $ok = dmdtk_write_json(dmdtk_index_file(), $index);
            @flock($fh, LOCK_UN);
        }
        @fclose($fh);
        @chmod($lockFile, 0640);
        return $ok;
    }
}

if (!function_exists('dmdtk_index_ticket')) {
    function dmdtk_index_ticket($ticket) {
        if (!is_array($ticket) || empty($ticket['id']) || empty($ticket['owner'])) return false;
        $id = (string)$ticket['id'];
        $entry = dmdtk_ticket_summary_index($ticket);
        return dmdtk_index_mutate(function($index) use ($id, $entry) {
            $index[$id] = $entry;
            return $index;
        });
    }
}

if (!function_exists('dmdtk_unindex_ticket')) {
    function dmdtk_unindex_ticket($id) {
        $id = (string)$id;
        return dmdtk_index_mutate(function($index) use ($id) {
            unset($index[$id]);
            return $index;
        });
    }
}

if (!function_exists('dmdtk_ticket_path')) {
    function dmdtk_ticket_path($id) {
        $id = preg_replace('~[^A-Za-z0-9._-]+~', '', (string)$id);
        if ($id === '') return array('', '');
        $index = dmdtk_index();
        $entry = isset($index[$id]) && is_array($index[$id]) ? $index[$id] : array();
        $owner = trim((string)(isset($entry['owner']) ? $entry['owner'] : ''));
        if ($owner !== '') {
            $dir = dmdtk_ticket_dir($owner, false);
            $path = $dir !== '' ? $dir . '/' . $id . '.json' : '';
            if ($path !== '' && is_file($path)) return array($path, $owner);
        }
        return array('', '');
    }
}

if (!function_exists('dmdtk_ticket_read')) {
    function dmdtk_ticket_read($id) {
        list($path, $owner) = dmdtk_ticket_path($id);
        if ($path === '') return array(null, '', '');
        $ticket = dmdtk_read_json($path, array());
        return array($ticket, $path, $owner);
    }
}

if (!function_exists('dmdtk_ticket_write')) {
    function dmdtk_ticket_write($ticket) {
        if (!is_array($ticket) || empty($ticket['id']) || empty($ticket['owner'])) return false;
        $dir = dmdtk_ticket_dir((string)$ticket['owner'], true);
        if ($dir === '') return false;
        $file = $dir . '/' . preg_replace('~[^A-Za-z0-9._-]+~', '', (string)$ticket['id']) . '.json';
        if (!dmdtk_write_json($file, $ticket)) return false;
        return dmdtk_index_ticket($ticket);
    }
}

if (!function_exists('dmdtk_remove_tree')) {
    function dmdtk_remove_tree($dir) {
        if (!is_dir($dir)) return true;
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($it as $item) {
            $path = $item->getPathname();
            if ($item->isDir()) @rmdir($path); else @unlink($path);
        }
        return @rmdir($dir);
    }
}

if (!function_exists('dmdtk_delete_local_ticket')) {
    function dmdtk_delete_local_ticket($ticket) {
        if (!is_array($ticket) || empty($ticket['id']) || empty($ticket['owner'])) return false;
        $dir = dmdtk_ticket_dir((string)$ticket['owner'], false);
        $file = $dir !== '' ? $dir . '/' . preg_replace('~[^A-Za-z0-9._-]+~', '', (string)$ticket['id']) . '.json' : '';
        if ($file !== '' && is_file($file)) @unlink($file);
        $files = dmdtk_files_dir((string)$ticket['owner'], (string)$ticket['id'], false);
        if ($files !== '') dmdtk_remove_tree($files);
        dmdtk_unindex_ticket((string)$ticket['id']);
        return true;
    }
}

if (!function_exists('dmdtk_user_role_metier')) {
    function dmdtk_user_role_metier($email) {
        $p = dmdtk_profile($email);
        return trim((string)(isset($p['role_metier']) ? $p['role_metier'] : ''));
    }
}

if (!function_exists('dmdtk_can_access_ticket')) {
    function dmdtk_can_access_ticket($ticket, $email) {
        if (!is_array($ticket) || $email === '' || !dmdtk_user_can($email, 'view')) return false;
        if (dmdtk_is_admin($email) && dmdtk_user_can($email, 'admin.view_all')) return true;
        if ((string)(isset($ticket['owner']) ? $ticket['owner'] : '') === $email) return true;
        $share = isset($ticket['share']) && is_array($ticket['share']) ? $ticket['share'] : array();
        if (!empty($share['all'])) return true;
        if (isset($share['users']) && is_array($share['users']) && in_array($email, $share['users'], true)) return true;
        $role = dmdtk_user_role_metier($email);
        return $role !== '' && isset($share['roles']) && is_array($share['roles']) && in_array($role, $share['roles'], true);
    }
}

if (!function_exists('dmdtk_can_manage_ticket')) {
    function dmdtk_can_manage_ticket($ticket, $email) {
        if (!is_array($ticket)) return false;
        if ((string)(isset($ticket['owner']) ? $ticket['owner'] : '') === $email) return true;
        return dmdtk_is_admin($email) && dmdtk_user_can($email, 'admin.edit_any');
    }
}

if (!function_exists('dmdtk_can_delete_ticket')) {
    function dmdtk_can_delete_ticket($ticket, $email) {
        if (!is_array($ticket)) return false;
        if ((string)(isset($ticket['owner']) ? $ticket['owner'] : '') === $email) return dmdtk_user_can($email, 'ticket.delete_own');
        return dmdtk_is_admin($email) && dmdtk_user_can($email, 'admin.delete_any');
    }
}

if (!function_exists('dmdtk_csrf_token')) {
    function dmdtk_csrf_token() {
        if (empty($_SESSION['csrf_dmd_ticketing'])) $_SESSION['csrf_dmd_ticketing'] = bin2hex(random_bytes(32));
        return (string)$_SESSION['csrf_dmd_ticketing'];
    }
}

if (!function_exists('dmdtk_csrf_valid')) {
    function dmdtk_csrf_valid($token) {
        $stored = isset($_SESSION['csrf_dmd_ticketing']) ? (string)$_SESSION['csrf_dmd_ticketing'] : '';
        return $stored !== '' && is_string($token) && hash_equals($stored, $token);
    }
}

if (!function_exists('dmdtk_log')) {
    function dmdtk_log($email, $action, $target, $status, $details) {
        $root = dmdtk_root() . '/users/profiles/' . $email . '/logs/' . dmdtk_module_id();
        if (!is_dir($root)) @mkdir($root, 0750, true);
        if (is_dir($root)) { @chmod($root, 0750); dmdtk_protect_dir($root); }
        $file = $root . '/' . date('Y-m-d') . '.json';
        $lock = $root . '/log.lock';
        $fh = @fopen($lock, 'c+');
        if (!$fh) return;
        if (@flock($fh, LOCK_EX)) {
            $rows = dmdtk_read_json($file, array());
            if (!is_array($rows)) $rows = array();
            $rows[] = array(
                'at' => dmdtk_now(),
                'module' => dmdtk_module_id(),
                'email' => $email,
                'action' => (string)$action,
                'target' => (string)$target,
                'status' => (string)$status,
                'details' => is_array($details) ? $details : array('message' => (string)$details),
                'ip' => isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : ''
            );
            if (count($rows) > 2000) $rows = array_slice($rows, -2000);
            dmdtk_write_json($file, $rows);
            @flock($fh, LOCK_UN);
        }
        @fclose($fh);
        @chmod($lock, 0640);
    }
}

if (!function_exists('dmdtk_file_url')) {
    function dmdtk_file_url($ticketId, $storedName) {
        return 'modules/' . dmdtk_module_id() . '/ticketing_file.php?id=' . rawurlencode((string)$ticketId) . '&file=' . rawurlencode((string)$storedName);
    }
}

if (!function_exists('dmdtk_rewrite_legacy_attachments')) {
    function dmdtk_rewrite_legacy_attachments(&$ticket, $legacyFilesDir, $newFilesDir) {
        if (!isset($ticket['messages']) || !is_array($ticket['messages'])) return;
        foreach ($ticket['messages'] as &$message) {
            if (!is_array($message) || !isset($message['attachments']) || !is_array($message['attachments'])) continue;
            foreach ($message['attachments'] as &$attachment) {
                if (!is_array($attachment)) continue;
                $url = (string)(isset($attachment['local_url']) ? $attachment['local_url'] : (isset($attachment['url']) ? $attachment['url'] : ''));
                $path = (string)(parse_url($url, PHP_URL_PATH));
                $stored = basename(rawurldecode($path));
                if ($stored === '' || $stored === '.' || $stored === '..') continue;
                $legacy = rtrim($legacyFilesDir, '/\\') . '/' . $stored;
                $target = rtrim($newFilesDir, '/\\') . '/' . $stored;
                if (is_file($legacy) && !is_file($target)) {
                    @copy($legacy, $target);
                    @chmod($target, 0640);
                }
                if (is_file($target)) {
                    $attachment['stored_name'] = $stored;
                    $attachment['local_url'] = dmdtk_file_url((string)$ticket['id'], $stored);
                    if (empty($attachment['central_url']) && (($attachment['stored_on'] ?? '') !== 'domycocenter')) {
                        $attachment['url'] = $attachment['local_url'];
                        $attachment['stored_on'] = 'domydesk';
                    }
                }
            }
            unset($attachment);
        }
        unset($message);
    }
}

if (!function_exists('dmdtk_migrate_legacy')) {
    function dmdtk_migrate_legacy() {
        $marker = dmdtk_migration_file();
        if (is_file($marker)) return dmdtk_read_json($marker, array('done' => true));

        $legacyRoot = dmdtk_root() . '/modules/ticketing';
        $report = array('done' => true, 'at' => dmdtk_now(), 'source' => $legacyRoot, 'config' => false, 'outbox' => false, 'tickets' => 0, 'errors' => array());
        if (!is_dir($legacyRoot)) {
            dmdtk_write_json($marker, $report);
            return $report;
        }

        $legacyConfig = $legacyRoot . '/config.json';
        if (is_file($legacyConfig) && !is_file(dmdtk_config_file())) {
            $cfg = dmdtk_read_json($legacyConfig, array());
            if ($cfg && dmdtk_write_json(dmdtk_config_file(), $cfg)) $report['config'] = true;
        }
        $legacyOutbox = $legacyRoot . '/domydesk_outbox.json';
        if (is_file($legacyOutbox) && !is_file(dmdtk_outbox_file())) {
            $queue = dmdtk_read_json($legacyOutbox, array());
            if (dmdtk_write_json(dmdtk_outbox_file(), $queue)) $report['outbox'] = true;
        }

        $legacyTickets = $legacyRoot . '/tickets';
        if (is_dir($legacyTickets)) {
            foreach ((array)@scandir($legacyTickets) as $ownerFolder) {
                if ($ownerFolder === '.' || $ownerFolder === '..' || $ownerFolder === '' || $ownerFolder[0] === '.') continue;
                $ownerDir = $legacyTickets . '/' . $ownerFolder;
                if (!is_dir($ownerDir)) continue;
                foreach ((array)glob($ownerDir . '/*.json') as $file) {
                    $ticket = dmdtk_read_json($file, array());
                    if (!$ticket || empty($ticket['id']) || empty($ticket['owner'])) continue;
                    $owner = (string)$ticket['owner'];
                    $newFiles = dmdtk_files_dir($owner, (string)$ticket['id'], true);
                    $legacyFiles = $ownerDir . '/files/' . (string)$ticket['id'];
                    if ($newFiles !== '') dmdtk_rewrite_legacy_attachments($ticket, $legacyFiles, $newFiles);
                    if (dmdtk_ticket_write($ticket)) $report['tickets']++;
                    else $report['errors'][] = 'Impossible de migrer ' . (string)$ticket['id'];
                }
            }
        }

        dmdtk_write_json($marker, $report);
        return $report;
    }
}

/* Initialise les espaces nécessaires, puis migre l'ancien module si présent. */
dmdtk_system_root(true);
if (!is_file(dmdtk_index_file())) dmdtk_write_json(dmdtk_index_file(), array());
dmdtk_migrate_legacy();
if (!is_file(dmdtk_outbox_file())) dmdtk_write_json(dmdtk_outbox_file(), array());
