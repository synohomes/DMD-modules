<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!function_exists('dmdtk_root')) {
    function dmdtk_root() {
        return dirname(__DIR__, 2);
    }
}

$__dmdtkPermissions = dmdtk_root() . '/core/dmd_permissions.php';
$__dmdtkSystem = dmdtk_root() . '/core/dmd_system_services.php';
$__dmdtkQuickSession = dmdtk_root() . '/core/dmd_quick_session.php';
$__dmdtkLicense = dmdtk_root() . '/core/dmd_license.php';
if (is_file($__dmdtkPermissions)) require_once $__dmdtkPermissions;
if (is_file($__dmdtkSystem)) require_once $__dmdtkSystem;
if (is_file($__dmdtkQuickSession)) require_once $__dmdtkQuickSession;
if (is_file($__dmdtkLicense)) require_once $__dmdtkLicense;
unset($__dmdtkPermissions, $__dmdtkSystem, $__dmdtkQuickSession, $__dmdtkLicense);

if (!function_exists('dmdtk_external_license_status')) {
    /**
     * Licence du rôle RECEPTEUR DMD-Ticketing.
     *
     * Jusqu'au 01/01/2027, la réception Support bénéficie d'une licence
     * de lancement indépendante des autres licences éventuellement installées.
     * Ainsi une licence Remote/MyDesk n'annule jamais la période de test Ticketing.
     */
    function dmdtk_external_license_status() {
        if (!function_exists('dmd_license_status')) {
            return array('enabled'=>false, 'state'=>'license_system_unavailable', 'license_id'=>'', 'clients_max'=>0, 'launch'=>false);
        }
        $status = dmd_license_status();
        $entitlements = isset($status['entitlements']) && is_array($status['entitlements']) ? $status['entitlements'] : array();
        $entitlement = isset($entitlements['dmd_ticketing_external']) && is_array($entitlements['dmd_ticketing_external']) ? $entitlements['dmd_ticketing_external'] : array();
        $state = (string)($status['state'] ?? 'invalid');
        $source = (string)($status['source'] ?? '');
        $isSigned = !empty($status['ok'])
            && !empty($status['verified'])
            && $source === 'file'
            && in_array($state, array('active','grace'), true)
            && (($entitlement['enabled'] ?? false) === true);
        $launchUntil = defined('DMD_LICENSE_LAUNCH_UNTIL') ? strtotime(DMD_LICENSE_LAUNCH_UNTIL) : strtotime('2027-01-01T00:00:00Z');
        $launchActive = $launchUntil !== false && time() < $launchUntil;
        $enabled = $isSigned || $launchActive;
        if ($isSigned) {
            $clientsMax = array_key_exists('clients_max', $entitlement) ? (int)$entitlement['clients_max'] : ($launchActive ? (defined('DMD_LICENSE_LAUNCH_TICKETING_CLIENTS_MAX') ? (int)DMD_LICENSE_LAUNCH_TICKETING_CLIENTS_MAX : 5) : -1);
        } else {
            $clientsMax = $launchActive ? (defined('DMD_LICENSE_LAUNCH_TICKETING_CLIENTS_MAX') ? (int)DMD_LICENSE_LAUNCH_TICKETING_CLIENTS_MAX : 5) : 0;
        }
        return array(
            'enabled' => $enabled,
            'state' => $isSigned ? $state : ($launchActive ? 'launch' : $state),
            'verified' => $isSigned,
            'source' => $isSigned ? 'file' : ($launchActive ? 'launch' : $source),
            'launch' => !$isSigned && $launchActive,
            'launch_available' => $launchActive,
            'license_id' => $isSigned ? (string)($status['license_id'] ?? '') : ($launchActive ? 'DMD-TICKETING-LAUNCH-2026' : ''),
            'valid_until' => $isSigned ? (string)($status['valid_until'] ?? '') : ($launchActive ? (defined('DMD_LICENSE_LAUNCH_UNTIL') ? DMD_LICENSE_LAUNCH_UNTIL : '2027-01-01T00:00:00Z') : ''),
            'grace_until' => $isSigned ? (string)($status['grace_until'] ?? '') : '',
            'clients_max' => $clientsMax
        );
    }
}
if (!function_exists('dmdtk_external_license_enabled')) {
    function dmdtk_external_license_enabled() {
        $s = dmdtk_external_license_status();
        return !empty($s['enabled']);
    }
}
if (!function_exists('dmdtk_external_clients_max')) {
    function dmdtk_external_clients_max() {
        $s = dmdtk_external_license_status();
        return !empty($s['enabled']) ? (int)($s['clients_max'] ?? 0) : 0;
    }
}

if (!function_exists('dmdtk_module_id')) {
    function dmdtk_module_id() { return 'dmd-ticketing'; }
}

if (!function_exists('dmdtk_now')) {
    function dmdtk_now() { return date('c'); }
}

if (!function_exists('dmdtk_user_email')) {
    function dmdtk_user_email() {
        return trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : ''));
    }
}

if (!function_exists('dmdtk_profile')) {
    function dmdtk_profile($email) {
        $email = trim((string)$email);
        if ($email === '') return array();
        if (function_exists('dmd_read_profile')) {
            $p = dmd_read_profile($email);
            if (is_array($p)) return $p;
        }
        $file = dmdtk_root() . '/users/profiles/' . $email . '/profile/profile.json';
        if (!is_file($file)) $file = dmdtk_root() . '/users/profiles/' . $email . '/profile.json';
        return dmdtk_read_json($file, array());
    }
}

if (!function_exists('dmdtk_system_role')) {
    function dmdtk_system_role($email) {
        $p = dmdtk_profile($email);
        return strtolower(trim((string)(isset($p['role_system']) ? $p['role_system'] : (isset($_SESSION['user']['role_system']) ? $_SESSION['user']['role_system'] : 'user'))));
    }
}

if (!function_exists('dmdtk_is_admin')) {
    function dmdtk_is_admin($email) {
        return in_array(dmdtk_system_role($email), array('admin', 'superadmin', 'administrator'), true);
    }
}

if (!function_exists('dmdtk_has_module_access')) {
    function dmdtk_has_module_access($email) {
        $email = trim((string)$email);
        if ($email === '') return false;
        if (function_exists('dmd_user_can_use_module')) {
            return (bool)dmd_user_can_use_module($email, dmdtk_module_id());
        }
        return true;
    }
}

if (!function_exists('dmdtk_user_can')) {
    function dmdtk_user_can($email, $capability) {
        $email = trim((string)$email);
        $capability = trim((string)$capability);
        if ($email === '' || $capability === '' || !dmdtk_has_module_access($email)) return false;

        /*
         * DoMyDesk 1.2.0 : moteur officiel des droits fins.
         * C'est cette fonction qui lit réellement :
         * - les droits du rôle métier ;
         * - les exceptions individuelles ;
         * - les permissions "*";
         * - les comptes Admin / Superadmin.
         *
         * Les deux noms historiques ci-dessous ne sont conservés qu'en
         * compatibilité avec d'anciennes branches de DoMyDesk.
         */
        if (function_exists('dmd_user_has_module_permission')) {
            return (bool)dmd_user_has_module_permission($email, dmdtk_module_id(), $capability);
        }
        if (function_exists('dmd_user_can_module_capability')) {
            return (bool)dmd_user_can_module_capability($email, dmdtk_module_id(), $capability);
        }
        if (function_exists('dmd_user_can_module_action')) {
            return (bool)dmd_user_can_module_action($email, dmdtk_module_id(), $capability);
        }

        /* Compatibilité de secours uniquement pour un ancien Core. */
        if (dmdtk_is_admin($email)) return true;

        return in_array($capability, array(
            'view', 'ticket.create', 'ticket.edit_own', 'ticket.reply', 'ticket.status', 'ticket.share',
            'ticket.delete_own', 'ticket.sync', 'attachment.upload'
        ), true);
    }
}

if (!function_exists('dmdtk_protect_dir')) {
    function dmdtk_protect_dir($dir) {
        if (!is_dir($dir)) return;
        $file = rtrim((string)$dir, '/\\') . '/.htaccess';
        if (!is_file($file)) {
            @file_put_contents($file, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
            @chmod($file, 0640);
        }
    }
}

if (!function_exists('dmdtk_system_root')) {
    function dmdtk_system_root($create) {
        $dir = dmdtk_root() . '/data/modules/' . dmdtk_module_id();
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}

if (!function_exists('dmdtk_profiles_root')) {
    function dmdtk_profiles_root() {
        return dmdtk_root() . '/users/profiles';
    }
}

if (!function_exists('dmdtk_user_root')) {
    function dmdtk_user_root($email, $create) {
        $email = trim((string)$email);
        if ($email === '' || strpos($email, '/') !== false || strpos($email, '\\') !== false || strpos($email, "\0") !== false) return '';
        $profile = dmdtk_profiles_root() . '/' . $email;
        if (!is_dir($profile)) return '';
        $dir = $profile . '/' . dmdtk_module_id();
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}

if (!function_exists('dmdtk_ticket_dir')) {
    function dmdtk_ticket_dir($email, $create) {
        $root = dmdtk_user_root($email, $create);
        if ($root === '') return '';
        $dir = $root . '/tickets';
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) @chmod($dir, 0750);
        return $dir;
    }
}

if (!function_exists('dmdtk_files_dir')) {
    function dmdtk_files_dir($email, $ticketId, $create) {
        $root = dmdtk_user_root($email, $create);
        if ($root === '') return '';
        $base = $root . '/files';
        if ($create && !is_dir($base)) @mkdir($base, 0750, true);
        $ticketId = preg_replace('~[^A-Za-z0-9._-]+~', '_', (string)$ticketId);
        if ($ticketId === '') return '';
        $dir = $base . '/' . $ticketId;
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) @chmod($dir, 0750);
        return $dir;
    }
}

/* ---------------------------------------------------------------------
 * Stockage commun des tickets reçus d'entreprises clientes.
 *
 * Un ticket externe appartient à l'instance DoMyDesk Support, pas au
 * profil du technicien configuré comme propriétaire logique. Les tickets
 * et leurs pièces jointes sont donc stockés sous :
 * data/modules/dmd-ticketing/external/{tickets,files}/
 * --------------------------------------------------------------------- */
if (!function_exists('dmdtk_external_storage_root')) {
    function dmdtk_external_storage_root($create) {
        $dir = dmdtk_system_root($create) . '/external';
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}
if (!function_exists('dmdtk_external_ticket_dir')) {
    function dmdtk_external_ticket_dir($create) {
        $root = dmdtk_external_storage_root($create);
        if ($root === '') return '';
        $dir = $root . '/tickets';
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}
if (!function_exists('dmdtk_external_files_dir')) {
    function dmdtk_external_files_dir($ticketId, $create) {
        $root = dmdtk_external_storage_root($create);
        if ($root === '') return '';
        $base = $root . '/files';
        if ($create && !is_dir($base)) @mkdir($base, 0750, true);
        if ($create && is_dir($base)) { @chmod($base, 0750); dmdtk_protect_dir($base); }
        $ticketId = preg_replace('~[^A-Za-z0-9._-]+~', '_', (string)$ticketId);
        if ($ticketId === '') return '';
        $dir = $base . '/' . $ticketId;
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}
if (!function_exists('dmdtk_ticket_is_external')) {
    function dmdtk_ticket_is_external($ticket) {
        if (!is_array($ticket)) return false;
        $id = trim((string)($ticket['id'] ?? ''));
        if (strpos($id, 'EXT-') === 0) return true;
        return !empty($ticket['meta']['external']) && is_array($ticket['meta']['external']);
    }
}
if (!function_exists('dmdtk_ticket_files_dir')) {
    function dmdtk_ticket_files_dir($ticket, $create) {
        if (!is_array($ticket) || empty($ticket['id'])) return '';
        if (dmdtk_ticket_is_external($ticket)) {
            return dmdtk_external_files_dir((string)$ticket['id'], $create);
        }
        return dmdtk_files_dir((string)($ticket['owner'] ?? ''), (string)$ticket['id'], $create);
    }
}

/* Cache commun des pièces jointes reçues depuis un Support/DoMyCo.
 * Le ticket client reste dans son stockage normal, mais les fichiers reçus
 * d'un serveur distant ne dépendent pas du profil d'un utilisateur. */
if (!function_exists('dmdtk_remote_storage_root')) {
    function dmdtk_remote_storage_root($create) {
        $dir = dmdtk_system_root($create) . '/remote';
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}
if (!function_exists('dmdtk_remote_files_dir')) {
    function dmdtk_remote_files_dir($ticketId, $create) {
        $root = dmdtk_remote_storage_root($create);
        if ($root === '') return '';
        $base = $root . '/files';
        if ($create && !is_dir($base)) @mkdir($base, 0750, true);
        if ($create && is_dir($base)) { @chmod($base, 0750); dmdtk_protect_dir($base); }
        $ticketId = preg_replace('~[^A-Za-z0-9._-]+~', '_', (string)$ticketId);
        if ($ticketId === '') return '';
        $dir = $base . '/' . $ticketId;
        if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
        if ($create && is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}
if (!function_exists('dmdtk_attachment_files_dir')) {
    function dmdtk_attachment_files_dir($ticket, $attachment, $create) {
        if (is_array($attachment) && (string)($attachment['stored_on'] ?? '') === 'remote_cache') {
            return dmdtk_remote_files_dir((string)($ticket['id'] ?? ''), $create);
        }
        return dmdtk_ticket_files_dir($ticket, $create);
    }
}

/* Résolution robuste d'une pièce jointe locale.
 * Les métadonnées d'un ticket peuvent évoluer pendant une synchronisation
 * (domydesk/support_provider/remote_cache). On ne doit jamais rendre le fichier
 * illisible uniquement parce que stored_on ne correspond plus exactement à
 * son emplacement physique. Seuls des répertoires autorisés pour CE ticket
 * sont parcourus, et le nom est toujours réduit à basename(). */
if (!function_exists('dmdtk_attachment_file_path')) {
    function dmdtk_attachment_file_path($ticket, $attachment, $storedName) {
        if (!is_array($ticket) || empty($ticket['id'])) return '';
        $stored = basename((string)$storedName);
        if ($stored === '' || $stored === '.' || $stored === '..') return '';

        $dirs = array();
        $specific = dmdtk_attachment_files_dir($ticket, $attachment, false);
        if ($specific !== '') $dirs[] = $specific;

        $ticketDir = dmdtk_ticket_files_dir($ticket, false);
        if ($ticketDir !== '') $dirs[] = $ticketDir;

        $remoteDir = dmdtk_remote_files_dir((string)$ticket['id'], false);
        if ($remoteDir !== '') $dirs[] = $remoteDir;

        $seen = array();
        foreach ($dirs as $dir) {
            $key = rtrim((string)$dir, '/\\');
            if ($key === '' || isset($seen[$key]) || !is_dir($key)) continue;
            $seen[$key] = true;
            $base = realpath($key);
            $file = realpath($key . DIRECTORY_SEPARATOR . $stored);
            if (!$base || !$file || !is_file($file)) continue;
            $prefix = rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
            if (strpos($file, $prefix) === 0) return $file;
        }
        return '';
    }
}

if (!function_exists('dmdtk_config_file')) {
    function dmdtk_config_file() { return dmdtk_system_root(true) . '/config.json'; }
}
if (!function_exists('dmdtk_index_file')) {
    function dmdtk_index_file() { return dmdtk_system_root(true) . '/index.json'; }
}
if (!function_exists('dmdtk_outbox_file')) {
    function dmdtk_outbox_file() { return dmdtk_system_root(true) . '/outbox.json'; }
}
if (!function_exists('dmdtk_migration_file')) {
    function dmdtk_migration_file() { return dmdtk_system_root(true) . '/migration_legacy_ticketing.json'; }
}


/* ---------------------------------------------------------------------
 * Identité / secrets DMD-Ticketing
 * --------------------------------------------------------------------- */
if (!function_exists('dmdtk_private_dir')) {
    function dmdtk_private_dir() {
        $dir = dmdtk_system_root(true) . '/private';
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        if (is_dir($dir)) { @chmod($dir, 0750); dmdtk_protect_dir($dir); }
        return $dir;
    }
}
if (!function_exists('dmdtk_secret_key_file')) {
    function dmdtk_secret_key_file() { return dmdtk_private_dir() . '/storage.key'; }
}
if (!function_exists('dmdtk_secret_key')) {
    function dmdtk_secret_key() {
        static $key = null;
        if (is_string($key) && strlen($key) === 32) return $key;
        $file = dmdtk_secret_key_file();
        if (is_file($file)) {
            $raw = @file_get_contents($file);
            $decoded = is_string($raw) ? base64_decode(trim($raw), true) : false;
            if (is_string($decoded) && strlen($decoded) === 32) return $key = $decoded;
        }
        try { $created = random_bytes(32); } catch (Throwable $e) { return ''; }
        if (@file_put_contents($file, base64_encode($created) . "\n", LOCK_EX) === false) return '';
        @chmod($file, 0600);
        return $key = $created;
    }
}
if (!function_exists('dmdtk_secret_encrypt')) {
    function dmdtk_secret_encrypt($plain) {
        $plain = (string)$plain;
        if ($plain === '') return '';
        $key = dmdtk_secret_key();
        if ($key === '') return false;
        if (function_exists('sodium_crypto_secretbox')) {
            $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            return 'sbox:' . base64_encode($nonce . sodium_crypto_secretbox($plain, $nonce, $key));
        }
        if (function_exists('openssl_encrypt')) {
            $iv = random_bytes(12); $tag = '';
            $cipher = @openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'DMD-TICKETING-V1', 16);
            if (is_string($cipher)) return 'gcm:' . base64_encode($iv . $tag . $cipher);
        }
        return false;
    }
}
if (!function_exists('dmdtk_secret_decrypt')) {
    function dmdtk_secret_decrypt($stored) {
        $stored = (string)$stored;
        if ($stored === '') return '';
        $key = dmdtk_secret_key();
        if ($key === '') return false;
        if (strpos($stored, 'sbox:') === 0 && function_exists('sodium_crypto_secretbox_open')) {
            $raw = base64_decode(substr($stored, 5), true);
            if (!is_string($raw) || strlen($raw) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) return false;
            $nonce = substr($raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $cipher = substr($raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            return sodium_crypto_secretbox_open($cipher, $nonce, $key);
        }
        if (strpos($stored, 'gcm:') === 0 && function_exists('openssl_decrypt')) {
            $raw = base64_decode(substr($stored, 4), true);
            if (!is_string($raw) || strlen($raw) <= 28) return false;
            $iv = substr($raw, 0, 12); $tag = substr($raw, 12, 16); $cipher = substr($raw, 28);
            return @openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'DMD-TICKETING-V1');
        }
        /* Compatibilité avec l'ancienne configuration en clair. */
        return $stored;
    }
}
if (!function_exists('dmdtk_b64url_encode')) {
    function dmdtk_b64url_encode($raw) { return rtrim(strtr(base64_encode((string)$raw), '+/', '-_'), '='); }
}
if (!function_exists('dmdtk_b64url_decode')) {
    function dmdtk_b64url_decode($text) {
        $text = strtr((string)$text, '-_', '+/');
        $pad = strlen($text) % 4; if ($pad) $text .= str_repeat('=', 4 - $pad);
        return base64_decode($text, true);
    }
}
if (!function_exists('dmdtk_domydesk_id')) {
    function dmdtk_domydesk_id() {
        $file = dmdtk_root() . '/data/id_domydesk.txt';
        return is_file($file) ? trim((string)@file_get_contents($file)) : '';
    }
}
if (!function_exists('dmdtk_link_identity_file')) {
    function dmdtk_link_identity_file() { return dmdtk_private_dir() . '/link-signing.json'; }
}
if (!function_exists('dmdtk_link_identity')) {
    function dmdtk_link_identity() {
        if (!function_exists('sodium_crypto_sign_keypair')) return array('ok'=>false,'error'=>'SODIUM_REQUIRED');
        $file = dmdtk_link_identity_file();
        $row = dmdtk_read_json($file, array());
        if (!empty($row['public_key_b64']) && !empty($row['secret_key_enc'])) {
            $pub = base64_decode((string)$row['public_key_b64'], true);
            $sec = dmdtk_secret_decrypt((string)$row['secret_key_enc']);
            $secRaw = is_string($sec) ? base64_decode($sec, true) : false;
            if (is_string($pub) && strlen($pub) === SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES && is_string($secRaw) && strlen($secRaw) === SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) {
                return array('ok'=>true,'public'=>$pub,'secret'=>$secRaw,'public_key_b64'=>base64_encode($pub),'fingerprint'=>strtoupper(hash('sha256',$pub)));
            }
        }
        $kp = sodium_crypto_sign_keypair();
        $secRaw = sodium_crypto_sign_secretkey($kp); $pub = sodium_crypto_sign_publickey($kp);
        $enc = dmdtk_secret_encrypt(base64_encode($secRaw));
        if (!is_string($enc) || $enc === '') return array('ok'=>false,'error'=>'SIGNING_KEY_STORAGE_FAILED');
        $payload = array('schema'=>1,'public_key_b64'=>base64_encode($pub),'secret_key_enc'=>$enc,'created_at'=>dmdtk_now());
        if (!dmdtk_write_json($file, $payload)) return array('ok'=>false,'error'=>'SIGNING_KEY_STORAGE_FAILED');
        @chmod($file, 0600);
        return array('ok'=>true,'public'=>$pub,'secret'=>$secRaw,'public_key_b64'=>base64_encode($pub),'fingerprint'=>strtoupper(hash('sha256',$pub)));
    }
}

/* ---------------------------------------------------------------------
 * Entreprises clientes du DoMyDesk Support
 * --------------------------------------------------------------------- */
if (!function_exists('dmdtk_external_clients_file')) {
    function dmdtk_external_clients_file() { return dmdtk_system_root(true) . '/external_clients.json'; }
}
if (!function_exists('dmdtk_external_clients_lock_file')) {
    function dmdtk_external_clients_lock_file() { return dmdtk_system_root(true) . '/external_clients.lock'; }
}
if (!function_exists('dmdtk_external_client_id_key')) {
    function dmdtk_external_client_id_key($instanceUid) { return hash('sha256', trim((string)$instanceUid)); }
}
if (!function_exists('dmdtk_external_clients_registry')) {
    function dmdtk_external_clients_registry() {
        $data = dmdtk_read_json(dmdtk_external_clients_file(), array());
        $clients = isset($data['clients']) && is_array($data['clients']) ? $data['clients'] : array();
        $out = array();
        foreach ($clients as $row) {
            if (!is_array($row)) continue;
            $uid = trim((string)($row['instance_uid'] ?? ''));
            if ($uid === '') continue;
            $status = strtolower(trim((string)($row['status'] ?? 'active')));
            if (!in_array($status, array('active','revoked'), true)) $status = 'active';
            $idKey = dmdtk_external_client_id_key($uid);
            $out[$idKey] = array(
                'instance_uid' => $uid,
                'client_name' => trim((string)($row['client_name'] ?? $row['instance_name'] ?? '')),
                'client_ref' => trim((string)($row['client_ref'] ?? '')),
                'token_hash' => trim((string)($row['token_hash'] ?? $row['key_hash'] ?? '')),
                'token_enc' => trim((string)($row['token_enc'] ?? '')),
                'status' => $status,
                'created_at' => (string)($row['created_at'] ?? $row['first_seen_at'] ?? ''),
                'created_by' => trim((string)($row['created_by'] ?? '')),
                'last_seen_at' => (string)($row['last_seen_at'] ?? ''),
                'revoked_at' => (string)($row['revoked_at'] ?? ''),
                'revoked_by' => trim((string)($row['revoked_by'] ?? '')),
                'updated_at' => (string)($row['updated_at'] ?? '')
            );
        }
        return array('schema'=>2, 'clients'=>$out);
    }
}
if (!function_exists('dmdtk_external_clients_mutate')) {
    function dmdtk_external_clients_mutate($callback) {
        $lock = dmdtk_external_clients_lock_file();
        $fh = @fopen($lock, 'c+'); if (!$fh) return false;
        $ok = false;
        if (@flock($fh, LOCK_EX)) {
            $registry = dmdtk_external_clients_registry();
            $next = call_user_func($callback, $registry); if (is_array($next)) $registry = $next;
            $registry['schema'] = 2; if (!isset($registry['clients']) || !is_array($registry['clients'])) $registry['clients'] = array();
            $ok = dmdtk_write_json(dmdtk_external_clients_file(), $registry);
            @flock($fh, LOCK_UN);
        }
        @fclose($fh); @chmod($lock, 0640); return $ok;
    }
}
if (!function_exists('dmdtk_external_client_record')) {
    function dmdtk_external_client_record($instanceUid) {
        $uid = trim((string)$instanceUid); if ($uid === '') return array();
        $registry = dmdtk_external_clients_registry(); $key = dmdtk_external_client_id_key($uid);
        return isset($registry['clients'][$key]) && is_array($registry['clients'][$key]) ? $registry['clients'][$key] : array();
    }
}
if (!function_exists('dmdtk_external_client_list')) {
    function dmdtk_external_client_list() {
        $rows = array_values(dmdtk_external_clients_registry()['clients']);
        usort($rows, function($a,$b){
            $sa=(string)($a['status']??'active'); $sb=(string)($b['status']??'active');
            if ($sa !== $sb) return $sa === 'active' ? -1 : 1;
            return strcasecmp((string)($a['client_name']??''),(string)($b['client_name']??''));
        });
        return $rows;
    }
}
if (!function_exists('dmdtk_external_active_client_count')) {
    function dmdtk_external_active_client_count() {
        $count = 0; foreach (dmdtk_external_client_list() as $row) if (($row['status'] ?? '') === 'active') $count++;
        return $count;
    }
}
if (!function_exists('dmdtk_external_client_create')) {
    function dmdtk_external_client_create($clientName, $instanceUid, $by) {
        $clientName = trim((string)$clientName); $instanceUid = trim((string)$instanceUid); $by = trim((string)$by);
        if ($clientName === '' || $instanceUid === '') return array('ok'=>false,'error'=>'CLIENT_FIELDS_REQUIRED');
        if (!dmdtk_external_license_enabled()) return array('ok'=>false,'error'=>'RECEIVER_LICENSE_REQUIRED');
        if (dmdtk_external_client_record($instanceUid)) return array('ok'=>false,'error'=>'CLIENT_ALREADY_EXISTS');
        $max = dmdtk_external_clients_max(); $active = dmdtk_external_active_client_count();
        if ($max >= 0 && $active >= $max) return array('ok'=>false,'error'=>'CLIENT_LIMIT_REACHED','clients_max'=>$max);
        $clientRef = 'CLI-' . strtoupper(substr(bin2hex(random_bytes(8)), 0, 12));
        $token = bin2hex(random_bytes(32)); $tokenEnc = dmdtk_secret_encrypt($token);
        if (!is_string($tokenEnc) || $tokenEnc === '') return array('ok'=>false,'error'=>'CLIENT_TOKEN_STORAGE_FAILED');
        $row = array(
            'instance_uid'=>$instanceUid,'client_name'=>$clientName,'client_ref'=>$clientRef,
            'token_hash'=>hash('sha256',$token),'token_enc'=>$tokenEnc,'status'=>'active',
            'created_at'=>dmdtk_now(),'created_by'=>$by,'last_seen_at'=>'','revoked_at'=>'','revoked_by'=>'','updated_at'=>dmdtk_now()
        );
        $saved = dmdtk_external_clients_mutate(function($registry) use ($row) {
            $registry['clients'][dmdtk_external_client_id_key($row['instance_uid'])] = $row; return $registry;
        });
        return $saved ? array('ok'=>true,'client'=>$row,'token'=>$token) : array('ok'=>false,'error'=>'CLIENT_REGISTRY_WRITE_FAILED');
    }
}
if (!function_exists('dmdtk_external_client_set_status')) {
    function dmdtk_external_client_set_status($instanceUid, $status, $by) {
        $instanceUid=trim((string)$instanceUid); $status=strtolower(trim((string)$status)); $by=trim((string)$by);
        if ($instanceUid==='' || !in_array($status,array('active','revoked'),true)) return array('ok'=>false,'error'=>'BAD_CLIENT_STATUS');
        $current=dmdtk_external_client_record($instanceUid); if (!$current) return array('ok'=>false,'error'=>'CLIENT_NOT_FOUND');
        if ($status==='active' && ($current['status']??'')!=='active') {
            $max=dmdtk_external_clients_max(); if ($max>=0 && dmdtk_external_active_client_count() >= $max) return array('ok'=>false,'error'=>'CLIENT_LIMIT_REACHED','clients_max'=>$max);
        }
        $found=false; $now=dmdtk_now();
        $saved=dmdtk_external_clients_mutate(function($registry) use ($instanceUid,$status,$by,$now,&$found){
            $key=dmdtk_external_client_id_key($instanceUid); if (!isset($registry['clients'][$key])) return $registry;
            $found=true; $row=$registry['clients'][$key]; $row['status']=$status; $row['updated_at']=$now;
            if ($status==='revoked') { $row['revoked_at']=$now; $row['revoked_by']=$by; }
            else { $row['revoked_at']=''; $row['revoked_by']=''; }
            $registry['clients'][$key]=$row; return $registry;
        });
        return array('ok'=>$saved && $found,'error'=>($saved&&$found)?'':'CLIENT_REGISTRY_WRITE_FAILED');
    }
}
if (!function_exists('dmdtk_external_client_regenerate_token')) {
    function dmdtk_external_client_regenerate_token($instanceUid, $by) {
        $row=dmdtk_external_client_record($instanceUid); if (!$row) return array('ok'=>false,'error'=>'CLIENT_NOT_FOUND');
        $token=bin2hex(random_bytes(32)); $enc=dmdtk_secret_encrypt($token); if (!is_string($enc)||$enc==='') return array('ok'=>false,'error'=>'CLIENT_TOKEN_STORAGE_FAILED');
        $found=false; $now=dmdtk_now();
        $saved=dmdtk_external_clients_mutate(function($registry) use ($instanceUid,$token,$enc,$by,$now,&$found){
            $key=dmdtk_external_client_id_key($instanceUid); if (!isset($registry['clients'][$key])) return $registry;
            $found=true; $r=$registry['clients'][$key]; $r['token_hash']=hash('sha256',$token); $r['token_enc']=$enc; $r['updated_at']=$now; $registry['clients'][$key]=$r; return $registry;
        });
        return ($saved&&$found)?array('ok'=>true,'token'=>$token,'client'=>dmdtk_external_client_record($instanceUid)):array('ok'=>false,'error'=>'CLIENT_REGISTRY_WRITE_FAILED');
    }
}
if (!function_exists('dmdtk_external_client_authorize')) {
    function dmdtk_external_client_authorize($instanceUid, $clientToken, $instance=array()) {
        $instanceUid=trim((string)$instanceUid); $clientToken=trim((string)$clientToken);
        if ($instanceUid==='' || $clientToken==='') return array('ok'=>false,'error'=>'CLIENT_IDENTITY_REQUIRED');
        $row=dmdtk_external_client_record($instanceUid); if (!$row) return array('ok'=>false,'error'=>'CLIENT_NOT_REGISTERED');
        if (($row['status']??'')==='revoked') return array('ok'=>false,'error'=>'CLIENT_REVOKED','client'=>$row);
        if (($row['status']??'')!=='active') return array('ok'=>false,'error'=>'CLIENT_NOT_ACTIVE','client'=>$row);
        $hash=hash('sha256',$clientToken); if (empty($row['token_hash']) || !hash_equals((string)$row['token_hash'],$hash)) return array('ok'=>false,'error'=>'CLIENT_TOKEN_INVALID','client'=>$row);
        $now=dmdtk_now();
        dmdtk_external_clients_mutate(function($registry) use ($instanceUid,$now){ $k=dmdtk_external_client_id_key($instanceUid); if(isset($registry['clients'][$k])){$registry['clients'][$k]['last_seen_at']=$now;$registry['clients'][$k]['updated_at']=$now;} return $registry; });
        return array('ok'=>true,'client'=>dmdtk_external_client_record($instanceUid));
    }
}
if (!function_exists('dmdtk_external_client_is_active')) {
    function dmdtk_external_client_is_active($instanceUid) { $row=dmdtk_external_client_record($instanceUid); return !empty($row) && ($row['status']??'')==='active'; }
}
if (!function_exists('dmdtk_external_client_token')) {
    function dmdtk_external_client_token($instanceUid) {
        $row=dmdtk_external_client_record($instanceUid); if (!$row || empty($row['token_enc'])) return '';
        $plain=dmdtk_secret_decrypt((string)$row['token_enc']); return is_string($plain)?$plain:'';
    }
}
if (!function_exists('dmdtk_link_export_raw')) {
    function dmdtk_link_export_raw($instanceUid) {
        $row=dmdtk_external_client_record($instanceUid); if (!$row) return array('ok'=>false,'error'=>'CLIENT_NOT_FOUND');
        if (($row['status']??'')!=='active') return array('ok'=>false,'error'=>'CLIENT_REVOKED');
        $cfg=dmdtk_config(); $receive=$cfg['external_receive']??array();
        if (empty($receive['enabled']) || trim((string)($receive['name']??''))==='' || trim((string)($receive['endpoint']??''))==='' || trim((string)($receive['token']??''))==='') return array('ok'=>false,'error'=>'SUPPORT_RECEIVER_NOT_CONFIGURED');
        $clientToken=dmdtk_external_client_token($instanceUid); if ($clientToken==='') return array('ok'=>false,'error'=>'CLIENT_TOKEN_UNAVAILABLE');
        $identity=dmdtk_link_identity(); if (empty($identity['ok'])) return $identity;
        $payload=array(
            'format'=>'DMD-TICKET-LINK-PAYLOAD-V1','schema'=>1,
            'support_name'=>(string)$receive['name'],'client_name'=>(string)($row['client_name']??''),'client_ref'=>(string)($row['client_ref']??''),
            'support_instance_id'=>dmdtk_domydesk_id(),'client_instance_id'=>(string)$row['instance_uid'],
            'endpoint'=>(string)$receive['endpoint'],'support_key'=>(string)$receive['token'],'client_token'=>$clientToken,
            'created_at'=>dmdtk_now(),'revision'=>1
        );
        $payloadRaw=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); if(!is_string($payloadRaw)) return array('ok'=>false,'error'=>'LINK_ENCODING_FAILED');
        $sig=sodium_crypto_sign_detached($payloadRaw,$identity['secret']);
        $env=array('format'=>'DMD-TICKET-LINK-V1','schema'=>1,'alg'=>'Ed25519','payload_b64'=>dmdtk_b64url_encode($payloadRaw),'signature_b64'=>dmdtk_b64url_encode($sig),'signer_public_key_b64'=>$identity['public_key_b64'],'signer_fingerprint'=>$identity['fingerprint']);
        $raw=json_encode($env,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $safe=preg_replace('~[^A-Za-z0-9._-]+~','-',(string)($row['client_name']??'client')); $safe=trim($safe,'-_.'); if($safe==='')$safe='client';
        return array('ok'=>true,'raw'=>$raw."\n",'filename'=>$safe.'.dmdticketlink','payload'=>$payload);
    }
}
if (!function_exists('dmdtk_link_import_raw')) {
    function dmdtk_link_import_raw($raw, $updatedBy='') {
        if (!function_exists('sodium_crypto_sign_verify_detached')) return array('ok'=>false,'error'=>'SODIUM_REQUIRED');
        $env=json_decode(trim((string)$raw),true);
        if(!is_array($env)||(string)($env['format']??'')!=='DMD-TICKET-LINK-V1'||(int)($env['schema']??0)!==1||(string)($env['alg']??'')!=='Ed25519') return array('ok'=>false,'error'=>'LINK_FORMAT_INVALID');
        $payloadRaw=dmdtk_b64url_decode((string)($env['payload_b64']??'')); $sig=dmdtk_b64url_decode((string)($env['signature_b64']??'')); $pub=base64_decode((string)($env['signer_public_key_b64']??''),true);
        if(!is_string($payloadRaw)||!is_string($sig)||!is_string($pub)||strlen($sig)!==SODIUM_CRYPTO_SIGN_BYTES||strlen($pub)!==SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) return array('ok'=>false,'error'=>'LINK_SIGNATURE_INVALID');
        if(!sodium_crypto_sign_verify_detached($sig,$payloadRaw,$pub)) return array('ok'=>false,'error'=>'LINK_SIGNATURE_INVALID');
        $p=json_decode($payloadRaw,true); if(!is_array($p)||(string)($p['format']??'')!=='DMD-TICKET-LINK-PAYLOAD-V1') return array('ok'=>false,'error'=>'LINK_PAYLOAD_INVALID');
        $required=array('support_name','client_name','client_ref','support_instance_id','client_instance_id','endpoint','support_key','client_token');
        foreach($required as $field) if(trim((string)($p[$field]??''))==='') return array('ok'=>false,'error'=>'LINK_FIELD_MISSING','field'=>$field);
        $local=dmdtk_domydesk_id(); if($local===''||!hash_equals($local,(string)$p['client_instance_id'])) return array('ok'=>false,'error'=>'LINK_INSTANCE_MISMATCH','expected'=>$local,'target'=>(string)$p['client_instance_id']);
        $cfg=dmdtk_config(); $support=array(
            'enabled'=>true,'name'=>(string)$p['support_name'],'endpoint'=>(string)$p['endpoint'],'port'=>0,
            'token'=>(string)$p['support_key'],'client_key'=>(string)$p['client_token'],'client_ref'=>(string)$p['client_ref'],
            'client_name'=>(string)$p['client_name'],'support_instance_id'=>(string)$p['support_instance_id'],'imported_at'=>dmdtk_now(),
            'link_fingerprint'=>strtoupper(hash('sha256',$pub))
        );
        $saved=dmdtk_save_config($cfg['categories']??array(),$cfg['priorities']??array(),$updatedBy,array('external_support'=>$support,'external_receive'=>$cfg['external_receive']??array()));
        return $saved===false?array('ok'=>false,'error'=>'LINK_STORAGE_FAILED'):array('ok'=>true,'support'=>$saved['external_support'],'payload'=>$p);
    }
}

if (!function_exists('dmdtk_read_json')) {
    function dmdtk_read_json($file, $fallback) {
        if (!is_file($file)) return $fallback;
        $raw = @file_get_contents($file);
        if ($raw === false || trim($raw) === '') return $fallback;
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $fallback;
    }
}

if (!function_exists('dmdtk_write_json')) {
    function dmdtk_write_json($file, $data) {
        $dir = dirname($file);
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($json === false) return false;
        $tmp = $file . '.tmp-' . getmypid() . '-' . substr(bin2hex(random_bytes(3)), 0, 6);
        if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
        @chmod($tmp, 0640);
        if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
        @chmod($file, 0640);
        return true;
    }
}


/* =========================================================
 * Workflow support : temps d'intervention, validation client,
 * incidents liés. Stockage JSON uniquement, sans SQL.
 * ========================================================= */
if (!function_exists('dmdtk_workflow_normalize')) {
    function dmdtk_workflow_normalize($workflow) {
        $workflow = is_array($workflow) ? $workflow : array();
        $time = isset($workflow['time']) && is_array($workflow['time']) ? $workflow['time'] : array();
        $entries = array();
        $sum = 0;
        foreach ((array)($time['entries'] ?? array()) as $row) {
            if (!is_array($row)) continue;
            $seconds = max(0, (int)($row['seconds'] ?? 0));
            if ($seconds <= 0) continue;
            $entry = array(
                'id' => trim((string)($row['id'] ?? '')),
                'user' => trim((string)($row['user'] ?? '')),
                'started_at' => (string)($row['started_at'] ?? ''),
                'ended_at' => (string)($row['ended_at'] ?? ''),
                'seconds' => $seconds,
                'note' => trim((string)($row['note'] ?? '')),
                'source' => in_array((string)($row['source'] ?? ''), array('timer','manual'), true) ? (string)$row['source'] : 'manual'
            );
            if ($entry['id'] === '') $entry['id'] = 'TIME-' . substr(hash('sha256', json_encode($entry)), 0, 16);
            $entries[] = $entry;
            $sum += $seconds;
        }
        $running = array();
        foreach ((array)($time['running'] ?? array()) as $user => $row) {
            if (!is_array($row)) continue;
            $email = trim((string)$user);
            $started = trim((string)($row['started_at'] ?? ''));
            if ($email === '' || $started === '' || strtotime($started) === false) continue;
            $running[$email] = array(
                'id' => trim((string)($row['id'] ?? '')),
                'started_at' => $started,
                'note' => trim((string)($row['note'] ?? ''))
            );
        }
        $explicitTotal = max(0, (int)($time['total_seconds'] ?? 0));
        $closure = isset($workflow['closure']) && is_array($workflow['closure']) ? $workflow['closure'] : array();
        $closureState = strtolower(trim((string)($closure['state'] ?? 'none')));
        if (!in_array($closureState, array('none','requested','accepted','rejected','cancelled','forced'), true)) $closureState = 'none';
        $incident = isset($workflow['incident']) && is_array($workflow['incident']) ? $workflow['incident'] : array();
        return array(
            'time' => array(
                'entries' => array_values($entries),
                'running' => $running,
                'total_seconds' => max($sum, $explicitTotal)
            ),
            'closure' => array(
                'state' => $closureState,
                'request_id' => trim((string)($closure['request_id'] ?? '')),
                'requested_at' => (string)($closure['requested_at'] ?? ''),
                'requested_by' => trim((string)($closure['requested_by'] ?? '')),
                'responded_at' => (string)($closure['responded_at'] ?? ''),
                'responded_by' => trim((string)($closure['responded_by'] ?? '')),
                'comment' => trim((string)($closure['comment'] ?? ''))
            ),
            'incident' => array(
                'id' => trim((string)($incident['id'] ?? '')),
                'title' => trim((string)($incident['title'] ?? '')),
                'status' => in_array((string)($incident['status'] ?? ''), array('open','closed'), true) ? (string)$incident['status'] : '',
                'linked_at' => (string)($incident['linked_at'] ?? ''),
                'linked_by' => trim((string)($incident['linked_by'] ?? ''))
            )
        );
    }
}
if (!function_exists('dmdtk_ticket_workflow')) {
    function dmdtk_ticket_workflow($ticket) {
        $workflow = is_array($ticket) && isset($ticket['meta']['workflow']) && is_array($ticket['meta']['workflow']) ? $ticket['meta']['workflow'] : array();
        return dmdtk_workflow_normalize($workflow);
    }
}
if (!function_exists('dmdtk_ticket_set_workflow')) {
    function dmdtk_ticket_set_workflow(&$ticket, $workflow) {
        if (!is_array($ticket)) return false;
        if (!isset($ticket['meta']) || !is_array($ticket['meta'])) $ticket['meta'] = array();
        $ticket['meta']['workflow'] = dmdtk_workflow_normalize($workflow);
        return true;
    }
}
if (!function_exists('dmdtk_incidents_file')) {
    function dmdtk_incidents_file() { return dmdtk_system_root(true) . '/incidents.json'; }
}
if (!function_exists('dmdtk_incidents_lock_file')) {
    function dmdtk_incidents_lock_file() { return dmdtk_system_root(true) . '/incidents.lock'; }
}
if (!function_exists('dmdtk_incidents_registry')) {
    function dmdtk_incidents_registry() {
        $raw = dmdtk_read_json(dmdtk_incidents_file(), array());
        $items = isset($raw['incidents']) && is_array($raw['incidents']) ? $raw['incidents'] : array();
        $out = array();
        foreach ($items as $id => $row) {
            if (!is_array($row)) continue;
            $iid = trim((string)($row['id'] ?? $id));
            if ($iid === '') continue;
            $status = in_array((string)($row['status'] ?? ''), array('open','closed'), true) ? (string)$row['status'] : 'open';
            $tickets = array();
            foreach ((array)($row['tickets'] ?? array()) as $ticketId) {
                $ticketId = preg_replace('~[^A-Za-z0-9._-]+~', '', (string)$ticketId);
                if ($ticketId !== '' && !in_array($ticketId, $tickets, true)) $tickets[] = $ticketId;
            }
            $out[$iid] = array(
                'id'=>$iid,
                'title'=>trim((string)($row['title'] ?? 'Incident')),
                'status'=>$status,
                'created_at'=>(string)($row['created_at'] ?? ''),
                'created_by'=>trim((string)($row['created_by'] ?? '')),
                'updated_at'=>(string)($row['updated_at'] ?? ''),
                'updated_by'=>trim((string)($row['updated_by'] ?? '')),
                'tickets'=>$tickets
            );
        }
        return array('incidents'=>$out);
    }
}
if (!function_exists('dmdtk_incidents_mutate')) {
    function dmdtk_incidents_mutate($callback) {
        $lock = dmdtk_incidents_lock_file();
        $fh = @fopen($lock, 'c+'); if (!$fh) return false;
        $ok = false;
        if (@flock($fh, LOCK_EX)) {
            $registry = dmdtk_incidents_registry();
            $next = call_user_func($callback, $registry);
            if (is_array($next)) $registry = $next;
            $ok = dmdtk_write_json(dmdtk_incidents_file(), $registry);
            @flock($fh, LOCK_UN);
        }
        @fclose($fh); @chmod($lock, 0640);
        return $ok;
    }
}
if (!function_exists('dmdtk_incident_list')) {
    function dmdtk_incident_list($includeClosed = true) {
        $rows = array_values(dmdtk_incidents_registry()['incidents']);
        if (!$includeClosed) $rows = array_values(array_filter($rows, function($row){ return ($row['status'] ?? 'open') === 'open'; }));
        usort($rows, function($a,$b){ return strcmp((string)($b['updated_at'] ?? $b['created_at'] ?? ''), (string)($a['updated_at'] ?? $a['created_at'] ?? '')); });
        return $rows;
    }
}
if (!function_exists('dmdtk_incident_get')) {
    function dmdtk_incident_get($incidentId) {
        $incidentId = trim((string)$incidentId);
        $registry = dmdtk_incidents_registry();
        return isset($registry['incidents'][$incidentId]) && is_array($registry['incidents'][$incidentId]) ? $registry['incidents'][$incidentId] : array();
    }
}
if (!function_exists('dmdtk_incident_create')) {
    function dmdtk_incident_create($title, $by) {
        $title = trim((string)$title); $by = trim((string)$by);
        if ($title === '') return array('ok'=>false,'error'=>'INCIDENT_TITLE_REQUIRED');
        $id = 'INC-' . date('Ymd-His') . '-' . strtoupper(substr(bin2hex(random_bytes(3)),0,6));
        $now = dmdtk_now();
        $row = array('id'=>$id,'title'=>$title,'status'=>'open','created_at'=>$now,'created_by'=>$by,'updated_at'=>$now,'updated_by'=>$by,'tickets'=>array());
        $saved = dmdtk_incidents_mutate(function($registry) use ($id,$row){ $registry['incidents'][$id]=$row; return $registry; });
        return $saved ? array('ok'=>true,'incident'=>$row) : array('ok'=>false,'error'=>'INCIDENT_WRITE_FAILED');
    }
}
if (!function_exists('dmdtk_incident_set_status')) {
    function dmdtk_incident_set_status($incidentId, $status, $by) {
        $incidentId=trim((string)$incidentId); $status=(string)$status; $by=trim((string)$by);
        if ($incidentId==='' || !in_array($status,array('open','closed'),true)) return false;
        $found=false;
        $saved=dmdtk_incidents_mutate(function($registry) use ($incidentId,$status,$by,&$found){
            if (!isset($registry['incidents'][$incidentId])) return $registry;
            $found=true;
            $registry['incidents'][$incidentId]['status']=$status;
            $registry['incidents'][$incidentId]['updated_at']=dmdtk_now();
            $registry['incidents'][$incidentId]['updated_by']=$by;
            return $registry;
        });
        return $saved && $found;
    }
}
if (!function_exists('dmdtk_incident_attach_ticket')) {
    function dmdtk_incident_attach_ticket($incidentId, $ticketId, $by) {
        $incidentId=trim((string)$incidentId); $ticketId=preg_replace('~[^A-Za-z0-9._-]+~','',(string)$ticketId); $by=trim((string)$by);
        if ($incidentId==='' || $ticketId==='') return false;
        return dmdtk_incidents_mutate(function($registry) use ($incidentId,$ticketId,$by){
            if (!isset($registry['incidents'][$incidentId])) return $registry;
            $tickets=(array)($registry['incidents'][$incidentId]['tickets']??array());
            if (!in_array($ticketId,$tickets,true)) $tickets[]=$ticketId;
            $registry['incidents'][$incidentId]['tickets']=array_values($tickets);
            $registry['incidents'][$incidentId]['updated_at']=dmdtk_now();
            $registry['incidents'][$incidentId]['updated_by']=$by;
            return $registry;
        });
    }
}
if (!function_exists('dmdtk_incident_detach_ticket')) {
    function dmdtk_incident_detach_ticket($incidentId, $ticketId, $by) {
        $incidentId=trim((string)$incidentId); $ticketId=preg_replace('~[^A-Za-z0-9._-]+~','',(string)$ticketId); $by=trim((string)$by);
        if ($incidentId==='' || $ticketId==='') return false;
        return dmdtk_incidents_mutate(function($registry) use ($incidentId,$ticketId,$by){
            if (!isset($registry['incidents'][$incidentId])) return $registry;
            $registry['incidents'][$incidentId]['tickets']=array_values(array_filter((array)($registry['incidents'][$incidentId]['tickets']??array()),function($id) use ($ticketId){ return (string)$id!==$ticketId; }));
            $registry['incidents'][$incidentId]['updated_at']=dmdtk_now();
            $registry['incidents'][$incidentId]['updated_by']=$by;
            return $registry;
        });
    }
}

if (!function_exists('dmdtk_default_config')) {
    function dmdtk_default_config() {
        return array(
            'categories' => array('Support', 'Bug', 'Amélioration', 'Demande', 'Incident'),
            'priorities' => array('Basse', 'Normale', 'Haute', 'Urgente'),
            /* Côté CLIENT : uniquement rempli par import d'un .dmdticketlink. */
            'external_support' => array(
                'enabled'=>false,'name'=>'','endpoint'=>'','port'=>443,'token'=>'','client_key'=>'','client_ref'=>'','client_name'=>'','support_instance_id'=>'','imported_at'=>'','link_fingerprint'=>''
            ),
            /* Côté SUPPORT : administré dans Administration > Licences. */
            'external_receive' => array(
                'enabled'=>false,'name'=>'','endpoint'=>'','token'=>'','owner'=>''
            )
        );
    }
}
if (!function_exists('dmdtk_normalize_config_values')) {
    function dmdtk_normalize_config_values($values, $fallback) {
        if (!is_array($values)) return array_values($fallback); $out=array();
        foreach($values as $value){$value=trim((string)$value);if($value!==''&&!in_array($value,$out,true))$out[]=$value;}
        return $out?$out:array_values($fallback);
    }
}
if (!function_exists('dmdtk_cfg_secret')) {
    function dmdtk_cfg_secret($row,$plainField,$encField) {
        if (isset($row[$encField]) && trim((string)$row[$encField])!=='') { $v=dmdtk_secret_decrypt((string)$row[$encField]); return is_string($v)?$v:''; }
        return trim((string)($row[$plainField]??''));
    }
}
if (!function_exists('dmdtk_normalize_config')) {
    function dmdtk_normalize_config($data) {
        $data=is_array($data)?$data:array(); $def=dmdtk_default_config();
        $support=isset($data['external_support'])&&is_array($data['external_support'])?$data['external_support']:array();
        $receive=isset($data['external_receive'])&&is_array($data['external_receive'])?$data['external_receive']:array();
        $supportEndpoint=trim((string)($support['endpoint']??'')); $supportPort=(int)($support['port']??0);
        if($supportPort<1||$supportPort>65535){$urlPort=(int)@parse_url($supportEndpoint,PHP_URL_PORT);if($urlPort>=1&&$urlPort<=65535)$supportPort=$urlPort;else $supportPort=strtolower((string)@parse_url($supportEndpoint,PHP_URL_SCHEME))==='http'?80:443;}
        return array(
            'categories'=>dmdtk_normalize_config_values($data['categories']??array(),$def['categories']),
            'priorities'=>dmdtk_normalize_config_values($data['priorities']??array(),$def['priorities']),
            'external_support'=>array(
                'enabled'=>!empty($support['enabled']),'name'=>trim((string)($support['name']??'')),'endpoint'=>$supportEndpoint,'port'=>$supportPort,
                'token'=>dmdtk_cfg_secret($support,'token','token_enc'),'client_key'=>dmdtk_cfg_secret($support,'client_key','client_key_enc'),
                'client_ref'=>trim((string)($support['client_ref']??'')),'client_name'=>trim((string)($support['client_name']??'')),
                'support_instance_id'=>trim((string)($support['support_instance_id']??'')),'imported_at'=>(string)($support['imported_at']??''),'link_fingerprint'=>trim((string)($support['link_fingerprint']??''))
            ),
            'external_receive'=>array(
                'enabled'=>!empty($receive['enabled']),'name'=>trim((string)($receive['name']??'')),'endpoint'=>trim((string)($receive['endpoint']??'')),
                'token'=>dmdtk_cfg_secret($receive,'token','token_enc'),'owner'=>trim((string)($receive['owner']??''))
            ),
            'updated_at'=>(string)($data['updated_at']??''),'updated_by'=>(string)($data['updated_by']??'')
        );
    }
}
if (!function_exists('dmdtk_config_storage')) {
    function dmdtk_config_storage($cfg) {
        $out=$cfg;
        foreach(array(array('external_support','token','token_enc'),array('external_support','client_key','client_key_enc'),array('external_receive','token','token_enc')) as $spec){
            list($section,$plain,$enc)=$spec; $value=(string)($out[$section][$plain]??'');
            if($value!==''){ $encrypted=dmdtk_secret_encrypt($value); if(!is_string($encrypted)||$encrypted==='') return false; $out[$section][$enc]=$encrypted; }
            unset($out[$section][$plain]);
        }
        return $out;
    }
}
if (!function_exists('dmdtk_config')) {
    function dmdtk_config() {
        $cfg=dmdtk_normalize_config(dmdtk_read_json(dmdtk_config_file(),array()));
        /* L'envoi côté client est libre. La réception reste soumise à licence. */
        $cfg['external_support']['enabled']=!empty($cfg['external_support']['enabled'])
            && trim((string)$cfg['external_support']['endpoint'])!==''
            && trim((string)$cfg['external_support']['token'])!==''
            && trim((string)$cfg['external_support']['client_key'])!=='';
        $cfg['external_receive']['enabled']=!empty($cfg['external_receive']['enabled']) && dmdtk_external_license_enabled();
        return $cfg;
    }
}
if (!function_exists('dmdtk_save_config')) {
    function dmdtk_save_config($categories,$priorities,$updatedBy,$options=array()) {
        $current=dmdtk_config(); $options=is_array($options)?$options:array();
        $support=isset($options['external_support'])&&is_array($options['external_support'])?$options['external_support']:$current['external_support'];
        $receive=isset($options['external_receive'])&&is_array($options['external_receive'])?$options['external_receive']:$current['external_receive'];
        $next=dmdtk_normalize_config(array('categories'=>is_array($categories)?$categories:array(),'priorities'=>is_array($priorities)?$priorities:array(),'external_support'=>$support,'external_receive'=>$receive,'updated_at'=>dmdtk_now(),'updated_by'=>trim((string)$updatedBy)));
        $storage=dmdtk_config_storage($next); if($storage===false || !dmdtk_write_json(dmdtk_config_file(),$storage)) return false;
        return dmdtk_config();
    }
}

if (!function_exists('dmdtk_index')) {
    function dmdtk_index() {
        $index = dmdtk_read_json(dmdtk_index_file(), array());
        return is_array($index) ? $index : array();
    }
}

if (!function_exists('dmdtk_ticket_summary_index')) {
    function dmdtk_ticket_summary_index($ticket) {
        $share = isset($ticket['share']) && is_array($ticket['share']) ? $ticket['share'] : array();
        return array(
            'owner' => (string)(isset($ticket['owner']) ? $ticket['owner'] : ''),
            'storage' => dmdtk_ticket_is_external($ticket) ? 'external' : 'user',
            'status' => (string)(isset($ticket['status']) ? $ticket['status'] : 'open'),
            'share' => array(
                'all' => !empty($share['all']),
                'users' => isset($share['users']) && is_array($share['users']) ? array_values($share['users']) : array(),
                'roles' => isset($share['roles']) && is_array($share['roles']) ? array_values($share['roles']) : array()
            ),
            'updated_at' => (string)(isset($ticket['updated_at']) ? $ticket['updated_at'] : ''),
            'created_at' => (string)(isset($ticket['created_at']) ? $ticket['created_at'] : ''),
            'domyco_requested' => !empty($ticket['send_to_domydesk']) || !empty($ticket['meta']['domydesk']['requested']),
            'remote_targets' => isset($ticket['remote_targets']) && is_array($ticket['remote_targets']) ? array_values($ticket['remote_targets']) : array(),
            'remote_target' => (string)(isset($ticket['remote_target']) ? $ticket['remote_target'] : ''),
            'external_requester' => (string)(isset($ticket['meta']['external']['requester']) ? $ticket['meta']['external']['requester'] : '')
        );
    }
}

if (!function_exists('dmdtk_index_mutate')) {
    function dmdtk_index_mutate($callback) {
        $lockFile = dmdtk_system_root(true) . '/index.lock';
        $fh = @fopen($lockFile, 'c+');
        if (!$fh) return false;
        $ok = false;
        if (@flock($fh, LOCK_EX)) {
            $index = dmdtk_read_json(dmdtk_index_file(), array());
            if (!is_array($index)) $index = array();
            $result = call_user_func($callback, $index);
            if (is_array($result)) $index = $result;
            $ok = dmdtk_write_json(dmdtk_index_file(), $index);
            @flock($fh, LOCK_UN);
        }
        @fclose($fh);
        @chmod($lockFile, 0640);
        return $ok;
    }
}

if (!function_exists('dmdtk_index_ticket')) {
    function dmdtk_index_ticket($ticket) {
        if (!is_array($ticket) || empty($ticket['id']) || empty($ticket['owner'])) return false;
        $id = (string)$ticket['id'];
        $entry = dmdtk_ticket_summary_index($ticket);
        return dmdtk_index_mutate(function($index) use ($id, $entry) {
            $index[$id] = $entry;
            return $index;
        });
    }
}

if (!function_exists('dmdtk_unindex_ticket')) {
    function dmdtk_unindex_ticket($id) {
        $id = (string)$id;
        return dmdtk_index_mutate(function($index) use ($id) {
            unset($index[$id]);
            return $index;
        });
    }
}

if (!function_exists('dmdtk_ticket_path')) {
    function dmdtk_ticket_path($id) {
        $id = preg_replace('~[^A-Za-z0-9._-]+~', '', (string)$id);
        if ($id === '') return array('', '');
        $index = dmdtk_index();
        $entry = isset($index[$id]) && is_array($index[$id]) ? $index[$id] : array();
        $owner = trim((string)(isset($entry['owner']) ? $entry['owner'] : ''));
        $storage = trim((string)($entry['storage'] ?? ''));

        /* Les EXT-* sont cherchés d'abord dans le stockage commun. */
        if ($storage === 'external' || strpos($id, 'EXT-') === 0) {
            $dir = dmdtk_external_ticket_dir(false);
            $path = $dir !== '' ? $dir . '/' . $id . '.json' : '';
            if ($path !== '' && is_file($path)) return array($path, $owner);
        }

        /* Compatibilité avec les tickets existants stockés dans un profil. */
        if ($owner !== '') {
            $dir = dmdtk_ticket_dir($owner, false);
            $path = $dir !== '' ? $dir . '/' . $id . '.json' : '';
            if ($path !== '' && is_file($path)) return array($path, $owner);
        }
        return array('', '');
    }
}

if (!function_exists('dmdtk_ticket_read')) {
    function dmdtk_ticket_read($id) {
        list($path, $owner) = dmdtk_ticket_path($id);
        if ($path === '') return array(null, '', '');
        $ticket = dmdtk_read_json($path, array());
        if (is_array($ticket) && !empty($ticket['owner'])) $owner = (string)$ticket['owner'];
        return array($ticket, $path, $owner);
    }
}

if (!function_exists('dmdtk_migrate_external_files_from_owner')) {
    function dmdtk_migrate_external_files_from_owner($ticket) {
        if (!dmdtk_ticket_is_external($ticket) || empty($ticket['owner']) || empty($ticket['id'])) return true;
        $oldDir = dmdtk_files_dir((string)$ticket['owner'], (string)$ticket['id'], false);
        if ($oldDir === '' || !is_dir($oldDir)) return true;
        $newDir = dmdtk_external_files_dir((string)$ticket['id'], true);
        if ($newDir === '') return false;
        foreach ((array)@scandir($oldDir) as $name) {
            if ($name === '.' || $name === '..' || $name === '.htaccess') continue;
            $src = $oldDir . '/' . $name;
            if (!is_file($src)) continue;
            $dst = $newDir . '/' . basename($name);
            if (!is_file($dst) && !@copy($src, $dst)) return false;
            @chmod($dst, 0640);
        }
        return true;
    }
}

if (!function_exists('dmdtk_ticket_write')) {
    function dmdtk_ticket_write($ticket) {
        if (!is_array($ticket) || empty($ticket['id']) || empty($ticket['owner'])) return false;
        $id = preg_replace('~[^A-Za-z0-9._-]+~', '', (string)$ticket['id']);
        if ($id === '') return false;

        $isExternal = dmdtk_ticket_is_external($ticket);
        if ($isExternal) {
            $dir = dmdtk_external_ticket_dir(true);
            if ($dir === '') return false;
            /* Migration transparente des anciennes PJ stockées dans le profil propriétaire. */
            if (!dmdtk_migrate_external_files_from_owner($ticket)) return false;
        } else {
            $dir = dmdtk_ticket_dir((string)$ticket['owner'], true);
            if ($dir === '') return false;
        }

        $file = $dir . '/' . $id . '.json';
        if (!dmdtk_write_json($file, $ticket)) return false;
        if (!dmdtk_index_ticket($ticket)) return false;

        /* Après écriture commune réussie, l'ancien JSON de profil n'est plus actif. */
        if ($isExternal) {
            $legacyDir = dmdtk_ticket_dir((string)$ticket['owner'], false);
            $legacyFile = $legacyDir !== '' ? $legacyDir . '/' . $id . '.json' : '';
            if ($legacyFile !== '' && $legacyFile !== $file && is_file($legacyFile)) @unlink($legacyFile);
        }
        return true;
    }
}

if (!function_exists('dmdtk_remove_tree')) {
    function dmdtk_remove_tree($dir) {
        if (!is_dir($dir)) return true;
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($it as $item) {
            $path = $item->getPathname();
            if ($item->isDir()) @rmdir($path); else @unlink($path);
        }
        return @rmdir($dir);
    }
}

if (!function_exists('dmdtk_delete_local_ticket')) {
    function dmdtk_delete_local_ticket($ticket) {
        if (!is_array($ticket) || empty($ticket['id']) || empty($ticket['owner'])) return false;
        $id = preg_replace('~[^A-Za-z0-9._-]+~', '', (string)$ticket['id']);
        if ($id === '') return false;

        if (dmdtk_ticket_is_external($ticket)) {
            $dir = dmdtk_external_ticket_dir(false);
            $file = $dir !== '' ? $dir . '/' . $id . '.json' : '';
            if ($file !== '' && is_file($file)) @unlink($file);
            $files = dmdtk_external_files_dir($id, false);
            if ($files !== '') dmdtk_remove_tree($files);

            /* Nettoyage d'un éventuel ancien stockage profil. */
            $legacyDir = dmdtk_ticket_dir((string)$ticket['owner'], false);
            $legacyFile = $legacyDir !== '' ? $legacyDir . '/' . $id . '.json' : '';
            if ($legacyFile !== '' && is_file($legacyFile)) @unlink($legacyFile);
            $legacyFiles = dmdtk_files_dir((string)$ticket['owner'], $id, false);
            if ($legacyFiles !== '') dmdtk_remove_tree($legacyFiles);
        } else {
            $dir = dmdtk_ticket_dir((string)$ticket['owner'], false);
            $file = $dir !== '' ? $dir . '/' . $id . '.json' : '';
            if ($file !== '' && is_file($file)) @unlink($file);
            $files = dmdtk_files_dir((string)$ticket['owner'], $id, false);
            if ($files !== '') dmdtk_remove_tree($files);
        }
        $workflow = dmdtk_ticket_workflow($ticket);
        $incidentId = trim((string)($workflow['incident']['id'] ?? ''));
        if ($incidentId !== '') dmdtk_incident_detach_ticket($incidentId, $id, 'system');
        dmdtk_unindex_ticket($id);
        return true;
    }
}

if (!function_exists('dmdtk_user_role_metier')) {
    function dmdtk_user_role_metier($email) {
        $p = dmdtk_profile($email);
        return trim((string)(isset($p['role_metier']) ? $p['role_metier'] : ''));
    }
}

if (!function_exists('dmdtk_can_access_ticket')) {
    function dmdtk_can_access_ticket($ticket, $email) {
        if (!is_array($ticket) || $email === '' || !dmdtk_user_can($email, 'view')) return false;
        if (dmdtk_user_can($email, 'admin.view_all')) return true;
        if ((string)(isset($ticket['owner']) ? $ticket['owner'] : '') === $email) return true;
        $share = isset($ticket['share']) && is_array($ticket['share']) ? $ticket['share'] : array();
        if (!empty($share['all'])) return true;
        if (isset($share['users']) && is_array($share['users']) && in_array($email, $share['users'], true)) return true;
        $role = dmdtk_user_role_metier($email);
        return $role !== '' && isset($share['roles']) && is_array($share['roles']) && in_array($role, $share['roles'], true);
    }
}

if (!function_exists('dmdtk_can_manage_ticket')) {
    function dmdtk_can_manage_ticket($ticket, $email) {
        if (!is_array($ticket)) return false;
        if ((string)(isset($ticket['owner']) ? $ticket['owner'] : '') === $email) return true;
        return dmdtk_user_can($email, 'admin.edit_any');
    }
}

if (!function_exists('dmdtk_can_delete_ticket')) {
    function dmdtk_can_delete_ticket($ticket, $email) {
        if (!is_array($ticket)) return false;
        if ((string)(isset($ticket['owner']) ? $ticket['owner'] : '') === $email) return dmdtk_user_can($email, 'ticket.delete_own');
        return dmdtk_user_can($email, 'admin.delete_any');
    }
}

if (!function_exists('dmdtk_csrf_token')) {
    function dmdtk_csrf_token() {
        if (empty($_SESSION['csrf_dmd_ticketing'])) $_SESSION['csrf_dmd_ticketing'] = bin2hex(random_bytes(32));
        return (string)$_SESSION['csrf_dmd_ticketing'];
    }
}

if (!function_exists('dmdtk_csrf_valid')) {
    function dmdtk_csrf_valid($token) {
        $stored = isset($_SESSION['csrf_dmd_ticketing']) ? (string)$_SESSION['csrf_dmd_ticketing'] : '';
        return $stored !== '' && is_string($token) && hash_equals($stored, $token);
    }
}

if (!function_exists('dmdtk_core_activity')) {
    function dmdtk_core_activity($email, $action, $target, $status, $details) {
        if (!function_exists('dmd_log_action')) return false;

        $email = trim((string)$email);
        $action = trim((string)$action);
        $target = trim((string)$target);
        $status = trim((string)$status);
        $details = is_array($details) ? $details : array('message' => (string)$details);
        if ($action === '' || $target === '') return false;

        $ticketId = preg_replace('~[^A-Za-z0-9._-]+~', '', $target);
        $title = trim((string)(isset($details['title']) ? $details['title'] : ''));
        if ($ticketId !== '' && $title === '') {
            list($ticket) = dmdtk_ticket_read($ticketId);
            if (is_array($ticket)) $title = trim((string)(isset($ticket['title']) ? $ticket['title'] : ''));
        }
        if ($title === '') $title = $ticketId !== '' ? $ticketId : $target;

        $coreAction = 'ticket_' . preg_replace('~[^a-z0-9_]+~', '_', strtolower($action));
        $resourceId = $ticketId !== '' ? $ticketId : $target;
        $payload = array(
            'module' => dmdtk_module_id(),
            'user' => $email,
            'action' => $coreAction,
            'resource' => 'ticket:' . $resourceId,
            'resource_type' => 'ticket',
            'resource_id' => $resourceId,
            'target' => $title,
            'status' => $status !== '' ? $status : 'success',
            'details' => $details
        );

        try {
            return dmd_log_action($payload) !== false;
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('dmdtk_log')) {
    function dmdtk_log($email, $action, $target, $status, $details) {
        $root = dmdtk_root() . '/users/profiles/' . $email . '/logs/' . dmdtk_module_id();
        if (!is_dir($root)) @mkdir($root, 0750, true);
        if (is_dir($root)) { @chmod($root, 0750); dmdtk_protect_dir($root); }
        $file = $root . '/' . date('Y-m-d') . '.json';
        $lock = $root . '/log.lock';
        $fh = @fopen($lock, 'c+');
        if (!$fh) return;
        if (@flock($fh, LOCK_EX)) {
            $rows = dmdtk_read_json($file, array());
            if (!is_array($rows)) $rows = array();
            $rows[] = array(
                'at' => dmdtk_now(),
                'module' => dmdtk_module_id(),
                'email' => $email,
                'action' => (string)$action,
                'target' => (string)$target,
                'status' => (string)$status,
                'details' => is_array($details) ? $details : array('message' => (string)$details),
                'ip' => isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : ''
            );
            if (count($rows) > 2000) $rows = array_slice($rows, -2000);
            dmdtk_write_json($file, $rows);
            @flock($fh, LOCK_UN);
            dmdtk_core_activity($email, $action, $target, $status, $details);
        }
        @fclose($fh);
        @chmod($lock, 0640);
    }
}

if (!function_exists('dmdtk_file_url')) {
    function dmdtk_file_url($ticketId, $storedName) {
        return 'modules/' . dmdtk_module_id() . '/dmd-ticketing_file.php?id=' . rawurlencode((string)$ticketId) . '&file=' . rawurlencode((string)$storedName);
    }
}

if (!function_exists('dmdtk_rewrite_legacy_attachments')) {
    function dmdtk_rewrite_legacy_attachments(&$ticket, $legacyFilesDir, $newFilesDir) {
        if (!isset($ticket['messages']) || !is_array($ticket['messages'])) return;
        foreach ($ticket['messages'] as &$message) {
            if (!is_array($message) || !isset($message['attachments']) || !is_array($message['attachments'])) continue;
            foreach ($message['attachments'] as &$attachment) {
                if (!is_array($attachment)) continue;
                $url = (string)(isset($attachment['local_url']) ? $attachment['local_url'] : (isset($attachment['url']) ? $attachment['url'] : ''));
                $path = (string)(parse_url($url, PHP_URL_PATH));
                $stored = basename(rawurldecode($path));
                if ($stored === '' || $stored === '.' || $stored === '..') continue;
                $legacy = rtrim($legacyFilesDir, '/\\') . '/' . $stored;
                $target = rtrim($newFilesDir, '/\\') . '/' . $stored;
                if (is_file($legacy) && !is_file($target)) {
                    @copy($legacy, $target);
                    @chmod($target, 0640);
                }
                if (is_file($target)) {
                    $attachment['stored_name'] = $stored;
                    $attachment['local_url'] = dmdtk_file_url((string)$ticket['id'], $stored);
                    if (empty($attachment['central_url']) && (($attachment['stored_on'] ?? '') !== 'domycocenter')) {
                        $attachment['url'] = $attachment['local_url'];
                        $attachment['stored_on'] = 'domydesk';
                    }
                }
            }
            unset($attachment);
        }
        unset($message);
    }
}


/* ---------------------------------------------------------------------
 * Relais automatique d'un ticket Support escaladé vers DoMyCo.
 *
 * Le Client ne contacte jamais DoMyCo directement. Dès qu'un ticket externe
 * a été escaladé une première fois par le Support, toute nouvelle synchro
 * Client -> Support republie automatiquement l'historique courant vers DoMyCo.
 * Les réponses du Support utilisent déjà le moteur de synchro de l'API.
 * --------------------------------------------------------------------- */
if (!function_exists('dmdtk_domyco_endpoint')) {
    function dmdtk_domyco_endpoint() {
        return 'https://register.synohomes.com/ticket.php';
    }
}

if (!function_exists('dmdtk_domyco_instance_context')) {
    function dmdtk_domyco_instance_context() {
        $context = array('instance_uid' => dmdtk_domydesk_id());
        $registerFile = dmdtk_root() . '/data/domyco_register.json';
        if (is_file($registerFile)) {
            $register = dmdtk_read_json($registerFile, array());
            $payload = isset($register['payload']) && is_array($register['payload']) ? $register['payload'] : array();
            foreach (array('instance_name','domain','install_url','version') as $key) {
                if (isset($payload[$key]) && is_scalar($payload[$key])) $context[$key] = (string)$payload[$key];
            }
        }
        return $context;
    }
}

if (!function_exists('dmdtk_domyco_ticket_escalated')) {
    function dmdtk_domyco_ticket_escalated($ticket) {
        if (!is_array($ticket)) return false;
        if (!empty($ticket['meta']['escalation']['requested'])) return true;
        return !empty($ticket['meta']['remotes']['domyco']['requested']);
    }
}

if (!function_exists('dmdtk_domyco_payload_ticket')) {
    function dmdtk_domyco_payload_ticket($ticket) {
        $copy = is_array($ticket) ? $ticket : array();
        if (isset($copy['messages']) && is_array($copy['messages'])) {
            $copy['messages'] = array_values(array_filter($copy['messages'], function($message) {
                if (!is_array($message)) return false;
                if ((string)($message['role'] ?? '') !== 'domydesk') return true;
                $target = trim((string)($message['remote_target'] ?? ''));
                return $target === '' || $target === 'domyco';
            }));
        }
        return $copy;
    }
}

if (!function_exists('dmdtk_domyco_attachment_path')) {
    function dmdtk_domyco_attachment_path($ticket, $attachment) {
        if (!is_array($ticket) || !is_array($attachment)) return '';
        $stored = basename((string)($attachment['stored_name'] ?? ''));
        if ($stored === '' || $stored === '.' || $stored === '..') return '';
        $dir = dmdtk_ticket_files_dir($ticket, false);
        if ($dir === '') return '';
        $base = realpath($dir);
        $candidate = realpath($dir . '/' . $stored);
        if (!$base || !$candidate || !is_file($candidate)) return '';
        $prefix = rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
        return strpos($candidate, $prefix) === 0 ? $candidate : '';
    }
}

if (!function_exists('dmdtk_domyco_post_ticket')) {
    function dmdtk_domyco_post_ticket($ticket) {
        $instance = dmdtk_domyco_instance_context();
        $instanceUid = trim((string)($instance['instance_uid'] ?? ''));
        if ($instanceUid === '') return array('ok'=>false,'status'=>'pending','reason'=>'instance_uid_missing','at'=>dmdtk_now());
        $payload = array(
            'type' => 'ticketing_ticket',
            'event' => 'upsert',
            'sent_at' => dmdtk_now(),
            'instance_uid' => $instanceUid,
            'instance' => $instance,
            'remote_target' => 'domyco',
            'ticket' => dmdtk_domyco_payload_ticket($ticket)
        );
        if (!empty($ticket['meta']['escalation']) && is_array($ticket['meta']['escalation'])) {
            $payload['escalation'] = $ticket['meta']['escalation'];
        }
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json) || $json === '') return array('ok'=>false,'status'=>'pending','reason'=>'json_encode_failed','at'=>dmdtk_now());

        $endpoint = dmdtk_domyco_endpoint();
        $http = 0; $error = ''; $body = '';
        if (function_exists('curl_init')) {
            $ch = curl_init($endpoint);
            if (!$ch) return array('ok'=>false,'status'=>'pending','reason'=>'curl_init_failed','at'=>dmdtk_now());
            curl_setopt_array($ch, array(
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $json,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 4,
                CURLOPT_TIMEOUT => 8,
                CURLOPT_HTTPHEADER => array('Content-Type: application/json','Accept: application/json'),
                CURLOPT_USERAGENT => 'DMD-Ticketing/2.0'
            ));
            $body = (string)curl_exec($ch);
            $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = (string)curl_error($ch);
            curl_close($ch);
        } else {
            $ctx = stream_context_create(array('http'=>array(
                'method'=>'POST',
                'header'=>"Content-Type: application/json\r\nAccept: application/json\r\nUser-Agent: DMD-Ticketing/2.0\r\n",
                'content'=>$json,
                'timeout'=>8,
                'ignore_errors'=>true
            )));
            $res = @file_get_contents($endpoint, false, $ctx);
            $body = $res === false ? '' : (string)$res;
            if (isset($http_response_header) && is_array($http_response_header)) {
                foreach ($http_response_header as $header) {
                    if (preg_match('#HTTP/\\S+\\s+(\\d+)#', $header, $m)) { $http = (int)$m[1]; break; }
                }
            }
            if ($res === false) $error = 'http_request_failed';
        }

        $decoded = json_decode($body, true);
        if (!is_array($decoded)) $decoded = array();
        $ok = $http >= 200 && $http < 300 && !empty($decoded['success']);
        return array(
            'ok'=>$ok,
            'status'=>$ok ? 'sent' : 'pending',
            'reason'=>$ok ? 'auto_relay' : 'send_failed',
            'http_code'=>$http,
            'error'=>$ok ? '' : ($error !== '' ? $error : (string)($decoded['message'] ?? 'DoMyCo n’a pas confirmé la réception.')),
            'at'=>dmdtk_now(),
            'central_ticket_id'=>(string)($decoded['ticket']['central_ticket_uid'] ?? ''),
            'central_status'=>(string)($decoded['ticket']['status'] ?? ''),
            'central_updated_at'=>(string)($decoded['ticket']['updated_at'] ?? '')
        );
    }
}

if (!function_exists('dmdtk_domyco_upload_one')) {
    function dmdtk_domyco_upload_one($ticket, $messageUid, $attachment, $path) {
        if (!function_exists('curl_init') || !class_exists('CURLFile')) return array('ok'=>false,'error'=>'curl_file_unavailable');
        $instanceUid = dmdtk_domydesk_id();
        if ($instanceUid === '') return array('ok'=>false,'error'=>'instance_uid_missing');
        $name = trim((string)($attachment['name'] ?? basename($path)));
        if ($name === '') $name = basename($path);
        $mime = function_exists('mime_content_type') ? (string)@mime_content_type($path) : 'application/octet-stream';
        if ($mime === '') $mime = 'application/octet-stream';
        $ch = curl_init(dmdtk_domyco_endpoint());
        if (!$ch) return array('ok'=>false,'error'=>'curl_init_failed');
        $post = array(
            'type'=>'ticketing_attachment',
            'instance_uid'=>$instanceUid,
            'local_ticket_id'=>(string)($ticket['id'] ?? ''),
            'message_uid'=>(string)$messageUid,
            'original_name'=>$name,
            'local_url'=>(string)($attachment['local_url'] ?? $attachment['url'] ?? ''),
            'file'=>new CURLFile($path, $mime, $name)
        );
        curl_setopt_array($ch, array(
            CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>$post,
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_CONNECTTIMEOUT=>5,
            CURLOPT_TIMEOUT=>45,
            CURLOPT_HTTPHEADER=>array('Accept: application/json'),
            CURLOPT_USERAGENT=>'DMD-Ticketing/2.0'
        ));
        $body = (string)curl_exec($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = (string)curl_error($ch);
        curl_close($ch);
        $decoded = json_decode($body, true);
        if (!is_array($decoded)) $decoded = array();
        if ($http < 200 || $http >= 300 || empty($decoded['success'])) {
            return array('ok'=>false,'http_code'=>$http,'error'=>$error !== '' ? $error : (string)($decoded['message'] ?? 'upload_failed'));
        }
        return array('ok'=>true,'http_code'=>$http,'attachment'=>is_array($decoded['attachment'] ?? null) ? $decoded['attachment'] : array());
    }
}

if (!function_exists('dmdtk_domyco_upload_pending_attachments')) {
    function dmdtk_domyco_upload_pending_attachments($ticket) {
        $uploaded = array(); $errors = array();
        $remote = isset($ticket['meta']['remotes']['domyco']) && is_array($ticket['meta']['remotes']['domyco']) ? $ticket['meta']['remotes']['domyco'] : array();
        $already = array();
        foreach ((array)($remote['uploaded_local_urls'] ?? array()) as $key) $already[(string)$key] = true;
        foreach ((array)($ticket['messages'] ?? array()) as $message) {
            if (!is_array($message) || (string)($message['role'] ?? '') === 'domydesk') continue;
            $messageUid = trim((string)($message['id'] ?? $message['message_uid'] ?? ''));
            if ($messageUid === '') continue;
            foreach ((array)($message['attachments'] ?? array()) as $attachment) {
                if (!is_array($attachment)) continue;
                $localUrl = (string)($attachment['local_url'] ?? $attachment['url'] ?? '');
                $uploadKey = $messageUid . '|' . $localUrl;
                if (isset($already[$uploadKey])) continue;
                $path = dmdtk_domyco_attachment_path($ticket, $attachment);
                if ($path === '') {
                    $errors[] = array('message_uid'=>$messageUid,'local_url'=>$localUrl,'error'=>'local_file_not_found');
                    continue;
                }
                $result = dmdtk_domyco_upload_one($ticket, $messageUid, $attachment, $path);
                if (!empty($result['ok'])) {
                    $uploaded[] = $uploadKey;
                    $already[$uploadKey] = true;
                } else {
                    $errors[] = array('message_uid'=>$messageUid,'local_url'=>$localUrl,'http_code'=>(int)($result['http_code'] ?? 0),'error'=>(string)($result['error'] ?? 'upload_failed'));
                }
            }
        }
        return array('uploaded_keys'=>$uploaded,'errors'=>$errors);
    }
}

if (!function_exists('dmdtk_domyco_apply_auto_relay_result')) {
    function dmdtk_domyco_apply_auto_relay_result(&$ticket, $result, $reason) {
        if (!is_array($ticket)) return;
        if (!isset($ticket['meta']) || !is_array($ticket['meta'])) $ticket['meta'] = array();
        if (!isset($ticket['meta']['remotes']) || !is_array($ticket['meta']['remotes'])) $ticket['meta']['remotes'] = array();
        $remote = isset($ticket['meta']['remotes']['domyco']) && is_array($ticket['meta']['remotes']['domyco']) ? $ticket['meta']['remotes']['domyco'] : array();
        $remote['requested'] = true;
        $remote['target'] = 'domyco';
        $remote['target_name'] = 'DoMyCo';
        $remote['status'] = (string)($result['status'] ?? 'pending');
        $remote['at'] = (string)($result['at'] ?? dmdtk_now());
        $remote['auto_relay_reason'] = (string)$reason;
        $remote['last_auto_relay_at'] = (string)($result['at'] ?? dmdtk_now());
        foreach (array('http_code','central_ticket_id','central_status','central_updated_at') as $key) {
            if (isset($result[$key]) && $result[$key] !== '') $remote[$key] = $result[$key];
        }
        if (!empty($result['error'])) $remote['error'] = (string)$result['error']; else unset($remote['error']);

        $uploaded = array();
        foreach ((array)($remote['uploaded_local_urls'] ?? array()) as $key) $uploaded[(string)$key] = true;
        foreach ((array)($result['uploaded_keys'] ?? array()) as $key) $uploaded[(string)$key] = true;
        $remote['uploaded_local_urls'] = array_keys($uploaded);
        if (!empty($result['attachment_errors'])) $remote['attachment_errors'] = $result['attachment_errors']; else unset($remote['attachment_errors']);

        $ticket['meta']['remotes']['domyco'] = $remote;
        $ticket['meta']['domydesk'] = $remote;
        if (!isset($ticket['meta']['escalation']) || !is_array($ticket['meta']['escalation'])) $ticket['meta']['escalation'] = array();
        $ticket['meta']['escalation']['requested'] = true;
        if (($result['status'] ?? '') === 'sent') $ticket['meta']['escalation']['last_sync_at'] = (string)($result['at'] ?? dmdtk_now());
        if (!empty($result['central_ticket_id'])) $ticket['meta']['escalation']['domyco_ticket_id'] = (string)$result['central_ticket_id'];
        $ticket['send_to_domydesk'] = true;
        $targets = isset($ticket['remote_targets']) && is_array($ticket['remote_targets']) ? $ticket['remote_targets'] : array();
        if (!in_array('domyco', $targets, true)) $targets[] = 'domyco';
        $ticket['remote_targets'] = array_values($targets);
    }
}

if (!function_exists('dmdtk_domyco_auto_relay_by_ticket_id')) {
    function dmdtk_domyco_auto_relay_by_ticket_id($ticketId, $reason) {
        list($snapshot) = dmdtk_ticket_read((string)$ticketId);
        if (!is_array($snapshot) || !$snapshot || !dmdtk_domyco_ticket_escalated($snapshot)) {
            return array('status'=>'skipped','reason'=>'not_escalated','at'=>dmdtk_now());
        }

        $result = dmdtk_domyco_post_ticket($snapshot);
        $attachmentResult = array('uploaded_keys'=>array(),'errors'=>array());
        /* Les PJ ne sont envoyées que lorsque DoMyCo a confirmé l'upsert. En cas
           de timeout, le moteur de synchro normal retentera sans bloquer le Client. */
        if (!empty($result['ok'])) $attachmentResult = dmdtk_domyco_upload_pending_attachments($snapshot);
        $result['uploaded_keys'] = $attachmentResult['uploaded_keys'];
        $result['attachment_errors'] = $attachmentResult['errors'];
        if (!empty($attachmentResult['errors'])) {
            $result['status'] = 'pending';
            $result['reason'] = 'attachments_upload_failed';
        }

        /* Relire juste avant la sauvegarde pour ne pas écraser une réponse Support
           ajoutée pendant l'appel réseau DoMyCo. On ne fusionne que la méta relais. */
        list($latest) = dmdtk_ticket_read((string)$ticketId);
        if (is_array($latest) && $latest) {
            dmdtk_domyco_apply_auto_relay_result($latest, $result, $reason);
            dmdtk_ticket_write($latest);
        }
        return $result;
    }
}

if (!function_exists('dmdtk_migrate_legacy')) {
    function dmdtk_migrate_legacy() {
        $marker = dmdtk_migration_file();
        if (is_file($marker)) return dmdtk_read_json($marker, array('done' => true));

        $legacyRoot = dmdtk_root() . '/modules/ticketing';
        $report = array('done' => true, 'at' => dmdtk_now(), 'source' => $legacyRoot, 'config' => false, 'outbox' => false, 'tickets' => 0, 'errors' => array());
        if (!is_dir($legacyRoot)) {
            dmdtk_write_json($marker, $report);
            return $report;
        }

        $legacyConfig = $legacyRoot . '/config.json';
        if (is_file($legacyConfig) && !is_file(dmdtk_config_file())) {
            $cfg = dmdtk_read_json($legacyConfig, array());
            if ($cfg && dmdtk_write_json(dmdtk_config_file(), $cfg)) $report['config'] = true;
        }
        $legacyOutbox = $legacyRoot . '/domydesk_outbox.json';
        if (is_file($legacyOutbox) && !is_file(dmdtk_outbox_file())) {
            $queue = dmdtk_read_json($legacyOutbox, array());
            if (dmdtk_write_json(dmdtk_outbox_file(), $queue)) $report['outbox'] = true;
        }

        $legacyTickets = $legacyRoot . '/tickets';
        if (is_dir($legacyTickets)) {
            foreach ((array)@scandir($legacyTickets) as $ownerFolder) {
                if ($ownerFolder === '.' || $ownerFolder === '..' || $ownerFolder === '' || $ownerFolder[0] === '.') continue;
                $ownerDir = $legacyTickets . '/' . $ownerFolder;
                if (!is_dir($ownerDir)) continue;
                foreach ((array)glob($ownerDir . '/*.json') as $file) {
                    $ticket = dmdtk_read_json($file, array());
                    if (!$ticket || empty($ticket['id']) || empty($ticket['owner'])) continue;
                    $owner = (string)$ticket['owner'];
                    $newFiles = dmdtk_files_dir($owner, (string)$ticket['id'], true);
                    $legacyFiles = $ownerDir . '/files/' . (string)$ticket['id'];
                    if ($newFiles !== '') dmdtk_rewrite_legacy_attachments($ticket, $legacyFiles, $newFiles);
                    if (dmdtk_ticket_write($ticket)) $report['tickets']++;
                    else $report['errors'][] = 'Impossible de migrer ' . (string)$ticket['id'];
                }
            }
        }

        dmdtk_write_json($marker, $report);
        return $report;
    }
}

/* Initialise les espaces nécessaires, puis migre l'ancien module si présent. */
dmdtk_system_root(true);
if (!is_file(dmdtk_index_file())) dmdtk_write_json(dmdtk_index_file(), array());
dmdtk_migrate_legacy();
if (!is_file(dmdtk_outbox_file())) dmdtk_write_json(dmdtk_outbox_file(), array());
