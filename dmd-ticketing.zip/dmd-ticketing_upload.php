<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

$me = dmdtk_user_email();
if ($me === '') { http_response_code(401); echo json_encode(array('ok'=>false,'err'=>'not_logged')); exit; }
if (!dmdtk_has_module_access($me) || !dmdtk_user_can($me, 'attachment.upload')) { http_response_code(403); echo json_encode(array('ok'=>false,'err'=>'forbidden')); exit; }
if (!dmdtk_csrf_valid(isset($_POST['csrf']) ? (string)$_POST['csrf'] : '')) { http_response_code(403); echo json_encode(array('ok'=>false,'err'=>'csrf_invalid')); exit; }

$id = trim((string)(isset($_POST['ticket_id']) ? $_POST['ticket_id'] : ''));
if ($id === '') { echo json_encode(array('ok'=>false,'err'=>'missing_id')); exit; }
list($ticket, $path, $owner) = dmdtk_ticket_read($id);
if (!is_array($ticket) || !$ticket) { echo json_encode(array('ok'=>false,'err'=>'not_found')); exit; }
if (!dmdtk_can_access_ticket($ticket, $me)) { http_response_code(403); echo json_encode(array('ok'=>false,'err'=>'forbidden')); exit; }
if (($ticket['status'] ?? 'open') === 'closed') { echo json_encode(array('ok'=>false,'err'=>'closed')); exit; }

$files = isset($_FILES['files']) ? $_FILES['files'] : null;
if (!is_array($files) || empty($files['name'])) { echo json_encode(array('ok'=>false,'err'=>'no_files')); exit; }

$destDir = dmdtk_files_dir((string)$ticket['owner'], $id, true);
if ($destDir === '') { echo json_encode(array('ok'=>false,'err'=>'storage_unavailable')); exit; }
$allowedExt = array('jpg','jpeg','png','gif','webp','pdf','txt','log','csv','doc','docx','xls','xlsx','odt','ods');
$urls = array();
$count = is_array($files['name']) ? count($files['name']) : 0;

for ($i=0; $i<$count; $i++) {
    if ((int)($files['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) continue;
    $size = (int)($files['size'][$i] ?? 0);
    if ($size <= 0 || $size > 20 * 1024 * 1024) continue;
    $name = basename((string)$files['name'][$i]);
    $tmp = (string)($files['tmp_name'][$i] ?? '');
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if ($ext === '' || !in_array($ext, $allowedExt, true) || !is_uploaded_file($tmp)) continue;
    $base = preg_replace('~[^A-Za-z0-9._-]+~', '_', pathinfo($name, PATHINFO_FILENAME));
    if ($base === '') $base = 'fichier';
    $stored = date('YmdHis') . '-' . substr(bin2hex(random_bytes(4)),0,8) . '-' . $base . '.' . $ext;
    $target = $destDir . '/' . $stored;
    if (@move_uploaded_file($tmp, $target)) {
        @chmod($target, 0640);
        $urls[] = array(
            'name' => $name,
            'url' => dmdtk_file_url($id, $stored),
            'local_url' => dmdtk_file_url($id, $stored),
            'stored_name' => $stored,
            'stored_on' => 'domydesk',
            'size' => $size
        );
    }
}
if (!$urls) { echo json_encode(array('ok'=>false,'err'=>'move_failed_or_type_forbidden')); exit; }

if (!isset($ticket['messages']) || !is_array($ticket['messages']) || !$ticket['messages']) {
    $ticket['messages'] = array(array('id'=>'M-'.date('YmdHis').'-'.substr(bin2hex(random_bytes(4)),0,8),'at'=>dmdtk_now(),'by'=>$me,'role'=>((string)$ticket['owner']===$me?'owner':'shared'),'text'=>'Pièces jointes','attachments'=>$urls));
} else {
    $idx = count($ticket['messages']) - 1;
    if (empty($ticket['messages'][$idx]['id'])) $ticket['messages'][$idx]['id'] = 'M-'.date('YmdHis').'-'.substr(bin2hex(random_bytes(4)),0,8);
    if (!isset($ticket['messages'][$idx]['attachments']) || !is_array($ticket['messages'][$idx]['attachments'])) $ticket['messages'][$idx]['attachments'] = array();
    $ticket['messages'][$idx]['attachments'] = array_merge($ticket['messages'][$idx]['attachments'], $urls);
}
$ticket['updated_at'] = dmdtk_now();
if (!empty($ticket['send_to_domydesk']) || !empty($ticket['meta']['domydesk']['requested'])) {
    if (!isset($ticket['meta']) || !is_array($ticket['meta'])) $ticket['meta'] = array();
    $previous = isset($ticket['meta']['domydesk']) && is_array($ticket['meta']['domydesk']) ? $ticket['meta']['domydesk'] : array();
    $ticket['meta']['domydesk'] = array_merge($previous, array('requested'=>true,'status'=>'pending','reason'=>'local_attachment_pending','at'=>dmdtk_now()));
}
dmdtk_ticket_write($ticket);
dmdtk_log($me, 'attachment_upload', $id, 'success', array('count'=>count($urls)));
echo json_encode(array('ok'=>true,'files'=>$urls), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
