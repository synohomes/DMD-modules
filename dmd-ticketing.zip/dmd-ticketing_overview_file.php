<?php
/* Pièces jointes consultables depuis la vue globale, selon ses droits fins. */
require_once __DIR__ . '/dmd-ticketing_overview_lib.php';
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') { http_response_code(405); exit; }
$me = dmdtk_user_email();
if ($me === '' || !dmdtk_ov_can($me)) { http_response_code(403); exit('Accès refusé.'); }
$id = trim((string)($_GET['id'] ?? ''));
$file = (string)($_GET['file'] ?? '');
if (!preg_match('/^[A-Za-z0-9._-]{1,160}$/D', $id) || $file === '' || $file === '.' || $file === '..' || basename($file) !== $file) {
    http_response_code(400); exit('Demande invalide.');
}
list($ticket) = dmdtk_ticket_read($id);
if (!is_array($ticket) || !$ticket || !dmdtk_ov_ticket_visible($ticket, $me, dmdtk_ov_can($me, 'all'))) {
    http_response_code(404); exit('Fichier introuvable.');
}
$matched = null;
foreach ((array)($ticket['messages'] ?? array()) as $m) {
    if (!is_array($m)) continue;
    foreach ((array)($m['attachments'] ?? array()) as $a) {
        if (!is_array($a)) continue;
        if ((string)($a['stored_name'] ?? '') === $file) { $matched = $a; break 2; }
    }
}
if ($matched === null) { http_response_code(404); exit('Fichier introuvable.'); }
$path = dmdtk_attachment_file_path($ticket, $matched, $file);
if ($path === '' || !is_readable($path)) { http_response_code(404); exit('Fichier introuvable.'); }
$name = basename((string)($matched['name'] ?? $file));
if ($name === '' || $name === '.' || $name === '..') $name = $file;
// Toujours télécharger : ne jamais exécuter/afficher directement une pièce jointe active dans le navigateur.
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . str_replace(array('"', "\r", "\n", "\\"), '_', $name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
header('Content-Length: ' . (string)filesize($path));
header('X-Content-Type-Options: nosniff');
readfile($path);
