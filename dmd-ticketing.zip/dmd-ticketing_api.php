<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('X-Content-Type-Options: nosniff');
header('Content-Type: application/json; charset=utf-8');
error_reporting(0);

$me = dmdtk_user_email();
$role = dmdtk_system_role($me);
if ($me === '') { http_response_code(401); echo json_encode(array('ok'=>false,'err'=>'not_logged')); exit; }
if (!dmdtk_has_module_access($me)) { http_response_code(403); echo json_encode(array('ok'=>false,'err'=>'module_forbidden')); exit; }
$isAdmin = dmdtk_is_admin($me);
$csrf = dmdtk_csrf_token();
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

$root = __DIR__;
$ticketsRoot = null;
$indexFile = dmdtk_index_file();

function tk_read_json($f){ return dmdtk_read_json($f, array()); }
function tk_write_json($f,$d){ return dmdtk_write_json($f,$d); }
function tk_ensure_dir($d){ if(!is_dir($d)) @mkdir($d,0750,true); }
function tk_now(){ return date('c'); }
function tk_id(){ return 'T-'.date('Ymd-His').'-'.substr(bin2hex(random_bytes(3)),0,6); }
function tk_message_id(){ return 'M-'.date('YmdHis').'-'.substr(bin2hex(random_bytes(4)),0,8); }
function tk_clean($s){ return trim((string)$s); }
function tk_strlen($s){ return function_exists('mb_strlen') ? mb_strlen((string)$s, 'UTF-8') : strlen((string)$s); }
function tk_safe_user_dir($email){ return str_replace(['/', '\\', "\0"], '_', (string)$email); }
function tk_statuses(){ return ['open'=>'Ouvert','in_progress'=>'En cours','waiting'=>'En attente','resolved'=>'Résolu','closed'=>'Fermé']; }
function tk_status_label($st){ $all=tk_statuses(); return $all[$st] ?? $all['open']; }
function tk_status_valid($st){ return array_key_exists((string)$st, tk_statuses()); }
function tk_clean_array($arr){
  if(!is_array($arr)) return [];
  $out=[];
  foreach($arr as $v){ $v=trim((string)$v); if($v!=='' && !in_array($v,$out,true)) $out[]=$v; }
  return $out;
}
function tk_users($root){
  $users=array(); $roles=array();
  $base=dmdtk_profiles_root();
  foreach((array)@scandir($base) as $d){
    if($d==='.'||$d==='..'||!is_dir($base.'/'.$d)) continue;
    $j=dmdtk_profile($d);
    $email=trim((string)(isset($j['email'])?$j['email']:$d));
    if($email===''||isset($users[$email])) continue;
    $name=trim((string)(isset($j['prenom'])?$j['prenom']:'').' '.(string)(isset($j['nom'])?$j['nom']:''));
    if($name==='') $name=$email;
    $rm=trim((string)(isset($j['role_metier'])?$j['role_metier']:''));
    if($rm!==''&&!in_array($rm,$roles,true)) $roles[]=$rm;
    $users[$email]=array('email'=>$email,'label'=>$name.' — '.$email,'role_metier'=>$rm);
  }
  if(!isset($users[$GLOBALS['me']])) $users[$GLOBALS['me']]=array('email'=>$GLOBALS['me'],'label'=>$GLOBALS['me'],'role_metier'=>dmdtk_user_role_metier($GLOBALS['me']));
  uasort($users,function($a,$b){ return strcasecmp((string)$a['label'],(string)$b['label']); });
  sort($roles,SORT_NATURAL|SORT_FLAG_CASE);
  return array(array_values($users),$roles);
}
function tk_user_role_metier($email,$root){ return dmdtk_user_role_metier($email); }
function tk_share_recipients($share,$root){
  if(!is_array($share)) $share=[];
  list($users,$roles)=tk_users($root);
  $wantedUsers=tk_clean_array($share['users']??[]);
  $wantedRoles=tk_clean_array($share['roles']??[]);
  $all=!empty($share['all']);
  $out=[];
  foreach($users as $user){
    if(!is_array($user)) continue;
    $email=trim((string)($user['email']??''));
    if($email==='') continue;
    $roleMetier=trim((string)($user['role_metier']??''));
    $shared=$all
      || in_array($email,$wantedUsers,true)
      || ($roleMetier!=='' && in_array($roleMetier,$wantedRoles,true));
    if(!$shared) continue;
    if(!dmdtk_has_module_access($email)) continue;
    if(!in_array($email,$out,true)) $out[]=$email;
  }
  return $out;
}
function tk_notify_new_share_recipients($ticket,$beforeShare,$afterShare,$actor,$root){
  if(!function_exists('dmd_notify_user')) return 0;

  $before=tk_share_recipients($beforeShare,$root);
  $after=tk_share_recipients($afterShare,$root);
  $added=array_values(array_diff($after,$before));

  $owner=trim((string)($ticket['owner']??''));
  $actor=trim((string)$actor);
  $ticketId=trim((string)($ticket['id']??''));
  $title=trim((string)($ticket['title']??'Ticket'));
  $sent=0;

  foreach($added as $email){
    $email=trim((string)$email);
    if($email==='' || $email===$actor || $email===$owner) continue;

    $message='Le ticket « '.$title.' » vous a été partagé';
    if($actor!=='') $message.=' par '.$actor;
    $message.='.';

    $ok=dmd_notify_user(
      $email,
      'ticket_shared',
      'Un ticket a été partagé avec vous',
      $message,
      [
        'level'=>'info',
        'action_url'=>'dashboard.php',
        'action_label'=>'Ouvrir les tickets',
        'meta'=>[
          'scope'=>'ticketing',
          'module'=>'dmd-ticketing',
          'ticket_id'=>$ticketId,
          'owner'=>$owner,
          'shared_by'=>$actor
        ]
      ]
    );
    if($ok!==false) $sent++;
  }

  return $sent;
}
function tk_ticket_recipients($ticket,$root){
  $out=[];
  $owner=trim((string)($ticket['owner']??''));
  if($owner!=='' && dmdtk_has_module_access($owner)) $out[]=$owner;
  foreach(tk_share_recipients($ticket['share']??[],$root) as $email){
    $email=trim((string)$email);
    if($email!=='' && !in_array($email,$out,true)) $out[]=$email;
  }
  return $out;
}
function tk_notify_ticket_recipients($ticket,$actor,$type,$notificationTitle,$message,$root,$extraMeta=[]){
  if(!function_exists('dmd_notify_user')) return 0;

  $actor=trim((string)$actor);
  $ticketId=trim((string)($ticket['id']??''));
  $owner=trim((string)($ticket['owner']??''));
  $sent=0;

  foreach(tk_ticket_recipients($ticket,$root) as $email){
    $email=trim((string)$email);
    if($email==='' || ($actor!=='' && $email===$actor)) continue;

    $meta=[
      'scope'=>'ticketing',
      'module'=>'dmd-ticketing',
      'ticket_id'=>$ticketId,
      'owner'=>$owner
    ];
    if(is_array($extraMeta)) $meta=array_merge($meta,$extraMeta);

    $ok=dmd_notify_user(
      $email,
      (string)$type,
      (string)$notificationTitle,
      (string)$message,
      [
        'level'=>'info',
        'action_url'=>'dashboard.php',
        'action_label'=>'Ouvrir les tickets',
        'meta'=>$meta
      ]
    );
    if($ok!==false) $sent++;
  }

  return $sent;
}

function tk_notify_ticket_message($ticket,$actor,$root,$source='local'){
  $title=trim((string)($ticket['title']??'Ticket'));
  $actor=trim((string)$actor);
  if($source==='domyco' || $source==='support'){
    $remoteName=tk_remote_name($ticket);
    return tk_notify_ticket_recipients(
      $ticket,'','ticket_message','Nouveau message sur un ticket',
      'Le ticket « '.$title.' » a reçu une nouvelle réponse de '.$remoteName.'.',
      $root,['event'=>'message','source'=>$source]
    );
  }

  $from=$actor!==''?$actor:'un utilisateur';
  return tk_notify_ticket_recipients(
    $ticket,$actor,'ticket_message','Nouveau message sur un ticket',
    $from.' a ajouté un nouveau message au ticket « '.$title.' ».',
    $root,['event'=>'message','source'=>'local','author'=>$actor]
  );
}

function tk_notify_ticket_status($ticket,$actor,$root,$source='local'){
  $title=trim((string)($ticket['title']??'Ticket'));
  $status=tk_status_label((string)($ticket['status']??'open'));
  $actor=trim((string)$actor);
  $message='Le statut du ticket « '.$title.' » est maintenant « '.$status.' ».';
  if($source==='local' && $actor!=='') $message='Le statut du ticket « '.$title.' » a été modifié par '.$actor.' : « '.$status.' ».';

  return tk_notify_ticket_recipients(
    $ticket,$source==='local'?$actor:'','ticket_status','Statut du ticket modifié',
    $message,$root,['event'=>'status','source'=>$source,'status'=>(string)($ticket['status']??'open')]
  );
}

function tk_path($id,$ticketsRoot=null,$indexFile=null){ return dmdtk_ticket_path($id); }
function tk_can_access($t,$me,$isAdmin,$root){ return dmdtk_can_access_ticket($t,$me); }
function tk_can_manage($t,$me,$isAdmin){ return dmdtk_can_manage_ticket($t,$me); }
function tk_can_delete($t,$me,$isAdmin){ return dmdtk_can_delete_ticket($t,$me); }
function tk_share_text($s){
  if(!is_array($s)) $s=[]; $p=[];
  if(!empty($s['all'])) $p[]='Tous';
  if(!empty($s['users'])) $p[]=count($s['users']).' utilisateur(s)';
  if(!empty($s['roles'])) $p[]='Rôle : '.implode(', ',$s['roles']);
  return $p?implode(' · ',$p):'Privé';
}
function tk_last_message($t){
  $last=''; foreach(($t['messages']??[]) as $m){ if(trim((string)($m['text']??''))!=='') $last=(string)$m['text']; }
  return $last;
}
function tk_summary($t,$me,$isAdmin){
  $share=$t['share']??[]; if(!is_array($share)) $share=[];
  return [
    'id'=>$t['id']??'', 'title'=>$t['title']??'', 'status'=>$t['status']??'open', 'status_label'=>tk_status_label($t['status']??'open'),
    'category'=>$t['category']??'', 'priority'=>$t['priority']??'', 'owner'=>$t['owner']??'',
    'created_at'=>$t['created_at']??null, 'updated_at'=>$t['updated_at']??null, 'last_message'=>tk_last_message($t),
    'share'=>$share, 'share_text'=>tk_share_text($share), 'meta'=>$t['meta']??[], 'send_to_domydesk'=>!empty($t['send_to_domydesk']), 'remote_targets'=>isset($t['remote_targets'])&&is_array($t['remote_targets'])?array_values($t['remote_targets']):[],
    'can_manage'=>tk_can_manage($t,$me,$isAdmin), 'can_delete'=>tk_can_delete($t,$me,$isAdmin)
  ];
}

function tk_workflow_enrich_ticket(&$t,$me,$isAdmin){
  if(!is_array($t)) return;
  $workflow=dmdtk_ticket_workflow($t);
  $t['workflow']=$workflow;
  $t['incident_options']=[];
  $t['incident_related']=[];
  if(tk_can_manage($t,$me,$isAdmin) || (!empty($t['meta']['external']) && dmdtk_user_can($me,'ticket.status'))){
    foreach(dmdtk_incident_list(true) as $incident){
      if(!is_array($incident)) continue;
      $t['incident_options'][]=['id'=>(string)($incident['id']??''),'title'=>(string)($incident['title']??''),'status'=>(string)($incident['status']??'open'),'count'=>count((array)($incident['tickets']??[]))];
    }
    $incidentId=(string)($workflow['incident']['id']??'');
    if($incidentId!==''){
      $incident=dmdtk_incident_get($incidentId);
      foreach((array)($incident['tickets']??[]) as $ticketId){
        if((string)$ticketId===(string)($t['id']??'')) continue;
        list($related)=dmdtk_ticket_read((string)$ticketId);
        if(!is_array($related)||!$related) continue;
        $t['incident_related'][]=['id'=>(string)($related['id']??''),'title'=>(string)($related['title']??''),'status'=>(string)($related['status']??'open'),'client'=>(string)($related['meta']['external']['client_name']??'')];
      }
    }
  }
}
function tk_require_external_workflow_ticket($ticket){
  if(empty($ticket['meta']['external']) || !is_array($ticket['meta']['external'])){
    echo json_encode(['ok'=>false,'err'=>'external_ticket_required','message'=>'Cette fonction est réservée aux tickets reçus d’une entreprise cliente.'],JSON_UNESCAPED_UNICODE); exit;
  }
  if(!dmdtk_external_license_enabled()){
    echo json_encode(['ok'=>false,'err'=>'ticketing_support_license_required','message'=>'Une licence DMD-Ticketing Support active est requise.'],JSON_UNESCAPED_UNICODE); exit;
  }
}
function tk_workflow_cancel_pending_closure(&$ticket,$by,$newStatus){
  $workflow=dmdtk_ticket_workflow($ticket);
  if(($workflow['closure']['state']??'none')!=='requested') return;
  if((string)$newStatus==='resolved') return;
  $workflow['closure']['state']=(string)$newStatus==='closed'?'forced':'cancelled';
  $workflow['closure']['responded_at']=tk_now();
  $workflow['closure']['responded_by']=(string)$by;
  $workflow['closure']['comment']=(string)$newStatus==='closed'?'Fermeture effectuée sans validation client.':'Demande de validation annulée par changement de statut.';
  dmdtk_ticket_set_workflow($ticket,$workflow);
}

function tk_domydesk_endpoint(){ return 'https://register.synohomes.com/ticket.php'; }
function tk_remote_targets($ticket){
  $targets=[];
  $raw=$ticket['remote_targets']??[];
  if(is_array($raw)){
    foreach($raw as $target){
      $target=trim((string)$target);
      if(in_array($target,['support','domyco'],true) && !in_array($target,$targets,true)) $targets[]=$target;
    }
  }
  if(!$targets){
    $target=trim((string)($ticket['remote_target']??$ticket['meta']['domydesk']['target']??''));
    if(in_array($target,['support','domyco'],true)) $targets[]=$target;
    elseif(!empty($ticket['send_to_domydesk'])) $targets[]='domyco';
  }
  return $targets;
}
function tk_remote_target($ticket){
  $targets=tk_remote_targets($ticket);
  return $targets ? (string)$targets[0] : 'domyco';
}
function tk_support_endpoint($base,$port){
  $base=trim((string)$base); if($base==='') return '';
  if(!preg_match('~^https?://~i',$base)) $base='https://'.$base;
  $parts=@parse_url($base); if(!is_array($parts)||empty($parts['host'])) return $base;
  $scheme=strtolower((string)($parts['scheme']??'https'))==='http'?'http':'https';
  $host=(string)$parts['host'];
  $user=(string)($parts['user']??''); $pass=(string)($parts['pass']??'');
  $auth=$user!==''?$user.($pass!==''?':'.$pass:'').'@':'';
  $port=(int)$port; if($port<1||$port>65535) $port=(int)($parts['port']??($scheme==='http'?80:443));
  $portPart=(($scheme==='https'&&$port===443)||($scheme==='http'&&$port===80))?'':':'.$port;
  $path=(string)($parts['path']??'');
  if(stripos($path,'dmd-ticketing_external.php')===false){
    if(!preg_match('~\.php$~i',$path)) $path=rtrim($path,'/').'/modules/dmd-ticketing/dmd-ticketing_external.php';
  }
  if($path===''||$path[0]!=='/') $path='/'.ltrim($path,'/');
  return $scheme.'://'.$auth.$host.$portPart.$path;
}
function tk_remote_settings($ticket,$forcedTarget=''){
  $target=trim((string)$forcedTarget);
  if(!in_array($target,['support','domyco'],true)) $target=tk_remote_target($ticket);
  if($target==='support'){
    $cfg=dmdtk_config(); $s=(isset($cfg['external_support'])&&is_array($cfg['external_support']))?$cfg['external_support']:[];
    $endpoint=tk_support_endpoint((string)($s['endpoint']??''),(int)($s['port']??443));
    return [
      'target'=>'support',
      'name'=>trim((string)($s['name']??''))!==''?trim((string)$s['name']):'Support externe',
      'endpoint'=>$endpoint,
      'port'=>(int)($s['port']??443),
      'token'=>trim((string)($s['token']??'')),
      'client_key'=>trim((string)($s['client_key']??'')),
      'client_ref'=>trim((string)($s['client_ref']??'')),
      'enabled'=>!empty($s['enabled'])
    ];
  }
  return ['target'=>'domyco','name'=>'DoMyCo','endpoint'=>tk_domydesk_endpoint(),'port'=>443,'token'=>'','enabled'=>true];
}
function tk_remote_name($ticket,$forcedTarget=''){ $r=tk_remote_settings($ticket,$forcedTarget); return (string)$r['name']; }
function tk_domydesk_instance_uid($root){
  $file=$root.'/../../data/id_domydesk.txt';
  return is_file($file)?trim((string)@file_get_contents($file)):'';
}
function tk_domydesk_instance_context($root){
  $context=['instance_uid'=>tk_domydesk_instance_uid($root)];
  $registerFile=$root.'/../../data/domyco_register.json';
  if(is_file($registerFile)){
    $register=tk_read_json($registerFile);
    $payload=(isset($register['payload'])&&is_array($register['payload']))?$register['payload']:[];
    foreach(['instance_name','domain','install_url','version'] as $key){ if(isset($payload[$key])&&is_scalar($payload[$key])) $context[$key]=(string)$payload[$key]; }
  }
  return $context;
}

function tk_domydesk_attachment_local_path($root,$url,$ticket=null,$attachment=null){
  if(is_array($attachment) && !empty($attachment['stored_name']) && is_array($ticket)){
    $owner=(string)(isset($ticket['owner'])?$ticket['owner']:'');
    $id=(string)(isset($ticket['id'])?$ticket['id']:'');
    $dir=dmdtk_ticket_files_dir($ticket,false);
    if($dir!==''){
      $candidate=realpath($dir.'/'.basename((string)$attachment['stored_name']));
      $base=realpath($dir);
      if($candidate&&$base&&is_file($candidate)&&strpos($candidate,rtrim($base,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR)===0) return $candidate;
    }
  }
  /* Compatibilité des anciennes URLs modules/ticketing/tickets/... durant migration. */
  $path=(string)(parse_url((string)$url,PHP_URL_PATH));
  $path=ltrim(str_replace('\\','/',rawurldecode($path)),'/');
  if(strpos($path,'modules/ticketing/tickets/')===0){
    $candidate=realpath(dmdtk_root().'/'.$path);
    $legacy=realpath(dmdtk_root().'/modules/ticketing/tickets');
    if($candidate&&$legacy&&is_file($candidate)&&strpos($candidate,rtrim($legacy,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR)===0) return $candidate;
  }
  return '';
}
function tk_domydesk_upload_one_attachment($endpoint,$instanceUid,$ticketId,$messageUid,$attachment,$path,$token='',$clientKey=''){
  if(!function_exists('curl_init')||!class_exists('CURLFile')) return ['ok'=>false,'error'=>'curl_file_unavailable'];
  $name=trim((string)($attachment['name']??basename($path))); if($name==='') $name=basename($path);
  $mime=function_exists('mime_content_type')?(string)@mime_content_type($path):'application/octet-stream';
  if($mime==='') $mime='application/octet-stream';
  $ch=curl_init($endpoint); if(!$ch) return ['ok'=>false,'error'=>'curl_init_failed'];
  $post=[
    'type'=>'ticketing_attachment',
    'instance_uid'=>$instanceUid,
    'local_ticket_id'=>$ticketId,
    'message_uid'=>$messageUid,
    'original_name'=>$name,
    'local_url'=>(string)($attachment['url']??$attachment['local_url']??''),
    'support_token'=>(string)$token,
    'client_key'=>(string)$clientKey,
    'file'=>new CURLFile($path,$mime,$name)
  ];
  curl_setopt_array($ch,[
    CURLOPT_POST=>true,
    CURLOPT_POSTFIELDS=>$post,
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_CONNECTTIMEOUT=>5,
    CURLOPT_TIMEOUT=>45,
    CURLOPT_HTTPHEADER=>array_values(array_filter(['Accept: application/json',$token!==''?'X-DMD-Support-Token: '.$token:null,$clientKey!==''?'X-DMD-Client-Key: '.$clientKey:null])),
    CURLOPT_USERAGENT=>'DMD-Ticketing/2.0'
  ]);
  $body=(string)curl_exec($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=(string)curl_error($ch); curl_close($ch);
  $decoded=json_decode($body,true); if(!is_array($decoded)) $decoded=[];
  if($http<200||$http>=300||empty($decoded['success'])){
    return ['ok'=>false,'http_code'=>$http,'error'=>$err!==''?$err:(string)($decoded['message']??'upload_failed')];
  }
  return ['ok'=>true,'http_code'=>$http,'attachment'=>is_array($decoded['attachment']??null)?$decoded['attachment']:[]];
}
function tk_domydesk_upload_attachments($ticket,$root,$instanceUid,$endpoint,$token='',$clientKey='',$target=''){
  $uploaded=[]; $errors=[];
  $target=trim((string)$target);
  $remoteMeta=(isset($ticket['meta']['remotes'][$target])&&is_array($ticket['meta']['remotes'][$target]))?$ticket['meta']['remotes'][$target]:[];
  $already=[];
  foreach((array)($remoteMeta['uploaded_local_urls']??[]) as $key){ $already[(string)$key]=true; }
  $hasPerTargetMeta=$target!=='' && isset($ticket['meta']['remotes'][$target]);
  foreach((array)($ticket['messages']??[]) as $message){
    if(!is_array($message)) continue;
    if((string)($message['role']??'')==='domydesk') continue;
    $messageUid=trim((string)($message['id']??$message['message_uid']??'')); if($messageUid==='') continue;
    foreach((array)($message['attachments']??[]) as $attachment){
      if(!is_array($attachment)) continue;
      $localUrl=(string)($attachment['local_url']??$attachment['url']??'');
      $uploadKey=$messageUid.'|'.$localUrl;
      if(isset($already[$uploadKey])) continue;
      if(!$hasPerTargetMeta && (!empty($attachment['central_url'])||in_array((string)($attachment['stored_on']??''),['domycocenter','support_provider'],true))) continue;
      $path=tk_domydesk_attachment_local_path($root,$localUrl,$ticket,$attachment);
      if($path===''){
        $errors[]=['message_uid'=>$messageUid,'local_url'=>$localUrl,'error'=>'local_file_not_found'];
        continue;
      }
      $result=tk_domydesk_upload_one_attachment(
        $endpoint,$instanceUid,(string)($ticket['id']??''),$messageUid,$attachment,$path,$token,$clientKey
      );
      if(!empty($result['ok'])){
        $uploaded[]=[
          'message_uid'=>$messageUid,
          'local_url'=>$localUrl,
          'upload_key'=>$uploadKey,
          'attachment'=>$result['attachment']
        ];
      }else{
        $errors[]=[
          'message_uid'=>$messageUid,
          'local_url'=>$localUrl,
          'http_code'=>(int)($result['http_code']??0),
          'error'=>(string)($result['error']??'upload_failed')
        ];
      }
    }
  }
  return ['uploaded'=>$uploaded,'errors'=>$errors];
}

function tk_domydesk_remote_attachment_url($ticket,$attachment,$target=''){
  if(!is_array($attachment)) return '';
  $raw='';
  foreach(['central_url','remote_url','url','local_url'] as $key){
    $candidate=trim((string)($attachment[$key]??''));
    if($candidate!==''){ $raw=$candidate; break; }
  }
  if($raw==='') return '';
  if(preg_match('~^https?://~i',$raw)) return $raw;

  $remote=tk_remote_settings($ticket,$target);
  $endpoint=trim((string)($remote['endpoint']??''));
  $parts=@parse_url($endpoint);
  if(!is_array($parts)||empty($parts['host'])) return '';
  $scheme=strtolower((string)($parts['scheme']??'https'))==='http'?'http':'https';
  $host=(string)$parts['host'];
  $port=(int)($parts['port']??($scheme==='http'?80:443));
  $portPart=(($scheme==='https'&&$port===443)||($scheme==='http'&&$port===80))?'':':'.$port;
  if(strpos($raw,'/')===0) return $scheme.'://'.$host.$portPart.$raw;
  $basePath=(string)($parts['path']??'/');
  $baseDir=rtrim(str_replace('\\','/',dirname($basePath)),'/');
  return $scheme.'://'.$host.$portPart.($baseDir!==''?$baseDir:'').'/'.ltrim($raw,'/');
}
function tk_domydesk_remote_attachment_url_allowed($url,$ticket,$target=''){
  $urlParts=@parse_url((string)$url);
  $remote=tk_remote_settings($ticket,$target);
  $endpointParts=@parse_url((string)($remote['endpoint']??''));
  if(!is_array($urlParts)||!is_array($endpointParts)||empty($urlParts['host'])||empty($endpointParts['host'])) return false;
  $scheme=strtolower((string)($urlParts['scheme']??''));
  $remoteScheme=strtolower((string)($endpointParts['scheme']??''));
  if(!in_array($scheme,['http','https'],true) || $scheme!==$remoteScheme) return false;
  if(strtolower((string)$urlParts['host'])!==strtolower((string)$endpointParts['host'])) return false;
  $port=(int)($urlParts['port']??($scheme==='http'?80:443));
  $remotePort=(int)($endpointParts['port']??($remoteScheme==='http'?80:443));
  return $port===$remotePort;
}
function tk_domydesk_cache_remote_attachment($ticket,$attachment,$target,$messageUid){
  if(!is_array($attachment)||!is_array($ticket)||empty($ticket['id'])) return is_array($attachment)?$attachment:[];
  $storedOn=(string)($attachment['stored_on']??'');
  $existingStored=basename((string)($attachment['stored_name']??''));
  if($storedOn==='remote_cache' && $existingStored!==''){
    $dir=dmdtk_remote_files_dir((string)$ticket['id'],false);
    if($dir!=='' && is_file($dir.'/'.$existingStored)){
      $local=dmdtk_file_url((string)$ticket['id'],$existingStored);
      $attachment['url']=$local;
      $attachment['local_url']=$local;
      return $attachment;
    }
  }

  $remoteUrl=tk_domydesk_remote_attachment_url($ticket,$attachment,$target);
  if($remoteUrl==='') return $attachment;
  /* Ne télécharge que depuis le serveur distant configuré : pas d'URL arbitraire. */
  if(!tk_domydesk_remote_attachment_url_allowed($remoteUrl,$ticket,$target)){
    $attachment['url']=$remoteUrl;
    $attachment['local_url']=$remoteUrl;
    $attachment['central_url']=$remoteUrl;
    $attachment['remote_url']=$remoteUrl;
    $attachment['remote_cache_error']='remote_origin_mismatch';
    return $attachment;
  }

  $name=basename(trim((string)($attachment['name']??'fichier')));
  if($name===''||$name==='.'||$name==='..') $name='fichier';
  $safe=preg_replace('~[^A-Za-z0-9._-]+~u','_',$name);
  if($safe==='') $safe='fichier';
  $hash=substr(hash('sha256',(string)$target.'|'.(string)$messageUid.'|'.$remoteUrl.'|'.$name),0,20);
  $stored='REMOTE-'.$hash.'-'.$safe;
  $dir=dmdtk_remote_files_dir((string)$ticket['id'],true);
  if($dir===''){
    $attachment['url']=$remoteUrl; $attachment['local_url']=$remoteUrl; $attachment['central_url']=$remoteUrl; $attachment['remote_url']=$remoteUrl;
    $attachment['remote_cache_error']='storage_unavailable';
    return $attachment;
  }
  $dest=$dir.'/'.$stored;
  $ok=is_file($dest) && (int)@filesize($dest)>0;
  $error='';
  $maxBytes=20*1024*1024;

  if(!$ok){
    $tmp=$dest.'.part-'.substr(bin2hex(random_bytes(3)),0,6);
    if(function_exists('curl_init')){
      $fh=@fopen($tmp,'wb');
      if($fh){
        $written=0; $tooLarge=false;
        $ch=curl_init($remoteUrl);
        if($ch){
          curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>false,
            CURLOPT_CONNECTTIMEOUT=>5,
            CURLOPT_TIMEOUT=>45,
            CURLOPT_FOLLOWLOCATION=>false,
            CURLOPT_HTTPHEADER=>['Accept: application/octet-stream'],
            CURLOPT_USERAGENT=>'DMD-Ticketing/2.0',
            CURLOPT_WRITEFUNCTION=>function($ch,$data) use ($fh,&$written,&$tooLarge,$maxBytes){
              $len=strlen($data);
              if(($written+$len)>$maxBytes){ $tooLarge=true; return 0; }
              $n=fwrite($fh,$data);
              if($n===false) return 0;
              $written+=$n;
              return $n;
            }
          ]);
          $curlOk=curl_exec($ch);
          $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);
          $curlErr=(string)curl_error($ch);
          curl_close($ch);
          fclose($fh);
          if($tooLarge) $error='remote_file_too_large';
          elseif($curlOk!==false && $http>=200 && $http<300 && is_file($tmp) && (int)@filesize($tmp)>0 && (int)@filesize($tmp)<=$maxBytes){
            $ok=@rename($tmp,$dest);
            if(!$ok) $error='remote_file_move_failed';
          } else {
            $error=$curlErr!==''?$curlErr:'remote_file_http_'.$http;
          }
        } else { fclose($fh); $error='curl_init_failed'; }
      } else $error='remote_temp_unavailable';
    } else {
      $ctx=stream_context_create(['http'=>['method'=>'GET','timeout'=>20,'ignore_errors'=>true,'header'=>"Accept: application/octet-stream\r\nUser-Agent: DMD-Ticketing/2.0\r\n"]]);
      $data=@file_get_contents($remoteUrl,false,$ctx,0,$maxBytes+1);
      if(is_string($data) && strlen($data)>0 && strlen($data)<=$maxBytes){ $ok=@file_put_contents($tmp,$data,LOCK_EX)!==false && @rename($tmp,$dest); if(!$ok) $error='remote_file_write_failed'; }
      else $error=is_string($data)&&strlen($data)>$maxBytes?'remote_file_too_large':'remote_file_download_failed';
    }
    if(is_file($tmp)) @unlink($tmp);
  }

  if($ok && is_file($dest)){
    @chmod($dest,0640);
    $local=dmdtk_file_url((string)$ticket['id'],$stored);
    $attachment['name']=$name;
    $attachment['stored_name']=$stored;
    $attachment['stored_on']='remote_cache';
    $attachment['remote_url']=$remoteUrl;
    $attachment['central_url']=$remoteUrl;
    $attachment['url']=$local;
    $attachment['local_url']=$local;
    $attachment['size']=(int)@filesize($dest);
    if(function_exists('mime_content_type')){
      $mime=(string)@mime_content_type($dest);
      if($mime!=='') $attachment['mime']=$mime;
    }
    unset($attachment['remote_cache_error']);
    return $attachment;
  }

  /* En cas d'échec du cache, l'URL distante signée reste utilisable. */
  $attachment['url']=$remoteUrl;
  $attachment['local_url']=$remoteUrl;
  $attachment['central_url']=$remoteUrl;
  $attachment['remote_url']=$remoteUrl;
  $attachment['remote_cache_error']=$error!==''?$error:'remote_file_download_failed';
  return $attachment;
}
function tk_domydesk_cache_remote_attachments($ticket,$attachments,$target,$messageUid){
  $out=[];
  foreach((array)$attachments as $attachment){
    if(!is_array($attachment)) continue;
    $out[]=tk_domydesk_cache_remote_attachment($ticket,$attachment,$target,$messageUid);
  }
  return $out;
}

function tk_outbox_mutate($callback){
  $lock=dmdtk_system_root(true).'/outbox.lock'; $fh=@fopen($lock,'c+'); if(!$fh) return false; $ok=false;
  if(@flock($fh,LOCK_EX)){
    $queue=dmdtk_read_json(dmdtk_outbox_file(),array()); if(!is_array($queue)) $queue=array();
    $next=call_user_func($callback,$queue); if(is_array($next)) $queue=$next;
    $ok=dmdtk_write_json(dmdtk_outbox_file(),$queue); @flock($fh,LOCK_UN);
  }
  @fclose($fh); @chmod($lock,0640); return $ok;
}
function tk_queue_domydesk_ticket($root,$payload){
  $ticketId=(string)($payload['ticket']['id']??'');
  $target=(string)($payload['remote_target']??'domyco');
  tk_outbox_mutate(function($queue) use ($ticketId,$target,$payload){
    $filtered=array();
    foreach($queue as $row){
      if(!is_array($row)) continue;
      $queuedId=(string)($row['payload']['ticket']['id']??'');
      $queuedTarget=(string)($row['payload']['remote_target']??'domyco');
      if($ticketId!==''&&$queuedId===$ticketId&&$queuedTarget===$target) continue;
      $filtered[]=$row;
    }
    $filtered[]=array('queued_at'=>tk_now(),'payload'=>$payload); return $filtered;
  });
}
function tk_clear_queued_domydesk_ticket($root,$ticketId,$target=''){
  tk_outbox_mutate(function($queue) use ($ticketId,$target){
    $filtered=array();
    foreach($queue as $row){
      $queuedId=(string)($row['payload']['ticket']['id']??'');
      $queuedTarget=(string)($row['payload']['remote_target']??'domyco');
      if($queuedId===(string)$ticketId && ($target==='' || $queuedTarget===(string)$target)) continue;
      $filtered[]=$row;
    }
    return $filtered;
  });
}

function tk_send_ticket_to_domydesk($ticket,$root,$event='upsert',$forcedTarget=''){
  $instance=tk_domydesk_instance_context($root); $instanceUid=trim((string)($instance['instance_uid']??''));
  if($instanceUid==='') return ['status'=>'pending','reason'=>'instance_uid_missing','at'=>tk_now()];
  $remote=tk_remote_settings($ticket,$forcedTarget); $endpoint=trim((string)($remote['endpoint']??'')); $token=trim((string)($remote['token']??'')); $clientKey=trim((string)($remote['client_key']??''));
  if(($remote['target']??'')==='support' && (empty($remote['enabled']) || $endpoint==='' || $token==='' || $clientKey==='')) return ['status'=>'pending','reason'=>'support_not_configured','error'=>'Aucune liaison Support valide n’est importée.','at'=>tk_now()];
  $target=(string)($remote['target']??'domyco');
  $ticketPayload=$ticket;
  if(isset($ticketPayload['messages'])&&is_array($ticketPayload['messages'])){
    $ticketPayload['messages']=array_values(array_filter($ticketPayload['messages'],function($message) use ($target){
      if(!is_array($message)) return false;
      if((string)($message['role']??'')!=='domydesk') return true;
      $messageTarget=(string)($message['remote_target']??'');
      return $messageTarget==='' || $messageTarget===$target;
    }));
  }
  $payload=['type'=>'ticketing_ticket','event'=>$event,'sent_at'=>tk_now(),'instance_uid'=>$instanceUid,'instance'=>$instance,'remote_target'=>$target,'ticket'=>$ticketPayload];
  if($target==='domyco' && !empty($ticket['meta']['escalation']) && is_array($ticket['meta']['escalation'])){
    $payload['escalation']=$ticket['meta']['escalation'];
  }
  $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  $ok=false; $http=0; $err=''; $responseBody='';
  if(function_exists('curl_init')){
    $ch=curl_init($endpoint);
    if($ch){
      curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$json,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>8,CURLOPT_HTTPHEADER=>array_values(array_filter(['Content-Type: application/json','Accept: application/json',$token!==''?'X-DMD-Support-Token: '.$token:null,$clientKey!==''?'X-DMD-Client-Key: '.$clientKey:null])),CURLOPT_USERAGENT=>'DMD-Ticketing/2.0']);
      $responseBody=(string)curl_exec($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=(string)curl_error($ch); curl_close($ch);
      $ok=($http>=200&&$http<300);
    }
  }else{
    $header="Content-Type: application/json\r\nAccept: application/json\r\nUser-Agent: DMD-Ticketing/2.0\r\n".($token!==''?"X-DMD-Support-Token: ".$token."\r\n":'').($clientKey!==''?"X-DMD-Client-Key: ".$clientKey."\r\n":'');
    $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>$header,'content'=>$json,'timeout'=>8,'ignore_errors'=>true]]);
    $res=@file_get_contents($endpoint,false,$ctx); $responseBody=$res===false?'':(string)$res;
    if(isset($http_response_header)&&is_array($http_response_header)) foreach($http_response_header as $h){ if(preg_match('#HTTP/\\S+\\s+(\\d+)#',$h,$m)){ $http=(int)$m[1]; break; } }
    $ok=($res!==false&&$http>=200&&$http<300);
  }
  $decoded=json_decode($responseBody,true); if(!is_array($decoded)) $decoded=[];
  if(!$ok||empty($decoded['success'])){
    $remoteError=(string)($decoded['error']??'');
    if(in_array($remoteError,['CLIENT_NOT_REGISTERED','CLIENT_REVOKED','CLIENT_TOKEN_INVALID','CLIENT_NOT_ACTIVE','CLIENT_IDENTITY_REQUIRED'],true)){
      return ['status'=>'blocked','reason'=>strtolower($remoteError),'http_code'=>$http,'error'=>(string)($decoded['message']??'Liaison avec l’entreprise de support refusée.'),'at'=>tk_now()];
    }
    if($event==='pull' && $http===404 && (string)($decoded['error']??'')==='TICKET_NOT_FOUND'){
      return ['status'=>'remote_missing','reason'=>'remote_not_found','http_code'=>$http,'error'=>(string)($decoded['message']??'Ticket distant introuvable.'),'at'=>tk_now()];
    }
    if($event!=='pull') tk_queue_domydesk_ticket($root,$payload);
    return ['status'=>'pending','reason'=>'send_failed','http_code'=>$http,'error'=>$err!==''?$err:(string)($decoded['message']??''),'at'=>tk_now()];
  }
  $attachmentSync=['uploaded'=>[],'errors'=>[]];
  if($event==='upsert'){
    $attachmentSync=tk_domydesk_upload_attachments($ticket,$root,$instanceUid,$endpoint,$token,$clientKey,(string)($remote['target']??''));
  }
  $common=[
    'http_code'=>$http,'at'=>tk_now(),
    'central_ticket_id'=>(string)($decoded['ticket']['central_ticket_uid']??''),
    'central_status'=>(string)($decoded['ticket']['status']??''),
    'central_updated_at'=>(string)($decoded['ticket']['updated_at']??''),
    'central_messages'=>isset($decoded['central_messages'])&&is_array($decoded['central_messages'])?$decoded['central_messages']:[],
    'remote_deleted'=>!empty($decoded['deleted']) || !empty($decoded['ticket']['deleted']),
    'deleted_at'=>(string)($decoded['ticket']['deleted_at']??''),
    'deleted_by'=>(string)($decoded['ticket']['deleted_by']??''),
    'workflow'=>isset($decoded['ticket']['workflow'])&&is_array($decoded['ticket']['workflow'])?$decoded['ticket']['workflow']:[],
    'uploaded_attachments'=>$attachmentSync['uploaded']
  ];
  if(!empty($attachmentSync['errors'])){
    tk_queue_domydesk_ticket($root,$payload);
    return array_merge($common,[
      'status'=>'pending',
      'reason'=>'attachments_upload_failed',
      'attachment_errors'=>$attachmentSync['errors']
    ]);
  }
  tk_clear_queued_domydesk_ticket($root,(string)($ticket['id']??''),(string)($remote['target']??''));
  return array_merge($common,['status'=>'sent']);
}
function tk_domydesk_requested($ticket){
  return count(tk_remote_targets($ticket))>0 || !empty($ticket['meta']['domydesk']['requested']) || !empty($ticket['send_to_domydesk']);
}
function tk_apply_domydesk_result(&$ticket,$result,$forcedTarget=''){
  if(!isset($ticket['meta'])||!is_array($ticket['meta'])) $ticket['meta']=[];
  if(!isset($ticket['meta']['remotes'])||!is_array($ticket['meta']['remotes'])) $ticket['meta']['remotes']=[];
  $targets=tk_remote_targets($ticket);
  $target=trim((string)$forcedTarget);
  if(!in_array($target,['support','domyco'],true)) $target=$targets ? (string)$targets[0] : tk_remote_target($ticket);
  $remoteName=tk_remote_name($ticket,$target);
  $isMulti=count($targets)>1;

  $previous=(isset($ticket['meta']['remotes'][$target])&&is_array($ticket['meta']['remotes'][$target]))?$ticket['meta']['remotes'][$target]:[];
  if(!$previous && isset($ticket['meta']['domydesk']) && is_array($ticket['meta']['domydesk']) && (string)($ticket['meta']['domydesk']['target']??'')===$target){
    $previous=$ticket['meta']['domydesk'];
  }
  $previousNotification=(isset($previous['notification'])&&is_array($previous['notification']))?$previous['notification']:[];
  $beforeStatus=(string)($ticket['status']??'open');

  $knownCentral=[];
  foreach((array)($ticket['messages']??[]) as $message){
    if(!is_array($message)||((string)($message['role']??''))!=='domydesk') continue;
    $messageTarget=(string)($message['remote_target']??'');
    if($messageTarget!=='' && $messageTarget!==$target) continue;
    $mid=(string)($message['id']??'');
    if($mid!=='') $knownCentral[$mid]=true;
  }

  $meta=['requested'=>true,'target'=>$target,'target_name'=>$remoteName,'status'=>(string)($result['status']??'pending'),'at'=>(string)($result['at']??tk_now())];
  foreach(['reason','http_code','error','central_ticket_id','central_status','central_updated_at'] as $key){
    if(isset($result[$key])&&$result[$key]!=='') $meta[$key]=$result[$key];
    elseif(isset($previous[$key])) $meta[$key]=$previous[$key];
  }
  if(isset($result['attachment_errors'])&&is_array($result['attachment_errors'])&&$result['attachment_errors']){
    $meta['attachment_errors']=$result['attachment_errors'];
  }elseif(isset($previous['attachment_errors'])){
    $meta['attachment_errors']=$previous['attachment_errors'];
  }

  $uploadedKeys=[];
  foreach((array)($previous['uploaded_local_urls']??[]) as $key){ $uploadedKeys[(string)$key]=true; }
  $uploaded=isset($result['uploaded_attachments'])&&is_array($result['uploaded_attachments'])?$result['uploaded_attachments']:[];
  foreach($uploaded as $upload){
    if(!is_array($upload)) continue;
    $uploadKey=(string)($upload['upload_key']??((string)($upload['message_uid']??'').'|'.(string)($upload['local_url']??'')));
    if($uploadKey!=='|') $uploadedKeys[$uploadKey]=true;
  }
  $meta['uploaded_local_urls']=array_keys($uploadedKeys);

  $ticket['send_to_domydesk']=true;
  if(!$isMulti && $uploaded && isset($ticket['messages'])&&is_array($ticket['messages'])){
    foreach($uploaded as $upload){
      if(!is_array($upload)) continue;
      $messageUid=(string)($upload['message_uid']??'');
      $localUrl=(string)($upload['local_url']??'');
      $central=is_array($upload['attachment']??null)?$upload['attachment']:[];
      foreach($ticket['messages'] as &$localMessage){
        if((string)($localMessage['id']??'')!==$messageUid||!isset($localMessage['attachments'])||!is_array($localMessage['attachments'])) continue;
        foreach($localMessage['attachments'] as &$localAttachment){
          if(!is_array($localAttachment)) continue;
          $candidate=(string)($localAttachment['local_url']??$localAttachment['url']??'');
          if($candidate!==$localUrl) continue;
          $originalUrl=$candidate;
          $localAttachment=array_merge($localAttachment,$central);
          $localAttachment['local_url']=$originalUrl;
          if(!empty($central['url'])) $localAttachment['url']=$central['url'];
        }
        unset($localAttachment);
      }
      unset($localMessage);
    }
  }

  $remoteStatus=(string)($result['central_status']??'');
  $statusChanged=false;
  if(!$isMulti && tk_status_valid($remoteStatus)){
    $statusChanged=$remoteStatus!==$beforeStatus;
    $ticket['status']=$remoteStatus;
  }



  /* Workflow public reçu du Support : validation client, total de temps et incident.
     Les entrées détaillées de temps restent sur l'instance Support. */
  if($target==='support' && isset($result['workflow']) && is_array($result['workflow'])){
    $incoming=dmdtk_workflow_normalize($result['workflow']);
    $local=dmdtk_ticket_workflow($ticket);
    if(isset($incoming['closure']) && is_array($incoming['closure'])) $local['closure']=$incoming['closure'];
    if(isset($incoming['time']) && is_array($incoming['time'])){
      $local['time']['total_seconds']=max(0,(int)($incoming['time']['total_seconds']??0));
    }
    if(isset($incoming['incident']) && is_array($incoming['incident'])){
      $local['incident']=array_merge($local['incident']??[], $incoming['incident']);
    }
    dmdtk_ticket_set_workflow($ticket,$local);
  }

  $centralMessages=isset($result['central_messages'])&&is_array($result['central_messages'])?$result['central_messages']:[];
  if(!isset($ticket['messages'])||!is_array($ticket['messages'])) $ticket['messages']=[];
  $newCentralCount=0;
  $lastCentralAt='';
  foreach($centralMessages as $message){
    if(!is_array($message)) continue;
    $mid=trim((string)($message['message_uid']??$message['id']??''));
    if($mid==='') continue;
    $incomingAttachments=isset($message['attachments'])&&is_array($message['attachments'])?$message['attachments']:[];
    $cachedAttachments=tk_domydesk_cache_remote_attachments($ticket,$incomingAttachments,$target,$mid);

    /* Un message déjà synchronisé peut avoir été créé avant le cache local :
       on répare alors ses PJ au prochain Synchroniser sans dupliquer le message. */
    if(isset($knownCentral[$mid])){
      foreach($ticket['messages'] as &$existingMessage){
        if(!is_array($existingMessage) || (string)($existingMessage['id']??'')!==$mid || (string)($existingMessage['role']??'')!=='domydesk') continue;
        $existingTarget=(string)($existingMessage['remote_target']??'');
        if($existingTarget!=='' && $existingTarget!==$target) continue;
        if($cachedAttachments) $existingMessage['attachments']=$cachedAttachments;
        break;
      }
      unset($existingMessage);
      continue;
    }
    $created=(string)($message['created_at']??tk_now());
    $ticket['messages'][]=[
      'id'=>$mid,
      'at'=>$created,
      'by'=>(string)($message['author_email']??('Support '.$remoteName)),
      'role'=>'domydesk',
      'remote_target'=>$target,
      'origin_target'=>(string)($message['origin_target']??$target),
      'origin_name'=>(string)($message['origin_name']??''),
      'text'=>(string)($message['message_text']??''),
      'attachments'=>$cachedAttachments
    ];
    $knownCentral[$mid]=true;
    $newCentralCount++;
    $lastCentralAt=$created;
  }

  if($newCentralCount>0||$statusChanged){
    $previousUnread=!empty($previousNotification['unread']);
    $previousCount=$previousUnread?(int)($previousNotification['count']??0):0;
    $delta=$newCentralCount+($statusChanged?1:0);
    $meta['notification']=[
      'unread'=>true,
      'state'=>'new',
      'count'=>$previousCount+max(1,$delta),
      'at'=>$lastCentralAt!==''?$lastCentralAt:tk_now(),
      'kind'=>$newCentralCount>0?'message':'status',
      'label'=>$newCentralCount>0?'Nouvelle réponse de '.$remoteName:'Nouveau statut depuis '.$remoteName
    ];
    $ticket['updated_at']=tk_now();
  }else{
    $meta['notification']=$previousNotification ?: [
      'unread'=>false,
      'state'=>'idle',
      'count'=>0,
      'at'=>tk_now(),
      'label'=>'Aucune nouvelle information'
    ];
    if(empty($meta['notification']['unread'])){
      $meta['notification']['state']='idle';
      $meta['notification']['count']=0;
      $meta['notification']['label']='Aucune nouvelle information';
    }
  }

  $ticket['meta']['remotes'][$target]=$meta;
  $primary=$targets ? (string)$targets[0] : $target;
  if($target===$primary || !isset($ticket['meta']['domydesk']) || !is_array($ticket['meta']['domydesk'])){
    $ticket['meta']['domydesk']=$meta;
  }elseif(!empty($meta['notification']['unread'])){
    $ticket['meta']['domydesk']['notification']=$meta['notification'];
  }
}
function tk_sync_domydesk_ticket(&$ticket,$root,$event='upsert'){
  $targets=tk_remote_targets($ticket);
  if(!$targets) return ['status'=>'skipped','targets'=>[]];

  $beforeStatus=(string)($ticket['status']??'open');
  $beforeCentral=[];
  foreach((array)($ticket['messages']??[]) as $message){
    if(!is_array($message)||((string)($message['role']??''))!=='domydesk') continue;
    $mid=trim((string)($message['id']??''));
    $mt=(string)($message['remote_target']??'');
    if($mid!=='') $beforeCentral[$mt.'|'.$mid]=true;
  }

  $snapshot=$ticket;
  $results=[];
  foreach($targets as $target){
    $results[$target]=tk_send_ticket_to_domydesk($snapshot,$root,$event,$target);
  }
  foreach($targets as $target){
    tk_apply_domydesk_result($ticket,$results[$target],$target);
  }

  if(count($targets)>1){
    $statuses=[];
    foreach($targets as $target){
      $remoteStatus=(string)($ticket['meta']['remotes'][$target]['central_status']??'');
      if(tk_status_valid($remoteStatus)) $statuses[]=$remoteStatus;
    }
    if(count($statuses)===count($targets) && count(array_unique($statuses))===1){
      $ticket['status']=$statuses[0];
    }
  }

  $newCentral=0;
  $sourceTarget='';
  foreach((array)($ticket['messages']??[]) as $message){
    if(!is_array($message)||((string)($message['role']??''))!=='domydesk') continue;
    $mid=trim((string)($message['id']??''));
    $mt=(string)($message['remote_target']??'');
    if($mid!=='' && !isset($beforeCentral[$mt.'|'.$mid])){
      $newCentral++;
      if($sourceTarget==='') $sourceTarget=$mt!==''?$mt:(string)$targets[0];
    }
  }

  $activityUser=dmdtk_user_email();
  if($newCentral>0){
    if($sourceTarget==='') $sourceTarget=(string)$targets[0];
    tk_notify_ticket_message($ticket,'',$root,$sourceTarget);
    if($activityUser!=='') dmdtk_log($activityUser,'domyco_reply',(string)($ticket['id']??''),'success',array(
      'title'=>(string)($ticket['title']??''),'source'=>tk_remote_name($ticket,$sourceTarget),'messages'=>$newCentral
    ));
  }
  if((string)($ticket['status']??'open')!==$beforeStatus){
    $statusSource=(string)$targets[0];
    tk_notify_ticket_status($ticket,'',$root,$statusSource);
    if($activityUser!=='') dmdtk_log($activityUser,'domyco_status',(string)($ticket['id']??''),'success',array(
      'title'=>(string)($ticket['title']??''),'source'=>tk_remote_name($ticket,$statusSource),'before'=>$beforeStatus,'after'=>(string)($ticket['status']??'open')
    ));
  }

  $allSent=true; $allDeleted=true; $hasDeleted=false;
  foreach($results as $result){
    if((string)($result['status']??'pending')!=='sent') $allSent=false;
    if(!empty($result['remote_deleted'])) $hasDeleted=true; else $allDeleted=false;
  }
  $aggregate=[
    'status'=>$allSent?'sent':'pending',
    'targets'=>$results,
    'remote_deleted'=>$hasDeleted && $allDeleted,
    'at'=>tk_now()
  ];
  if(count($targets)===1){
    $single=$results[$targets[0]];
    $single['targets']=$results;
    return $single;
  }
  return $aggregate;
}

function tk_delete_local_ticket_files($ticketPath,$ticket,$ticketsRoot=null,$indexFile=null){
  dmdtk_delete_local_ticket($ticket);
}
function tk_require_csrf($input){
  $token=is_array($input)&&isset($input['csrf'])?(string)$input['csrf']:'';
  if(!dmdtk_csrf_valid($token)){
    http_response_code(403);
    echo json_encode(array('ok'=>false,'err'=>'csrf_invalid'),JSON_UNESCAPED_UNICODE);
    exit;
  }
}
function tk_require_capability($cap){
  if(!dmdtk_user_can($GLOBALS['me'],$cap)){
    http_response_code(403);
    echo json_encode(array('ok'=>false,'err'=>'permission_denied','capability'=>$cap),JSON_UNESCAPED_UNICODE);
    exit;
  }
}


$cfg=dmdtk_config(); $CATS=$cfg['categories']; $PRIO=$cfg['priorities'];
$a=$_GET['a'] ?? ($_POST['a'] ?? '');
$input=json_decode(file_get_contents('php://input')?:'',true); if(!is_array($input)) $input=[];

switch($a){
  case 'bootstrap': {
    [$users,$roles]=tk_users($root);
    $mydeskContext=(isset($_SESSION['dmd_mydesk_context'])&&is_array($_SESSION['dmd_mydesk_context'])&&($_SESSION['dmd_mydesk_context']['module_id']??'')==='dmd-ticketing'&&(int)($_SESSION['dmd_mydesk_context']['expires_ts']??0)>=time())?$_SESSION['dmd_mydesk_context']:null;
    $supportCfg=(isset($cfg['external_support'])&&is_array($cfg['external_support']))?$cfg['external_support']:[];
    $externalLicense=dmdtk_external_license_status();
    $supportPublic=['enabled'=>dmdtk_user_can($me,'ticket.external.send') && !empty($supportCfg['enabled']) && trim((string)($supportCfg['endpoint']??''))!=='' && trim((string)($supportCfg['token']??''))!=='' && trim((string)($supportCfg['client_key']??''))!=='','name'=>trim((string)($supportCfg['name']??''))!==''?trim((string)$supportCfg['name']):'Support externe'];
    $externalClientsPublic=[];
    if($isAdmin && dmdtk_external_license_enabled()){
      foreach(dmdtk_external_client_list() as $row){ if(($row['status']??'')==='active') $externalClientsPublic[]=['name'=>(string)($row['client_name']??''),'ref'=>(string)($row['client_ref']??''),'instance_uid'=>(string)($row['instance_uid']??'')]; }
    }
    echo json_encode(array('ok'=>true,'me'=>$me,'is_admin'=>$isAdmin,'csrf'=>$csrf,'categories'=>$CATS,'priorities'=>$PRIO,'statuses'=>tk_statuses(),'users'=>$users,'roles'=>$roles,'mydesk_context'=>$mydeskContext,'external_support'=>$supportPublic,'external_clients'=>$externalClientsPublic,'external_support_license'=>$externalLicense,'permissions'=>array('create'=>dmdtk_user_can($me,'ticket.create'),'edit_own'=>dmdtk_user_can($me,'ticket.edit_own'),'reply'=>dmdtk_user_can($me,'ticket.reply'),'share'=>dmdtk_user_can($me,'ticket.share'),'status'=>dmdtk_user_can($me,'ticket.status'),'sync'=>dmdtk_user_can($me,'ticket.sync'),'external_send'=>dmdtk_user_can($me,'ticket.external.send'),'escalate_domyco'=>dmdtk_user_can($me,'ticket.escalate.domyco'))),JSON_UNESCAPED_UNICODE); exit;
  }
  case 'list': {
    tk_require_capability('view');
    $status=(string)($input['status']??'all'); $cat=tk_clean($input['category']??''); $pri=tk_clean($input['priority']??''); $client=tk_clean($input['client']??''); $q=function_exists('mb_strtolower')?mb_strtolower(tk_clean($input['q']??'')):strtolower(tk_clean($input['q']??'')); $scope=(string)($input['scope']??'visible');
    $out=array();
    foreach(dmdtk_index() as $ticketId=>$idx){
      if(!is_array($idx)) continue;
      if($scope==='mine' && (string)($idx['owner']??'')!==$me) continue;
      if($scope==='all' && !dmdtk_user_can($me,'admin.view_all')) continue;
      list($t,$p,$owner)=dmdtk_ticket_read((string)$ticketId);
      if(!is_array($t)||!$t) continue;
      if(!tk_can_access($t,$me,$isAdmin,$root)) continue;
      if($status!=='all' && ($t['status']??'open')!==$status) continue;
      if($cat!=='' && ($t['category']??'')!==$cat) continue;
      if($pri!=='' && ($t['priority']??'')!==$pri) continue;
      if($client!==''){
        $tClient=(string)($t['meta']['external']['client_ref']??$t['meta']['external']['client_name']??'');
        if($tClient!==$client) continue;
      }
      if($q!==''){
        $hay=(string)($t['title']??'').' '.(string)($t['owner']??'').' '.tk_last_message($t);
        $hay=function_exists('mb_strtolower')?mb_strtolower($hay):strtolower($hay);
        $found=function_exists('mb_strpos')?mb_strpos($hay,$q):strpos($hay,$q);
        if($found===false) continue;
      }
      $out[]=tk_summary($t,$me,$isAdmin);
    }
    usort($out,function($a,$b){ return strcmp($b['updated_at']??$b['created_at']??'',$a['updated_at']??$a['created_at']??''); });
    echo json_encode(array('ok'=>true,'items'=>$out),JSON_UNESCAPED_UNICODE); exit;
  }
  case 'sync_all': {
    tk_require_csrf($input); tk_require_capability('ticket.sync');
    $synced=0; $pending=0; $failed=0; $deleted=0;
    foreach(dmdtk_index() as $ticketId=>$idx){
      if(!is_array($idx)) continue;
      if(array_key_exists('domyco_requested',$idx) && empty($idx['domyco_requested'])) continue;
      list($t,$p,$owner)=dmdtk_ticket_read((string)$ticketId);
      if(!is_array($t)||!$t) continue;
      if(!tk_can_access($t,$me,$isAdmin,$root) || !tk_domydesk_requested($t)) continue;
      $dmStatus=(string)($t['meta']['domydesk']['status']??'');
      $force=!empty($input['force']);
      $lastAt=strtotime((string)($t['meta']['domydesk']['at']??''))?:0;
      if(!$force && $lastAt>0 && (time()-$lastAt)<120) continue;
      /* Un ticket Support escaladé doit toujours republier son historique courant vers DoMyCo.
         Cela inclut les nouvelles réponses reçues du Client depuis la dernière synchro.
         L'upsert renvoie aussi les réponses centrales, donc il remplace avantageusement un simple pull. */
      $isEscalated=!empty($t['meta']['escalation']['requested']);
      $event=$isEscalated?'upsert':(in_array($dmStatus,array('sent','remote_missing'),true)?'pull':'upsert');
      $result=tk_sync_domydesk_ticket($t,$root,$event);
      if(!empty($result['remote_deleted'])){
        dmdtk_delete_local_ticket($t); dmdtk_log($me,'remote_delete',(string)$ticketId,'success',array('deleted_by'=>$result['deleted_by']??tk_remote_name($t))); $synced++; $deleted++; continue;
      }
      dmdtk_ticket_write($t);
      if(($result['status']??'')==='sent') $synced++; elseif(($result['status']??'')==='pending') $pending++; else $failed++;
    }
    echo json_encode(array('ok'=>true,'synced'=>$synced,'pending'=>$pending,'failed'=>$failed,'deleted'=>$deleted),JSON_UNESCAPED_UNICODE); exit;
  }
  case 'create': {
    tk_require_csrf($input); tk_require_capability('ticket.create');
    $title=tk_clean($input['title']??''); $message=tk_clean($input['message']??''); $cat=tk_clean($input['category']??($CATS[0]??'Support')); $pri=tk_clean($input['priority']??($PRIO[0]??'normale'));
    if(tk_strlen($title)<3){ echo json_encode(['ok'=>false,'err'=>'Titre trop court']); exit; }
    if($message===''){ echo json_encode(['ok'=>false,'err'=>'Message requis']); exit; }
    if(!in_array($cat,$CATS,true)) $cat=$CATS[0]??'Support'; if(!in_array($pri,$PRIO,true)) $pri=$PRIO[0]??'normale';
    $share=$input['share']??[]; if(!is_array($share)) $share=[];
    $share=['all'=>!empty($share['all']),'users'=>tk_clean_array($share['users']??[]),'roles'=>tk_clean_array($share['roles']??[])];
    $id=tk_id();
    $remoteTargets=[];
    $requestedTargets=$input['remote_targets']??[];
    if(is_array($requestedTargets)){
      foreach($requestedTargets as $target){
        $target=tk_clean($target);
        if(in_array($target,['domyco','support'],true) && !in_array($target,$remoteTargets,true)) $remoteTargets[]=$target;
      }
    }
    /* Compatibilité avec les anciens formulaires à destination unique. */
    if(!$remoteTargets){
      $legacyTarget=tk_clean($input['remote_target']??'');
      if(in_array($legacyTarget,['domyco','support'],true)) $remoteTargets[]=$legacyTarget;
      elseif(!empty($input['send_to_domydesk'])) $remoteTargets[]='domyco';
    }
    if(in_array('support',$remoteTargets,true)){
      tk_require_capability('ticket.external.send');
      $support=(isset($cfg['external_support'])&&is_array($cfg['external_support']))?$cfg['external_support']:[];
      if(empty($support['enabled']) || trim((string)($support['endpoint']??''))==='' || trim((string)($support['token']??''))==='' || trim((string)($support['client_key']??''))===''){
        echo json_encode(['ok'=>false,'err'=>'external_support_not_configured','message'=>'Aucune liaison Support valide n’est importée.'],JSON_UNESCAPED_UNICODE); exit;
      }
    }
    $remoteTarget=$remoteTargets ? (string)$remoteTargets[0] : '';
    $t=['id'=>$id,'owner'=>$me,'created_at'=>tk_now(),'updated_at'=>tk_now(),'status'=>'open','title'=>$title,'category'=>$cat,'priority'=>$pri,'share'=>$share,'remote_targets'=>$remoteTargets,'remote_target'=>$remoteTarget,'send_to_domydesk'=>!empty($remoteTargets),'messages'=>[['id'=>tk_message_id(),'at'=>tk_now(),'by'=>$me,'role'=>'owner','text'=>$message,'attachments'=>[]]],'meta'=>[]];
    if(isset($_SESSION['dmd_mydesk_context'])&&is_array($_SESSION['dmd_mydesk_context'])&&($_SESSION['dmd_mydesk_context']['module_id']??'')==='dmd-ticketing'&&(int)($_SESSION['dmd_mydesk_context']['expires_ts']??0)>=time()) {
      $ctx=$_SESSION['dmd_mydesk_context'];
      $t['meta']['mydesk']=['agent_id'=>tk_clean($ctx['agent_id']??''),'hostname'=>tk_clean($ctx['hostname']??''),'launched_at'=>tk_clean($ctx['launched_at']??'')];
    }
    if($remoteTargets){
      $t['meta']['remotes']=[];
      foreach($remoteTargets as $target){
        $targetName=$target==='support'?((string)($cfg['external_support']['name']??'Support externe')):'DoMyCo';
        $t['meta']['remotes'][$target]=['requested'=>true,'target'=>$target,'target_name'=>$targetName,'status'=>'pending','at'=>tk_now(),'uploaded_local_urls'=>[]];
      }
      $t['meta']['domydesk']=$t['meta']['remotes'][$remoteTarget];
    }
    dmdtk_ticket_write($t);
    if(tk_domydesk_requested($t)){ tk_sync_domydesk_ticket($t,$root,'upsert'); dmdtk_ticket_write($t); }
    $shareNotifications=tk_notify_new_share_recipients($t,[],$share,$me,$root);
    dmdtk_log($me,'create',$id,'success',array('title'=>$title,'remote'=>tk_domydesk_requested($t),'remote_target'=>$remoteTarget,'remote_targets'=>$remoteTargets,'share_notifications'=>$shareNotifications));
    echo json_encode(['ok'=>true,'id'=>$id,'domydesk'=>$t['meta']['domydesk']??null,'remotes'=>$t['meta']['remotes']??[],'share_notifications'=>$shareNotifications],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'get': {
    $id=tk_clean($input['id']??($_GET['id']??'')); if($id===''){ echo json_encode(['ok'=>false,'err'=>'missing_id']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    $t['can_manage']=tk_can_manage($t,$me,$isAdmin); $t['can_delete']=tk_can_delete($t,$me,$isAdmin);
    $isExternal=!empty($t['meta']['external']) && is_array($t['meta']['external']);
    $t['can_workflow_time']=$isExternal && dmdtk_user_can($me,'ticket.reply');
    $t['can_workflow_status']=$isExternal && dmdtk_user_can($me,'ticket.status');
    $t['can_status']=tk_can_manage($t,$me,$isAdmin) || $t['can_workflow_status'];
    $t['can_escalate']=$isExternal && dmdtk_user_can($me,'ticket.escalate.domyco');
    tk_workflow_enrich_ticket($t,$me,$isAdmin);
    echo json_encode(['ok'=>true,'item'=>$t],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'mark_read': {
    tk_require_csrf($input); tk_require_capability('view');
    $id=tk_clean($input['id']??''); if($id===''){ echo json_encode(['ok'=>false,'err'=>'missing_id']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(!isset($t['meta'])||!is_array($t['meta'])) $t['meta']=[];
    if(!isset($t['meta']['domydesk'])||!is_array($t['meta']['domydesk'])) $t['meta']['domydesk']=[];
    $previous=(isset($t['meta']['domydesk']['notification'])&&is_array($t['meta']['domydesk']['notification']))?$t['meta']['domydesk']['notification']:[];
    $t['meta']['domydesk']['notification']=array_merge($previous,[
      'unread'=>false,'state'=>'idle','count'=>0,'seen_at'=>tk_now(),'label'=>'Aucune nouvelle information'
    ]);
    if(isset($t['meta']['external'])&&is_array($t['meta']['external'])){
      $previousExternal=(isset($t['meta']['external']['notification'])&&is_array($t['meta']['external']['notification']))?$t['meta']['external']['notification']:[];
      $t['meta']['external']['notification']=array_merge($previousExternal,[
        'unread'=>false,'state'=>'idle','count'=>0,'seen_at'=>tk_now(),'label'=>'Aucune nouvelle information'
      ]);
    }
    dmdtk_ticket_write($t);
    echo json_encode(['ok'=>true],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'reply': {
    tk_require_csrf($input); tk_require_capability('ticket.reply');
    $id=tk_clean($input['id']??''); $msg=tk_clean($input['message']??''); if($id===''||$msg===''){ echo json_encode(['ok'=>false,'err'=>'message_empty']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(($t['status']??'open')==='closed'){ echo json_encode(['ok'=>false,'err'=>'closed']); exit; }
    $t['messages'][]=['id'=>tk_message_id(),'at'=>tk_now(),'by'=>$me,'role'=>tk_can_manage($t,$me,$isAdmin)?((($t['owner']??'')===$me)?'owner':'admin'):'shared','text'=>$msg,'attachments'=>[]]; $t['updated_at']=tk_now();
    $domydeskResult=null;
    if(tk_domydesk_requested($t)) $domydeskResult=tk_sync_domydesk_ticket($t,$root,'upsert');
    dmdtk_ticket_write($t);
    $messageNotifications=tk_notify_ticket_message($t,$me,$root,'local');
    dmdtk_log($me,'reply',$id,'success',array('remote'=>tk_domydesk_requested($t),'remote_target'=>tk_domydesk_requested($t)?tk_remote_target($t):'','message_notifications'=>$messageNotifications));
    echo json_encode(['ok'=>true,'domydesk'=>$domydeskResult,'message_notifications'=>$messageNotifications],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'time_start': {
    tk_require_csrf($input); tk_require_capability('ticket.reply');
    $id=tk_clean($input['id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    tk_require_external_workflow_ticket($t);
    $workflow=dmdtk_ticket_workflow($t);
    if(!isset($workflow['time']['running'])||!is_array($workflow['time']['running'])) $workflow['time']['running']=[];
    if(!isset($workflow['time']['running'][$me])) $workflow['time']['running'][$me]=['id'=>'RUN-'.substr(bin2hex(random_bytes(6)),0,12),'started_at'=>tk_now(),'note'=>tk_clean($input['note']??'')];
    dmdtk_ticket_set_workflow($t,$workflow); $t['updated_at']=tk_now(); dmdtk_ticket_write($t);
    dmdtk_log($me,'time_start',$id,'success',array('started_at'=>$workflow['time']['running'][$me]['started_at']??''));
    echo json_encode(['ok'=>true,'workflow'=>dmdtk_ticket_workflow($t)],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'time_stop': {
    tk_require_csrf($input); tk_require_capability('ticket.reply');
    $id=tk_clean($input['id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    tk_require_external_workflow_ticket($t);
    $workflow=dmdtk_ticket_workflow($t); $running=$workflow['time']['running'][$me]??null;
    if(!is_array($running)){ echo json_encode(['ok'=>false,'err'=>'timer_not_running']); exit; }
    $startTs=strtotime((string)($running['started_at']??'')); if($startTs===false) $startTs=time();
    $seconds=max(1,time()-$startTs); $note=tk_clean($input['note']??($running['note']??''));
    $workflow['time']['entries'][]=['id'=>'TIME-'.substr(bin2hex(random_bytes(6)),0,12),'user'=>$me,'started_at'=>(string)($running['started_at']??tk_now()),'ended_at'=>tk_now(),'seconds'=>$seconds,'note'=>$note,'source'=>'timer'];
    unset($workflow['time']['running'][$me]);
    dmdtk_ticket_set_workflow($t,$workflow); $t['updated_at']=tk_now(); dmdtk_ticket_write($t);
    dmdtk_log($me,'time_stop',$id,'success',array('seconds'=>$seconds,'note'=>$note));
    echo json_encode(['ok'=>true,'workflow'=>dmdtk_ticket_workflow($t)],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'time_add': {
    tk_require_csrf($input); tk_require_capability('ticket.reply');
    $id=tk_clean($input['id']??''); $minutes=max(0,(int)($input['minutes']??0)); if($minutes<1||$minutes>1440){ echo json_encode(['ok'=>false,'err'=>'invalid_minutes']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    tk_require_external_workflow_ticket($t);
    $workflow=dmdtk_ticket_workflow($t); $now=tk_now();
    $workflow['time']['entries'][]=['id'=>'TIME-'.substr(bin2hex(random_bytes(6)),0,12),'user'=>$me,'started_at'=>$now,'ended_at'=>$now,'seconds'=>$minutes*60,'note'=>tk_clean($input['note']??''),'source'=>'manual'];
    dmdtk_ticket_set_workflow($t,$workflow); $t['updated_at']=tk_now(); dmdtk_ticket_write($t);
    dmdtk_log($me,'time_add',$id,'success',array('minutes'=>$minutes,'note'=>tk_clean($input['note']??'')));
    echo json_encode(['ok'=>true,'workflow'=>dmdtk_ticket_workflow($t)],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'request_closure': {
    tk_require_csrf($input); tk_require_capability('ticket.status');
    $id=tk_clean($input['id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    tk_require_external_workflow_ticket($t);
    $workflow=dmdtk_ticket_workflow($t); $requestId='CLOSE-'.substr(bin2hex(random_bytes(10)),0,20);
    $workflow['closure']=['state'=>'requested','request_id'=>$requestId,'requested_at'=>tk_now(),'requested_by'=>$me,'responded_at'=>'','responded_by'=>'','comment'=>tk_clean($input['comment']??'')];
    dmdtk_ticket_set_workflow($t,$workflow); $statusBefore=(string)($t['status']??'open'); $t['status']='resolved'; $t['updated_at']=tk_now(); dmdtk_ticket_write($t);
    if($statusBefore!=='resolved') tk_notify_ticket_status($t,$me,$root,'local');
    dmdtk_log($me,'request_closure',$id,'success',array('request_id'=>$requestId));
    echo json_encode(['ok'=>true,'workflow'=>dmdtk_ticket_workflow($t)],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'closure_respond': {
    tk_require_csrf($input);
    $id=tk_clean($input['id']??''); $decision=tk_clean($input['decision']??''); if(!in_array($decision,['accepted','rejected'],true)){ echo json_encode(['ok'=>false,'err'=>'bad_decision']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if((string)($t['owner']??'')!==$me && !tk_can_manage($t,$me,$isAdmin)){ echo json_encode(['ok'=>false,'err'=>'owner_required']); exit; }
    $workflow=dmdtk_ticket_workflow($t); $closure=$workflow['closure']??[]; $requestId=tk_clean($input['request_id']??'');
    if(($closure['state']??'none')!=='requested' || $requestId==='' || !hash_equals((string)($closure['request_id']??''),$requestId)){ echo json_encode(['ok'=>false,'err'=>'closure_request_expired']); exit; }
    $comment=tk_clean($input['comment']??'');
    $workflow['closure']=array_merge($closure,['state'=>$decision,'responded_at'=>tk_now(),'responded_by'=>$me,'comment'=>$comment]);
    dmdtk_ticket_set_workflow($t,$workflow); $t['status']=$decision==='accepted'?'closed':'open';
    $text=$decision==='accepted'?'Résolution confirmée par le client.':'Résolution refusée par le client.'; if($comment!=='') $text.=' '.$comment;
    $t['messages'][]=['id'=>tk_message_id(),'at'=>tk_now(),'by'=>$me,'role'=>(string)($t['owner']??'')===$me?'owner':'admin','text'=>$text,'attachments'=>[]]; $t['updated_at']=tk_now();
    $remoteResult=null; if(tk_domydesk_requested($t)) $remoteResult=tk_sync_domydesk_ticket($t,$root,'upsert'); dmdtk_ticket_write($t);
    dmdtk_log($me,'closure_'.$decision,$id,'success',array('request_id'=>$requestId,'comment'=>$comment));
    echo json_encode(['ok'=>true,'workflow'=>dmdtk_ticket_workflow($t),'domydesk'=>$remoteResult],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'incident_create': {
    tk_require_csrf($input); tk_require_capability('ticket.status');
    $id=tk_clean($input['id']??''); $title=tk_clean($input['title']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    tk_require_external_workflow_ticket($t);
    $created=dmdtk_incident_create($title,$me); if(empty($created['ok'])){ echo json_encode(['ok'=>false,'err'=>$created['error']??'incident_create_failed']); exit; }
    $incident=$created['incident']; $workflow=dmdtk_ticket_workflow($t); $old=(string)($workflow['incident']['id']??''); if($old!=='') dmdtk_incident_detach_ticket($old,$id,$me);
    $workflow['incident']=['id'=>$incident['id'],'title'=>$incident['title'],'status'=>$incident['status'],'linked_at'=>tk_now(),'linked_by'=>$me]; dmdtk_ticket_set_workflow($t,$workflow); dmdtk_incident_attach_ticket($incident['id'],$id,$me); $t['updated_at']=tk_now(); dmdtk_ticket_write($t);
    dmdtk_log($me,'incident_create',$id,'success',array('incident_id'=>$incident['id'],'incident_title'=>$incident['title']));
    echo json_encode(['ok'=>true,'incident'=>$incident],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'incident_link': {
    tk_require_csrf($input); tk_require_capability('ticket.status');
    $id=tk_clean($input['id']??''); $incidentId=tk_clean($input['incident_id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    tk_require_external_workflow_ticket($t);
    $incident=dmdtk_incident_get($incidentId); if(!$incident){ echo json_encode(['ok'=>false,'err'=>'incident_not_found']); exit; }
    $workflow=dmdtk_ticket_workflow($t); $old=(string)($workflow['incident']['id']??''); if($old!==''&&$old!==$incidentId) dmdtk_incident_detach_ticket($old,$id,$me);
    $workflow['incident']=['id'=>$incidentId,'title'=>(string)$incident['title'],'status'=>(string)$incident['status'],'linked_at'=>tk_now(),'linked_by'=>$me]; dmdtk_ticket_set_workflow($t,$workflow); dmdtk_incident_attach_ticket($incidentId,$id,$me); $t['updated_at']=tk_now(); dmdtk_ticket_write($t);
    dmdtk_log($me,'incident_link',$id,'success',array('incident_id'=>$incidentId)); echo json_encode(['ok'=>true],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'incident_unlink': {
    tk_require_csrf($input); tk_require_capability('ticket.status');
    $id=tk_clean($input['id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    tk_require_external_workflow_ticket($t);
    $workflow=dmdtk_ticket_workflow($t); $incidentId=(string)($workflow['incident']['id']??''); if($incidentId!=='') dmdtk_incident_detach_ticket($incidentId,$id,$me);
    $workflow['incident']=['id'=>'','title'=>'','status'=>'','linked_at'=>'','linked_by'=>'']; dmdtk_ticket_set_workflow($t,$workflow); $t['updated_at']=tk_now(); dmdtk_ticket_write($t);
    dmdtk_log($me,'incident_unlink',$id,'success',array('incident_id'=>$incidentId)); echo json_encode(['ok'=>true],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'incident_status': {
    tk_require_csrf($input); tk_require_capability('ticket.status');
    $id=tk_clean($input['id']??''); $status=tk_clean($input['status']??''); if(!in_array($status,['open','closed'],true)){ echo json_encode(['ok'=>false,'err'=>'bad_incident_status']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    tk_require_external_workflow_ticket($t);
    $workflow=dmdtk_ticket_workflow($t); $incidentId=(string)($workflow['incident']['id']??''); if($incidentId===''||!dmdtk_incident_set_status($incidentId,$status,$me)){ echo json_encode(['ok'=>false,'err'=>'incident_not_found']); exit; }
    $incident=dmdtk_incident_get($incidentId);
    foreach((array)($incident['tickets']??[]) as $ticketId){ list($linked)=dmdtk_ticket_read((string)$ticketId); if(!is_array($linked)||!$linked) continue; $wf=dmdtk_ticket_workflow($linked); if((string)($wf['incident']['id']??'')!==$incidentId) continue; $wf['incident']['status']=$status; $wf['incident']['title']=(string)($incident['title']??$wf['incident']['title']??''); dmdtk_ticket_set_workflow($linked,$wf); $linked['updated_at']=tk_now(); dmdtk_ticket_write($linked); }
    dmdtk_log($me,'incident_status',$id,'success',array('incident_id'=>$incidentId,'status'=>$status)); echo json_encode(['ok'=>true],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'escalate_domyco': {
    tk_require_csrf($input); tk_require_capability('ticket.escalate.domyco');
    $id=tk_clean($input['id']??''); if($id===''){ echo json_encode(['ok'=>false,'err'=>'missing_id']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(empty($t['meta']['external']) || !is_array($t['meta']['external'])){
      echo json_encode(['ok'=>false,'err'=>'not_external_ticket','message'=>'Seuls les tickets reçus d’une entreprise cliente peuvent être escaladés vers DoMyCo.'],JSON_UNESCAPED_UNICODE); exit;
    }
    if(!dmdtk_external_license_enabled()){
      echo json_encode(['ok'=>false,'err'=>'ticketing_support_license_required','message'=>'La réception Support DMD-Ticketing doit être couverte par une licence active pour escalader vers DoMyCo.'],JSON_UNESCAPED_UNICODE); exit;
    }

    $targets=tk_remote_targets($t);
    if(!in_array('domyco',$targets,true)) $targets[]='domyco';
    $t['remote_targets']=array_values(array_unique($targets));
    $t['remote_target']='domyco';
    $t['send_to_domydesk']=true;
    if(!isset($t['meta'])||!is_array($t['meta'])) $t['meta']=[];
    if(!isset($t['meta']['remotes'])||!is_array($t['meta']['remotes'])) $t['meta']['remotes']=[];
    $already=!empty($t['meta']['escalation']['requested']);
    if(!$already){
      $instance=tk_domydesk_instance_context($root);
      $external=$t['meta']['external'];
      $supportCfg=(isset($cfg['external_receive'])&&is_array($cfg['external_receive']))?$cfg['external_receive']:[];
      $supportName=trim((string)($supportCfg['name']??''));
      if($supportName==='') $supportName=trim((string)($instance['instance_name']??''));
      if($supportName==='') $supportName='Support';
      $t['meta']['escalation']=[
        'requested'=>true,
        'target'=>'domyco',
        'status'=>'pending',
        'escalated_at'=>tk_now(),
        'escalated_by'=>$me,
        'support_name'=>$supportName,
        'support_instance_id'=>(string)($instance['instance_uid']??''),
        'client_name'=>(string)($external['client_name']??''),
        'client_ref'=>(string)($external['client_ref']??''),
        'client_instance_id'=>(string)($external['source_instance_uid']??''),
        'client_ticket_id'=>(string)($external['source_ticket_id']??''),
        'support_ticket_id'=>(string)($t['id']??'')
      ];
    }
    if(!isset($t['meta']['remotes']['domyco'])||!is_array($t['meta']['remotes']['domyco'])){
      $t['meta']['remotes']['domyco']=['requested'=>true,'target'=>'domyco','target_name'=>'DoMyCo','status'=>'pending','at'=>tk_now(),'uploaded_local_urls'=>[]];
    }else{
      $t['meta']['remotes']['domyco']['requested']=true;
      $t['meta']['remotes']['domyco']['target']='domyco';
      $t['meta']['remotes']['domyco']['target_name']='DoMyCo';
    }
    $t['meta']['domydesk']=$t['meta']['remotes']['domyco'];
    $t['updated_at']=tk_now();

    if(!dmdtk_ticket_write($t)){ echo json_encode(['ok'=>false,'err'=>'write_failed']); exit; }
    $result=tk_send_ticket_to_domydesk($t,$root,'upsert','domyco');
    tk_apply_domydesk_result($t,$result,'domyco');
    if(isset($t['meta']['escalation'])&&is_array($t['meta']['escalation'])){
      $t['meta']['escalation']['status']=(string)($result['status']??'pending');
      $t['meta']['escalation']['last_sync_at']=(string)($result['at']??tk_now());
      if(!empty($result['central_ticket_id'])) $t['meta']['escalation']['domyco_ticket_id']=(string)$result['central_ticket_id'];
      if(!empty($result['error'])) $t['meta']['escalation']['last_error']=(string)$result['error'];
      else unset($t['meta']['escalation']['last_error']);
    }
    dmdtk_ticket_write($t);
    dmdtk_log($me,'escalate_domyco',$id,($result['status']??'pending')==='sent'?'success':'pending',array(
      'client_name'=>(string)($t['meta']['external']['client_name']??''),
      'client_ref'=>(string)($t['meta']['external']['client_ref']??''),
      'client_instance_id'=>(string)($t['meta']['external']['source_instance_uid']??''),
      'domyco_status'=>(string)($result['status']??'pending'),
      'domyco_ticket_id'=>(string)($result['central_ticket_id']??'')
    ));
    echo json_encode(['ok'=>true,'already'=>$already,'result'=>$result,'escalation'=>$t['meta']['escalation']??[]],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'sync': {
    tk_require_csrf($input); tk_require_capability('ticket.sync');
    $id=tk_clean($input['id']??''); if($id===''){ echo json_encode(['ok'=>false,'err'=>'missing_id']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(!tk_domydesk_requested($t)){ echo json_encode(['ok'=>true,'skipped'=>true]); exit; }
    $dmStatus=(string)($t['meta']['domydesk']['status']??'');
    /* Après escalade, Synchroniser doit pousser à DoMyCo TOUT ce qui est arrivé depuis le Client
       ou a été écrit par le Support, puis récupérer la réponse centrale dans le même échange. */
    $isEscalated=!empty($t['meta']['escalation']['requested']);
    $event=$isEscalated?'upsert':(in_array($dmStatus,array('sent','remote_missing'),true)?'pull':'upsert');
    $result=tk_sync_domydesk_ticket($t,$root,$event);
    if(!empty($result['remote_deleted'])){
      dmdtk_delete_local_ticket($t); dmdtk_log($me,'remote_delete',$id,'success',array('source'=>tk_remote_name($t)));
      echo json_encode(['ok'=>true,'deleted'=>true,'result'=>$result],JSON_UNESCAPED_UNICODE); exit;
    }
    dmdtk_ticket_write($t); dmdtk_log($me,'sync',$id,'success',array('status'=>$result['status']??''));
    echo json_encode(['ok'=>true,'domydesk'=>$t['meta']['domydesk']??[],'result'=>$result],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'update': {
    tk_require_csrf($input);
    $id=tk_clean($input['id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p);
    $canManage=tk_can_manage($t,$me,$isAdmin);
    $externalStatusOnly=!empty($t['meta']['external']) && is_array($t['meta']['external']) && tk_can_access($t,$me,$isAdmin,$root)
      && isset($input['status']) && !isset($input['share']) && !isset($input['title']) && !isset($input['category']) && !isset($input['priority']);
    if(!$canManage && !$externalStatusOnly){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(isset($input['share'])) tk_require_capability('ticket.share');
    if(isset($input['status'])) tk_require_capability('ticket.status');
    if(isset($input['title'])||isset($input['category'])||isset($input['priority'])){
      if((string)($t['owner']??'')===$me) tk_require_capability('ticket.edit_own');
      else tk_require_capability('admin.edit_any');
    }
    $shareBefore=(isset($t['share'])&&is_array($t['share']))?$t['share']:[];
    $shareChanged=false;
    $statusBefore=(string)($t['status']??'open');
    if(isset($input['title'])){ $title=tk_clean($input['title']); if($title!=='') $t['title']=$title; }
    if(isset($input['status'])&&tk_status_valid($input['status'])) { $t['status']=(string)$input['status']; tk_workflow_cancel_pending_closure($t,$me,$t['status']); }
    if(isset($input['category'])&&in_array($input['category'],$CATS,true)) $t['category']=$input['category'];
    if(isset($input['priority'])&&in_array($input['priority'],$PRIO,true)) $t['priority']=$input['priority'];
    if(isset($input['share'])&&is_array($input['share'])){
      $t['share']=['all'=>!empty($input['share']['all']),'users'=>tk_clean_array($input['share']['users']??[]),'roles'=>tk_clean_array($input['share']['roles']??[])];
      $shareChanged=true;
    }
    $t['updated_at']=tk_now();
    if(tk_domydesk_requested($t)) tk_sync_domydesk_ticket($t,$root,'upsert');
    dmdtk_ticket_write($t);
    $shareNotifications=$shareChanged?tk_notify_new_share_recipients($t,$shareBefore,$t['share']??[],$me,$root):0;
    $statusNotifications=((string)($t['status']??'open')!==$statusBefore)?tk_notify_ticket_status($t,$me,$root,'local'):0;
    dmdtk_log($me,'update',$id,'success',array('status'=>$t['status']??'','share_notifications'=>$shareNotifications,'status_notifications'=>$statusNotifications));
    echo json_encode(['ok'=>true,'share_notifications'=>$shareNotifications,'status_notifications'=>$statusNotifications],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'close': case 'reopen': {
    tk_require_csrf($input); tk_require_capability('ticket.status');
    $id=tk_clean($input['id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_manage($t,$me,$isAdmin) && (empty($t['meta']['external']) || !tk_can_access($t,$me,$isAdmin,$root))){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    $statusBefore=(string)($t['status']??'open');
    $t['status']=$a==='close'?'closed':'open';
    tk_workflow_cancel_pending_closure($t,$me,$t['status']);
    $t['updated_at']=tk_now();
    if(tk_domydesk_requested($t)) tk_sync_domydesk_ticket($t,$root,'upsert');
    dmdtk_ticket_write($t);
    $statusNotifications=((string)($t['status']??'open')!==$statusBefore)?tk_notify_ticket_status($t,$me,$root,'local'):0;
    dmdtk_log($me,$a,$id,'success',array('status'=>$t['status'],'status_notifications'=>$statusNotifications));
    echo json_encode(['ok'=>true,'status_notifications'=>$statusNotifications],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'delete': {
    tk_require_csrf($input);
    $id=tk_clean($input['id']??''); list($p,$owner)=tk_path($id); if(!$p){ echo json_encode(array('ok'=>false,'err'=>'not_found')); exit; }
    $t=tk_read_json($p); if(!tk_can_delete($t,$me,$isAdmin)){ echo json_encode(array('ok'=>false,'err'=>'forbidden')); exit; }
    if((string)($t['owner']??'')===$me) tk_require_capability('ticket.delete_own'); else tk_require_capability('admin.delete_any');
    $remote=null;
    if(tk_domydesk_requested($t)){
      $remote=tk_sync_domydesk_ticket($t,$root,'delete');
      if(($remote['status']??'pending')!=='sent'){
        dmdtk_log($me,'delete',$id,'error',array('reason'=>'remote_delete_failed','remote'=>$remote));
        echo json_encode(array('ok'=>false,'err'=>'remote_delete_failed','message'=>'Suppression sur le support distant impossible : le ticket local est conservé.','remote'=>$remote),JSON_UNESCAPED_UNICODE); exit;
      }
    }
    dmdtk_delete_local_ticket($t); dmdtk_log($me,'delete',$id,'success',array('remote'=>tk_domydesk_requested($t)));
    echo json_encode(array('ok'=>true,'remote'=>$remote),JSON_UNESCAPED_UNICODE); exit;
  }
  default: echo json_encode(['ok'=>false,'err'=>'bad_action']); exit;
}