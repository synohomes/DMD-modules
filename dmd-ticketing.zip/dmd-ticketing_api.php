<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('X-Content-Type-Options: nosniff');
header('Content-Type: application/json; charset=utf-8');
error_reporting(0);

$me = dmdtk_user_email();
$role = dmdtk_system_role($me);
if ($me === '') { http_response_code(401); echo json_encode(array('ok'=>false,'err'=>'not_logged')); exit; }
if (!dmdtk_has_module_access($me)) { http_response_code(403); echo json_encode(array('ok'=>false,'err'=>'module_forbidden')); exit; }
$isAdmin = dmdtk_is_admin($me);
$csrf = dmdtk_csrf_token();

/* La synchro distante ne doit pas verrouiller la session PHP. */
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

$root = __DIR__;
$ticketsRoot = null;
$indexFile = dmdtk_index_file();

function tk_read_json($f){ return dmdtk_read_json($f, array()); }
function tk_write_json($f,$d){ return dmdtk_write_json($f,$d); }
function tk_ensure_dir($d){ if(!is_dir($d)) @mkdir($d,0750,true); }
function tk_now(){ return date('c'); }
function tk_id(){ return 'T-'.date('Ymd-His').'-'.substr(bin2hex(random_bytes(3)),0,6); }
function tk_message_id(){ return 'M-'.date('YmdHis').'-'.substr(bin2hex(random_bytes(4)),0,8); }
function tk_clean($s){ return trim((string)$s); }
function tk_strlen($s){ return function_exists('mb_strlen') ? mb_strlen((string)$s, 'UTF-8') : strlen((string)$s); }
function tk_safe_user_dir($email){ return str_replace(['/', '\\', "\0"], '_', (string)$email); }
function tk_statuses(){ return ['open'=>'Ouvert','in_progress'=>'En cours','waiting'=>'En attente','resolved'=>'Résolu','closed'=>'Fermé']; }
function tk_status_label($st){ $all=tk_statuses(); return $all[$st] ?? $all['open']; }
function tk_status_valid($st){ return array_key_exists((string)$st, tk_statuses()); }
function tk_clean_array($arr){
  if(!is_array($arr)) return [];
  $out=[];
  foreach($arr as $v){ $v=trim((string)$v); if($v!=='' && !in_array($v,$out,true)) $out[]=$v; }
  return $out;
}
function tk_users($root){
  $users=array(); $roles=array();
  $base=dmdtk_profiles_root();
  foreach((array)@scandir($base) as $d){
    if($d==='.'||$d==='..'||!is_dir($base.'/'.$d)) continue;
    $j=dmdtk_profile($d);
    $email=trim((string)(isset($j['email'])?$j['email']:$d));
    if($email===''||isset($users[$email])) continue;
    $name=trim((string)(isset($j['prenom'])?$j['prenom']:'').' '.(string)(isset($j['nom'])?$j['nom']:''));
    if($name==='') $name=$email;
    $rm=trim((string)(isset($j['role_metier'])?$j['role_metier']:''));
    if($rm!==''&&!in_array($rm,$roles,true)) $roles[]=$rm;
    $users[$email]=array('email'=>$email,'label'=>$name.' — '.$email,'role_metier'=>$rm);
  }
  if(!isset($users[$GLOBALS['me']])) $users[$GLOBALS['me']]=array('email'=>$GLOBALS['me'],'label'=>$GLOBALS['me'],'role_metier'=>dmdtk_user_role_metier($GLOBALS['me']));
  uasort($users,function($a,$b){ return strcasecmp((string)$a['label'],(string)$b['label']); });
  sort($roles,SORT_NATURAL|SORT_FLAG_CASE);
  return array(array_values($users),$roles);
}
function tk_user_role_metier($email,$root){ return dmdtk_user_role_metier($email); }

/* Résout les utilisateurs réellement concernés par une règle de partage. */
function tk_share_recipients($share,$root){
  if(!is_array($share)) $share=[];
  list($users,$roles)=tk_users($root);
  $wantedUsers=tk_clean_array($share['users']??[]);
  $wantedRoles=tk_clean_array($share['roles']??[]);
  $all=!empty($share['all']);
  $out=[];
  foreach($users as $user){
    if(!is_array($user)) continue;
    $email=trim((string)($user['email']??''));
    if($email==='') continue;
    $roleMetier=trim((string)($user['role_metier']??''));
    $shared=$all
      || in_array($email,$wantedUsers,true)
      || ($roleMetier!=='' && in_array($roleMetier,$wantedRoles,true));
    if(!$shared) continue;
    if(!dmdtk_has_module_access($email)) continue;
    if(!in_array($email,$out,true)) $out[]=$email;
  }
  return $out;
}

/* Notification Core DoMyDesk uniquement pour les nouveaux destinataires. */
function tk_notify_new_share_recipients($ticket,$beforeShare,$afterShare,$actor,$root){
  if(!function_exists('dmd_notify_user')) return 0;

  $before=tk_share_recipients($beforeShare,$root);
  $after=tk_share_recipients($afterShare,$root);
  $added=array_values(array_diff($after,$before));

  $owner=trim((string)($ticket['owner']??''));
  $actor=trim((string)$actor);
  $ticketId=trim((string)($ticket['id']??''));
  $title=trim((string)($ticket['title']??'Ticket'));
  $sent=0;

  foreach($added as $email){
    $email=trim((string)$email);
    if($email==='' || $email===$actor || $email===$owner) continue;

    $message='Le ticket « '.$title.' » vous a été partagé';
    if($actor!=='') $message.=' par '.$actor;
    $message.='.';

    $ok=dmd_notify_user(
      $email,
      'ticket_shared',
      'Un ticket a été partagé avec vous',
      $message,
      [
        'level'=>'info',
        'action_url'=>'dashboard.php',
        'action_label'=>'Ouvrir les tickets',
        'meta'=>[
          'scope'=>'ticketing',
          'module'=>'dmd-ticketing',
          'ticket_id'=>$ticketId,
          'owner'=>$owner,
          'shared_by'=>$actor
        ]
      ]
    );
    if($ok!==false) $sent++;
  }

  return $sent;
}


/* Tous les participants d'un ticket : propriétaire + utilisateurs réellement couverts par le partage. */
function tk_ticket_recipients($ticket,$root){
  $out=[];
  $owner=trim((string)($ticket['owner']??''));
  if($owner!=='' && dmdtk_has_module_access($owner)) $out[]=$owner;
  foreach(tk_share_recipients($ticket['share']??[],$root) as $email){
    $email=trim((string)$email);
    if($email!=='' && !in_array($email,$out,true)) $out[]=$email;
  }
  return $out;
}

/* Notification Core commune aux participants, sans notifier l'auteur de l'action. */
function tk_notify_ticket_recipients($ticket,$actor,$type,$notificationTitle,$message,$root,$extraMeta=[]){
  if(!function_exists('dmd_notify_user')) return 0;

  $actor=trim((string)$actor);
  $ticketId=trim((string)($ticket['id']??''));
  $owner=trim((string)($ticket['owner']??''));
  $sent=0;

  foreach(tk_ticket_recipients($ticket,$root) as $email){
    $email=trim((string)$email);
    if($email==='' || ($actor!=='' && $email===$actor)) continue;

    $meta=[
      'scope'=>'ticketing',
      'module'=>'dmd-ticketing',
      'ticket_id'=>$ticketId,
      'owner'=>$owner
    ];
    if(is_array($extraMeta)) $meta=array_merge($meta,$extraMeta);

    $ok=dmd_notify_user(
      $email,
      (string)$type,
      (string)$notificationTitle,
      (string)$message,
      [
        'level'=>'info',
        'action_url'=>'dashboard.php',
        'action_label'=>'Ouvrir les tickets',
        'meta'=>$meta
      ]
    );
    if($ok!==false) $sent++;
  }

  return $sent;
}

function tk_notify_ticket_message($ticket,$actor,$root,$source='local'){
  $title=trim((string)($ticket['title']??'Ticket'));
  $actor=trim((string)$actor);
  if($source==='domyco'){
    return tk_notify_ticket_recipients(
      $ticket,'','ticket_message','Nouveau message sur un ticket',
      'Le ticket « '.$title.' » a reçu une nouvelle réponse de DomyCo.',
      $root,['event'=>'message','source'=>'domyco']
    );
  }

  $from=$actor!==''?$actor:'un utilisateur';
  return tk_notify_ticket_recipients(
    $ticket,$actor,'ticket_message','Nouveau message sur un ticket',
    $from.' a ajouté un nouveau message au ticket « '.$title.' ».',
    $root,['event'=>'message','source'=>'local','author'=>$actor]
  );
}

function tk_notify_ticket_status($ticket,$actor,$root,$source='local'){
  $title=trim((string)($ticket['title']??'Ticket'));
  $status=tk_status_label((string)($ticket['status']??'open'));
  $actor=trim((string)$actor);
  $message='Le statut du ticket « '.$title.' » est maintenant « '.$status.' ».';
  if($source==='local' && $actor!=='') $message='Le statut du ticket « '.$title.' » a été modifié par '.$actor.' : « '.$status.' ».';

  return tk_notify_ticket_recipients(
    $ticket,$source==='local'?$actor:'','ticket_status','Statut du ticket modifié',
    $message,$root,['event'=>'status','source'=>$source,'status'=>(string)($ticket['status']??'open')]
  );
}

function tk_path($id,$ticketsRoot=null,$indexFile=null){ return dmdtk_ticket_path($id); }
function tk_can_access($t,$me,$isAdmin,$root){ return dmdtk_can_access_ticket($t,$me); }
function tk_can_manage($t,$me,$isAdmin){ return dmdtk_can_manage_ticket($t,$me); }
function tk_can_delete($t,$me,$isAdmin){ return dmdtk_can_delete_ticket($t,$me); }
function tk_share_text($s){
  if(!is_array($s)) $s=[]; $p=[];
  if(!empty($s['all'])) $p[]='Tous';
  if(!empty($s['users'])) $p[]=count($s['users']).' utilisateur(s)';
  if(!empty($s['roles'])) $p[]='Rôle : '.implode(', ',$s['roles']);
  return $p?implode(' · ',$p):'Privé';
}
function tk_last_message($t){
  $last=''; foreach(($t['messages']??[]) as $m){ if(trim((string)($m['text']??''))!=='') $last=(string)$m['text']; }
  return $last;
}
function tk_summary($t,$me,$isAdmin){
  $share=$t['share']??[]; if(!is_array($share)) $share=[];
  return [
    'id'=>$t['id']??'', 'title'=>$t['title']??'', 'status'=>$t['status']??'open', 'status_label'=>tk_status_label($t['status']??'open'),
    'category'=>$t['category']??'', 'priority'=>$t['priority']??'', 'owner'=>$t['owner']??'',
    'created_at'=>$t['created_at']??null, 'updated_at'=>$t['updated_at']??null, 'last_message'=>tk_last_message($t),
    'share'=>$share, 'share_text'=>tk_share_text($share), 'meta'=>$t['meta']??[], 'send_to_domydesk'=>!empty($t['send_to_domydesk']),
    'can_manage'=>tk_can_manage($t,$me,$isAdmin), 'can_delete'=>tk_can_delete($t,$me,$isAdmin)
  ];
}

/* Liaison centrale DomyCo : endpoint interne au module, jamais saisi par l'utilisateur. */
function tk_domydesk_endpoint(){ return 'https://register.synohomes.com/ticket.php'; }
function tk_domydesk_instance_uid($root){
  $file=$root.'/../../data/id_domydesk.txt';
  return is_file($file)?trim((string)@file_get_contents($file)):'';
}
function tk_domydesk_instance_context($root){
  $context=['instance_uid'=>tk_domydesk_instance_uid($root)];
  $registerFile=$root.'/../../data/domyco_register.json';
  if(is_file($registerFile)){
    $register=tk_read_json($registerFile);
    $payload=(isset($register['payload'])&&is_array($register['payload']))?$register['payload']:[];
    foreach(['instance_name','domain','install_url','version'] as $key){ if(isset($payload[$key])&&is_scalar($payload[$key])) $context[$key]=(string)$payload[$key]; }
  }
  return $context;
}

function tk_domydesk_attachment_local_path($root,$url,$ticket=null,$attachment=null){
  if(is_array($attachment) && !empty($attachment['stored_name']) && is_array($ticket)){
    $owner=(string)(isset($ticket['owner'])?$ticket['owner']:'');
    $id=(string)(isset($ticket['id'])?$ticket['id']:'');
    $dir=dmdtk_files_dir($owner,$id,false);
    if($dir!==''){
      $candidate=realpath($dir.'/'.basename((string)$attachment['stored_name']));
      $base=realpath($dir);
      if($candidate&&$base&&is_file($candidate)&&strpos($candidate,rtrim($base,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR)===0) return $candidate;
    }
  }
  /* Compatibilité des anciennes URLs modules/ticketing/tickets/... durant migration. */
  $path=(string)(parse_url((string)$url,PHP_URL_PATH));
  $path=ltrim(str_replace('\\','/',rawurldecode($path)),'/');
  if(strpos($path,'modules/ticketing/tickets/')===0){
    $candidate=realpath(dmdtk_root().'/'.$path);
    $legacy=realpath(dmdtk_root().'/modules/ticketing/tickets');
    if($candidate&&$legacy&&is_file($candidate)&&strpos($candidate,rtrim($legacy,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR)===0) return $candidate;
  }
  return '';
}
function tk_domydesk_upload_one_attachment($endpoint,$instanceUid,$ticketId,$messageUid,$attachment,$path){
  if(!function_exists('curl_init')||!class_exists('CURLFile')) return ['ok'=>false,'error'=>'curl_file_unavailable'];
  $name=trim((string)($attachment['name']??basename($path))); if($name==='') $name=basename($path);
  $mime=function_exists('mime_content_type')?(string)@mime_content_type($path):'application/octet-stream';
  if($mime==='') $mime='application/octet-stream';
  $ch=curl_init($endpoint); if(!$ch) return ['ok'=>false,'error'=>'curl_init_failed'];
  $post=[
    'type'=>'ticketing_attachment',
    'instance_uid'=>$instanceUid,
    'local_ticket_id'=>$ticketId,
    'message_uid'=>$messageUid,
    'original_name'=>$name,
    'local_url'=>(string)($attachment['url']??$attachment['local_url']??''),
    'file'=>new CURLFile($path,$mime,$name)
  ];
  curl_setopt_array($ch,[
    CURLOPT_POST=>true,
    CURLOPT_POSTFIELDS=>$post,
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_CONNECTTIMEOUT=>5,
    CURLOPT_TIMEOUT=>45,
    CURLOPT_HTTPHEADER=>['Accept: application/json'],
    CURLOPT_USERAGENT=>'DMD-Ticketing/2.0'
  ]);
  $body=(string)curl_exec($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=(string)curl_error($ch); curl_close($ch);
  $decoded=json_decode($body,true); if(!is_array($decoded)) $decoded=[];
  if($http<200||$http>=300||empty($decoded['success'])){
    return ['ok'=>false,'http_code'=>$http,'error'=>$err!==''?$err:(string)($decoded['message']??'upload_failed')];
  }
  return ['ok'=>true,'http_code'=>$http,'attachment'=>is_array($decoded['attachment']??null)?$decoded['attachment']:[]];
}
function tk_domydesk_upload_attachments($ticket,$root,$instanceUid,$endpoint){
  $uploaded=[]; $errors=[];
  foreach((array)($ticket['messages']??[]) as $message){
    if(!is_array($message)) continue;
    $messageUid=trim((string)($message['id']??$message['message_uid']??'')); if($messageUid==='') continue;
    foreach((array)($message['attachments']??[]) as $attachment){
      if(!is_array($attachment)) continue;
      if(!empty($attachment['central_url'])||(($attachment['stored_on']??'')==='domycocenter')) continue;
      $localUrl=(string)($attachment['url']??$attachment['local_url']??'');
      $path=tk_domydesk_attachment_local_path($root,$localUrl,$ticket,$attachment);
      if($path===''){
        $errors[]=['message_uid'=>$messageUid,'local_url'=>$localUrl,'error'=>'local_file_not_found'];
        continue;
      }
      $result=tk_domydesk_upload_one_attachment(
        $endpoint,$instanceUid,(string)($ticket['id']??''),$messageUid,$attachment,$path
      );
      if(!empty($result['ok'])){
        $uploaded[]=[
          'message_uid'=>$messageUid,
          'local_url'=>$localUrl,
          'attachment'=>$result['attachment']
        ];
      }else{
        $errors[]=[
          'message_uid'=>$messageUid,
          'local_url'=>$localUrl,
          'http_code'=>(int)($result['http_code']??0),
          'error'=>(string)($result['error']??'upload_failed')
        ];
      }
    }
  }
  return ['uploaded'=>$uploaded,'errors'=>$errors];
}

function tk_outbox_mutate($callback){
  $lock=dmdtk_system_root(true).'/outbox.lock'; $fh=@fopen($lock,'c+'); if(!$fh) return false; $ok=false;
  if(@flock($fh,LOCK_EX)){
    $queue=dmdtk_read_json(dmdtk_outbox_file(),array()); if(!is_array($queue)) $queue=array();
    $next=call_user_func($callback,$queue); if(is_array($next)) $queue=$next;
    $ok=dmdtk_write_json(dmdtk_outbox_file(),$queue); @flock($fh,LOCK_UN);
  }
  @fclose($fh); @chmod($lock,0640); return $ok;
}
function tk_queue_domydesk_ticket($root,$payload){
  $ticketId=(string)($payload['ticket']['id']??'');
  tk_outbox_mutate(function($queue) use ($ticketId,$payload){
    $filtered=array();
    foreach($queue as $row){
      if(!is_array($row)) continue;
      $queuedId=(string)($row['payload']['ticket']['id']??'');
      if($ticketId!==''&&$queuedId===$ticketId) continue;
      $filtered[]=$row;
    }
    $filtered[]=array('queued_at'=>tk_now(),'payload'=>$payload); return $filtered;
  });
}
function tk_clear_queued_domydesk_ticket($root,$ticketId){
  tk_outbox_mutate(function($queue) use ($ticketId){
    $filtered=array(); foreach($queue as $row){ $queuedId=(string)($row['payload']['ticket']['id']??''); if($queuedId!==(string)$ticketId) $filtered[]=$row; } return $filtered;
  });
}
function tk_send_ticket_to_domydesk($ticket,$root,$event='upsert'){
  $instance=tk_domydesk_instance_context($root); $instanceUid=trim((string)($instance['instance_uid']??''));
  if($instanceUid==='') return ['status'=>'pending','reason'=>'instance_uid_missing','at'=>tk_now()];
  $payload=['type'=>'ticketing_ticket','event'=>$event,'sent_at'=>tk_now(),'instance_uid'=>$instanceUid,'instance'=>$instance,'ticket'=>$ticket];
  $json=json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  $endpoint=tk_domydesk_endpoint(); $ok=false; $http=0; $err=''; $responseBody='';
  if(function_exists('curl_init')){
    $ch=curl_init($endpoint);
    if($ch){
      curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$json,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_TIMEOUT=>8,CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json'],CURLOPT_USERAGENT=>'DMD-Ticketing/2.0']);
      $responseBody=(string)curl_exec($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=(string)curl_error($ch); curl_close($ch);
      $ok=($http>=200&&$http<300);
    }
  }else{
    $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: application/json\r\nAccept: application/json\r\nUser-Agent: DMD-Ticketing/2.0\r\n",'content'=>$json,'timeout'=>8,'ignore_errors'=>true]]);
    $res=@file_get_contents($endpoint,false,$ctx); $responseBody=$res===false?'':(string)$res;
    if(isset($http_response_header)&&is_array($http_response_header)) foreach($http_response_header as $h){ if(preg_match('#HTTP/\\S+\\s+(\\d+)#',$h,$m)){ $http=(int)$m[1]; break; } }
    $ok=($res!==false&&$http>=200&&$http<300);
  }
  $decoded=json_decode($responseBody,true); if(!is_array($decoded)) $decoded=[];
  if(!$ok||empty($decoded['success'])){
    if($event==='pull' && $http===404 && (string)($decoded['error']??'')==='TICKET_NOT_FOUND'){
      return ['status'=>'remote_missing','reason'=>'remote_not_found','http_code'=>$http,'error'=>(string)($decoded['message']??'Ticket distant introuvable.'),'at'=>tk_now()];
    }
    if($event!=='pull') tk_queue_domydesk_ticket($root,$payload);
    return ['status'=>'pending','reason'=>'send_failed','http_code'=>$http,'error'=>$err!==''?$err:(string)($decoded['message']??''),'at'=>tk_now()];
  }
  $attachmentSync=['uploaded'=>[],'errors'=>[]];
  if($event==='upsert'){
    $attachmentSync=tk_domydesk_upload_attachments($ticket,$root,$instanceUid,$endpoint);
  }
  $common=[
    'http_code'=>$http,'at'=>tk_now(),
    'central_ticket_id'=>(string)($decoded['ticket']['central_ticket_uid']??''),
    'central_status'=>(string)($decoded['ticket']['status']??''),
    'central_updated_at'=>(string)($decoded['ticket']['updated_at']??''),
    'central_messages'=>isset($decoded['central_messages'])&&is_array($decoded['central_messages'])?$decoded['central_messages']:[],
    'remote_deleted'=>!empty($decoded['deleted']) || !empty($decoded['ticket']['deleted']),
    'deleted_at'=>(string)($decoded['ticket']['deleted_at']??''),
    'deleted_by'=>(string)($decoded['ticket']['deleted_by']??''),
    'uploaded_attachments'=>$attachmentSync['uploaded']
  ];
  if(!empty($attachmentSync['errors'])){
    tk_queue_domydesk_ticket($root,$payload);
    return array_merge($common,[
      'status'=>'pending',
      'reason'=>'attachments_upload_failed',
      'attachment_errors'=>$attachmentSync['errors']
    ]);
  }
  tk_clear_queued_domydesk_ticket($root,(string)($ticket['id']??''));
  return array_merge($common,['status'=>'sent']);
}
function tk_domydesk_requested($ticket){ return !empty($ticket['meta']['domydesk']['requested']) || !empty($ticket['send_to_domydesk']); }
function tk_apply_domydesk_result(&$ticket,$result){
  if(!isset($ticket['meta'])||!is_array($ticket['meta'])) $ticket['meta']=[];
  $previous=(isset($ticket['meta']['domydesk'])&&is_array($ticket['meta']['domydesk']))?$ticket['meta']['domydesk']:[];
  $previousNotification=(isset($previous['notification'])&&is_array($previous['notification']))?$previous['notification']:[];
  $beforeStatus=(string)($ticket['status']??'open');

  $knownCentral=[];
  foreach((array)($ticket['messages']??[]) as $message){
    if(!is_array($message)||(($message['role']??'')!=='domydesk')) continue;
    $mid=(string)($message['id']??'');
    if($mid!=='') $knownCentral[$mid]=true;
  }

  $meta=['requested'=>true,'status'=>(string)($result['status']??'pending'),'at'=>(string)($result['at']??tk_now())];
  foreach(['reason','http_code','error','central_ticket_id','central_status','central_updated_at'] as $key){
    if(isset($result[$key])&&$result[$key]!=='') $meta[$key]=$result[$key];
    elseif(isset($previous[$key])) $meta[$key]=$previous[$key];
  }
  if(isset($result['attachment_errors'])&&is_array($result['attachment_errors'])&&$result['attachment_errors']){
    $meta['attachment_errors']=$result['attachment_errors'];
  }

  $ticket['send_to_domydesk']=true;
  $uploaded=isset($result['uploaded_attachments'])&&is_array($result['uploaded_attachments'])?$result['uploaded_attachments']:[];
  if($uploaded&&isset($ticket['messages'])&&is_array($ticket['messages'])){
    foreach($uploaded as $upload){
      if(!is_array($upload)) continue;
      $messageUid=(string)($upload['message_uid']??'');
      $localUrl=(string)($upload['local_url']??'');
      $central=is_array($upload['attachment']??null)?$upload['attachment']:[];
      foreach($ticket['messages'] as &$localMessage){
        if((string)($localMessage['id']??'')!==$messageUid||!isset($localMessage['attachments'])||!is_array($localMessage['attachments'])) continue;
        foreach($localMessage['attachments'] as &$localAttachment){
          if(!is_array($localAttachment)) continue;
          $candidate=(string)($localAttachment['url']??$localAttachment['local_url']??'');
          if($candidate!==$localUrl) continue;
          $originalUrl=$candidate;
          $localAttachment=array_merge($localAttachment,$central);
          $localAttachment['local_url']=$originalUrl;
          if(!empty($central['url'])) $localAttachment['url']=$central['url'];
        }
        unset($localAttachment);
      }
      unset($localMessage);
    }
  }

  $remoteStatus=(string)($result['central_status']??'');
  $statusChanged=false;
  if(tk_status_valid($remoteStatus)){
    $statusChanged=$remoteStatus!==$beforeStatus;
    $ticket['status']=$remoteStatus;
  }

  $centralMessages=isset($result['central_messages'])&&is_array($result['central_messages'])?$result['central_messages']:[];
  if(!isset($ticket['messages'])||!is_array($ticket['messages'])) $ticket['messages']=[];
  $newCentralCount=0;
  $lastCentralAt='';
  foreach($centralMessages as $message){
    if(!is_array($message)) continue;
    $mid=trim((string)($message['message_uid']??$message['id']??''));
    if($mid===''||isset($knownCentral[$mid])) continue;
    $created=(string)($message['created_at']??tk_now());
    $ticket['messages'][]=[
      'id'=>$mid,
      'at'=>$created,
      'by'=>(string)($message['author_email']??'Support DomyCo'),
      'role'=>'domydesk',
      'text'=>(string)($message['message_text']??''),
      'attachments'=>isset($message['attachments'])&&is_array($message['attachments'])?$message['attachments']:[]
    ];
    $knownCentral[$mid]=true;
    $newCentralCount++;
    $lastCentralAt=$created;
  }

  if($newCentralCount>0||$statusChanged){
    $previousUnread=!empty($previousNotification['unread']);
    $previousCount=$previousUnread?(int)($previousNotification['count']??0):0;
    $delta=$newCentralCount+($statusChanged?1:0);
    $meta['notification']=[
      'unread'=>true,
      'state'=>'new',
      'count'=>$previousCount+max(1,$delta),
      'at'=>$lastCentralAt!==''?$lastCentralAt:tk_now(),
      'kind'=>$newCentralCount>0?'message':'status',
      'label'=>$newCentralCount>0?'Nouvelle réponse de DomyCo':'Nouveau statut depuis DomyCo'
    ];
    $ticket['updated_at']=tk_now();
  }else{
    $meta['notification']=$previousNotification ?: [
      'unread'=>false,
      'state'=>'idle',
      'count'=>0,
      'at'=>tk_now(),
      'label'=>'Aucune nouvelle information'
    ];
    if(empty($meta['notification']['unread'])){
      $meta['notification']['state']='idle';
      $meta['notification']['count']=0;
      $meta['notification']['label']='Aucune nouvelle information';
    }
  }

  $ticket['meta']['domydesk']=$meta;
}
function tk_sync_domydesk_ticket(&$ticket,$root,$event='upsert'){
  $beforeStatus=(string)($ticket['status']??'open');
  $beforeCentral=[];
  foreach((array)($ticket['messages']??[]) as $message){
    if(!is_array($message)||(($message['role']??'')!=='domydesk')) continue;
    $mid=trim((string)($message['id']??''));
    if($mid!=='') $beforeCentral[$mid]=true;
  }

  $result=tk_send_ticket_to_domydesk($ticket,$root,$event);
  tk_apply_domydesk_result($ticket,$result);

  $newCentral=0;
  foreach((array)($ticket['messages']??[]) as $message){
    if(!is_array($message)||(($message['role']??'')!=='domydesk')) continue;
    $mid=trim((string)($message['id']??''));
    if($mid!=='' && !isset($beforeCentral[$mid])) $newCentral++;
  }
  $activityUser=dmdtk_user_email();
  if($newCentral>0){
    tk_notify_ticket_message($ticket,'',$root,'domyco');
    if($activityUser!=='') dmdtk_log($activityUser,'domyco_reply',(string)($ticket['id']??''),'success',array(
      'title'=>(string)($ticket['title']??''),'source'=>'DomyCo','messages'=>$newCentral
    ));
  }
  if((string)($ticket['status']??'open')!==$beforeStatus){
    tk_notify_ticket_status($ticket,'',$root,'domyco');
    if($activityUser!=='') dmdtk_log($activityUser,'domyco_status',(string)($ticket['id']??''),'success',array(
      'title'=>(string)($ticket['title']??''),'source'=>'DomyCo','before'=>$beforeStatus,'after'=>(string)($ticket['status']??'open')
    ));
  }

  return $result;
}
function tk_delete_local_ticket_files($ticketPath,$ticket,$ticketsRoot=null,$indexFile=null){
  dmdtk_delete_local_ticket($ticket);
}
function tk_require_csrf($input){
  $token=is_array($input)&&isset($input['csrf'])?(string)$input['csrf']:'';
  if(!dmdtk_csrf_valid($token)){
    http_response_code(403);
    echo json_encode(array('ok'=>false,'err'=>'csrf_invalid'),JSON_UNESCAPED_UNICODE);
    exit;
  }
}
function tk_require_capability($cap){
  if(!dmdtk_user_can($GLOBALS['me'],$cap)){
    http_response_code(403);
    echo json_encode(array('ok'=>false,'err'=>'permission_denied','capability'=>$cap),JSON_UNESCAPED_UNICODE);
    exit;
  }
}


$cfg=dmdtk_config(); $CATS=$cfg['categories']; $PRIO=$cfg['priorities'];
$a=$_GET['a'] ?? ($_POST['a'] ?? '');
$input=json_decode(file_get_contents('php://input')?:'',true); if(!is_array($input)) $input=[];

switch($a){
  case 'bootstrap': {
    [$users,$roles]=tk_users($root);
    echo json_encode(array('ok'=>true,'me'=>$me,'is_admin'=>$isAdmin,'csrf'=>$csrf,'categories'=>$CATS,'priorities'=>$PRIO,'statuses'=>tk_statuses(),'users'=>$users,'roles'=>$roles,'permissions'=>array('create'=>dmdtk_user_can($me,'ticket.create'),'reply'=>dmdtk_user_can($me,'ticket.reply'),'share'=>dmdtk_user_can($me,'ticket.share'),'status'=>dmdtk_user_can($me,'ticket.status'),'sync'=>dmdtk_user_can($me,'ticket.sync'))),JSON_UNESCAPED_UNICODE); exit;
  }
  case 'list': {
    tk_require_capability('view');
    $status=(string)($input['status']??'all'); $cat=tk_clean($input['category']??''); $pri=tk_clean($input['priority']??''); $q=function_exists('mb_strtolower')?mb_strtolower(tk_clean($input['q']??'')):strtolower(tk_clean($input['q']??'')); $scope=(string)($input['scope']??'visible');
    $out=array();
    foreach(dmdtk_index() as $ticketId=>$idx){
      if(!is_array($idx)) continue;
      if($scope==='mine' && (string)($idx['owner']??'')!==$me) continue;
      if($scope==='all' && !(dmdtk_is_admin($me)&&dmdtk_user_can($me,'admin.view_all'))) continue;
      list($t,$p,$owner)=dmdtk_ticket_read((string)$ticketId);
      if(!is_array($t)||!$t) continue;
      if(!tk_can_access($t,$me,$isAdmin,$root)) continue;
      if($status!=='all' && ($t['status']??'open')!==$status) continue;
      if($cat!=='' && ($t['category']??'')!==$cat) continue;
      if($pri!=='' && ($t['priority']??'')!==$pri) continue;
      if($q!==''){
        $hay=(string)($t['title']??'').' '.(string)($t['owner']??'').' '.tk_last_message($t);
        $hay=function_exists('mb_strtolower')?mb_strtolower($hay):strtolower($hay);
        $found=function_exists('mb_strpos')?mb_strpos($hay,$q):strpos($hay,$q);
        if($found===false) continue;
      }
      $out[]=tk_summary($t,$me,$isAdmin);
    }
    usort($out,function($a,$b){ return strcmp($b['updated_at']??$b['created_at']??'',$a['updated_at']??$a['created_at']??''); });
    echo json_encode(array('ok'=>true,'items'=>$out),JSON_UNESCAPED_UNICODE); exit;
  }
  case 'sync_all': {
    tk_require_csrf($input); tk_require_capability('ticket.sync');
    $synced=0; $pending=0; $failed=0; $deleted=0;
    foreach(dmdtk_index() as $ticketId=>$idx){
      if(!is_array($idx)) continue;
      if(array_key_exists('domyco_requested',$idx) && empty($idx['domyco_requested'])) continue;
      list($t,$p,$owner)=dmdtk_ticket_read((string)$ticketId);
      if(!is_array($t)||!$t) continue;
      if(!tk_can_access($t,$me,$isAdmin,$root) || !tk_domydesk_requested($t)) continue;
      $dmStatus=(string)($t['meta']['domydesk']['status']??'');
      $force=!empty($input['force']);
      $lastAt=strtotime((string)($t['meta']['domydesk']['at']??''))?:0;
      if(!$force && $lastAt>0 && (time()-$lastAt)<120) continue;
      $event=in_array($dmStatus,array('sent','remote_missing'),true)?'pull':'upsert';
      $result=tk_sync_domydesk_ticket($t,$root,$event);
      if(!empty($result['remote_deleted'])){
        dmdtk_delete_local_ticket($t); dmdtk_log($me,'remote_delete',(string)$ticketId,'success',array('deleted_by'=>$result['deleted_by']??'DomyCo')); $synced++; $deleted++; continue;
      }
      dmdtk_ticket_write($t);
      if(($result['status']??'')==='sent') $synced++; elseif(($result['status']??'')==='pending') $pending++; else $failed++;
    }
    echo json_encode(array('ok'=>true,'synced'=>$synced,'pending'=>$pending,'failed'=>$failed,'deleted'=>$deleted),JSON_UNESCAPED_UNICODE); exit;
  }
  case 'create': {
    tk_require_csrf($input); tk_require_capability('ticket.create');
    $title=tk_clean($input['title']??''); $message=tk_clean($input['message']??''); $cat=tk_clean($input['category']??($CATS[0]??'Support')); $pri=tk_clean($input['priority']??($PRIO[0]??'normale'));
    if(tk_strlen($title)<3){ echo json_encode(['ok'=>false,'err'=>'Titre trop court']); exit; }
    if($message===''){ echo json_encode(['ok'=>false,'err'=>'Message requis']); exit; }
    if(!in_array($cat,$CATS,true)) $cat=$CATS[0]??'Support'; if(!in_array($pri,$PRIO,true)) $pri=$PRIO[0]??'normale';
    $share=$input['share']??[]; if(!is_array($share)) $share=[];
    $share=['all'=>!empty($share['all']),'users'=>tk_clean_array($share['users']??[]),'roles'=>tk_clean_array($share['roles']??[])];
    $id=tk_id();
    $t=['id'=>$id,'owner'=>$me,'created_at'=>tk_now(),'updated_at'=>tk_now(),'status'=>'open','title'=>$title,'category'=>$cat,'priority'=>$pri,'share'=>$share,'send_to_domydesk'=>!empty($input['send_to_domydesk']),'messages'=>[['id'=>tk_message_id(),'at'=>tk_now(),'by'=>$me,'role'=>'owner','text'=>$message,'attachments'=>[]]],'meta'=>[]];
    if(!empty($input['send_to_domydesk'])) $t['meta']['domydesk']=['requested'=>true,'status'=>'pending','at'=>tk_now()];
    dmdtk_ticket_write($t);
    if(tk_domydesk_requested($t)){ tk_sync_domydesk_ticket($t,$root,'upsert'); dmdtk_ticket_write($t); }
    $shareNotifications=tk_notify_new_share_recipients($t,[],$share,$me,$root);
    dmdtk_log($me,'create',$id,'success',array('title'=>$title,'domyco'=>tk_domydesk_requested($t),'share_notifications'=>$shareNotifications));
    echo json_encode(['ok'=>true,'id'=>$id,'domydesk'=>$t['meta']['domydesk']??null,'share_notifications'=>$shareNotifications],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'get': {
    $id=tk_clean($input['id']??($_GET['id']??'')); if($id===''){ echo json_encode(['ok'=>false,'err'=>'missing_id']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }

    /*
     * Lecture locale uniquement : l'ouverture de la popup ne dépend plus
     * de register.synohomes.com. La synchronisation reste assurée par
     * sync_all (automatique), le bouton Actualiser et le bouton Synchroniser.
     */
    $t['can_manage']=tk_can_manage($t,$me,$isAdmin); $t['can_delete']=tk_can_delete($t,$me,$isAdmin);
    echo json_encode(['ok'=>true,'item'=>$t],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'mark_read': {
    tk_require_csrf($input); tk_require_capability('view');
    $id=tk_clean($input['id']??''); if($id===''){ echo json_encode(['ok'=>false,'err'=>'missing_id']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(!isset($t['meta'])||!is_array($t['meta'])) $t['meta']=[];
    if(!isset($t['meta']['domydesk'])||!is_array($t['meta']['domydesk'])) $t['meta']['domydesk']=[];
    $previous=(isset($t['meta']['domydesk']['notification'])&&is_array($t['meta']['domydesk']['notification']))?$t['meta']['domydesk']['notification']:[];
    $t['meta']['domydesk']['notification']=array_merge($previous,[
      'unread'=>false,'state'=>'idle','count'=>0,'seen_at'=>tk_now(),'label'=>'Aucune nouvelle information'
    ]);
    dmdtk_ticket_write($t);
    echo json_encode(['ok'=>true],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'reply': {
    tk_require_csrf($input); tk_require_capability('ticket.reply');
    $id=tk_clean($input['id']??''); $msg=tk_clean($input['message']??''); if($id===''||$msg===''){ echo json_encode(['ok'=>false,'err'=>'message_empty']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(($t['status']??'open')==='closed'){ echo json_encode(['ok'=>false,'err'=>'closed']); exit; }
    $t['messages'][]=['id'=>tk_message_id(),'at'=>tk_now(),'by'=>$me,'role'=>tk_can_manage($t,$me,$isAdmin)?((($t['owner']??'')===$me)?'owner':'admin'):'shared','text'=>$msg,'attachments'=>[]]; $t['updated_at']=tk_now();
    $domydeskResult=null;
    if(tk_domydesk_requested($t)) $domydeskResult=tk_sync_domydesk_ticket($t,$root,'upsert');
    dmdtk_ticket_write($t);
    $messageNotifications=tk_notify_ticket_message($t,$me,$root,'local');
    dmdtk_log($me,'reply',$id,'success',array('domyco'=>tk_domydesk_requested($t),'message_notifications'=>$messageNotifications));
    echo json_encode(['ok'=>true,'domydesk'=>$domydeskResult,'message_notifications'=>$messageNotifications],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'sync': {
    tk_require_csrf($input); tk_require_capability('ticket.sync');
    $id=tk_clean($input['id']??''); if($id===''){ echo json_encode(['ok'=>false,'err'=>'missing_id']); exit; }
    [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_access($t,$me,$isAdmin,$root)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(!tk_domydesk_requested($t)){ echo json_encode(['ok'=>true,'skipped'=>true]); exit; }
    $dmStatus=(string)($t['meta']['domydesk']['status']??''); $event=in_array($dmStatus,array('sent','remote_missing'),true)?'pull':'upsert'; $result=tk_sync_domydesk_ticket($t,$root,$event);
    if(!empty($result['remote_deleted'])){
      dmdtk_delete_local_ticket($t); dmdtk_log($me,'remote_delete',$id,'success',array('source'=>'DomyCo'));
      echo json_encode(['ok'=>true,'deleted'=>true,'result'=>$result],JSON_UNESCAPED_UNICODE); exit;
    }
    dmdtk_ticket_write($t); dmdtk_log($me,'sync',$id,'success',array('status'=>$result['status']??''));
    echo json_encode(['ok'=>true,'domydesk'=>$t['meta']['domydesk']??[],'result'=>$result],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'update': {
    tk_require_csrf($input);
    $id=tk_clean($input['id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_manage($t,$me,$isAdmin)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    if(isset($input['share'])) tk_require_capability('ticket.share');
    if(isset($input['status'])) tk_require_capability('ticket.status');
    if(isset($input['title'])||isset($input['category'])||isset($input['priority'])){ if((string)($t['owner']??'')!==$me) tk_require_capability('admin.edit_any'); }
    $shareBefore=(isset($t['share'])&&is_array($t['share']))?$t['share']:[];
    $shareChanged=false;
    $statusBefore=(string)($t['status']??'open');
    if(isset($input['title'])){ $title=tk_clean($input['title']); if($title!=='') $t['title']=$title; }
    if(isset($input['status'])&&tk_status_valid($input['status'])) $t['status']=(string)$input['status'];
    if(isset($input['category'])&&in_array($input['category'],$CATS,true)) $t['category']=$input['category'];
    if(isset($input['priority'])&&in_array($input['priority'],$PRIO,true)) $t['priority']=$input['priority'];
    if(isset($input['share'])&&is_array($input['share'])){
      $t['share']=['all'=>!empty($input['share']['all']),'users'=>tk_clean_array($input['share']['users']??[]),'roles'=>tk_clean_array($input['share']['roles']??[])];
      $shareChanged=true;
    }
    $t['updated_at']=tk_now();
    if(tk_domydesk_requested($t)) tk_sync_domydesk_ticket($t,$root,'upsert');
    dmdtk_ticket_write($t);
    $shareNotifications=$shareChanged?tk_notify_new_share_recipients($t,$shareBefore,$t['share']??[],$me,$root):0;
    $statusNotifications=((string)($t['status']??'open')!==$statusBefore)?tk_notify_ticket_status($t,$me,$root,'local'):0;
    dmdtk_log($me,'update',$id,'success',array('status'=>$t['status']??'','share_notifications'=>$shareNotifications,'status_notifications'=>$statusNotifications));
    echo json_encode(['ok'=>true,'share_notifications'=>$shareNotifications,'status_notifications'=>$statusNotifications],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'close': case 'reopen': {
    tk_require_csrf($input); tk_require_capability('ticket.status');
    $id=tk_clean($input['id']??''); [$p,$owner]=tk_path($id,$ticketsRoot,$indexFile); if(!$p){ echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }
    $t=tk_read_json($p); if(!tk_can_manage($t,$me,$isAdmin)){ echo json_encode(['ok'=>false,'err'=>'forbidden']); exit; }
    $statusBefore=(string)($t['status']??'open');
    $t['status']=$a==='close'?'closed':'open';
    $t['updated_at']=tk_now();
    if(tk_domydesk_requested($t)) tk_sync_domydesk_ticket($t,$root,'upsert');
    dmdtk_ticket_write($t);
    $statusNotifications=((string)($t['status']??'open')!==$statusBefore)?tk_notify_ticket_status($t,$me,$root,'local'):0;
    dmdtk_log($me,$a,$id,'success',array('status'=>$t['status'],'status_notifications'=>$statusNotifications));
    echo json_encode(['ok'=>true,'status_notifications'=>$statusNotifications],JSON_UNESCAPED_UNICODE); exit;
  }
  case 'delete': {
    tk_require_csrf($input);
    $id=tk_clean($input['id']??''); list($p,$owner)=tk_path($id); if(!$p){ echo json_encode(array('ok'=>false,'err'=>'not_found')); exit; }
    $t=tk_read_json($p); if(!tk_can_delete($t,$me,$isAdmin)){ echo json_encode(array('ok'=>false,'err'=>'forbidden')); exit; }
    if((string)($t['owner']??'')===$me) tk_require_capability('ticket.delete_own'); else tk_require_capability('admin.delete_any');
    $remote=null;
    if(tk_domydesk_requested($t)){
      $remote=tk_send_ticket_to_domydesk($t,$root,'delete');
      if(($remote['status']??'pending')!=='sent'){
        dmdtk_log($me,'delete',$id,'error',array('reason'=>'domyco_delete_failed','remote'=>$remote));
        echo json_encode(array('ok'=>false,'err'=>'domyco_delete_failed','message'=>'Suppression DomyCo impossible : le ticket local est conservé.','remote'=>$remote),JSON_UNESCAPED_UNICODE); exit;
      }
    }
    dmdtk_delete_local_ticket($t); dmdtk_log($me,'delete',$id,'success',array('remote'=>tk_domydesk_requested($t)));
    echo json_encode(array('ok'=>true,'remote'=>$remote),JSON_UNESCAPED_UNICODE); exit;
  }
  default: echo json_encode(['ok'=>false,'err'=>'bad_action']); exit;
}