<?php
/* * =====================================================================
                                DoMyDesk
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
*
Ce fichier fait partie du logiciel DoMyDesk.
*
Toute reproduction, redistribution, revente, publication ou
intégration de tout ou partie de ce code dans un autre produit
sans autorisation préalable de SynoHomes est interdite.
*
La modification du logiciel dans le cadre de son utilisation
*
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0
*
Éditeur : SynoHomes

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('X-Content-Type-Options: nosniff');
error_reporting(0);

$me = dmdtk_user_email();
if (!$me) { echo "<div class='section dmd-ticketing-cfg'><div class='tk-empty'>⛔ Non connecté.</div></div>"; return; }
$canGeneralConfig = dmdtk_user_can($me, 'admin.configure');
$canExternalConfig = dmdtk_user_can($me, 'external.configure') && dmdtk_is_admin($me);
if (!$canGeneralConfig && !$canExternalConfig) { echo "<div class='section dmd-ticketing-cfg'><div class='tk-empty'>⛔ Configuration DMD-Ticketing non autorisée.</div></div>"; return; }

function tkcfg_lines($s) {
    $out = array();
    foreach (preg_split('~\R+~', (string)$s) as $v) {
        $v = trim($v);
        if ($v !== '' && !in_array($v, $out, true)) $out[] = $v;
    }
    return $out;
}

$cfg = dmdtk_config();
$cats = $cfg['categories'];
$pri = $cfg['priorities'];
$supportCfg = isset($cfg['external_support']) && is_array($cfg['external_support']) ? $cfg['external_support'] : array();
$msg = '';
$msgType = 'ok';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!dmdtk_csrf_valid(isset($_POST['csrf']) ? (string)$_POST['csrf'] : '')) { http_response_code(403); exit('Formulaire expiré.'); }
    $action = trim((string)($_POST['cfg_action'] ?? 'save'));

    if ($action === 'import_link') {
        if (!$canExternalConfig) {
            $msg = 'Seul un administrateur autorisé peut importer une liaison Support.'; $msgType = 'error';
        } elseif (!isset($_FILES['ticket_link']) || !is_array($_FILES['ticket_link'])) {
            $msg = 'Aucun fichier de liaison reçu.'; $msgType = 'error';
        } else {
            $upload = $_FILES['ticket_link'];
            $name = (string)($upload['name'] ?? '');
            if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                $msg = 'Erreur pendant l’import du fichier de liaison.'; $msgType = 'error';
            } elseif (($upload['size'] ?? 0) <= 0 || ($upload['size'] ?? 0) > 131072) {
                $msg = 'Taille du fichier de liaison invalide.'; $msgType = 'error';
            } elseif (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'dmdticketlink') {
                $msg = 'Le fichier doit être au format .dmdticketlink.'; $msgType = 'error';
            } else {
                $raw = @file_get_contents((string)$upload['tmp_name']);
                $result = is_string($raw) ? dmdtk_link_import_raw($raw, $me) : array('ok'=>false,'error'=>'LINK_READ_FAILED');
                if (!empty($result['ok'])) {
                    $cfg = dmdtk_config(); $supportCfg = $cfg['external_support'];
                    $msg = 'Liaison Support importée pour « ' . (string)($supportCfg['name'] ?? 'Support') . ' ».';
                    dmdtk_log($me, 'external_link_import', 'config', 'success', array('support'=>(string)($supportCfg['name']??''),'client_ref'=>(string)($supportCfg['client_ref']??'')));
                } else {
                    $err = (string)($result['error'] ?? 'LINK_INVALID');
                    if ($err === 'LINK_INSTANCE_MISMATCH') $msg = 'Ce fichier de liaison a été créé pour une autre instance DoMyDesk.';
                    elseif ($err === 'LINK_SIGNATURE_INVALID') $msg = 'Signature du fichier de liaison invalide.';
                    else $msg = 'Fichier de liaison refusé : ' . $err;
                    $msgType = 'error';
                }
            }
        }
    } elseif ($action === 'remove_link') {
        if (!$canExternalConfig) { $msg='Droit insuffisant.'; $msgType='error'; }
        else {
            $empty = dmdtk_default_config()['external_support'];
            $saved = dmdtk_save_config($cats, $pri, $me, array('external_support'=>$empty,'external_receive'=>$cfg['external_receive']??array()));
            if ($saved === false) { $msg='Impossible de supprimer la liaison.'; $msgType='error'; }
            else { $cfg=$saved; $supportCfg=$cfg['external_support']; $msg='Liaison Support supprimée.'; dmdtk_log($me,'external_link_remove','config','success',array()); }
        }
    } else {
        $catsP = $canGeneralConfig ? tkcfg_lines($_POST['categories'] ?? '') : $cats;
        $priP = $canGeneralConfig ? tkcfg_lines($_POST['priorities'] ?? '') : $pri;
        $saved = dmdtk_save_config($catsP, $priP, $me, array('external_support'=>$supportCfg,'external_receive'=>$cfg['external_receive']??array()));
        if ($saved === false) { $msg='Erreur : impossible d’enregistrer la configuration.'; $msgType='error'; }
        else { $cfg=$saved; $cats=$cfg['categories']; $pri=$cfg['priorities']; $supportCfg=$cfg['external_support']; $msg='Configuration enregistrée.'; dmdtk_log($me,'configure','config','success',array('categories'=>count($cats),'priorities'=>count($pri))); }
    }
}

$uid = substr(bin2hex(random_bytes(4)), 0, 8);
$cssVersion = @filemtime(__DIR__ . '/dmd-ticketing.css') ?: time();
$hasLink = !empty($supportCfg['enabled']);
?>
<link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing.css?v=<?= (int)$cssVersion ?>">
<div id="ticketing-cfg-<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>" class="section dmd-ticketing-cfg">
  <div class="tk-shell">
    <section class="tk-hero">
      <div class="tk-title">
        <div class="tk-icon">⚙️</div>
        <div><h2>Configuration DMD-Ticketing</h2><p>Paramètres du module et liaison avec votre entreprise de support.</p></div>
      </div>
      <div class="tk-actions"><button type="button" class="btn tk-btn" data-refresh>↻ Actualiser</button></div>
    </section>

    <section class="tk-cfg-grid tk-cfg-grid-single">
      <div class="tk-panel tk-compose tk-cfg-main">
        <?php if ($msg): ?><div class="tk-msg tk-cfg-message <?= $msgType === 'error' ? 'is-error' : 'is-ok' ?>"><?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

        <?php if ($canGeneralConfig): ?>
        <form method="post">
          <input type="hidden" name="csrf" value="<?= htmlspecialchars(dmdtk_csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="cfg_action" value="save">
          <div class="tk-cfg-section">
            <strong>Paramètres du module</strong>
            <div class="tk-cfg-two">
              <div class="tk-field"><label>Catégories — une par ligne</label><textarea name="categories" class="input tk-input" rows="6"><?= htmlspecialchars(implode("\n", $cats), ENT_QUOTES, 'UTF-8') ?></textarea></div>
              <div class="tk-field"><label>Priorités — une par ligne</label><textarea name="priorities" class="input tk-input" rows="6"><?= htmlspecialchars(implode("\n", $pri), ENT_QUOTES, 'UTF-8') ?></textarea></div>
            </div>
            <div class="tk-actions tk-cfg-save-row"><button class="btn tk-btn tk-btn-primary" type="submit">Enregistrer les paramètres</button></div>
          </div>
        </form>
        <?php endif; ?>

        <?php if ($canExternalConfig): ?>
        <hr class="tk-cfg-separator">
        <div class="tk-cfg-section">
          <div class="tk-cfg-section-head">
            <div><strong>📤 Liaison avec une entreprise Support</strong><div class="tk-hint">Le fichier est obligatoirement créé par l’entreprise Support. Ce DoMyDesk ne peut pas fabriquer lui-même une liaison.</div></div>
            <span class="tk-cfg-license-state <?= $hasLink ? 'is-active' : 'is-required' ?>"><?= $hasLink ? 'Liaison active' : 'Non configuré' ?></span>
          </div>

          <?php if ($hasLink): ?>
            <div class="tk-cfg-support-grid">
              <div class="tk-field"><label>Entreprise Support</label><div class="tk-cfg-readonly"><strong><?= htmlspecialchars((string)($supportCfg['name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></strong></div></div>
              <div class="tk-field"><label>Entreprise cliente</label><div class="tk-cfg-readonly"><?= htmlspecialchars((string)($supportCfg['client_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></div></div>
              <div class="tk-field tk-cfg-wide"><label>Adresse de réception</label><div class="tk-cfg-readonly"><code><?= htmlspecialchars((string)($supportCfg['endpoint'] ?? ''), ENT_QUOTES, 'UTF-8') ?></code></div></div>
              <div class="tk-field"><label>Référence client</label><div class="tk-cfg-readonly"><code><?= htmlspecialchars((string)($supportCfg['client_ref'] ?? ''), ENT_QUOTES, 'UTF-8') ?></code></div></div>
              <div class="tk-field"><label>Instance Support</label><div class="tk-cfg-readonly"><code><?= htmlspecialchars((string)($supportCfg['support_instance_id'] ?? ''), ENT_QUOTES, 'UTF-8') ?></code></div></div>
            </div>
            <div class="tk-hint">Les clés et jetons de liaison sont chiffrés dans le stockage local et ne sont pas affichés ici.</div>
            <form method="post" onsubmit="return confirm('Supprimer la liaison avec cette entreprise Support ?');" class="tk-actions tk-cfg-save-row">
              <input type="hidden" name="csrf" value="<?= htmlspecialchars(dmdtk_csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
              <input type="hidden" name="cfg_action" value="remove_link">
              <button class="btn tk-btn tk-btn-danger" type="submit">Supprimer la liaison</button>
            </form>
          <?php else: ?>
            <form method="post" enctype="multipart/form-data" class="tk-cfg-link-import">
              <input type="hidden" name="csrf" value="<?= htmlspecialchars(dmdtk_csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
              <input type="hidden" name="cfg_action" value="import_link">
              <div class="tk-field"><label>Fichier fourni par votre Support</label><input type="file" name="ticket_link" accept=".dmdticketlink,application/json" required></div>
              <button class="btn tk-btn tk-btn-primary" type="submit">📥 Importer la liaison</button>
            </form>
            <div class="tk-hint">L’import vérifie la signature du fichier et l’ID unique de ce DoMyDesk. Un fichier destiné à une autre instance est refusé.</div>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>
    </section>
  </div>
</div>
<script>
(() => {
  const root = document.getElementById('ticketing-cfg-<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>');
  if (!root) return;
  const refresh = root.querySelector('[data-refresh]');
  if (refresh) refresh.addEventListener('click', () => location.reload());
})();
</script>
