<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('X-Content-Type-Options: nosniff');
error_reporting(0);
$me = dmdtk_user_email();
$role = dmdtk_system_role($me);
if (!$me) { echo "<div class='section dmd-ticketing-cfg'><div class='tk-empty'>⛔ Non connecté.</div></div>"; return; }
$isAdmin = dmdtk_is_admin($me);
if (!$isAdmin || !dmdtk_user_can($me, 'admin.configure')) { echo "<div class='section dmd-ticketing-cfg'><div class='tk-empty'>⛔ Configuration DMD-Ticketing non autorisée.</div></div>"; return; }

function tkcfg_lines($s){ $out=[]; foreach (preg_split('~\R+~', (string)$s) as $v) { $v=trim($v); if ($v!=='' && !in_array($v,$out,true)) $out[]=$v; } return $out; }
$cfg = dmdtk_config();
$cats = $cfg['categories'];
$pri = $cfg['priorities'];
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!dmdtk_csrf_valid(isset($_POST['csrf']) ? (string)$_POST['csrf'] : '')) { http_response_code(403); exit('Formulaire expiré.'); }
  $catsP = tkcfg_lines($_POST['categories'] ?? '');
  $priP = tkcfg_lines($_POST['priorities'] ?? '');
  $saved = dmdtk_save_config($catsP, $priP, $me);
  if ($saved === false) {
    $msg = 'Erreur : impossible d’enregistrer la configuration.';
  } else {
    $cats = $saved['categories'];
    $pri = $saved['priorities'];
    dmdtk_log($me,'configure','config','success',array('categories'=>count($cats),'priorities'=>count($pri)));
    $msg='Configuration enregistrée.';
  }
}
$uid = substr(bin2hex(random_bytes(4)), 0, 8);
$cssVersion = @filemtime(__DIR__.'/dmd-ticketing.css') ?: time();
?>
<link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing.css?v=<?= (int)$cssVersion ?>">
<div id="ticketing-cfg-<?= htmlspecialchars($uid, ENT_QUOTES) ?>" class="section dmd-ticketing-cfg">
  <div class="tk-shell">
    <section class="tk-hero">
      <div class="tk-title">
        <div class="tk-icon">⚙️</div>
        <div>
          <h2>Configuration DMD-Ticketing</h2>
          <p>Catégories, priorités et supervision des tickets du module.</p>
        </div>
      </div>
      <div class="tk-actions">
        <button type="button" class="btn tk-btn" data-refresh>↻ Actualiser</button>
      </div>
    </section>

    <section class="tk-cfg-grid">
      <form method="post" class="tk-panel tk-compose"><input type="hidden" name="csrf" value="<?= htmlspecialchars(dmdtk_csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
        <strong>Paramètres du module</strong>
        <?php if ($msg): ?><div class="tk-msg">✅ <?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <div class="tk-field">
          <label>Catégories — une par ligne</label>
          <textarea name="categories" class="input tk-input" rows="8"><?= htmlspecialchars(implode("\n", $cats)) ?></textarea>
        </div>
        <div class="tk-field">
          <label>Priorités — une par ligne</label>
          <textarea name="priorities" class="input tk-input" rows="6"><?= htmlspecialchars(implode("\n", $pri)) ?></textarea>
        </div>
        <div class="tk-hint">Les tickets cochés “À envoyer à DomyCo” utilisent la configuration centrale de l’installation. Si l’envoi direct n’est pas disponible, ils restent en attente dans <code>/data/modules/dmd-ticketing/outbox.json</code>.</div>
        <div class="tk-actions"><button class="btn tk-btn tk-btn-primary" type="submit">Enregistrer</button></div>
      </form>

      <div class="tk-panel tk-compose">
        <div class="tk-title">
          <div class="tk-icon">📋</div>
          <div>
            <h3>Tous les tickets</h3>
            <p>Vue admin avec modification rapide et suppression.</p>
          </div>
        </div>
        <div class="tk-toolbar">
          <div class="tk-field"><label>Statut</label><select class="input tk-input" data-filter="status"><option value="all">Tous</option><option value="open">Ouverts</option><option value="closed">Fermés</option></select></div>
          <div class="tk-field"><label>Recherche</label><input class="input tk-input" data-filter="q" placeholder="Titre, ID, propriétaire..."></div>
        </div>
        <div class="tk-cfg-list" data-grid></div>
      </div>
    </section>
  </div>

  <div class="tk-modal" data-modal aria-hidden="true">
    <div class="tk-modal-card">
      <div class="tk-modal-head">
        <div><h3 data-title>Ticket</h3><div class="tk-hint" data-sub></div></div>
        <button type="button" class="btn tk-btn" data-close>✕</button>
      </div>
      <div data-body></div>
      <div class="tk-actions">
        <button type="button" class="btn tk-btn tk-btn-primary" data-save>Enregistrer</button>
        <button type="button" class="btn tk-btn tk-btn-danger" data-delete>Supprimer</button>
      </div>
      <div class="tk-msg" data-msg></div>
    </div>
  </div>
</div>
<script>
(() => {
  const uid = <?= json_encode($uid) ?>;
  const root = document.getElementById('ticketing-cfg-' + uid);
  const API = 'modules/dmd-ticketing/dmd-ticketing_api.php';
  const state = { boot:null, items:[], current:null, timer:null };
  const $ = (s,sc=root)=>sc.querySelector(s);
  const $$ = (s,sc=root)=>Array.from(sc.querySelectorAll(s));
  const h = v => String(v ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[ch]));
  const fmt = s => { if(!s) return ''; const d=new Date(s); return isNaN(d)?h(s):d.toLocaleString(); };
  const selectedValues = sel => Array.from(sel?.selectedOptions || []).map(o=>o.value).filter(Boolean);
  async function api(a, body={}, method='POST') {
    body = body || {}; if(method !== 'GET' && state.boot?.csrf && !body.csrf) body.csrf=state.boot.csrf;
    const opt = {method, headers:{'Content-Type':'application/json'}};
    if (method !== 'GET') opt.body = JSON.stringify(body);
    const res = await fetch(API+'?a='+encodeURIComponent(a), opt);
    return await res.json();
  }
  function badge(t){ return `<span class="tk-badge">${h(t)}</span>`; }
  function shareText(s){ s=s||{}; const p=[]; if(s.all)p.push('Tous'); if((s.users||[]).length)p.push((s.users||[]).length+' user(s)'); if((s.roles||[]).length)p.push('Rôle: '+(s.roles||[]).join(', ')); return p.join(' · ') || 'Privé'; }
  async function load(){
    const status = $('[data-filter="status"]').value || 'all';
    const q = ($('[data-filter="q"]').value || '').trim();
    const r = await api('list', {scope:'all', status, q});
    const grid = $('[data-grid]');
    if(!r?.ok){ grid.innerHTML = `<div class="tk-empty">Erreur : ${h(r?.err || 'chargement')}</div>`; return; }
    state.items = r.items || [];
    if(!state.items.length){ grid.innerHTML='<div class="tk-empty">Aucun ticket.</div>'; return; }
    grid.innerHTML = state.items.map(t => `<article class="tk-card">
      <div class="tk-card-title">${h(t.title || '(sans titre)')}</div>
      <div class="tk-card-meta"><span>${h(t.id)}</span><span>${fmt(t.updated_at || t.created_at)}</span></div>
      <div class="tk-badges">${badge(t.status === 'closed' ? 'Fermé' : 'Ouvert')}${badge(t.category || '')}${badge(t.priority || '')}${badge(shareText(t.share))}</div>
      <div class="tk-preview">${h(t.owner || '')}</div>
      <div class="tk-actions"><button type="button" class="btn tk-btn" data-open="${h(t.id)}">Ouvrir</button><button type="button" class="btn tk-btn tk-btn-danger" data-del="${h(t.id)}">Supprimer</button></div>
    </article>`).join('');
    $$('[data-open]',grid).forEach(b=>b.onclick=()=>openTicket(b.dataset.open));
    $$('[data-del]',grid).forEach(b=>b.onclick=()=>deleteTicket(b.dataset.del));
  }
  function optionList(values, selected){ return (values||[]).map(v=>`<option value="${h(v)}" ${String(selected)===String(v)?'selected':''}>${h(v)}</option>`).join(''); }
  function multiUsers(selected){ selected=selected||[]; return (state.boot?.users||[]).map(u=>`<option value="${h(u.email)}" ${selected.includes(u.email)?'selected':''}>${h(u.label || u.email)}${u.role_metier?' ['+h(u.role_metier)+']':''}</option>`).join(''); }
  function multiRoles(selected){ selected=selected||[]; return (state.boot?.roles||[]).map(r=>`<option value="${h(r)}" ${selected.includes(r)?'selected':''}>${h(r)}</option>`).join(''); }
  async function openTicket(id){
    const r = await api('get', {id});
    if(!r?.ok){ alert(r?.err || 'Erreur'); return; }
    const t = r.item; state.current=t;
    $('[data-title]').textContent = (t.title || '(sans titre)') + ' — ' + t.id;
    $('[data-sub]').textContent = 'Créé par ' + (t.owner || '') + ' · ' + fmt(t.created_at);
    const share=t.share||{};
    const messages=(t.messages||[]).map(m=>`<div class="tk-message"><div class="tk-message-head"><strong>${h(m.by||'')}</strong><span>${fmt(m.at)}</span></div><div class="tk-message-text">${h(m.text||'')}</div></div>`).join('');
    $('[data-body]').innerHTML = `<div class="tk-form-grid">
      <div class="tk-field wide"><label>Titre</label><input class="input tk-input" data-edit="title" value="${h(t.title||'')}"></div>
      <div class="tk-field"><label>Statut</label><select class="input tk-input" data-edit="status"><option value="open" ${t.status==='open'?'selected':''}>Ouvert</option><option value="closed" ${t.status==='closed'?'selected':''}>Fermé</option></select></div>
      <div class="tk-field"><label>Catégorie</label><select class="input tk-input" data-edit="category">${optionList(state.boot?.categories||[], t.category)}</select></div>
      <div class="tk-field"><label>Priorité</label><select class="input tk-input" data-edit="priority">${optionList(state.boot?.priorities||[], t.priority)}</select></div>
      <div class="wide tk-share-box"><strong>Partage</strong><label><input type="checkbox" data-edit="share_all" ${share.all?'checked':''}> Partager avec tous</label><div class="tk-share-row"><div class="tk-field"><label>Utilisateurs</label><select class="input tk-input tk-multi" multiple data-edit="share_users">${multiUsers(share.users)}</select></div><div class="tk-field"><label>Rôles métier</label><select class="input tk-input tk-multi" multiple data-edit="share_roles">${multiRoles(share.roles)}</select></div></div></div>
      <div class="wide"><h4>Messages</h4>${messages || '<div class="tk-empty">Aucun message.</div>'}</div>
    </div>`;
    $('[data-modal]').classList.add('is-open');
  }
  async function save(){
    if(!state.current) return;
    const body = {
      id: state.current.id,
      title: $('[data-edit="title"]').value.trim(),
      status: $('[data-edit="status"]').value,
      category: $('[data-edit="category"]').value,
      priority: $('[data-edit="priority"]').value,
      share: { all: $('[data-edit="share_all"]').checked, users:selectedValues($('[data-edit="share_users"]')), roles:selectedValues($('[data-edit="share_roles"]')) }
    };
    $('[data-msg]').textContent='Enregistrement...';
    const r = await api('update', body);
    $('[data-msg]').textContent = r?.ok ? 'Enregistré.' : (r?.err || 'Erreur.');
    if(r?.ok) load();
  }
  async function deleteTicket(id){
    if(!confirm('Supprimer définitivement ce ticket ?')) return;
    const r = await api('delete', {id});
    if(r?.ok){ $('[data-modal]').classList.remove('is-open'); state.current=null; load(); }
    else alert(r?.err || 'Erreur.');
  }
  $('[data-refresh]').onclick=load;
  $('[data-save]').onclick=save;
  $('[data-delete]').onclick=()=>state.current && deleteTicket(state.current.id);
  $('[data-close]').onclick=()=> $('[data-modal]').classList.remove('is-open');
  $('[data-filter="status"]').onchange=load;
  $('[data-filter="q"]').addEventListener('input',()=>{ clearTimeout(state.timer); state.timer=setTimeout(load,300); });
  (async()=>{ const boot=await api('bootstrap'); if(boot?.ok) state.boot=boot; await load(); })();
})();
</script>
