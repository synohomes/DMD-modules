<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('X-Content-Type-Options: nosniff');
error_reporting(0);
$me = dmdtk_user_email();
$role = dmdtk_system_role($me);
if (!$me) { echo "<div class='section dmd-ticketing'><div class='tk-empty'>⛔ Connecte-toi.</div></div>"; return; }
if (!dmdtk_has_module_access($me)) { echo "<div class='section dmd-ticketing'><div class='tk-empty'>⛔ Accès à DMD-Ticketing non autorisé.</div></div>"; return; }
$cfg = dmdtk_config();
$cats = $cfg['categories'];
$pri  = $cfg['priorities'];
$uid = substr(bin2hex(random_bytes(4)), 0, 8);
$cssVersion = @filemtime(__DIR__.'/dmd-ticketing.css') ?: time();
?>
<?php if (!defined('DMD_TICKETING_CSS_LOADED')): ?>
<link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing.css?v=<?= (int)$cssVersion ?>">
<?php endif; ?>
<div id="ticketing-<?= htmlspecialchars($uid, ENT_QUOTES) ?>" class="section dmd-ticketing">
  <div class="tk-shell">
    <section class="tk-hero">
      <div class="tk-title">
        <div class="tk-icon">🎫</div>
        <div>
          <h2>DMD-Ticketing <span class="tk-title-notification is-idle" data-notif-summary title="Aucune nouvelle information"></span></h2>
          <p>Tickets, échanges, pièces jointes et partage par utilisateur ou rôle métier.</p>
        </div>
      </div>
      <div class="tk-actions">
        <button type="button" class="tk-btn tk-btn-primary" data-new>+ Nouveau ticket</button>
        <button type="button" class="tk-btn" data-refresh>↻ Actualiser</button>
      </div>
    </section>

    <section class="tk-stats" data-stats>
      <div class="tk-stat"><b>0</b><span>Ouverts</span></div>
      <div class="tk-stat"><b>0</b><span>Fermés</span></div>
      <div class="tk-stat"><b>0</b><span>Mes tickets</span></div>
      <div class="tk-stat"><b>0</b><span>Partagés avec moi</span></div>
    </section>

    <section class="tk-toolbar">
      <div class="tk-field"><label>Statut</label><select class="tk-input" data-filter="status"><option value="all">Tous</option><option value="open">Ouvert</option><option value="in_progress">En cours</option><option value="waiting">En attente</option><option value="resolved">Résolu</option><option value="closed">Fermé</option></select></div>
      <div class="tk-field"><label>Vue</label><select class="tk-input" data-filter="scope"><option value="visible">Tous visibles</option><option value="mine">Mes tickets</option><?php if (in_array($role, ['admin','superadmin'], true)): ?><option value="all">Tous admin</option><?php endif; ?></select></div>
      <div class="tk-field"><label>Catégorie</label><select class="tk-input" data-filter="category"><option value="">Toutes</option><?php foreach($cats as $c): ?><option value="<?= htmlspecialchars($c, ENT_QUOTES) ?>"><?= htmlspecialchars($c) ?></option><?php endforeach; ?></select></div>
      <div class="tk-field"><label>Priorité</label><select class="tk-input" data-filter="priority"><option value="">Toutes</option><?php foreach($pri as $p): ?><option value="<?= htmlspecialchars($p, ENT_QUOTES) ?>"><?= htmlspecialchars($p) ?></option><?php endforeach; ?></select></div>
      <div class="tk-field"><label>Recherche</label><input class="tk-input" data-filter="q" placeholder="Titre, message, auteur..."></div>
      <button type="button" class="tk-btn" data-clear>Effacer</button>
    </section>

    <section class="tk-list" data-list></section>
  </div>
</div>
<script>
(() => {
  const uid = <?= json_encode($uid) ?>;
  const root = document.getElementById('ticketing-' + uid);
  const API = 'modules/dmd-ticketing/dmd-ticketing_api.php';
  const UPLOAD = 'modules/dmd-ticketing/dmd-ticketing_upload.php';
  const state = { boot:null, items:[], z:100000, offset:0, timer:null, pollTimer:null, polling:false, baseDocW:0, baseDocH:0 };
  const $ = (s, sc=root) => sc.querySelector(s);
  const $$ = (s, sc=root) => Array.from(sc.querySelectorAll(s));
  const h = v => String(v ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[ch]));
  const fmt = s => { if(!s) return ''; const d = new Date(s); return isNaN(d) ? h(s) : d.toLocaleString(); };
  const nl = s => h(s).replace(/\n/g, '<br>');
  const vals = sel => Array.from(sel?.selectedOptions || []).map(o=>o.value).filter(Boolean);
  const statusLabels = () => state.boot?.statuses || {open:'Ouvert', in_progress:'En cours', waiting:'En attente', resolved:'Résolu', closed:'Fermé'};
  const statusLabel = st => statusLabels()[st || 'open'] || 'Ouvert';
  const statusClass = st => ({open:'tk-badge-open', in_progress:'tk-badge-progress', waiting:'tk-badge-waiting', resolved:'tk-badge-resolved', closed:'tk-badge-closed'}[st || 'open'] || 'tk-badge-open');

  function copyThemeVars(win){
    const cs = getComputedStyle(root);
    ['--tk-bg','--tk-bg-soft','--tk-bg-strong','--tk-border','--tk-text','--tk-muted','--tk-accent','--tk-danger','--tk-ok','--tk-radius','--card-bg','--section-bg','--input-bg','--popup-bg','--border-color','--text-color','--muted-color','--accent-color','--primary-color'].forEach(v => {
      const val = cs.getPropertyValue(v);
      if (val) win.style.setProperty(v, val);
    });
  }
  async function api(a, body={}, method='POST'){
    body = body || {};
    if(method !== 'GET' && state.boot?.csrf && !body.csrf) body.csrf = state.boot.csrf;
    const opt = {method, headers:{'Content-Type':'application/json'}};
    if(method !== 'GET') opt.body = JSON.stringify(body);
    const res = await fetch(API + '?a=' + encodeURIComponent(a), opt);
    return await res.json();
  }
  async function refreshBootstrap(){
    const b = await api('bootstrap');
    if(!b?.ok) return null;
    state.boot = b;

    const categoryFilter = $('[data-filter="category"]');
    if(categoryFilter){
      const previous = categoryFilter.value;
      categoryFilter.innerHTML = '<option value="">Toutes</option>' + options(b.categories || [], previous);
      if(previous && !(b.categories || []).includes(previous)) categoryFilter.value = '';
    }

    const priorityFilter = $('[data-filter="priority"]');
    if(priorityFilter){
      const previous = priorityFilter.value;
      priorityFilter.innerHTML = '<option value="">Toutes</option>' + options(b.priorities || [], previous);
      if(previous && !(b.priorities || []).includes(previous)) priorityFilter.value = '';
    }
    return b;
  }
  async function uploadFiles(id, input){
    if(!input || !input.files || !input.files.length) return {ok:true};
    const fd = new FormData(); fd.append('ticket_id', id); if(state.boot?.csrf) fd.append('csrf', state.boot.csrf);
    Array.from(input.files).forEach(f => fd.append('files[]', f));
    const res = await fetch(UPLOAD, {method:'POST', body:fd});
    return await res.json();
  }
  function setDroppedFiles(input, files){
    if(!input || !files || !files.length) return false;
    try {
      const dt = new DataTransfer();
      Array.from(input.files || []).forEach(file => dt.items.add(file));
      Array.from(files).forEach(file => dt.items.add(file));
      input.files = dt.files;
      input.dispatchEvent(new Event('change', {bubbles:true}));
      return true;
    } catch(e) { return false; }
  }
  function myDeskDropInput(){
    const windows = $$('.tk-window, .tk-create-window, .tk-ticket-window', document)
      .filter(w => w && w.offsetParent !== null)
      .sort((a,b) => (parseInt(getComputedStyle(a).zIndex || '0',10)||0) - (parseInt(getComputedStyle(b).zIndex || '0',10)||0));
    const top = windows.length ? windows[windows.length-1] : root;
    return top ? top.querySelector('input[type="file"]:not(:disabled)') : null;
  }
  if(window.DMDMyDesk){
    window.addEventListener('dmd:mydesk-files', ev => {
      const files = Array.from(ev.detail?.files || ev.detail?.fileList || []);
      if(!files.length) return;
      const input = myDeskDropInput();
      if(!input){
        window.DMDMyDesk.notify('DMD-Ticketing', 'Ouvrez un nouveau ticket ou une réponse avant de déposer des fichiers.', 'dmd-ticketing');
        return;
      }
      if(setDroppedFiles(input, files)){
        const drop = input.closest('.tk-new-ticket-upload') || input.parentElement;
        if(drop){ drop.classList.add('is-mydesk-drop'); setTimeout(()=>drop.classList.remove('is-mydesk-drop'),900); }
        window.DMDMyDesk.notify('DMD-Ticketing', files.length + ' fichier(s) ajouté(s) aux pièces jointes.', 'dmd-ticketing');
      }
    });
  }
  function badge(text, cls=''){
    if(!text) return '';
    return `<span class="tk-badge ${cls}">${h(text)}</span>`;
  }
  function domydeskBadge(t){
    const dm = t?.meta?.domydesk;
    if(!dm?.requested && !t?.send_to_domydesk) return '';
    if(dm?.status === 'sent') return badge('DomyCo synchronisé', 'tk-badge-domydesk');
    return badge('DomyCo en attente', 'tk-badge-waiting');
  }
  function notificationInfo(t){
    const dm = t?.meta?.domydesk;
    if(!dm?.requested && !t?.send_to_domydesk) return {linked:false, unread:false, count:0, label:''};
    const n = (dm?.notification && typeof dm.notification === 'object') ? dm.notification : {};
    return {
      linked:true,
      unread:!!n.unread,
      count:Number(n.count || 0),
      label:String(n.label || (n.unread ? 'Nouvelle information de DomyCo' : 'Aucune nouvelle information'))
    };
  }
  function notificationDot(t){
    const n = notificationInfo(t);
    if(!n.linked) return '';
    const cls = n.unread ? 'is-new' : 'is-idle';
    const text = n.unread && n.count > 1 ? String(n.count) : '';
    return `<span class="tk-notification-dot ${cls}" title="${h(n.label)}">${h(text)}</span>`;
  }
  function updateNotificationSummary(items){
    const target = $('[data-notif-summary]');
    if(!target) return;
    const unread = (items || []).filter(t => notificationInfo(t).unread).length;
    target.classList.toggle('is-new', unread > 0);
    target.classList.toggle('is-idle', unread === 0);
    target.textContent = unread > 0 ? String(unread) : '';
    target.title = unread > 0 ? unread + ' ticket(s) avec une nouvelle information' : 'Aucune nouvelle information';
  }
  function shareText(t){
    const s = t.share || {};
    if (t.owner !== state.boot?.me && t.owner) return 'Partagé';
    if (s.all) return 'Tous';
    const nU = (s.users || []).length;
    const nR = (s.roles || []).length;
    if(nU || nR) return [nU ? nU + ' utilisateur(s)' : '', nR ? nR + ' rôle(s)' : ''].filter(Boolean).join(' · ');
    return 'Privé';
  }
  function renderStats(items){
    const active = items.filter(t=>!['resolved','closed'].includes(t.status || 'open')).length;
    const progress = items.filter(t=>(t.status || 'open')==='in_progress').length;
    const waiting = items.filter(t=>(t.status || 'open')==='waiting').length;
    const done = items.filter(t=>['resolved','closed'].includes(t.status || 'open')).length;
    $('[data-stats]').innerHTML = `
      <div class="tk-stat"><b>${active}</b><span>Actifs</span></div>
      <div class="tk-stat"><b>${progress}</b><span>En cours</span></div>
      <div class="tk-stat"><b>${waiting}</b><span>En attente</span></div>
      <div class="tk-stat"><b>${done}</b><span>Résolus/Fermés</span></div>`;
  }
  function renderList(items){
    const list = $('[data-list]');
    renderStats(items);
    updateNotificationSummary(items);
    if(!items.length){ list.innerHTML = '<div class="tk-empty">Aucun ticket.</div>'; return; }
    list.innerHTML = items.map(t => `
      <article class="tk-card" data-open="${h(t.id)}" data-dmd-context-type="ticket" data-dmd-context-id="${h(t.id)}">
        <div class="tk-card-top">
          <div class="tk-card-title">${h(t.title || '(sans titre)')}</div>
          <div class="tk-card-flags">${notificationDot(t)}${badge(statusLabel(t.status), statusClass(t.status))}</div>
        </div>
        <div class="tk-card-meta"><span>${h(t.owner || '')}</span><span>${fmt(t.updated_at || t.created_at)}</span></div>
        <div class="tk-preview">${h(t.last_message || '')}</div>
        <div class="tk-badges">${badge(t.category)}${badge(t.priority)}${badge(shareText(t),'tk-badge-shared')}${domydeskBadge(t)}</div>
      </article>`).join('');
    $$('[data-open]', list).forEach(card => card.onclick = () => openTicket(card.dataset.open));
    if(window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') window.DMDActionHub.decorate(list);
  }
  async function load(){
    const payload = {
      status: $('[data-filter="status"]').value,
      scope: $('[data-filter="scope"]').value,
      category: $('[data-filter="category"]').value,
      priority: $('[data-filter="priority"]').value,
      q: $('[data-filter="q"]').value.trim()
    };
    const r = await api('list', payload);
    if(!r?.ok){ $('[data-list]').innerHTML = '<div class="tk-empty">Erreur de chargement.</div>'; return; }
    state.items = r.items || [];
    renderList(state.items);
  }
  async function refreshAll(){
    const btn = $('[data-refresh]');
    const previous = btn.textContent;
    btn.disabled = true;
    btn.textContent = '↻ Synchronisation...';
    try {
      await refreshBootstrap();
      const r = await api('sync_all', {force:true});
      if(!r?.ok) alert(r?.err || 'Erreur de synchronisation.');
      await load();
    } finally {
      btn.disabled = false;
      btn.textContent = previous;
    }
  }
  async function silentSync(){
    if(state.polling || document.hidden) return;
    state.polling = true;
    try {
      const r = await api('sync_all');
      if(r?.ok) await load();
    } catch (_) {
    } finally {
      state.polling = false;
    }
  }
  function startAutomaticSync(){
    if(state.pollTimer) clearInterval(state.pollTimer);
    state.pollTimer = setInterval(silentSync, 120000);
    document.addEventListener('visibilitychange', () => { if(!document.hidden) silentSync(); });
    window.addEventListener('focus', silentSync);
  }
  function initWorkspaceBase(){
    const doc = document.documentElement;
    const body = document.body;
    if(!state.baseDocW) state.baseDocW = Math.max(window.innerWidth, doc.clientWidth || 0, body.clientWidth || 0, doc.scrollWidth || 0, body.scrollWidth || 0);
    if(!state.baseDocH) state.baseDocH = Math.max(window.innerHeight, doc.clientHeight || 0, body.clientHeight || 0, doc.scrollHeight || 0, body.scrollHeight || 0);
  }
  function recalcWorkspace(){
    initWorkspaceBase();
    const doc = document.documentElement;
    const body = document.body;
    let needW = state.baseDocW;
    let needH = state.baseDocH;
    document.querySelectorAll('.tk-window').forEach(w => {
      if(!w.isConnected) return;
      const left = parseFloat(w.style.left) || w.offsetLeft || 0;
      const top  = parseFloat(w.style.top) || w.offsetTop || 0;
      needW = Math.max(needW, Math.ceil(left + w.offsetWidth + 80));
      needH = Math.max(needH, Math.ceil(top + w.offsetHeight + 80));
    });
    doc.style.minWidth = needW + 'px';
    body.style.minWidth = needW + 'px';
    doc.style.minHeight = needH + 'px';
    body.style.minHeight = needH + 'px';
    const maxX = Math.max(0, needW - window.innerWidth);
    const maxY = Math.max(0, needH - window.innerHeight);
    if(window.scrollX > maxX || window.scrollY > maxY) window.scrollTo(Math.min(window.scrollX, maxX), Math.min(window.scrollY, maxY));
  }
  function removeWindow(win){
    if(win && win.parentNode) win.remove();
    requestAnimationFrame(recalcWorkspace);
  }
  function windowShell(title, id, bodyHtml, width=760, height=620){
    state.offset = (state.offset + 18) % 120;
    const win = document.createElement('div');
    win.className = 'tk-window';
    win.style.left = (24 + state.offset) + 'px';
    win.style.top = (24 + state.offset) + 'px';
    win.style.width = `min(${width}px, calc(100vw - 18px))`;
    win.style.height = `min(${height}px, calc(100vh - 18px))`;
    copyThemeVars(win);
    win.innerHTML = `
      <div class="tk-window-head" data-drag>
        <strong>${h(title)}</strong>${id ? `<span class="tk-window-id">${h(id)}</span>` : ''}
        <div class="tk-window-actions"><button type="button" class="tk-btn" data-reload title="Actualiser">↻</button><button type="button" class="tk-btn" data-x title="Fermer">×</button></div>
      </div>
      <div class="tk-window-body">${bodyHtml}</div>`;
    document.body.appendChild(win);
    win.style.zIndex = ++state.z;
    win.addEventListener('pointerdown', () => win.style.zIndex = ++state.z);
    $('[data-x]', win).onclick = () => removeWindow(win);
    makeDraggable(win, $('[data-drag]', win));
    requestAnimationFrame(recalcWorkspace);
    return win;
  }
  function makeDraggable(win, handle){
    let sx=0, sy=0, sl=0, st=0, dragging=false;
    const autoScroll = (e) => {
      const edge = 34;
      const step = 32;
      if(e.clientX > window.innerWidth - edge) window.scrollBy(step, 0);
      if(e.clientY > window.innerHeight - edge) window.scrollBy(0, step);
      if(e.clientX < edge) window.scrollBy(-step, 0);
      if(e.clientY < edge) window.scrollBy(0, -step);
    };
    handle.addEventListener('pointerdown', e => {
      if(e.target.closest('button')) return;
      dragging=true;
      sx=e.pageX; sy=e.pageY;
      sl=parseFloat(win.style.left) || win.offsetLeft;
      st=parseFloat(win.style.top) || win.offsetTop;
      win.style.zIndex = ++state.z;
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener('pointermove', e => {
      if(!dragging) return;
      autoScroll(e);
      const nextL = Math.max(6, sl + e.pageX - sx);
      const nextT = Math.max(6, st + e.pageY - sy);
      win.style.left = nextL + 'px';
      win.style.top = nextT + 'px';
      recalcWorkspace();
    });
    const stop = e => { dragging=false; try{handle.releasePointerCapture(e.pointerId);}catch(_){} requestAnimationFrame(recalcWorkspace); };
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
  }
  function options(arr, selected=''){ return (arr || []).map(v => `<option value="${h(v)}" ${String(v)===String(selected)?'selected':''}>${h(v)}</option>`).join(''); }
  function statusOptions(selected='open'){ return Object.entries(statusLabels()).map(([k,v]) => `<option value="${h(k)}" ${String(k)===String(selected || 'open')?'selected':''}>${h(v)}</option>`).join(''); }
  function multiUsers(selected=[]){ return (state.boot?.users || []).map(u => `<option value="${h(u.email)}" ${selected.includes(u.email)?'selected':''}>${h(u.label || u.email)}${u.role_metier ? ' [' + h(u.role_metier) + ']' : ''}</option>`).join(''); }
  function multiRoles(selected=[]){ return (state.boot?.roles || []).map(r => `<option value="${h(r)}" ${selected.includes(r)?'selected':''}>${h(r)}</option>`).join(''); }
  function shareForm(share={}){
    return `<div class="tk-share-box tk-wide">
      <strong>Partage du ticket</strong>
      <label class="tk-checkline"><input type="checkbox" data-share-all ${share.all?'checked':''}> Partager avec tous les utilisateurs</label>
      <div class="tk-share-row">
        <div class="tk-field"><label>Utilisateurs</label><select class="tk-input tk-multi" multiple data-share-users>${multiUsers(share.users || [])}</select></div>
        <div class="tk-field"><label>Rôles métier</label><select class="tk-input tk-multi" multiple data-share-roles>${multiRoles(share.roles || [])}</select></div>
      </div>
    </div>`;
  }
  function collectShare(win){
    return {all: !!$('[data-share-all]', win)?.checked, users: vals($('[data-share-users]', win)), roles: vals($('[data-share-roles]', win))};
  }
  async function openNew(){
    const fresh = await refreshBootstrap();
    if(!fresh){ alert('Impossible de charger la configuration DMD-Ticketing.'); return; }
    const html = `<form class="tk-new-ticket-form" data-new-form>
      <div class="tk-new-ticket-intro">
        <div>
          <span class="tk-new-ticket-kicker">NOUVELLE DEMANDE</span>
          <h3>Créer un ticket</h3>
          <p>Renseignez la demande, choisissez son niveau de priorité puis définissez qui peut la consulter.</p>
        </div>
        <span class="tk-new-ticket-state">Brouillon local</span>
      </div>

      <div class="tk-new-ticket-grid">
        ${state.boot?.mydesk_context ? `<section class="tk-new-ticket-card tk-wide tk-mydesk-context"><div class="tk-new-ticket-card-head"><span class="tk-new-ticket-step">PC</span><div><strong>Poste lié automatiquement</strong><small>${h(state.boot.mydesk_context.hostname || 'Poste DMD-Agent')} · ${h(state.boot.mydesk_context.agent_id || 'Agent inconnu')}</small></div></div></section>` : ''}
        <section class="tk-new-ticket-card tk-new-ticket-request">
          <div class="tk-new-ticket-card-head">
            <span class="tk-new-ticket-step">1</span>
            <div>
              <strong>La demande</strong>
              <small>Donnez un titre clair et décrivez précisément le besoin.</small>
            </div>
          </div>

          <div class="tk-field">
            <label>Titre du ticket</label>
            <input class="tk-input tk-new-ticket-title" name="title" required
                   placeholder="Ex. : L’imprimante ne répond plus">
          </div>

          <div class="tk-field tk-new-ticket-description-field">
            <label>Description détaillée</label>
            <textarea class="tk-input tk-new-ticket-description" name="message" required
                      placeholder="Décrivez le problème, les essais déjà réalisés et le résultat attendu."></textarea>
          </div>
        </section>

        <aside class="tk-new-ticket-side">
          <section class="tk-new-ticket-card">
            <div class="tk-new-ticket-card-head">
              <span class="tk-new-ticket-step">2</span>
              <div>
                <strong>Classement</strong>
                <small>Ces informations facilitent le traitement du ticket.</small>
              </div>
            </div>

            <div class="tk-new-ticket-two-fields">
              <div class="tk-field">
                <label>Catégorie</label>
                <select class="tk-input" name="category">${options(state.boot?.categories || [])}</select>
              </div>
              <div class="tk-field">
                <label>Priorité</label>
                <select class="tk-input" name="priority">${options(state.boot?.priorities || [])}</select>
              </div>
            </div>
          </section>

          <section class="tk-new-ticket-card">
            <div class="tk-new-ticket-card-head">
              <span class="tk-new-ticket-step">3</span>
              <div>
                <strong>Transmission</strong>
                <small>Envoyez le ticket à DomyCo et joignez les fichiers utiles.</small>
              </div>
            </div>

            <label class="tk-new-ticket-sync">
              <input type="checkbox" name="send_to_domydesk">
              <span class="tk-new-ticket-switch" aria-hidden="true"></span>
              <span>
                <strong>Envoyer à DomyCo</strong>
                <small>Les réponses et statuts seront ensuite synchronisés automatiquement.</small>
              </span>
            </label>

            <label class="tk-new-ticket-upload">
              <span class="tk-new-ticket-upload-icon">📎</span>
              <span class="tk-new-ticket-upload-content">
                <strong>Ajouter des pièces jointes</strong>
                <small>Images, PDF, documents ou fichiers de diagnostic.</small>
                <input type="file" class="tk-input" name="files" multiple>
              </span>
            </label>
          </section>
        </aside>

        <section class="tk-new-ticket-card tk-new-ticket-sharing">
          <div class="tk-new-ticket-card-head">
            <span class="tk-new-ticket-step">4</span>
            <div>
              <strong>Partage du ticket</strong>
              <small>Le propriétaire et les administrateurs conservent toujours l’accès.</small>
            </div>
            <label class="tk-new-ticket-share-all">
              <input type="checkbox" data-share-all>
              <span>Partager avec tous</span>
            </label>
          </div>

          <div class="tk-new-ticket-share-grid">
            <div class="tk-field">
              <label>Utilisateurs autorisés</label>
              <select class="tk-input tk-multi" multiple data-share-users>${multiUsers([])}</select>
            </div>
            <div class="tk-field">
              <label>Rôles métier autorisés</label>
              <select class="tk-input tk-multi" multiple data-share-roles>${multiRoles([])}</select>
            </div>
          </div>
        </section>
      </div>

      <div class="tk-new-ticket-footer">
        <div class="tk-msg" data-msg></div>
        <div class="tk-new-ticket-actions">
          <button type="button" class="tk-btn" data-cancel>Annuler</button>
          <button type="submit" class="tk-btn tk-btn-primary">Créer le ticket</button>
        </div>
      </div>
    </form>`;

    const win = windowShell('Nouveau ticket', '', html, 920, 680);
    win.classList.add('tk-create-window', 'tk-new-ticket-window');
    $('[data-reload]', win).style.display = 'none';
    $('[data-cancel]', win).onclick = () => removeWindow(win);

    $('[data-new-form]', win).onsubmit = async e => {
      e.preventDefault();
      const f = e.currentTarget;
      const msg = $('[data-msg]', win);
      const submit = f.querySelector('button[type="submit"]');
      msg.textContent = 'Création du ticket...';
      if(submit) submit.disabled = true;

      try {
        const r = await api('create', {
          title: f.title.value,
          category: f.category.value,
          priority: f.priority.value,
          message: f.message.value,
          send_to_domydesk: f.send_to_domydesk.checked,
          share: collectShare(win)
        });

        if(!r?.ok){
          msg.textContent = r?.err || 'Erreur lors de la création.';
          return;
        }

        const upload = await uploadFiles(r.id, f.files);
        if(!upload?.ok){
          msg.textContent = upload?.err || 'Le ticket est créé, mais les pièces jointes n’ont pas été enregistrées.';
          return;
        }

        if(f.files.files.length){
          const syncResult = await api('sync', {id:r.id});
          if(!syncResult?.ok){
            msg.textContent = syncResult?.err || 'Le ticket est créé localement, mais la synchronisation a échoué.';
          }
        }

        msg.textContent = 'Ticket créé.';
        if(window.DMDMyDesk?.notify){
          window.DMDMyDesk.notify('DMD-Ticketing', 'Ticket créé : ' + (f.title.value || r.id), 'dmd-ticketing');
        }
        await load();
        removeWindow(win);
        openTicket(r.id);
      } finally {
        if(submit) submit.disabled = false;
      }
    };
  }
  function attachmentUrl(a){
    const local = String(a?.local_url || '').trim();
    const central = String(a?.central_url || '').trim();
    const raw = local || String(a?.url || '').trim() || central;

    if(!raw) return '#';
    if(/^https?:\/\//i.test(raw)) return raw;

    /*
     * Les fichiers centralisés sont renvoyés sous la forme /ticket_files/...
     * Sans domaine, le navigateur les cherchait sur le DoMyDesk courant.
     */
    if(raw.startsWith('/ticket_files/')){
      return 'https://register.synohomes.com' + raw;
    }
    if(raw.startsWith('ticket_files/')){
      return 'https://register.synohomes.com/' + raw;
    }

    return raw;
  }
  function isImageAttachment(a){
    const name = String(a?.name || '').trim();
    const raw = String(a?.local_url || a?.url || a?.central_url || '').trim();
    const candidate = name || raw.split('?')[0];
    return /\.(?:jpe?g|png|gif|webp)$/i.test(candidate);
  }
  function openImagePreview(name, url){
    const safeName = String(name || 'Image');
    const safeUrl = String(url || '').trim();
    if(!safeUrl) return;

    const html = `<div class="tk-image-preview">
      <div class="tk-image-preview-stage">
        <img src="${h(safeUrl)}" alt="${h(safeName)}" data-image-preview>
        <div class="tk-image-preview-error" data-image-error hidden>Impossible d’afficher cette image.</div>
      </div>
      <div class="tk-image-preview-caption">${h(safeName)}</div>
    </div>`;

    const win = windowShell('Aperçu image', safeName, html, 1040, 780);
    win.classList.add('tk-image-window');
    const reload = $('[data-reload]', win);
    if(reload) reload.remove();
    const img = $('[data-image-preview]', win);
    const err = $('[data-image-error]', win);
    if(img){
      img.addEventListener('error', () => {
        img.hidden = true;
        if(err) err.hidden = false;
      });
    }
  }
  function bindAttachmentPreviews(scope){
    $$('[data-attachment-image]', scope).forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        openImagePreview(link.dataset.attachmentName || 'Image', link.dataset.attachmentUrl || link.href);
      });
    });
  }
  function attachments(list){
    if(!Array.isArray(list) || !list.length) return '';
    return `<ul class="tk-attachments">${list.map(a=>{
      const url = attachmentUrl(a);
      const name = a?.name || 'fichier';
      if(isImageAttachment(a)){
        return `<li><a href="${h(url)}" class="tk-attachment-image" data-attachment-image data-attachment-name="${h(name)}" data-attachment-url="${h(url)}">🖼️ ${h(name)}</a></li>`;
      }
      return `<li><a href="${h(url)}" target="_blank" rel="noopener">📎 ${h(name)}</a></li>`;
    }).join('')}</ul>`;
  }
  async function openTicket(id){
    const r = await api('get', {id});
    if(!r?.ok){ alert(r?.err || 'Ticket introuvable'); return; }
    const t = r.item;

    const messages = (t.messages || []).map(m => {
      const fromDomyCo = m.role === 'domydesk';
      return `<article class="tk-view-message ${fromDomyCo ? 'is-domyco' : 'is-local'}">
        <div class="tk-view-message-icon" aria-hidden="true">${fromDomyCo ? '🛠️' : '👤'}</div>
        <div class="tk-view-message-content">
          <div class="tk-view-message-head">
            <div>
              <strong>${h(m.by || (fromDomyCo ? 'Support DomyCo' : 'Utilisateur'))}</strong>
              ${fromDomyCo ? '<span class="tk-view-origin">Support DomyCo</span>' : '<span class="tk-view-origin">Message local</span>'}
            </div>
            <time>${fmt(m.at)}</time>
          </div>
          <div class="tk-view-message-text">${nl(m.text || '')}</div>
          ${attachments(m.attachments)}
        </div>
      </article>`;
    }).join('') || '<div class="tk-empty">Aucun message.</div>';

    const html = `<div class="tk-view-page">
      <section class="tk-view-overview">
        <div class="tk-view-summary">
          <span class="tk-view-kicker">TICKET ${h(t.id)}</span>
          <h3>${h(t.title || '(sans titre)')}</h3>
          <div class="tk-view-meta">
            <span><b>Créé par</b>${h(t.owner || '')}</span>
            <span><b>Créé le</b>${fmt(t.created_at)}</span>
            <span><b>Mis à jour</b>${fmt(t.updated_at || t.created_at)}</span>
          </div>
          <div class="tk-view-badges">
            ${badge(statusLabel(t.status), statusClass(t.status))}
            ${badge(t.category)}
            ${badge(t.priority)}
            ${badge(shareText(t),'tk-badge-shared')}
            ${domydeskBadge(t)}
            ${notificationInfo(t).unread ? badge(notificationInfo(t).label, 'tk-badge-notification') : ''}
          </div>
        </div>

        <aside class="tk-view-control-panel">
          ${t.can_manage ? `<div class="tk-field tk-view-status-field">
            <label>Statut du ticket</label>
            <select class="tk-input" data-ticket-status>${statusOptions(t.status)}</select>
          </div>` : `<div class="tk-view-status-readonly"><span>Statut actuel</span><strong>${h(statusLabel(t.status))}</strong></div>`}

          <div class="tk-view-actions">
            ${t.can_manage ? '<button type="button" class="tk-btn tk-btn-primary" data-status-save>Enregistrer le statut</button><button type="button" class="tk-btn" data-share-open>Partager</button><button type="button" class="tk-btn" data-toggle>' + (t.status === 'closed' ? 'Rouvrir' : 'Fermer') + '</button>' : ''}
            ${t?.meta?.domydesk?.requested || t.send_to_domydesk ? '<button type="button" class="tk-btn" data-sync>Synchroniser DomyCo</button>' : ''}
            ${t.can_delete ? '<button type="button" class="tk-btn tk-btn-danger" data-delete>Supprimer</button>' : ''}
          </div>
        </aside>
      </section>

      <section class="tk-view-conversation">
        <div class="tk-view-section-head">
          <div>
            <span class="tk-view-section-kicker">ÉCHANGES</span>
            <h4>Conversation</h4>
          </div>
          <span class="tk-view-count">${(t.messages || []).length} message(s)</span>
        </div>
        <div class="tk-view-thread">${messages}</div>
      </section>

      <form class="tk-view-reply" data-reply-form>
        <div class="tk-view-section-head">
          <div>
            <span class="tk-view-section-kicker">RÉPONDRE</span>
            <h4>Ajouter un message</h4>
          </div>
        </div>

        <div class="tk-view-reply-grid">
          <div class="tk-field tk-view-reply-message">
            <label>Votre réponse</label>
            <textarea class="tk-input" name="message" ${t.status === 'closed' ? 'disabled' : ''} placeholder="${t.status === 'closed' ? 'Ticket fermé : rouvre-le pour répondre.' : 'Écrivez votre réponse ici…'}"></textarea>
          </div>
          <div class="tk-field tk-view-reply-files">
            <label>Pièces jointes</label>
            <div class="tk-view-file-box">
              <span class="tk-view-file-icon" aria-hidden="true">📎</span>
              <div>
                <strong>Ajouter des fichiers</strong>
                <small>Images, PDF, documents ou diagnostics.</small>
              </div>
              <input type="file" class="tk-input" name="files" multiple ${t.status === 'closed' ? 'disabled' : ''}>
            </div>
          </div>
        </div>

        <div class="tk-view-reply-footer">
          <div class="tk-msg" data-msg></div>
          <button type="submit" class="tk-btn tk-btn-primary" ${t.status === 'closed' ? 'disabled' : ''}>Envoyer la réponse</button>
        </div>
      </form>

      ${t.can_manage ? `<form class="tk-view-share-panel" data-share-panel style="display:none">
        <div class="tk-view-section-head">
          <div>
            <span class="tk-view-section-kicker">ACCÈS</span>
            <h4>Partage du ticket</h4>
          </div>
        </div>
        <div class="tk-form-grid">${shareForm(t.share || {})}</div>
        <div class="tk-view-reply-footer">
          <div class="tk-msg" data-share-msg></div>
          <button type="submit" class="tk-btn tk-btn-primary">Enregistrer le partage</button>
        </div>
      </form>` : ''}
    </div>`;

    const win = windowShell(t.title || 'Ticket', t.id, html, 920, 700);
    win.classList.add('tk-ticket-window');
    win.setAttribute('data-dmd-context-type', 'ticket');
    win.setAttribute('data-dmd-context-id', String(t.id || ''));
    bindAttachmentPreviews(win);
    if(window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') window.DMDActionHub.decorate(win);
    if(notificationInfo(t).unread){
      setTimeout(async () => {
        try { await api('mark_read', {id:t.id}); await load(); } catch (_) {}
      }, 500);
    }
    $('[data-reload]', win).onclick = () => { removeWindow(win); openTicket(id); };
    const shareOpen = $('[data-share-open]', win); if(shareOpen) shareOpen.onclick = () => { const p = $('[data-share-panel]', win); p.style.display = p.style.display === 'none' ? '' : 'none'; p.scrollIntoView({behavior:'smooth', block:'nearest'}); };
    const statusSave = $('[data-status-save]', win); if(statusSave) statusSave.onclick = async () => { const rr=await api('update', {id:t.id, status:$('[data-ticket-status]', win).value}); if(!rr?.ok){ alert(rr?.err || 'Erreur.'); return; } await load(); removeWindow(win); openTicket(id); };
    const toggle = $('[data-toggle]', win); if(toggle) toggle.onclick = async () => { const rr=await api(t.status === 'closed' ? 'reopen' : 'close', {id:t.id}); if(!rr?.ok){ alert(rr?.err || 'Erreur.'); return; } await load(); removeWindow(win); openTicket(id); };
    const sync = $('[data-sync]', win); if(sync) sync.onclick = async () => { sync.disabled=true; sync.textContent='Synchronisation...'; const rr=await api('sync',{id:t.id}); if(!rr?.ok){ alert(rr?.err || 'Erreur de synchronisation.'); } await load(); removeWindow(win); openTicket(id); };
    const del = $('[data-delete]', win); if(del) del.onclick = async () => { if(!confirm('Supprimer définitivement ce ticket ?')) return; const rr=await api('delete', {id:t.id}); if(!rr?.ok){ alert(rr?.err || 'Erreur.'); return; } await load(); removeWindow(win); };
    $('[data-reply-form]', win).onsubmit = async e => {
      e.preventDefault(); const f=e.currentTarget; const msg=$('[data-msg]', win); msg.textContent='Envoi...';
      let replyResult = null;
      if(f.message.value.trim()){
        replyResult=await api('reply', {id:t.id, message:f.message.value});
        if(!replyResult?.ok){ msg.textContent=replyResult?.err||'Erreur.'; return; }
      }
      let syncResult = replyResult?.domydesk || null;
      if(f.files.files.length){
        const ur=await uploadFiles(t.id, f.files);
        if(!ur?.ok){ msg.textContent=ur?.err||'Erreur upload.'; return; }
        const sr=await api('sync', {id:t.id});
        if(!sr?.ok){ msg.textContent=sr?.err||'Erreur de synchronisation.'; return; }
        syncResult=sr?.result || sr?.domydesk || syncResult;
      }
      if((t?.meta?.domydesk?.requested || t.send_to_domydesk) && syncResult?.status === 'pending'){
        alert('La réponse est enregistrée localement. DomyCo est momentanément indisponible : l’envoi sera retenté automatiquement.');
      }
      await load(); removeWindow(win); openTicket(id);
    };
    const sharePanel = $('[data-share-panel]', win); if(sharePanel) sharePanel.onsubmit = async e => {
      e.preventDefault(); const sm=$('[data-share-msg]', win); sm.textContent='Enregistrement...';
      const rr=await api('update', {id:t.id, share:collectShare(win)}); sm.textContent = rr?.ok ? 'Partage enregistré.' : (rr?.err || 'Erreur.'); if(rr?.ok) await load();
    };
  }

  $('[data-new]').onclick = openNew;
  $('[data-refresh]').onclick = refreshAll;
  $('[data-clear]').onclick = () => { $$('[data-filter]').forEach(el => { if(el.tagName === 'INPUT') el.value=''; else if(el.dataset.filter==='status') el.value='all'; else if(el.dataset.filter==='scope') el.value='visible'; else el.value=''; }); load(); };
  $$('[data-filter]').forEach(el => el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', () => { clearTimeout(state.timer); state.timer=setTimeout(load, el.tagName === 'INPUT' ? 250 : 0); }));
  window.addEventListener('resize', () => requestAnimationFrame(recalcWorkspace));
  initWorkspaceBase();
  (async()=>{
    const b = await refreshBootstrap();
    if(!b?.ok){ $('[data-list]').innerHTML='<div class="tk-empty">Erreur initialisation.</div>'; return; }
    const newBtn=$('[data-new]');
    if(newBtn && b.permissions && !b.permissions.create){ newBtn.disabled=true; newBtn.title='Création de ticket non autorisée'; }
    await load();
    startAutomaticSync();
    setTimeout(silentSync, 1500);
  })();
})();
</script>
