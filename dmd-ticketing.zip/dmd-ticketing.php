<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('X-Content-Type-Options: nosniff');
error_reporting(0);
$me = dmdtk_user_email();
$role = dmdtk_system_role($me);
if (!$me) { echo "<div class='section dmd-ticketing'><div class='tk-empty'>⛔ Connecte-toi.</div></div>"; return; }
if (!dmdtk_has_module_access($me)) { echo "<div class='section dmd-ticketing'><div class='tk-empty'>⛔ Accès à DMD-Ticketing non autorisé.</div></div>"; return; }
$cfg = dmdtk_config();
$cats = $cfg['categories'];
$pri  = $cfg['priorities'];
$uid = substr(bin2hex(random_bytes(4)), 0, 8);
$cssVersion = @filemtime(__DIR__.'/dmd-ticketing.css') ?: time();
?>
<?php if (!defined('DMD_TICKETING_CSS_LOADED')): ?>
<link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing.css?v=<?= (int)$cssVersion ?>">
<?php endif; ?>
<div id="ticketing-<?= htmlspecialchars($uid, ENT_QUOTES) ?>" class="section dmd-ticketing">
  <div class="tk-shell">
    <section class="tk-hero">
      <div class="tk-title">
        <div class="tk-icon">🎫</div>
        <div>
          <h2>DMD-Ticketing <span class="tk-title-notification is-idle" data-notif-summary title="Aucune nouvelle information"></span></h2>
          <p>Tickets, échanges, pièces jointes et partage par utilisateur ou rôle métier.</p>
        </div>
      </div>
      <div class="tk-actions">
        <button type="button" class="tk-btn tk-btn-primary" data-new>+ Nouveau ticket</button>
        <button type="button" class="tk-btn" data-refresh>↻ Actualiser</button>
      </div>
    </section>

    <section class="tk-stats" data-stats>
      <div class="tk-stat"><b>0</b><span>Ouverts</span></div>
      <div class="tk-stat"><b>0</b><span>Fermés</span></div>
      <div class="tk-stat"><b>0</b><span>Mes tickets</span></div>
      <div class="tk-stat"><b>0</b><span>Partagés avec moi</span></div>
    </section>

    <section class="tk-toolbar">
      <div class="tk-field"><label>Statut</label><select class="tk-input" data-filter="status"><option value="all">Tous</option><option value="open">Ouvert</option><option value="in_progress">En cours</option><option value="waiting">En attente</option><option value="resolved">Résolu</option><option value="closed">Fermé</option></select></div>
      <div class="tk-field"><label>Vue</label><select class="tk-input" data-filter="scope"><option value="visible">Tous visibles</option><option value="mine">Mes tickets</option><?php if (in_array($role, ['admin','superadmin'], true)): ?><option value="all">Tous admin</option><?php endif; ?></select></div>
      <div class="tk-field"><label>Catégorie</label><select class="tk-input" data-filter="category"><option value="">Toutes</option><?php foreach($cats as $c): ?><option value="<?= htmlspecialchars($c, ENT_QUOTES) ?>"><?= htmlspecialchars($c) ?></option><?php endforeach; ?></select></div>
      <div class="tk-field"><label>Priorité</label><select class="tk-input" data-filter="priority"><option value="">Toutes</option><?php foreach($pri as $p): ?><option value="<?= htmlspecialchars($p, ENT_QUOTES) ?>"><?= htmlspecialchars($p) ?></option><?php endforeach; ?></select></div>
      <div class="tk-field" data-client-filter-wrap hidden><label>Entreprise</label><select class="tk-input" data-filter="client"><option value="">Toutes</option></select></div>
      <div class="tk-field"><label>Recherche</label><input class="tk-input" data-filter="q" placeholder="Titre, message, auteur..."></div>
      <button type="button" class="tk-btn" data-clear>Effacer</button>
    </section>

    <section class="tk-list" data-list></section>
  </div>
</div>
<script>
(() => {
  const uid = <?= json_encode($uid) ?>;
  const root = document.getElementById('ticketing-' + uid);
  const API = 'modules/dmd-ticketing/dmd-ticketing_api.php';
  const UPLOAD = 'modules/dmd-ticketing/dmd-ticketing_upload.php';
  const state = { boot:null, items:[], z:100000, offset:0, timer:null, pollTimer:null, polling:false, baseDocW:0, baseDocH:0 };
  const $ = (s, sc=root) => sc.querySelector(s);
  const $$ = (s, sc=root) => Array.from(sc.querySelectorAll(s));
  const h = v => String(v ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[ch]));
  const fmt = s => { if(!s) return ''; const d = new Date(s); return isNaN(d) ? h(s) : d.toLocaleString(); };
  const nl = s => h(s).replace(/\n/g, '<br>');
  const vals = sel => Array.from(sel?.selectedOptions || []).map(o=>o.value).filter(Boolean);
  const statusLabels = () => state.boot?.statuses || {open:'Ouvert', in_progress:'En cours', waiting:'En attente', resolved:'Résolu', closed:'Fermé'};
  const statusLabel = st => statusLabels()[st || 'open'] || 'Ouvert';
  const statusClass = st => ({open:'tk-badge-open', in_progress:'tk-badge-progress', waiting:'tk-badge-waiting', resolved:'tk-badge-resolved', closed:'tk-badge-closed'}[st || 'open'] || 'tk-badge-open');


  const workflowOf = t => (t?.workflow && typeof t.workflow==='object') ? t.workflow : (t?.meta?.workflow || {});
  function durationLabel(seconds){
    seconds=Math.max(0,Number(seconds||0)); const minutes=Math.floor(seconds/60); const h=Math.floor(minutes/60); const m=minutes%60;
    if(h>0) return h+' h '+String(m).padStart(2,'0');
    if(minutes>0) return minutes+' min';
    return seconds>0 ? Math.floor(seconds)+' s' : '0 min';
  }
  function workflowHtml(t){
    const wf=workflowOf(t); const cards=[]; const time=wf.time||{}; const closure=wf.closure||{}; const incident=wf.incident||{};
    const running=time.running||{}; const myRunning=running[state.boot?.me||''];
    const timeEntries=Array.isArray(time.entries)?time.entries:[];
    const canTime=!!t.can_workflow_time;
    const canStatus=!!t.can_workflow_status;
    if(canTime || Number(time.total_seconds||0)>0){
      const rows=timeEntries.slice().reverse().slice(0,8).map(e=>`<div class="tk-workflow-row"><span><b>${h(e.user||'Intervenant')}</b>${e.note?'<small>'+h(e.note)+'</small>':''}</span><strong>${h(durationLabel(e.seconds))}</strong></div>`).join('');
      cards.push(`<details class="tk-workflow-card"><summary><span>⏱️</span><div><strong>Temps passé</strong><small>${h(durationLabel(time.total_seconds||0))}</small></div><b>›</b></summary><div class="tk-workflow-content">${canTime?`<div class="tk-workflow-actions">${myRunning?'<button type="button" class="tk-btn tk-btn-primary" data-time-stop>Stop</button>':'<button type="button" class="tk-btn" data-time-start>Chrono</button>'}<input class="tk-input tk-time-minutes" type="number" min="1" max="1440" placeholder="min" data-time-minutes><input class="tk-input" type="text" maxlength="180" placeholder="Note" data-time-note><button type="button" class="tk-btn" data-time-add>+ Temps</button></div>`:''}${rows?`<div class="tk-workflow-history">${rows}</div>`:''}</div></details>`);
    }
    const isClientSide=!isExternalTicket(t) && remoteTarget(t)==='support';
    if(canStatus){
      let body='';
      if(closure.state==='requested') body=`<div class="tk-workflow-state">En attente du client depuis ${h(fmt(closure.requested_at))}.</div>`;
      else if(closure.state==='accepted') body=`<div class="tk-workflow-state is-ok">Résolution confirmée par ${h(closure.responded_by||'le client')}.</div>`;
      else if(closure.state==='rejected') body=`<div class="tk-workflow-state is-warn">Résolution refusée${closure.comment?' : '+h(closure.comment):''}.</div>`;
      else if(closure.state==='forced') body='<div class="tk-workflow-state">Fermé sans validation client.</div>';
      else body='<button type="button" class="tk-btn tk-btn-primary" data-request-closure>Demander la validation</button>';
      const stateText=closure.state==='requested'?'En attente':closure.state==='accepted'?'Confirmée':closure.state==='rejected'?'Refusée':'À demander';
      cards.push(`<details class="tk-workflow-card"><summary><span>✅</span><div><strong>Validation client</strong><small>${h(stateText)}</small></div><b>›</b></summary><div class="tk-workflow-content">${body}</div></details>`);
    } else if(isClientSide && closure.state==='requested'){
      cards.push(`<details class="tk-workflow-card tk-workflow-validation" open><summary><span>✅</span><div><strong>Validation demandée</strong><small>Le support propose de clôturer</small></div><b>›</b></summary><div class="tk-workflow-content"><textarea class="tk-input" rows="2" maxlength="300" placeholder="Commentaire si nécessaire" data-closure-comment></textarea><div class="tk-workflow-actions"><button type="button" class="tk-btn tk-btn-primary" data-closure-accept>Résolu</button><button type="button" class="tk-btn" data-closure-reject>Toujours en panne</button></div></div></details>`);
    } else if(isClientSide && ['accepted','rejected'].includes(String(closure.state||''))){
      cards.push(`<details class="tk-workflow-card"><summary><span>✅</span><div><strong>Validation client</strong><small>${closure.state==='accepted'?'Résolution confirmée':'Résolution refusée'}</small></div><b>›</b></summary></details>`);
    }
    if(canStatus){
      const options=(t.incident_options||[]).map(i=>`<option value="${h(i.id)}" ${String(i.id)===String(incident.id||'')?'selected':''}>${h(i.title)}${i.status==='closed'?' · clos':''} (${h(i.count||0)})</option>`).join('');
      const related=(t.incident_related||[]).map(r=>`<button type="button" class="tk-related-ticket" data-related-ticket="${h(r.id)}"><span>${h(r.title||r.id)}</span><small>${h(r.client||statusLabel(r.status))}</small></button>`).join('');
      cards.push(`<details class="tk-workflow-card"><summary><span>🧩</span><div><strong>Incident lié</strong><small>${h(incident.title||'Aucun incident')}</small></div><b>›</b></summary><div class="tk-workflow-content"><div class="tk-workflow-actions"><select class="tk-input" data-incident-select><option value="">Aucun incident</option>${options}</select><button type="button" class="tk-btn" data-incident-link>Lier</button>${incident.id?'<button type="button" class="tk-btn" data-incident-unlink>Délier</button><button type="button" class="tk-btn" data-incident-status>'+(incident.status==='closed'?'Rouvrir':'Clore')+'</button>':''}</div><div class="tk-workflow-create"><input class="tk-input" type="text" maxlength="180" placeholder="Nouvel incident" data-incident-title><button type="button" class="tk-btn" data-incident-create>Créer</button></div>${related?`<div class="tk-related-list">${related}</div>`:''}</div></details>`);
    } else if(incident.id){
      cards.push(`<details class="tk-workflow-card"><summary><span>🧩</span><div><strong>Incident lié</strong><small>${h(incident.title||incident.id)}</small></div><b>›</b></summary></details>`);
    }
    return cards.length ? `<section class="tk-workflow-grid">${cards.join('')}</section>` : '';
  }

  function copyThemeVars(win){
    const cs = getComputedStyle(root);
    ['--tk-bg','--tk-bg-soft','--tk-bg-strong','--tk-border','--tk-text','--tk-muted','--tk-accent','--tk-danger','--tk-ok','--tk-radius','--card-bg','--section-bg','--input-bg','--popup-bg','--border-color','--text-color','--muted-color','--accent-color','--primary-color'].forEach(v => {
      const val = cs.getPropertyValue(v);
      if (val) win.style.setProperty(v, val);
    });
  }
  async function api(a, body={}, method='POST'){
    body = body || {};
    if(method !== 'GET' && state.boot?.csrf && !body.csrf) body.csrf = state.boot.csrf;
    const opt = {method, headers:{'Content-Type':'application/json'}};
    if(method !== 'GET') opt.body = JSON.stringify(body);
    const res = await fetch(API + '?a=' + encodeURIComponent(a), opt);
    return await res.json();
  }
  async function refreshBootstrap(){
    const b = await api('bootstrap');
    if(!b?.ok) return null;
    state.boot = b;

    const categoryFilter = $('[data-filter="category"]');
    if(categoryFilter){
      const previous = categoryFilter.value;
      categoryFilter.innerHTML = '<option value="">Toutes</option>' + options(b.categories || [], previous);
      if(previous && !(b.categories || []).includes(previous)) categoryFilter.value = '';
    }

    const priorityFilter = $('[data-filter="priority"]');
    if(priorityFilter){
      const previous = priorityFilter.value;
      priorityFilter.innerHTML = '<option value="">Toutes</option>' + options(b.priorities || [], previous);
      if(previous && !(b.priorities || []).includes(previous)) priorityFilter.value = '';
    }

    const clientFilter = $('[data-filter="client"]');
    const clientWrap = $('[data-client-filter-wrap]');
    const clientRows = Array.isArray(b.external_clients) ? b.external_clients : [];
    if(clientFilter && clientWrap){
      const previous = clientFilter.value;
      clientWrap.hidden = clientRows.length === 0;
      clientFilter.innerHTML = '<option value="">Toutes</option>' + clientRows.map(c => `<option value="${h(c.ref || c.name || '')}">${h(c.name || c.ref || 'Client')}</option>`).join('');
      if(previous && !clientRows.some(c => String(c.ref || c.name || '') === previous)) clientFilter.value = '';
      else clientFilter.value = previous;
    }
    return b;
  }
  async function uploadFiles(id, input){
    if(!input || !input.files || !input.files.length) return {ok:true};
    const fd = new FormData(); fd.append('ticket_id', id); if(state.boot?.csrf) fd.append('csrf', state.boot.csrf);
    Array.from(input.files).forEach(f => fd.append('files[]', f));
    const res = await fetch(UPLOAD, {method:'POST', body:fd});
    return await res.json();
  }
  function setDroppedFiles(input, files){
    if(!input || !files || !files.length) return false;
    try {
      const dt = new DataTransfer();
      Array.from(input.files || []).forEach(file => dt.items.add(file));
      Array.from(files).forEach(file => dt.items.add(file));
      input.files = dt.files;
      input.dispatchEvent(new Event('change', {bubbles:true}));
      return true;
    } catch(e) { return false; }
  }
  function myDeskDropInput(){
    const windows = $$('.tk-window, .tk-create-window, .tk-ticket-window', document)
      .filter(w => w && w.offsetParent !== null)
      .sort((a,b) => (parseInt(getComputedStyle(a).zIndex || '0',10)||0) - (parseInt(getComputedStyle(b).zIndex || '0',10)||0));
    const top = windows.length ? windows[windows.length-1] : root;
    return top ? top.querySelector('input[type="file"]:not(:disabled)') : null;
  }
  if(window.DMDMyDesk){
    window.addEventListener('dmd:mydesk-files', ev => {
      const files = Array.from(ev.detail?.files || ev.detail?.fileList || []);
      if(!files.length) return;
      const input = myDeskDropInput();
      if(!input){
        window.DMDMyDesk.notify('DMD-Ticketing', 'Ouvrez un nouveau ticket ou une réponse avant de déposer des fichiers.', 'dmd-ticketing');
        return;
      }
      if(setDroppedFiles(input, files)){
        const drop = input.closest('.tk-new-ticket-upload') || input.parentElement;
        if(drop){ drop.classList.add('is-mydesk-drop'); setTimeout(()=>drop.classList.remove('is-mydesk-drop'),900); }
        window.DMDMyDesk.notify('DMD-Ticketing', files.length + ' fichier(s) ajouté(s) aux pièces jointes.', 'dmd-ticketing');
      }
    });
  }
  function badge(text, cls=''){
    if(!text) return '';
    return `<span class="tk-badge ${cls}">${h(text)}</span>`;
  }
  function remoteTarget(t){ return String(t?.remote_target || t?.meta?.domydesk?.target || 'domyco'); }
  function remoteName(t){
    if(remoteTarget(t)==='support') return String(t?.meta?.domydesk?.target_name || state.boot?.external_support?.name || 'Support externe');
    return 'DoMyCo';
  }
  function isExternalTicket(t){ return !!(t?.meta?.external && typeof t.meta.external === 'object'); }
  function isEscalatedToDomyco(t){
    if(t?.meta?.escalation?.requested) return true;
    const targets=Array.isArray(t?.remote_targets) ? t.remote_targets : [];
    return targets.includes('domyco');
  }
  function messageRemoteName(m,t){
    const origin=String(m?.origin_target || '');
    if(origin==='domyco') return 'DoMyCo';
    if(origin==='support' && m?.origin_name) return String(m.origin_name);
    return remoteName(t);
  }
  function escalationBadge(t){
    if(!isEscalatedToDomyco(t)) return '';
    const st=String(t?.meta?.remotes?.domyco?.status || t?.meta?.escalation?.status || 'pending');
    return st==='sent' ? badge('Escaladé vers DoMyCo','tk-badge-domydesk') : badge('Escalade DoMyCo en attente','tk-badge-waiting');
  }
  function displayOwner(t){ return String(t?.meta?.external?.requester || t?.external_requester || t?.owner || ''); }
  function externalClientName(t){ return String(t?.meta?.external?.client_name || ''); }
  function domydeskBadge(t){
    const dm = t?.meta?.domydesk;
    if(!dm?.requested && !t?.send_to_domydesk) return '';
    const name=remoteName(t);
    if(dm?.status === 'sent') return badge(name + ' synchronisé', 'tk-badge-domydesk');
    return badge(name + ' en attente', 'tk-badge-waiting');
  }
  function notificationInfo(t){
    const dm = t?.meta?.domydesk;
    const ext = t?.meta?.external;
    const remoteN = (dm?.notification && typeof dm.notification === 'object') ? dm.notification : {};
    const externalN = (ext?.notification && typeof ext.notification === 'object') ? ext.notification : {};
    const remoteUnread = !!remoteN.unread;
    const externalUnread = !!externalN.unread;
    const linked = !!(ext?.client_name || ext?.client_ref || dm?.requested || t?.send_to_domydesk);
    const count = (remoteUnread ? Number(remoteN.count || 1) : 0) + (externalUnread ? Number(externalN.count || 1) : 0);
    let label = 'Aucune nouvelle information';
    if(externalUnread && remoteUnread) label = 'Nouvelles informations Client et ' + remoteName(t);
    else if(externalUnread) label = String(externalN.label || ('Nouvelle réponse de ' + (externalClientName(t) || 'Client')));
    else if(remoteUnread) label = String(remoteN.label || ('Nouvelle information de ' + remoteName(t)));
    return { linked, unread:remoteUnread || externalUnread, count, label };
  }
  function notificationDot(t){
    const n = notificationInfo(t);
    if(!n.linked) return '';
    const cls = n.unread ? 'is-new' : 'is-idle';
    const text = n.unread && n.count > 1 ? String(n.count) : '';
    return `<span class="tk-notification-dot ${cls}" title="${h(n.label)}">${h(text)}</span>`;
  }
  function updateNotificationSummary(items){
    const target = $('[data-notif-summary]');
    if(!target) return;
    const unread = (items || []).filter(t => notificationInfo(t).unread).length;
    target.classList.toggle('is-new', unread > 0);
    target.classList.toggle('is-idle', unread === 0);
    target.textContent = unread > 0 ? String(unread) : '';
    target.title = unread > 0 ? unread + ' ticket(s) avec une nouvelle information' : 'Aucune nouvelle information';
  }
  function shareText(t){
    const s = t.share || {};
    if (t.owner !== state.boot?.me && t.owner) return 'Partagé';
    if (s.all) return 'Tous';
    const nU = (s.users || []).length;
    const nR = (s.roles || []).length;
    if(nU || nR) return [nU ? nU + ' utilisateur(s)' : '', nR ? nR + ' rôle(s)' : ''].filter(Boolean).join(' · ');
    return 'Privé';
  }
  function renderStats(items){
    const active = items.filter(t=>!['resolved','closed'].includes(t.status || 'open')).length;
    const progress = items.filter(t=>(t.status || 'open')==='in_progress').length;
    const waiting = items.filter(t=>(t.status || 'open')==='waiting').length;
    const done = items.filter(t=>['resolved','closed'].includes(t.status || 'open')).length;
    $('[data-stats]').innerHTML = `
      <div class="tk-stat"><b>${active}</b><span>Actifs</span></div>
      <div class="tk-stat"><b>${progress}</b><span>En cours</span></div>
      <div class="tk-stat"><b>${waiting}</b><span>En attente</span></div>
      <div class="tk-stat"><b>${done}</b><span>Résolus/Fermés</span></div>`;
  }
  function renderTicketCard(t){
    return `
      <article class="tk-card" data-open="${h(t.id)}" data-dmd-context-type="ticket" data-dmd-context-id="${h(t.id)}">
        <div class="tk-card-top">
          <div class="tk-card-title">${h(t.title || '(sans titre)')}</div>
          <div class="tk-card-flags">${notificationDot(t)}${badge(statusLabel(t.status), statusClass(t.status))}</div>
        </div>
        <div class="tk-card-meta"><span>${h(externalClientName(t) || t.owner || '')}</span><span>${fmt(t.updated_at || t.created_at)}</span></div>
        <div class="tk-preview">${h(t.last_message || '')}</div>
        <div class="tk-badges">${externalClientName(t)?badge('Client : '+externalClientName(t),'tk-badge-shared'):''}${badge(t.category)}${badge(t.priority)}${badge(shareText(t),'tk-badge-shared')}${domydeskBadge(t)}</div>
      </article>`;
  }
  function renderClientGroup(name, tickets, internal=false){
    const unread = tickets.filter(t => notificationInfo(t).unread).length;
    const countLabel = tickets.length + ' ticket' + (tickets.length > 1 ? 's' : '');
    const newBadge = unread > 0
      ? `<span class="tk-client-group-new" title="${h(unread + ' ticket' + (unread > 1 ? 's' : '') + ' avec une nouvelle information')}">${h(String(unread))}</span>`
      : '';
    return `<section class="tk-client-group${internal ? ' is-internal' : ''}">
      <div class="tk-client-group-head">
        <div class="tk-client-group-title"><strong>${h(name)}</strong><span>${h(countLabel)}</span></div>
        ${newBadge}
      </div>
      <div class="tk-client-group-list">${tickets.map(renderTicketCard).join('')}</div>
    </section>`;
  }
  function renderList(items){
    const list = $('[data-list]');
    renderStats(items);
    updateNotificationSummary(items);
    if(!items.length){ list.classList.remove('is-client-grouped'); list.innerHTML = '<div class="tk-empty">Aucun ticket.</div>'; return; }

    const selectedClient = $('[data-filter="client"]')?.value || '';
    const hasExternalTickets = items.some(t => externalClientName(t) !== '');
    const groupByClient = selectedClient === '' && hasExternalTickets;
    list.classList.toggle('is-client-grouped', groupByClient);

    if(groupByClient){
      const groups = new Map();
      const internal = [];
      items.forEach(t => {
        const clientName = externalClientName(t);
        if(!clientName){ internal.push(t); return; }
        if(!groups.has(clientName)) groups.set(clientName, []);
        groups.get(clientName).push(t);
      });
      let html = '';
      groups.forEach((tickets, clientName) => { html += renderClientGroup(clientName, tickets, false); });
      if(internal.length) html += renderClientGroup('Tickets internes', internal, true);
      list.innerHTML = html;
    }else{
      list.innerHTML = items.map(renderTicketCard).join('');
    }

    $$('[data-open]', list).forEach(card => card.onclick = () => openTicket(card.dataset.open));
    if(window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') window.DMDActionHub.decorate(list);
  }
  async function load(){
    const payload = {
      status: $('[data-filter="status"]').value,
      scope: $('[data-filter="scope"]').value,
      category: $('[data-filter="category"]').value,
      priority: $('[data-filter="priority"]').value,
      client: $('[data-filter="client"]')?.value || '',
      q: $('[data-filter="q"]').value.trim()
    };
    const r = await api('list', payload);
    if(!r?.ok){ $('[data-list]').innerHTML = '<div class="tk-empty">Erreur de chargement.</div>'; return; }
    state.items = r.items || [];
    renderList(state.items);
  }
  async function refreshAll(){
    const btn = $('[data-refresh]');
    const previous = btn.textContent;
    btn.disabled = true;
    btn.textContent = '↻ Synchronisation...';
    try {
      await refreshBootstrap();
      const r = await api('sync_all', {force:true});
      if(!r?.ok) alert(r?.err || 'Erreur de synchronisation.');
      await load();
    } finally {
      btn.disabled = false;
      btn.textContent = previous;
    }
  }
  function openTicketWindows(){
    return $$('.tk-ticket-window[data-dmd-context-id]', document).filter(w => w && w.isConnected);
  }
  function ticketWindowHasDraft(win){
    const textarea = $('[data-reply-form] textarea[name="message"]', win);
    const files = $('[data-reply-form] input[type="file"]', win);
    return !!((textarea && textarea.value.trim() !== '') || (files && files.files && files.files.length));
  }
  async function refreshOpenTicketsAfterSync(){
    const windows = openTicketWindows();
    for(const win of windows){
      const id = String(win.getAttribute('data-dmd-context-id') || '');
      if(!id || ticketWindowHasDraft(win)) continue;
      try {
        const r = await api('get', {id});
        if(!r?.ok || !r.item) continue;
        const remoteUpdated = String(r.item.updated_at || r.item.created_at || '');
        const localUpdated = String(win.getAttribute('data-ticket-updated-at') || '');
        const remoteCount = Number(Array.isArray(r.item.messages) ? r.item.messages.length : 0);
        const localCount = Number(win.getAttribute('data-ticket-message-count') || 0);
        if(remoteUpdated !== localUpdated || remoteCount !== localCount){
          const rect = win.getBoundingClientRect();
          const width = win.offsetWidth;
          const height = win.offsetHeight;
          removeWindow(win);
          await openTicket(id);
          const reopened = openTicketWindows().filter(w => String(w.getAttribute('data-dmd-context-id') || '') === id).pop();
          if(reopened){
            reopened.style.left = Math.max(0, rect.left + window.scrollX) + 'px';
            reopened.style.top = Math.max(0, rect.top + window.scrollY) + 'px';
            reopened.style.width = width + 'px';
            reopened.style.height = height + 'px';
            recalcWorkspace();
          }
        }
      } catch (_) {}
    }
  }
  async function silentSync(){
    if(state.polling) return;
    state.polling = true;
    try {
      const r = await api('sync_all');
      if(r?.ok){
        await load();
        await refreshOpenTicketsAfterSync();
      }
    } catch (_) {
    } finally {
      state.polling = false;
    }
  }
  function startAutomaticSync(){
    if(state.pollTimer) clearInterval(state.pollTimer);
    state.pollTimer = setInterval(silentSync, 120000);
    document.addEventListener('visibilitychange', () => { if(!document.hidden) silentSync(); });
    window.addEventListener('focus', silentSync);
  }
  function initWorkspaceBase(){
    const doc = document.documentElement;
    const body = document.body;
    if(!state.baseDocW) state.baseDocW = Math.max(window.innerWidth, doc.clientWidth || 0, body.clientWidth || 0, doc.scrollWidth || 0, body.scrollWidth || 0);
    if(!state.baseDocH) state.baseDocH = Math.max(window.innerHeight, doc.clientHeight || 0, body.clientHeight || 0, doc.scrollHeight || 0, body.scrollHeight || 0);
  }
  function recalcWorkspace(){
    initWorkspaceBase();
    const doc = document.documentElement;
    const body = document.body;
    let needW = state.baseDocW;
    let needH = state.baseDocH;
    document.querySelectorAll('.tk-window').forEach(w => {
      if(!w.isConnected) return;
      const left = parseFloat(w.style.left) || w.offsetLeft || 0;
      const top  = parseFloat(w.style.top) || w.offsetTop || 0;
      needW = Math.max(needW, Math.ceil(left + w.offsetWidth + 80));
      needH = Math.max(needH, Math.ceil(top + w.offsetHeight + 80));
    });
    doc.style.minWidth = needW + 'px';
    body.style.minWidth = needW + 'px';
    doc.style.minHeight = needH + 'px';
    body.style.minHeight = needH + 'px';
    const maxX = Math.max(0, needW - window.innerWidth);
    const maxY = Math.max(0, needH - window.innerHeight);
    if(window.scrollX > maxX || window.scrollY > maxY) window.scrollTo(Math.min(window.scrollX, maxX), Math.min(window.scrollY, maxY));
  }
  function removeWindow(win){
    if(win && win.parentNode) win.remove();
    requestAnimationFrame(recalcWorkspace);
  }
  function windowShell(title, id, bodyHtml, width=760, height=620){
    state.offset = (state.offset + 18) % 120;
    const win = document.createElement('div');
    win.className = 'tk-window';
    win.style.left = (24 + state.offset) + 'px';
    win.style.top = (24 + state.offset) + 'px';
    win.style.width = `min(${width}px, calc(100vw - 18px))`;
    win.style.height = `min(${height}px, calc(100vh - 18px))`;
    copyThemeVars(win);
    win.innerHTML = `
      <div class="tk-window-head" data-drag>
        <strong>${h(title)}</strong>${id ? `<span class="tk-window-id">${h(id)}</span>` : ''}
        <div class="tk-window-actions"><button type="button" class="tk-btn" data-reload title="Actualiser">↻</button><button type="button" class="tk-btn" data-x title="Fermer">×</button></div>
      </div>
      <div class="tk-window-body">${bodyHtml}</div>`;
    document.body.appendChild(win);
    win.style.zIndex = ++state.z;
    win.addEventListener('pointerdown', () => win.style.zIndex = ++state.z);
    $('[data-x]', win).onclick = () => removeWindow(win);
    makeDraggable(win, $('[data-drag]', win));
    requestAnimationFrame(recalcWorkspace);
    return win;
  }
  function makeDraggable(win, handle){
    let sx=0, sy=0, sl=0, st=0, dragging=false;
    const autoScroll = (e) => {
      const edge = 34;
      const step = 32;
      if(e.clientX > window.innerWidth - edge) window.scrollBy(step, 0);
      if(e.clientY > window.innerHeight - edge) window.scrollBy(0, step);
      if(e.clientX < edge) window.scrollBy(-step, 0);
      if(e.clientY < edge) window.scrollBy(0, -step);
    };
    handle.addEventListener('pointerdown', e => {
      if(e.target.closest('button')) return;
      dragging=true;
      sx=e.pageX; sy=e.pageY;
      sl=parseFloat(win.style.left) || win.offsetLeft;
      st=parseFloat(win.style.top) || win.offsetTop;
      win.style.zIndex = ++state.z;
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener('pointermove', e => {
      if(!dragging) return;
      autoScroll(e);
      const nextL = Math.max(6, sl + e.pageX - sx);
      const nextT = Math.max(6, st + e.pageY - sy);
      win.style.left = nextL + 'px';
      win.style.top = nextT + 'px';
      recalcWorkspace();
    });
    const stop = e => { dragging=false; try{handle.releasePointerCapture(e.pointerId);}catch(_){} requestAnimationFrame(recalcWorkspace); };
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
  }
  function makeResizable(win, handle){
    if(!win || !handle) return;
    let startX=0, startY=0, startW=0, startH=0, resizing=false;
    const minW=420, minH=360;
    handle.addEventListener('pointerdown', e=>{
      e.preventDefault();
      e.stopPropagation();
      resizing=true;
      startX=e.clientX;
      startY=e.clientY;
      const r=win.getBoundingClientRect();
      startW=r.width;
      startH=r.height;
      win.style.zIndex=++state.z;
      handle.setPointerCapture?.(e.pointerId);
      win.classList.add('is-resizing');
    });
    handle.addEventListener('pointermove', e=>{
      if(!resizing) return;
      const maxW=Math.max(minW, window.innerWidth - Math.max(6, win.getBoundingClientRect().left) - 6);
      const maxH=Math.max(minH, window.innerHeight - Math.max(6, win.getBoundingClientRect().top) - 6);
      const nextW=Math.max(minW, Math.min(maxW, startW + (e.clientX-startX)));
      const nextH=Math.max(minH, Math.min(maxH, startH + (e.clientY-startY)));
      win.style.setProperty('width', nextW+'px', 'important');
      win.style.setProperty('height', nextH+'px', 'important');
      requestAnimationFrame(recalcWorkspace);
    });
    const stop=e=>{
      if(!resizing) return;
      resizing=false;
      win.classList.remove('is-resizing');
      try{handle.releasePointerCapture?.(e.pointerId);}catch(_){ }
      requestAnimationFrame(recalcWorkspace);
    };
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
  }

  function options(arr, selected=''){ return (arr || []).map(v => `<option value="${h(v)}" ${String(v)===String(selected)?'selected':''}>${h(v)}</option>`).join(''); }
  function statusOptions(selected='open'){ return Object.entries(statusLabels()).map(([k,v]) => `<option value="${h(k)}" ${String(k)===String(selected || 'open')?'selected':''}>${h(v)}</option>`).join(''); }
  function multiUsers(selected=[]){ return (state.boot?.users || []).map(u => `<option value="${h(u.email)}" ${selected.includes(u.email)?'selected':''}>${h(u.label || u.email)}${u.role_metier ? ' [' + h(u.role_metier) + ']' : ''}</option>`).join(''); }
  function multiRoles(selected=[]){ return (state.boot?.roles || []).map(r => `<option value="${h(r)}" ${selected.includes(r)?'selected':''}>${h(r)}</option>`).join(''); }
  function shareUserChecks(selected=[]){
    const users = state.boot?.users || [];
    if(!users.length) return '<div class="tk-pro-check-empty">Aucun utilisateur disponible.</div>';
    return users.map(u => {
      const email=String(u.email || '');
      const label=String(u.label || email);
      const role=u.role_metier ? ' · ' + String(u.role_metier) : '';
      return `<label class="tk-pro-check-row" data-share-search="${h((label + ' ' + email + role).toLowerCase())}"><input type="checkbox" data-share-user value="${h(email)}" ${selected.includes(email)?'checked':''}><span class="tk-pro-checkbox"></span><span class="tk-pro-check-copy"><strong>${h(label)}</strong><small>${h(email + role)}</small></span></label>`;
    }).join('');
  }
  function shareRoleChecks(selected=[]){
    const roles = state.boot?.roles || [];
    if(!roles.length) return '<div class="tk-pro-check-empty">Aucun rôle métier disponible.</div>';
    return roles.map(r => `<label class="tk-pro-check-row" data-share-search="${h(String(r).toLowerCase())}"><input type="checkbox" data-share-role value="${h(r)}" ${selected.includes(r)?'checked':''}><span class="tk-pro-checkbox"></span><span class="tk-pro-check-copy"><strong>${h(r)}</strong><small>Rôle métier</small></span></label>`).join('');
  }
  function shareForm(share={}){
    return `<div class="tk-share-box tk-wide">
      <strong>Partage du ticket</strong>
      <label class="tk-checkline"><input type="checkbox" data-share-all ${share.all?'checked':''}> Partager avec tous les utilisateurs</label>
      <div class="tk-share-row">
        <div class="tk-field"><label>Utilisateurs</label><select class="tk-input tk-multi" multiple data-share-users>${multiUsers(share.users || [])}</select></div>
        <div class="tk-field"><label>Rôles métier</label><select class="tk-input tk-multi" multiple data-share-roles>${multiRoles(share.roles || [])}</select></div>
      </div>
    </div>`;
  }
  function collectShare(win){
    const userChecks=$$('[data-share-user]:checked', win).map(el=>el.value).filter(Boolean);
    const roleChecks=$$('[data-share-role]:checked', win).map(el=>el.value).filter(Boolean);
    const userSelect=$('[data-share-users]', win);
    const roleSelect=$('[data-share-roles]', win);
    return {
      all: !!$('[data-share-all]', win)?.checked,
      users: userChecks.length ? userChecks : vals(userSelect),
      roles: roleChecks.length ? roleChecks : vals(roleSelect)
    };
  }
  async function openNew(){
    const fresh = await refreshBootstrap();
    if(!fresh){ alert('Impossible de charger la configuration DMD-Ticketing.'); return; }
    const supportEnabled = !!state.boot?.external_support?.enabled;
    const supportName = h(state.boot?.external_support?.name || 'Support externe');
    const html = `<form class="tk-new-ticket-form tk-new-ticket-pro" data-new-form>
      <div class="tk-pro-scroll" data-ticket-scroll>
        <header class="tk-pro-head">
          <div>
            <span class="tk-pro-eyebrow">NOUVEAU TICKET</span>
            <strong>Créer une demande</strong>
            <small>Décrivez le besoin, classez-le puis choisissez les destinataires et les personnes autorisées.</small>
          </div>
          ${state.boot?.mydesk_context ? `<div class="tk-pro-context"><span>Poste lié</span><b>${h(state.boot.mydesk_context.hostname || 'DMD-Agent')}</b></div>` : ''}
        </header>

        <div class="tk-pro-top-grid">
          <section class="tk-pro-main">
            <div class="tk-pro-section-title">
              <span>01</span>
              <div><strong>Demande</strong><small>Décrivez clairement le problème ou le besoin.</small></div>
            </div>

            <div class="tk-field">
              <label>Titre</label>
              <input class="tk-input tk-pro-title" name="title" required placeholder="Ex. : Impossible d’imprimer depuis le poste accueil">
            </div>

            <div class="tk-field tk-pro-message-field">
              <label>Description</label>
              <textarea class="tk-input tk-pro-message" name="message" required placeholder="Décrivez le problème, ce qui a déjà été essayé et l’impact pour l’utilisateur..."></textarea>
            </div>

            <label class="tk-pro-upload">
              <input type="file" name="files" multiple data-ticket-files>
              <span class="tk-pro-upload-icon">📎</span>
              <span><strong>Pièces jointes</strong><small data-file-summary>Captures, PDF, logs, documents…</small></span>
              <span class="tk-pro-upload-action">Parcourir</span>
            </label>
          </section>

          <aside class="tk-pro-treatment">
            <section class="tk-pro-panel">
              <div class="tk-pro-section-title">
                <span>02</span>
                <div><strong>Traitement</strong><small>Classement du ticket.</small></div>
              </div>
              <div class="tk-pro-meta-stack">
                <div class="tk-field"><label>Catégorie</label><select class="tk-input" name="category">${options(state.boot?.categories || [])}</select></div>
                <div class="tk-field"><label>Priorité</label><select class="tk-input" name="priority">${options(state.boot?.priorities || [])}</select></div>
              </div>
              <div class="tk-pro-treatment-note">
                <strong>Conseil</strong>
                <span>Choisissez la priorité selon l’impact réel pour l’utilisateur ou le service.</span>
              </div>
            </section>
          </aside>
        </div>

        <div class="tk-pro-accordions">
          <details class="tk-pro-panel tk-pro-fold tk-pro-routing-panel" data-destination-fold>
            <summary>
              <span class="tk-pro-section-title tk-pro-section-title-inline"><span>03</span><div><strong>Destinataires</strong><small>Choisissez un ou plusieurs supports.</small></div></span>
              <span class="tk-pro-fold-right"><b data-destination-summary>${supportEnabled ? supportName : 'Interne uniquement'}</b><span class="tk-pro-chevron" aria-hidden="true">⌄</span></span>
            </summary>
            <div class="tk-pro-fold-body">
              <div class="tk-pro-route-grid">
                <label class="tk-pro-check-row tk-pro-check-row-fixed">
                  <input type="checkbox" checked disabled>
                  <span class="tk-pro-checkbox"></span>
                  <span class="tk-pro-check-copy"><strong>Ce DoMyDesk</strong><small>Le ticket reste toujours disponible localement.</small></span>
                </label>
                ${supportEnabled ? `<label class="tk-pro-check-row">
                  <input type="checkbox" name="remote_targets[]" value="support" data-destination-label="${supportName}" checked>
                  <span class="tk-pro-checkbox"></span>
                  <span class="tk-pro-check-copy"><strong>${supportName}</strong><small>Entreprise de support configurée</small></span>
                </label>` : ''}
                <label class="tk-pro-check-row">
                  <input type="checkbox" name="remote_targets[]" value="domyco" data-destination-label="DoMyCo">
                  <span class="tk-pro-checkbox"></span>
                  <span class="tk-pro-check-copy"><strong>DoMyCo</strong><small>DoMyDesk, module, licence ou service DoMyCo.</small></span>
                </label>
              </div>
              <div class="tk-pro-fold-hint">Plusieurs supports peuvent être cochés pour le même ticket. Sans support externe, le ticket reste uniquement dans ce DoMyDesk.</div>
            </div>
          </details>

          <details class="tk-pro-panel tk-pro-fold tk-pro-share" data-share-fold>
            <summary>
              <span class="tk-pro-section-title tk-pro-section-title-inline"><span>04</span><div><strong>Partage</strong><small>Définissez qui peut consulter ce ticket.</small></div></span>
              <span class="tk-pro-fold-right"><b data-share-summary>Privé</b><span class="tk-pro-chevron" aria-hidden="true">⌄</span></span>
            </summary>
            <div class="tk-pro-fold-body tk-pro-share-body-v2" data-share-body>
              <label class="tk-pro-check-row tk-pro-share-everyone">
                <input type="checkbox" data-share-all>
                <span class="tk-pro-checkbox"></span>
                <span class="tk-pro-check-copy"><strong>Tous les utilisateurs</strong><small>Donner accès à tous les utilisateurs autorisés à utiliser DMD-Ticketing.</small></span>
              </label>

              <div class="tk-pro-share-toolbar">
                <div class="tk-pro-share-tabs" role="tablist" aria-label="Type de partage">
                  <button type="button" class="is-active" data-share-tab="users">Utilisateurs <span data-share-user-count>0</span></button>
                  <button type="button" data-share-tab="roles">Rôles métier <span data-share-role-count>0</span></button>
                </div>
                <label class="tk-pro-share-search"><span>⌕</span><input type="search" data-share-filter placeholder="Rechercher..."></label>
              </div>

              <div class="tk-pro-share-browser" data-share-browser>
                <div class="tk-pro-share-list" data-share-pane="users">${shareUserChecks([])}</div>
                <div class="tk-pro-share-list" data-share-pane="roles" hidden>${shareRoleChecks([])}</div>
              </div>
              <div class="tk-pro-fold-hint">Cochez plusieurs utilisateurs ou rôles si nécessaire. Le propriétaire et les administrateurs conservent toujours l’accès.</div>
            </div>
          </details>
        </div>
      </div>

      <div class="tk-pro-footer">
        <div class="tk-msg" data-msg></div>
        <div class="tk-pro-actions">
          <button type="button" class="tk-btn" data-cancel>Annuler</button>
          <button type="submit" class="tk-btn tk-btn-primary">Créer le ticket</button>
        </div>
      </div>
    </form>`;
    const win = windowShell('Nouveau ticket', '', html, 900, 620);
    win.classList.add('tk-create-window', 'tk-new-ticket-window');
    win.style.setProperty('width', Math.min(900, Math.max(620, window.innerWidth - 40)) + 'px', 'important');
    win.style.setProperty('height', Math.min(620, Math.max(500, window.innerHeight - 40)) + 'px', 'important');
    const resizeHandle=document.createElement('span');
    resizeHandle.className='tk-window-resize-handle';
    resizeHandle.setAttribute('aria-hidden','true');
    win.appendChild(resizeHandle);
    makeResizable(win, resizeHandle);

    const updateWindowLayout=()=>{
      const r=win.getBoundingClientRect();
      win.classList.toggle('tk-create-narrow', r.width < 720);
      win.classList.toggle('tk-create-small', r.width < 580);
      win.classList.toggle('tk-create-short', r.height < 540);
    };
    updateWindowLayout();
    const createResizeObserver=('ResizeObserver' in window) ? new ResizeObserver(()=>updateWindowLayout()) : null;
    createResizeObserver?.observe(win);
    $('[data-reload]', win).style.display = 'none';
    $('[data-cancel]', win).onclick = () => removeWindow(win);

    // Volets type menu déroulant : un seul ouvert, sans agrandir ni faire défiler la fenêtre.
    const ticketFolds=$$('[data-destination-fold], [data-share-fold]', win);
    ticketFolds.forEach(fold=>fold.addEventListener('toggle', ()=>{
      if(!fold.open) return;
      ticketFolds.forEach(other=>{ if(other!==fold) other.open=false; });
    }));
    win.addEventListener('pointerdown', e=>{
      if(e.target.closest('[data-destination-fold], [data-share-fold]')) return;
      ticketFolds.forEach(fold=>{ fold.open=false; });
    });
    win.addEventListener('keydown', e=>{
      if(e.key==='Escape') ticketFolds.forEach(fold=>{ fold.open=false; });
    });

    // Partage : un seul navigateur, avec onglets et recherche, au lieu de deux mini-listes scrollables.
    let activeSharePane='users';
    const shareFilter=$('[data-share-filter]', win);
    const setSharePane=(name)=>{
      activeSharePane=name==='roles'?'roles':'users';
      $$('[data-share-tab]', win).forEach(btn=>btn.classList.toggle('is-active', btn.dataset.shareTab===activeSharePane));
      $$('[data-share-pane]', win).forEach(pane=>{ pane.hidden=pane.dataset.sharePane!==activeSharePane; });
      if(shareFilter){ shareFilter.value=''; }
      $$('[data-share-pane] .tk-pro-check-row', win).forEach(row=>row.hidden=false);
    };
    $$('[data-share-tab]', win).forEach(btn=>btn.addEventListener('click', ()=>setSharePane(btn.dataset.shareTab)));
    shareFilter?.addEventListener('input', ()=>{
      const q=(shareFilter.value || '').trim().toLowerCase();
      const pane=$(`[data-share-pane="${activeSharePane}"]`, win);
      $$('.tk-pro-check-row', pane).forEach(row=>{
        const hay=(row.getAttribute('data-share-search') || row.textContent || '').toLowerCase();
        row.hidden=!!q && !hay.includes(q);
      });
    });

    const ticketFiles=$('[data-ticket-files]', win);
    const fileSummary=$('[data-file-summary]', win);
    const updateFileSummary=()=>{
      if(!ticketFiles || !fileSummary) return;
      const files=Array.from(ticketFiles.files || []);
      fileSummary.textContent=!files.length ? 'Captures, PDF, logs, documents…' : (files.length===1 ? files[0].name : files.length + ' fichiers sélectionnés');
    };
    ticketFiles?.addEventListener('change', updateFileSummary);

    const updateDestinationSummary = () => {
      const selected=$$('input[name="remote_targets[]"]:checked', win);
      const labels=selected.map(el=>el.getAttribute('data-destination-label') || el.value).filter(Boolean);
      const summary=$('[data-destination-summary]', win);
      if(summary) summary.textContent = labels.length ? labels.join(' + ') : 'Interne uniquement';
    };
    const updateShareSummary = () => {
      const all=$('[data-share-all]', win);
      const users=$$('[data-share-user]:checked', win);
      const roles=$$('[data-share-role]:checked', win);
      const summary=$('[data-share-summary]', win);
      if(summary){
        if(all?.checked) summary.textContent='Tous les utilisateurs';
        else if(!users.length && !roles.length) summary.textContent='Privé';
        else {
          const parts=[];
          if(users.length) parts.push(users.length + ' utilisateur' + (users.length>1?'s':''));
          if(roles.length) parts.push(roles.length + ' rôle' + (roles.length>1?'s':''));
          summary.textContent=parts.join(' + ');
        }
      }
      const userCount=$('[data-share-user-count]', win); if(userCount) userCount.textContent=String(users.length);
      const roleCount=$('[data-share-role-count]', win); if(roleCount) roleCount.textContent=String(roles.length);
      const disabled=!!all?.checked;
      $$('[data-share-user], [data-share-role]', win).forEach(el=>{ el.disabled=disabled; });
      $('[data-share-browser]', win)?.classList.toggle('is-disabled',disabled);
      if(shareFilter) shareFilter.disabled=disabled;
    };
    $$('input[name="remote_targets[]"]', win).forEach(el=>el.addEventListener('change', updateDestinationSummary));
    $$('[data-share-all], [data-share-user], [data-share-role]', win).forEach(el=>el.addEventListener('change', updateShareSummary));
    updateDestinationSummary();
    updateShareSummary();

    $('[data-new-form]', win).onsubmit = async e => {
      e.preventDefault();
      const f = e.currentTarget;
      const msg = $('[data-msg]', win);
      const submit = f.querySelector('button[type="submit"]');
      msg.textContent = 'Création du ticket...';
      if(submit) submit.disabled = true;

      try {
        const r = await api('create', {
          title: f.title.value,
          category: f.category.value,
          priority: f.priority.value,
          message: f.message.value,
          remote_targets: $$('input[name="remote_targets[]"]:checked', f).map(el=>el.value),
          share: collectShare(win)
        });

        if(!r?.ok){
          msg.textContent = r?.err || 'Erreur lors de la création.';
          return;
        }

        const upload = await uploadFiles(r.id, f.files);
        if(!upload?.ok){
          msg.textContent = upload?.err || 'Le ticket est créé, mais les pièces jointes n’ont pas été enregistrées.';
          return;
        }

        if(f.files.files.length){
          const syncResult = await api('sync', {id:r.id});
          if(!syncResult?.ok){
            msg.textContent = syncResult?.err || 'Le ticket est créé localement, mais la synchronisation a échoué.';
          }
        }

        msg.textContent = 'Ticket créé.';
        if(window.DMDMyDesk?.notify){
          window.DMDMyDesk.notify('DMD-Ticketing', 'Ticket créé : ' + (f.title.value || r.id), 'dmd-ticketing');
        }
        await load();
        removeWindow(win);
      } finally {
        if(submit) submit.disabled = false;
      }
    };
  }
  function attachmentUrl(a){
    const local = String(a?.local_url || '').trim();
    const url = String(a?.url || '').trim();
    const central = String(a?.central_url || a?.remote_url || '').trim();

    /* Une copie locale doit toujours être prioritaire. Les synchronisations
       conservent volontairement l'URL distante en secours, mais elle ne doit
       jamais remplacer une PJ déjà rapatriée dans ce DoMyDesk. */
    const raw = local || url || central;

    if(!raw) return '#';
    if(/^https?:\/\//i.test(raw)) return raw;

    /*
     * Les fichiers centralisés sont renvoyés sous la forme /ticket_files/...
     * Sans domaine, le navigateur les cherchait sur le DoMyDesk courant.
     */
    if(raw.startsWith('/ticket_files/')){
      return 'https://register.synohomes.com' + raw;
    }
    if(raw.startsWith('ticket_files/')){
      return 'https://register.synohomes.com/' + raw;
    }

    return raw;
  }
  function isImageAttachment(a){
    const name = String(a?.name || '').trim();
    const raw = String(a?.local_url || a?.url || a?.central_url || '').trim();
    const candidate = name || raw.split('?')[0];
    return /\.(?:jpe?g|png|gif|webp)$/i.test(candidate);
  }
  function openImagePreview(name, url){
    const safeName = String(name || 'Image');
    const safeUrl = String(url || '').trim();
    if(!safeUrl) return;

    const html = `<div class="tk-image-preview">
      <div class="tk-image-preview-stage">
        <img src="${h(safeUrl)}" alt="${h(safeName)}" data-image-preview>
        <div class="tk-image-preview-error" data-image-error hidden>Impossible d’afficher cette image.</div>
      </div>
      <div class="tk-image-preview-caption">${h(safeName)}</div>
    </div>`;

    const win = windowShell('Aperçu image', safeName, html, 1040, 780);
    win.classList.add('tk-image-window');
    const reload = $('[data-reload]', win);
    if(reload) reload.remove();
    const img = $('[data-image-preview]', win);
    const err = $('[data-image-error]', win);
    if(img){
      img.addEventListener('error', () => {
        img.hidden = true;
        if(err) err.hidden = false;
      });
    }
  }
  function bindAttachmentPreviews(scope){
    $$('[data-attachment-image]', scope).forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        e.stopPropagation();
        openImagePreview(link.dataset.attachmentName || 'Image', link.dataset.attachmentUrl || link.href);
      });
    });
  }
  function attachments(list){
    if(!Array.isArray(list) || !list.length) return '';
    return `<ul class="tk-attachments">${list.map(a=>{
      const url = attachmentUrl(a);
      const name = a?.name || 'fichier';
      if(isImageAttachment(a)){
        return `<li><a href="${h(url)}" class="tk-attachment-image" data-attachment-image data-attachment-name="${h(name)}" data-attachment-url="${h(url)}">🖼️ ${h(name)}</a></li>`;
      }
      return `<li><a href="${h(url)}" target="_blank" rel="noopener">📎 ${h(name)}</a></li>`;
    }).join('')}</ul>`;
  }
  async function openTicket(id){
    const r = await api('get', {id});
    if(!r?.ok){ alert(r?.err || 'Ticket introuvable'); return; }
    const t = r.item;

    const messages = (t.messages || []).map(m => {
      const fromRemote = m.role === 'domydesk';
      const fromExternalRequester = m.role === 'external_requester';
      const remoteLabel = messageRemoteName(m,t);
      const forwardedDomyco = fromRemote && String(m?.origin_target || '') === 'domyco' && remoteTarget(t) === 'support';
      const remoteOrigin = forwardedDomyco ? ('DoMyCo via ' + remoteName(t)) : ('Support ' + remoteLabel);
      return `<article class="tk-view-message ${fromRemote ? 'is-domyco' : 'is-local'}">
        <div class="tk-view-message-icon" aria-hidden="true">${fromRemote ? '🛠️' : '👤'}</div>
        <div class="tk-view-message-content">
          <div class="tk-view-message-head">
            <div>
              <strong>${h(m.by || (fromRemote ? remoteLabel : 'Utilisateur'))}</strong>
              ${fromRemote ? '<span class="tk-view-origin">' + h(remoteOrigin) + '</span>' : (fromExternalRequester ? '<span class="tk-view-origin">Client externe</span>' : '<span class="tk-view-origin">Message local</span>')}
            </div>
            <time>${fmt(m.at)}</time>
          </div>
          <div class="tk-view-message-text">${nl(m.text || '')}</div>
          ${attachments(m.attachments)}
        </div>
      </article>`;
    }).join('') || '<div class="tk-empty">Aucun message.</div>';

    const html = `<div class="tk-view-page">
      <section class="tk-view-overview">
        <div class="tk-view-summary">
          <span class="tk-view-kicker">TICKET ${h(t.id)}</span>
          <h3>${h(t.title || '(sans titre)')}</h3>
          <div class="tk-view-meta">
            <span><b>Créé par</b>${h(displayOwner(t))}</span>
            <span><b>Créé le</b>${fmt(t.created_at)}</span>
            <span><b>Mis à jour</b>${fmt(t.updated_at || t.created_at)}</span>
          </div>
          <div class="tk-view-badges">
            ${badge(statusLabel(t.status), statusClass(t.status))}
            ${badge(t.category)}
            ${badge(t.priority)}
            ${badge(shareText(t),'tk-badge-shared')}
            ${domydeskBadge(t)}
            ${escalationBadge(t)}
            ${notificationInfo(t).unread ? badge(notificationInfo(t).label, 'tk-badge-notification') : ''}
          </div>
        </div>

        <aside class="tk-view-control-panel">
          ${t.can_status ? `<div class="tk-field tk-view-status-field">
            <label>Statut du ticket</label>
            <select class="tk-input" data-ticket-status>${statusOptions(t.status)}</select>
          </div>` : `<div class="tk-view-status-readonly"><span>Statut actuel</span><strong>${h(statusLabel(t.status))}</strong></div>`}

          <div class="tk-view-actions">
            ${t.can_status ? '<button type="button" class="tk-btn tk-btn-primary" data-status-save>Statut</button><button type="button" class="tk-btn" data-toggle>' + (t.status === 'closed' ? 'Rouvrir' : 'Fermer') + '</button>' : ''}
            ${t.can_manage ? '<button type="button" class="tk-btn" data-share-open>Partager</button>' : ''}
            ${t.can_escalate && isExternalTicket(t) && !isEscalatedToDomyco(t) ? '<button type="button" class="tk-btn" data-escalate-domyco>↗ DoMyCo</button>' : ''}
            ${t?.meta?.domydesk?.requested || t.send_to_domydesk ? '<button type="button" class="tk-btn" data-sync>Synchroniser</button>' : ''}
            ${t.can_delete ? '<button type="button" class="tk-btn tk-btn-danger" data-delete>Supprimer</button>' : ''}
          </div>
        </aside>
      </section>

      ${workflowHtml(t)}

      <section class="tk-view-conversation">
        <div class="tk-view-section-head">
          <div>
            <span class="tk-view-section-kicker">ÉCHANGES</span>
            <h4>Conversation</h4>
          </div>
          <span class="tk-view-count">${(t.messages || []).length} message(s)</span>
        </div>
        <div class="tk-view-thread">${messages}</div>
      </section>

      <form class="tk-view-reply" data-reply-form>
        <div class="tk-view-section-head">
          <div>
            <span class="tk-view-section-kicker">RÉPONDRE</span>
            <h4>Ajouter un message</h4>
          </div>
        </div>

        <div class="tk-view-reply-grid">
          <div class="tk-field tk-view-reply-message">
            <label>Votre réponse</label>
            <textarea class="tk-input" name="message" ${t.status === 'closed' ? 'disabled' : ''} placeholder="${t.status === 'closed' ? 'Ticket fermé : rouvre-le pour répondre.' : 'Écrivez votre réponse ici…'}"></textarea>
          </div>
          <div class="tk-field tk-view-reply-files">
            <label>Pièces jointes</label>
            <div class="tk-view-file-box">
              <span class="tk-view-file-icon" aria-hidden="true">📎</span>
              <div>
                <strong>Ajouter des fichiers</strong>
                <small>Images, PDF, documents ou diagnostics.</small>
              </div>
              <input type="file" class="tk-input" name="files" multiple ${t.status === 'closed' ? 'disabled' : ''}>
            </div>
          </div>
        </div>

        ${isEscalatedToDomyco(t) ? '<div class="tk-hint">Ce ticket est escaladé vers DoMyCo. Les nouvelles réponses du Client et du Support sont synchronisées vers DoMyCo et restent visibles dans toute la chaîne.</div>' : ''}
        <div class="tk-view-reply-footer">
          <div class="tk-msg" data-msg></div>
          <button type="submit" class="tk-btn tk-btn-primary" ${t.status === 'closed' ? 'disabled' : ''}>Envoyer la réponse</button>
        </div>
      </form>

      ${t.can_manage ? `<form class="tk-view-share-panel" data-share-panel style="display:none">
        <div class="tk-view-section-head">
          <div>
            <span class="tk-view-section-kicker">ACCÈS</span>
            <h4>Partage du ticket</h4>
          </div>
        </div>
        <div class="tk-form-grid">${shareForm(t.share || {})}</div>
        <div class="tk-view-reply-footer">
          <div class="tk-msg" data-share-msg></div>
          <button type="submit" class="tk-btn tk-btn-primary">Enregistrer le partage</button>
        </div>
      </form>` : ''}
    </div>`;

    const win = windowShell(t.title || 'Ticket', t.id, html, 840, 560);
    win.classList.add('tk-ticket-window');

    // Poignée de redimensionnement visible : la fenêtre ticket doit rester aussi
    // manipulable que la fenêtre de création, sans dépendre du resize natif du navigateur.
    const ticketResizeHandle=document.createElement('span');
    ticketResizeHandle.className='tk-window-resize-handle tk-ticket-resize-handle';
    ticketResizeHandle.setAttribute('aria-hidden','true');
    win.appendChild(ticketResizeHandle);
    makeResizable(win, ticketResizeHandle);

    // Le responsive suit la taille réelle de LA FENÊTRE. Ainsi, sur un grand écran,
    // réduire le ticket réorganise quand même son contenu au lieu de créer un scroll horizontal.
    const updateTicketLayout=()=>{
      const r=win.getBoundingClientRect();
      win.classList.toggle('tk-ticket-narrow', r.width < 700);
      win.classList.toggle('tk-ticket-small', r.width < 560);
      win.classList.toggle('tk-ticket-tiny', r.width < 440);
      win.classList.toggle('tk-ticket-short', r.height < 500);
    };
    updateTicketLayout();
    const ticketResizeObserver=('ResizeObserver' in window) ? new ResizeObserver(()=>updateTicketLayout()) : null;
    ticketResizeObserver?.observe(win);

    win.setAttribute('data-dmd-context-type', 'ticket');
    win.setAttribute('data-dmd-context-id', String(t.id || ''));
    win.setAttribute('data-ticket-updated-at', String(t.updated_at || t.created_at || ''));
    win.setAttribute('data-ticket-message-count', String(Array.isArray(t.messages) ? t.messages.length : 0));
    bindAttachmentPreviews(win);
    if(window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') window.DMDActionHub.decorate(win);
    if(notificationInfo(t).unread){
      setTimeout(async () => {
        try { await api('mark_read', {id:t.id}); await load(); } catch (_) {}
      }, 500);
    }
    $('[data-reload]', win).onclick = () => { removeWindow(win); openTicket(id); };
    const shareOpen = $('[data-share-open]', win); if(shareOpen) shareOpen.onclick = () => { const p = $('[data-share-panel]', win); p.style.display = p.style.display === 'none' ? '' : 'none'; p.scrollIntoView({behavior:'smooth', block:'nearest'}); };
    const statusSave = $('[data-status-save]', win); if(statusSave) statusSave.onclick = async () => { const rr=await api('update', {id:t.id, status:$('[data-ticket-status]', win).value}); if(!rr?.ok){ alert(rr?.err || 'Erreur.'); return; } await load(); removeWindow(win); openTicket(id); };
    const toggle = $('[data-toggle]', win); if(toggle) toggle.onclick = async () => { const rr=await api(t.status === 'closed' ? 'reopen' : 'close', {id:t.id}); if(!rr?.ok){ alert(rr?.err || 'Erreur.'); return; } await load(); removeWindow(win); openTicket(id); };
    const escalate = $('[data-escalate-domyco]', win); if(escalate) escalate.onclick = async () => {
      if(!confirm('Escalader ce ticket client vers DoMyCo avec tout son historique et ses pièces jointes ?')) return;
      escalate.disabled=true;
      const previous=escalate.textContent;
      escalate.textContent='Escalade vers DoMyCo...';
      const rr=await api('escalate_domyco',{id:t.id});
      if(!rr?.ok){
        alert(rr?.message || rr?.err || 'Impossible d’escalader le ticket vers DoMyCo.');
        escalate.disabled=false;
        escalate.textContent=previous;
        return;
      }
      if(rr?.result?.status==='pending'){
        alert('Le ticket est marqué pour escalade. DoMyCo n’a pas confirmé la réception immédiatement ; la synchronisation reste en attente et sera retentée.');
      }
      await load(); removeWindow(win); openTicket(id);
    };
    const sync = $('[data-sync]', win); if(sync) sync.onclick = async () => { sync.disabled=true; sync.textContent='Synchronisation...'; const rr=await api('sync',{id:t.id}); if(!rr?.ok){ alert(rr?.err || 'Erreur de synchronisation.'); } await load(); removeWindow(win); openTicket(id); };
    const del = $('[data-delete]', win); if(del) del.onclick = async () => { if(!confirm('Supprimer définitivement ce ticket ?')) return; const rr=await api('delete', {id:t.id}); if(!rr?.ok){ alert(rr?.err || 'Erreur.'); return; } await load(); removeWindow(win); };

    const timeStart=$('[data-time-start]',win); if(timeStart) timeStart.onclick=async()=>{ timeStart.disabled=true; const rr=await api('time_start',{id:t.id,note:$('[data-time-note]',win)?.value||''}); if(!rr?.ok) alert(rr?.err||'Chrono impossible'); await load(); removeWindow(win); openTicket(id); };
    const timeStop=$('[data-time-stop]',win); if(timeStop) timeStop.onclick=async()=>{ timeStop.disabled=true; const rr=await api('time_stop',{id:t.id,note:$('[data-time-note]',win)?.value||''}); if(!rr?.ok) alert(rr?.err||'Arrêt du chrono impossible'); await load(); removeWindow(win); openTicket(id); };
    const timeAdd=$('[data-time-add]',win); if(timeAdd) timeAdd.onclick=async()=>{ const minutes=Number($('[data-time-minutes]',win)?.value||0); if(minutes<1){ alert('Indique un nombre de minutes.'); return; } timeAdd.disabled=true; const rr=await api('time_add',{id:t.id,minutes,note:$('[data-time-note]',win)?.value||''}); if(!rr?.ok) alert(rr?.err||'Ajout impossible'); await load(); removeWindow(win); openTicket(id); };
    const requestClosure=$('[data-request-closure]',win); if(requestClosure) requestClosure.onclick=async()=>{ if(!confirm('Passer le ticket en Résolu et demander au client de confirmer la clôture ?')) return; requestClosure.disabled=true; const rr=await api('request_closure',{id:t.id}); if(!rr?.ok) alert(rr?.message||rr?.err||'Validation impossible'); await load(); removeWindow(win); openTicket(id); };
    const closureRespond=async decision=>{ const closure=workflowOf(t).closure||{}; const comment=$('[data-closure-comment]',win)?.value||''; const rr=await api('closure_respond',{id:t.id,decision,request_id:closure.request_id||'',comment}); if(!rr?.ok){ alert(rr?.err||'Réponse impossible'); return; } await load(); removeWindow(win); openTicket(id); };
    const closureAccept=$('[data-closure-accept]',win); if(closureAccept) closureAccept.onclick=()=>closureRespond('accepted');
    const closureReject=$('[data-closure-reject]',win); if(closureReject) closureReject.onclick=()=>closureRespond('rejected');
    const incidentCreate=$('[data-incident-create]',win); if(incidentCreate) incidentCreate.onclick=async()=>{ const title=$('[data-incident-title]',win)?.value.trim()||''; if(!title){alert('Indique un nom d’incident.');return;} incidentCreate.disabled=true; const rr=await api('incident_create',{id:t.id,title}); if(!rr?.ok) alert(rr?.err||'Création impossible'); await load(); removeWindow(win); openTicket(id); };
    const incidentLink=$('[data-incident-link]',win); if(incidentLink) incidentLink.onclick=async()=>{ const incident_id=$('[data-incident-select]',win)?.value||''; if(!incident_id){alert('Choisis un incident.');return;} const rr=await api('incident_link',{id:t.id,incident_id}); if(!rr?.ok) alert(rr?.err||'Liaison impossible'); await load(); removeWindow(win); openTicket(id); };
    const incidentUnlink=$('[data-incident-unlink]',win); if(incidentUnlink) incidentUnlink.onclick=async()=>{ const rr=await api('incident_unlink',{id:t.id}); if(!rr?.ok) alert(rr?.err||'Déliaison impossible'); await load(); removeWindow(win); openTicket(id); };
    const incidentStatus=$('[data-incident-status]',win); if(incidentStatus) incidentStatus.onclick=async()=>{ const inc=workflowOf(t).incident||{}; const rr=await api('incident_status',{id:t.id,status:inc.status==='closed'?'open':'closed'}); if(!rr?.ok) alert(rr?.err||'Modification impossible'); await load(); removeWindow(win); openTicket(id); };
    $$('[data-related-ticket]',win).forEach(btn=>btn.onclick=()=>{ const related=btn.dataset.relatedTicket; if(!related)return; removeWindow(win); openTicket(related); });

    $('[data-reply-form]', win).onsubmit = async e => {
      e.preventDefault(); const f=e.currentTarget; const msg=$('[data-msg]', win); msg.textContent='Envoi...';
      let replyResult = null;
      if(f.message.value.trim()){
        replyResult=await api('reply', {id:t.id, message:f.message.value});
        if(!replyResult?.ok){ msg.textContent=replyResult?.err||'Erreur.'; return; }
      }
      let syncResult = replyResult?.domydesk || null;
      if(f.files.files.length){
        const ur=await uploadFiles(t.id, f.files);
        if(!ur?.ok){ msg.textContent=ur?.err||'Erreur upload.'; return; }
        const sr=await api('sync', {id:t.id});
        if(!sr?.ok){ msg.textContent=sr?.err||'Erreur de synchronisation.'; return; }
        syncResult=sr?.result || sr?.domydesk || syncResult;
      }
      if((t?.meta?.domydesk?.requested || t.send_to_domydesk) && syncResult?.status === 'pending'){
        alert('La réponse est enregistrée localement. ' + remoteName(t) + ' n’a pas confirmé la réception immédiatement : la synchronisation reste en attente et sera retentée automatiquement.');
      }
      await load(); removeWindow(win); openTicket(id);
    };
    const sharePanel = $('[data-share-panel]', win); if(sharePanel) sharePanel.onsubmit = async e => {
      e.preventDefault(); const sm=$('[data-share-msg]', win); sm.textContent='Enregistrement...';
      const rr=await api('update', {id:t.id, share:collectShare(win)}); sm.textContent = rr?.ok ? 'Partage enregistré.' : (rr?.err || 'Erreur.'); if(rr?.ok) await load();
    };
  }

  $('[data-new]').onclick = openNew;
  $('[data-refresh]').onclick = refreshAll;
  $('[data-clear]').onclick = () => { $$('[data-filter]').forEach(el => { if(el.tagName === 'INPUT') el.value=''; else if(el.dataset.filter==='status') el.value='all'; else if(el.dataset.filter==='scope') el.value='visible'; else el.value=''; }); load(); };
  $$('[data-filter]').forEach(el => el.addEventListener(el.tagName === 'INPUT' ? 'input' : 'change', () => { clearTimeout(state.timer); state.timer=setTimeout(load, el.tagName === 'INPUT' ? 250 : 0); }));
  window.addEventListener('resize', () => requestAnimationFrame(recalcWorkspace));
  initWorkspaceBase();
  (async()=>{
    const b = await refreshBootstrap();
    if(!b?.ok){ $('[data-list]').innerHTML='<div class="tk-empty">Erreur initialisation.</div>'; return; }
    const newBtn=$('[data-new]');
    if(newBtn && b.permissions && !b.permissions.create){ newBtn.disabled=true; newBtn.title='Création de ticket non autorisée'; }
    await load();
    startAutomaticSync();
    setTimeout(silentSync, 1500);
  })();
})();
</script>
