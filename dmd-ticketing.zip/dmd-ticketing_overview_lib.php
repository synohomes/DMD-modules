<?php
/* DMD-Ticketing — ACL explicite de la page de supervision. PHP 8.0. */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';

if (!function_exists('dmdtk_ov_acl_file')) {
    function dmdtk_ov_acl_file() {
        return dmdtk_system_root(true) . '/overview_acl.json';
    }
}
if (!function_exists('dmdtk_ov_acl')) {
    function dmdtk_ov_acl() {
        $v = dmdtk_read_json(dmdtk_ov_acl_file(), array());
        $users = isset($v['users']) && is_array($v['users']) ? $v['users'] : array();
        return array('version' => 1, 'users' => $users);
    }
}
if (!function_exists('dmdtk_ov_key')) {
    function dmdtk_ov_key($email) {
        return strtolower(trim((string)$email));
    }
}
if (!function_exists('dmdtk_ov_can')) {
    function dmdtk_ov_can($email, $right = 'access') {
        if ($email === '' || !dmdtk_has_module_access($email)) return false;
        if (!in_array($right, array('access', 'all'), true)) return false;
        $acl = dmdtk_ov_acl();
        $key = dmdtk_ov_key($email);
        $row = isset($acl['users'][$key]) && is_array($acl['users'][$key]) ? $acl['users'][$key] : array();
        // Les permissions "*" héritées de default_access=everyone ne peuvent pas
        // ouvrir une page confidentielle : seuls les droits explicitement attribués le font.
        return !empty($row['access']) && ($right === 'access' || !empty($row['all']));
    }
}
if (!function_exists('dmdtk_ov_is_manager')) {
    function dmdtk_ov_is_manager($email) {
        return $email !== '' && dmdtk_has_module_access($email) && dmdtk_is_admin($email);
    }
}
if (!function_exists('dmdtk_ov_users')) {
    function dmdtk_ov_users() {
        $res = array();
        $base = dmdtk_profiles_root();
        foreach ((array)@scandir($base) as $name) {
            if ($name === '.' || $name === '..' || strpos($name, '/') !== false || strpos($name, '\\') !== false || !is_dir($base . '/' . $name)) continue;
            $profile = dmdtk_profile($name);
            $email = trim((string)(isset($profile['email']) ? $profile['email'] : $name));
            if ($email === '') continue;
            $key = dmdtk_ov_key($email);
            $res[$key] = array('email' => $email, 'name' => trim((string)($profile['prenom'] ?? $profile['first_name'] ?? '')) . ' ' . trim((string)($profile['nom'] ?? $profile['last_name'] ?? '')), 'role' => dmdtk_system_role($email));
            $res[$key]['name'] = trim($res[$key]['name']);
        }
        uasort($res, function($a,$b) { return strcasecmp($a['email'], $b['email']); });
        return $res;
    }
}
if (!function_exists('dmdtk_ov_ticket_visible')) {
    function dmdtk_ov_ticket_visible($ticket, $email, $all) {
        if ($all) return true;
        if ((string)($ticket['owner'] ?? '') === $email) return true;
        $share = isset($ticket['share']) && is_array($ticket['share']) ? $ticket['share'] : array();
        if (!empty($share['all'])) return true;
        if (in_array($email, (array)($share['users'] ?? array()), true)) return true;
        $role = dmdtk_user_role_metier($email);
        return $role !== '' && in_array($role, (array)($share['roles'] ?? array()), true);
    }
}
if (!function_exists('dmdtk_ov_require')) {
    function dmdtk_ov_require($manager = false) {
        $email = dmdtk_user_email();
        if ($email === '') { http_response_code(401); exit('Authentification requise.'); }
        if ($manager ? !dmdtk_ov_is_manager($email) : !dmdtk_ov_can($email)) {
            http_response_code(403); exit('Accès à la supervision Ticketing refusé.');
        }
        return $email;
    }
}
