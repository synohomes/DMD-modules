<?php
/* * =====================================================================
                                DoMyDesk
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
*
Ce fichier fait partie du logiciel DoMyDesk.
*
Toute reproduction, redistribution, revente, publication ou
intégration de tout ou partie de ce code dans un autre produit
sans autorisation préalable de SynoHomes est interdite.
*
La modification du logiciel dans le cadre de son utilisation
*
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0
*
Éditeur : SynoHomes

* * ===================================================================== * */
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=300');
error_reporting(0);

$cfg = dmdtk_config();
$receive = isset($cfg['external_receive']) && is_array($cfg['external_receive']) ? $cfg['external_receive'] : array();
$token = trim((string)($receive['token'] ?? ''));
$ticketId = preg_replace('~[^A-Za-z0-9._-]+~', '', (string)($_GET['ticket'] ?? ''));
$stored = basename((string)($_GET['file'] ?? ''));
$sig = trim((string)($_GET['sig'] ?? ''));

if (empty($receive['enabled']) || $token === '' || $ticketId === '' || $stored === '' || $sig === '') { http_response_code(404); exit; }
$expected = hash_hmac('sha256', $ticketId . '|' . $stored, $token);
if (!hash_equals($expected, $sig)) { http_response_code(403); exit; }

list($ticket) = dmdtk_ticket_read($ticketId);
if (!is_array($ticket) || !$ticket || empty($ticket['meta']['external'])) { http_response_code(404); exit; }
$sourceInstance = trim((string)($ticket['meta']['external']['source_instance_uid'] ?? ''));
if ($sourceInstance === '' || !dmdtk_external_client_is_active($sourceInstance)) { http_response_code(403); exit; }
$allowed = false;
$matchedAttachment = null;
$downloadName = $stored;
foreach ((array)($ticket['messages'] ?? array()) as $message) {
    if (!is_array($message) || (string)($message['role'] ?? '') === 'external_requester') continue;
    foreach ((array)($message['attachments'] ?? array()) as $attachment) {
        if (!is_array($attachment) || basename((string)($attachment['stored_name'] ?? '')) !== $stored) continue;
        $allowed = true;
        $matchedAttachment = $attachment;
        $downloadName = trim((string)($attachment['name'] ?? $stored));
        break 2;
    }
}
if (!$allowed) { http_response_code(404); exit; }

$file = dmdtk_attachment_file_path($ticket, $matchedAttachment, $stored);
if ($file === '') { http_response_code(404); exit; }

$mime = function_exists('mime_content_type') ? (string)@mime_content_type($file) : 'application/octet-stream';
if ($mime === '') $mime = 'application/octet-stream';
header('Content-Type: ' . $mime);
header('Content-Length: ' . (string)filesize($file));
header("Content-Disposition: inline; filename*=UTF-8''" . rawurlencode($downloadName !== '' ? $downloadName : $stored));
readfile($file);
