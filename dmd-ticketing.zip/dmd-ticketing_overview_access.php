<?php
/* Attribution nominative et explicite des droits de supervision. */
require_once __DIR__ . '/dmd-ticketing_overview_lib.php';
$me = dmdtk_ov_require(true);
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');
$users = dmdtk_ov_users();
$acl = dmdtk_ov_acl();
$msg = '';
$ok = false;
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (!dmdtk_csrf_valid((string)($_POST['csrf'] ?? ''))) {
        http_response_code(403);
        $msg = 'Session du formulaire expirée. Rechargez la page.';
    } else {
        $access = isset($_POST['access']) && is_array($_POST['access']) ? $_POST['access'] : array();
        $all = isset($_POST['all']) && is_array($_POST['all']) ? $_POST['all'] : array();
        $next = array('version'=>1,'users'=>array());
        foreach ($users as $key => $u) {
            if (!array_key_exists($key, $access)) continue;
            $next['users'][$key] = array('access'=>true, 'all'=>array_key_exists($key, $all));
        }
        if (dmdtk_write_json(dmdtk_ov_acl_file(), $next)) {
            dmdtk_log($me, 'overview_acl_update', 'overview', 'success', array('granted'=>count($next['users']), 'full_access'=>count(array_filter($next['users'],function($a){return !empty($a['all']);}))));
            $acl = $next;
            $msg = 'Droits enregistrés.';
            $ok = true;
        } else {
            http_response_code(500);
            $msg = 'Échec de l’enregistrement. Vérifiez les droits d’écriture de data/modules/dmd-ticketing.';
        }
    }
}
function dmdtk_ov_e($value){return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');}
$cssV = @filemtime(__DIR__.'/dmd-ticketing_overview.css') ?: 1;
$embed = isset($_GET['embed']) && (string)$_GET['embed'] === '1';
if ($embed) {
    ?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><base href="../../"><link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing_overview.css?v=<?= (int)$cssV ?>"></head><body class="dmd-ov-embed-body"><?php
} else {
    ob_start();
    require dmdtk_root() . '/header.php';
    $dmdHeaderHtml = (string)ob_get_clean();
    $dmdAssets = '<base href="../../">' . "\n" . '<link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing_overview.css?v=' . (int)$cssV . '">';
    $dmdHeadPos = stripos($dmdHeaderHtml, '</head>');
    if ($dmdHeadPos !== false) echo substr_replace($dmdHeaderHtml, $dmdAssets . "\n", $dmdHeadPos, 0);
    else { echo $dmdHeaderHtml; echo $dmdAssets; }
    unset($dmdHeaderHtml, $dmdAssets, $dmdHeadPos);
}
?>
<div class="dmd-ov-page dmd-ov-acl-page<?= $embed ? ' dmd-ov-embed' : '' ?>" aria-label="DMD-Ticketing — Gestion des droits">
<main class="ov-acl-main">
 <div class="ov-acl-header"><div><h1>Droits — Vue d'ensemble</h1><p>Attribuer l'accès à l'interface globale du Ticketing, indépendamment du statut administrateur.</p></div><?php if(!$embed): ?><div class="ov-acl-actions"><a href="dashboard.php" class="ov-btn">DoMyDesk</a><?php if(dmdtk_ov_can($me)): ?><a class="ov-btn" href="modules/dmd-ticketing/dmd-ticketing_overview.php">Vue d'ensemble</a><?php endif; ?></div><?php endif; ?></div>
 <div class="ov-acl-help">Aucun utilisateur n'a accès par défaut. Cochez <b>Interface</b> pour afficher le bouton dans le module et autoriser l'ouverture de cette page. Cochez <b>Tous les tickets</b> pour permettre la supervision de tous les tickets, y compris ceux non partagés. Sans ce second droit, seuls les tickets appartenant à l'utilisateur ou partagés avec lui sont visibles. <b>Ces autorisations s'appliquent également aux administrateurs.</b></div>
 <?php if($msg): ?><div class="ov-acl-alert<?= $ok?'':' is-error' ?>"><?= dmdtk_ov_e($msg) ?></div><?php endif; ?>
 <form method="post" id="ov-acl-form"><input type="hidden" name="csrf" value="<?= dmdtk_ov_e(dmdtk_csrf_token()) ?>">
 <div class="ov-acl-tools"><input class="ov-acl-filter" type="search" placeholder="Filtrer les comptes..." aria-label="Filtrer les utilisateurs" id="ov-acl-filter"><span id="ov-acl-n" class="ov-muted"><?= count($users) ?> comptes</span></div>
 <div class="ov-acl-panel"><div class="ov-acl-table-wrap"><table class="ov-acl-table"><thead><tr><th>Utilisateur</th><th>Interface</th><th>Tous les tickets</th></tr></thead><tbody>
 <?php foreach($users as $key=>$u): $right=isset($acl['users'][$key])&&is_array($acl['users'][$key])?$acl['users'][$key]:array(); ?>
  <tr data-account="<?= dmdtk_ov_e(strtolower($u['email'].' '.$u['name'])) ?>"><td><b><?= dmdtk_ov_e($u['email']) ?></b><small><?= dmdtk_ov_e($u['name']!==''?$u['name']:'Utilisateur') ?> · <?= dmdtk_ov_e($u['role']) ?></small></td><td><input class="ov-access" type="checkbox" name="access[<?= dmdtk_ov_e($key) ?>]" value="1" <?= !empty($right['access'])?'checked':'' ?> aria-label="Accès interface <?= dmdtk_ov_e($u['email']) ?>"></td><td><input class="ov-all" type="checkbox" name="all[<?= dmdtk_ov_e($key) ?>]" value="1" <?= !empty($right['all'])?'checked':'' ?> <?= empty($right['access'])?'disabled':'' ?> aria-label="Tous les tickets <?= dmdtk_ov_e($u['email']) ?>"></td></tr>
 <?php endforeach; ?>
 </tbody></table></div><div class="ov-acl-foot"><small class="ov-muted">Droits stockés dans data/modules/dmd-ticketing/overview_acl.json — aucun changement du Core.</small><button class="ov-acl-btn" type="submit">Enregistrer les droits</button></div></div></form>
</main>
<script>
(()=>{const filter=document.querySelector('#ov-acl-filter'),rows=[...document.querySelectorAll('[data-account]')];filter.addEventListener('input',()=>{const q=filter.value.trim().toLocaleLowerCase();let n=0;rows.forEach(r=>{r.hidden=!r.dataset.account.includes(q);if(!r.hidden)n++;});document.querySelector('#ov-acl-n').textContent=n+' comptes';});rows.forEach(r=>{const a=r.querySelector('.ov-access'),all=r.querySelector('.ov-all');a.addEventListener('change',()=>{all.disabled=!a.checked;if(!a.checked)all.checked=false;});});})();
</script>
</div>
</body></html>
