<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
$root = dirname(__DIR__, 2);
$email = trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : ''));
if ($email === '') {
    http_response_code(401);
    ?><!doctype html><html lang="fr"><meta charset="utf-8"><title>DMD-MyDesk · DMD-Ticketing</title><body><p>Session MyDesk expirée. Fermez cette fenêtre puis relancez Tickets depuis DMD-MyDesk.</p></body></html><?php
    exit;
}
$theme = 'default';
$themeFile = $root . '/users/profiles/' . $email . '/theme.json';
if (is_file($themeFile)) {
    $d = json_decode((string)@file_get_contents($themeFile), true);
    if (is_array($d) && !empty($d['theme']) && is_file($root . '/theme/' . basename((string)$d['theme']) . '/style.css')) $theme = basename((string)$d['theme']);
}
$mydeskCssVersion = @filemtime(__DIR__.'/dmd-ticketing-mydesk.css') ?: time();
?>
<!doctype html>
<html lang="fr" data-dmd-context="mydesk" data-dmd-view="compact">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>DMD-MyDesk · Tickets</title>
<base href="../../">
<link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
<link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing-mydesk.css?v=<?= (int)$mydeskCssVersion ?>">
</head>
<body class="dmd-mydesk-module dmd-mydesk-ticketing dmd-mydesk-view-compact">
  <main class="tk-mydesk-quick" id="tk-mydesk-quick">
    <header class="tk-mydesk-quick-head">
      <div class="tk-mydesk-quick-title">
        <span class="tk-mydesk-quick-icon">🎫</span>
        <div>
          <strong>Nouveau ticket</strong>
          <small>DMD-Ticketing · création rapide</small>
        </div>
      </div>
      <div class="tk-mydesk-head-actions">
        <span class="tk-mydesk-quick-pc" data-pc hidden></span>
        <a class="tk-mydesk-open-full"
         href="dashboard.php?mydesk_open=dmd-ticketing"
         target="_blank"
         rel="noopener"
         title="Ouvrir DMD-Ticketing complet dans DoMyDesk"
         aria-label="Ouvrir DMD-Ticketing complet dans DoMyDesk">↗</a>
      </div>
    </header>

    <form class="tk-mydesk-quick-form" data-form>
      <label class="tk-mydesk-field">
        <span>Titre</span>
        <input type="text" name="title" maxlength="180" required autofocus placeholder="Ex. : Imprimante inaccessible">
      </label>

      <label class="tk-mydesk-field">
        <span>Description</span>
        <textarea name="message" required placeholder="Décrivez rapidement le problème..."></textarea>
      </label>

      <label class="tk-mydesk-drop" data-drop>
        <input type="file" name="files" multiple>
        <span class="tk-mydesk-drop-icon">📎</span>
        <span class="tk-mydesk-drop-copy"><strong>Pièces jointes</strong><small data-files>Cliquer ou déposer des fichiers</small></span>
      </label>

      <label class="tk-mydesk-sync">
        <input type="checkbox" name="send_to_domydesk">
        <span class="tk-mydesk-sync-toggle" aria-hidden="true"></span>
        <span><strong>Synchroniser avec DomyCo</strong><small>Transmettre au support central</small></span>
      </label>

      <div class="tk-mydesk-quick-footer">
        <span class="tk-mydesk-msg" data-msg></span>
        <button type="submit" class="tk-mydesk-submit">Créer</button>
      </div>
    </form>
  </main>
<script>
(() => {
  const root = document.getElementById('tk-mydesk-quick');
  const form = root.querySelector('[data-form]');
  const fileInput = form.elements.files;
  const fileLabel = root.querySelector('[data-files]');
  const msg = root.querySelector('[data-msg]');
  const submit = root.querySelector('[type="submit"]');
  const API = 'modules/dmd-ticketing/dmd-ticketing_api.php';
  const UPLOAD = 'modules/dmd-ticketing/dmd-ticketing_upload.php';
  let boot = null;

  const api = async (action, body={}) => {
    if (boot?.csrf && !body.csrf) body.csrf = boot.csrf;
    const r = await fetch(API + '?a=' + encodeURIComponent(action), {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
    return r.json();
  };
  const bootstrap = async () => {
    const r = await fetch(API + '?a=bootstrap', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'});
    boot = await r.json();
    if (!boot?.ok) throw new Error(boot?.err || 'Initialisation impossible.');
    if (boot.mydesk_context) {
      const pc = root.querySelector('[data-pc]');
      const host = boot.mydesk_context.hostname || 'Poste';
      const aid = boot.mydesk_context.agent_id || 'Agent';
      pc.textContent = host;
      pc.title = host + ' · ' + aid;
      pc.hidden = false;
    }
    if (!boot.permissions?.create) {
      submit.disabled = true; submit.title = 'Création de ticket non autorisée';
    }
    if (!boot.permissions?.sync) {
      form.elements.send_to_domydesk.disabled = true;
      form.elements.send_to_domydesk.checked = false;
      form.elements.send_to_domydesk.closest('.tk-mydesk-sync').title = 'Synchronisation DomyCo non autorisée';
    }
  };
  const updateFiles = () => {
    const files = Array.from(fileInput.files || []);
    fileLabel.textContent = files.length ? files.length + ' fichier(s)' : 'Cliquer ou déposer des fichiers';
  };
  const setDropped = files => {
    try {
      const dt = new DataTransfer();
      Array.from(fileInput.files || []).forEach(f => dt.items.add(f));
      Array.from(files || []).forEach(f => dt.items.add(f));
      fileInput.files = dt.files; updateFiles(); return true;
    } catch(e) { return false; }
  };
  const upload = async id => {
    if (!fileInput.files.length) return {ok:true};
    const fd = new FormData(); fd.append('ticket_id', id); if (boot?.csrf) fd.append('csrf', boot.csrf);
    Array.from(fileInput.files).forEach(f => fd.append('files[]', f));
    const r = await fetch(UPLOAD, {method:'POST', body:fd}); return r.json();
  };
  fileInput.addEventListener('change', updateFiles);
  window.addEventListener('dmd:mydesk-files', e => {
    const files = Array.from(e.detail?.files || []); if (!files.length) return;
    if (setDropped(files)) {
      const drop = root.querySelector('[data-drop]'); drop.classList.add('is-drop'); setTimeout(()=>drop.classList.remove('is-drop'),700);
    }
  });

  form.addEventListener('submit', async e => {
    e.preventDefault();
    submit.disabled = true; msg.className = 'tk-mydesk-msg'; msg.textContent = 'Création...';
    try {
      const title = form.elements.title.value;
      const create = await api('create', {
        title,
        message: form.elements.message.value,
        send_to_domydesk: form.elements.send_to_domydesk.checked,
        share: {all:false,users:[],roles:[]}
      });
      if (!create?.ok) throw new Error(create?.err || 'Création impossible.');
      const up = await upload(create.id);
      if (!up?.ok) throw new Error(up?.err || 'Ticket créé, mais pièces jointes non enregistrées.');
      let sync = create.domydesk || null;
      if (form.elements.send_to_domydesk.checked && fileInput.files.length) {
        const sr = await api('sync', {id:create.id});
        if (!sr?.ok) throw new Error(sr?.err || 'Ticket créé, synchronisation DomyCo en attente.');
        sync = sr.result || sr.domydesk || sync;
      }
      const pending = form.elements.send_to_domydesk.checked && sync?.status === 'pending';
      msg.className = 'tk-mydesk-msg ' + (pending ? 'is-warn' : 'is-ok');
      msg.textContent = pending ? 'Créé · DomyCo en attente' : (form.elements.send_to_domydesk.checked ? 'Créé · DomyCo OK' : 'Ticket créé');
      window.DMDMyDesk?.notify?.('DMD-Ticketing', msg.textContent + ' : ' + title, 'dmd-ticketing');
      form.reset(); updateFiles(); form.elements.title.focus();
    } catch(err) {
      msg.className = 'tk-mydesk-msg is-error'; msg.textContent = err?.message || 'Erreur.';
    } finally { submit.disabled = !boot?.permissions?.create; }
  });

  bootstrap().catch(err => { msg.className='tk-mydesk-msg is-error'; msg.textContent=err.message; submit.disabled=true; });
  const fitWindow = () => {
    const h = Math.max(310, Math.min(370, Math.ceil(document.documentElement.scrollHeight + 36)));
    window.DMDMyDesk?.resize?.(360,h,330,310);
  };
  setTimeout(fitWindow,40);
  setTimeout(fitWindow,220);
})();
</script>
</body>
</html>
