<?php
/* * =====================================================================
                                DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_overview_lib.php';
$root = dirname(__DIR__, 2);
$email = trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : ''));
if ($email === '') {
    http_response_code(401);
    ?><!doctype html><html lang="fr"><meta charset="utf-8"><title>DMD-MyDesk · DMD-Ticketing</title><body><p>Session MyDesk expirée. Fermez cette fenêtre puis relancez Tickets depuis DMD-MyDesk.</p></body></html><?php
    exit;
}
$theme = 'default';
$themeFile = $root . '/users/profiles/' . $email . '/theme.json';
if (is_file($themeFile)) {
    $d = json_decode((string)@file_get_contents($themeFile), true);
    if (is_array($d) && !empty($d['theme']) && is_file($root . '/theme/' . basename((string)$d['theme']) . '/style.css')) $theme = basename((string)$d['theme']);
}
$mydeskCssVersion = @filemtime(__DIR__.'/dmd-ticketing-mydesk.css') ?: time();
?>
<!doctype html>
<html lang="fr" data-dmd-context="mydesk" data-dmd-view="app">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>DMD-MyDesk · Tickets</title>
<base href="../../">
<link rel="stylesheet" href="theme/<?= htmlspecialchars($theme, ENT_QUOTES, 'UTF-8') ?>/style.css">
<link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing-mydesk.css?v=<?= (int)$mydeskCssVersion ?>">
</head>
<body class="dmd-mydesk-module dmd-mydesk-ticketing dmd-mydesk-view-app">
<main class="tk-app" id="tk-app">
  <header class="tk-app-head">
    <div class="tk-app-brand">
      <span class="tk-app-icon">🎫</span>
      <div>
        <strong>DMD-Ticketing</strong>
        <small data-subtitle>Tickets</small>
      </div>
    </div>
    <div class="tk-app-head-actions">
      <span class="tk-app-pc" data-pc hidden></span>
      <?php if (dmdtk_ov_can($email)): ?><a class="tk-icon-btn" href="modules/dmd-ticketing/dmd-ticketing_overview.php" target="_blank" rel="noopener noreferrer" title="Ouvrir la vue d’ensemble du Ticketing" aria-label="Vue d’ensemble Ticketing">▦</a><?php endif; ?>
      <?php if (dmdtk_ov_is_manager($email)): ?><a class="tk-icon-btn" href="modules/dmd-ticketing/dmd-ticketing_overview_access.php" target="_blank" rel="noopener noreferrer" title="Attribuer les droits de supervision" aria-label="Droits vue d’ensemble Ticketing">⚙</a><?php endif; ?>
      <button type="button" class="tk-icon-btn" data-refresh title="Actualiser">↻</button>
    </div>
  </header>

  <nav class="tk-tabs" aria-label="DMD-Ticketing">
    <button type="button" class="is-active" data-tab="tickets">Tickets <span data-unread hidden></span></button>
    <button type="button" data-tab="new">Nouveau</button>
  </nav>

  <section class="tk-view is-active" data-view="tickets">
    <div class="tk-toolbar">
      <select data-status aria-label="Filtrer par statut">
        <option value="all">Tous les statuts</option>
        <option value="open">Ouverts</option>
        <option value="in_progress">En cours</option>
        <option value="waiting">En attente</option>
        <option value="resolved">Résolus</option>
        <option value="closed">Fermés</option>
      </select>
      <input type="search" data-search placeholder="Rechercher…" aria-label="Rechercher un ticket">
    </div>
    <div class="tk-list" data-list><div class="tk-empty">Chargement…</div></div>
  </section>

  <section class="tk-view" data-view="new">
    <form class="tk-new-form" data-new-form>
      <label class="tk-field">
        <span>Titre</span>
        <input type="text" name="title" maxlength="180" required placeholder="Ex. : Imprimante inaccessible">
      </label>
      <label class="tk-field">
        <span>Description</span>
        <textarea name="message" required placeholder="Décrivez le problème…"></textarea>
      </label>
      <div class="tk-destinations" data-destinations></div>
      <label class="tk-drop" data-new-drop>
        <input type="file" name="files" multiple>
        <span>📎</span>
        <span><strong>Pièces jointes</strong><small data-new-files>Cliquer ou déposer des fichiers</small></span>
      </label>
      <div class="tk-form-foot">
        <span class="tk-msg" data-new-msg></span>
        <button type="submit" class="tk-primary" data-new-submit>Créer</button>
      </div>
    </form>
  </section>

  <section class="tk-detail" data-detail hidden aria-live="polite"></section>
  <section class="tk-preview-layer" data-preview hidden></section>
</main>
<script>
(() => {
  'use strict';
  const root = document.getElementById('tk-app');
  const API = 'modules/dmd-ticketing/dmd-ticketing_api.php';
  const UPLOAD = 'modules/dmd-ticketing/dmd-ticketing_upload.php';
  const state = { boot:null, items:[], openId:'', timer:null, busy:false };
  const $ = (s, c=root) => c.querySelector(s);
  const $$ = (s, c=root) => Array.from(c.querySelectorAll(s));
  const h = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const nl = v => h(v).replace(/\n/g,'<br>');
  const fmt = v => { if(!v) return ''; const d=new Date(v); return Number.isNaN(d.getTime()) ? String(v) : d.toLocaleString('fr-FR',{dateStyle:'short',timeStyle:'short'}); };
  const statusLabel = s => ({open:'Ouvert',in_progress:'En cours',waiting:'En attente',resolved:'Résolu',closed:'Fermé'}[s] || s || 'Ouvert');
  const remoteTarget = t => String(t?.remote_target || t?.meta?.domydesk?.target || '');
  const remoteName = t => remoteTarget(t)==='support' ? String(t?.meta?.domydesk?.target_name || state.boot?.external_support?.name || 'Support') : 'DoMyCo';
  const extClient = t => String(t?.meta?.external?.client_name || '');
  const isExternal = t => !!(t?.meta?.external && typeof t.meta.external === 'object');
  const isEscalated = t => !!t?.meta?.escalation?.requested || (Array.isArray(t?.remote_targets) && t.remote_targets.includes('domyco'));

  const workflowOf = t => (t?.workflow && typeof t.workflow==='object') ? t.workflow : (t?.meta?.workflow || {});
  function durationLabel(seconds){ seconds=Math.max(0,Number(seconds||0)); const m=Math.floor(seconds/60), hh=Math.floor(m/60), mm=m%60; return hh?hh+' h '+String(mm).padStart(2,'0'):(m?m+' min':(seconds?Math.floor(seconds)+' s':'0 min')); }
  function workflowCompact(t){
    const wf=workflowOf(t), time=wf.time||{}, closure=wf.closure||{}, incident=wf.incident||{}, parts=[]; const p=state.boot?.permissions||{}; const canTime=!!t.can_workflow_time; const canStatus=!!t.can_workflow_status;
    const clientSide=!isExternal(t) && remoteTarget(t)==='support'; const myRunning=(time.running||{})[state.boot?.me||''];
    if(canTime || Number(time.total_seconds||0)>0) parts.push(`<div class="tk-wf-card"><b>⏱️ ${h(durationLabel(time.total_seconds||0))}</b>${canTime&&p.reply?`<span>${myRunning?'<button type="button" data-time-stop>Stop</button>':'<button type="button" data-time-start>Chrono</button>'}<input type="number" min="1" max="1440" placeholder="min" data-time-minutes><button type="button" data-time-add>+ temps</button></span>`:''}</div>`);
    if(canStatus&&p.status){ const text=closure.state==='requested'?'En attente du client':closure.state==='accepted'?'Confirmé par le client':closure.state==='rejected'?'Refusé par le client':''; parts.push(`<div class="tk-wf-card"><b>✅ Validation</b><span>${text?h(text):'<button type="button" data-request-closure>Demander au client</button>'}</span></div>`); }
    if(clientSide&&closure.state==='requested') parts.push(`<div class="tk-wf-card tk-wf-validation"><b>✅ Le support propose de clôturer</b><input type="text" maxlength="300" placeholder="Commentaire" data-closure-comment><span><button type="button" data-closure-accept>Résolu</button><button type="button" data-closure-reject>Toujours en panne</button></span></div>`);
    if(canStatus&&p.status){ const opts=(t.incident_options||[]).map(i=>`<option value="${h(i.id)}" ${String(i.id)===String(incident.id||'')?'selected':''}>${h(i.title)}${i.status==='closed'?' · clos':''}</option>`).join(''); parts.push(`<div class="tk-wf-card"><b>🧩 ${h(incident.title||'Incident')}</b><span><select data-incident-select><option value="">Aucun</option>${opts}</select><button type="button" data-incident-link>Lier</button>${incident.id?'<button type="button" data-incident-unlink>Délier</button>':''}</span><span><input type="text" maxlength="120" placeholder="Nouvel incident" data-incident-title><button type="button" data-incident-create>Créer</button></span></div>`); }
    else if(incident.id) parts.push(`<div class="tk-wf-card"><b>🧩 ${h(incident.title||incident.id)}</b></div>`);
    return parts.length?`<div class="tk-workflow-mini">${parts.join('')}</div>`:'';
  }

  const notification = t => {
    const a=t?.meta?.domydesk?.notification || {}, b=t?.meta?.external?.notification || {};
    const unread=!!a.unread || !!b.unread;
    return {unread, count:(a.unread?Number(a.count||1):0)+(b.unread?Number(b.count||1):0)};
  };

  async function api(action, body={}){
    if(state.boot?.csrf && !body.csrf) body.csrf=state.boot.csrf;
    const r=await fetch(API+'?a='+encodeURIComponent(action),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),cache:'no-store'});
    const data=await r.json().catch(()=>({ok:false,err:'Réponse invalide'}));
    if(!r.ok && data?.ok!==true) return data;
    return data;
  }
  async function upload(id,input){
    if(!input?.files?.length) return {ok:true};
    const fd=new FormData(); fd.append('ticket_id',id); if(state.boot?.csrf) fd.append('csrf',state.boot.csrf);
    Array.from(input.files).forEach(f=>fd.append('files[]',f));
    const r=await fetch(UPLOAD,{method:'POST',body:fd,cache:'no-store'});
    return r.json().catch(()=>({ok:false,err:'Upload impossible'}));
  }
  function setDetailMode(open){
    root.classList.toggle('is-detail-open', !!open);
    $('[data-detail]').hidden = !open;
  }
  function switchTab(name){
    $$('[data-tab]').forEach(b=>b.classList.toggle('is-active',b.dataset.tab===name));
    $$('[data-view]').forEach(v=>v.classList.toggle('is-active',v.dataset.view===name));
    state.openId='';
    setDetailMode(false);
  }
  function setFilesLabel(input, el){
    const n=input?.files?.length||0; el.textContent=n ? n+' fichier'+(n>1?'s':'') : 'Cliquer ou déposer des fichiers';
  }
  function setDropped(input,files){
    try{ const dt=new DataTransfer(); Array.from(input.files||[]).forEach(f=>dt.items.add(f)); Array.from(files||[]).forEach(f=>dt.items.add(f)); input.files=dt.files; return true; }catch(_){ return false; }
  }
  function renderDestinations(){
    const box=$('[data-destinations]'); const p=state.boot?.permissions||{}; const rows=[];
    if(state.boot?.external_support?.enabled && p.external_send){
      rows.push(`<label class="tk-check"><input type="checkbox" name="targets" value="support" checked><span><b>${h(state.boot.external_support.name||'Support')}</b><small>Envoyer à votre entreprise de support</small></span></label>`);
    }
    if(p.sync){
      rows.push(`<label class="tk-check"><input type="checkbox" name="targets" value="domyco"><span><b>DoMyCo</b><small>Support central DoMyDesk</small></span></label>`);
    }
    box.innerHTML=rows.length ? rows.join('') : '<div class="tk-hint">Ticket local uniquement.</div>';
  }
  function ticketCard(t){
    const n=notification(t); const client=extClient(t); const remote=t?.meta?.domydesk?.requested||t?.send_to_domydesk;
    return `<button type="button" class="tk-ticket-card${n.unread?' has-new':''}" data-open="${h(t.id)}">
      <span class="tk-ticket-main"><strong>${h(t.title||'(sans titre)')}</strong><small>${h(client || t.owner || '')} · ${h(fmt(t.updated_at||t.created_at))}</small></span>
      <span class="tk-ticket-side">${n.unread?`<i>${h(n.count||1)}</i>`:''}<em>${h(statusLabel(t.status))}</em></span>
      <span class="tk-ticket-preview">${h(t.last_message||'')}</span>
      <span class="tk-ticket-tags">${client?`<b>Client : ${h(client)}</b>`:''}${t.category?`<b>${h(t.category)}</b>`:''}${t.priority?`<b>${h(t.priority)}</b>`:''}${remote?`<b>${h(remoteName(t))}</b>`:''}</span>
    </button>`;
  }
  function renderList(){
    const list=$('[data-list]'); const items=state.items; const unread=items.filter(t=>notification(t).unread).length;
    const u=$('[data-unread]'); u.hidden=!unread; u.textContent=unread||'';
    if(!items.length){ list.innerHTML='<div class="tk-empty">Aucun ticket.</div>'; return; }
    const ext=items.filter(t=>extClient(t)); const local=items.filter(t=>!extClient(t));
    if(ext.length){
      const groups=new Map(); ext.forEach(t=>{ const k=extClient(t); if(!groups.has(k))groups.set(k,[]); groups.get(k).push(t); });
      let html='';
      groups.forEach((arr,name)=>{ const n=arr.filter(t=>notification(t).unread).length; html+=`<section class="tk-client-group"><header><strong>${h(name)}</strong><span>${arr.length} ticket${arr.length>1?'s':''}</span>${n?`<i>${n}</i>`:''}</header><div>${arr.map(ticketCard).join('')}</div></section>`; });
      if(local.length) html+=`<section class="tk-client-group is-local"><header><strong>Mes tickets</strong><span>${local.length}</span></header><div>${local.map(ticketCard).join('')}</div></section>`;
      list.innerHTML=html;
    } else list.innerHTML=items.map(ticketCard).join('');
    $$('[data-open]',list).forEach(b=>b.onclick=()=>openTicket(b.dataset.open));
  }
  async function loadList(doSync=false){
    if(state.busy) return; state.busy=true;
    try{
      if(doSync && state.boot?.permissions?.sync) await api('sync_all',{});
      const r=await api('list',{status:$('[data-status]').value,scope:'visible',category:'',priority:'',client:'',q:$('[data-search]').value.trim()});
      if(!r?.ok) throw new Error(r?.err||'Chargement impossible');
      state.items=r.items||[]; renderList();
      if(state.openId && !detailIsEditing()) await refreshOpenTicket();
    }catch(e){ $('[data-list]').innerHTML='<div class="tk-empty is-error">'+h(e.message||'Erreur')+'</div>'; }
    finally{ state.busy=false; }
  }
  function attachmentHtml(a){
    if(!a||typeof a!=='object') return '';
    const url=String(a.local_url||a.url||''); if(!url) return '';
    const name=String(a.name||a.stored_name||'Fichier');
    const ext=name.split('.').pop().toLowerCase(); const image=['jpg','jpeg','png','gif','webp'].includes(ext);
    return `<button type="button" class="tk-attachment" data-file-url="${h(url)}" data-file-name="${h(name)}" data-image="${image?'1':'0'}">${image?'🖼️':'📎'} ${h(name)}</button>`;
  }
  function messageHtml(m,t){
    const remote=m?.role==='domydesk'; const external=m?.role==='external_requester';
    let origin=remote?'Support '+(m?.origin_target==='domyco'?'DoMyCo':remoteName(t)):(external?'Client externe':'Message local');
    if(remote && m?.origin_target==='domyco' && remoteTarget(t)==='support') origin='DoMyCo via '+remoteName(t);
    return `<article class="tk-message ${remote?'is-remote':''}"><header><strong>${h(m.by || (remote?'Support':'Utilisateur'))}</strong><span>${h(origin)} · ${h(fmt(m.at))}</span></header><div>${nl(m.text||'')}</div><footer>${(m.attachments||[]).map(attachmentHtml).join('')}</footer></article>`;
  }
  function detailIsEditing(){
    const d=$('[data-detail]'); if(d.hidden) return false;
    const ta=$('[data-reply-text]',d), fi=$('[data-reply-files]',d);
    return !!(ta?.value?.trim() || fi?.files?.length);
  }
  async function openTicket(id){
    state.openId=id; const d=$('[data-detail]'); setDetailMode(true); d.innerHTML='<div class="tk-empty">Ouverture…</div>';
    await refreshOpenTicket(true);
  }
  async function refreshOpenTicket(mark=true){
    const id=state.openId; if(!id) return;
    const r=await api('get',{id}); if(!r?.ok){ $('[data-detail]').innerHTML='<div class="tk-empty is-error">Ticket introuvable.</div>'; return; }
    const t=r.item; if(state.openId!==id) return;
    renderDetail(t);
    if(mark && notification(t).unread){ await api('mark_read',{id}); loadList(false); }
  }
  function renderDetail(t){
    const d=$('[data-detail]'); const p=state.boot?.permissions||{}; const linked=!!(t?.meta?.domydesk?.requested||t?.send_to_domydesk); const closed=t.status==='closed';
    const statuses=Object.entries(state.boot?.statuses||{}).map(([v,l])=>`<option value="${h(v)}"${v===t.status?' selected':''}>${h(l)}</option>`).join('');
    d.innerHTML=`<div class="tk-detail-shell">
      <header class="tk-detail-head"><button type="button" class="tk-back" data-back>‹</button><div><strong>${h(t.title||'Ticket')}</strong><small>${h(t.id)}</small></div><span>${h(statusLabel(t.status))}</span></header>
      <div class="tk-detail-meta"><span><b>${h(extClient(t)||t.owner||'')}</b>${h(fmt(t.updated_at||t.created_at))}</span><span>${h(t.category||'')} · ${h(t.priority||'')}</span></div>
      ${workflowCompact(t)}
      <div class="tk-thread">${(t.messages||[]).map(m=>messageHtml(m,t)).join('')||'<div class="tk-empty">Aucun message.</div>'}</div>
      <div class="tk-detail-actions">
        ${t.can_status && p.status?`<select data-ticket-status>${statuses}</select><button type="button" data-status-save>Statut</button>`:''}
        ${t.can_escalate && isExternal(t) && !isEscalated(t)?'<button type="button" data-escalate>Escalader vers DoMyCo</button>':''}
        ${linked && p.sync?`<button type="button" data-sync>Synchroniser ${h(remoteName(t))}</button>`:''}
      </div>
      ${p.reply?`<form class="tk-reply" data-reply-form><textarea data-reply-text name="message" ${closed?'disabled':''} placeholder="${closed?'Ticket fermé':'Votre réponse…'}"></textarea><label class="tk-reply-file"><input type="file" data-reply-files multiple ${closed?'disabled':''}><span>📎 <b data-reply-files-label>Ajouter un fichier</b></span></label><div><span class="tk-msg" data-reply-msg></span><button type="submit" class="tk-primary" ${closed?'disabled':''}>Envoyer</button></div></form>`:''}
    </div>`;
    $('[data-back]',d).onclick=()=>{ state.openId=''; setDetailMode(false); d.innerHTML=''; };
    $$('[data-file-url]',d).forEach(b=>b.onclick=()=>openPreview(b.dataset.fileUrl,b.dataset.fileName,b.dataset.image==='1'));
    const save=$('[data-status-save]',d); if(save) save.onclick=async()=>{ save.disabled=true; const rr=await api('update',{id:t.id,status:$('[data-ticket-status]',d).value}); save.disabled=false; if(!rr?.ok){alert(rr?.err||'Erreur');return;} await loadList(false); await refreshOpenTicket(false); };
    const esc=$('[data-escalate]',d); if(esc) esc.onclick=async()=>{ if(!confirm('Escalader ce ticket vers DoMyCo ?'))return; esc.disabled=true; const rr=await api('escalate_domyco',{id:t.id}); if(!rr?.ok) alert(rr?.message||rr?.err||'Escalade impossible'); await loadList(false); await refreshOpenTicket(false); };
    const sync=$('[data-sync]',d); if(sync) sync.onclick=async()=>{ sync.disabled=true; sync.textContent='Synchronisation…'; const rr=await api('sync',{id:t.id}); if(!rr?.ok) alert(rr?.err||'Synchronisation impossible'); await loadList(false); await refreshOpenTicket(false); };

    const timeStart=$('[data-time-start]',d); if(timeStart) timeStart.onclick=async()=>{ const rr=await api('time_start',{id:t.id}); if(!rr?.ok)alert(rr?.err||'Chrono impossible'); await loadList(false); await refreshOpenTicket(false); };
    const timeStop=$('[data-time-stop]',d); if(timeStop) timeStop.onclick=async()=>{ const rr=await api('time_stop',{id:t.id}); if(!rr?.ok)alert(rr?.err||'Arrêt impossible'); await loadList(false); await refreshOpenTicket(false); };
    const timeAdd=$('[data-time-add]',d); if(timeAdd) timeAdd.onclick=async()=>{ const minutes=Number($('[data-time-minutes]',d)?.value||0); if(minutes<1){alert('Indique les minutes.');return;} const rr=await api('time_add',{id:t.id,minutes}); if(!rr?.ok)alert(rr?.err||'Ajout impossible'); await loadList(false); await refreshOpenTicket(false); };
    const requestClosure=$('[data-request-closure]',d); if(requestClosure) requestClosure.onclick=async()=>{ if(!confirm('Demander au client de confirmer la résolution ?'))return; const rr=await api('request_closure',{id:t.id}); if(!rr?.ok)alert(rr?.message||rr?.err||'Impossible'); await loadList(false); await refreshOpenTicket(false); };
    const closureRespond=async decision=>{ const c=workflowOf(t).closure||{}; const rr=await api('closure_respond',{id:t.id,decision,request_id:c.request_id||'',comment:$('[data-closure-comment]',d)?.value||''}); if(!rr?.ok){alert(rr?.err||'Impossible');return;} await loadList(false); await refreshOpenTicket(false); };
    const ca=$('[data-closure-accept]',d); if(ca)ca.onclick=()=>closureRespond('accepted'); const cr=$('[data-closure-reject]',d); if(cr)cr.onclick=()=>closureRespond('rejected');
    const ic=$('[data-incident-create]',d); if(ic)ic.onclick=async()=>{const title=$('[data-incident-title]',d)?.value.trim()||'';if(!title){alert('Nom de l’incident requis.');return;}const rr=await api('incident_create',{id:t.id,title});if(!rr?.ok)alert(rr?.err||'Impossible');await loadList(false);await refreshOpenTicket(false);};
    const il=$('[data-incident-link]',d); if(il)il.onclick=async()=>{const incident_id=$('[data-incident-select]',d)?.value||'';if(!incident_id)return;const rr=await api('incident_link',{id:t.id,incident_id});if(!rr?.ok)alert(rr?.err||'Impossible');await loadList(false);await refreshOpenTicket(false);};
    const iu=$('[data-incident-unlink]',d); if(iu)iu.onclick=async()=>{const rr=await api('incident_unlink',{id:t.id});if(!rr?.ok)alert(rr?.err||'Impossible');await loadList(false);await refreshOpenTicket(false);};

    const fi=$('[data-reply-files]',d), fl=$('[data-reply-files-label]',d); if(fi) fi.onchange=()=>{ const n=fi.files.length; fl.textContent=n?n+' fichier'+(n>1?'s':''):'Ajouter un fichier'; };
    const form=$('[data-reply-form]',d); if(form) form.onsubmit=async e=>{
      e.preventDefault(); const ta=$('[data-reply-text]',d), files=$('[data-reply-files]',d), msg=$('[data-reply-msg]',d); const text=ta.value.trim();
      if(!text){ msg.textContent='Écris un message avant d’envoyer.'; msg.className='tk-msg is-error'; return; }
      const btn=form.querySelector('button[type="submit"]'); btn.disabled=true; msg.textContent='Envoi…'; msg.className='tk-msg';
      const rr=await api('reply',{id:t.id,message:text}); if(!rr?.ok){ msg.textContent=rr?.err||'Erreur'; msg.className='tk-msg is-error'; btn.disabled=false; return; }
      if(files.files.length){ const ur=await upload(t.id,files); if(!ur?.ok){ msg.textContent=ur?.err||'Pièce jointe non enregistrée'; msg.className='tk-msg is-error'; btn.disabled=false; return; } if(linked && p.sync) await api('sync',{id:t.id}); }
      ta.value=''; files.value=''; await loadList(false); await refreshOpenTicket(false);
    };
  }
  function openPreview(url,name,image){
    const layer=$('[data-preview]'); layer.hidden=false; layer.innerHTML=`<div class="tk-preview-box"><header><strong>${h(name)}</strong><button type="button" data-close>×</button></header><div class="tk-preview-body">${image?`<img src="${h(url)}" alt="${h(name)}">`:`<iframe src="${h(url)}" title="${h(name)}"></iframe>`}</div><footer><a href="${h(url)}" download>Ouvrir / télécharger</a></footer></div>`;
    $('[data-close]',layer).onclick=()=>{layer.hidden=true;layer.innerHTML='';};
    layer.onclick=e=>{if(e.target===layer){layer.hidden=true;layer.innerHTML='';}};
  }
  async function bootstrap(){
    const r=await fetch(API+'?a=bootstrap',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',cache:'no-store'}); state.boot=await r.json();
    if(!state.boot?.ok) throw new Error(state.boot?.err||'Initialisation impossible');
    const pc=$('[data-pc]'); if(state.boot.mydesk_context){ pc.textContent=state.boot.mydesk_context.hostname||'Poste'; pc.hidden=false; }
    renderDestinations();
    const submit=$('[data-new-submit]'); if(!state.boot.permissions?.create) submit.disabled=true;
    await loadList(true);
    clearInterval(state.timer); state.timer=setInterval(()=>loadList(true),120000);
  }

  $$('[data-tab]').forEach(b=>b.onclick=()=>switchTab(b.dataset.tab));
  $('[data-refresh]').onclick=()=>loadList(true);
  $('[data-status]').onchange=()=>loadList(false);
  let searchTimer=null; $('[data-search]').oninput=()=>{ clearTimeout(searchTimer); searchTimer=setTimeout(()=>loadList(false),250); };
  const nf=$('[data-new-form]'), nfi=nf.elements.files, nfl=$('[data-new-files]'); nfi.onchange=()=>setFilesLabel(nfi,nfl);
  nf.onsubmit=async e=>{
    e.preventDefault(); const msg=$('[data-new-msg]'), btn=$('[data-new-submit]'); btn.disabled=true; msg.textContent='Création…'; msg.className='tk-msg';
    const targets=$$('input[name="targets"]:checked',nf).map(x=>x.value);
    const rr=await api('create',{title:nf.elements.title.value,message:nf.elements.message.value,remote_targets:targets,share:{all:false,users:[],roles:[]}});
    if(!rr?.ok){ msg.textContent=rr?.message||rr?.err||'Création impossible'; msg.className='tk-msg is-error'; btn.disabled=!state.boot?.permissions?.create; return; }
    if(nfi.files.length){ const ur=await upload(rr.id,nfi); if(!ur?.ok){ msg.textContent='Ticket créé, pièce jointe non enregistrée'; msg.className='tk-msg is-error'; btn.disabled=!state.boot?.permissions?.create; return; } if(targets.length && state.boot.permissions?.sync) await api('sync',{id:rr.id}); }
    nf.reset(); setFilesLabel(nfi,nfl); renderDestinations(); msg.textContent='Ticket créé'; msg.className='tk-msg is-ok'; btn.disabled=!state.boot?.permissions?.create; await loadList(false); switchTab('tickets');
  };
  window.addEventListener('dmd:mydesk-files',e=>{
    const files=Array.from(e.detail?.files||[]); if(!files.length) return;
    if(state.openId){ const d=$('[data-detail]'), input=$('[data-reply-files]',d); if(input && setDropped(input,files)){ input.dispatchEvent(new Event('change')); return; } }
    switchTab('new'); if(setDropped(nfi,files)) nfi.dispatchEvent(new Event('change'));
  });
  document.addEventListener('visibilitychange',()=>{ if(!document.hidden) loadList(true); });
  bootstrap().catch(e=>{ $('[data-list]').innerHTML='<div class="tk-empty is-error">'+h(e.message)+'</div>'; });
  setDetailMode(false);
})();
</script>
</body>
</html>
