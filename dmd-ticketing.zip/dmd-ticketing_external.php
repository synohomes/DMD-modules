<?php
/* * =====================================================================
                                DoMyDesk
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
*
Ce fichier fait partie du logiciel DoMyDesk.
*
Toute reproduction, redistribution, revente, publication ou
intégration de tout ou partie de ce code dans un autre produit
sans autorisation préalable de SynoHomes est interdite.
*
La modification du logiciel dans le cadre de son utilisation
*
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0
*
Éditeur : SynoHomes

* * ===================================================================== * */
require_once __DIR__ . '/dmd-ticketing_lib.php';

header('X-Content-Type-Options: nosniff');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
error_reporting(0);

function tkext_out($data, $status = 200) {
    http_response_code((int)$status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function tkext_out_after($data, $status, $callback = null) {
    $body = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($body)) $body = '{"success":false,"error":"ENCODE_FAILED"}';
    http_response_code((int)$status);
    header('Content-Length: ' . strlen($body));
    header('Connection: close');
    echo $body;
    if (function_exists('fastcgi_finish_request')) {
        @fastcgi_finish_request();
    } else {
        @ob_flush();
        @flush();
    }
    if (is_callable($callback)) {
        try { call_user_func($callback); } catch (Throwable $e) { /* Le Client ne doit jamais échouer à cause du relais DoMyCo. */ }
    }
    exit;
}
function tkext_header_token() {
    if (!empty($_SERVER['HTTP_X_DMD_SUPPORT_TOKEN'])) return trim((string)$_SERVER['HTTP_X_DMD_SUPPORT_TOKEN']);
    if (!empty($_POST['support_token'])) return trim((string)$_POST['support_token']);
    return '';
}
function tkext_header_client_token() {
    if (!empty($_SERVER['HTTP_X_DMD_CLIENT_KEY'])) return trim((string)$_SERVER['HTTP_X_DMD_CLIENT_KEY']);
    if (!empty($_POST['client_key'])) return trim((string)$_POST['client_key']);
    return '';
}
function tkext_status_valid($status) {
    return in_array((string)$status, array('open','in_progress','waiting','resolved','closed'), true);
}
function tkext_ticket_id($instanceUid, $localTicketId) {
    return 'EXT-' . strtoupper(substr(hash('sha256', (string)$instanceUid . '|' . (string)$localTicketId), 0, 20));
}
function tkext_find_ticket($id) {
    list($ticket) = dmdtk_ticket_read((string)$id);
    return is_array($ticket) && $ticket ? $ticket : null;
}
function tkext_public_file_url($ticketId, $storedName, $token) {
    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off');
    $scheme = $https ? 'https' : 'http';
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host === '') return '';
    $dir = rtrim(str_replace('\\','/', dirname((string)($_SERVER['SCRIPT_NAME'] ?? ''))), '/');
    $sig = hash_hmac('sha256', (string)$ticketId . '|' . (string)$storedName, (string)$token);
    return $scheme . '://' . $host . $dir . '/dmd-ticketing_external_file.php?ticket=' . rawurlencode((string)$ticketId) . '&file=' . rawurlencode((string)$storedName) . '&sig=' . rawurlencode($sig);
}
function tkext_client_messages($ticket, $token) {
    $out = array();
    $localCfg = dmdtk_config();
    $supportName = trim((string)($localCfg['external_receive']['name'] ?? 'Support'));
    if ($supportName === '') $supportName = 'Support';
    foreach ((array)($ticket['messages'] ?? array()) as $message) {
        if (!is_array($message)) continue;
        if ((string)($message['role'] ?? '') === 'external_requester') continue;
        $attachments = array();
        foreach ((array)($message['attachments'] ?? array()) as $attachment) {
            if (!is_array($attachment)) continue;
            $copy = $attachment;
            $stored = trim((string)($copy['stored_name'] ?? ''));
            $localFile = $stored !== '' ? dmdtk_attachment_file_path($ticket, $copy, $stored) : '';
            if ($localFile !== '') {
                $url = tkext_public_file_url((string)($ticket['id'] ?? ''), $stored, $token);
                if ($url !== '') {
                    $copy['url'] = $url;
                    $copy['local_url'] = $url;
                    $copy['central_url'] = $url;
                    $copy['remote_url'] = $url;
                }
                $copy['stored_on'] = 'support_provider';
            }
            $attachments[] = $copy;
        }
        $originTarget = ((string)($message['role'] ?? '') === 'domydesk')
            ? trim((string)($message['origin_target'] ?? $message['remote_target'] ?? 'domyco'))
            : 'support';
        if (!in_array($originTarget, array('support','domyco'), true)) $originTarget = 'support';
        $originName = $originTarget === 'domyco' ? 'DoMyCo' : $supportName;
        $out[] = array(
            'message_uid' => (string)($message['id'] ?? ''),
            'created_at' => (string)($message['at'] ?? dmdtk_now()),
            'author_email' => (string)($message['by'] ?? 'Support'),
            'origin_target' => $originTarget,
            'origin_name' => $originName,
            'message_text' => (string)($message['text'] ?? ''),
            'attachments' => $attachments
        );
    }
    return $out;
}
function tkext_public_workflow($ticket) {
    $workflow = dmdtk_ticket_workflow($ticket);
    $time = isset($workflow['time']) && is_array($workflow['time']) ? $workflow['time'] : array();
    $closure = isset($workflow['closure']) && is_array($workflow['closure']) ? $workflow['closure'] : array();
    $incident = isset($workflow['incident']) && is_array($workflow['incident']) ? $workflow['incident'] : array();
    return array(
        'time' => array('total_seconds'=>max(0,(int)($time['total_seconds'] ?? 0))),
        'closure' => $closure,
        'incident' => array(
            'id'=>(string)($incident['id'] ?? ''),
            'title'=>(string)($incident['title'] ?? ''),
            'status'=>(string)($incident['status'] ?? '')
        )
    );
}
function tkext_response_ticket($ticket) {
    return array(
        'central_ticket_uid' => (string)($ticket['id'] ?? ''),
        'status' => (string)($ticket['status'] ?? 'open'),
        'updated_at' => (string)($ticket['updated_at'] ?? $ticket['created_at'] ?? dmdtk_now()),
        'workflow' => tkext_public_workflow($ticket)
    );
}

$cfg = dmdtk_config();
$receive = isset($cfg['external_receive']) && is_array($cfg['external_receive']) ? $cfg['external_receive'] : array();
if (empty($receive['enabled'])) tkext_out(array('success'=>false,'error'=>'EXTERNAL_SUPPORT_DISABLED','message'=>'Réception des tickets externes désactivée.'), 403);

$expected = trim((string)($receive['token'] ?? ''));
$provided = tkext_header_token();
if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
    tkext_out(array('success'=>false,'error'=>'INVALID_SUPPORT_TOKEN','message'=>'Clé de liaison invalide.'), 403);
}

$owner = trim((string)($receive['owner'] ?? ''));
if ($owner === '' || dmdtk_user_root($owner, false) === '') {
    tkext_out(array('success'=>false,'error'=>'RECEIVER_OWNER_MISSING','message'=>'Compte propriétaire des tickets externes non configuré.'), 503);
}

/* Upload d'une pièce jointe depuis le DoMyDesk client. */
if ((string)($_POST['type'] ?? '') === 'ticketing_attachment') {
    $instanceUid = trim((string)($_POST['instance_uid'] ?? ''));
    $localTicketId = trim((string)($_POST['local_ticket_id'] ?? ''));
    $messageUid = trim((string)($_POST['message_uid'] ?? ''));
    if ($instanceUid === '' || $localTicketId === '' || $messageUid === '' || empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
        tkext_out(array('success'=>false,'error'=>'BAD_ATTACHMENT_REQUEST','message'=>'Pièce jointe incomplète.'), 400);
    }
    $clientAuth = dmdtk_external_client_authorize($instanceUid, tkext_header_client_token());
    if (empty($clientAuth['ok'])) {
        $err = (string)($clientAuth['error'] ?? 'CLIENT_AUTH_FAILED');
        tkext_out(array('success'=>false,'error'=>$err,'message'=>$err==='CLIENT_REVOKED'?'Entreprise cliente révoquée.':'Liaison entreprise cliente invalide.'), 403);
    }
    $ticketId = tkext_ticket_id($instanceUid, $localTicketId);
    $ticket = tkext_find_ticket($ticketId);
    if (!$ticket) tkext_out(array('success'=>false,'error'=>'TICKET_NOT_FOUND','message'=>'Ticket distant introuvable.'), 404);

    $original = trim((string)($_POST['original_name'] ?? $_FILES['file']['name'] ?? 'fichier'));
    $safe = preg_replace('~[^A-Za-z0-9._-]+~u', '_', basename($original));
    if ($safe === '') $safe = 'fichier';
    $stored = date('YmdHis') . '-' . substr(bin2hex(random_bytes(4)), 0, 8) . '-' . $safe;
    $dir = dmdtk_ticket_files_dir($ticket, true);
    if ($dir === '') tkext_out(array('success'=>false,'error'=>'STORAGE_UNAVAILABLE'), 500);
    $dest = $dir . '/' . $stored;
    if (!@move_uploaded_file($_FILES['file']['tmp_name'], $dest)) tkext_out(array('success'=>false,'error'=>'UPLOAD_FAILED'), 500);
    @chmod($dest, 0640);

    $attachment = array(
        'name' => $original,
        'stored_name' => $stored,
        'size' => (int)@filesize($dest),
        'mime' => function_exists('mime_content_type') ? (string)@mime_content_type($dest) : 'application/octet-stream',
        'url' => dmdtk_file_url((string)$ticket['id'], $stored),
        'local_url' => dmdtk_file_url((string)$ticket['id'], $stored),
        'stored_on' => 'support_provider'
    );
    foreach ($ticket['messages'] as &$message) {
        if (!is_array($message) || (string)($message['id'] ?? '') !== $messageUid) continue;
        if (!isset($message['attachments']) || !is_array($message['attachments'])) $message['attachments'] = array();
        $message['attachments'][] = $attachment;
        break;
    }
    unset($message);
    $ticket['updated_at'] = dmdtk_now();
    if (!dmdtk_ticket_write($ticket)) tkext_out(array('success'=>false,'error'=>'WRITE_FAILED'), 500);
    $relayTicketId = (string)$ticket['id'];
    if (dmdtk_domyco_ticket_escalated($ticket)) {
        tkext_out_after(array('success'=>true,'attachment'=>$attachment), 200, function() use ($relayTicketId) {
            dmdtk_domyco_auto_relay_by_ticket_id($relayTicketId, 'client_attachment');
        });
    }
    tkext_out(array('success'=>true,'attachment'=>$attachment));
}

$raw = (string)file_get_contents('php://input');
$payload = json_decode($raw, true);
if (!is_array($payload) || (string)($payload['type'] ?? '') !== 'ticketing_ticket') {
    tkext_out(array('success'=>false,'error'=>'BAD_REQUEST','message'=>'Requête Ticketing invalide.'), 400);
}

$event = trim((string)($payload['event'] ?? 'upsert'));
$instanceUid = trim((string)($payload['instance_uid'] ?? ''));
$sourceTicket = isset($payload['ticket']) && is_array($payload['ticket']) ? $payload['ticket'] : array();
$localTicketId = trim((string)($sourceTicket['id'] ?? ''));
if ($instanceUid === '' || $localTicketId === '') tkext_out(array('success'=>false,'error'=>'MISSING_IDENTIFIERS'), 400);

$clientAuth = dmdtk_external_client_authorize($instanceUid, tkext_header_client_token(), isset($payload['instance']) && is_array($payload['instance']) ? $payload['instance'] : array());
if (empty($clientAuth['ok'])) {
    $err = (string)($clientAuth['error'] ?? 'CLIENT_AUTH_FAILED');
    $messages = array(
        'CLIENT_NOT_REGISTERED'=>'Cette instance cliente n’est pas enregistrée chez le support.',
        'CLIENT_REVOKED'=>'Cette entreprise cliente a été révoquée par le support.',
        'CLIENT_TOKEN_INVALID'=>'Jeton de liaison client invalide.',
        'CLIENT_IDENTITY_REQUIRED'=>'Identité de liaison client manquante.'
    );
    tkext_out(array('success'=>false,'error'=>$err,'message'=>$messages[$err] ?? 'Liaison entreprise cliente invalide.'), 403);
}
$clientRecord = isset($clientAuth['client']) && is_array($clientAuth['client']) ? $clientAuth['client'] : array();

$ticketId = tkext_ticket_id($instanceUid, $localTicketId);
$ticket = tkext_find_ticket($ticketId);

if ($event === 'delete') {
    if ($ticket) dmdtk_delete_local_ticket($ticket);
    tkext_out(array('success'=>true,'deleted'=>true,'ticket'=>array('central_ticket_uid'=>$ticketId,'deleted'=>true,'deleted_at'=>dmdtk_now(),'deleted_by'=>(string)($sourceTicket['owner'] ?? 'Client'))));
}

if ($event === 'pull') {
    if (!$ticket) tkext_out(array('success'=>false,'error'=>'TICKET_NOT_FOUND','message'=>'Ticket distant introuvable.'), 404);
    tkext_out(array('success'=>true,'ticket'=>tkext_response_ticket($ticket),'central_messages'=>tkext_client_messages($ticket, $expected)));
}

if ($event !== 'upsert') tkext_out(array('success'=>false,'error'=>'BAD_EVENT'), 400);

$isNew = !$ticket;
if ($isNew) {
    $ticket = array(
        'id' => $ticketId,
        'owner' => $owner,
        'created_at' => dmdtk_now(),
        'updated_at' => dmdtk_now(),
        'status' => tkext_status_valid($sourceTicket['status'] ?? '') ? (string)$sourceTicket['status'] : 'open',
        'title' => trim((string)($sourceTicket['title'] ?? 'Ticket client externe')),
        'category' => trim((string)($sourceTicket['category'] ?? 'Support')),
        'priority' => trim((string)($sourceTicket['priority'] ?? 'Normale')),
        'share' => array('all'=>true,'users'=>array(),'roles'=>array()),
        'send_to_domydesk' => false,
        'messages' => array(),
        'meta' => array()
    );
}

$instance = isset($payload['instance']) && is_array($payload['instance']) ? $payload['instance'] : array();
$previousExternal = isset($ticket['meta']['external']) && is_array($ticket['meta']['external']) ? $ticket['meta']['external'] : array();
$previousExternalNotification = isset($previousExternal['notification']) && is_array($previousExternal['notification']) ? $previousExternal['notification'] : array();
$ticket['title'] = trim((string)($sourceTicket['title'] ?? $ticket['title'] ?? 'Ticket client externe'));
$ticket['category'] = trim((string)($sourceTicket['category'] ?? $ticket['category'] ?? 'Support'));
$ticket['priority'] = trim((string)($sourceTicket['priority'] ?? $ticket['priority'] ?? 'Normale'));
$ticket['meta']['external'] = array(
    'requester' => trim((string)($sourceTicket['owner'] ?? '')),
    'source_instance_uid' => $instanceUid,
    'source_ticket_id' => $localTicketId,
    'source_instance_name' => trim((string)($instance['instance_name'] ?? '')),
    'source_domain' => trim((string)($instance['domain'] ?? '')),
    'client_name' => trim((string)($clientRecord['client_name'] ?? '')),
    'client_ref' => trim((string)($clientRecord['client_ref'] ?? '')),
    'received_at' => (string)($previousExternal['received_at'] ?? dmdtk_now()),
    'last_sync_at' => dmdtk_now(),
    'notification' => $previousExternalNotification
);


/* Le Client peut répondre à une demande de validation de résolution.
   On n'accepte que la réponse correspondant au request_id actuellement attendu. */
$sourceWorkflow = isset($sourceTicket['meta']['workflow']) && is_array($sourceTicket['meta']['workflow']) ? dmdtk_workflow_normalize($sourceTicket['meta']['workflow']) : array();
$sourceClosure = isset($sourceWorkflow['closure']) && is_array($sourceWorkflow['closure']) ? $sourceWorkflow['closure'] : array();
$localWorkflow = dmdtk_ticket_workflow($ticket);
$localClosure = isset($localWorkflow['closure']) && is_array($localWorkflow['closure']) ? $localWorkflow['closure'] : array();
$sourceClosureState = (string)($sourceClosure['state'] ?? 'none');
$sourceRequestId = trim((string)($sourceClosure['request_id'] ?? ''));
$localRequestId = trim((string)($localClosure['request_id'] ?? ''));
if (($localClosure['state'] ?? 'none') === 'requested'
    && $sourceRequestId !== '' && $localRequestId !== '' && hash_equals($localRequestId, $sourceRequestId)
    && in_array($sourceClosureState, array('accepted','rejected'), true)) {
    $localWorkflow['closure'] = array_merge($localClosure, array(
        'state'=>$sourceClosureState,
        'responded_at'=>(string)($sourceClosure['responded_at'] ?? dmdtk_now()),
        'responded_by'=>trim((string)($sourceClosure['responded_by'] ?? $sourceTicket['owner'] ?? 'Client')),
        'comment'=>trim((string)($sourceClosure['comment'] ?? ''))
    ));
    dmdtk_ticket_set_workflow($ticket, $localWorkflow);
    $ticket['status'] = $sourceClosureState === 'accepted' ? 'closed' : 'open';
}

$newClientMessages = 0;
$lastClientMessageAt = '';
$known = array();
foreach ((array)$ticket['messages'] as $message) {
    if (!is_array($message)) continue;
    $mid = trim((string)($message['id'] ?? ''));
    if ($mid !== '') $known[$mid] = true;
}
foreach ((array)($sourceTicket['messages'] ?? array()) as $message) {
    if (!is_array($message)) continue;
    if ((string)($message['role'] ?? '') === 'domydesk') continue; // Réponse déjà issue du support distant.
    $mid = trim((string)($message['id'] ?? ''));
    if ($mid === '' || isset($known[$mid])) continue;
    $messageAt = (string)($message['at'] ?? dmdtk_now());
    $ticket['messages'][] = array(
        'id' => $mid,
        'at' => $messageAt,
        'by' => (string)($message['by'] ?? $sourceTicket['owner'] ?? 'Client externe'),
        'role' => 'external_requester',
        'text' => (string)($message['text'] ?? ''),
        'attachments' => array()
    );
    $known[$mid] = true;
    $newClientMessages++;
    $lastClientMessageAt = $messageAt;
}
if ($newClientMessages > 0) {
    $wasUnread = !empty($previousExternalNotification['unread']);
    $previousCount = $wasUnread ? (int)($previousExternalNotification['count'] ?? 0) : 0;
    $clientLabel = trim((string)($ticket['meta']['external']['client_name'] ?? ''));
    if ($clientLabel === '') $clientLabel = 'Client';
    $ticket['meta']['external']['notification'] = array(
        'unread' => true,
        'state' => 'new',
        'count' => $previousCount + $newClientMessages,
        'at' => $lastClientMessageAt !== '' ? $lastClientMessageAt : dmdtk_now(),
        'kind' => 'message',
        'label' => 'Nouvelle réponse de ' . $clientLabel
    );
} elseif (!$previousExternalNotification) {
    $ticket['meta']['external']['notification'] = array(
        'unread' => false,
        'state' => 'idle',
        'count' => 0,
        'at' => dmdtk_now(),
        'label' => 'Aucune nouvelle information'
    );
}
$ticket['updated_at'] = dmdtk_now();

if (!dmdtk_ticket_write($ticket)) tkext_out(array('success'=>false,'error'=>'WRITE_FAILED','message'=>'Impossible d’enregistrer le ticket reçu.'), 500);

$response = array(
    'success'=>true,
    'ticket'=>tkext_response_ticket($ticket),
    'central_messages'=>tkext_client_messages($ticket, $expected)
);

/* Une fois escaladé, le Support devient le seul relais vers DoMyCo.
   Le Client continue uniquement à synchroniser avec son Support : chaque upsert
   reçu ici republie automatiquement l'historique courant vers DoMyCo. */
if (dmdtk_domyco_ticket_escalated($ticket)) {
    $relayTicketId = (string)$ticket['id'];
    tkext_out_after($response, 200, function() use ($relayTicketId) {
        dmdtk_domyco_auto_relay_by_ticket_id($relayTicketId, 'client_sync');
    });
}

tkext_out($response);
