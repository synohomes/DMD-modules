<?php
/* Données de supervision — lecture seule, contrôle d'accès côté serveur. */
require_once __DIR__ . '/dmd-ticketing_overview_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, private');
$email = dmdtk_user_email();
if ($email === '') { http_response_code(401); echo json_encode(array('ok'=>false,'error'=>'not_authenticated')); exit; }
if (!dmdtk_ov_can($email)) { http_response_code(403); echo json_encode(array('ok'=>false,'error'=>'forbidden')); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'GET') { http_response_code(405); exit; }
$all = dmdtk_ov_can($email, 'all');
/* Le détail est chargé à la demande : ne pas exposer les échanges dans le résumé global. */
if (isset($_GET['action']) && $_GET['action'] === 'detail') {
    $id = trim((string)($_GET['id'] ?? ''));
    if (!preg_match('/^[A-Za-z0-9._-]{1,160}$/D', $id)) {
        http_response_code(400);
        echo json_encode(array('ok'=>false,'error'=>'invalid_id'));
        exit;
    }
    list($ticket) = dmdtk_ticket_read($id);
    if (!is_array($ticket) || !$ticket || !dmdtk_ov_ticket_visible($ticket, $email, $all)) {
        http_response_code(404);
        echo json_encode(array('ok'=>false,'error'=>'not_found'));
        exit;
    }
    $messages = array();
    foreach ((array)($ticket['messages'] ?? array()) as $m) {
        if (!is_array($m)) continue;
        $attachments = array();
        foreach ((array)($m['attachments'] ?? array()) as $a) {
            if (!is_array($a)) continue;
            $stored = trim((string)($a['stored_name'] ?? ''));
            $downloadUrl = '';
            if ($stored !== '' && basename($stored) === $stored && $stored !== '.' && $stored !== '..') {
                $downloadUrl = 'modules/dmd-ticketing/dmd-ticketing_overview_file.php?id='
                    . rawurlencode($id) . '&file=' . rawurlencode($stored);
            }
            $attachments[] = array(
                'name'=>(string)($a['name'] ?? 'Fichier joint'),
                'size'=>(int)($a['size'] ?? 0),
                'download_url'=>$downloadUrl
            );
        }
        $messages[] = array(
            'by'=>(string)($m['by'] ?? ''),
            'at'=>(string)($m['at'] ?? ''),
            'text'=>(string)($m['text'] ?? ''),
            'attachments'=>$attachments
        );
    }
    echo json_encode(array('ok'=>true,'id'=>$id,'messages'=>$messages), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
$rows = array();
$counts = array('open'=>0, 'in_progress'=>0, 'waiting'=>0, 'resolved'=>0, 'closed'=>0);
$urgent = 0;
$clients = array();
$owners = array();
$trend = array();
$now = time();
$firstResponses = array();
for ($i=29; $i>=0; $i--) {
    $key = date('Y-m-d', $now - 86400*$i);
    $trend[$key] = 0;
}
foreach (dmdtk_index() as $id => $idx) {
    if (!is_array($idx)) continue;
    if (!$all) {
        $owner = (string)($idx['owner'] ?? '');
        $share = isset($idx['share']) && is_array($idx['share']) ? $idx['share'] : array();
        $role = dmdtk_user_role_metier($email);
        if ($owner !== $email && empty($share['all']) && !in_array($email, (array)($share['users']??array()),true) && ($role === '' || !in_array($role,(array)($share['roles']??array()),true))) continue;
    }
    list($t) = dmdtk_ticket_read((string)$id);
    if (!is_array($t) || empty($t) || !dmdtk_ov_ticket_visible($t, $email, $all)) continue;
    $status = (string)($t['status'] ?? 'open');
    if (!array_key_exists($status,$counts)) $status='open';
    $counts[$status]++;
    $priority = trim((string)($t['priority'] ?? ''));
    $isUrgent = preg_match('/urg|crit|immed|p1/i', $priority) === 1;
    if ($isUrgent && !in_array($status,array('resolved','closed'),true)) $urgent++;
    $owner = (string)($t['owner'] ?? '');
    if ($owner !== '') $owners[$owner] = ($owners[$owner] ?? 0) + 1;
    $meta = isset($t['meta']) && is_array($t['meta']) ? $t['meta'] : array();
    $ext = isset($meta['external']) && is_array($meta['external']) ? $meta['external'] : array();
    $client = trim((string)($ext['client_name'] ?? $ext['client_ref'] ?? ''));
    if ($client === '') $client = 'Interne';
    if (!in_array($status,array('resolved','closed'),true)) $clients[$client] = ($clients[$client] ?? 0) + 1;
    $created = (string)($t['created_at']??'');
    $updated = (string)($t['updated_at']??$created);
    $createdTs = strtotime($created);
    if ($createdTs !== false) { $day = date('Y-m-d', $createdTs); if (isset($trend[$day])) $trend[$day]++; }
    $msgs = isset($t['messages']) && is_array($t['messages']) ? $t['messages'] : array();
    if ($createdTs !== false) {
        foreach ($msgs as $m) {
            if (!is_array($m)) continue;
            $by = (string)($m['by'] ?? '');
            if ($by === '' || strcasecmp($by,$owner) === 0) continue;
            $msgTs = strtotime((string)($m['at'] ?? ''));
            if ($msgTs !== false && $msgTs >= $createdTs) { $firstResponses[] = $msgTs - $createdTs; break; }
        }
    }
    $rows[] = array(
        'id'=>(string)($t['id']??$id),
        'title'=>(string)($t['title']??''),
        'owner'=>$owner,
        'status'=>$status,
        'priority'=>$priority,
        'category'=>(string)($t['category']??''),
        'client'=>$client,
        'created_at'=>$created,
        'updated_at'=>$updated,
        'urgent'=>$isUrgent,
        'message_count'=>count($msgs),
        'description'=>isset($msgs[0]['text']) ? (function_exists('mb_substr') ? mb_substr((string)$msgs[0]['text'],0,350) : substr((string)$msgs[0]['text'],0,350)) : ''
    );
}
usort($rows,function($a,$b){ return strcmp($b['updated_at'],$a['updated_at']); });
arsort($clients); arsort($owners);
$mean = count($firstResponses) ? (int)round(array_sum($firstResponses)/count($firstResponses)) : null;
echo json_encode(array(
    'ok'=>true, 'scope'=>$all?'all':'visible', 'me'=>$email,
    'summary'=>array('total'=>count($rows),'statuses'=>$counts,'urgent'=>$urgent,'first_response_seconds'=>$mean,'answered_tickets'=>count($firstResponses)),
    'trend'=>array_map(function($day,$value){return array('day'=>$day,'count'=>$value);},array_keys($trend),array_values($trend)),
    'clients'=>array_slice($clients,0,8,true), 'owners'=>array_slice($owners,0,8,true),
    'tickets'=>$rows,
),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
