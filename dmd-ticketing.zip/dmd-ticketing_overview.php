<?php
/* Interface indépendante du Core DoMyDesk : seule l'autorisation du module ouvre cette page. */
require_once __DIR__ . '/dmd-ticketing_overview_lib.php';
$me = dmdtk_ov_require();
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
function ov_h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$cssV = @filemtime(__DIR__.'/dmd-ticketing_overview.css') ?: 1;
$jsV = @filemtime(__DIR__.'/dmd-ticketing_overview.js') ?: 1;
$manager = dmdtk_ov_is_manager($me);
$embed = isset($_GET['embed']) && (string)$_GET['embed'] === '1';
if ($embed) {
    ?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><base href="../../"><link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing_overview.css?v=<?= (int)$cssV ?>"></head><body class="dmd-ov-embed-body"><?php
} else {
    // Direct access keeps the real DoMyDesk header and current user theme.
    ob_start();
    require dmdtk_root() . '/header.php';
    $dmdHeaderHtml = (string)ob_get_clean();
    $dmdAssets = '<base href="../../">' . "\n" . '<link rel="stylesheet" href="modules/dmd-ticketing/dmd-ticketing_overview.css?v=' . (int)$cssV . '">';
    $dmdHeadPos = stripos($dmdHeaderHtml, '</head>');
    if ($dmdHeadPos !== false) echo substr_replace($dmdHeaderHtml, $dmdAssets . "\n", $dmdHeadPos, 0);
    else { echo $dmdHeaderHtml; echo $dmdAssets; }
    unset($dmdHeaderHtml, $dmdAssets, $dmdHeadPos);
}
?>
<div class="dmd-ov-page<?= $embed ? ' dmd-ov-embed dmd-ov-overview-embed' : '' ?>" aria-label="DMD-Ticketing — Vue d'ensemble">
<div class="ov-heading">
  <div class="ov-brand"><span class="ov-symbol">▣</span><span><strong>DMD-Ticketing</strong><small>Gestion du support et des demandes</small></span></div>
  <label class="ov-search"><span>⌕</span><input type="search" id="ov-search" placeholder="Rechercher un ticket, un client, un utilisateur..." aria-label="Rechercher un ticket"></label>
  <div class="ov-topstats"><span><b data-head="total">—</b><small>Tickets</small></span><span><b data-head="open">—</b><small>Ouverts</small></span><span><b data-head="progress">—</b><small>En cours</small></span><span><b data-head="waiting">—</b><small>En attente</small></span><span><b data-head="urgent">—</b><small>Urgents</small></span></div>
</div>
<div class="ov-layout">
  <aside class="ov-sidebar" aria-label="Navigation Ticketing">
    <nav>
      <button type="button" class="ov-nav-active" data-section="overview"><span>⌂</span> Vue d'ensemble</button>
      <h3>TICKETS</h3>
      <button type="button" data-section="tickets"><span>▤</span> Tous accessibles</button>
      <button type="button" data-section="mine"><span>♙</span> Mes tickets</button>
      <button type="button" data-section="urgent"><span>△</span> Prioritaires</button>
      <button type="button" data-section="open"><span>▢</span> Ouverts</button>
      <button type="button" data-section="in_progress"><span>▷</span> En cours</button>
      <button type="button" data-section="waiting"><span>◷</span> En attente</button>
      <button type="button" data-section="resolved"><span>✓</span> Résolus</button>
      <button type="button" data-section="closed"><span>▣</span> Fermés</button>
      <h3>SUPERVISION</h3>
      <button type="button" data-section="clients"><span>♧</span> Clients</button>
      <button type="button" data-section="statistics"><span>▥</span> Statistiques</button>
      <?php if ($manager): ?><h3>CONFIGURATION</h3><a href="modules/dmd-ticketing/dmd-ticketing_overview_access.php<?= $embed ? '?embed=1' : '' ?>"><span>⚙</span> Droits d'accès</a><?php endif; ?>
    </nav>
    <?php if(!$embed): ?><a class="ov-back" href="dashboard.php">← Retour à DoMyDesk</a><?php endif; ?>
  </aside>
  <main class="ov-main" id="ov-main">
    <div class="ov-system"><span class="ov-led"></span><div><b>Vue d'ensemble du Ticketing</b><small id="ov-scope">Chargement des données...</small></div><button id="ov-refresh" type="button" class="ov-btn">↻ Actualiser</button></div>
    <div class="ov-intro"><div><h1 id="ov-heading-label">Tableau de bord</h1><p>Supervision des tickets et des interventions.</p></div><small id="ov-count-label"></small></div>
    <section class="ov-cards" id="ov-cards" aria-label="Indicateurs">
      <div class="ov-card"><span>Tickets ouverts</span><strong data-stat="open">—</strong><small>En attente de prise en charge</small></div>
      <div class="ov-card"><span>En cours</span><strong data-stat="in_progress">—</strong><small>Traitement en cours</small></div>
      <div class="ov-card"><span>En attente</span><strong data-stat="waiting">—</strong><small>En attente de réponse ou action</small></div>
      <div class="ov-card is-alert"><span>Priorité urgente</span><strong data-stat="urgent">—</strong><small>Hors tickets clos / résolus</small></div>
      <div class="ov-card is-ok"><span>Résolus</span><strong data-stat="resolved">—</strong><small>Statut actuel</small></div>
      <div class="ov-card"><span>Fermés</span><strong data-stat="closed">—</strong><small>Statut actuel</small></div>
    </section>
    <section class="ov-analysis" data-chart-group>
      <div class="ov-panel ov-trend"><div class="ov-panel-title"><b>Évolution des créations de tickets</b><small>30 derniers jours</small></div><svg id="ov-trend" viewBox="0 0 690 172" preserveAspectRatio="none" role="img" aria-label="Création quotidienne de tickets"></svg></div>
      <div class="ov-panel ov-distribution"><div class="ov-panel-title"><b>Répartition par statut</b></div><div class="ov-donut-layout"><div class="ov-donut" id="ov-donut"><div><strong data-stat="total">—</strong><small>tickets</small></div></div><div id="ov-legend" class="ov-legend"></div></div></div>
      <div class="ov-panel ov-performance"><div class="ov-panel-title"><b>Indicateurs de réponse</b></div><div class="ov-perf-value"><small>Première réponse moyenne*</small><strong id="ov-first-response">—</strong></div><p>*Calculée sur les tickets comportant une réponse identifiable d'un autre intervenant.</p></div>
    </section>
    <section class="ov-lower">
      <div class="ov-panel ov-listpanel"><div class="ov-panel-title"><b id="ov-list-title">Tickets récents</b><span id="ov-list-meta"></span></div>
        <div class="ov-filters"><select id="ov-status" aria-label="Filtrer par statut"><option value="">Tous les statuts</option><option value="open">Ouverts</option><option value="in_progress">En cours</option><option value="waiting">En attente</option><option value="resolved">Résolus</option><option value="closed">Fermés</option></select><select id="ov-client" aria-label="Filtrer par client"><option value="">Tous les clients</option></select><select id="ov-priority" aria-label="Filtrer par priorité"><option value="">Toutes les priorités</option></select><button id="ov-clear" type="button" class="ov-btn">Effacer</button></div>
        <div class="ov-table-scroll"><table class="ov-table"><thead><tr><th>Ticket</th><th>Sujet</th><th>Client</th><th>Priorité</th><th>Statut</th><th>Mise à jour</th></tr></thead><tbody id="ov-tbody"><tr><td colspan="6">Chargement...</td></tr></tbody></table></div>
        <div class="ov-table-footer"><span id="ov-pagination-count"></span><div><button type="button" id="ov-prev" class="ov-btn">← Précédent</button><button type="button" id="ov-next" class="ov-btn">Suivant →</button></div></div>
      </div>
      <aside class="ov-panel ov-sidepanel" aria-label="Synthèse">
        <div class="ov-panel-title"><b id="ov-right-title">Clients — tickets actifs</b></div><div id="ov-right-list" class="ov-ranks"></div>
        <div class="ov-panel-title ov-second-title"><b>Auteurs de tickets</b></div><div id="ov-owners" class="ov-ranks"></div>
      </aside>
    </section>
  </main>
</div>
<dialog id="ov-detail" class="ov-detail"><form method="dialog"><button class="ov-detail-close" aria-label="Fermer">×</button></form><div id="ov-detail-body"></div></dialog>
<script src="modules/dmd-ticketing/dmd-ticketing_overview.js?v=<?= (int)$jsV ?>" defer></script>
</div>
</body></html>
