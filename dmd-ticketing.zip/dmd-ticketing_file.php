<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/dmd-ticketing_lib.php';
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');

$me = dmdtk_user_email();
if ($me === '' || !dmdtk_has_module_access($me)) { http_response_code(403); exit('Accès refusé.'); }
$id = trim((string)($_GET['id'] ?? ''));
$file = basename((string)($_GET['file'] ?? ''));
if ($id === '' || $file === '' || $file === '.' || $file === '..') { http_response_code(400); exit('Fichier invalide.'); }
list($ticket, $ticketPath, $owner) = dmdtk_ticket_read($id);
if (!is_array($ticket) || !$ticket || !dmdtk_can_access_ticket($ticket, $me)) { http_response_code(404); exit('Fichier introuvable.'); }
$dir = dmdtk_files_dir((string)$ticket['owner'], $id, false);
$base = $dir !== '' ? realpath($dir) : false;
$target = $dir !== '' ? realpath($dir . '/' . $file) : false;
if (!$base || !$target || !is_file($target) || strpos($target, rtrim($base, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR) !== 0) { http_response_code(404); exit('Fichier introuvable.'); }
$mime = 'application/octet-stream';
if (function_exists('finfo_open')) {
    $fi = finfo_open(FILEINFO_MIME_TYPE);
    if ($fi) { $m = finfo_file($fi, $target); finfo_close($fi); if (is_string($m) && $m !== '') $mime = $m; }
}
$downloadName = $file;
foreach ((array)($ticket['messages'] ?? array()) as $message) {
    foreach ((array)($message['attachments'] ?? array()) as $attachment) {
        if (!is_array($attachment)) continue;
        if ((string)($attachment['stored_name'] ?? '') === $file && !empty($attachment['name'])) { $downloadName = basename((string)$attachment['name']); break 2; }
    }
}
header('Content-Type: ' . $mime);
header('Content-Length: ' . (string)filesize($target));
header('Content-Disposition: inline; filename="' . str_replace(array('"',"\r","\n"),'_',$downloadName) . '"');
header('Cache-Control: private, max-age=300');
readfile($target);
