# DMD-Ticketing

Système de tickets intégré à **DoMyDesk 1.2.0**, avec échanges, pièces jointes, partage entre utilisateurs ou rôles métier et synchronisation optionnelle avec **DomyCo**.

DMD-Ticketing est un module **hybride** : la configuration et l'index sont communs à l'installation, tandis que chaque ticket et ses fichiers restent stockés dans le profil de son propriétaire.

---

## Informations du module

| Élément | Valeur |
|---|---|
| Nom affiché | **DMD-Ticketing** |
| ID technique | `dmd-ticketing` |
| Version documentée | `2.0.2` |
| DoMyDesk minimum | `1.2.0` |
| Type de stockage | `hybrid` |
| Accès par défaut | `everyone` |
| Base de données | **Aucune** |
| Point d'entrée | `dmd-ticketing.php` |
| Configuration | `dmd-ticketingcfg.php` |
| API interne | `dmd-ticketing_api.php` |

---

## Objectif

DMD-Ticketing permet d'utiliser DoMyDesk comme système de suivi de demandes sans imposer une base SQL supplémentaire.

Un ticket peut rester entièrement local à l'instance DoMyDesk ou être envoyé à DomyCo pour créer une liaison avec le support central.

Le même module gère :

- les demandes privées ;
- les tickets partagés ;
- les échanges entre utilisateurs ;
- les pièces jointes ;
- les statuts ;
- les catégories et priorités ;
- les droits fins DoMyDesk ;
- la remontée vers DomyCo ;
- la récupération des réponses et changements de statut DomyCo ;
- la suppression synchronisée lorsqu'un ticket distant est supprimé.

---

## Fonctionnalités principales

### Création de tickets

Un utilisateur autorisé peut créer un ticket avec :

- un titre ;
- un message initial ;
- une catégorie ;
- une priorité ;
- des règles de partage ;
- l'option d'envoi vers DomyCo.

Chaque ticket reçoit un identifiant du type :

```text
T-YYYYMMDD-HHMMSS-xxxxxx
```

### Conversation

Chaque ticket contient une suite de messages horodatés.

Un message conserve notamment :

- son identifiant ;
- sa date ;
- son auteur ;
- le rôle de l'auteur dans le ticket ;
- son texte ;
- ses pièces jointes.

### Statuts

Les statuts disponibles sont :

```text
open        → Ouvert
in_progress → En cours
waiting     → En attente
resolved    → Résolu
closed      → Fermé
```

### Catégories par défaut

```text
Support
Bug
Amélioration
Demande
Incident
```

### Priorités par défaut

```text
Basse
Normale
Haute
Urgente
```

Les catégories et priorités sont configurables par un administrateur disposant du droit `admin.configure`.

---

## Interface utilisateur

L'écran principal fournit notamment :

- le nombre de tickets ouverts ;
- le nombre de tickets fermés ;
- le nombre de tickets appartenant à l'utilisateur ;
- le nombre de tickets partagés avec lui ;
- un bouton de création ;
- un bouton d'actualisation ;
- des filtres ;
- une recherche ;
- l'ouverture des tickets dans des fenêtres internes au dashboard.

### Filtres

Les tickets peuvent être filtrés par :

- statut ;
- vue ;
- catégorie ;
- priorité ;
- recherche texte.

La recherche porte notamment sur :

- le titre ;
- le propriétaire ;
- le dernier message.

### Vues

Selon les droits de l'utilisateur :

```text
Tous visibles
Mes tickets
Tous admin
```

La vue `Tous admin` nécessite un compte administrateur et la capacité `admin.view_all`.

---

## Partage des tickets

Un ticket peut être :

- privé ;
- partagé avec un ou plusieurs utilisateurs ;
- partagé avec un ou plusieurs rôles métier ;
- partagé avec tous les utilisateurs.

Le partage est stocké dans le ticket sous une structure comparable à :

```json
{
  "all": false,
  "users": ["user@example.com"],
  "roles": ["SUPPORT"]
}
```

### Important : un seul ticket, pas de copies

Le ticket reste physiquement stocké dans le profil de son **propriétaire**.

Les utilisateurs avec lesquels il est partagé ne reçoivent pas une copie indépendante : ils accèdent au même ticket via l'index système et les règles d'accès.

Cela évite les divergences entre plusieurs versions du même ticket.

---

## Gestion des droits

DMD-Ticketing déclare des capacités granulaires dans son manifeste DoMyDesk 1.2.0.

### Capacités utilisateur

| Capacité | Fonction |
|---|---|
| `view` | Voir les tickets accessibles |
| `ticket.create` | Créer un ticket |
| `ticket.reply` | Répondre à un ticket |
| `ticket.status` | Modifier le statut |
| `ticket.share` | Modifier le partage |
| `ticket.delete_own` | Supprimer son propre ticket |
| `ticket.sync` | Synchroniser avec DomyCo |
| `attachment.upload` | Ajouter des pièces jointes |

### Capacités administrateur

| Capacité | Fonction |
|---|---|
| `admin.view_all` | Voir tous les tickets |
| `admin.edit_any` | Modifier les tickets des autres utilisateurs |
| `admin.delete_any` | Supprimer les tickets des autres utilisateurs |
| `admin.configure` | Modifier la configuration générale du module |

Le module utilise les droits fournis par le Core DoMyDesk lorsque les fonctions correspondantes sont disponibles.

---

## Qui peut gérer un ticket ?

Le propriétaire peut gérer son propre ticket.

Un administrateur peut gérer le ticket d'un autre utilisateur uniquement s'il possède la capacité :

```text
admin.edit_any
```

Pour la suppression :

- le propriétaire doit posséder `ticket.delete_own` ;
- un administrateur supprimant le ticket d'un autre utilisateur doit posséder `admin.delete_any`.

---

## Pièces jointes

Les pièces jointes sont stockées dans le profil du propriétaire du ticket.

### Extensions acceptées

```text
jpg
jpeg
png
gif
webp
pdf
txt
log
csv
doc
docx
xls
xlsx
odt
ods
```

### Taille maximale

La limite appliquée par le module est :

```text
20 Mo par fichier
```

Les limites PHP du serveur (`upload_max_filesize`, `post_max_size`) peuvent toutefois être plus restrictives.

### Accès sécurisé aux fichiers

Un fichier n'est pas servi directement depuis son chemin physique.

L'accès passe par :

```text
dmd-ticketing_file.php
```

Avant de renvoyer le fichier, le module contrôle :

- la session utilisateur ;
- l'accès au module ;
- l'existence du ticket ;
- le droit de consulter le ticket ;
- que le chemin demandé reste bien dans le répertoire de pièces jointes du ticket.

Le type MIME est détecté avec `fileinfo` lorsque cette extension PHP est disponible.

---

## Stockage hybride

DMD-Ticketing ne nécessite aucune base de données.

### Données système

Les données communes sont enregistrées dans :

```text
data/modules/dmd-ticketing/
```

On y trouve notamment :

```text
config.json
index.json
outbox.json
migration_legacy_ticketing.json
```

#### `config.json`

Contient les catégories et priorités du module.

#### `index.json`

Index léger permettant de retrouver les tickets sans parcourir tous les profils utilisateur.

Il conserve notamment des informations comme :

- propriétaire ;
- statut ;
- partage ;
- dates ;
- indication de synchronisation DomyCo.

Le contenu complet du ticket reste dans le profil de son propriétaire.

#### `outbox.json`

File d'attente de synchronisation DomyCo.

Lorsqu'un envoi distant ne peut pas aboutir, le ticket peut rester localement en attente dans cette outbox au lieu d'être perdu.

#### `migration_legacy_ticketing.json`

Marqueur et rapport de la migration automatique de l'ancien module `ticketing`.

---

## Données utilisateur

Pour le propriétaire d'un ticket :

```text
users/profiles/[email]/dmd-ticketing/
├── .htaccess
├── tickets/
│   └── T-....json
└── files/
    └── T-..../
        └── pièces jointes
```

### Tickets

Chaque ticket possède son propre fichier JSON :

```text
users/profiles/[email]/dmd-ticketing/tickets/[ticket-id].json
```

### Pièces jointes

```text
users/profiles/[email]/dmd-ticketing/files/[ticket-id]/
```

Les dossiers sensibles sont protégés contre l'accès HTTP direct avec `.htaccess` lorsque le module les crée.

---

## Logs

DMD-Ticketing possède des logs **par utilisateur**.

Chemin :

```text
users/profiles/[email]/logs/dmd-ticketing/YYYY-MM-DD.json
```

Une entrée contient notamment :

```text
at       date/heure ISO
module   dmd-ticketing
email    utilisateur ayant effectué l'action
action   type d'action
target   ticket ou cible
status   résultat
details  informations complémentaires
ip       adresse IP vue par le serveur
```

Les actions journalisées par le code comprennent notamment :

- création ;
- réponse ;
- modification ;
- changement de statut ;
- fermeture ;
- réouverture ;
- synchronisation ;
- suppression ;
- suppression distante ;
- upload de pièce jointe ;
- modification de la configuration.

Pour limiter la taille d'un fichier quotidien, le module conserve au maximum les **2000 dernières entrées** du fichier concerné.

---

## Configuration administrateur

La configuration est accessible uniquement à un administrateur autorisé et disposant de :

```text
admin.configure
```

Elle permet actuellement de modifier :

- la liste des catégories ;
- la liste des priorités ;
- de superviser les tickets depuis l'interface d'administration du module.

Le fichier correspondant est :

```text
data/modules/dmd-ticketing/config.json
```

L'enregistrement est protégé par un jeton CSRF.

---

# Synchronisation DomyCo

La synchronisation avec DomyCo est **optionnelle par ticket**.

Lors de la création, l'utilisateur peut demander l'envoi vers DomyCo. Si l'option n'est pas cochée, le ticket reste uniquement local dans DoMyDesk.

---

## Endpoint central

La version documentée utilise l'endpoint interne suivant :

```text
https://register.synohomes.com/ticket.php
```

Cet endpoint n'est pas demandé à l'utilisateur dans la configuration du module.

Le module récupère l'identité de l'instance depuis :

```text
data/id_domydesk.txt
```

et peut compléter le contexte avec :

```text
data/domyco_register.json
```

---

## Informations d'instance transmises

Selon les données disponibles dans `domyco_register.json`, le contexte peut comprendre :

```text
instance_uid
instance_name
domain
install_url
version
```

ainsi que les informations nécessaires au ticket lui-même.

---

## Envoi d'un ticket

Lorsqu'un ticket est marqué pour DomyCo :

1. le ticket est créé localement ;
2. DoMyDesk tente l'envoi vers DomyCo ;
3. le résultat de synchronisation est enregistré dans `ticket.meta.domydesk` ;
4. si l'envoi échoue, le ticket reste local ;
5. l'opération peut être placée dans `outbox.json` ;
6. une synchronisation ultérieure peut retenter l'opération.

La création locale n'est donc pas perdue simplement parce que DomyCo est temporairement indisponible.

---

## Synchronisation automatique

Le module déclenche une synchronisation silencieuse toutes les :

```text
120 secondes
```

Le code évite également de relancer inutilement un ticket dont la dernière synchronisation date de moins de 120 secondes, sauf actualisation forcée.

La synchronisation silencieuse est évitée lorsque l'onglet est caché.

---

## Synchronisation manuelle

L'utilisateur peut forcer la récupération avec :

- le bouton **Actualiser** du module ;
- le bouton **Synchroniser DomyCo** à l'intérieur d'un ticket.

L'ouverture de la popup d'un ticket reste locale : elle n'attend pas une réponse de `register.synohomes.com`.

Cette séparation évite qu'une indisponibilité du service distant ne bloque simplement l'ouverture d'un ticket déjà présent dans DoMyDesk.

---

## Réponses venant de DomyCo

Lors d'une synchronisation, DMD-Ticketing peut récupérer :

- de nouveaux messages ;
- un changement de statut ;
- les pièces jointes renvoyées par le centre ;
- l'information indiquant qu'un ticket a été supprimé à distance.

Les messages distants sont ajoutés au même historique local avec le rôle :

```text
domydesk
```

et l'auteur retourné par le serveur central, avec comme valeur de secours :

```text
Support DomyCo
```

---

## Indicateur de nouveauté DomyCo

Lorsqu'une nouvelle réponse ou un nouveau statut arrive de DomyCo, le module conserve une information de notification dans :

```text
ticket.meta.domydesk.notification
```

L'interface DMD-Ticketing affiche alors un indicateur de nouveauté sur le ticket et dans son titre.

L'état peut être marqué comme lu par l'action `mark_read`.

Dans la version documentée, ce mécanisme est un **indicateur interne au module DMD-Ticketing** ; le code du module ne déclenche pas directement une notification générale de la cloche DoMyDesk via `dmd_notify_user()`.

---

## Synchronisation des pièces jointes

Lorsqu'un ticket synchronisé contient une pièce jointe locale, DMD-Ticketing tente d'envoyer le fichier à DomyCo.

La synchronisation distante des fichiers utilise :

```text
cURL
CURLFile
```

Si l'upload d'une pièce jointe distante échoue, le ticket peut rester en état `pending` et l'opération est conservée pour une nouvelle tentative.

Le fichier local reste dans DoMyDesk.

---

## Suppression et DomyCo

La suppression est volontairement prudente.

### Ticket local uniquement

Le ticket et son dossier de pièces jointes sont supprimés localement.

### Ticket lié à DomyCo

Avant d'effacer le ticket local, le module demande sa suppression à DomyCo.

Si la suppression distante échoue :

> **le ticket local est conservé.**

Cela évite de perdre la trace locale alors qu'un ticket existe encore côté DomyCo.

### Suppression effectuée depuis DomyCo

Lors d'une synchronisation, si DomyCo indique que le ticket a été supprimé à distance, DMD-Ticketing supprime également la copie locale et journalise l'action `remote_delete`.

---

## Migration depuis l'ancien module `ticketing`

DMD-Ticketing contient une migration automatique pour l'ancienne structure :

```text
modules/ticketing/
```

La migration peut récupérer :

- `config.json` ;
- `domydesk_outbox.json` ;
- les tickets ;
- les anciennes pièces jointes.

Les anciennes URLs de pièces jointes du type :

```text
modules/ticketing/tickets/...
```

sont également prises en compte pendant la migration.

Les données sont replacées dans la nouvelle architecture DoMyDesk 1.2.0.

Le rapport de migration est enregistré dans :

```text
data/modules/dmd-ticketing/migration_legacy_ticketing.json
```

---

## Sécurité

DMD-Ticketing applique plusieurs contrôles :

- session DoMyDesk obligatoire ;
- contrôle d'accès au module ;
- capacités granulaires ;
- jetons CSRF sur les actions d'écriture ;
- validation du droit d'accès à chaque ticket ;
- contrôle séparé pour gestion et suppression ;
- stockage protégé par `.htaccess` ;
- permissions de fichiers et dossiers restrictives ;
- chemins de pièces jointes contrôlés avec `realpath` ;
- noms de fichiers stockés générés côté serveur ;
- liste blanche d'extensions ;
- limite de 20 Mo par fichier ;
- `X-Content-Type-Options: nosniff` ;
- `X-Frame-Options: SAMEORIGIN` sur le service de fichiers.

---

## Permissions fichiers utilisées

Le module applique généralement :

```text
Dossiers : 0750
Fichiers : 0640
```

Les écritures JSON importantes utilisent un fichier temporaire puis un renommage, afin d'éviter autant que possible de laisser un JSON partiellement écrit.

L'index, l'outbox et les logs utilisent également des mécanismes de verrouillage lors des opérations sensibles.

---

## Structure du module

```text
modules/
└── dmd-ticketing/
    ├── dmd_module.json
    ├── icon.png
    ├── dmd-ticketing.php
    ├── dmd-ticketing.css
    ├── dmd-ticketing_lib.php
    ├── dmd-ticketing_api.php
    ├── dmd-ticketing_upload.php
    ├── dmd-ticketing_file.php
    └── dmd-ticketingcfg.php
```

### `dmd_module.json`

Manifeste DoMyDesk 1.2.0 et catalogue des capacités du module.

### `icon.png`

Icône utilisée par DoMyDesk.

### `dmd-ticketing.php`

Interface utilisateur principale.

### `dmd-ticketing.css`

Mise en forme du module.

### `dmd-ticketing_lib.php`

Bibliothèque commune : stockage, permissions, index, logs, migration, accès aux tickets et chemins de fichiers.

### `dmd-ticketing_api.php`

API interne du module : création, lecture, liste, réponses, statuts, partage, synchronisation et suppression.

### `dmd-ticketing_upload.php`

Réception et stockage sécurisé des pièces jointes.

### `dmd-ticketing_file.php`

Lecture contrôlée des pièces jointes pour les utilisateurs autorisés.

### `dmd-ticketingcfg.php`

Configuration administrateur des catégories/priorités et vue de supervision.

---

## Actions de l'API interne

La version documentée expose notamment les actions suivantes :

```text
bootstrap
list
sync_all
create
get
mark_read
reply
sync
update
close
reopen
delete
```

Cette API est prévue pour être appelée par l'interface DMD-Ticketing dans une session DoMyDesk valide, et non comme une API publique externe.

---

## Installation

Le dossier attendu est :

```text
modules/dmd-ticketing/
```

Le manifeste indique :

```text
storage_scope : hybrid
data_policy.create : install
preserve_on_update : true
```

L'installation prépare donc le stockage système du module, tandis que les dossiers utilisateurs sont créés lorsqu'ils sont nécessaires.

Aucune base SQL n'est à créer.

---

## Mise à jour

Les données runtime sont séparées du code du module.

Les éléments à préserver comprennent en particulier :

```text
data/modules/dmd-ticketing/
users/profiles/[email]/dmd-ticketing/
users/profiles/[email]/logs/dmd-ticketing/
```

Le manifeste déclare :

```text
preserve_on_update : true
```

---

## Sauvegarde complète

Pour sauvegarder DMD-Ticketing, conserver :

### Système

```text
data/modules/dmd-ticketing/
```

### Utilisateurs

Pour chaque utilisateur concerné :

```text
users/profiles/[email]/dmd-ticketing/
users/profiles/[email]/logs/dmd-ticketing/
```

Il n'y a aucune base SQL à dumper.

---

## Restauration

Pour restaurer le système :

1. restaurer le code du module ;
2. restaurer `data/modules/dmd-ticketing/` ;
3. restaurer les dossiers `dmd-ticketing/` dans les profils concernés ;
4. restaurer les logs si leur historique doit être conservé ;
5. vérifier les propriétaires et droits Unix ;
6. ouvrir le module et contrôler l'index et les tickets.

---

## Dépendances

### Obligatoires pour le fonctionnement local

- DoMyDesk `1.2.0` ou supérieur ;
- PHP compatible avec DoMyDesk ;
- extension JSON ;
- sessions PHP ;
- droits d'écriture dans les emplacements de données DoMyDesk.

### Pour la synchronisation DomyCo

Un accès réseau HTTPS à :

```text
register.synohomes.com
```

est nécessaire.

Le module sait envoyer le JSON avec cURL lorsqu'il est disponible et possède un fallback HTTP pour l'échange JSON.

### Pour les pièces jointes vers DomyCo

`cURL` et `CURLFile` sont nécessaires à l'upload distant des fichiers.

### Optionnel

L'extension PHP `fileinfo` permet de détecter plus précisément le type MIME lorsqu'un fichier est affiché.

---

## Dépannage

### Le module affiche « Accès non autorisé »

Vérifier :

- que le module est autorisé pour l'utilisateur ;
- son rôle métier ;
- les exceptions utilisateur ;
- ses capacités DMD-Ticketing.

### Un ticket partagé n'est pas visible

Vérifier le champ `share` du ticket :

- `all` ;
- liste `users` ;
- liste `roles`.

Pour un partage par rôle, vérifier également `role_metier` dans le profil de l'utilisateur.

### Un ticket DomyCo reste en attente

Contrôler :

```text
data/modules/dmd-ticketing/outbox.json
```

puis vérifier :

- l'accès à `register.synohomes.com` ;
- `data/id_domydesk.txt` ;
- les logs utilisateur DMD-Ticketing ;
- la réponse de synchronisation affichée dans le ticket.

### Les pièces jointes fonctionnent localement mais pas vers DomyCo

Vérifier que PHP possède :

```text
curl
CURLFile
```

et que la taille du fichier ne dépasse pas 20 Mo ni les limites PHP du serveur.

### Une suppression DomyCo échoue

Le comportement normal du module est de **conserver le ticket local** si la suppression distante n'est pas confirmée.

### Un fichier retourne « Fichier introuvable »

Le module masque volontairement certaines différences entre fichier absent et accès interdit.

Vérifier que :

- l'utilisateur peut consulter le ticket ;
- le fichier existe dans le dossier du propriétaire ;
- l'entrée de pièce jointe du ticket correspond au fichier stocké.

---

## Contrat DoMyDesk 1.2.0

Le manifeste documenté déclare notamment :

```text
schema         : 1
id             : dmd-ticketing
name           : DMD-Ticketing
version        : 2.0.2
min_domydesk   : 1.2.0
storage_scope  : hybrid
default_access : everyone
entrypoint     : dmd-ticketing.php
config         : dmd-ticketingcfg.php
package.strict : true
```

Si ce README est ajouté **dans le ZIP strict du module**, il doit également être déclaré dans `package.files` de `dmd_module.json`. Il peut sinon être distribué séparément avec le package ou sur le dépôt du module.

---

## Résumé de l'architecture

```text
                           ┌────────────────────┐
                           │     DoMyDesk       │
                           │    DMD-Ticketing   │
                           └─────────┬──────────┘
                                     │
                   ┌─────────────────┴─────────────────┐
                   │                                   │
         Données système                        Données utilisateur
 data/modules/dmd-ticketing/          users/profiles/[email]/dmd-ticketing/
                   │                                   │
        config / index / outbox              tickets / pièces jointes
                   │                                   │
                   └──────────────┬────────────────────┘
                                  │
                         Synchronisation optionnelle
                                  │
                                  ▼
                              DomyCo
```

DMD-Ticketing conserve ainsi la philosophie DoMyDesk : **pas de base de données imposée, données utilisateur séparées, droits centralisés par le Core et synchronisation distante uniquement lorsqu'elle est demandée.**
