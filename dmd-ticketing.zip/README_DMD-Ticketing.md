# DMD-Ticketing — Vue d'ensemble 2.1.1

## Accès immédiat aux autorisations

1. Ouvrir **le module DMD-Ticketing depuis le dashboard** avec un compte **administrateur**.
2. Cliquer sur **⚙ Droits vue d’ensemble** (bouton visible même si personne n’est encore autorisé).
3. Cocher **Interface** pour chaque utilisateur autorisé, administrateur compris.
4. Cocher, indépendamment, **Tous les tickets** pour autoriser la consultation globale.
5. Cliquer sur **Enregistrer les droits**.
6. Si votre compte a été autorisé, cliquer sur **Vue d’ensemble** depuis la page des droits, ou actualiser le module Ticketing pour faire apparaître son bouton **▦ Vue d’ensemble**.

**Le droit d’ouvrir la page est vérifié côté serveur sur chaque demande.** Le bouton est masqué pour les comptes non autorisés. Les administrateurs n’ont pas accès à la vue d’ensemble sans attribution explicite, mais peuvent toujours en gérer les droits.

## Données et périmètre

- Interface sans « Tous les tickets » : tickets personnels ou partagés seulement.
- Interface avec « Tous les tickets » : tous les tickets présents dans l’index du module.
- Statistiques de synthèse et de tendance 30 jours, recherche, filtres, répartition, tableaux et détail en lecture seule.
- Le calcul des délais de première réponse ne s’effectue que si les messages contiennent les horodatages nécessaires.
- Le module ne crée ni techniciens fictifs, ni SQL, ni données de démonstration.
- Les tickets existants, les pièces jointes, le système d’authentification et les autres modules ne sont pas modifiés.
- Les autorisations sont enregistrées dans `data/modules/dmd-ticketing/overview_acl.json`.

## Installation du correctif

**Important : il s’agit d’un ZIP de fichiers modifiés et ajoutés, pas d’un paquet complet à importer comme un nouveau module.**

1. Sauvegarder le dossier existant `/volume1/web/domydesk/modules/dmd-ticketing/`.
2. Extraire le ZIP à la **racine `/volume1/web/domydesk/`**, en autorisant l’écrasement des seuls fichiers contenus dans l’archive.
3. Vérifier que le fichier `/volume1/web/domydesk/modules/dmd-ticketing/dmd-ticketing_overview_access.php` existe.
4. Actualiser le dashboard, puis ouvrir **DMD-Ticketing**. Le bouton **⚙ Droits vue d’ensemble** doit apparaître pour un admin.
5. En cas de cache, rafraîchir le navigateur avec Ctrl+F5.

Tous les fichiers du ZIP sont sous `modules/dmd-ticketing/`. Aucun changement dans le cœur de DoMyDesk ni dans DMD-Agent.
