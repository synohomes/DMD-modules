<div class="bn-shell" data-bn-screen="list">
  <header class="bn-top">
    <div class="bn-heading"><span class="bn-app-symbol" aria-hidden="true">▤</span><span><strong>Bloc-notes</strong><small>Mon espace de notes</small></span></div>
    <div class="bn-top-buttons">
      <button type="button" class="bn-btn-icon" data-bn-act="refresh" title="Actualiser les notes" aria-label="Actualiser">↻</button>
      <button type="button" class="bn-btn bn-view-toggle" data-bn-act="toggle-board" title="Afficher plusieurs notes en entier">▦ Mur</button>
      <button type="button" class="bn-btn bn-btn-primary" data-bn-act="new">+ Note</button>
    </div>
  </header>
  <div class="bn-workarea">
    <aside class="bn-rail" aria-label="Catégories et filtres">
      <div class="bn-rail-heading">BIBLIOTHÈQUE</div>
      <button type="button" class="bn-rail-link is-active" data-bn-filter="all">Toutes <span data-bn-count="all">0</span></button>
      <button type="button" class="bn-rail-link" data-bn-filter="pinned">Épinglées <span data-bn-count="pinned">0</span></button>
      <button type="button" class="bn-rail-link" data-bn-filter="favorites">Favoris <span data-bn-count="favorites">0</span></button>
      <button type="button" class="bn-rail-link" data-bn-filter="shared">Partagées <span data-bn-count="shared">0</span></button>
      <button type="button" class="bn-rail-link" data-bn-filter="archived">Archives <span data-bn-count="archived">0</span></button>
      <button type="button" class="bn-categories-trigger" data-bn-act="categories" title="Gérer les catégories" aria-label="Gérer les catégories">＋</button>
      <div class="bn-rail-categories"></div>
      <button type="button" class="bn-rail-link bn-trash-link" data-bn-filter="trash">Corbeille <span data-bn-count="trash">0</span></button>
    </aside>
    <section class="bn-content" aria-label="Notes">
      <div class="bn-list-screen" data-bn-panel="list">
        <div class="bn-tools"><label class="bn-search"><span>⌕</span><input type="search" placeholder="Rechercher..." data-bn-search aria-label="Rechercher des notes"></label>
          <select data-bn-select-filter aria-label="Catégorie" class="bn-mobile-filter"><option value="all">Toutes les notes</option></select>
          <select data-bn-sort aria-label="Trier les notes"><option value="recent">Récentes</option><option value="title">A → Z</option><option value="created">Création</option></select><button type="button" class="bn-btn-icon bn-manage-cats" data-bn-act="categories-compact" title="Gérer les catégories" aria-label="Gérer les catégories">＋</button></div>
        <div class="bn-list-caption"><strong data-bn-list-title>Toutes les notes</strong><div class="bn-list-options"><small data-bn-total>0 notes</small><span class="bn-wall-controls" hidden><button class="bn-btn-icon" data-bn-act="wall-smaller" title="Notes plus compactes">−</button><button class="bn-btn-icon" data-bn-act="wall-larger" title="Notes plus grandes">+</button></span></div></div>
        <div class="bn-notes" data-bn-notes><p class="bn-empty">Chargement des notes…</p></div>
      </div>
      <div class="bn-edit-screen" data-bn-panel="edit" hidden>
        <header class="bn-edit-title"><button type="button" class="bn-btn-icon" data-bn-act="back" title="Retour" aria-label="Retour">←</button><strong data-bn-edit-label>Nouvelle note</strong><span class="bn-flex"></span><button type="button" class="bn-btn-icon" data-bn-act="share-current" title="Partager la note" aria-label="Partager la note">⇪</button><button type="button" class="bn-btn-icon" data-bn-act="export-current" title="Exporter en TXT" aria-label="Exporter">⇩</button></header>
        <div class="bn-edit-fields">
          <input data-bn-title maxlength="160" placeholder="Titre de la note" aria-label="Titre" autocomplete="off">
          <div class="bn-edit-options">
            <select data-bn-category aria-label="Catégorie"></select>
            <select data-bn-kind aria-label="Type de note"><option value="text">Texte</option><option value="checklist">Liste de tâches</option></select>
            <input type="color" data-bn-color value="#6488e8" aria-label="Couleur de la note">
            <button type="button" class="bn-btn-icon" data-bn-act="pin" title="Épingler" aria-label="Épingler">◆</button>
            <button type="button" class="bn-btn-icon" data-bn-act="favorite" title="Favori" aria-label="Favori">★</button>
          </div>
          <div class="bn-creator-info" data-bn-editor-meta hidden></div>
          <div class="bn-task-editor" data-bn-task-editor hidden><div class="bn-task-header"><strong>Tâches à effectuer</strong><button type="button" class="bn-btn" data-bn-act="task-add">+ Tâche</button></div><div class="bn-task-items" data-bn-task-items></div></div>
          <textarea data-bn-body placeholder="Écrivez votre note ici…" maxlength="100000" aria-label="Contenu de la note" spellcheck="true"></textarea>
          <small class="bn-edit-tip" data-bn-task-tip hidden>Cochez les tâches terminées ; ajoutez, modifiez ou supprimez les lignes directement.</small>
        </div>
        <footer class="bn-edit-actions"><span data-bn-edit-status></span><button type="button" class="bn-btn" data-bn-act="cancel">Annuler</button><button type="button" class="bn-btn bn-btn-primary" data-bn-act="save">Enregistrer</button></footer>
      </div>
      <div class="bn-read-screen" data-bn-panel="read" hidden><header class="bn-edit-title"><button type="button" class="bn-btn-icon" data-bn-act="back">←</button><strong data-bn-read-title></strong><span class="bn-flex"></span><button type="button" class="bn-btn" data-bn-act="reader-copy">Copier dans mes notes</button></header><small class="bn-read-author" data-bn-read-by></small><article class="bn-read-body" data-bn-read-body></article></div>
      <div class="bn-categories-screen" data-bn-panel="categories" hidden>
        <header class="bn-edit-title"><button type="button" class="bn-btn-icon" data-bn-act="back" aria-label="Retour">←</button><strong>Catégories</strong></header>
        <div class="bn-category-table" data-bn-category-table></div>
        <form data-bn-cat-form class="bn-cat-new"><input type="text" name="name" maxlength="45" placeholder="Nouvelle catégorie" required aria-label="Nom de catégorie"><input type="color" name="color" value="#6488e8" aria-label="Couleur"><button class="bn-btn bn-btn-primary" type="submit">Ajouter</button></form>
      </div>
    </section>
  </div>
  <div class="bn-share-overlay" data-bn-share-overlay hidden>
    <section class="bn-share-dialog" role="dialog" aria-modal="true" aria-labelledby="bn-share-heading">
      <header class="bn-share-head"><div><small>COLLABORATION</small><strong id="bn-share-heading">Partager une note</strong></div><button type="button" class="bn-btn-icon" data-bn-act="close-share" aria-label="Fermer">×</button></header>
      <div class="bn-share-body"><p data-bn-share-title></p><div class="bn-share-target"><label for="bn-share-type">Partager avec</label><select id="bn-share-type" data-bn-share-type><option value="user">Un utilisateur</option><option value="group">Un groupe DoMyDesk</option></select></div><label data-bn-share-label>Utilisateur DoMyDesk</label><div class="bn-share-input"><input type="email" data-bn-share-email list="bn-share-users" placeholder="nom@domaine.fr" autocomplete="off"><datalist id="bn-share-users" data-bn-share-users></datalist><select data-bn-share-group aria-label="Groupe DoMyDesk" hidden><option value="">Choisir un groupe…</option></select><button type="button" class="bn-btn bn-btn-primary" data-bn-act="send-share">Partager</button></div><small>Notes en lecture seule, listes de tâches collaboratives : les membres peuvent cocher les tâches. Une notification DoMyDesk est envoyée aux participants. Accès révocable.</small><div class="bn-share-recipients" data-bn-share-recipients></div><div class="bn-share-divider"></div><button type="button" class="bn-btn" data-bn-act="share-text">Copier le texte de la note</button></div>
    </section>
  </div>
  <footer class="bn-bottom"><span data-bn-state>Connecté à DoMyDesk</span><div><button type="button" data-bn-act="export-all" title="Sauvegarder les notes en JSON">Sauvegarde</button><button type="button" data-bn-act="import" title="Importer une sauvegarde JSON">Importer</button><input data-bn-import type="file" accept=".json,application/json" hidden></div></footer>
  <output class="bn-alert" data-bn-alert role="status" aria-live="polite" hidden></output>
</div>
