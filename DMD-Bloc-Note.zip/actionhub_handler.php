<?php
/** Actions natives ActionHub pour DMD-Bloc-Note. Les permissions sont revalidées ici. */
require_once __DIR__.'/dmd-bloc-note_lib.php';
function dmd_bn_actionhub_handle(array $ctx){
    $email=trim((string)($ctx['email']??''));
    if($email==='' || strcasecmp($email,bn_me())!==0)return ['ok'=>false,'error'=>'user_context_mismatch','message'=>'Session utilisateur invalide.'];
    $action=(string)($ctx['action']['id']??'');
    $required=$action==='note.trash'?'notes.delete':'notes.write';
    if(!bn_can($required))return ['ok'=>false,'error'=>'permission_denied','message'=>'Accès refusé.'];
    $id=trim((string)($ctx['resource']['id']??''));
    $payload=is_array($ctx['payload']??null)?$ctx['payload']:[];
    try{
        if($action==='note.create'){
            $title=bn_trim($payload['title']??'',160);
            $body=bn_trim($payload['body']??'',100000);
            if($title==='')return ['ok'=>false,'error'=>'title_required','message'=>'Titre obligatoire.'];
            $kind=($payload['kind']??'text')==='checklist'?'checklist':'text';
            $record=bn_tx(function(&$d)use($title,$body,$kind){
                $now=gmdate('c');
                $record=['id'=>bin2hex(random_bytes(12)),'title'=>$title,'body'=>$body,'kind'=>$kind,'category'=>'general','color'=>'#6488e8','created_at'=>$now,'created_by'=>bn_me(),'updated_at'=>$now,'archived_at'=>null,'deleted_at'=>null,'pinned'=>false,'favorite'=>false,'shared_with'=>[]];
                $d['notes'][]=$record;return $record;
            });
        }elseif(in_array($action,['note.pin','note.archive','note.restore_archive','note.trash'],true)){
            if($id===''||!preg_match('/^[a-zA-Z0-9_-]{1,80}$/',$id))return ['ok'=>false,'error'=>'invalid_note','message'=>'Identifiant invalide.'];
            $record=bn_tx(function(&$d)use($id,$action){
                foreach($d['notes'] as &$note){
                    if(($note['id']??'')!==$id||!empty($note['deleted_at']))continue;
                    $now=gmdate('c');
                    if($action==='note.pin')$note['pinned']=empty($note['pinned']);
                    elseif($action==='note.archive')$note['archived_at']=$now;
                    elseif($action==='note.restore_archive')$note['archived_at']=null;
                    else $note['deleted_at']=$now;
                    $note['updated_at']=$now;return $note;
                }
                throw new RuntimeException('Note introuvable ou inaccessible.');
            });
        }else return ['ok'=>false,'error'=>'unknown_action','message'=>'Action inconnue.'];
        $event=bn_emit($action,$record,'Action lancée depuis ActionHub');
        return ['ok'=>true,'message'=>'Bloc-notes mis à jour.','event_emitted'=>!empty($event['ok']),'data'=>['id'=>$record['id'],'title'=>$record['title']]];
    }catch(Throwable $e){return ['ok'=>false,'error'=>'operation_failed','message'=>$e->getMessage()];}
}
