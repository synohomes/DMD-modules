<?php
/* DMD-Bloc-Note 1.1.0 — stockage natif utilisateur / gestion des droits DoMyDesk */
if (session_status() === PHP_SESSION_NONE) session_start();
function bn_root(){return dirname(__DIR__,2);}
function bn_me(){return trim((string)($_SESSION['user']['email']??''));}
function bn_module_id(){return basename(__DIR__);}
function bn_boot(){ $file=bn_root().'/core/dmd_permissions.php'; if(is_file($file)) require_once $file; }
function bn_can($p='view'){
  $email=bn_me(); if($email==='') return false;
  bn_boot();
  if(function_exists('dmd_user_has_module_permission')) return (bool)dmd_user_has_module_permission($email,bn_module_id(),$p);
  return $p==='view';
}
function bn_data_dir(){
  bn_boot();
  $email=bn_me();if($email==='')throw new RuntimeException('Utilisateur non connecté');
  if(function_exists('dmd_user_module_data_dir')){
    $dir=dmd_user_module_data_dir($email,bn_module_id(),true);
    if($dir===''||!is_dir($dir)) throw new RuntimeException('Stockage personnel indisponible');
    return rtrim($dir,'/\\');
  }
  $dir=bn_root().'/users/profiles/'.$email.'/'.bn_module_id();
  if(!is_dir($dir)&&!@mkdir($dir,0750,true)&&!is_dir($dir))throw new RuntimeException('Stockage indisponible');
  if(!is_file($dir.'/.htaccess')) @file_put_contents($dir.'/.htaccess',"Options -Indexes\nRequire all denied\n");
  return $dir;
}
function bn_user_path(){
  $dir=bn_data_dir();$target=$dir.'/notes.json';
  if(!file_exists($target)){
    $other=bn_root().'/users/profiles/'.bn_me().'/dmd-bloc-note/notes.json';
    if($other!==$target && is_file($other) && is_readable($other)){$raw=@file_get_contents($other);$decoded=json_decode((string)$raw,true);if(is_array($decoded))@file_put_contents($target,$raw,LOCK_EX);}
    // Migration non destructive des versions 1.0.x (stockage commun haché).
    $old=bn_root().'/data/modules/dmd-bloc-note/'.hash('sha256',strtolower(bn_me())).'.json';
    if(!is_file($target)&&is_file($old)&&is_readable($old)){
      $raw=@file_get_contents($old);$decoded=json_decode((string)$raw,true);
      if(is_array($decoded)) @file_put_contents($target,$raw,LOCK_EX);
    }
  }
  return $target;
}
function bn_default(){return ['version'=>1,'categories'=>[['id'=>'general','name'=>'Général','color'=>'#6488e8'],['id'=>'travail','name'=>'Travail','color'=>'#4dbbaa'],['id'=>'personnel','name'=>'Personnel','color'=>'#c18deb']],'notes'=>[]];}
function bn_read($h){rewind($h);$raw=stream_get_contents($h);if($raw===false)throw new RuntimeException('Lecture des notes impossible');if(trim($raw)==='')return bn_default();$obj=json_decode($raw,true);if(!is_array($obj)||!isset($obj['categories'],$obj['notes'])||!is_array($obj['categories'])||!is_array($obj['notes']))throw new RuntimeException('Fichier de notes illisible : aucune donnée écrasée');return array_replace(bn_default(),$obj);}
function bn_tx($fn,$write=true){
  $f=bn_user_path();$h=@fopen($f,'c+');if(!$h)throw new RuntimeException('Impossible d’ouvrir les notes');
  try{
    if(!flock($h,$write?LOCK_EX:LOCK_SH)) throw new RuntimeException('Verrou impossible');
    $d=bn_read($h);$out=$fn($d);
    if($write){
      $json=json_encode($d,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_INVALID_UTF8_SUBSTITUTE);
      if($json===false)throw new RuntimeException('Erreur encodage des notes');
      rewind($h);if(!ftruncate($h,0))throw new RuntimeException('Troncature impossible');
      $size=strlen($json);$written=0;
      while($written<$size){$n=fwrite($h,substr($json,$written));if($n===false||$n===0)throw new RuntimeException('Écriture impossible');$written+=$n;}
      fflush($h);@chmod($f,0640);
    }
    flock($h,LOCK_UN);return $out;
  } finally {fclose($h);}
}
function bn_trim($s,$max=10000){if(!is_scalar($s))return ''; $s=trim((string)$s);return function_exists('mb_substr')?mb_substr($s,0,$max):substr($s,0,$max);}
function bn_error($msg,$status=400){http_response_code($status);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'error'=>$msg],JSON_UNESCAPED_UNICODE);exit;}
function bn_token(){if(empty($_SESSION['bn_csrf']))$_SESSION['bn_csrf']=bin2hex(random_bytes(24));return $_SESSION['bn_csrf'];}
function bn_color($c){return is_string($c)&&preg_match('/^#[0-9a-fA-F]{6}$/',$c)?$c:'#6488e8';}
function bn_category($d,$id){foreach($d['categories'] as $cat)if($cat['id']===$id)return true;return false;}

/* Partage privé : les accès sont vérifiés au moment de chaque lecture.
 * Aucun document n'est exposé par URL publique. */
function bn_existing_user($email) {
  $email = strtolower(trim((string)$email));
  if (!filter_var($email, FILTER_VALIDATE_EMAIL) || (strpos($email,'/')!==false || strpos($email,chr(92))!==false)) return false;
  bn_boot();
  $dir = bn_root().'/users/profiles/'.$email;
  if (!is_dir($dir)) return false;
  if (function_exists('dmd_read_profile')) {
    $profile = dmd_read_profile($email);
    return is_array($profile) && !empty($profile);
  }
  return false;
}
function bn_users_list() {
  bn_boot(); $result=[]; $base=bn_root().'/users/profiles/';
  foreach (glob($base.'*', GLOB_ONLYDIR) ?: [] as $dir) {
    $email=strtolower(basename($dir));
    if ($email===strtolower(bn_me()) || !bn_existing_user($email)) continue;
    $profile=dmd_read_profile($email);
    $name=trim((string)($profile['first_name']??$profile['prenom']??'').' '.(string)($profile['last_name']??$profile['nom']??''));
    $result[]=['email'=>$email,'name'=>$name!==''?$name:$email];
    if(count($result)>=500)break;
  }
  usort($result,function($a,$b){return strcasecmp($a['name'],$b['name']);});
  return $result;
}
/* Groupes DoMyDesk (gérés par DMD-Agent) et groupes des rôles DoMyDesk.
   Leur composition est résolue à chaque accès : aucun destinataire ne conserve
   un droit après son retrait du groupe. */
function bn_groups_list(){
  static $cached=null;
  if(is_array($cached))return $cached;
  $groups=[];
  $file=bn_root().'/var/agent/access/user_groups.php';
  if(is_file($file)&&is_readable($file)){
    $raw=(string)@file_get_contents($file);
    $guard="<?php http_response_code(404); header('Cache-Control: no-store'); exit; ?>\n";
    if(strncmp($raw,$guard,strlen($guard))===0){
      $decoded=json_decode(substr($raw,strlen($guard)),true);
      foreach(($decoded['groups']??[]) as $key=>$g){
        if(!is_array($g))continue;
        $id='agent:'.(string)$key;
        $members=[];
        foreach(($g['users']??[]) as $email){
          $email=strtolower(trim((string)$email));
          if(bn_existing_user($email))$members[$email]=$email;
        }
        $groups[$id]=['id'=>$id,'name'=>bn_trim($g['name']??$key,110),'source'=>'DoMyDesk · Groupes utilisateurs','members'=>array_values($members)];
      }
    }
  }
  // Les rôles métier DoMyDesk sont des groupes natifs de la plateforme.
  $service=bn_root().'/core/dmd_system_services.php';
  if(is_file($service)){
    require_once $service;
    if(function_exists('dmd_notification_index')){
      $index=dmd_notification_index();
      foreach(($index['role_metier']??[]) as $role=>$emails){
        if(!is_array($emails)||trim((string)$role)==='')continue;
        $members=[];
        foreach($emails as $email){$email=strtolower(trim((string)$email));if(bn_existing_user($email))$members[$email]=$email;}
        if($members)$groups['role:'.(string)$role]=['id'=>'role:'.(string)$role,'name'=>ucfirst(str_replace('_',' ',(string)$role)),'source'=>'DoMyDesk · Rôles métier','members'=>array_values($members)];
      }
    }
  }
  uasort($groups,function($a,$b){return strcasecmp($a['name'],$b['name']);});
  return $cached=$groups;
}
function bn_group_ids($note){
  $ids=[];
  foreach(($note['shared_groups']??[]) as $id)if(is_string($id)&&strlen($id)<=200)$ids[$id]=$id;
  return array_values($ids);
}
function bn_share_targets($note,$owner){
  $users=[];
  foreach(($note['shared_with']??[]) as $email){
    $email=strtolower(trim((string)$email));if(bn_existing_user($email))$users[$email]=$email;
  }
  $groups=bn_groups_list();
  foreach(bn_group_ids($note) as $id){
    if(!isset($groups[$id]))continue;
    foreach($groups[$id]['members'] as $email)$users[$email]=$email;
  }
  unset($users[strtolower($owner)]);
  return array_values($users);
}
function bn_group_labels($note){
  $all=bn_groups_list();$out=[];
  foreach(bn_group_ids($note) as $id)$out[]=['id'=>$id,'name'=>$all[$id]['name']??'Groupe supprimé','valid'=>isset($all[$id])];
  return $out;
}
function bn_has_shared_access($note,$owner,$recipient){
  return in_array(strtolower($recipient),bn_share_targets($note,$owner),true);
}
function bn_tx_external_note($owner,$callback){
  $file=strtolower($owner)===strtolower(bn_me())?bn_user_path():bn_external_path($owner);
  if($file==='')throw new RuntimeException('Note introuvable ou inaccessible');
  $h=@fopen($file,'c+');if(!$h)throw new RuntimeException('Impossible de lire cette note');
  try{
    if(!flock($h,LOCK_EX))throw new RuntimeException('Verrouillage impossible');
    $data=bn_read($h);$result=$callback($data);
    if(!empty($result['changed'])){
      $json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_INVALID_UTF8_SUBSTITUTE);
      if($json===false)throw new RuntimeException('Encodage impossible');
      rewind($h);if(!ftruncate($h,0))throw new RuntimeException('Écriture impossible');
      $len=strlen($json);$i=0;
      while($i<$len){$n=fwrite($h,substr($json,$i));if($n===false||$n===0)throw new RuntimeException('Écriture interrompue');$i+=$n;}
      fflush($h);
    }
    flock($h,LOCK_UN);return $result;
  }finally{fclose($h);}
}
function bn_notify_people($emails,$type,$title,$message,$note,$actor){
  $service=bn_root().'/core/dmd_system_services.php';
  if(!is_file($service))return 0;
  require_once $service;
  if(!function_exists('dmd_notify_many'))return 0;
  $receivers=[];
  foreach($emails as $email){$email=strtolower(trim((string)$email));if($email!==strtolower($actor)&&bn_existing_user($email))$receivers[$email]=$email;}
  if(!$receivers)return 0;
  return dmd_notify_many(array_values($receivers),$type,$title,$message,['level'=>'info',
    'action_url'=>'dashboard.php','action_label'=>'Ouvrir DoMyDesk',
    'meta'=>['module'=>'DMD-Bloc-Note','note_id'=>$note['id']??'','owner'=>$note['created_by']??'']]);
}
function bn_external_path($owner) {
  if (!bn_existing_user($owner)) return '';
  bn_boot();
  $mid=bn_module_id();
  $dir=function_exists('dmd_user_module_data_dir') ? dmd_user_module_data_dir($owner,$mid,false) : bn_root().'/users/profiles/'.$owner.'/'.$mid.'/';
  $file=rtrim((string)$dir,'/\\').'/notes.json';
  return is_file($file) ? $file : '';
}
function bn_shared_from($owner,$recipient,$noteId='') {
  $file=bn_external_path($owner);if($file==='')return [];
  $handle=@fopen($file,'rb');if(!$handle)return [];
  try {
    if(!flock($handle,LOCK_SH))return [];
    $raw=stream_get_contents($handle);flock($handle,LOCK_UN);
    $data=json_decode((string)$raw,true);
    if(!is_array($data)||!is_array($data['notes']??null))return [];
    $out=[];
    foreach($data['notes'] as $n){
      if(!is_array($n)||!empty($n['deleted_at']))continue;
      if($noteId!==''&&($n['id']??'')!==$noteId)continue;
      if(!bn_has_shared_access($n,$owner,$recipient))continue;
      unset($n['shared_with']);
      $n['shared']=true;$n['shared_by']=$owner;$n['shared_group_labels']=bn_group_labels($n); $n['created_by']=$n['created_by']??$owner; $n['created_by_name']=bn_display_name($n['created_by']); $n['shared_by_name']=bn_display_name($owner);
      $out[]=$n;
    }
    return $out;
  } finally {fclose($handle);}
}
function bn_shared_inbox(){
  $email=strtolower(bn_me()); $notes=[];$base=bn_root().'/users/profiles/';
  foreach(glob($base.'*',GLOB_ONLYDIR) ?: [] as $dir){
    $owner=basename($dir);if(strtolower($owner)===$email)continue;
    foreach(bn_shared_from($owner,$email) as $note)$notes[]=$note;
  }
  usort($notes,function($a,$b){return strcmp((string)($b['updated_at']??''),(string)($a['updated_at']??''));});
  return $notes;
}

/* Métadonnées auteur affichées même pour les notes existantes. */
function bn_display_name($email){
  $email=trim((string)$email);
  if($email==='')return 'Utilisateur';
  if($email!==bn_me() && !bn_existing_user($email))return $email;
  bn_boot();
  if(function_exists('dmd_read_profile')){
    $profile=dmd_read_profile($email);
    if(is_array($profile)){
      $name=trim((string)($profile['first_name']??$profile['prenom']??'').' '.(string)($profile['last_name']??$profile['nom']??''));
      if($name!=='')return $name;
    }
  }
  return $email;
}
/* ActionHub + QuickSession utilisent le bus d'activité natif (pas de simulacre de métadonnées). */
function bn_emit($action,$note,$details=''){
  try{
    $file=bn_root().'/dmd_runtime.php';
    if(!is_file($file))return false;
    require_once $file;
    if(!function_exists('dmd_module_event'))return false;
    $id=trim((string)($note['id']??''));
    if($id==='')return false;
    $label=trim((string)($note['title']??$note['name']??'Note'));
    return dmd_module_event('DMD-Bloc-Note',$action,['type'=>'note','id'=>$id,'name'=>$label,'source'=>'DMD-Bloc-Note'],['email'=>bn_me(),'status'=>'success','label'=>$action,'target'=>$label,'details'=>$details]);
  }catch(Throwable $e){error_log('DMD-Bloc-Note événement : '.$e->getMessage());return false;}
}
