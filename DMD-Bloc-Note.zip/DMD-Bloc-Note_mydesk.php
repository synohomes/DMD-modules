<?php
/** Standalone MyDesk WebView2 surface. No dashboard chrome or iframe. */
require_once __DIR__.'/dmd-bloc-note_lib.php';
if (!bn_can('view')) {http_response_code(403);echo '<!doctype html><html lang="fr"><meta charset="utf-8"><body>Accès refusé ou session expirée.</body></html>';exit;}
$root=bn_root(); $email=bn_me(); $theme='default';
$themePath=$root.'/users/profiles/'.$email.'/theme.json';
if(is_file($themePath)){
 $opts=json_decode((string)@file_get_contents($themePath),true);
 $chosen=basename((string)($opts['theme']??''));
 if($chosen!=='' && is_file($root.'/theme/'.$chosen.'/style.css')) $theme=$chosen;
}
if($theme==='default'){
  $profileFile=$root.'/users/profiles/'.$email.'/profile.json';
  if(is_file($profileFile)){
    $p=json_decode((string)@file_get_contents($profileFile),true);
    $chosen=basename((string)($p['theme']??''));
    if($chosen!==''&&is_file($root.'/theme/'.$chosen.'/style.css'))$theme=$chosen;
  }
}
$dir='modules/'.rawurlencode(basename(__DIR__)).'/';
$ver=(int)(@filemtime(__DIR__.'/dmd-bloc-note.js')?:time());
$cssVer=substr(hash_file('sha256',__DIR__.'/dmd-bloc-note.css'),0,12);
$pwaVer=substr(hash_file('sha256',__DIR__.'/dmd-bloc-note-mydesk.css'),0,12);
$floatVer=substr(hash_file('sha256',__DIR__.'/bn-floating.css'),0,12);
?><!doctype html><html lang="fr" class="bn-mydesk-root" data-dmd-context="mydesk" data-dmd-view="app">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="color-scheme" content="dark light"><title>Bloc-notes | MyDesk</title>
<base href="../../">
<link rel="stylesheet" href="theme/<?= htmlspecialchars($theme,ENT_QUOTES,'UTF-8') ?>/style.css">
<link rel="stylesheet" href="core/dmd_theme_user.css.php">
<link rel="stylesheet" href="<?= htmlspecialchars($dir,ENT_QUOTES,'UTF-8') ?>dmd-bloc-note.css?v=<?= $cssVer ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($dir,ENT_QUOTES,'UTF-8') ?>dmd-bloc-note-mydesk.css?v=<?= $pwaVer ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($dir,ENT_QUOTES,'UTF-8') ?>bn-floating.css?v=<?= $floatVer ?>">
</head><body class="bn-mydesk-page"><main class="bn-widget bn-pwa" id="bn_my_app" data-bn-api="<?= htmlspecialchars($dir,ENT_QUOTES,'UTF-8') ?>dmd-bloc-note_api.php">
<?php require __DIR__.'/dmd-bloc-note_view.php'; ?>
</main><script src="<?= htmlspecialchars($dir,ENT_QUOTES,'UTF-8') ?>dmd-bloc-note.js?v=<?= $ver ?>"></script><script>window.DMDBlocNote.mount(document.getElementById('bn_my_app'))</script></body></html>
