/* DMD-Bloc-Note 1.3.0 – isolated instance, dashboard + standalone MyDesk */
(function(){
  'use strict';
  const DMD = window.DMDBlocNote || {};
  DMD.mount = function(root) {
    if (!root || root.dataset.bnMounted === '1') return;
    root.dataset.bnMounted = '1';
    const $ = (q) => root.querySelector(q);
    const $$ = (q) => [...root.querySelectorAll(q)];
    const escapeHTML = (x) => String(x ?? '').replace(/[&<>"']/g,(c)=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const date = (s) => { if(!s) return '';const d=new Date(s);return isNaN(d.getTime())?'':d.toLocaleDateString('fr-FR',{day:'2-digit',month:'short',year:'numeric'}); };
    const api = root.dataset.bnApi;
    let data = {notes:[],categories:[],shared_notes:[]};
    let rights = {write:false,delete:false,categories:false,export:false,share:false};
    let csrf = '';
    let filter = 'all';
    let board = root.classList.contains('bn-dashboard');
    let boardSize=200;
    try {const saved=localStorage.getItem('dmd-blocnote-board-'+(root.classList.contains('bn-dashboard')?'dashboard':'mydesk'));if(saved!==null)board=saved==='1';const sz=Number(localStorage.getItem('dmd-blocnote-wall-size'));if(sz>=150&&sz<=400)boardSize=sz;}catch(e){};
    let shareNote=null;let shareUsers=[];let shareGroups=[];
    const expandedNotes = new Set(); // MyDesk conserve l'affichage développé dans la liste.
    const floatingNotes = new Map(); // Fenêtres indépendantes sur le dashboard uniquement.
    let floatSequence = 0;
    const noteKey=n=>String(n.shared_by||'moi')+':'+String(n.id);
    let taskDraft=[];
    let current = null;
    let dirty = false;
    let busy = false;
    let ready = false;
    let lastListError = '';
    const app=$('.bn-shell');
    const noteData = () => Array.isArray(data.notes) ? data.notes : [];
    const sharedData = () => Array.isArray(data.shared_notes) ? data.shared_notes : [];
    const outgoingData = () => noteData().filter(n => isVisible(n) && ((Array.isArray(n.shared_with) && n.shared_with.length>0) || (Array.isArray(n.shared_groups) && n.shared_groups.length>0)));
    const allSharedData = () => [...outgoingData(), ...sharedData()];
    const findCardNote = (el) => {const id=el?.dataset.bnId,owner=el?.dataset.bnOwner || '';return [...noteData(),...sharedData()].find(n=>String(n.id)===id&&String(n.shared_by||'')===owner);};
    const cats = () => Array.isArray(data.categories) ? data.categories : [];
    const cat = (id) => cats().find(c=>c.id === id) || {id:'general',name:'Général',color:'#6488e8'};
    const isTrash = n => !!n.deleted_at;
    const isArchived = n => !!n.archived_at;
    const isVisible = n => !isTrash(n) && !isArchived(n);
    function notice(message, isError=false){
      const box=$('[data-bn-alert]');
      box.textContent=message; box.hidden=false;
      box.classList.toggle('bn-alert-error',isError);
      clearTimeout(box._timer);
      box._timer=setTimeout(()=>{box.hidden=true;},4500);
    }
    async function req(action, payload=null){
      let opt={method:payload===null?'GET':'POST',credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}};
      if(payload!==null){opt.headers['Content-Type']='application/json';opt.headers['X-BN-CSRF']=csrf;opt.body=JSON.stringify(payload);}
      const r=await fetch(api+'?action='+encodeURIComponent(action),opt);
      const type=r.headers.get('content-type')||'';
      if(!type.includes('application/json')) throw Error('Session expirée ou route API incorrecte (HTTP '+r.status+').');
      const result=await r.json();
      if(!r.ok || !result || !result.ok) throw Error((result && result.error)||'Erreur HTTP '+r.status);
      return result;
    }
    async function refresh(silent=false){
      try {
        const ans=await req('list');
        data=ans.data;rights=ans.permissions;csrf=ans.csrf;
        lastListError='';ready=true;
        $('[data-bn-state]').textContent='Notes synchronisées';
        render();
        syncFloatingNotes();
        if(!silent)notice('Notes actualisées');
      } catch(e){
        lastListError=e.message;
        $('[data-bn-state]').textContent='Connexion indisponible';
        if(!ready)$('[data-bn-notes]').innerHTML='<div class="bn-empty"><strong>Impossible de charger les notes</strong><span>'+escapeHTML(e.message)+'</span><button type="button" class="bn-btn" data-bn-act="refresh">Réessayer</button></div>';
        notice(e.message,true);
      }
    }
    function count(name){if(name==='shared')return allSharedData().length;return noteData().filter(n => name==='trash'?isTrash(n):name==='archived'?(!isTrash(n)&&isArchived(n)):(isVisible(n)&&(name==='all'||(name==='pinned'&&n.pinned)||(name==='favorites'&&n.favorite)||n.category===name))).length;}
    function filtered(){
      const search=($('[data-bn-search]').value||'').trim().toLocaleLowerCase('fr');
      const list=(filter==='shared'?allSharedData():noteData().filter(n => filter==='trash'?isTrash(n):filter==='archived'?(!isTrash(n)&&isArchived(n)):(isVisible(n)&&(filter==='all'||(filter==='pinned'&&n.pinned)||(filter==='favorites'&&n.favorite)||n.category===filter))));
      const matching=search ? list.filter(n=>(String(n.title||'')+' '+String(n.body||'')+' '+cat(n.category).name).toLocaleLowerCase('fr').includes(search)) : list;
      const order=$('[data-bn-sort]').value;
      matching.sort((a,b)=>order==='title'?String(a.title).localeCompare(String(b.title),'fr'):String(b[order==='created'?'created_at':'updated_at']||'').localeCompare(String(a[order==='created'?'created_at':'updated_at']||'')));
      if(order==='recent' && !['archived','trash'].includes(filter))matching.sort((a,b)=>Number(!!b.pinned)-Number(!!a.pinned)||String(b.updated_at).localeCompare(String(a.updated_at)));
      return matching;
    }
    function optionList(){
      const options=[['all','Toutes'],['pinned','Épinglées'],['favorites','Favoris'],['shared','Partagées'],['archived','Archives'],...cats().map(c=>[c.id,c.name]),['trash','Corbeille']];
      const select=$('[data-bn-select-filter]');
      select.innerHTML=options.map(([v,label])=>'<option value="'+escapeHTML(v)+'">'+escapeHTML(label)+(v==='shared'?' · '+count('shared'):'')+'</option>').join('');
      select.value=filter;
    }
    function card(n){
      const c=cat(n.category);
      const color=/^#[0-9a-fA-F]{6}$/.test(n.color||'')?n.color:c.color;
      const content=String(n.body||'');
      const shared=!!n.shared;
      // Aperçu en lecture seule : aucune case à cocher dans les vignettes.
      // Les tâches restent modifiables depuis l'éditeur "Liste de tâches".
      const items=n.kind==='checklist'?content.split('\n').filter(raw=>raw.trim()).slice(0,expandedNotes.has(noteKey(n))?500:3).map(raw=>{
        const done=/^\s*\[x\]\s*/i.test(raw);
        const label=raw.replace(/^\s*\[[x ]\]\s*/i,'').trim();
        return '<span class="bn-task-preview-line'+(done?' is-done':'')+'">'+escapeHTML(label)+'</span>';
      }).join(''):'<p class="bn-note-summary">'+escapeHTML(board?content:content.substring(0,400))+'</p>';
      const expandedChecklist=(n.kind==='checklist' && !root.classList.contains('bn-dashboard') && expandedNotes.has(noteKey(n)));
      const checklistRows=expandedChecklist?content.split('\n').filter(raw=>raw.trim()).map((raw,i)=>{
        const done=/^\s*\[[xX]\]/.test(raw);
        const label=raw.replace(/^\s*\[[xX ]\]\s*/,'').trim();
        return '<label class="bn-expanded-task"><input type="checkbox" data-bn-expanded-task="'+i+'" data-bn-task-label="'+escapeHTML(label)+'" '+(done?'checked':'')+'><span>'+escapeHTML(label)+'</span></label>';
      }).join(''):'';
      const mode=shared?'shared':isTrash(n)?'trash':isArchived(n)?'archived':'live';
      const paths={edit:'<path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L9 17l-4 1 1-4L16.5 3.5Z"/>',archive:'<rect x="3" y="4" width="18" height="4" rx="1"/><path d="M5 8v11h14V8M10 12h4"/>',unarchive:'<path d="M3 8h18V4H3v4ZM5 8v11h14V8M12 16v-6m-3 3 3-3 3 3"/>',pin:'<path d="m15 3 6 6-3 1-4 4-1 5-2 2-3-7-6-3 2-2 5-1 4-4 2-3Z"/>',favorite:'<path d="m12 3 2.8 5.7 6.3.9-4.5 4.4 1.1 6.3L12 17.4l-5.7 2.9 1.1-6.3L3 9.6l6.2-.9L12 3Z"/>',share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.7 10.7 6.6-4M8.7 13.4l6.6 4"/>',export:'<path d="M12 3v12m-4-4 4 4 4-4M5 17v4h14v-4"/>',trash:'<path d="M4 7h16M10 11v7m4-7v7M6 7l1 14h10l1-14M9 7V4h6v3"/>',restore:'<path d="M4 11a8 8 0 1 1 2.1 6M4 5v6h6"/>',purge:'<path d="M4 7h16M6 7l1 14h10l1-14M9 7V4h6v3M9 11l6 6m0-6-6 6"/>','copy-shared':'<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>'};
      const btn=(act,label,icon,needPermission=true)=>needPermission?'<button type="button" title="'+label+'" aria-label="'+label+'" data-bn-card-act="'+act+'"><svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+(paths[act]||paths.export)+'</svg></button>':'';
      let actions='';
      const expanded=!root.classList.contains('bn-dashboard') && expandedNotes.has(noteKey(n));
      const shareList=Array.isArray(n.shared_with)?n.shared_with:[];
      const groupNames=(Array.isArray(n.shared_group_labels)?n.shared_group_labels:[]).map(g=>g.name).filter(Boolean);
      const recipients=[...shareList,...groupNames.map(g=>'Groupe : '+g)];
      const sharedInfo='Créée par '+ownerLabel(n)+(shared?' · Reçue en partage':(recipients.length?' · Avec '+recipients.join(', '):''));
      const shareBadge=shared?'<span class="bn-share-pill bn-share-in" title="'+escapeHTML(sharedInfo)+'">↙ Reçue</span>':recipients.length?'<button type="button" class="bn-share-pill bn-share-out" data-bn-card-act="share" title="'+escapeHTML(sharedInfo)+'">↗ Partagée</button>':'';
      const recipientLabel=shared?'De : '+ownerLabel(n):(recipients.length?'Avec : '+recipients.join(', '):'');
      const visibleShare=recipientLabel?'<button type="button" class="bn-card-sharing" '+(shared?'data-bn-card-act="open"':'data-bn-card-act="share"')+' title="'+escapeHTML(recipientLabel)+'">'+escapeHTML(recipientLabel)+'</button>':'';
      if(mode==='shared')actions=btn('copy-shared','Copier dans mes notes','⧉',rights.write)+btn('export','Exporter','↓',rights.export);
      else if(mode==='trash')actions=btn('restore','Restaurer','↶',rights.delete)+btn('purge','Supprimer définitivement','×',rights.delete);
      else actions=btn('edit','Modifier','✎',rights.write)+btn(mode==='archived'?'unarchive':'archive',mode==='archived'?'Désarchiver':'Archiver',mode==='archived'?'↶':'▣',rights.write)+btn('pin','Épingler','◆',rights.write)+btn('favorite','Favori',n.favorite?'★':'☆',rights.write)+btn('share','Partager','⇪',rights.share)+btn('export','Exporter','↓',rights.export)+btn('trash','Corbeille','×',rights.delete);
      return '<article class="bn-note'+(expanded?' bn-is-expanded':'')+'" data-bn-id="'+escapeHTML(n.id)+'" data-bn-owner="'+escapeHTML(n.shared_by||'')+'" data-dmd-context-type="note" data-dmd-context-id="'+escapeHTML(n.id)+'" data-dmd-context-label="'+escapeHTML(n.title)+'" data-dmd-context-source="DMD-Bloc-Note" style="--bn-note-color:'+escapeHTML(color)+'">'+
      '<div class="bn-note-label"><span class="bn-color-dot"></span><small>'+escapeHTML(shared?'Reçue':c.name)+'</small><span class="bn-flex"></span>'+shareBadge+'<button type="button" class="bn-expand" data-bn-card-act="open" aria-expanded="'+expanded+'" title="'+(root.classList.contains('bn-dashboard')?'Ouvrir une fenêtre flottante':(expanded?'Réduire':'Lire cette note en entier'))+'">'+(expanded?'−':'↗')+'</button></div>'+
      '<div class="bn-note-open"><button type="button" class="bn-card-title" data-bn-card-act="open">'+escapeHTML(n.title||'Sans titre')+'</button>'+contentPart(content,expandedChecklist?checklistRows:items,n.kind)+'</div>'+
      visibleShare+'<div class="bn-author-line" title="'+escapeHTML(sharedInfo)+'">'+escapeHTML(sharedInfo)+'</div>'+
      '<div class="bn-note-foot"><time>'+escapeHTML(date(n.updated_at))+'</time><span class="bn-note-actions">'+actions+'</span></div></article>';
    }
    function contentPart(content,markup,kind){return kind==='checklist'?'<div class="bn-checklist-preview">'+(markup||'<span class="bn-note-summary">Liste vide</span>')+'</div>':'<div class="bn-note-excerpt">'+(content?markup:'<span class="bn-note-summary">Note sans contenu</span>')+'</div>';}
    function render(){
      if(!ready)return;
      if(filter!=='all'&&!['pinned','favorites','shared','archived','trash'].includes(filter)&&!cats().some(c=>c.id===filter))filter='all';
      const nav=$('.bn-rail-categories');
      nav.innerHTML=cats().map(c=>'<button type="button" class="bn-rail-link '+(filter===c.id?'is-active':'')+'" data-bn-filter="'+escapeHTML(c.id)+'"><i style="background:'+escapeHTML(c.color)+'"></i>'+escapeHTML(c.name)+' <span>'+count(c.id)+'</span></button>').join('');
      $$('[data-bn-filter]').forEach(el=>el.classList.toggle('is-active',el.dataset.bnFilter===filter));
      $$('[data-bn-count]').forEach(el=>el.textContent=count(el.dataset.bnCount));
      optionList();
      const titles={all:'Toutes les notes',pinned:'Épinglées',favorites:'Favoris',shared:'Partagées avec moi',archived:'Archives',trash:'Corbeille'};
      $('[data-bn-list-title]').textContent=titles[filter]||cat(filter).name;
      const notes=filtered();
      $('[data-bn-total]').textContent=notes.length+' note'+(notes.length>1?'s':'');
      $('[data-bn-notes]').innerHTML=notes.length?notes.map(card).join(''):'<div class="bn-empty"><strong>Aucune note</strong><span>Créez une note ou choisissez un autre filtre.</span></div>';
      root.classList.toggle('bn-wall-mode',board);
      $('[data-bn-act="toggle-board"]').textContent=board?'☷ Liste':'▦ Mur';
      $('[data-bn-act="toggle-board"]').setAttribute('aria-pressed',String(board));
      $('[data-bn-notes]').style.setProperty('--bn-wall-card-size',boardSize+'px');
      $('.bn-wall-controls').hidden=!board;
      $('[data-bn-act="new"]').disabled=!rights.write;
      $('[data-bn-act="export-all"]').disabled=!rights.export;
      $('[data-bn-act="import"]').disabled=!rights.write;
      $('[data-bn-act="categories"]').hidden=!rights.categories;
      $('[data-bn-act="categories-compact"]').hidden=!rights.categories;
      if(window.DMDActionHub && typeof window.DMDActionHub.decorate==='function' && root.classList.contains('bn-dashboard'))window.DMDActionHub.decorate($('[data-bn-notes]'));
    }
    function setScreen(screen){
      app.dataset.bnScreen=screen;
      $$('[data-bn-panel]').forEach(el=>{el.hidden=el.dataset.bnPanel!==screen;});
    }
    function ownerLabel(n){return n?.created_by_name || n?.created_by || n?.shared_by_name || n?.shared_by || data.me_name || data.me || 'Utilisateur';}
    function renderTasks(focusLast=false){
      const host=$('[data-bn-task-items]');
      host.innerHTML=taskDraft.map((t,i)=>'<div class="bn-task-item" data-bn-task-index="'+i+'"><input type="checkbox" data-bn-task-done aria-label="Tâche terminée" '+(t.done?'checked':'')+'><input type="text" maxlength="5000" data-bn-task-text placeholder="Décrire la tâche…" value="'+escapeHTML(t.text)+'"><button type="button" data-bn-task-remove title="Supprimer cette tâche" aria-label="Supprimer cette tâche">×</button></div>').join('');
      if(focusLast)host.querySelector('.bn-task-item:last-child [data-bn-task-text]')?.focus();
    }
    function flushTasks(){
      taskDraft=[];
      $$('[data-bn-task-index]').forEach(row=>{
        const text=row.querySelector('[data-bn-task-text]').value.trim();
        if(text)taskDraft.push({text,done:row.querySelector('[data-bn-task-done]').checked});
      });
    }
    function switchKind(kind){
      const on=kind==='checklist';
      $('[data-bn-task-editor]').hidden=!on;
      $('[data-bn-body]').hidden=on;
      $('[data-bn-task-tip]').hidden=!on;
      if(on){
        taskDraft=$('[data-bn-body]').value.split('\n').filter(line=>line.trim()).map(line=>({done:/^\s*\[[xX]\]/.test(line),text:line.replace(/^\s*\[[xX ]\]\s*/, '').trim()}));
        renderTasks();
      } else {
        flushTasks();
        $('[data-bn-body]').value=taskDraft.map(t=>(t.done?'[x] ':'[ ] ')+t.text).join('\n');
      }
    }
    function tasksBody(){flushTasks();return taskDraft.map(t=>(t.done?'[x] ':'[ ] ')+t.text).join('\n');}
    function openEditor(note=null){
      if(!rights.write || (note && isTrash(note))) {notice('Modification non autorisée',true);return;}
      current=note?{...note}:null;dirty=false;
      $('[data-bn-edit-label]').textContent=note?'Modifier la note':'Nouvelle note';
      $('[data-bn-title]').value=note?.title||'';
      $('[data-bn-body]').value=note?.body||'';
      const categories=cats().map(c=>'<option value="'+escapeHTML(c.id)+'">'+escapeHTML(c.name)+'</option>').join('');
      $('[data-bn-category]').innerHTML=categories;
      $('[data-bn-category]').value=note?.category || (cats().some(c=>c.id===filter)?filter:'general');
      $('[data-bn-kind]').value=note?.kind==='checklist'?'checklist':'text';
      $('[data-bn-color]').value=note?.color||'#6488e8';
      const meta=$('[data-bn-editor-meta]');meta.hidden=!note;meta.textContent=note?'Créée par '+ownerLabel(note)+' · '+date(note.created_at)+(note.shared_with?.length?' · Partagée avec '+note.shared_with.join(', '):''):'';
      switchKind($('[data-bn-kind]').value);
      for(const [action,value] of [['pin',note?.pinned],['favorite',note?.favorite]]){
        const el=$('[data-bn-act="'+action+'"]');el.dataset.bnValue=value?'1':'0';el.classList.toggle('is-selected',!!value);
      }
      $('[data-bn-edit-status]').textContent='';
      $('[data-bn-act="save"]').disabled=false;
      $('[data-bn-act="share-current"]').hidden=!note||!rights.share;
      setScreen('edit');
      $('[data-bn-title]').focus({preventScroll:true});
    }
    function getEditor(){return {id:current?.id||'',title:$('[data-bn-title]').value,body:$('[data-bn-kind]').value==='checklist'?tasksBody():$('[data-bn-body]').value,category:$('[data-bn-category]').value,kind:$('[data-bn-kind]').value,color:$('[data-bn-color]').value,pinned:$('[data-bn-act="pin"]').dataset.bnValue==='1',favorite:$('[data-bn-act="favorite"]').dataset.bnValue==='1'};}
    function leaveEditor(){if(dirty&&!confirm('Abandonner les modifications non enregistrées ?'))return;dirty=false;current=null;setScreen('list');}
    async function save(){if(busy)return;busy=true;const button=$('[data-bn-act="save"]');button.disabled=true;$('[data-bn-edit-status]').textContent='Enregistrement…';try{
      await req('save',getEditor());dirty=false;current=null;await refresh(true);setScreen('list');notice('Note enregistrée');
    }catch(e){$('[data-bn-edit-status]').textContent='Échec';notice(e.message,true);}finally{busy=false;button.disabled=false;}}
    function download(name,content,mime='text/plain;charset=utf-8'){
      const blob=new Blob([content],{type:mime});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),8000);
    }
    function safeFilename(name){return String(name||'note').replace(/[\\\/:*?"<>|\x00-\x1f]/g,'_').slice(0,85);}
    function exportNote(n){if(!rights.export){notice('Export non autorisé',true);return;}download(safeFilename(n.title)+'.txt',n.title+'\n\n'+n.body+'\n');}
    async function cardAction(n,action){
      if(action==='open') {if(root.classList.contains('bn-dashboard')){openFloatingNote(n);}else{const key=noteKey(n);if(expandedNotes.has(key))expandedNotes.delete(key);else expandedNotes.add(key);render();}return;}
      if(action==='edit'){openEditor(n);return;}
      if(action==='share'){openShare(n);return;}
      if(action==='copy-shared'){try{await req('copy_shared',{owner:n.shared_by,id:n.id});await refresh(true);notice('Note copiée dans votre espace');}catch(e){notice(e.message,true);}return;}
      if(action==='export'){exportNote(n);return;}
      try{
        if(action==='purge'&&!confirm('Supprimer définitivement cette note ?'))return;
        if(action==='trash'&&!confirm('Déplacer cette note dans la corbeille ?'))return;
        if(['pin','favorite'].includes(action))await req('toggle',{id:n.id,field:action==='pin'?'pinned':'favorite',value:action==='pin'?!n.pinned:!n.favorite});
        else await req(action,{id:n.id});
        await refresh(true);
      }catch(e){notice(e.message,true);}
    }
    // Fenêtres mobiles indépendantes du conteneur du module (qui masque son débordement).
    // Aucun iframe et aucune API externe : le contenu provient des notes déjà autorisées.
    function floatingNoteData(n){
      const kind=n.kind==='checklist'?'checklist':'text';
      const category=cat(n.category);
      const color=/^#[0-9a-fA-F]{6}$/.test(n.color||'')?n.color:category.color;
      const recipients=Array.isArray(n.shared_with)?n.shared_with:[];
      const sharedBy=n.shared?'Note reçue':recipients.length?'Partagée avec '+recipients.join(', '):'Privée';
      const body=String(n.body||'');
      const taskLines=body.split('\n').filter(x=>x.trim()).map((line,i)=>{
        const done=/^\s*\[[xX]\]/.test(line);
        const label=line.replace(/^\s*\[[xX ]\]\s*/,'').trim();
        return '<label class="bn-float-task'+(done?' is-done':'')+'"><input type="checkbox" data-bn-floating-check="'+i+'" data-bn-task-label="'+escapeHTML(label)+'" '+(done?'checked':'')+'><span>'+escapeHTML(label)+'</span></label>';
      }).join('');
      const groupNames=(Array.isArray(n.shared_group_labels)?n.shared_group_labels:[]).map(g=>'Groupe : '+g.name);
      const allRecipients=[...recipients,...groupNames];
      return {color, header:escapeHTML(n.title||'Sans titre'), meta:escapeHTML(category.name+' · Créée par '+ownerLabel(n)+' · '+date(n.created_at)), sharing:escapeHTML(sharedBy), content:kind==='checklist'?(taskLines||'<div class="bn-float-empty">Aucune tâche</div>'):'<div class="bn-float-text">'+escapeHTML(body||'Note vide')+'</div>'};
    }
    function matchFloatingNote(key){
      return [...noteData(),...sharedData()].find(n=>noteKey(n)===key);
    }
    function syncFloatingNotes(){
      for(const [key,windowEl] of floatingNotes){
        const n=matchFloatingNote(key);
        if(!n || isTrash(n)){closeFloatingNote(key);continue;}
        fillFloatingNote(windowEl,n);
      }
    }
    function popupTheme(el,n){
      const s=getComputedStyle(root);
      for(const name of ['--bn-surface','--bn-background','--bn-fg','--bn-secondary','--bn-line','--bn-accent']){
        const val=s.getPropertyValue(name).trim();if(val)el.style.setProperty(name,val);
      }
      el.style.setProperty('--bn-note-color',floatingNoteData(n).color);
      el.style.colorScheme=s.colorScheme||'normal';
    }
    function fillFloatingNote(el,n){
      const d=floatingNoteData(n);
      popupTheme(el,n);
      el.querySelector('.bn-float-title').textContent=n.title||'Sans titre';
      el.querySelector('.bn-float-meta').textContent=cat(n.category).name+' · Créée par '+ownerLabel(n)+' · '+date(n.created_at);
      el.querySelector('.bn-float-sharing').textContent=n.shared?'Note reçue':((n.shared_with?.length||n.shared_groups?.length)?'Partagée avec '+[...(n.shared_with||[]),...(n.shared_group_labels||[]).map(g=>'Groupe : '+g.name)].join(', '):'Note privée');
      el.querySelector('.bn-float-body').innerHTML=d.content;
      const activity=Array.isArray(n.task_activity)?n.task_activity:[];
      const latest=activity.length?activity[activity.length-1]:null;
      el.querySelector('.bn-float-activity').textContent=latest?'Dernière action : '+(latest.name||latest.actor)+' · '+(latest.done?'terminée':'rouverte')+' · '+date(latest.at):'';
      el.querySelectorAll('[data-bn-floating-check]').forEach(cb=>{cb.disabled=false;});
      el.querySelector('[data-bn-float-action="edit"]').hidden=!!n.shared||!rights.write||isTrash(n);
      el.querySelector('[data-bn-float-action="share"]').hidden=!!n.shared||!rights.share||isTrash(n);
      el.querySelector('[data-bn-float-action="export"]').hidden=!rights.export;
    }
    async function toggleTask(n,index,done,label,checkbox){
      if(checkbox)checkbox.disabled=true;
      try{
        const result=await req('check_task',{owner:n.shared_by||data.me,id:n.id,task_index:index,done,text:label});
        await refresh(true);
        if(result.result.changed)notice(done?'Tâche terminée et participants informés':'Tâche rouverte et participants informés');
      }catch(err){
        if(checkbox){checkbox.checked=!done;checkbox.disabled=false;}
        notice(err.message,true);
        await refresh(true);
      }
    }
    // DMD dashboard scrolls inside #dashboard (wrapper height:100vh), NOT in
    // document.body. Attach notes directly to that scrollable workspace so
    // moving right/down extends the actual dashboard scrollbars.
    function floatingScrollHost(){
      const dash=root.closest('#dashboard');
      return dash || document.scrollingElement || document.documentElement;
    }
    function floatingViewport(){
      const host=floatingScrollHost();
      let layer=host.querySelector(':scope > #dmd-bloc-note-floating-layer');
      if(!layer){
        layer=document.createElement('div');
        layer.id='dmd-bloc-note-floating-layer';
        layer.className='bn-floating-layer';
        layer.setAttribute('aria-label','Fenêtres de notes DoMyDesk');
        host.appendChild(layer);
      }
      return layer;
    }
    function floatingBounds(){
      const host=floatingScrollHost();
      return {width:host.clientWidth||window.innerWidth,height:host.clientHeight||window.innerHeight};
    }
    function frontFloatingNote(el){
      window.DMDBlocNoteFloatZ=Math.max(Number(window.DMDBlocNoteFloatZ)||1,1)+1;
      el.style.zIndex=String(window.DMDBlocNoteFloatZ);
    }
    function updateFloatScrollArea(){
      const layer=document.getElementById('dmd-bloc-note-floating-layer');
      if(!layer)return;
      let marker=layer.querySelector('.bn-float-scroll-extent');
      if(!marker){
        marker=document.createElement('span');
        marker.className='bn-float-scroll-extent';
        marker.setAttribute('aria-hidden','true');
        layer.appendChild(marker);
      }
      let right=0,bottom=0;
      for(const el of floatingNotes.values()){
        if(!el.isConnected)continue;
        right=Math.max(right,el.offsetLeft+el.offsetWidth);
        bottom=Math.max(bottom,el.offsetTop+el.offsetHeight);
      }
      // A small margin makes the last line of the note reachable at the edge.
      marker.style.left=Math.ceil(right+12)+'px';
      marker.style.top=Math.ceil(bottom+12)+'px';
    }
    function activateFloatPointer(el,handle,type){
      handle.addEventListener('pointerdown',e=>{
        if(e.button!==0 || (type==='move'&&e.target.closest('button')))return;
        e.preventDefault();frontFloatingNote(el);
        const host=floatingScrollHost();
        const startX=e.clientX,startY=e.clientY;
        const startScrollX=host.scrollLeft,startScrollY=host.scrollTop;
        const startLeft=parseFloat(el.style.left)||0,startTop=parseFloat(el.style.top)||0;
        const startWidth=el.offsetWidth,startHeight=el.offsetHeight;
        let pointerX=e.clientX,pointerY=e.clientY,active=true,dragged=false,frame=0;
        handle.setPointerCapture(e.pointerId);
        handle.classList.add('bn-float-grabbing');
        const draw=()=>{
          const dx=pointerX-startX+host.scrollLeft-startScrollX;
          const dy=pointerY-startY+host.scrollTop-startScrollY;
          if(type==='move'){
            el.style.left=Math.max(0,startLeft+dx)+'px';
            el.style.top=Math.max(0,startTop+dy)+'px';
          }else{
            el.style.width=Math.max(210,startWidth+dx)+'px';
            el.style.height=Math.max(160,startHeight+dy)+'px';
          }
          updateFloatScrollArea();
        };
        // Auto-scroll the real DoMyDesk workspace near its right/bottom edge.
        // This avoids leaving a window cut off at the browser edge.
        const edgeScroll=()=>{
          if(!active)return;
          if(!dragged){frame=requestAnimationFrame(edgeScroll);return;}
          const box=host.getBoundingClientRect();
          const margin=35;
          const speed=(distance)=>Math.max(0,Math.min(18,(margin-distance)*.7));
          const right=box.right-pointerX,bottom=box.bottom-pointerY;
          const left=pointerX-box.left,top=pointerY-box.top;
          let sx=0,sy=0;
          if(right<margin&&right>=-12)sx=speed(right);
          else if(left<margin&&left>=-12)sx=-speed(left);
          if(bottom<margin&&bottom>=-12)sy=speed(bottom);
          else if(top<margin&&top>=-12)sy=-speed(top);
          if(sx||sy){
            // Enlarge the scroll area before scrolling, then keep the dragged
            // element anchored under the pointer while its scroll parent moves.
            if(sx>0||sy>0){
              if(type==='move'){
                el.style.left=Math.max(0,(parseFloat(el.style.left)||0)+Math.max(0,sx))+'px';
                el.style.top=Math.max(0,(parseFloat(el.style.top)||0)+Math.max(0,sy))+'px';
              }else{
                if(sx>0)el.style.width=Math.max(210,el.offsetWidth+sx)+'px';
                if(sy>0)el.style.height=Math.max(160,el.offsetHeight+sy)+'px';
              }
              updateFloatScrollArea();
            }
            host.scrollLeft=Math.max(0,host.scrollLeft+sx);
            host.scrollTop=Math.max(0,host.scrollTop+sy);
            draw();
          }
          frame=requestAnimationFrame(edgeScroll);
        };
        const move=ev=>{
          if(ev.pointerId!==e.pointerId)return;
          pointerX=ev.clientX;pointerY=ev.clientY;
          if(Math.abs(pointerX-startX)+Math.abs(pointerY-startY)>3)dragged=true;
          draw();
        };
        const end=ev=>{
          if(ev.pointerId!==e.pointerId)return;
          active=false;cancelAnimationFrame(frame);
          handle.classList.remove('bn-float-grabbing');
          handle.removeEventListener('pointermove',move);
          handle.removeEventListener('pointerup',end);
          handle.removeEventListener('pointercancel',end);
          if(handle.hasPointerCapture(e.pointerId))handle.releasePointerCapture(e.pointerId);
          updateFloatScrollArea();
          // On release, show the whole floating window instead of leaving its
          // contents cut off at the bottom/right of the visible dashboard.
          const hostRect=host.getBoundingClientRect();
          const noteRect=el.getBoundingClientRect();
          if(noteRect.right>hostRect.right-8){host.scrollLeft+=noteRect.right-hostRect.right+12;}
          if(noteRect.bottom>hostRect.bottom-8){host.scrollTop+=noteRect.bottom-hostRect.bottom+12;}
        };
        handle.addEventListener('pointermove',move);
        handle.addEventListener('pointerup',end);
        handle.addEventListener('pointercancel',end);
        frame=requestAnimationFrame(edgeScroll);
      });
    }
    function closeFloatingNote(key){
      const el=floatingNotes.get(key);
      if(!el)return;
      const layer=el.parentElement;
      el.remove();floatingNotes.delete(key);
      if(!floatingNotes.size && layer?.classList.contains('bn-floating-layer'))layer.remove();
      else updateFloatScrollArea();
    }
    function openFloatingNote(n){
      const key=noteKey(n);
      if(floatingNotes.has(key)){
        const el=floatingNotes.get(key);fillFloatingNote(el,n);frontFloatingNote(el);return;
      }
      const popup=document.createElement('section');
      popup.className='bn-floating-window';
      popup.setAttribute('role','dialog');
      popup.setAttribute('aria-label','Note : '+(n.title||'Sans titre'));
      popup.dataset.bnFloatOwner=root.id;
      popup.innerHTML='<header class="bn-float-head"><span class="bn-float-dot"></span><strong class="bn-float-title"></strong><button type="button" class="bn-float-close" data-bn-float-action="close" aria-label="Fermer la note" title="Fermer">×</button></header>'+
        '<div class="bn-float-information"><div class="bn-float-meta"></div><div class="bn-float-sharing"></div></div>'+
        '<div class="bn-float-body" tabindex="0"></div><div class="bn-float-activity"></div>'+
        '<footer class="bn-float-footer"><button type="button" data-bn-float-action="edit">Modifier</button><button type="button" data-bn-float-action="share">Partager</button><button type="button" data-bn-float-action="export">Exporter</button></footer>'+
        '<div class="bn-float-resizer" role="button" tabindex="0" aria-label="Redimensionner la fenêtre" title="Redimensionner"></div>';
      // Float directly in the DoMyDesk scrollable workspace, not outside it.
      const layer=floatingViewport();
      // Keep user theme colors even if the dashboard theme variables live on <body>.
      const originStyles=getComputedStyle(root);
      for(const name of ['--bn-background','--bn-surface','--bn-fg','--bn-line','--bn-accent','--bn-secondary','--page-bg','--card-bg','--text-color','--primary-color','--muted-color']){
        const value=originStyles.getPropertyValue(name).trim();
        if(value)popup.style.setProperty(name,value);
      }
      layer.appendChild(popup);
      const origin=root.closest('.module')?.getBoundingClientRect()||root.getBoundingClientRect();
      const offset=(floatSequence++%7)*25;
      const bounds=floatingBounds();
      const width=Math.min(350,Math.max(210,bounds.width-8));
      const height=Math.min(310,Math.max(160,bounds.height-8));
      const host=floatingScrollHost();
      const hostBox=host.getBoundingClientRect();
      // Prefer an initially visible position BESIDE the module, so another
      // note can still be opened from the cards without moving the first popup.
      const nearRight=origin.right-hostBox.left+host.scrollLeft+12+offset;
      const besideFits=nearRight+width+12<=host.scrollLeft+bounds.width;
      const left=besideFits?nearRight:Math.max(0,origin.left-hostBox.left+host.scrollLeft+24+offset);
      const preferredTop=origin.top-hostBox.top+host.scrollTop+30+offset;
      const top=Math.max(host.scrollTop,Math.min(preferredTop,host.scrollTop+bounds.height-height-12));
      popup.style.width=width+'px';popup.style.height=height+'px';
      popup.style.left=left+'px';popup.style.top=top+'px';
      floatingNotes.set(key,popup);
      fillFloatingNote(popup,n);frontFloatingNote(popup);updateFloatScrollArea();
      activateFloatPointer(popup,popup.querySelector('.bn-float-head'),'move');
      activateFloatPointer(popup,popup.querySelector('.bn-float-resizer'),'resize');
      popup.addEventListener('pointerdown',()=>frontFloatingNote(popup));
      popup.addEventListener('change',async event=>{
        const cb=event.target.closest('[data-bn-floating-check]');if(!cb)return;
        const latest=matchFloatingNote(key);if(!latest){cb.checked=!cb.checked;return;}
        await toggleTask(latest,Number(cb.dataset.bnFloatingCheck),cb.checked,cb.dataset.bnTaskLabel,cb);
      });
      popup.addEventListener('click',event=>{
        const b=event.target.closest('[data-bn-float-action]');if(!b)return;
        const action=b.dataset.bnFloatAction;
        if(action==='close'){closeFloatingNote(key);return;}
        const latest=matchFloatingNote(key);if(!latest){closeFloatingNote(key);return;}
        if(action==='edit'){closeFloatingNote(key);openEditor(latest);}
        if(action==='share'){closeFloatingNote(key);openShare(latest);}
        if(action==='export')exportNote(latest);
      });
    }
    window.addEventListener('resize',updateFloatScrollArea);
    function openReader(n){
      $('[data-bn-read-title]').textContent=n.title||'Sans titre';
      $('[data-bn-read-title]').dataset.noteId=n.id;
      $('[data-bn-read-title]').dataset.owner=n.shared_by||'';
      $('[data-bn-read-by]').textContent='Créée par '+ownerLabel(n)+' · '+date(n.created_at)+(n.shared_by?' · Note reçue':'');
      $('[data-bn-read-body]').textContent=n.body||'';
      $('[data-bn-act="reader-copy"]').hidden=!rights.write||!n.shared;
      setScreen('read');
    }
    function renderShareRecipients(){
      const box=$('[data-bn-share-recipients]');
      const list=Array.isArray(shareNote?.shared_with)?shareNote.shared_with:[];
      const groupList=Array.isArray(shareNote?.shared_group_labels)?shareNote.shared_group_labels:[];
      const people=list.map(email=>'<div class="bn-recipient"><span>Utilisateur · '+escapeHTML(email)+'</span><button type="button" class="bn-btn-icon" data-bn-revoke="'+escapeHTML(email)+'" aria-label="Retirer le partage utilisateur" title="Révoquer">×</button></div>');
      const groups=groupList.map(group=>'<div class="bn-recipient"><span>Groupe · '+escapeHTML(group.name)+'</span><button type="button" class="bn-btn-icon" data-bn-revoke-group="'+escapeHTML(group.id)+'" aria-label="Retirer le partage groupe" title="Révoquer le groupe">×</button></div>');
      box.innerHTML=people.length+groups.length?'<strong>Accès autorisés</strong>'+[...people,...groups].join(''):'<small>Cette note n’est partagée avec personne.</small>';
    }
    function syncShareMode(){
      const group=$('[data-bn-share-type]').value==='group';
      $('[data-bn-share-email]').hidden=group;
      $('[data-bn-share-group]').hidden=!group;
      $('[data-bn-share-label]').textContent=group?'Groupe DoMyDesk':'Utilisateur DoMyDesk';
    }
    async function openShare(n){
      if(!rights.share||n.shared){notice('Partage non autorisé',true);return;}
      shareNote=n;
      $('[data-bn-share-title]').textContent=n.title||'Sans titre';
      $('[data-bn-share-email]').value='';
      renderShareRecipients();
      $('[data-bn-share-overlay]').hidden=false;
      syncShareMode();
      try{
        const [u,g]=await Promise.all([req('users'),req('groups')]);
        shareUsers=u.users||[];shareGroups=g.groups||[];
        $('[data-bn-share-users]').innerHTML=shareUsers.map(u=>'<option value="'+escapeHTML(u.email)+'" label="'+escapeHTML(u.name)+'"></option>').join('');
        $('[data-bn-share-group]').innerHTML='<option value="">Choisir un groupe…</option>'+shareGroups.map(g=>'<option value="'+escapeHTML(g.id)+'">'+escapeHTML(g.name)+' ('+g.count+')</option>').join('');
      }catch(e){notice(e.message,true);}
    }
    function closeShare(){$('[data-bn-share-overlay]').hidden=true;shareNote=null;}
    async function sendShare(){
      if(!shareNote)return;
      const isGroup=$('[data-bn-share-type]').value==='group';
      const email=$('[data-bn-share-email]').value.trim().toLowerCase();
      const groupId=$('[data-bn-share-group]').value;
      if(isGroup&&!groupId){notice('Choisir un groupe',true);return;}
      if(!isGroup&&!email){notice('Saisir un utilisateur DoMyDesk',true);return;}
      try{
        const r=await req(isGroup?'share_group':'share',isGroup?{id:shareNote.id,group_id:groupId}:{id:shareNote.id,email});
        const savedId=shareNote.id;
        await refresh(true);
        shareNote=noteData().find(n=>n.id===savedId)||shareNote;
        renderShareRecipients();
        $('[data-bn-share-email]').value='';
        notice(isGroup?'Note partagée avec le groupe':'Note partagée avec '+email);
      }catch(e){notice(e.message,true);}
    }
    async function copyNoteText(){
      if(!shareNote)return;
      const text=(shareNote.title||'Sans titre')+'\n\n'+(shareNote.body||'');
      try{
        if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(text);notice('Texte copié');}
        else{download(safeFilename(shareNote.title)+'.txt',text);notice('Note téléchargée');}
      }catch(e){download(safeFilename(shareNote.title)+'.txt',text);notice('Note téléchargée');}
    }
    $('[data-bn-share-recipients]').addEventListener('click',async e=>{
      const btn=e.target.closest('[data-bn-revoke],[data-bn-revoke-group]');if(!btn||!shareNote)return;
      const isGroup=btn.hasAttribute('data-bn-revoke-group');
      const dataPart=isGroup?{group_id:btn.dataset.bnRevokeGroup}:{email:btn.dataset.bnRevoke};
      try{
        const noteId=shareNote.id;
        await req(isGroup?'share_group_remove':'share_remove',{id:noteId,...dataPart});
        await refresh(true);shareNote=noteData().find(n=>n.id===noteId)||shareNote;
        renderShareRecipients();notice('Accès supprimé');
      }catch(err){notice(err.message,true);}
    });
    $('[data-bn-share-type]').addEventListener('change',syncShareMode);
    $('[data-bn-share-overlay]').addEventListener('click',e=>{if(e.target===$('[data-bn-share-overlay]'))closeShare();});
    function renderCategories(){
      $('[data-bn-category-table]').innerHTML=cats().map(c=>'<div class="bn-cat-row" data-bn-cat-id="'+escapeHTML(c.id)+'"><input type="color" value="'+escapeHTML(c.color)+'" aria-label="Couleur catégorie"><input type="text" value="'+escapeHTML(c.name)+'" maxlength="45" aria-label="Nom catégorie"><button type="button" class="bn-btn" data-bn-cat-action="save">✓</button>'+(c.id==='general'?'':'<button type="button" class="bn-btn-icon" data-bn-cat-action="delete" title="Supprimer">×</button>')+'</div>').join('');
    }
    function adapt(){
      const width=Math.round(root.getBoundingClientRect().width);
      const height=Math.round(root.getBoundingClientRect().height);
      root.classList.toggle('bn-compact',width<560);
      root.classList.toggle('bn-tiny',width<365);
      root.classList.toggle('bn-short',height<360);
    }
    if(window.ResizeObserver){const observer=new ResizeObserver(adapt);observer.observe(root);}else window.addEventListener('resize',adapt);
    adapt();
    root.addEventListener('click',async e=>{
      const filterBtn=e.target.closest('[data-bn-filter]');
      if(filterBtn){filter=filterBtn.dataset.bnFilter;setScreen('list');render();return;}
      const btn=e.target.closest('[data-bn-act]');
      if(btn){const act=btn.dataset.bnAct;
        if(act==='refresh'){await refresh();return;}
        if(act==='toggle-board'){
          board=!board;try{localStorage.setItem('dmd-blocnote-board-'+(root.classList.contains('bn-dashboard')?'dashboard':'mydesk'),board?'1':'0');}catch(err){}
          render();return;
        }
        if(act==='wall-smaller'||act==='wall-larger'){
          boardSize=Math.min(400,Math.max(150,boardSize+(act==='wall-larger'?40:-40)));
          try{localStorage.setItem('dmd-blocnote-wall-size',String(boardSize));}catch(err){}
          render();return;
        }
        if(act==='close-share'){closeShare();return;}
        if(act==='share-current'){if(current&& !dirty){openShare(current);}else notice('Enregistrez la note avant de la partager',true);return;}
        if(act==='send-share'){await sendShare();return;}
        if(act==='share-text'){await copyNoteText();return;}
        if(act==='reader-copy'){
          const note=sharedData().find(x=>x.id===$('[data-bn-read-title]').dataset.noteId&&x.shared_by===$('[data-bn-read-title]').dataset.owner);
          if(note)await cardAction(note,'copy-shared');return;
        }
        if(act==='task-add'){flushTasks();taskDraft.push({text:'',done:false});renderTasks(true);dirty=true;return;}
        if(act==='new'){openEditor();return;}
        if(act==='back'||act==='cancel'){if(app.dataset.bnScreen==='edit')leaveEditor();else setScreen('list');return;}
        if(act==='save'){await save();return;}
        if(act==='categories'||act==='categories-compact'){renderCategories();setScreen('categories');return;}
        if(act==='pin'||act==='favorite'){btn.dataset.bnValue=btn.dataset.bnValue==='1'?'0':'1';btn.classList.toggle('is-selected',btn.dataset.bnValue==='1');dirty=true;return;}
        if(act==='export-current'){exportNote(getEditor());return;}
        if(act==='export-all'){
          const json=JSON.stringify({format:'DMD-Bloc-Note',version:1,exported_at:new Date().toISOString(),categories:cats(),notes:noteData()},null,2);
          download('DMD-Bloc-Note-'+new Date().toISOString().slice(0,10)+'.json',json,'application/json;charset=utf-8');return;
        }
        if(act==='import'){$('[data-bn-import]').click();return;}
      }
      const categoryBtn=e.target.closest('[data-bn-cat-action]');
      if(categoryBtn){const row=categoryBtn.closest('[data-bn-cat-id]'),id=row.dataset.bnCatId;const action=categoryBtn.dataset.bnCatAction;
        if(action==='delete'&&!confirm('Supprimer cette catégorie ? Les notes seront placées dans Général.'))return;
        try{await req(action==='delete'?'category_delete':'category_save',{id,name:row.querySelector('input[type=text]').value,color:row.querySelector('input[type=color]').value});await refresh(true);renderCategories();notice('Catégories enregistrées');}catch(err){notice(err.message,true);}return;
      }
      const cardBtn=e.target.closest('[data-bn-card-act]');
      if(cardBtn){const card=cardBtn.closest('[data-bn-id]');if(!card)return;const note=findCardNote(card);if(note)await cardAction(note,cardBtn.dataset.bnCardAct);return;}
      // Un clic sur le reste de la vignette ouvre aussi la fenêtre, hors commandes.
      if(root.classList.contains('bn-dashboard') && !e.target.closest('button,a,input,select,textarea,[contenteditable]')){
        const card=e.target.closest('[data-bn-id]');
        if(card){const note=findCardNote(card);if(note)openFloatingNote(note);}
      }
    });
    $('[data-bn-notes]').addEventListener('change',async e=>{
      const expanded=e.target.closest('[data-bn-expanded-task]');
      if(expanded){
        const card=expanded.closest('[data-bn-id]');const n=findCardNote(card);
        if(n)await toggleTask(n,Number(expanded.dataset.bnExpandedTask),expanded.checked,expanded.dataset.bnTaskLabel,expanded);
        return;
      }
      const cb=e.target.closest('[data-bn-check]');if(!cb||!rights.write)return;
      const card=cb.closest('[data-bn-id]');const note=noteData().find(n=>n.id===card?.dataset.bnId);if(!note)return;
      const rows=String(note.body||'').split('\n');const index=Number(cb.dataset.bnCheck);
      if(index<0||index>=rows.length)return;
      rows[index]=(cb.checked?'[x] ':'[ ] ')+rows[index].replace(/^\[[x ]\] /i,'');
      try{await req('save',{...note,body:rows.join('\n')});await refresh(true);}catch(err){notice(err.message,true);cb.checked=!cb.checked;}
    });
    $('[data-bn-kind]').addEventListener('change',e=>{switchKind(e.target.value);dirty=true;});
    $('[data-bn-task-items]').addEventListener('input',()=>{dirty=true;});
    $('[data-bn-task-items]').addEventListener('change',()=>{dirty=true;});
    $('[data-bn-task-items]').addEventListener('click',e=>{
      const btn=e.target.closest('[data-bn-task-remove]');if(!btn)return;
      const idx=Number(btn.closest('[data-bn-task-index]').dataset.bnTaskIndex);
      flushTasks();taskDraft.splice(idx,1);renderTasks();dirty=true;
    });
    $('[data-bn-task-items]').addEventListener('keydown',e=>{
      if(e.key==='Enter'&&e.target.matches('[data-bn-task-text]')){
        e.preventDefault();flushTasks();taskDraft.push({text:'',done:false});renderTasks(true);dirty=true;
      }
    });
    $('[data-bn-search]').addEventListener('input',render);
    $('[data-bn-sort]').addEventListener('change',render);
    $('[data-bn-select-filter]').addEventListener('change',e=>{filter=e.target.value;render();});
    $$('[data-bn-panel="edit"] input, [data-bn-panel="edit"] select, [data-bn-panel="edit"] textarea').forEach(el=>el.addEventListener('input',()=>{dirty=true;}));
    $('[data-bn-cat-form]').addEventListener('submit',async e=>{
      e.preventDefault();const form=e.currentTarget;try{await req('category_save',{name:form.elements.name.value,color:form.elements.color.value});form.reset();await refresh(true);renderCategories();notice('Catégorie créée');}catch(err){notice(err.message,true);}
    });
    $('[data-bn-import]').addEventListener('change',async e=>{
      const file=e.target.files?.[0];e.target.value='';if(!file)return;
      if(file.size>10*1024*1024){notice('Sauvegarde trop volumineuse (maximum 10 Mo)',true);return;}
      try{const json=JSON.parse(await file.text());if(json.format!=='DMD-Bloc-Note'||!Array.isArray(json.notes)||!Array.isArray(json.categories))throw Error('Format de sauvegarde inconnu');
        if(!confirm('Importer cette sauvegarde ? Les notes ayant le même identifiant seront mises à jour. Les autres seront conservées.'))return;
        const res=await req('import',{backup:json});await refresh(true);notice('Import : '+res.result.imported+' note(s)');
      }catch(err){notice(err.message,true);}
    });
    root.addEventListener('keydown',e=>{
      if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'&&app.dataset.bnScreen==='edit'){e.preventDefault();save();}
      if(e.key==='Escape'&&!$('[data-bn-share-overlay]').hidden){e.preventDefault();closeShare();return;}
      if(e.key==='Escape'&&app.dataset.bnScreen==='edit'){e.preventDefault();leaveEditor();}
    });
    document.addEventListener('dmd:actionhub-action-complete', event=>{if(event?.detail?.module==='DMD-Bloc-Note')refresh(true);});
    refresh(true);
  };
  window.DMDBlocNote=DMD;
})();
