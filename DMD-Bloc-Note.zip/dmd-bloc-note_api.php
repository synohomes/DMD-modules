<?php
require_once __DIR__.'/dmd-bloc-note_lib.php';
header('Content-Type: application/json; charset=utf-8');header('X-Content-Type-Options: nosniff');header('Cache-Control: no-store');
if(!bn_can())bn_error('Accès refusé',403);
$action=(string)($_GET['action']??$_POST['action']??'list');
try{
 if($action==='list'){
  $data=bn_tx(function($d){return $d;},false);
  $data['shared_notes']=bn_shared_inbox();
  foreach($data['notes'] as &$bnOwn){if(!is_array($bnOwn))continue;$bnOwn['shared_group_labels']=bn_group_labels($bnOwn);}unset($bnOwn);
  $data['me']=bn_me(); $data['me_name']=bn_display_name(bn_me());
  foreach($data['notes'] as &$bnNote){if(!is_array($bnNote))continue;$bnNote['created_by']=$bnNote['created_by']??bn_me();$bnNote['created_by_name']=bn_display_name($bnNote['created_by']);}unset($bnNote);
  echo json_encode(['ok'=>true,'data'=>$data,'csrf'=>bn_token(),'permissions'=>['write'=>bn_can('notes.write'),'delete'=>bn_can('notes.delete'),'categories'=>bn_can('categories.manage'),'export'=>bn_can('notes.export'),'share'=>bn_can('notes.share')]],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;
 }
 if($action==='users') {echo json_encode(['ok'=>true,'users'=>bn_users_list()],JSON_UNESCAPED_UNICODE);exit;}
 if($action==='groups'){
   $all=bn_groups_list();$result=[];
   foreach($all as $g)$result[]=['id'=>$g['id'],'name'=>$g['name'],'source'=>$g['source'],'count'=>count($g['members'])];
   echo json_encode(['ok'=>true,'groups'=>$result],JSON_UNESCAPED_UNICODE);exit;
 }
 if($_SERVER['REQUEST_METHOD']!=='POST')bn_error('Méthode refusée',405);
 $tok=(string)($_SERVER['HTTP_X_BN_CSRF']??$_POST['csrf']??'');if(!hash_equals(bn_token(),$tok))bn_error('Jeton de sécurité invalide',403);
 $raw=file_get_contents('php://input');if(strlen($raw)>12*1024*1024)bn_error('Requête trop volumineuse',413);$input=json_decode($raw,true);if(!is_array($input))bn_error('JSON invalide');
 if($action==='check_task'){
   $owner=strtolower(bn_trim($input['owner']??bn_me(),190));
   if(!bn_existing_user($owner))bn_error('Propriétaire introuvable',404);
   $id=bn_trim($input['id']??'',80);
   $idx=filter_var($input['task_index']??null,FILTER_VALIDATE_INT,['options'=>['min_range'=>0,'max_range'=>2000]]);
   if($id===''||$idx===false||!is_bool($input['done']??null))bn_error('Tâche invalide');
   $done=$input['done'];$expected=bn_trim($input['text']??'',5000);
   $actor=bn_me();
   $result=bn_tx_external_note($owner,function(&$d)use($owner,$id,$idx,$done,$expected,$actor){
     foreach($d['notes'] as &$n){
       if(($n['id']??'')!==$id)continue;
       if(!empty($n['deleted_at'])||($n['kind']??'')!=='checklist')throw new RuntimeException('Liste de tâches indisponible');
       if(strtolower($owner)!==strtolower($actor) && !bn_has_shared_access($n,$owner,$actor))throw new RuntimeException('Partage révoqué ou accès refusé');
       $lines=explode("\n",(string)($n['body']??''));$actualIndex=-1;$rowPos=null;
       foreach($lines as $i=>$line){if(trim($line)==='')continue;$actualIndex++;if($actualIndex===$idx){$rowPos=$i;break;}}
       if($rowPos===null)throw new RuntimeException('Tâche supprimée : actualiser la note');
       $old=$lines[$rowPos];$text=trim(preg_replace('/^\s*\[[xX ]\]\s*/u','',$old));
       if($text!==$expected)throw new RuntimeException('La tâche a changé : actualiser la note');
       $wasDone=(bool)preg_match('/^\s*\[[xX]\]/u',$old);
       if($wasDone===$done)return ['changed'=>false,'note'=>$n,'task'=>$text,'done'=>$done];
       $lines[$rowPos]=($done?'[x] ':'[ ] ').$text;
       $n['body']=implode("\n",$lines);$n['updated_at']=gmdate('c');
       $entry=['task'=>$text,'done'=>$done,'actor'=>$actor,'name'=>bn_display_name($actor),'at'=>$n['updated_at']];
       if(!isset($n['task_activity'])||!is_array($n['task_activity']))$n['task_activity']=[];
       $n['task_activity'][]=$entry;$n['task_activity']=array_slice($n['task_activity'],-30);
       return ['changed'=>true,'note'=>$n,'task'=>$text,'done'=>$done];
     }
     throw new RuntimeException('Note introuvable');
   });
   if(!empty($result['changed'])){
     $note=$result['note'];$audience=bn_share_targets($note,$owner);$audience[]=$owner;
     $label=bn_display_name($actor).' a '.($done?'terminé':'rouvert').' une tâche';
     $message='« '.$result['task'].' » dans « '.($note['title']??'Note').' »';
     bn_notify_people($audience,'bloc_note_task',$label,$message,$note,$actor);
     bn_emit('note.check_task',$note,$message);
   }
   echo json_encode(['ok'=>true,'result'=>['changed'=>$result['changed'],'done'=>$done]],JSON_UNESCAPED_UNICODE);exit;
 }
 $permission=in_array($action,['save','toggle','archive','unarchive','import','copy_shared'],true)?'notes.write':(in_array($action,['trash','restore','purge'],true)?'notes.delete':(in_array($action,['share','share_remove','share_group','share_group_remove'],true)?'notes.share':'categories.manage'));
 if(!bn_can($permission))bn_error('Permission insuffisante',403);
 if($action==='copy_shared'){
   $owner=strtolower(bn_trim($input['owner']??'',190));$sourceId=bn_trim($input['id']??'',80);
   if($owner===''||$sourceId==='')bn_error('Note partagée introuvable');
   $sources=bn_shared_from($owner,bn_me(),$sourceId);
   if(!$sources)bn_error('Partage inexistant ou révoqué',403);
   $source=$sources[0];
   $result=bn_tx(function(&$d) use($source){
     $now=gmdate('c');
     $note=['id'=>bin2hex(random_bytes(12)),'title'=>bn_trim($source['title']??'',160),'body'=>bn_trim($source['body']??'',100000),'category'=>'general','color'=>bn_color($source['color']??''),'kind'=>($source['kind']??'')==='checklist'?'checklist':'text','pinned'=>false,'favorite'=>false,'created_at'=>$now,'created_by'=>bn_me(),'updated_at'=>$now,'deleted_at'=>null,'archived_at'=>null];
     $d['notes'][]=$note;return $note;
   });
   bn_emit('note.copy',$result,'Note copiée depuis un partage');
   echo json_encode(['ok'=>true,'result'=>$result],JSON_UNESCAPED_UNICODE);exit;
 }
 $result=bn_tx(function(&$d)use($input,$action){
  if ($action==='import') {
    $b=$input['backup']??null;
    if (!is_array($b)||($b['format']??'')!=='DMD-Bloc-Note'||!isset($b['categories'],$b['notes'])||!is_array($b['categories'])||!is_array($b['notes'])) throw new RuntimeException('Sauvegarde invalide');
    if (count($b['notes'])>2000||count($b['categories'])>250) throw new RuntimeException('Sauvegarde trop volumineuse');
    $known=[];foreach($d['notes'] as $i=>$n)if(isset($n['id']))$known[$n['id']]=$i;
    $ids=[];$added=0;
    foreach($b['categories'] as $c){if(!is_array($c))continue;$name=bn_trim($c['name']??'',45);$catid=bn_trim($c['id']??'',80);if($name===''||$catid===''||!bn_can('categories.manage'))continue;$exists=false;foreach($d['categories'] as $saved){if($saved['id']===$catid){$exists=true;break;}}if(!$exists)$d['categories'][]=['id'=>$catid,'name'=>$name,'color'=>bn_color($c['color']??'')];}
    foreach($b['notes'] as $n){
      if(!is_array($n))continue;
      $id=bn_trim($n['id']??'',80);if($id===''||isset($ids[$id]))continue;$ids[$id]=true;
      $title=bn_trim($n['title']??'',160);$body=bn_trim($n['body']??'',100000);if($title===''&&$body==='')continue;
      $cat=bn_trim($n['category']??'general',80);if(!bn_category($d,$cat))$cat='general';
      $now=gmdate('c');$created=bn_trim($n['created_at']??$now,60);$updated=bn_trim($n['updated_at']??$now,60);
      $record=['id'=>$id,'title'=>$title?:'Sans titre','body'=>$body,'category'=>$cat,'color'=>bn_color($n['color']??''),'kind'=>in_array($n['kind']??'text',['text','checklist'],true)?($n['kind']??'text'):'text','pinned'=>!empty($n['pinned']),'favorite'=>!empty($n['favorite']),'created_at'=>$created,'created_by'=>$d['notes'][$known[$id]]['created_by']??bn_me(),'updated_at'=>$updated,'deleted_at'=>!empty($n['deleted_at'])?$n['deleted_at']:null,'archived_at'=>!empty($n['archived_at'])?$n['archived_at']:null,'shared_with'=>$d['notes'][$known[$id]]['shared_with']??[],'shared_groups'=>$d['notes'][$known[$id]]['shared_groups']??[],'task_activity'=>$d['notes'][$known[$id]]['task_activity']??[]];
      if(isset($known[$id]))$d['notes'][$known[$id]]=$record;else{$d['notes'][]=$record;$added++;}
    }
    return ['imported'=>count($ids),'added'=>$added];
  }
  $now=gmdate('c');$id=bn_trim($input['id']??'',80);
  if($action==='save'){
   $existing=null;$key=null;
   foreach($d['notes'] as $i=>$n)if($n['id']===$id){$existing=$n;$key=$i;break;}
   if($existing && !empty($existing['deleted_at']))throw new RuntimeException('Restaurer la note avant modification');
   $title=bn_trim($input['title']??'',160);$body=bn_trim($input['body']??'',100000);
   if($title===''&&$body==='')throw new RuntimeException('Note vide');
   $cat=bn_trim($input['category']??'general',80);if(!bn_category($d,$cat))$cat='general';
   $note=['id'=>$existing['id']??bin2hex(random_bytes(12)),'title'=>$title?:'Sans titre','body'=>$body,'category'=>$cat,'color'=>bn_color($input['color']??'#6488e8'),'pinned'=>!empty($input['pinned']),'favorite'=>!empty($input['favorite']),'kind'=>in_array($input['kind']??'text',['text','checklist'],true)?($input['kind']??'text'):'text','created_at'=>$existing['created_at']??$now,'created_by'=>$existing['created_by']??bn_me(),'updated_at'=>$now,'deleted_at'=>null,'archived_at'=>$existing['archived_at']??null,'shared_with'=>$existing['shared_with']??[],'shared_groups'=>$existing['shared_groups']??[],'task_activity'=>$existing['task_activity']??[]];
   if($key!==null)$d['notes'][$key]=$note;else $d['notes'][]=$note;return $note;
  }
  if(in_array($action,['share_group','share_group_remove'],true)){
    $groupId=bn_trim($input['group_id']??'',200);
    $groups=bn_groups_list();
    // La révocation reste possible même après suppression du groupe.
    if($action==='share_group' && (!isset($groups[$groupId])||!count($groups[$groupId]['members'])))throw new RuntimeException('Choisir un groupe DoMyDesk valide contenant des membres');
    foreach($d['notes'] as &$note){
      if(($note['id']??'')!==$id)continue;
      if(!empty($note['deleted_at']))throw new RuntimeException('Note placée dans la corbeille');
      $ids=bn_group_ids($note);
      if($action==='share_group'){
        if(!in_array($groupId,$ids,true))$ids[]=$groupId;
        if(count($ids)>40)throw new RuntimeException('Nombre de groupes maximal atteint');
      }else{$ids=array_values(array_diff($ids,[$groupId]));}
      $note['shared_groups']=$ids;$note['updated_at']=gmdate('c');
      return ['id'=>$id,'shared_groups'=>$ids,'shared_group_labels'=>bn_group_labels($note),'group_name'=>$groups[$groupId]['name']??$groupId,'audience'=>bn_share_targets($note,bn_me()),'note'=>$note];
    }
    throw new RuntimeException('Note introuvable');
  }
  if(in_array($action,['share','share_remove'],true)) {
    $recipient=strtolower(bn_trim($input['email']??'',190));
    if(!bn_existing_user($recipient) || $recipient===strtolower(bn_me()))throw new RuntimeException('Choisir un utilisateur DoMyDesk valide');
    foreach($d['notes'] as &$note){
      if(($note['id']??'')!==$id)continue;
      if(!empty($note['deleted_at']))throw new RuntimeException('Note placée dans la corbeille');
      $with=array_values(array_unique(array_map('strtolower',array_filter($note['shared_with']??[],'is_string'))));
      if($action==='share'){
        if(!in_array($recipient,$with,true))$with[]=$recipient;
        if(count($with)>100)throw new RuntimeException('Nombre de destinataires maximal atteint');
      }else{$with=array_values(array_filter($with,function($v)use($recipient){return $v!==$recipient;}));}
      $note['shared_with']=$with;
      $note['updated_at']=gmdate('c');
      return ['id'=>$id,'shared_with'=>$with,'note'=>$note];
    }
    throw new RuntimeException('Note introuvable');
  }
  if(in_array($action,['trash','restore','purge','toggle','archive','unarchive'],true)){
   foreach($d['notes'] as $i=>&$n){if($n['id']!==$id)continue;
    if($action==='purge'){if(empty($n['deleted_at']))throw new RuntimeException('Placer d’abord la note dans la corbeille');array_splice($d['notes'],$i,1);return ['id'=>$id];}
    if($action==='trash')$n['deleted_at']=$now;
    if($action==='restore')$n['deleted_at']=null;
    if($action==='archive'){$n['archived_at']=$now;}
    if($action==='unarchive'){$n['archived_at']=null;}
    if($action==='toggle'){if(!empty($n['deleted_at']))throw new RuntimeException('Note supprimée');$field=(string)($input['field']??'');if(!in_array($field,['pinned','favorite'],true))throw new RuntimeException('Champ interdit');$n[$field]=!empty($input['value']);}
    $n['updated_at']=$now;return $n;
   }throw new RuntimeException('Note introuvable');
  }
  if($action==='category_save'){
   $name=bn_trim($input['name']??'',45);if($name==='')throw new RuntimeException('Nom obligatoire');
   if($id==='')$id=bin2hex(random_bytes(8));
   $cat=['id'=>$id,'name'=>$name,'color'=>bn_color($input['color']??'#6488e8')];
   foreach($d['categories'] as $i=>$c){if($c['id']===$id){$d['categories'][$i]=$cat;return $cat;}if(strcasecmp($c['name'],$name)===0)throw new RuntimeException('Cette catégorie existe déjà');}
   $d['categories'][]=$cat;return $cat;
  }
  if($action==='category_delete'){
   if($id==='general')throw new RuntimeException('La catégorie Général est protégée');
   $found=false;foreach($d['categories'] as $i=>$c)if($c['id']===$id){array_splice($d['categories'],$i,1);$found=true;break;}
   if(!$found)throw new RuntimeException('Catégorie introuvable');
   foreach($d['notes'] as &$n)if($n['category']===$id)$n['category']='general';return ['id'=>$id];
  }
  throw new RuntimeException('Action inconnue');
 });
 if(in_array($action,['save','toggle','archive','unarchive','trash','restore','purge','share','share_remove','share_group','share_group_remove'],true) && is_array($result))bn_emit('note.'.$action,$result['note']??$result,'Opération Bloc-notes');
 if($action==='share' && isset($result['note'])){
   bn_notify_people([$input['email']??''],'bloc_note_share','Une note a été partagée avec vous','« '.($result['note']['title']??'Note').' » par '.bn_display_name(bn_me()),$result['note'],bn_me());
 }
 if($action==='share_group' && isset($result['note'])){
   bn_notify_people($result['audience']??[],'bloc_note_share','Une note a été partagée avec votre groupe','« '.($result['note']['title']??'Note').' » pour '.($result['group_name']??'Groupe'),$result['note'],bn_me());
 }
 if(isset($result['note']))unset($result['note']);
 if(isset($result['audience']))unset($result['audience']);
 echo json_encode(['ok'=>true,'result'=>$result],JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
}catch(Throwable $e){bn_error($e->getMessage(),400);}
