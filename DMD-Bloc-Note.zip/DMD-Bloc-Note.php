<?php
/** DoMyDesk dashboard loader: dashboard.php resolves modules/<id>/<id>.php exactly. */
require_once __DIR__ . '/dmd-bloc-note_lib.php';
if (!bn_can('view')) { http_response_code(403); echo '<p class="bn-denied">Accès non autorisé.</p>'; return; }
$bnId = 'bn_' . bin2hex(random_bytes(8));
$bnPath = 'modules/' . rawurlencode(basename(__DIR__)) . '/';
$bnCssVersion = substr(hash_file('sha256', __DIR__ . '/dmd-bloc-note.css'), 0, 12);
$bnFloatVersion = substr(hash_file('sha256', __DIR__ . '/bn-floating.css'), 0, 12);
$bnVersion = (int)(@filemtime(__DIR__ . '/dmd-bloc-note.js') ?: time());
?>
<link rel="stylesheet" href="<?= htmlspecialchars($bnPath, ENT_QUOTES, 'UTF-8') ?>dmd-bloc-note.css?v=<?= $bnCssVersion ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($bnPath, ENT_QUOTES, 'UTF-8') ?>bn-floating.css?v=<?= $bnFloatVersion ?>">
<section id="<?= $bnId ?>" class="bn-widget bn-dashboard" data-bn-api="<?= htmlspecialchars($bnPath, ENT_QUOTES, 'UTF-8') ?>dmd-bloc-note_api.php" aria-label="Bloc-notes">
<?php include __DIR__ . '/dmd-bloc-note_view.php'; ?>
</section>
<style data-dmd-blocnote-compact="1">
<?php readfile(__DIR__ . "/compact-dashboard.css"); ?>
</style>
<script><?php readfile(__DIR__.'/dmd-bloc-note.js'); ?></script>
<script>
(function(){
 const root=document.getElementById(<?= json_encode($bnId) ?>);
 if(!root || !window.DMDBlocNote) return;
 const widget=root.closest('.module');
 if(widget){
   widget.dataset.dmdMinWidth='240'; widget.dataset.dmdMinHeight='200';
   const header=widget.querySelector('.module-header');
   if(header){header.classList.add('dmd-module-drag-handle');header.setAttribute('title','Déplacer la fenêtre (hors boutons)');}
   const handle=widget.querySelector('.resize-handle');
   if(handle){handle.style.width='22px';handle.style.height='22px';handle.style.zIndex='30';handle.style.touchAction='none';}
 }
 window.DMDBlocNote.mount(root);
})();
</script>
