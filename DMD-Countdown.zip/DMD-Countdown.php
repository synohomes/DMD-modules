<?php
/*
 * =====================================================================
 *                               DoMyDesk
 * =====================================================================
 * Copyright (c) 2026 SynoHomes / Tous droits réservés.
 * DMD-Countdown - tableau de bord - DoMyDesk 1.2.0
 */
if (session_status() === PHP_SESSION_NONE) @session_start();
require_once __DIR__ . '/dmd-countdown_lib.php';
$email = dmd_countdown_email();
if ($email === '') { echo '<div class="dmd-cd-state">Connexion requise.</div>'; return; }
if (!dmd_countdown_has_permission($email, 'module.view') || !dmd_countdown_has_permission($email, 'countdown.view')) { echo '<div class="dmd-cd-state">⛔ Accès refusé.</div>'; return; }
$events = dmd_countdown_list($email);
$moduleWeb = dmd_countdown_module_web_path();
$canCreate = dmd_countdown_has_permission($email, 'countdown.create');
$canEdit = dmd_countdown_has_permission($email, 'countdown.edit');
$canDelete = dmd_countdown_has_permission($email, 'countdown.delete');
$themes = dmd_countdown_theme_catalog($email);
$asset = rawurlencode(DMD_COUNTDOWN_VERSION);
?>
<link rel="stylesheet" href="<?= dmd_countdown_h($moduleWeb) ?>/dmd-countdown.css?v=<?= $asset ?>">
<div class="dmd-cd dmd-cd-dashboard" data-dmd-countdown-root data-mode="dashboard" data-module-web="<?= dmd_countdown_h($moduleWeb) ?>" data-api="<?= dmd_countdown_h($moduleWeb) ?>/dmd-countdown_api.php" data-csrf="<?= dmd_countdown_h(dmd_countdown_csrf()) ?>" data-can-create="<?= $canCreate?'1':'0' ?>" data-can-edit="<?= $canEdit?'1':'0' ?>" data-can-delete="<?= $canDelete?'1':'0' ?>">
    <div class="dmd-cd-compactbar">
        <span class="dmd-cd-event-count"><strong><?= count($events) ?></strong> échéance<?= count($events)>1?'s':'' ?></span>
        <?php if ($canCreate): ?><button type="button" class="dmd-cd-btn dmd-cd-btn-primary dmd-cd-add-compact" data-cd-new title="Ajouter une échéance">＋ <span>Ajouter</span></button><?php endif; ?>
    </div>

    <div class="dmd-cd-content" data-cd-content>
        <?php if (!$events): ?>
            <div class="dmd-cd-empty dmd-cd-empty-dashboard"><span>⏱️</span><div><strong>Aucune échéance</strong><small>Ajoute ton premier compte à rebours.</small></div></div>
        <?php else: ?>
            <?php $first = $events[0]; ?>
            <article class="dmd-cd-hero" data-countdown-date="<?= dmd_countdown_h($first['date']) ?>" data-dmd-context="1" data-dmd-context-type="countdown" data-dmd-context-id="<?= dmd_countdown_h($first['id']) ?>" data-dmd-context-label="<?= dmd_countdown_h($first['title']) ?>" data-dmd-context-source="DMD-Countdown" data-dmd-context-tags="<?= dmd_countdown_h($first['theme_id']) ?>">
                <img src="<?= dmd_countdown_h(dmd_countdown_image_url($email,$first['image'])) ?>" alt="">
                <div class="dmd-cd-hero-body">
                    <h3><?= dmd_countdown_h($first['title']) ?></h3>
                    <div class="dmd-cd-date"><?= dmd_countdown_h(date('d/m/Y H:i', strtotime($first['date']))) ?></div>
                </div>
                <div class="dmd-cd-time" data-countdown-output>—</div>
                <?php if ($canEdit): ?><button type="button" class="dmd-cd-iconbtn dmd-cd-editbtn" data-cd-edit="<?= dmd_countdown_h($first['id']) ?>" title="Modifier" aria-label="Modifier">✎</button><?php endif; ?>
            </article>

            <?php if (count($events)>1): ?><div class="dmd-cd-list">
            <?php foreach (array_slice($events,1,4) as $event): ?>
                <article class="dmd-cd-row" data-countdown-date="<?= dmd_countdown_h($event['date']) ?>" data-dmd-context="1" data-dmd-context-type="countdown" data-dmd-context-id="<?= dmd_countdown_h($event['id']) ?>" data-dmd-context-label="<?= dmd_countdown_h($event['title']) ?>" data-dmd-context-source="DMD-Countdown" data-dmd-context-tags="<?= dmd_countdown_h($event['theme_id']) ?>">
                    <img src="<?= dmd_countdown_h(dmd_countdown_image_url($email,$event['image'])) ?>" alt="">
                    <div class="dmd-cd-row-main"><strong><?= dmd_countdown_h($event['title']) ?></strong><small><?= dmd_countdown_h(date('d/m/Y H:i', strtotime($event['date']))) ?></small></div>
                    <span class="dmd-cd-row-time" data-countdown-output>—</span>
                    <?php if ($canEdit): ?><button type="button" class="dmd-cd-iconbtn dmd-cd-editbtn" data-cd-edit="<?= dmd_countdown_h($event['id']) ?>" title="Modifier" aria-label="Modifier">✎</button><?php endif; ?>
                </article>
            <?php endforeach; ?></div><?php endif; ?>
        <?php endif; ?>
    </div>

    <?php if ($canCreate || $canEdit): ?>
    <div class="dmd-cd-modal" data-cd-modal hidden><div class="dmd-cd-dialog"><div class="dmd-cd-dialog-head"><div><strong data-cd-dialog-title>Nouveau compte à rebours</strong><small>Ajout rapide</small></div><button type="button" class="dmd-cd-iconbtn" data-cd-close>×</button></div><form data-cd-form enctype="multipart/form-data"><input type="hidden" name="id" value=""><input type="hidden" name="csrf" value="<?= dmd_countdown_h(dmd_countdown_csrf()) ?>"><label>Titre<input name="title" maxlength="120" required placeholder="Ex : Mise en production"></label><label>Date et heure<input name="date" type="datetime-local" required></label><div class="dmd-cd-theme-picker"><img class="dmd-cd-theme-preview" data-cd-theme-preview src="<?= dmd_countdown_h(dmd_countdown_image_url($email, dmd_countdown_theme_image_token($email, 'project'))) ?>" alt=""><label>Catégorie<select name="theme_id" data-cd-theme-select><?php foreach ($themes as $theme): ?><option value="<?= dmd_countdown_h($theme['id']) ?>" data-image-url="<?= dmd_countdown_h(dmd_countdown_image_url($email,$theme['image'])) ?>"><?= dmd_countdown_h($theme['icon'].' '.$theme['name']) ?></option><?php endforeach; ?></select><small>Le logo de la catégorie sera appliqué automatiquement.</small></label></div><label>Note<textarea name="note" rows="3" placeholder="Contexte ou détail facultatif"></textarea></label><div class="dmd-cd-form-actions"><button type="button" class="dmd-cd-btn" data-cd-close>Annuler</button><button type="submit" class="dmd-cd-btn dmd-cd-btn-primary">Enregistrer</button></div><div class="dmd-cd-message" data-cd-message></div></form></div></div>
    <?php endif; ?>
</div>
<script src="<?= dmd_countdown_h($moduleWeb) ?>/dmd-countdown.js?v=<?= $asset ?>"></script>
