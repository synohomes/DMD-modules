<?php
/*
 * =====================================================================
 *                               DoMyDesk
 * =====================================================================
 * Copyright (c) 2026 SynoHomes / Tous droits réservés.
 * DMD-Countdown - bibliothèque commune - compatible DoMyDesk 1.2.0 / PHP 7.3+
 */

if (!defined('DMD_COUNTDOWN_ID')) define('DMD_COUNTDOWN_ID', 'DMD-Countdown');
if (!defined('DMD_COUNTDOWN_VERSION')) define('DMD_COUNTDOWN_VERSION', '1.0.5');

function dmd_countdown_root() {
    $root = realpath(__DIR__ . '/../..');
    return $root !== false ? $root : dirname(__DIR__, 2);
}

function dmd_countdown_boot_core() {
    $root = dmd_countdown_root();
    $files = array(
        $root . '/core/dmd_permissions.php',
        $root . '/core/dmd_system_services.php',
        $root . '/core/dmd_activity.php',
        $root . '/core/dmd_module_logs.php',
        $root . '/core/dmd_module_events.php',
        $root . '/Quick-Session/dmd_quick_session.php',
        $root . '/core/dmd_quick_session.php'
    );
    foreach ($files as $file) {
        if (is_file($file)) require_once $file;
    }
}

function dmd_countdown_email() {
    return trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : (isset($_SESSION['email']) ? $_SESSION['email'] : (isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''))));
}

function dmd_countdown_module_web_path() {
    $docRoot = realpath(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '');
    $moduleDir = realpath(__DIR__);
    if ($docRoot !== false && $moduleDir !== false) {
        $doc = rtrim(str_replace('\\', '/', $docRoot), '/');
        $mod = rtrim(str_replace('\\', '/', $moduleDir), '/');
        if ($doc !== '' && ($mod === $doc || strpos($mod, $doc . '/') === 0)) {
            return '/' . ltrim(substr($mod, strlen($doc)), '/');
        }
    }
    $script = str_replace('\\', '/', (string)(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : ''));
    $moduleName = basename(__DIR__);
    $needle = '/modules/' . $moduleName;
    $pos = strpos($script, $needle);
    if ($pos !== false) {
        return substr($script, 0, $pos + strlen($needle));
    }
    $requestUri = str_replace('\\', '/', (string)(isset($_SERVER['REQUEST_URI']) ? parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) : ''));
    $pos = strpos($requestUri, $needle);
    if ($pos !== false) {
        return substr($requestUri, 0, $pos + strlen($needle));
    }
    $base = rtrim(str_replace('\\', '/', dirname($script)), '/');
    if ($base === '.' || $base === '/') $base = '';
    if (substr($base, -strlen($needle)) === $needle) return $base;
    return $base . '/modules/' . rawurlencode($moduleName);
}

function dmd_countdown_h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function dmd_countdown_has_permission($email, $permission) {
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return false;
    dmd_countdown_boot_core();
    if (function_exists('dmd_user_has_module_permission')) {
        try { return (bool)dmd_user_has_module_permission($email, DMD_COUNTDOWN_ID, $permission); }
        catch (Throwable $e) { return false; }
    }
    return false;
}

function dmd_countdown_require_permission($email, $permission) {
    if (!dmd_countdown_has_permission($email, $permission)) {
        http_response_code(403);
        echo '<div class="dmd-cd-state">⛔ Accès refusé.</div>';
        exit;
    }
}

function dmd_countdown_safe_email($email) {
    $email = trim((string)$email);
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) return '';
    if (basename($email) !== $email || strpos($email, '/') !== false || strpos($email, '\\') !== false || strpos($email, '..') !== false) return '';
    return $email;
}

function dmd_countdown_storage_dir($email, $create) {
    $email = dmd_countdown_safe_email($email);
    if ($email === '') return '';
    $dir = dmd_countdown_root() . '/users/profiles/' . $email . '/dmd-countdown';
    if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
    if ($create && is_dir($dir)) {
        @chmod($dir, 0750);
        $rules = "Options -Indexes\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n";
        if (!is_file($dir . '/.htaccess')) @file_put_contents($dir . '/.htaccess', $rules, LOCK_EX);
    }
    return is_dir($dir) ? $dir : '';
}

function dmd_countdown_read_json($file, $fallback) {
    if (!is_file($file)) return $fallback;
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') return $fallback;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
}

function dmd_countdown_write_json($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000, 9999);
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
    @chmod($file, 0640);
    return true;
}

function dmd_countdown_defaults() {
    return array(
        'birthday' => array('id'=>'birthday','name'=>'Anniversaire','icon'=>'🎂','image'=>'img/defaults/birthday.jpg'),
        'meeting'  => array('id'=>'meeting','name'=>'Rendez-vous','icon'=>'💼','image'=>'img/defaults/meeting.png'),
        'cooking'  => array('id'=>'cooking','name'=>'Cuisine','icon'=>'🍳','image'=>'img/defaults/cooking.png'),
        'sport'    => array('id'=>'sport','name'=>'Sport','icon'=>'🏋️','image'=>'img/defaults/sport.png'),
        'travel'   => array('id'=>'travel','name'=>'Voyage','icon'=>'✈️','image'=>'img/defaults/travel.png'),
        'project'  => array('id'=>'project','name'=>'Projet / échéance','icon'=>'🎯','image'=>'img/defaults/project.png')
    );
}

function dmd_countdown_migrate_legacy($email) {
    $dir = dmd_countdown_storage_dir($email, true);
    if ($dir === '') return;
    $dest = $dir . '/countdowns.json';
    if (is_file($dest)) return;
    $legacyKey = preg_replace('/[^a-zA-Z0-9@._-]/', '_', $email);
    $candidates = array(
        dirname(__DIR__) . '/countdown/data/' . $legacyKey . '/countdowns.json',
        __DIR__ . '/data/' . $legacyKey . '/countdowns.json'
    );
    foreach ($candidates as $old) {
        if (!is_file($old)) continue;
        $items = dmd_countdown_read_json($old, array());
        if (!is_array($items)) continue;
        $normalized = array();
        foreach ($items as $event) {
            if (!is_array($event)) continue;
            $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($event['id']) ? $event['id'] : ''));
            if ($id === '') $id = 'evt_' . substr(sha1(json_encode($event)), 0, 12);
            $theme = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($event['themeId']) ? $event['themeId'] : 'project'));
            if ($theme === '') $theme = 'project';
            $normalized[] = array(
                'id'=>$id,
                'title'=>trim((string)(isset($event['titre']) ? $event['titre'] : (isset($event['title']) ? $event['title'] : 'Événement'))),
                'date'=>trim((string)(isset($event['date']) ? $event['date'] : '')),
                'theme_id'=>$theme,
                'image'=>'default:' . $theme,
                'note'=>trim((string)(isset($event['note']) ? $event['note'] : '')),
                'created_at'=>isset($event['created_at']) ? $event['created_at'] : date(DATE_ATOM),
                'updated_at'=>isset($event['updated_at']) ? $event['updated_at'] : date(DATE_ATOM)
            );
        }
        dmd_countdown_write_json($dest, $normalized);
        return;
    }
}

function dmd_countdown_events_file($email) {
    dmd_countdown_migrate_legacy($email);
    $dir = dmd_countdown_storage_dir($email, true);
    return $dir !== '' ? $dir . '/countdowns.json' : '';
}

function dmd_countdown_normalize_event($event) {
    if (!is_array($event)) return null;
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($event['id']) ? $event['id'] : ''));
    $title = trim((string)(isset($event['title']) ? $event['title'] : (isset($event['titre']) ? $event['titre'] : '')));
    $date = trim((string)(isset($event['date']) ? $event['date'] : ''));
    if ($id === '' || $title === '' || $date === '') return null;
    $theme = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($event['theme_id']) ? $event['theme_id'] : (isset($event['themeId']) ? $event['themeId'] : 'project')));
    if ($theme === '') $theme = 'project';
    return array(
        'id'=>$id,
        'title'=>substr($title, 0, 120),
        'date'=>$date,
        'theme_id'=>$theme,
        'image'=>trim((string)(isset($event['image']) ? $event['image'] : ('default:' . $theme))),
        'note'=>substr(trim((string)(isset($event['note']) ? $event['note'] : '')), 0, 2000),
        'created_at'=>(string)(isset($event['created_at']) ? $event['created_at'] : date(DATE_ATOM)),
        'updated_at'=>(string)(isset($event['updated_at']) ? $event['updated_at'] : date(DATE_ATOM))
    );
}

function dmd_countdown_list($email) {
    $file = dmd_countdown_events_file($email);
    $raw = $file !== '' ? dmd_countdown_read_json($file, array()) : array();
    $out = array();
    foreach ($raw as $event) {
        $event = dmd_countdown_normalize_event($event);
        if ($event) $out[] = $event;
    }
    usort($out, function($a, $b) { return strcmp($a['date'], $b['date']); });
    return $out;
}

function dmd_countdown_find($email, $id) {
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$id);
    foreach (dmd_countdown_list($email) as $event) if ($event['id'] === $id) return $event;
    return null;
}

function dmd_countdown_save($email, $event) {
    $event = dmd_countdown_normalize_event($event);
    if (!$event) return false;
    $items = dmd_countdown_list($email);
    $found = false;
    foreach ($items as $i => $item) {
        if ($item['id'] === $event['id']) { $items[$i] = $event; $found = true; break; }
    }
    if (!$found) $items[] = $event;
    usort($items, function($a, $b) { return strcmp($a['date'], $b['date']); });
    return dmd_countdown_write_json(dmd_countdown_events_file($email), $items);
}

function dmd_countdown_delete($email, $id) {
    $items = dmd_countdown_list($email);
    $next = array();
    $removed = false;
    foreach ($items as $item) {
        if ($item['id'] === $id) { $removed = true; continue; }
        $next[] = $item;
    }
    if (!$removed) return false;
    return dmd_countdown_write_json(dmd_countdown_events_file($email), $next);
}

function dmd_countdown_status($event) {
    $ts = strtotime((string)$event['date']);
    if ($ts === false) return 'invalid';
    if ($ts <= time()) return 'done';
    if (($ts - time()) <= 86400) return 'soon';
    return 'upcoming';
}

function dmd_countdown_resource($event) {
    $status = dmd_countdown_status($event);
    return array(
        'type'=>'countdown',
        'id'=>(string)$event['id'],
        'name'=>(string)$event['title'],
        'label'=>(string)$event['title'],
        'source'=>DMD_COUNTDOWN_ID,
        'tags'=>array((string)$event['theme_id'], $status)
    );
}

function dmd_countdown_emit($email, $action, $event, $details, $changes) {
    dmd_countdown_boot_core();
    if (!function_exists('dmd_module_event')) return null;
    return dmd_module_event(DMD_COUNTDOWN_ID, $action, dmd_countdown_resource($event), array(
        'email'=>$email,
        'label'=>$action,
        'target'=>$event['title'],
        'status'=>'success',
        'details'=>$details,
        'changes'=>is_array($changes) ? $changes : array(),
        'meta'=>array('date'=>$event['date'],'theme'=>$event['theme_id'])
    ));
}

function dmd_countdown_csrf() {
    if (empty($_SESSION['dmd_countdown_csrf']) || !is_string($_SESSION['dmd_countdown_csrf'])) {
        $_SESSION['dmd_countdown_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['dmd_countdown_csrf'];
}

function dmd_countdown_check_csrf($token) {
    return is_string($token) && isset($_SESSION['dmd_countdown_csrf']) && hash_equals($_SESSION['dmd_countdown_csrf'], $token);
}

function dmd_countdown_theme_catalog($email) {
    $defaults = dmd_countdown_defaults();
    $file = dmd_countdown_storage_dir($email, true) . '/themes.json';
    $custom = dmd_countdown_read_json($file, array());
    $out = $defaults;
    foreach ($custom as $theme) {
        if (!is_array($theme)) continue;
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '', strtolower((string)(isset($theme['id']) ? $theme['id'] : '')));
        if ($id === '' || isset($defaults[$id])) continue;
        $name = trim((string)(isset($theme['name']) ? $theme['name'] : ''));
        $image = trim((string)(isset($theme['image']) ? $theme['image'] : ''));
        if ($name === '' || $image === '') continue;
        $out[$id] = array('id'=>$id,'name'=>substr($name,0,80),'icon'=>'🖼️','image'=>$image);
    }
    return $out;
}

function dmd_countdown_save_custom_themes($email, $catalog) {
    $defaults = dmd_countdown_defaults();
    $custom = array();
    foreach ($catalog as $id => $theme) if (!isset($defaults[$id])) $custom[] = $theme;
    return dmd_countdown_write_json(dmd_countdown_storage_dir($email, true) . '/themes.json', $custom);
}


function dmd_countdown_theme_image_token($email, $themeId) {
    $themeId = preg_replace('/[^a-zA-Z0-9_-]/', '', strtolower((string)$themeId));
    if ($themeId === '') $themeId = 'project';
    $defaults = dmd_countdown_defaults();
    if (isset($defaults[$themeId])) return 'default:' . $themeId;
    $catalog = dmd_countdown_theme_catalog($email);
    if (isset($catalog[$themeId])) {
        $token = trim((string)(isset($catalog[$themeId]['image']) ? $catalog[$themeId]['image'] : ''));
        if ($token !== '') return $token;
    }
    return 'default:project';
}

function dmd_countdown_upload($email, $field, &$error) {
    $error = '';
    if (empty($_FILES[$field]) || (isset($_FILES[$field]['error']) ? $_FILES[$field]['error'] : UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    $upload = $_FILES[$field];
    if ((isset($upload['error']) ? $upload['error'] : UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) { $error = 'Upload impossible.'; return ''; }
    if ((int)(isset($upload['size']) ? $upload['size'] : 0) > 2 * 1024 * 1024) { $error = 'Image trop lourde : maximum 2 Mo.'; return ''; }
    $tmp = isset($upload['tmp_name']) ? $upload['tmp_name'] : '';
    if ($tmp === '' || !is_uploaded_file($tmp)) { $error = 'Fichier upload invalide.'; return ''; }
    if (!class_exists('finfo')) { $error = 'Extension PHP fileinfo requise.'; return ''; }
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($tmp);
    $allowed = array('image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif');
    if (!isset($allowed[$mime]) || @getimagesize($tmp) === false) { $error = 'Format image refusé.'; return ''; }
    $dir = dmd_countdown_storage_dir($email, true) . '/uploads';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $name = 'img_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $allowed[$mime];
    if (!@move_uploaded_file($tmp, $dir . '/' . $name)) { $error = 'Impossible d’enregistrer l’image.'; return ''; }
    @chmod($dir . '/' . $name, 0640);
    return 'upload:' . $name;
}

function dmd_countdown_image_url($email, $token) {
    $token = trim((string)$token);
    $moduleWeb = dmd_countdown_module_web_path();
    $defaults = dmd_countdown_defaults();
    if (strpos($token, 'upload:') === 0) {
        $file = basename(substr($token, 7));
        return $moduleWeb . '/dmd-countdown_media.php?file=' . rawurlencode($file);
    }
    if (strpos($token, 'default:') === 0) {
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '', substr($token, 8));
        if ($id === '' || !isset($defaults[$id])) $id = 'project';
        return $moduleWeb . '/' . $defaults[$id]['image'];
    }
    /* Compatibilité avec les événements 1.0.3 qui stockaient directement img/defaults/... */
    foreach ($defaults as $id => $theme) {
        if ($token === (string)$theme['image']) return $moduleWeb . '/' . $theme['image'];
    }
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', $token);
    if ($id === '' || !isset($defaults[$id])) $id = 'project';
    return $moduleWeb . '/' . $defaults[$id]['image'];
}

function dmd_countdown_new_id() {
    try { return 'evt_' . bin2hex(random_bytes(8)); }
    catch (Exception $e) { return 'evt_' . substr(sha1(uniqid('', true)), 0, 16); }
}
