(function(){
  'use strict';
  function esc(v){return String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');}
  function parseDate(v){var d=new Date(String(v||'')); return isNaN(d.getTime())?null:d;}
  function human(diff){
    if(diff<=0) return 'Terminé';
    var d=Math.floor(diff/86400000), h=Math.floor((diff%86400000)/3600000), m=Math.floor((diff%3600000)/60000), s=Math.floor((diff%60000)/1000);
    if(d>0) return d+'j '+String(h).padStart(2,'0')+'h '+String(m).padStart(2,'0')+'m';
    return String(h).padStart(2,'0')+'h '+String(m).padStart(2,'0')+'m '+String(s).padStart(2,'0')+'s';
  }
  function tick(root){
    root.querySelectorAll('[data-countdown-date]').forEach(function(el){var d=parseDate(el.dataset.countdownDate),out=el.querySelector('[data-countdown-output]');if(!d||!out)return;var diff=d.getTime()-Date.now();out.textContent=human(diff);el.classList.toggle('is-done',diff<=0);el.classList.toggle('is-soon',diff>0&&diff<=86400000);});
  }
  function moduleBase(root){
    var api=String(root.dataset.api||'').split('?')[0];
    return api.replace(/\/[^\/]*$/, '');
  }
  function ensureDashboardDragHandle(root){
    if(!root||root.dataset.mode!=='dashboard')return;
    var moduleEl=root.closest?root.closest('.module'):null;
    if(!moduleEl)return;
    var header=null;
    try{header=moduleEl.querySelector(':scope > .module-header');}catch(e){}
    if(!header)header=moduleEl.querySelector('.module-header');
    if(!header)return;
    var host=header.querySelector('.dmd-module-head-title')||header;
    var handle=header.querySelector('.dmd-module-drag-handle');
    if(!handle){
      handle=document.createElement('img');
      handle.className='dmd-module-drag-handle dmd-cd-dashboard-drag-handle';
      if(host.firstChild)host.insertBefore(handle,host.firstChild);else host.appendChild(handle);
    }else{
      handle.classList.add('dmd-cd-dashboard-drag-handle');
    }
    var base=moduleBase(root);
    if(base)handle.src=base+'/icon.png';
    handle.alt='';
    handle.draggable=false;
    handle.title='Déplacer DMD-Countdown';
    handle.setAttribute('aria-label','Déplacer DMD-Countdown');
    handle.style.width='28px';
    handle.style.height='28px';
    handle.style.objectFit='contain';
    handle.style.flex='0 0 28px';
    handle.style.display='block';
    handle.style.cursor='grab';
    handle.style.userSelect='none';
    handle.style.webkitUserDrag='none';
    handle.style.touchAction='none';
    moduleEl.dataset.dmdModuleId='DMD-Countdown';
  }
  function compactDashboardHost(root){
    if(!root||root.dataset.mode!=='dashboard')return;
    var moduleEl=root.closest?root.closest('.module'):null;
    if(!moduleEl)return;

    moduleEl.dataset.dmdMinWidth='280';
    moduleEl.dataset.dmdMinHeight='130';

    var key='DMD-Countdown:dashboard-compact:1.0.5:'+(location.pathname||'')+(location.search||'');
    var migrated=false;
    try{migrated=localStorage.getItem(key)==='1';}catch(e){}
    if(migrated)return;

    var w=parseFloat(moduleEl.style.width)||moduleEl.offsetWidth||280;
    var h=parseFloat(moduleEl.style.height)||moduleEl.offsetHeight||280;
    var looksLegacy=(h>=230)||(w>=460)||(Math.abs(w-280)<3&&Math.abs(h-280)<3);

    if(looksLegacy){
      moduleEl.style.width='320px';
      moduleEl.style.height='155px';
      if(window.DMDWorkspace&&typeof window.DMDWorkspace.rememberModuleGeometry==='function'){
        window.DMDWorkspace.rememberModuleGeometry(moduleEl);
      }
      if(typeof window.saveDashboard==='function'){
        window.setTimeout(function(){window.saveDashboard();},30);
      }
      if(typeof window.DMDExpandDashboardCanvas==='function'){
        window.requestAnimationFrame(function(){window.DMDExpandDashboardCanvas();});
      }
    }
    try{localStorage.setItem(key,'1');}catch(e){}
  }
  function api(root, action, body){
    var url=root.dataset.api+'?action='+encodeURIComponent(action);
    var opts={method:body?'POST':'GET',credentials:'same-origin',cache:'no-store'};
    if(body) opts.body=body;
    return fetch(url,opts).then(function(r){return r.text().then(function(t){var j;try{j=JSON.parse(t);}catch(e){throw new Error('Réponse serveur invalide.');}if(!r.ok||!j.ok)throw new Error(j.message||'Erreur.');return j;});});
  }
  function syncThemePreview(form){
    if(!form)return;
    var select=form.querySelector('[data-cd-theme-select]')||form.elements.theme_id;
    var preview=form.querySelector('[data-cd-theme-preview]');
    if(!select||!preview)return;
    var option=select.options&&select.selectedIndex>=0?select.options[select.selectedIndex]:null;
    var url=option&&option.dataset?option.dataset.imageUrl:'';
    if(url){preview.src=url;preview.alt=option.textContent||'Catégorie';}
  }
  function openModal(root,event){
    var modal=root.querySelector('[data-cd-modal]'), form=root.querySelector('[data-cd-form]'); if(!modal||!form)return;
    form.reset(); form.elements.id.value=event?event.id:''; form.elements.csrf.value=root.dataset.csrf||form.elements.csrf.value;
    if(event){form.elements.title.value=event.title||'';form.elements.date.value=(event.date||'').slice(0,16);form.elements.theme_id.value=event.theme_id||'project';form.elements.note.value=event.note||'';}
    syncThemePreview(form);
    var title=root.querySelector('[data-cd-dialog-title]');if(title)title.textContent=event?'Modifier le compte à rebours':'Nouveau compte à rebours';
    modal.hidden=false; modal.setAttribute('aria-hidden','false'); if(window.requestAnimationFrame){requestAnimationFrame(function(){modal.classList.add('is-open');});}else{modal.classList.add('is-open');}
  }
  function closeModal(root){var modal=root.querySelector('[data-cd-modal]');if(!modal)return;modal.classList.remove('is-open');modal.setAttribute('aria-hidden','true');setTimeout(function(){modal.hidden=true;},130);}
  function eventImageUrl(root,event){
    var base=String(root.dataset.moduleWeb||moduleBase(root)||'').replace(/\/$/,'');
    var token=String(event&&event.image||'');
    var theme=String(event&&event.theme_id||'project').replace(/[^a-zA-Z0-9_-]/g,'')||'project';
    var defaults={birthday:'birthday.jpg',meeting:'meeting.png',cooking:'cooking.png',sport:'sport.png',travel:'travel.png',project:'project.png'};
    if(token.indexOf('upload:')===0&&base){return base+'/dmd-countdown_media.php?file='+encodeURIComponent(token.slice(7).split('/').pop());}
    if(token.indexOf('default:')===0){theme=token.slice(8).replace(/[^a-zA-Z0-9_-]/g,'')||theme;}
    if(defaults[theme]&&base){return base+'/img/defaults/'+defaults[theme];}
    var url=String(event&&event.image_url||'');
    if(url&&base){
      var marker='/modules/DMD-Countdown/';
      var idx=url.indexOf(marker);
      if(idx>=0) return base+'/'+url.slice(idx+marker.length);
    }
    return url||(base?base+'/img/defaults/project.png':'');
  }
  function card(event,canEdit,canDelete,root){
    var actions='';
    if(canEdit)actions+='<button type="button" class="dmd-cd-iconbtn dmd-cd-editbtn" data-cd-edit="'+esc(event.id)+'" title="Modifier" aria-label="Modifier">✎</button>';
    if(canDelete)actions+='<button type="button" class="dmd-cd-iconbtn is-danger" data-cd-delete="'+esc(event.id)+'" title="Supprimer" aria-label="Supprimer">×</button>';
    var img=eventImageUrl(root,event);
    var fallback=(String(root.dataset.moduleWeb||moduleBase(root)||'').replace(/\/$/,'')+'/img/defaults/project.png');
    return '<article class="dmd-cd-app-card" data-event-id="'+esc(event.id)+'" data-event-status="'+esc(event.status)+'" data-search="'+esc((event.title+' '+(event.note||'')).toLowerCase())+'" data-countdown-date="'+esc(event.date)+'" data-dmd-context="1" data-dmd-context-type="countdown" data-dmd-context-id="'+esc(event.id)+'" data-dmd-context-label="'+esc(event.title)+'" data-dmd-context-source="DMD-Countdown" data-dmd-context-tags="'+esc(event.theme_id)+'"><img class="dmd-cd-app-card-image" src="'+esc(img)+'" data-fallback-src="'+esc(fallback)+'" alt=""><div class="dmd-cd-app-card-main"><div class="dmd-cd-app-card-top"><div class="dmd-cd-app-card-title"><strong>'+esc(event.title)+'</strong><small>'+esc(formatDate(event.date))+'</small></div><div class="dmd-cd-card-actions">'+actions+'</div></div><div class="dmd-cd-app-count" data-countdown-output>—</div>'+(event.note?'<p>'+esc(event.note)+'</p>':'')+'</div></article>';
  }
  function formatDate(v){var d=parseDate(v);if(!d)return v||'';return d.toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'}).replace(',',' ·');}
  function loadList(root){
    var list=root.querySelector('[data-cd-app-list]'); if(!list)return Promise.resolve();
    return api(root,'list').then(function(j){root._events=j.events||[];var canEdit=root.dataset.canEdit==='1',canDelete=root.dataset.canDelete==='1';list.innerHTML=root._events.length?root._events.map(function(e){return card(e,canEdit,canDelete,root);}).join(''):'<div class="dmd-cd-empty"><span>⏱️</span><strong>Aucun compte à rebours</strong><small>Crée ton premier événement.</small></div>';if(window.DMDActionHub)window.DMDActionHub.decorate(list);tick(root);applyFilter(root);});
  }
  function applyFilter(root){var q=(root.querySelector('[data-cd-search]')||{}).value||'';q=q.toLowerCase().trim();var active=root.querySelector('[data-cd-filter].is-active');var f=active?active.dataset.cdFilter:'all';root.querySelectorAll('[data-event-id]').forEach(function(el){var okQ=!q||String(el.dataset.search||'').indexOf(q)>=0;var st=el.dataset.eventStatus||'';var okF=f==='all'||(f==='done'?st==='done':st!=='done');el.hidden=!(okQ&&okF);});}
  function openEditById(root,id){
    id=String(id||'');if(!id)return;
    var event=(root._events||[]).find(function(x){return x.id===id;});
    if(event){openModal(root,event);return;}
    api(root,'list').then(function(j){root._events=j.events||[];var found=root._events.find(function(x){return x.id===id;});if(found)openModal(root,found);else alert('Événement introuvable.');}).catch(function(err){alert(err.message);});
  }
  function boot(root){
    if(!root||root.dataset.cdReady==='1')return;ensureDashboardDragHandle(root);compactDashboardHost(root);root.dataset.cdReady='1';tick(root);setInterval(function(){tick(root);},1000);
    root.addEventListener('click',function(e){
      var n=e.target.closest('[data-cd-new]');if(n){openModal(root,null);return;}
      if(e.target===root.querySelector('[data-cd-modal]')){closeModal(root);return;}
      if(e.target.closest('[data-cd-close]')){closeModal(root);return;}
      var edit=e.target.closest('[data-cd-edit]');if(edit){openEditById(root,edit.dataset.cdEdit);return;}
      var del=e.target.closest('[data-cd-delete]');if(del){if(!confirm('Supprimer ce compte à rebours ?'))return;var fd=new FormData();fd.set('csrf',root.dataset.csrf||'');fd.set('id',del.dataset.cdDelete);api(root,'delete',fd).then(function(){return loadList(root);}).catch(function(err){alert(err.message);});return;}
      var filter=e.target.closest('[data-cd-filter]');if(filter){root.querySelectorAll('[data-cd-filter]').forEach(function(b){b.classList.remove('is-active');});filter.classList.add('is-active');applyFilter(root);return;}
      var td=e.target.closest('[data-cd-theme-delete]');if(td){if(!confirm('Supprimer cette image de la bibliothèque ?'))return;var fdt=new FormData();fdt.set('csrf',root.dataset.csrf||'');fdt.set('id',td.dataset.cdThemeDelete);api(root,'theme_delete',fdt).then(function(){location.reload();}).catch(function(err){alert(err.message);});}
    });
    root.addEventListener('error',function(e){var img=e.target;if(!img||img.tagName!=='IMG')return;var fb=img.getAttribute('data-fallback-src');if(fb&&img.src!==fb){img.src=fb;}},true);
    var search=root.querySelector('[data-cd-search]');if(search)search.addEventListener('input',function(){applyFilter(root);});
    var themeSelect=root.querySelector('[data-cd-theme-select]');if(themeSelect)themeSelect.addEventListener('change',function(){syncThemePreview(themeSelect.form);});
    root.addEventListener('keydown',function(e){if(e.key==='Escape')closeModal(root);});
    var form=root.querySelector('[data-cd-form]');if(form)form.addEventListener('submit',function(e){e.preventDefault();var msg=form.querySelector('[data-cd-message]');if(msg)msg.textContent='Enregistrement…';var fd=new FormData(form);fd.set('csrf',root.dataset.csrf||fd.get('csrf')||'');api(root,'save',fd).then(function(){if(msg)msg.textContent='Enregistré.';closeModal(root);if(root.dataset.mode==='dashboard')location.reload();else return loadList(root);}).catch(function(err){if(msg)msg.textContent=err.message;});});
    var tf=root.querySelector('[data-cd-theme-form]');if(tf)tf.addEventListener('submit',function(e){e.preventDefault();var msg=root.querySelector('[data-cd-theme-message]');if(msg)msg.textContent='Enregistrement…';var fd=new FormData(tf);fd.set('csrf',root.dataset.csrf||'');api(root,'theme_save',fd).then(function(){location.reload();}).catch(function(err){if(msg)msg.textContent=err.message;});});
    if(root.querySelector('[data-cd-app-list]')) loadList(root);
    if(window.DMDActionHub)window.DMDActionHub.decorate(root);
  }
  document.querySelectorAll('[data-dmd-countdown-root]').forEach(boot);
  var obs=new MutationObserver(function(ms){ms.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType!==1)return;if(n.matches&&n.matches('[data-dmd-countdown-root]'))boot(n);if(n.querySelectorAll)n.querySelectorAll('[data-dmd-countdown-root]').forEach(boot);});});});
  if(document.body)obs.observe(document.body,{childList:true,subtree:true});
})();
