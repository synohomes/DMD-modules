<?php
/* DoMyDesk / DMD-Countdown media privé */
if (session_status() === PHP_SESSION_NONE) @session_start();
require_once __DIR__ . '/dmd-countdown_lib.php';
$email = dmd_countdown_email();
if ($email === '' || !dmd_countdown_has_permission($email, 'countdown.view')) { http_response_code(403); exit; }
$file = basename((string)(isset($_GET['file']) ? $_GET['file'] : ''));
if ($file === '' || !preg_match('/^[a-zA-Z0-9._-]+$/', $file)) { http_response_code(404); exit; }
$path = dmd_countdown_storage_dir($email, false) . '/uploads/' . $file;
if (!is_file($path)) { http_response_code(404); exit; }
$finfo = class_exists('finfo') ? new finfo(FILEINFO_MIME_TYPE) : null;
$mime = $finfo ? $finfo->file($path) : 'application/octet-stream';
if (!in_array($mime, array('image/jpeg','image/png','image/webp','image/gif'), true)) { http_response_code(415); exit; }
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('Cache-Control: private, max-age=3600');
header('X-Content-Type-Options: nosniff');
readfile($path);
