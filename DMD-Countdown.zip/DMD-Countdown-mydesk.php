<?php
/* DoMyDesk / DMD-Countdown - vue DMD-MyDesk type application */
if (session_status() === PHP_SESSION_NONE) @session_start();
require_once __DIR__ . '/dmd-countdown_lib.php';
$email = dmd_countdown_email();
if ($email === '') { echo '<div class="dmd-cd-state">Connexion requise.</div>'; return; }
if (!dmd_countdown_has_permission($email, 'module.view') || !dmd_countdown_has_permission($email, 'countdown.view')) { echo '<div class="dmd-cd-state">⛔ Accès refusé.</div>'; return; }
$moduleWeb = dmd_countdown_module_web_path();
$rootDir = dmd_countdown_root();
$webRoot = preg_replace('~/modules/' . preg_quote(DMD_COUNTDOWN_ID, '~') . '/?$~', '', $moduleWeb);
if (!is_string($webRoot)) $webRoot = '';
$webRoot = rtrim($webRoot, '/');
$theme = 'default';
$themeFile = $rootDir . '/users/profiles/' . basename($email) . '/theme.json';
if (is_file($themeFile)) {
    $td = json_decode((string)@file_get_contents($themeFile), true);
    if (is_array($td) && !empty($td['theme'])) {
        $candidate = basename((string)$td['theme']);
        if (is_file($rootDir . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
    }
}
$themes = dmd_countdown_theme_catalog($email);
$canCreate = dmd_countdown_has_permission($email, 'countdown.create');
$canEdit = dmd_countdown_has_permission($email, 'countdown.edit');
$canDelete = dmd_countdown_has_permission($email, 'countdown.delete');
?>
<link rel="stylesheet" href="<?= dmd_countdown_h(($webRoot!==''?$webRoot:'') . '/theme/' . rawurlencode($theme) . '/style.css') ?>">
<link rel="stylesheet" href="<?= dmd_countdown_h(($webRoot!==''?$webRoot:'') . '/core/dmd_theme_user.css.php') ?>?v=<?= rawurlencode(DMD_COUNTDOWN_VERSION) ?>">
<link rel="stylesheet" href="<?= dmd_countdown_h($moduleWeb) ?>/dmd-countdown.css?v=<?= rawurlencode(DMD_COUNTDOWN_VERSION) ?>">
<link rel="stylesheet" href="<?= dmd_countdown_h($moduleWeb) ?>/dmd-countdown-mydesk.css?v=<?= rawurlencode(DMD_COUNTDOWN_VERSION) ?>">
<div class="dmd-cd dmd-cd-app" data-dmd-countdown-root data-mode="mydesk" data-module-web="<?= dmd_countdown_h($moduleWeb) ?>" data-api="<?= dmd_countdown_h($moduleWeb) ?>/dmd-countdown_api.php" data-csrf="<?= dmd_countdown_h(dmd_countdown_csrf()) ?>" data-can-create="<?= $canCreate?'1':'0' ?>" data-can-edit="<?= $canEdit?'1':'0' ?>" data-can-delete="<?= $canDelete?'1':'0' ?>">
    <header class="dmd-cd-appbar"><div class="dmd-cd-brand"><img class="dmd-cd-appicon" src="<?= dmd_countdown_h($moduleWeb) ?>/icon.png" alt=""><div><strong>DMD-Countdown</strong><small>Échéances & comptes à rebours</small></div></div><?php if ($canCreate): ?><button type="button" class="dmd-cd-btn dmd-cd-btn-primary" data-cd-new>＋ Nouveau</button><?php endif; ?></header>
    <div class="dmd-cd-app-tools"><div class="dmd-cd-search"><span>⌕</span><input type="search" placeholder="Rechercher un événement…" data-cd-search></div><div class="dmd-cd-tabs"><button type="button" class="is-active" data-cd-filter="all">Tous</button><button type="button" data-cd-filter="upcoming">À venir</button><button type="button" data-cd-filter="done">Terminés</button></div></div>
    <main class="dmd-cd-app-content"><div class="dmd-cd-app-list" data-cd-app-list><div class="dmd-cd-loading">Chargement…</div></div></main>
    <div class="dmd-cd-modal" data-cd-modal hidden><div class="dmd-cd-dialog dmd-cd-dialog-app"><div class="dmd-cd-dialog-head"><div><strong data-cd-dialog-title>Nouveau compte à rebours</strong><small>Événement personnel</small></div><button type="button" class="dmd-cd-iconbtn" data-cd-close>×</button></div><form data-cd-form enctype="multipart/form-data"><input type="hidden" name="csrf" value="<?= dmd_countdown_h(dmd_countdown_csrf()) ?>"><input type="hidden" name="id"><div class="dmd-cd-form-grid"><label>Titre<input name="title" maxlength="120" required placeholder="Ex : Déploiement du serveur"></label><label>Date et heure<input name="date" type="datetime-local" required></label></div><div class="dmd-cd-theme-picker"><img class="dmd-cd-theme-preview" data-cd-theme-preview src="<?= dmd_countdown_h(dmd_countdown_image_url($email, dmd_countdown_theme_image_token($email, 'project'))) ?>" alt=""><label>Catégorie<select name="theme_id" data-cd-theme-select><?php foreach ($themes as $theme): ?><option value="<?= dmd_countdown_h($theme['id']) ?>" data-image-url="<?= dmd_countdown_h(dmd_countdown_image_url($email,$theme['image'])) ?>"><?= dmd_countdown_h($theme['icon'] . ' ' . $theme['name']) ?></option><?php endforeach; ?></select><small>Le logo de la catégorie sera appliqué automatiquement.</small></label></div><label>Note<textarea name="note" rows="4" placeholder="Contexte, objectif, rappel…"></textarea></label><label>Image personnalisée<input name="image" type="file" accept="image/png,image/jpeg,image/webp,image/gif"><small>Facultatif · si tu en choisis une, elle remplace le logo de catégorie pour cet enregistrement.</small></label><div class="dmd-cd-form-actions"><button type="button" class="dmd-cd-btn" data-cd-close>Annuler</button><button type="submit" class="dmd-cd-btn dmd-cd-btn-primary">Enregistrer</button></div><div class="dmd-cd-message" data-cd-message></div></form></div></div>
</div>
<script src="<?= dmd_countdown_h($moduleWeb) ?>/dmd-countdown.js?v=<?= rawurlencode(DMD_COUNTDOWN_VERSION) ?>"></script>
<script>
(function(){
  var names=['--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow'];
  var source=null; try{ if(window.opener&&!window.opener.closed) source=window.opener; else if(window.parent&&window.parent!==window) source=window.parent; }catch(e){}
  if(!source) return; try{ var cs=source.getComputedStyle(source.document.documentElement); names.forEach(function(n){var v=cs.getPropertyValue(n);if(v&&v.trim())document.documentElement.style.setProperty(n,v.trim());}); }catch(e){}
})();
</script>
