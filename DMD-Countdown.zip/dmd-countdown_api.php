<?php
/* DoMyDesk / DMD-Countdown API - 1.0.5 */
if (session_status() === PHP_SESSION_NONE) @session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/dmd-countdown_lib.php';

function dmd_cd_api_reply($ok, $message, $extra, $status) {
    http_response_code($status);
    echo json_encode(array_merge(array('ok'=>(bool)$ok,'message'=>(string)$message), is_array($extra)?$extra:array()), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function dmd_cd_api_input() {
    $ct = isset($_SERVER['CONTENT_TYPE']) ? strtolower((string)$_SERVER['CONTENT_TYPE']) : '';
    if (strpos($ct, 'application/json') !== false) {
        $data = json_decode((string)file_get_contents('php://input'), true);
        return is_array($data) ? $data : array();
    }
    return $_POST;
}
$email = dmd_countdown_email();
if ($email === '') dmd_cd_api_reply(false, 'Connexion requise.', array(), 403);
$action = trim((string)(isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : 'list')));

if ($action === 'list') {
    if (!dmd_countdown_has_permission($email, 'countdown.view')) dmd_cd_api_reply(false, 'Accès refusé.', array(), 403);
    $events = dmd_countdown_list($email);
    foreach ($events as $i => $event) {
        $events[$i]['status'] = dmd_countdown_status($event);
        $events[$i]['image_url'] = dmd_countdown_image_url($email, $event['image']);
        $events[$i]['resource'] = dmd_countdown_resource($event);
    }
    dmd_cd_api_reply(true, 'OK', array('events'=>$events,'themes'=>array_values(dmd_countdown_theme_catalog($email)),'csrf'=>dmd_countdown_csrf()), 200);
}

$input = dmd_cd_api_input();
$token = isset($input['csrf']) ? (string)$input['csrf'] : (isset($_SERVER['HTTP_X_DMD_CSRF']) ? (string)$_SERVER['HTTP_X_DMD_CSRF'] : '');
if (!dmd_countdown_check_csrf($token)) dmd_cd_api_reply(false, 'Session expirée. Recharge la page.', array(), 419);

if ($action === 'save') {
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($input['id']) ? $input['id'] : ''));
    $old = $id !== '' ? dmd_countdown_find($email, $id) : null;
    $perm = $old ? 'countdown.edit' : 'countdown.create';
    if (!dmd_countdown_has_permission($email, $perm)) dmd_cd_api_reply(false, 'Droit insuffisant.', array('permission'=>$perm), 403);
    if ($id === '') $id = dmd_countdown_new_id();
    $title = trim((string)(isset($input['title']) ? $input['title'] : ''));
    $date = trim((string)(isset($input['date']) ? $input['date'] : ''));
    $themeId = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($input['theme_id']) ? $input['theme_id'] : 'project'));
    $note = trim((string)(isset($input['note']) ? $input['note'] : ''));
    if ($title === '') dmd_cd_api_reply(false, 'Le titre est obligatoire.', array(), 400);
    if ($date === '' || strtotime($date) === false) dmd_cd_api_reply(false, 'La date est invalide.', array(), 400);
    $themes = dmd_countdown_theme_catalog($email);
    if ($themeId === '' || !isset($themes[$themeId])) $themeId = 'project';
    /* La catégorie choisie impose son visuel ; un upload dans ce même enregistrement peut le remplacer. */
    $image = dmd_countdown_theme_image_token($email, $themeId);
    $uploadError = '';
    $uploaded = dmd_countdown_upload($email, 'image', $uploadError);
    if ($uploadError !== '') dmd_cd_api_reply(false, $uploadError, array(), 400);
    if ($uploaded !== '') $image = $uploaded;
    $now = date(DATE_ATOM);
    $event = array(
        'id'=>$id,'title'=>$title,'date'=>$date,'theme_id'=>$themeId,'image'=>$image,'note'=>$note,
        'created_at'=>$old ? $old['created_at'] : $now,'updated_at'=>$now
    );
    if (!dmd_countdown_save($email, $event)) dmd_cd_api_reply(false, 'Enregistrement impossible.', array(), 500);
    dmd_countdown_emit($email, $old ? 'countdown.update' : 'countdown.create', $event, $old ? 'Compte à rebours modifié.' : 'Compte à rebours créé.', array());
    $event['status'] = dmd_countdown_status($event);
    $event['image_url'] = dmd_countdown_image_url($email, $event['image']);
    $event['resource'] = dmd_countdown_resource($event);
    dmd_cd_api_reply(true, $old ? 'Compte à rebours modifié.' : 'Compte à rebours créé.', array('event'=>$event), 200);
}

if ($action === 'delete') {
    if (!dmd_countdown_has_permission($email, 'countdown.delete')) dmd_cd_api_reply(false, 'Droit insuffisant.', array(), 403);
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($input['id']) ? $input['id'] : ''));
    $event = dmd_countdown_find($email, $id);
    if (!$event) dmd_cd_api_reply(false, 'Événement introuvable.', array(), 404);
    if (!dmd_countdown_delete($email, $id)) dmd_cd_api_reply(false, 'Suppression impossible.', array(), 500);
    dmd_countdown_emit($email, 'countdown.delete', $event, 'Compte à rebours supprimé.', array());
    dmd_cd_api_reply(true, 'Compte à rebours supprimé.', array(), 200);
}

if ($action === 'theme_save') {
    if (!dmd_countdown_has_permission($email, 'config.library')) dmd_cd_api_reply(false, 'Droit insuffisant.', array(), 403);
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', strtolower((string)(isset($input['theme_id']) ? $input['theme_id'] : '')));
    $name = trim((string)(isset($input['theme_name']) ? $input['theme_name'] : ''));
    if ($id === '' || $name === '') dmd_cd_api_reply(false, 'Nom et identifiant requis.', array(), 400);
    $defaults = dmd_countdown_defaults();
    if (isset($defaults[$id])) dmd_cd_api_reply(false, 'Cet identifiant est réservé.', array(), 400);
    $uploadError = '';
    $image = dmd_countdown_upload($email, 'image', $uploadError);
    if ($uploadError !== '') dmd_cd_api_reply(false, $uploadError, array(), 400);
    if ($image === '') dmd_cd_api_reply(false, 'Choisis une image.', array(), 400);
    $catalog = dmd_countdown_theme_catalog($email);
    $catalog[$id] = array('id'=>$id,'name'=>substr($name,0,80),'icon'=>'🖼️','image'=>$image);
    if (!dmd_countdown_save_custom_themes($email, $catalog)) dmd_cd_api_reply(false, 'Enregistrement impossible.', array(), 500);
    dmd_cd_api_reply(true, 'Image ajoutée à la bibliothèque.', array(), 200);
}

if ($action === 'theme_delete') {
    if (!dmd_countdown_has_permission($email, 'config.library')) dmd_cd_api_reply(false, 'Droit insuffisant.', array(), 403);
    $id = preg_replace('/[^a-zA-Z0-9_-]/', '', strtolower((string)(isset($input['id']) ? $input['id'] : '')));
    $defaults = dmd_countdown_defaults();
    if (isset($defaults[$id])) dmd_cd_api_reply(false, 'Les catégories intégrées ne peuvent pas être supprimées.', array(), 400);
    $catalog = dmd_countdown_theme_catalog($email);
    if (!isset($catalog[$id])) dmd_cd_api_reply(false, 'Image introuvable.', array(), 404);
    unset($catalog[$id]);
    if (!dmd_countdown_save_custom_themes($email, $catalog)) dmd_cd_api_reply(false, 'Suppression impossible.', array(), 500);
    dmd_cd_api_reply(true, 'Image supprimée.', array(), 200);
}

dmd_cd_api_reply(false, 'Action inconnue.', array(), 400);
