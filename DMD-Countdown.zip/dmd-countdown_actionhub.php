<?php
/* DoMyDesk / DMD-Countdown - ActionHub handler */
require_once __DIR__ . '/dmd-countdown_lib.php';

function dmd_countdown_actionhub_handle($context) {
    $email = trim((string)(isset($context['email']) ? $context['email'] : ''));
    $action = isset($context['action']['id']) ? (string)$context['action']['id'] : '';
    $payload = isset($context['payload']) && is_array($context['payload']) ? $context['payload'] : array();
    $resource = isset($context['resource']) && is_array($context['resource']) ? $context['resource'] : null;

    if ($action === 'countdown.open') {
        $id = $resource ? (string)$resource['id'] : '';
        $event = dmd_countdown_find($email, $id);
        if (!$event) return array('ok'=>false,'error'=>'not_found','message'=>'Compte à rebours introuvable.');
        return array('ok'=>true,'message'=>'Compte à rebours disponible.','data'=>array('event'=>$event));
    }

    if ($action === 'countdown.reschedule') {
        $id = $resource ? (string)$resource['id'] : '';
        $event = dmd_countdown_find($email, $id);
        if (!$event) return array('ok'=>false,'error'=>'not_found','message'=>'Compte à rebours introuvable.');
        $date = trim((string)(isset($payload['date']) ? $payload['date'] : ''));
        if ($date === '' || strtotime($date) === false) return array('ok'=>false,'error'=>'invalid_date','message'=>'Date invalide.');
        $event['date'] = $date; $event['updated_at'] = date(DATE_ATOM);
        if (!dmd_countdown_save($email, $event)) return array('ok'=>false,'error'=>'write_failed','message'=>'Modification impossible.');
        dmd_countdown_emit($email, 'countdown.reschedule', $event, 'Échéance modifiée depuis ActionHub.', array());
        return array('ok'=>true,'message'=>'Nouvelle échéance enregistrée.','event_emitted'=>true,'data'=>array('event'=>$event));
    }

    if ($action === 'countdown.delete') {
        $id = $resource ? (string)$resource['id'] : '';
        $event = dmd_countdown_find($email, $id);
        if (!$event) return array('ok'=>false,'error'=>'not_found','message'=>'Compte à rebours introuvable.');
        if (!dmd_countdown_delete($email, $id)) return array('ok'=>false,'error'=>'write_failed','message'=>'Suppression impossible.');
        dmd_countdown_emit($email, 'countdown.delete', $event, 'Compte à rebours supprimé depuis ActionHub.', array());
        return array('ok'=>true,'message'=>'Compte à rebours supprimé.','event_emitted'=>true);
    }

    if ($action === 'scenario.countdown.create') {
        $title = trim((string)(isset($payload['title']) ? $payload['title'] : ''));
        $date = trim((string)(isset($payload['date']) ? $payload['date'] : ''));
        $theme = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)(isset($payload['theme_id']) ? $payload['theme_id'] : 'project'));
        $note = trim((string)(isset($payload['note']) ? $payload['note'] : ''));
        if ($title === '' || $date === '' || strtotime($date) === false) return array('ok'=>false,'error'=>'invalid_input','message'=>'Titre et date valide requis.');
        $catalog = dmd_countdown_theme_catalog($email); if (!isset($catalog[$theme])) $theme='project';
        $event = array('id'=>dmd_countdown_new_id(),'title'=>$title,'date'=>$date,'theme_id'=>$theme,'image'=>$catalog[$theme]['image'],'note'=>$note,'created_at'=>date(DATE_ATOM),'updated_at'=>date(DATE_ATOM));
        if (!dmd_countdown_save($email, $event)) return array('ok'=>false,'error'=>'write_failed','message'=>'Création impossible.');
        dmd_countdown_emit($email, 'countdown.create', $event, 'Compte à rebours créé par scénario ActionHub.', array());
        return array('ok'=>true,'message'=>'Compte à rebours créé.','event_emitted'=>true,'data'=>array('event'=>$event));
    }

    return array('ok'=>false,'error'=>'unsupported_action','message'=>'Action non prise en charge.');
}
