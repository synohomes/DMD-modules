/* DMD-VNC: noVNC raw channel, HTTP polling of TCP-backed PHP relay.
 * Unlike SSE, PHP does not have to stream binary frames through FastCGI.
 */
const NativeSocket = window.WebSocket;
export class VncHttpSocket {
 static CONNECTING=0;static OPEN=1;static CLOSING=2;static CLOSED=3;
 constructor(url){
  this.binaryType='arraybuffer';this.bufferedAmount=0;this.extensions='';this.protocol='';
  this.readyState=VncHttpSocket.CONNECTING;
  this.onopen=null;this.onmessage=null;this.onclose=null;this.onerror=null;
  this.ontransporterror=null;this.ontrace=null;
  this.receivedBytes=0;this.sentBytes=0;this.httpStatus=0;this.lastHttpPost=0;
  this.lastError='';this.phase='Initialisation du relais';this.startedAt=Date.now();this.lastPacketAt=0;
  this.abort=new AbortController();this.pending=Promise.resolve();this._opened=false;this._pumpRequest=null;this._handshakeBytes=[];this._reportedVersion=false;this._reportedSecurity=false;this._clientVersion='';
  const source=decodeURIComponent(url.slice('dmv-http:'.length));
  const [api,token,csrf]=source.split('|');
  if(!api||!token||!csrf)throw new Error('Paramètres du relais VNC manquants');
  this.api=api;this.token=token;this.csrf=csrf;
  queueMicrotask(()=>this._run());
 }
 _trace(msg){this.ontrace?.(msg)}
 _inspectHandshake(bytes){
  // Record only the public RFB banner and security type IDs, never passwords or challenges.
  if(this._reportedSecurity)return;
  const incoming=this._handshakeBytes;
  for(const b of bytes){if(incoming.length>=48)break;incoming.push(b);}
  if(incoming.length<12)return;
  const banner=String.fromCharCode(...incoming.slice(0,12));
  if(!this._reportedVersion){this._reportedVersion=true;this._trace('Annonce du serveur : '+banner.trim());}
  if(!/^RFB [0-9]{3}\.[0-9]{3}\n$/.test(banner))return;
  if(!this._clientVersion||incoming.length<13)return;
  const legacy=this._clientVersion==='003.003';
  if(legacy){
   if(incoming.length<16)return;
   const type=((incoming[12]<<24)|(incoming[13]<<16)|(incoming[14]<<8)|incoming[15])>>>0;
   this._trace('Sécurité RFB 3.3 : méthode '+type+' ('+(type===1?'aucune':type===2?'mot de passe VNC':'propriétaire ou non prise en charge')+')');
  }else{
   const count=incoming[12];
   if(count===0){this._trace('Le serveur annonce zéro méthode de sécurité');this._reportedSecurity=true;return;}
   if(count>32){this._trace('Liste de sécurité RFB invalide : '+count+' méthodes annoncées');this._reportedSecurity=true;return;}
   if(incoming.length<13+count)return;
   const types=incoming.slice(13,13+count);
   this._trace('Sécurité RFB 3.8 : méthodes proposées ['+types.join(', ')+'] ; standard : 1=aucune, 2=mot de passe VNC, 19=VeNCrypt');
  }
  this._reportedSecurity=true;
 }
 _fail(message){
  if(this.readyState===VncHttpSocket.CLOSED)return;
  if(!this.lastError){this.lastError='['+this.phase+'] '+message;this._trace('ERREUR : '+this.lastError);this.ontransporterror?.(this.lastError);this.onerror?.(new Error(this.lastError));}
  this.close();
 }
 async _request(url,options={}){
  const controller=new AbortController();
  const onAbort=()=>controller.abort();
  this.abort.signal.addEventListener('abort',onAbort,{once:true});
  const timer=setTimeout(()=>controller.abort(),12000);
  try {return await fetch(url,{credentials:'same-origin',cache:'no-store',...options,signal:controller.signal});}
  finally {clearTimeout(timer);this.abort.signal.removeEventListener('abort',onAbort);}
 }
 async _run(){
  let seq=1;let since=Date.now();let started=false;
  try {
   this.phase='Démarrage du relais TCP PHP';this._trace(this.phase);
   // This request owns the TCP socket for the session. Its response may be
   // buffered by Apache/nginx/FastCGI; the client intentionally does not await it.
   this._pumpRequest=fetch(this.api+'?mode=stream&token='+encodeURIComponent(this.token),{
    credentials:'same-origin',cache:'no-store',signal:this.abort.signal,headers:{Accept:'text/plain'}
   }).then(async r=>{
    this.httpStatus=r.status;
    if(!r.ok){const detail=await r.text().catch(()=>'');if(this.readyState!==VncHttpSocket.CLOSED)this._fail('Démarrage du relais : HTTP '+r.status+' '+detail.slice(0,200));}
   }).catch(err=>{if(!this.abort.signal.aborted)this._fail('Relais TCP interrompu : '+err.message)});
   this.phase='Lecture des données RFB par HTTP';
   while(this.readyState!==VncHttpSocket.CLOSED){
    const url=this.api+'?mode=poll&token='+encodeURIComponent(this.token)+'&seq='+seq+'&_='+Date.now();
    let response;
    try{response=await this._request(url,{headers:{Accept:'application/json'}});}
    catch(err){if(this.abort.signal.aborted)break;throw new Error('La requête de lecture du relais a expiré : vérifier les workers PHP disponibles ('+err.message+')');}
    if(this.readyState===VncHttpSocket.CLOSED)break;
    if(!response.ok){const content=await response.text().catch(()=>'');throw new Error('Lecture des données VNC : HTTP '+response.status+' '+content.slice(0,180));}
    if(!this.httpStatus)this.httpStatus=response.status;
    let report;
    try {report=await response.json();}catch(e){throw new Error('Lecture VNC : réponse JSON invalide : '+e.message)}
    if(!report.ok)throw new Error(report.error||'Lecture VNC rejetée');
    if(report.status==='active' && !started){
     started=true;this._opened=true;this.readyState=VncHttpSocket.OPEN;
     this._trace('Relais TCP actif ; les octets RFB sont lus sans diffusion HTTP continue');
     this.onopen?.({});
    }
    // The first bytes may be received before the relay status flips to active.
    if(report.frames?.length && !started){
     started=true;this._opened=true;this.readyState=VncHttpSocket.OPEN;
     this.onopen?.({});
    }
    for(const encoded of report.frames||[]){
     const bin=atob(encoded),bytes=new Uint8Array(bin.length);
     for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);
     this.receivedBytes+=bytes.length;
     this.lastPacketAt=Date.now();this.phase='Échange RFB';
     if(this.receivedBytes===bytes.length)this._trace('Première réponse VNC : '+bytes.length+' octets');this._inspectHandshake(bytes);
     if(this.readyState===VncHttpSocket.OPEN)this.onmessage?.({data:bytes.buffer});
    }
    seq=report.seq;
    if(report.status==='error'||report.status==='closed')throw new Error('Relais PHP : '+(report.reason||'session VNC terminée')+' ; TCP reçus='+report.rx+' transmis='+report.tx);
    if(!started && Date.now()-since>18000)throw new Error('Relais TCP non démarré sous 18 secondes : serveur PHP occupé ou connexion réseau bloquée');
    if(started && this.receivedBytes===0 && Date.now()-since>18000)throw new Error('Aucune bannière RFB reçue après 18 secondes ; vérifier le relais TCP et les permissions du stockage');
   }
  }catch(err){if(!this.abort.signal.aborted)this._fail(err?.message||String(err));}
 }
 send(data){
  if(this.readyState!==VncHttpSocket.OPEN)throw new Error('Relais VNC inactif');
  const bytes=data instanceof Uint8Array?data:new Uint8Array(data);
  const copy=bytes.slice();
  if(copy.length===12&&copy[0]===82&&copy[1]===70&&copy[2]===66&&copy[3]===32&&copy[11]===10){
   this._clientVersion=String.fromCharCode(...copy.subarray(4,11));this._trace('Version RFB du client : '+this._clientVersion);
   if(!this._reportedSecurity&&this._handshakeBytes.length>12)this._inspectHandshake([]);
  }
  this.sentBytes+=copy.length;
  this.pending=this.pending.then(async()=>{
   if(this.readyState!==VncHttpSocket.OPEN)return;
   let binary='';for(let i=0;i<copy.length;i+=8192)binary+=String.fromCharCode(...copy.subarray(i,i+8192));
   const body=new URLSearchParams({mode:'send',token:this.token,csrf:this.csrf,packet:btoa(binary)});
   const response=await this._request(this.api,{method:'POST',body});
   this.lastHttpPost=response.status;
   if(!response.ok){const detail=await response.text().catch(()=>'');throw Error('Transmission TCP HTTP '+response.status+' '+detail.slice(0,200));}
  }).catch(err=>{if(this.readyState===VncHttpSocket.OPEN)this._fail('Émission VNC : '+err.message)});
 }
 close(){
  if(this.readyState===VncHttpSocket.CLOSED)return;
  this.readyState=VncHttpSocket.CLOSED;
  this.abort.abort();
  const body=new URLSearchParams({mode:'stop',token:this.token,csrf:this.csrf});
  // Cannot await: noVNC expects close() to be synchronous.
  fetch(this.api,{method:'POST',credentials:'same-origin',cache:'no-store',body,keepalive:true}).catch(()=>{});
  this.onclose?.({code:this.lastError?1006:1000,reason:this.lastError||'Session terminée',wasClean:!this.lastError});
 }
}
export class VncTransport {
 static CONNECTING=0;static OPEN=1;static CLOSING=2;static CLOSED=3;
 constructor(url,protocols){return url.startsWith('dmv-http:')?new VncHttpSocket(url):new NativeSocket(url,protocols);}
}
