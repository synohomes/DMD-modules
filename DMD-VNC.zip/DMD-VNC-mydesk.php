<?php
require_once __DIR__.'/DMD-VNC_lib.php';
if (!dmv_perm('view')) { http_response_code(403); exit('Accès refusé'); }
?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:var(--background-color,var(--bg-color,#10151d));color:var(--text-color,#e5eaf2)}body>.dmv{height:100dvh}</style></head><body><?php require __DIR__.'/DMD-VNC.php'; ?></body></html>
