<?php
require_once __DIR__.'/DMD-VNC_lib.php';
function dmd_vnc_actionhub_catalog($context){$actions=[];foreach(dmv_devices() as $d){if(dmv_acl($d['id'],'connect'))$actions[]=['id'=>'vnc.open.'.$d['id'],'label'=>'Ouvrir VNC · '.$d['name'],'group'=>'DMD-VNC','permission'=>'connect','resource'=>['type'=>'vnc_device','id'=>'DMD-VNC:device:'.$d['id']]];}return ['replace'=>true,'actions'=>$actions];}
function dmd_vnc_actionhub_handle($context){$action=(string)($context['action_id']??$context['action']??'');if(!preg_match('/^vnc\.open\.([a-f0-9]{16})$/',$action,$m)||!dmv_device($m[1])||!dmv_acl($m[1],'connect'))return ['ok'=>false,'message'=>'Accès VNC refusé'];return ['ok'=>true,'message'=>'Équipement disponible dans DMD-VNC','url'=>'DMD-VNC.php?device='.$m[1]];}
