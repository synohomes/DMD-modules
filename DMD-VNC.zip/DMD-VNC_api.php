<?php
require_once __DIR__.'/DMD-VNC_lib.php';
if(!dmv_perm('view'))dmv_json(['ok'=>false,'message'=>'Accès refusé'],403);
$action=(string)($_REQUEST['action']??'list');
if($action==='list'){
 $out=[];foreach(dmv_devices() as $d)if(dmv_acl($d['id'],'view'))$out[]=dmv_public($d);
 dmv_json(['ok'=>true,'devices'=>$out,'can_manage'=>dmv_perm('manage'),'can_acl'=>dmv_perm('acl.manage'),'csrf'=>dmv_token()]);
}
if($_SERVER['REQUEST_METHOD']!=='POST'||!dmv_check())dmv_json(['ok'=>false,'message'=>'Requête refusée (CSRF)'],403);
$id=(string)($_POST['id']??'');
if($action==='save'){
 if(!dmv_perm('manage'))dmv_json(['ok'=>false],403);
 $name=trim((string)($_POST['name']??''));$endpoint=trim((string)($_POST['endpoint']??''));$host=trim((string)($_POST['host']??''));$port=filter_var($_POST['port']??5900,FILTER_VALIDATE_INT,['options'=>['min_range'=>1,'max_range'=>65535]]);$group=trim((string)($_POST['group']??''));$description=trim((string)($_POST['description']??''));$kind=trim((string)($_POST['kind']??'other'));$favorite=($_POST['favorite']??'')==='1';
 if(strlen($name)>120||$name===''||strlen($group)>80||strlen($description)>500||!in_array($kind,['domybox','thin','linux','windows','other'],true)||!dmv_host($host)||$port===false||($endpoint!==''&&!dmv_endpoint($endpoint)))dmv_json(['ok'=>false,'message'=>'Nom, adresse IP, port ou WebSocket invalide'],400);
 $ds=dmv_devices();$found=false;
 if($id!==''){foreach($ds as &$d){if($d['id']===$id){$d=['id'=>$id,'name'=>$name,'endpoint'=>$endpoint,'host'=>$host,'port'=>$port,'group'=>$group,'description'=>$description,'kind'=>$kind,'favorite'=>$favorite];$found=true;break;}}unset($d);if(!$found)dmv_json(['ok'=>false,'message'=>'Équipement inconnu'],404);}
 else{$id=bin2hex(random_bytes(8));$ds[]=['id'=>$id,'name'=>$name,'endpoint'=>$endpoint,'host'=>$host,'port'=>$port,'group'=>$group,'description'=>$description,'kind'=>$kind,'favorite'=>$favorite];}
 if(!dmv_save('devices.json',$ds))dmv_json(['ok'=>false,'message'=>'Écriture impossible'],500);
 dmv_log('device.save',$id);dmv_json(['ok'=>true,'id'=>$id]);
}
if($action==='delete'){
 if(!dmv_perm('manage')||!dmv_device($id))dmv_json(['ok'=>false],403);
 if(!dmv_save('devices.json',array_values(array_filter(dmv_devices(),fn($d)=>$d['id']!==$id))))dmv_json(['ok'=>false],500);
 $a=dmv_read('acl.json');unset($a[$id]);dmv_save('acl.json',$a);dmv_log('device.delete',$id);dmv_json(['ok'=>true]);
}
if($action==='acl_list'){
 if(!dmv_perm('acl.manage')||!dmv_device($id))dmv_json(['ok'=>false],403);
 dmv_json(['ok'=>true,'rules'=>dmv_read('acl.json')[$id]??[]]);
}
if($action==='acl_remove'){
 if(!dmv_perm('acl.manage')||!dmv_device($id))dmv_json(['ok'=>false],403);
 $email=strtolower(trim((string)($_POST['email']??'')));$a=dmv_read('acl.json');unset($a[$id][$email]);
 if(isset($a[$id])&&!$a[$id])unset($a[$id]);
 if(!dmv_save('acl.json',$a))dmv_json(['ok'=>false],500);dmv_log('acl.remove',$id);dmv_json(['ok'=>true]);
}
if($action==='acl'){
 if(!dmv_perm('acl.manage')||!dmv_device($id))dmv_json(['ok'=>false],403);
 $email=strtolower(trim((string)($_POST['email']??'')));$perms=(array)($_POST['permissions']??[]);
 if(!filter_var($email,FILTER_VALIDATE_EMAIL))dmv_json(['ok'=>false,'message'=>'Adresse e-mail invalide'],400);
 $perms=array_values(array_intersect(['view','connect','control'],$perms));$a=dmv_read('acl.json');if(!isset($a[$id]))$a[$id]=[];$a[$id][$email]=$perms;
 if(!dmv_save('acl.json',$a))dmv_json(['ok'=>false],500);dmv_log('acl.save',$id);dmv_json(['ok'=>true]);
}
if($action==='diagnose'){
 if(!dmv_device($id)||!dmv_acl($id,'connect'))dmv_json(['ok'=>false,'message'=>'Accès au diagnostic refusé'],403);
 $d=dmv_device($id);$host=(string)($d['host']??'');$port=(int)($d['port']??5900);
 $steps=[];$add=static function($stage,$ok,$detail)use(&$steps){$steps[]=['stage'=>$stage,'ok'=>(bool)$ok,'detail'=>$detail];};
 $add('PHP',function_exists('stream_socket_client'),'stream_socket_client '.(function_exists('stream_socket_client')?'disponible':'indisponible'));
 $add('Stockage',dmv_dir()!=='' && is_writable(dmv_dir()),'Répertoire des données du module '.(is_writable(dmv_dir())?'accessible en écriture':'NON accessible en écriture'));
 $endpoint=(string)($d['endpoint']??'');
 if($endpoint!==''){
   $add('Transport',true,'WebSocket configuré : ce test TCP ne s’applique pas. Contrôler son URL et ses certificats.');
 }elseif(!function_exists('stream_socket_client')){
   $add('Transport',false,'PHP ne permet pas la connexion TCP sortante');
 }else{
   $ip=filter_var($host,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)?$host:gethostbyname($host);
   $private=filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4) && preg_match('/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/',$ip);
   $add('Résolution et réseau',!!$private,$private?'Cible résolue : '.$ip.':'.$port:'Cible non résolue ou IP refusée par la restriction aux réseaux privés : '.$host);
   if($private){
     $errno=0;$errstr='';$start=microtime(true);
     $socket=@stream_socket_client('tcp://'.$ip.':'.$port,$errno,$errstr,5,STREAM_CLIENT_CONNECT);
     $delay=round((microtime(true)-$start)*1000);
     $add('TCP',!!$socket,$socket?'Connexion TCP établie en '.$delay.' ms':"Échec TCP ($errno) : ".($errstr?:'délai expiré / port fermé / pare-feu'));
     if($socket){
       stream_set_timeout($socket,3);
       $readBytes=static function($stream,int $length): string {
          $out='';$until=microtime(true)+3;
          while(strlen($out)<$length && microtime(true)<$until){
             $buf=@fread($stream,$length-strlen($out));
             if($buf===false || $buf==='')break;
             $out.=$buf;
          }
          return $out;
       };
       $banner=$readBytes($socket,12);$meta=stream_get_meta_data($socket);
       $valid=preg_match('/^RFB [0-9]{3}\.[0-9]{3}\n$/D',$banner)===1;
       $add('Protocole RFB',$valid,$valid?'Bannière VNC : '.trim($banner):($meta['timed_out']?'Délai dépassé en attendant la bannière RFB':'Réponse non VNC ou vide ('.strlen($banner).' octets)'));
       if($valid){
          $version=substr($banner,4,7);
          $useLegacy=version_compare($version,'003.007','<');
          $clientVersion=$useLegacy?'003.003':'003.008';
          $write=@fwrite($socket,'RFB '.$clientVersion."\n");
          if($write!==12){$add('Sécurité RFB',false,'Impossible d’envoyer la version client');}
          elseif($useLegacy){
             $scheme=$readBytes($socket,4);
             if(strlen($scheme)===4){
                $kind=unpack('N',$scheme)[1];
                $ok=in_array($kind,[1,2],true);
                $add('Sécurité RFB',$ok,'Protocole 3.3 : méthode '.$kind.($kind===1?' (sans authentification)':($kind===2?' (mot de passe VNC)':' (extension / authentification non standard)')));
             }else{$add('Sécurité RFB',false,'Réponse 3.3 incomplète : '.strlen($scheme).'/4 octets');}
          }else{
             $countBytes=$readBytes($socket,1);
             if(strlen($countBytes)===1){
                $count=ord($countBytes);
                if($count===0){$add('Sécurité RFB',false,'Le serveur refuse toute méthode de sécurité');}
                elseif($count>32){$add('Sécurité RFB',false,'Liste de sécurité invalide : '.$count.' méthodes');}
                else{
                   $schemes=$readBytes($socket,$count);
                   $ids=array_values(unpack('C*',$schemes)?:[]);
                   $supported=[1,2,6,16,19,22,30,113];
                   $compatible=array_values(array_intersect($ids,$supported));
                   $ok=strlen($schemes)===$count && count($compatible)>0;
                   $add('Sécurité RFB',$ok,'Protocole '.$clientVersion.' : méthodes proposées ['.implode(', ',$ids).']; compatibles noVNC ['.implode(', ',$compatible).']'.(strlen($schemes)!==$count?' (réponse incomplète)':''));
                }
             }else{$add('Sécurité RFB',false,'Aucune liste de sécurité renvoyée après RFB '.$clientVersion);}
          }
       }
       @fclose($socket);
     }
   }
 }
 $add('Transport navigateur',true,'Le relais conserve une session TCP en PHP et transfère les octets RFB par requêtes HTTP courtes. Aucun streaming HTTP sans tamponnement n’est requis. Le relais demande au moins deux workers PHP disponibles en parallèle.');
 $ok=!in_array(false,array_column($steps,'ok'),true);
 dmv_log($ok?'diagnostic.ok':'diagnostic.fail',$id);
 $logpath=dmv_path('diagnostics.jsonl');if($logpath)@file_put_contents($logpath,json_encode(['at'=>gmdate('c'),'user'=>dmv_email(),'device'=>$id,'steps'=>$steps],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n",FILE_APPEND|LOCK_EX);
 dmv_json(['ok'=>true,'healthy'=>$ok,'steps'=>$steps,'at'=>gmdate('c')]);
}
if($action==='diagnostics_log'){
 if(!dmv_perm('manage'))dmv_json(['ok'=>false,'message'=>'Accès refusé'],403);
 $path=dmv_path('diagnostics.jsonl');$lines=is_file($path)?array_slice(file($path,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES)?:[],-30):[];
 dmv_json(['ok'=>true,'entries'=>array_reverse(array_values(array_filter(array_map(static fn($line)=>json_decode($line,true),$lines),'is_array')))]);
}
if($action==='session'){
 if(!dmv_device($id)||!dmv_acl($id,'view')||!dmv_acl($id,'connect'))dmv_json(['ok'=>false,'message'=>'Connexion interdite'],403);
 $d=dmv_device($id);dmv_log('session.open',$id);
 $endpoint=(string)($d['endpoint']??'');
 if($endpoint==='') {
   $token=bin2hex(random_bytes(24));
   $record=['id'=>$id,'email'=>dmv_email(),'expires'=>time()+3600];
   if(!dmv_save('tunnel-'.$token.'.json',$record))dmv_json(['ok'=>false,'message'=>'Impossible de préparer le transport VNC'],500);
   $base=dirname((string)($_SERVER['SCRIPT_NAME']??''));
   $endpoint='dmv-http:'.rawurlencode(rtrim($base,'/').'/DMD-VNC_transport.php|'.$token.'|'.dmv_token());
 }
 dmv_json(['ok'=>true,'endpoint'=>$endpoint,'control'=>dmv_acl($id,'control'),'name'=>$d['name']]);
}
if($action==='closed'){if(!dmv_device($id))dmv_json(['ok'=>false],404);dmv_log('session.close',$id);dmv_json(['ok'=>true]);}
dmv_json(['ok'=>false,'message'=>'Action inconnue'],404);
