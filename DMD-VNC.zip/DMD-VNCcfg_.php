<?php
/** Page de configuration utilisateur chargée par profile_edit.php (iframe native). */
require_once __DIR__ . '/DMD-VNC_lib.php';
if (!dmv_perm('view')) { http_response_code(403); echo 'Accès refusé'; return; }
require __DIR__ . '/DMD-VNC.php';
