DMD-VNC 0.5.0 — Module autonome pour DoMyDesk.
Installation : ZIP via la gestion des modules, sans modification du MASTER.
Configuration : adresse IP du périphérique et port TCP (5900 par défaut).
Connexion : relais PHP TCP/HTTP embarqué ; nécessite PHP stream_socket_client, au moins deux workers PHP simultanés et transmission HTTP non tamponnée. Aucun démon à installer.
Limites : certains reverse proxies PHP/HTTP tamponnent ou coupent les flux continus ; la connexion dépend de la connectivité réseau du serveur web vers les équipements, et du paramétrage du serveur VNC.
Le navigateur doit disposer de JavaScript et du support Streams/fetch. Les appareils doivent exécuter un serveur VNC.
La compatibilité doit être testée dans une véritable instance DoMyDesk avant utilisation en production.

Version diagnostic 0.5.1 : bouton ⓘ par équipement, diagnostic TCP, RFB, résolution d'adresse, écriture PHP, journal des 30 derniers diagnostics consultable et copiable. Journal : data/modules/DMD-VNC/diagnostics.jsonl. Ne contient pas de mot de passe. Une bannière RFB valide ne garantit pas le fonctionnement du flux HTTP qui reste dépendant du serveur et des proxies.

0.5.6 : restauration base 0.5.3, entrée JavaScript isolée du cache, erreurs de chargement visibles. Aucune migration ni suppression des équipements.
