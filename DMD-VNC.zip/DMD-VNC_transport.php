<?php
/** DMD-VNC: TCP relay with disk-backed HTTP polling.
 *  The browser never depends on FastCGI/proxy response-stream flushing.
 *  One PHP request owns the VNC socket; short requests exchange data through
 *  private files. No service/daemon or modification to DoMyDesk is required.
 */
require_once __DIR__.'/DMD-VNC_lib.php';
if (!dmv_perm('connect')) { http_response_code(403); exit('Accès VNC refusé'); }
$token = (string)($_REQUEST['token'] ?? '');
if (!preg_match('/^[a-f0-9]{48}$/D', $token)) { http_response_code(403); exit('Jeton VNC invalide'); }
$record = dmv_read('tunnel-'.$token.'.json');
if (empty($record['id']) || ($record['email'] ?? '') !== dmv_email()
    || ($record['expires'] ?? 0) < time() || !dmv_acl($record['id'], 'connect')) {
    http_response_code(403); exit('Session VNC expirée ou non autorisée');
}
$device = dmv_device($record['id']);
if (!$device) { http_response_code(404); exit('Équipement VNC inconnu'); }
$dir = dmv_dir();
if ($dir === '') { http_response_code(500); exit('Stockage DMD-VNC inaccessible'); }
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$mode = (string)($_REQUEST['mode'] ?? '');
$queue = $dir.'/queue-'.$token.'.bin';
$stateName = 'relay-'.$token.'.json';
$stopPath = $dir.'/stop-'.$token;
$seenPath = $dir.'/seen-'.$token;
$rxPrefix = $dir.'/rx-'.$token.'-';
header('Cache-Control: no-store, private');
header('X-Content-Type-Options: nosniff');

if ($method === 'POST') {
    if (!dmv_check()) { http_response_code(403); exit('Protection CSRF refusée'); }
    if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
    if ($mode === 'stop') {
        @file_put_contents($stopPath, 'stop', LOCK_EX);
        dmv_json(['ok'=>true]);
    }
    if ($mode !== 'send') { http_response_code(400); exit('Action de transport invalide'); }
    $payload = (string)($_POST['packet'] ?? '');
    if ($payload === '' || strlen($payload) > 90000) { http_response_code(400); exit('Paquet VNC vide ou trop volumineux'); }
    $packet = base64_decode($payload, true);
    if ($packet === false || strlen($packet) > 65536) { http_response_code(400); exit('Paquet VNC incorrect'); }
    clearstatcache(true, $queue);
    if (is_file($queue) && filesize($queue) > 8*1024*1024) { http_response_code(429); exit('File TCP saturée'); }
    if (@file_put_contents($queue, base64_encode($packet)."\n", FILE_APPEND | LOCK_EX) === false) {
        http_response_code(500); exit('Transmission du paquet VNC impossible');
    }
    dmv_json(['ok'=>true]);
}
if ($method !== 'GET') { http_response_code(405); exit('Méthode non autorisée'); }
if (session_status() === PHP_SESSION_ACTIVE) session_write_close();

if ($mode === 'poll') {
    header('Content-Type: application/json; charset=utf-8');
    $seq = filter_var($_GET['seq'] ?? null, FILTER_VALIDATE_INT, ['options'=>['min_range'=>1, 'max_range'=>100000000]]);
    if ($seq === false || $seq === null) { http_response_code(400); exit('{"ok":false,"error":"Séquence invalide"}'); }
    // The last frame was already delivered; remove it after client acknowledgement.
    if ($seq > 1) @unlink($rxPrefix.($seq-1).'.bin');
    @touch($seenPath);
    $frames = [];
    $length = 0;
    $deadline = microtime(true) + 0.16;
    do {
        while (count($frames) < 20 && $length < 512*1024) {
            $path = $rxPrefix.$seq.'.bin';
            if (!is_file($path)) break;
            $raw = @file_get_contents($path);
            if ($raw === false) break;
            $length += strlen($raw);
            $frames[] = base64_encode($raw);
            ++$seq;
        }
        $state = dmv_read($stateName);
        if ($frames || in_array($state['status'] ?? '', ['closed','error'], true)) break;
        usleep(25000);
    } while (microtime(true) < $deadline);
    $state = dmv_read($stateName);
    echo json_encode([
        'ok'=>true, 'seq'=>$seq, 'frames'=>$frames,
        'status'=>(string)($state['status'] ?? 'starting'),
        'reason'=>(string)($state['reason'] ?? ''),
        'rx'=>(int)($state['rx'] ?? 0),
        'tx'=>(int)($state['tx'] ?? 0),
        'updated'=>(int)($state['updated'] ?? 0),
    ], JSON_INVALID_UTF8_SUBSTITUTE | JSON_UNESCAPED_UNICODE);
    exit;
}
if ($mode !== 'stream') { http_response_code(400); exit('Mode de transport manquant'); }

// Do not allow a second concurrent PHP worker to open another TCP connection
// for the same browser session. The lock is held until the relay is closed.
$lock = @fopen($dir.'/lock-'.$token.'.lck', 'c');
if (!$lock || !@flock($lock, LOCK_EX | LOCK_NB)) {
    http_response_code(409); exit('Relais VNC déjà actif');
}
$saveState = static function(string $status, string $reason, int $rx, int $tx) use ($stateName): void {
    dmv_save($stateName, ['status'=>$status,'reason'=>$reason,'rx'=>$rx,'tx'=>$tx,'updated'=>time()]);
};
$host=(string)($device['host'] ?? ''); $port=(int)($device['port'] ?? 5900);
$ip=filter_var($host,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4) ? $host : gethostbyname($host);
if (!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4)
    || !preg_match('/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/', $ip)
    || $port < 1 || $port > 65535) {
    $saveState('error', 'Adresse non privée ou port TCP invalide', 0, 0);
    http_response_code(403); exit('Adresse VNC refusée');
}
$saveState('starting', 'Ouverture TCP '.$ip.':'.$port, 0, 0);
$errno=0; $errstr='';
$sock=@stream_socket_client('tcp://'.$ip.':'.$port, $errno, $errstr, 6, STREAM_CLIENT_CONNECT);
if (!$sock) {
    $reason='Connexion TCP échouée ('.$errno.') : '.$errstr;
    $saveState('error', $reason, 0, 0);
    http_response_code(502); exit($reason);
}
stream_set_blocking($sock, false);
@set_time_limit(0);
ignore_user_abort(true); // Connection lifetime is controlled by stop requests + client heartbeat.
@ini_set('zlib.output_compression', '0');
@ini_set('output_buffering', '0');
if (function_exists('apache_setenv')) @apache_setenv('no-gzip', '1');
while (ob_get_level() > 0) @ob_end_clean();
header('Content-Type: text/plain; charset=utf-8');
header('X-Accel-Buffering: no');
header('Content-Encoding: identity');
// The stream response is only a KEEPALIVE. RFB bytes are delivered via poll.
echo 'DMD-VNC-TCP-RELAY '.str_repeat(' ',16384)."\n"; @flush();
@touch($seenPath);
$saveState('active', '', 0, 0);
$position=0; $pending=''; $start=time(); $lastState=0;
$received=0; $sent=0; $nextSeq=1; $endReason=''; $lastPing=time();
try {
    while (time()-$start < 3600) {
        clearstatcache(true, $stopPath);
        if (is_file($stopPath)) { $endReason='Session fermée par l’utilisateur'; break; }
        clearstatcache(true, $seenPath);
        if (time()-$start > 30 && (!is_file($seenPath) || time()-(int)filemtime($seenPath)>30)) {
            $endReason='Navigateur inactif depuis 30 secondes'; break;
        }
        $r=[$sock]; $w=$e=[];
        $available=@stream_select($r,$w,$e,0,90000);
        if ($available === false) { $endReason='Lecture du socket TCP impossible'; break; }
        if ($available > 0) {
            $data=@fread($sock,49152);
            if ($data === false) { $endReason='Erreur de lecture TCP'; break; }
            if ($data === '') {
                if (feof($sock)) { $endReason='Le serveur VNC a fermé la connexion TCP'; break; }
            } else {
                $temp=@tempnam($dir, '.dmv_rx_');
                if ($temp === false || @file_put_contents($temp,$data) !== strlen($data)
                    || !@rename($temp,$rxPrefix.$nextSeq.'.bin')) {
                    if ($temp) @unlink($temp);
                    $endReason='Impossible d’enregistrer les données reçues du serveur VNC'; break;
                }
                @chmod($rxPrefix.$nextSeq.'.bin',0600);
                ++$nextSeq;
                $received+=strlen($data);
            }
        }
        clearstatcache(true, $queue);
        if (is_file($queue)) {
            $f=@fopen($queue,'rb');
            if ($f) {
                if (@fseek($f,$position,SEEK_SET)===0) {
                    while (($line=fgets($f,92000)) !== false) {
                        if (!str_ends_with($line,"\n")) break;
                        $position=ftell($f);
                        $chunk=base64_decode(trim($line),true);
                        if ($chunk === false) { $endReason='Paquet navigateur mal formé'; break 2; }
                        $pending.=$chunk;
                        if (strlen($pending) > 1048576) { $endReason='Tampon d’envoi TCP saturé'; break 2; }
                    }
                }
                @fclose($f);
            }
        }
        if ($pending !== '') {
            $n=@fwrite($sock,$pending);
            if ($n === false) { $endReason='Écriture vers le serveur VNC impossible'; break; }
            if ($n > 0) { $sent+=$n; $pending=substr($pending,$n); }
        }
        if (time()-$lastState>=2) {
            $saveState('active','',$received,$sent);
            $lastState=time();
        }
        if (time()-$lastPing>=10) { echo ".\n"; @flush(); $lastPing=time(); }
    }
} catch (Throwable $exc) {
    $endReason='Erreur du relais PHP : '.$exc->getMessage();
} finally {
    $saveState('closed',$endReason?:'Durée maximale de session atteinte',$received,$sent);
    @fclose($sock);
    @unlink($queue); @unlink($stopPath);
    @flock($lock,LOCK_UN); @fclose($lock);
    echo "\nDMD-VNC terminé\n"; @flush();
}
