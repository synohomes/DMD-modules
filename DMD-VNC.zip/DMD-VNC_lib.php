<?php
if (session_status() === PHP_SESSION_NONE) session_start();
$core = dirname(__DIR__,2).'/functions.php'; if (is_file($core)) require_once $core;
function dmv_email(){return trim((string)($_SESSION['user']['email']??''));}
function dmv_perm($p){$e=dmv_email();return $e!=='' && function_exists('dmd_user_can_use_module') && dmd_user_can_use_module($e,'DMD-VNC') && function_exists('dmd_user_has_module_permission') && dmd_user_has_module_permission($e,'DMD-VNC',$p);}
function dmv_token(){if(empty($_SESSION['dmv_csrf']))$_SESSION['dmv_csrf']=bin2hex(random_bytes(24));return $_SESSION['dmv_csrf'];}
function dmv_check(){return isset($_POST['csrf']) && hash_equals(dmv_token(),(string)$_POST['csrf']);}
function dmv_json($data,$code=200){http_response_code($code);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function dmv_dir(){ $p=dirname(__DIR__,2).'/data/modules/DMD-VNC'; if(!is_dir($p)&&!@mkdir($p,0700,true))return '';return $p; }
function dmv_path($name){$d=dmv_dir();return $d===''?'':$d.'/'.$name;}
function dmv_read($name){$p=dmv_path($name);$j=$p!=='' && is_file($p)?json_decode((string)@file_get_contents($p),true):null;return is_array($j)?$j:[];}
function dmv_save($name,$data){$p=dmv_path($name);if($p==='')return false;$t=tempnam(dirname($p),'.dmv_');if($t===false)return false;@chmod($t,0600);$ok=file_put_contents($t,json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX)!==false&&@rename($t,$p);if(!$ok)@unlink($t);return $ok;}
function dmv_acl($id,$p){if(!dmv_perm($p))return false;$acl=dmv_read('acl.json');$email=strtolower(dmv_email());$rule=$acl[$id]??null;if(!is_array($rule))return $p==='view'||$p==='connect'||$p==='control'; if(dmv_perm('acl.manage'))return true;if(!isset($rule[$email]))return false;return in_array($p,(array)$rule[$email],true);}
function dmv_devices(){return array_values(array_filter(dmv_read('devices.json'),'is_array'));}
function dmv_device($id){foreach(dmv_devices() as $d)if(hash_equals((string)($d['id']??''),(string)$id))return $d;return null;}
function dmv_public($d){return ['id'=>$d['id'],'name'=>$d['name'],'group'=>$d['group']??'','description'=>$d['description']??'','kind'=>$d['kind']??'other','favorite'=>!empty($d['favorite']),'host'=>$d['host']??(parse_url($d['endpoint']??'',PHP_URL_HOST)??''),'port'=>$d['port']??5900,'endpoint'=>dmv_perm('manage')?($d['endpoint']??''):'','view'=>dmv_acl($d['id'],'view'),'connect'=>dmv_acl($d['id'],'connect'),'control'=>dmv_acl($d['id'],'control')];}
function dmv_endpoint($url){$u=parse_url($url);if(!$u||!in_array($u['scheme']??'',['ws','wss'],true)||empty($u['host'])||isset($u['user'])||isset($u['pass'])||isset($u['fragment']))return false;return preg_match('~^wss?://[a-zA-Z0-9.\-:\[\]]+(?::[0-9]{1,5})?(?:/[a-zA-Z0-9_./~%?&=+\-]*)?$~',$url)===1;}
function dmv_log($event,$device=''){ $p=dmv_path('events.jsonl');if($p==='')return;@file_put_contents($p,json_encode(['at'=>gmdate('c'),'email'=>dmv_email(),'event'=>$event,'device'=>$device],JSON_UNESCAPED_UNICODE)."\n",FILE_APPEND|LOCK_EX);}

function dmv_host($host){return strlen($host)<=253 && (filter_var($host,FILTER_VALIDATE_IP)!==false || (preg_match('/^(?=.{1,253}$)[a-zA-Z0-9](?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?$/D',$host) && strpos($host,'..')===false));}
