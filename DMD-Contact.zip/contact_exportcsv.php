<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/contact_export_lib.php';
$email = contact_current_email();
if ($email === '') { http_response_code(403); exit('Accès refusé'); }
dmd_require_module_access(CONTACT_MODULE_ID, 'export');

$id = trim((string)($_GET['id'] ?? ''));
$owner = trim((string)($_GET['owner'] ?? ''));
$contacts = contact_accessible_contacts($email, $owner, $id);
$csv = contact_export_csv_bytes($contacts);
$filename = contact_export_filename('csv', $id);
contact_log($email, 'contact.export_csv', $id !== '' ? $id : 'all', 'success', count($contacts) . ' contact(s) téléchargé(s)');
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($csv));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, max-age=0');
echo $csv;
exit;
