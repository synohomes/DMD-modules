<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/contact_export_lib.php';
$email = contact_current_email();
if ($email === '') { http_response_code(403); exit('Accès refusé'); }
dmd_require_module_access(CONTACT_MODULE_ID, 'export');

$id = trim((string)($_GET['id'] ?? ''));
$owner = trim((string)($_GET['owner'] ?? ''));
$download = !empty($_GET['download']);
$contacts = contact_accessible_contacts($email, $owner, $id);
$pdf = contact_export_pdf_bytes($contacts, $id !== '');
$filename = contact_export_filename('pdf', $id);

if ($download) {
    contact_log($email, 'contact.export_pdf', $id !== '' ? $id : 'all', 'success', count($contacts) . ' contact(s) téléchargé(s)');
}
header('Content-Type: application/pdf');
header('Content-Disposition: ' . ($download ? 'attachment' : 'inline') . '; filename="' . $filename . '"');
header('Content-Length: ' . strlen($pdf));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, max-age=0');
echo $pdf;
exit;
