<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/contact_lib.php';

function contact_security_out($ok, $data = array(), $code = 200) {
    http_response_code($code);
    echo json_encode(array_merge(array('ok'=>(bool)$ok), $data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

$email = contact_current_email();
if ($email === '') contact_security_out(false, array('error'=>'AUTH'), 403);
dmd_require_module_access(CONTACT_MODULE_ID, 'view');

$state = contact_mfa_gate_state($email);
$action = trim((string)($_POST['action'] ?? $_GET['action'] ?? 'status'));

if ($action === 'status') {
    contact_security_out(true, array('state'=>$state));
}

if ($action !== 'verify' || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    contact_security_out(false, array('error'=>'METHOD'), 405);
}

$token = (string)($_POST['csrf_token'] ?? '');
if ($token === '' || empty($_SESSION['csrf_contact']) || !hash_equals((string)$_SESSION['csrf_contact'], $token)) {
    contact_security_out(false, array('error'=>'CSRF','message'=>'Formulaire expiré. Recharge la page.'), 403);
}

if (empty($state['required'])) {
    contact_security_out(true, array('verified'=>true,'state'=>$state));
}
if (empty($state['challenge_available'])) {
    $reason = (string)($state['reason'] ?? 'mfa_unavailable');
    if ($reason === 'account_mfa_not_configured') {
        contact_security_out(false, array('error'=>'MFA_NOT_CONFIGURED','message'=>'Le MFA est obligatoire pour DMD-Contact. Active-le d’abord dans ton profil DoMyDesk.'), 409);
    }
    if ($reason === 'disabled_by_policy') {
        contact_security_out(false, array('error'=>'MFA_DISABLED','message'=>'Le MFA est obligatoire pour DMD-Contact mais il est désactivé par la politique centrale DoMyDesk.'), 409);
    }
    contact_security_out(false, array('error'=>'MFA_UNAVAILABLE','message'=>'Le MFA est obligatoire pour DMD-Contact mais le moteur MFA central est indisponible.'), 503);
}

$blockedUntil = (int)($_SESSION['dmd_contact_mfa_blocked_until'] ?? 0);
if ($blockedUntil > time()) {
    contact_security_out(false, array('error'=>'RATE_LIMIT','message'=>'Trop de tentatives. Réessaie dans quelques minutes.','retry_after'=>$blockedUntil-time()), 429);
}

$code = trim((string)($_POST['mfa_code'] ?? ''));
if ($code === '' || strlen($code) > 80) contact_security_out(false, array('error'=>'CODE','message'=>'Saisis ton code Authenticator ou un code de secours.'), 400);

if (!contact_mfa_boot()) contact_security_out(false, array('error'=>'MFA_CORE','message'=>'Le moteur MFA central DoMyDesk est indisponible.'), 503);

$usedRecovery = false;
if (dmd_mfa_verify_user_code($email, $code, $usedRecovery)) {
    contact_mfa_mark_verified();
    unset($_SESSION['dmd_contact_mfa_failures'], $_SESSION['dmd_contact_mfa_blocked_until']);
    if (function_exists('dmd_system_log')) {
        dmd_system_log('contact_mfa_unlock', $email, 'success', $usedRecovery ? 'DMD-Contact déverrouillé avec un code de récupération.' : 'DMD-Contact déverrouillé par MFA.');
    }
    contact_log($email, 'contact.mfa_unlock', 'module', 'success', $usedRecovery ? 'Code de récupération central utilisé.' : 'Code TOTP central validé.');
    contact_security_out(true, array('verified'=>true,'used_recovery'=>$usedRecovery,'state'=>contact_mfa_gate_state($email)));
}

$fails = (int)($_SESSION['dmd_contact_mfa_failures'] ?? 0) + 1;
$_SESSION['dmd_contact_mfa_failures'] = $fails;
if ($fails >= 5) {
    $_SESSION['dmd_contact_mfa_blocked_until'] = time() + 300;
    $_SESSION['dmd_contact_mfa_failures'] = 0;
}
usleep(250000);
contact_log($email, 'contact.mfa_unlock', 'module', 'denied', 'Code MFA incorrect.');
contact_security_out(false, array('error'=>'MFA_INVALID','message'=>'Code Authenticator ou code de secours incorrect.'), 401);
