<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/contact_lib.php';
$email = contact_current_email();
if ($email === '') { http_response_code(403); exit; }
dmd_require_module_access(CONTACT_MODULE_ID, 'view');
$owner = trim((string)($_GET['owner'] ?? '')); $id = trim((string)($_GET['id'] ?? ''));
if ($owner === '' || $id === '' || dmd_safe_user_key($owner) === '') { http_response_code(400); exit; }
$rows = contact_accessible_contacts($email, $owner, $id);
if (!$rows) { http_response_code(404); exit; }
$c = $rows[0]; $name = basename((string)($c['avatar'] ?? ''));
if ($name === '') { http_response_code(404); exit; }
$file = contact_avatar_dir($owner, false) . $name;
if (!is_file($file)) { http_response_code(404); exit; }
$info = @getimagesize($file); if ($info === false) { http_response_code(404); exit; }
header('Content-Type: ' . ($info['mime'] ?? 'application/octet-stream'));
header('Content-Length: ' . filesize($file));
header('Cache-Control: private, max-age=3600');
header('X-Content-Type-Options: nosniff');
readfile($file); exit;
