<?php
if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(E_ALL); ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/contact_export_lib.php';

function contact_api_out($ok, $data = array(), $code = 200) {
    http_response_code($code);
    echo json_encode(array_merge(array('ok'=>(bool)$ok), $data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function contact_post($key, $default = '') { return trim((string)($_POST[$key] ?? $default)); }
function contact_bool_post($key) { return isset($_POST[$key]) && in_array((string)$_POST[$key], array('1','true','on','yes'), true); }
function contact_array_post($key) {
    $v = $_POST[$key] ?? array(); if (!is_array($v)) $v = array($v); $out = array();
    foreach ($v as $item) { $item = trim((string)$item); if ($item !== '' && !in_array($item, $out, true)) $out[] = $item; }
    return $out;
}
function contact_upload_avatar($avatarDir) {
    if (!isset($_FILES['avatar']) || !is_array($_FILES['avatar']) || ($_FILES['avatar']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    if (($_FILES['avatar']['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || !is_uploaded_file($_FILES['avatar']['tmp_name'])) contact_api_out(false, array('error'=>'UPLOAD_INVALID'), 400);
    if ((int)($_FILES['avatar']['size'] ?? 0) > 4 * 1024 * 1024) contact_api_out(false, array('error'=>'UPLOAD_TOO_LARGE'), 400);
    $info = @getimagesize($_FILES['avatar']['tmp_name']); if ($info === false) contact_api_out(false, array('error'=>'UPLOAD_NOT_IMAGE'), 400);
    $map = array('image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp');
    $mime = (string)($info['mime'] ?? ''); if (!isset($map[$mime])) contact_api_out(false, array('error'=>'UPLOAD_TYPE'), 400);
    $name = bin2hex(random_bytes(16)) . '.' . $map[$mime];
    if (!@move_uploaded_file($_FILES['avatar']['tmp_name'], rtrim($avatarDir, '/\\') . '/' . $name)) contact_api_out(false, array('error'=>'UPLOAD_MOVE'), 500);
    @chmod(rtrim($avatarDir, '/\\') . '/' . $name, 0640); return $name;
}

$email = contact_current_email();
if ($email === '') contact_api_out(false, array('error'=>'AUTH'), 403);
dmd_require_module_access(CONTACT_MODULE_ID, 'view');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') contact_api_out(false, array('error'=>'METHOD'), 405);
$token = (string)($_POST['csrf_token'] ?? '');
if ($token === '' || empty($_SESSION['csrf_contact']) || !hash_equals((string)$_SESSION['csrf_contact'], $token)) contact_api_out(false, array('error'=>'CSRF'), 403);

$file = contact_contacts_file($email, true); $avatarDir = contact_avatar_dir($email, true); $contacts = contact_read_json($file, array());
$action = contact_post('action');

/* ==========================================================
   Export / transfert DoMyDesk
   ========================================================== */
if (in_array($action, array('export_save_pdf','export_save_csv','export_share_pdf','export_share_csv','export_to_contact'), true)) {
    dmd_require_module_access(CONTACT_MODULE_ID, 'export');
    $id = contact_post('id');
    $owner = contact_post('owner');
    $selected = contact_accessible_contacts($email, $owner, $id);
    if (!$selected) contact_api_out(false, array('error'=>'NO_CONTACT','message'=>'Aucun contact à exporter.'), 404);

    if ($action === 'export_save_pdf' || $action === 'export_save_csv') {
        $format = substr($action, -3) === 'csv' ? 'csv' : 'pdf';
        $bytes = $format === 'csv' ? contact_export_csv_bytes($selected) : contact_export_pdf_bytes($selected, $id !== '');
        $path = contact_export_write_user_file($email, $bytes, contact_export_filename($format, $id), false);
        if ($path === '') contact_api_out(false, array('error'=>'WRITE','message'=>'Impossible d’enregistrer l’export dans le dossier personnel.'), 500);
        contact_log($email, 'contact.export_' . $format . '_personal', $id !== '' ? $id : 'all', 'success', contact_export_relative_user_path($email, $path));
        if ($id !== '' && isset($selected[0])) contact_emit_resource_event($email, 'contact.export', $selected[0], 'success', strtoupper($format) . ' enregistré dans le dossier personnel.');
        contact_api_out(true, array('message'=>strtoupper($format) . ' enregistré dans ton dossier DoMyDesk.', 'path'=>contact_export_relative_user_path($email, $path)));
    }

    dmd_require_module_access(CONTACT_MODULE_ID, 'share');
    $recipient = contact_post('recipient');
    $recipientResolved = contact_export_resolve_user($recipient);
    if ($recipient === '' || !$recipientResolved) contact_api_out(false, array('error'=>'RECIPIENT','message'=>'Utilisateur destinataire introuvable.'), 404);
    $selfResolved = contact_export_resolve_user($email);
    if ($selfResolved && contact_lower($recipientResolved['key']) === contact_lower($selfResolved['key'])) contact_api_out(false, array('error'=>'RECIPIENT_SELF','message'=>'Choisis un autre utilisateur.'), 400);
    $recipientKey = (string)$recipientResolved['key'];
    $recipientNotify = (string)$recipientResolved['email'];
    $recipientLabel = contact_user_label($recipientKey);

    if ($action === 'export_share_pdf' || $action === 'export_share_csv') {
        $format = substr($action, -3) === 'csv' ? 'csv' : 'pdf';
        $bytes = $format === 'csv' ? contact_export_csv_bytes($selected) : contact_export_pdf_bytes($selected, $id !== '');
        $path = contact_export_write_user_file($recipientKey, $bytes, contact_export_filename($format, $id), true);
        if ($path === '') contact_api_out(false, array('error'=>'WRITE','message'=>'Impossible de déposer le fichier chez le destinataire.'), 500);
        $who = contact_user_label($email);
        $what = $id !== '' && isset($selected[0]) ? contact_full_name($selected[0]) : count($selected) . ' contacts';
        contact_core_notification(
            $recipientNotify,
            'Export Contact reçu',
            $who . ' vous a partagé un export ' . strtoupper($format) . ' : ' . $what . '.',
            $email,
            'contact_export_shared',
            'dashboard.php',
            array('module'=>CONTACT_MODULE_ID,'format'=>$format,'path'=>contact_export_relative_user_path($recipientKey, $path),'contact_id'=>$id)
        );
        contact_log($email, 'contact.export_' . $format . '_share', $id !== '' ? $id : 'all', 'success', 'Destinataire : ' . $recipientNotify);
        if ($id !== '' && isset($selected[0])) contact_emit_resource_event($email, 'contact.export', $selected[0], 'success', strtoupper($format) . ' partagé à ' . $recipientNotify . '.');
        contact_api_out(true, array('message'=>strtoupper($format) . ' partagé à ' . $recipientNotify . '.'));
    }

    if ($action === 'export_to_contact') {
        $transferable = array_values(array_filter($selected, function($row){ return is_array($row); }));
        if (!$transferable) contact_api_out(false, array('error'=>'NO_ACCESSIBLE_CONTACT','message'=>'Aucun contact accessible ne peut être intégré chez ce destinataire.'), 400);
        $result = contact_export_copy_to_contact_module($email, $recipientKey, $transferable);
        if (empty($result['count'])) contact_api_out(false, array('error'=>$result['error'] ?? 'IMPORT','message'=>'L’intégration au module Contact a échoué.'), 500);
        $count = (int)$result['count'];
        $who = contact_user_label($email);
        $what = $count === 1 ? contact_full_name($transferable[0]) : $count . ' contacts';
        contact_core_notification(
            $recipientNotify,
            'Contact reçu',
            $who . ' vous a envoyé ' . $what . '. ' . ($count === 1 ? 'Le contact a été ajouté directement à votre module Contact.' : 'Les contacts ont été ajoutés directement à votre module Contact.'),
            $email,
            'contact_imported',
            'dashboard.php',
            array('module'=>CONTACT_MODULE_ID,'count'=>$count,'contact_id'=>$id)
        );
        contact_log($email, 'contact.export_internal', $id !== '' ? $id : 'all', 'success', $count . ' contact(s) intégré(s) chez ' . $recipientNotify);
        foreach ($transferable as $row) contact_emit_resource_event($email, 'contact.export', $row, 'success', 'Contact accessible intégré au module Contact de ' . $recipientNotify . '.');
        contact_api_out(true, array('message'=>$count . ' contact(s) intégré(s) directement dans le module Contact de ' . ($recipientLabel !== '' ? $recipientLabel : $recipientNotify) . '.', 'count'=>$count));
    }
}

if ($action === 'delete') {
    dmd_require_module_access(CONTACT_MODULE_ID, 'delete');
    $id = contact_post('id'); if ($id === '') contact_api_out(false, array('error'=>'ID_REQUIRED'), 400);
    $idx = contact_find_own($email, $id, $contacts); if ($idx < 0) contact_api_out(false, array('error'=>'NOT_FOUND'), 404);
    $old = $contacts[$idx];
    if (!empty($old['avatar'])) { $path = $avatarDir . basename((string)$old['avatar']); if (is_file($path)) @unlink($path); }
    array_splice($contacts, $idx, 1);
    if (!contact_write_json($file, array_values($contacts))) contact_api_out(false, array('error'=>'WRITE'), 500);
    contact_index_refresh_owner($email, $contacts); contact_emit_resource_event($email, 'contact.delete', $old, 'success', 'Contact supprimé : ' . contact_full_name($old));
    contact_api_out(true, array('deleted'=>true));
}

if ($action === 'save') {
    $id = contact_post('id'); $existingIndex = $id !== '' ? contact_find_own($email, $id, $contacts) : -1;
    dmd_require_module_access(CONTACT_MODULE_ID, $existingIndex >= 0 ? 'edit' : 'create');
    if ($id === '') $id = 'c_' . bin2hex(random_bytes(12));
    $old = $existingIndex >= 0 ? $contacts[$existingIndex] : array();
    $isPrivate = contact_bool_post('is_private'); $isPro = contact_bool_post('is_pro'); if (!$isPrivate && !$isPro) $isPrivate = true;
    $newAvatar = contact_upload_avatar($avatarDir); $now = date('c');
    $canShare = dmd_current_user_has_module_permission(CONTACT_MODULE_ID, 'share');
    $newSharedWith = $canShare ? contact_array_post('shared_with') : (array)($old['shared_with'] ?? array());
    $oldSharedMap = array(); foreach ((array)($old['shared_with'] ?? array()) as $mail) $oldSharedMap[contact_lower($mail)] = true;
    $addedSharedWith = array(); foreach ($newSharedWith as $mail) if (!isset($oldSharedMap[contact_lower($mail)])) $addedSharedWith[] = $mail;
    $record = array(
        'id'=>$id,'civilite'=>contact_post('civilite'),'prenom'=>contact_post('prenom'),'nom'=>contact_post('nom'),'surnom'=>contact_post('surnom'),
        'is_private'=>$isPrivate,'is_pro'=>$isPro,'relation_private'=>contact_post('relation_private'),'relation_pro'=>contact_post('relation_pro'),
        'entreprise'=>contact_post('entreprise'),'poste'=>contact_post('poste'),'service'=>contact_post('service'),'siret'=>contact_post('siret'),
        'mail'=>contact_post('mail'),'mail2'=>contact_post('mail2'),'tel'=>contact_post('tel'),'tel2'=>contact_post('tel2'),
        'adresse'=>contact_post('adresse'),'code_postal'=>contact_post('code_postal'),'ville'=>contact_post('ville'),'pays'=>contact_post('pays'),
        'date_naissance'=>contact_post('date_naissance'),'statut_familial'=>contact_post('statut_familial'),'site_web'=>contact_post('site_web'),
        'linkedin'=>contact_post('linkedin'),'tags'=>contact_post('tags'),'notes'=>contact_post('notes'),
        'shared_with'=>$newSharedWith,
        'shared_roles'=>$canShare ? contact_array_post('shared_roles') : (array)($old['shared_roles'] ?? array()),
        'share_same_role'=>$canShare ? contact_bool_post('share_same_role') : !empty($old['share_same_role']),
        'created_at'=>(string)($old['created_at'] ?? $now),'updated_at'=>$now,'avatar'=>$newAvatar !== '' ? $newAvatar : (string)($old['avatar'] ?? '')
    );
    if ($newAvatar !== '' && !empty($old['avatar']) && basename((string)$old['avatar']) !== $newAvatar) { $oldPath = $avatarDir . basename((string)$old['avatar']); if (is_file($oldPath)) @unlink($oldPath); }
    if ($existingIndex >= 0) $contacts[$existingIndex] = $record; else $contacts[] = $record;
    usort($contacts, function($a,$b){ return strcoll(contact_lower(contact_sort_key($a)), contact_lower(contact_sort_key($b))); });
    if (!contact_write_json($file, array_values($contacts))) contact_api_out(false, array('error'=>'WRITE'), 500);
    contact_index_refresh_owner($email, $contacts);
    $eventAction = $existingIndex >= 0 ? 'contact.edit' : 'contact.create';
    contact_emit_resource_event($email, $eventAction, $record, 'success', ($existingIndex >= 0 ? 'Contact modifié : ' : 'Contact créé : ') . contact_full_name($record));
    if ($canShare && $addedSharedWith) {
        $who = contact_user_label($email);
        foreach ($addedSharedWith as $recipient) {
            if (!contact_export_user_exists($recipient)) continue;
            contact_core_notification(
                $recipient,
                'Contact partagé',
                $who . ' vous a partagé le contact ' . contact_full_name($record) . '.',
                $email,
                'contact_shared',
                'dashboard.php',
                array('module'=>CONTACT_MODULE_ID,'contact_id'=>$id,'contact_name'=>contact_full_name($record))
            );
        }
        contact_emit_resource_event($email, 'contact.share', $record, 'success', 'Contact partagé à : ' . implode(', ', $addedSharedWith));
    }
    contact_api_out(true, array('id'=>$id,'count'=>count($contacts)));
}
contact_api_out(false, array('error'=>'NO_ROUTE'), 400);
