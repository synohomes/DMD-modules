<?php
/* * =====================================================================
                                DoMyDesk
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
*
Ce fichier fait partie du logiciel DoMyDesk.
*
Toute reproduction, redistribution, revente, publication ou
intégration de tout ou partie de ce code dans un autre produit
sans autorisation préalable de SynoHomes est interdite.
*
La modification du logiciel dans le cadre de son utilisation
*
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0
*
Éditeur : SynoHomes

* * ===================================================================== * */

if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(E_ALL); ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/contact_lib.php';

function cimp_out($ok, $data = array(), $code = 200) {
    http_response_code($code);
    echo json_encode(array_merge(array('ok'=>(bool)$ok), $data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function cimp_clean($v, $max = 4000) {
    $v = trim((string)$v);
    $v = str_replace("\0", '', $v);
    if (function_exists('mb_substr')) return mb_substr($v, 0, $max, 'UTF-8');
    return substr($v, 0, $max);
}
function cimp_to_utf8($raw) {
    $raw = (string)$raw;
    if (substr($raw, 0, 3) === "\xEF\xBB\xBF") $raw = substr($raw, 3);
    if ($raw === '') return '';
    if (function_exists('mb_check_encoding') && mb_check_encoding($raw, 'UTF-8')) return $raw;
    if (!function_exists('mb_check_encoding') && @preg_match('//u', $raw) === 1) return $raw;
    foreach (array('Windows-1252','ISO-8859-15','ISO-8859-1') as $enc) {
        $converted = @iconv($enc, 'UTF-8//IGNORE', $raw);
        if ($converted !== false && $converted !== '') return $converted;
    }
    return $raw;
}
function cimp_key($v) {
    $v = cimp_to_utf8((string)$v);
    $v = contact_lower(trim($v));
    if (function_exists('iconv')) {
        $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $v);
        if ($ascii !== false) $v = $ascii;
    }
    $v = preg_replace('/[^a-z0-9]+/i', '', $v) ?: '';
    return $v;
}
function cimp_email($v) { return contact_lower(trim((string)$v)); }
function cimp_phone($v) {
    $v = preg_replace('/[^0-9+]+/', '', (string)$v) ?: '';
    if (substr_count($v, '+') > 1 || (strpos($v, '+') !== false && strpos($v, '+') !== 0)) $v = str_replace('+', '', $v);
    return $v;
}
function cimp_bool($v) {
    $v = cimp_key($v);
    return in_array($v, array('1','true','yes','oui','on','x','vrai'), true);
}
function cimp_empty_record() {
    return array(
        'civilite'=>'','prenom'=>'','nom'=>'','surnom'=>'','is_private'=>true,'is_pro'=>false,
        'relation_private'=>'','relation_pro'=>'','entreprise'=>'','poste'=>'','service'=>'','siret'=>'',
        'mail'=>'','mail2'=>'','tel'=>'','tel2'=>'','adresse'=>'','code_postal'=>'','ville'=>'','pays'=>'',
        'date_naissance'=>'','statut_familial'=>'','site_web'=>'','linkedin'=>'','tags'=>'','notes'=>''
    );
}
function cimp_is_meaningful($c) {
    foreach (array('prenom','nom','entreprise','mail','mail2','tel','tel2') as $k) if (trim((string)($c[$k] ?? '')) !== '') return true;
    return false;
}
function cimp_csv_delimiter($line) {
    $scores = array(','=>0,';'=>0,"\t"=>0);
    foreach ($scores as $d => $_) $scores[$d] = substr_count($line, $d);
    arsort($scores);
    $d = (string)key($scores);
    return ((int)current($scores) > 0) ? $d : ',';
}
function cimp_csv_rows($raw) {
    $raw = cimp_to_utf8($raw);
    $firstLine = strtok($raw, "\r\n");
    $delimiter = cimp_csv_delimiter((string)$firstLine);
    $fp = fopen('php://temp', 'w+b');
    if (!$fp) return array();
    fwrite($fp, $raw); rewind($fp);
    $rows = array();
    while (($row = fgetcsv($fp, 0, $delimiter)) !== false) $rows[] = $row;
    fclose($fp);
    return $rows;
}
function cimp_header_aliases() {
    return array(
        'civilite'=>array('civilite','title','titre','salutation'),
        'prenom'=>array('prenom','firstname','givenname','givennamevalue','first name','given name'),
        'nom'=>array('nom','lastname','familyname','surname','last name','family name'),
        'surnom'=>array('surnom','nickname','nick name'),
        'entreprise'=>array('entreprise','societe','company','companyname','organization1name','organisation','organization'),
        'poste'=>array('poste','fonction','jobtitle','titlebusiness','organization1title','job title'),
        'service'=>array('service','department','organization1department'),
        'siret'=>array('siret'),
        'mail'=>array('emailprincipal','email','emailaddress','e-mailaddress','e-mail1-value','email1value','primaryemail','adresse de messagerie','adresse de courrier electronique'),
        'mail2'=>array('emailsecondaire','email2','email2address','e-mail2address','e-mail2-value','email2value','secondaryemail','adresse de messagerie 2'),
        'tel'=>array('telephone','tel','phone','mobilephone','mobile','businessphone','homephone','phone1value','phone 1 - value','telephone mobile','telephone professionnel','telephone domicile'),
        'tel2'=>array('telephone2','tel2','phone2','phone2value','phone 2 - value','businessphone2','homephone2','telephone 2'),
        'adresse'=>array('adresse','adressecomplete','address','street','businessstreet','homestreet','address1street','address 1 - street','rue bureau','rue domicile'),
        'code_postal'=>array('codepostal','postalcode','zipcode','businesspostalcode','homepostalcode','address1postalcode','address 1 - postal code','code postal bureau','code postal domicile'),
        'ville'=>array('ville','city','businesscity','homecity','address1city','address 1 - city','ville bureau','ville domicile'),
        'pays'=>array('pays','country','countryregion','businesscountryregion','homecountryregion','address1country','address 1 - country','pays region bureau','pays region domicile'),
        'date_naissance'=>array('datedenaissance','birthday','birthdate','date of birth'),
        'statut_familial'=>array('situationfamiliale','spouse','conjoint'),
        'site_web'=>array('siteweb','website','webpage','website1value','website 1 - value','businesswebpage'),
        'linkedin'=>array('linkedin'),
        'tags'=>array('tags','labels','categories','category'),
        'notes'=>array('notes','note','comments','commentaires'),
        'is_private'=>array('prive','private'),
        'is_pro'=>array('pro','professional')
    );
}
function cimp_normalized_header($h) {
    $h = trim(cimp_to_utf8((string)$h));
    if (function_exists('iconv')) { $x = @iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$h); if ($x !== false) $h = $x; }
    $h = strtolower($h);
    $h = preg_replace('/[^a-z0-9]+/', '', $h) ?: '';
    return $h;
}
function cimp_map_headers($headers) {
    $aliasSets = array();
    foreach (cimp_header_aliases() as $field=>$aliases) {
        $aliasSets[$field] = array();
        foreach ($aliases as $a) $aliasSets[$field][cimp_normalized_header($a)] = true;
    }
    $map = array();
    foreach ($headers as $i=>$h) {
        $nh = cimp_normalized_header($h);
        $matched = false;
        foreach ($aliasSets as $field=>$set) {
            if (isset($set[$nh]) && !isset($map[$field])) { $map[$field] = $i; $matched = true; break; }
        }
        if ($matched) continue;
        if (preg_match('/^email[0-9]+value$/', $nh)) {
            if (!isset($map['mail'])) $map['mail']=$i; elseif (!isset($map['mail2'])) $map['mail2']=$i;
        }
        if (preg_match('/^phone[0-9]+value$/', $nh)) {
            if (!isset($map['tel'])) $map['tel']=$i; elseif (!isset($map['tel2'])) $map['tel2']=$i;
        }
    }
    return $map;
}
function cimp_detect_csv_source($headers) {
    $flat = implode('|', array_map('cimp_normalized_header', $headers));
    if (strpos($flat, 'givenname') !== false || strpos($flat, 'organization1name') !== false || strpos($flat, 'email1value') !== false) return 'Google Contacts';
    if (strpos($flat, 'businessphone') !== false || strpos($flat, 'emailaddress') !== false || strpos($flat, 'company') !== false || strpos($flat, 'adressedemessagerie') !== false || strpos($flat, 'telephoneprofessionnel') !== false || strpos($flat, 'societe') !== false) return 'Microsoft Outlook';
    if (strpos($flat, 'emailprincipal') !== false && strpos($flat, 'typepro') !== false) return 'DMD-Contact';
    return 'CSV générique';
}
function cimp_parse_csv($raw) {
    $rows = cimp_csv_rows($raw);
    if (count($rows) < 2) return array('source'=>'CSV','contacts'=>array());
    $headers = array_map('cimp_to_utf8', array_shift($rows));
    $map = cimp_map_headers($headers);
    $contacts = array();
    foreach ($rows as $row) {
        $c = cimp_empty_record();
        foreach ($map as $field=>$idx) {
            $v = isset($row[$idx]) ? cimp_clean($row[$idx]) : '';
            if ($field === 'is_private' || $field === 'is_pro') $c[$field] = cimp_bool($v); else $c[$field] = $v;
        }
        if ($c['tags'] !== '') $c['tags'] = str_replace(':::', ', ', $c['tags']);
        $hasWork = ($c['entreprise'] !== '' || $c['poste'] !== '' || $c['service'] !== '');
        if (!isset($map['is_pro'])) $c['is_pro'] = $hasWork;
        if (!isset($map['is_private'])) $c['is_private'] = !$hasWork;
        if (!$c['is_private'] && !$c['is_pro']) $c['is_private'] = true;
        if (cimp_is_meaningful($c)) $contacts[] = $c;
        if (count($contacts) >= 5000) break;
    }
    return array('source'=>cimp_detect_csv_source($headers), 'contacts'=>$contacts);
}
function cimp_vcard_unescape($v) {
    $v = str_replace(array('\\n','\\N'), "\n", (string)$v);
    return str_replace(array('\\,','\\;','\\\\'), array(',',';','\\'), $v);
}
function cimp_vcard_value($line) {
    $pos = strpos($line, ':');
    if ($pos === false) return array('','');
    $left = substr($line,0,$pos); $value = substr($line,$pos+1);
    if (stripos($left, 'ENCODING=QUOTED-PRINTABLE') !== false) $value = quoted_printable_decode($value);
    return array($left, cimp_vcard_unescape(cimp_to_utf8($value)));
}
function cimp_parse_vcf($raw) {
    $raw = cimp_to_utf8($raw);
    $raw = preg_replace("/\r\n[ \t]|\n[ \t]|\r[ \t]/", '', $raw);
    $blocks = preg_split('/END:VCARD/i', (string)$raw);
    $contacts = array();
    foreach ($blocks as $block) {
        if (stripos($block, 'BEGIN:VCARD') === false) continue;
        $c = cimp_empty_record(); $emails=array(); $phones=array(); $address=array(); $fn='';
        $lines = preg_split('/\r\n|\r|\n/', trim($block));
        foreach ($lines as $line) {
            list($left,$value) = cimp_vcard_value($line);
            if ($left === '') continue;
            $prop = strtoupper(strtok($left, ';'));
            if (strpos($prop,'.') !== false) $prop = substr($prop, strrpos($prop,'.')+1);
            if ($prop === 'FN') $fn = cimp_clean($value);
            elseif ($prop === 'N') {
                $p = explode(';',$value); $c['nom']=cimp_clean($p[0]??''); $c['prenom']=cimp_clean($p[1]??'');
                if (($p[3]??'') !== '') $c['civilite']=cimp_clean($p[3]);
            }
            elseif ($prop === 'EMAIL') { $v=cimp_clean($value); if ($v!=='' && !in_array($v,$emails,true)) $emails[]=$v; }
            elseif ($prop === 'TEL') { $v=cimp_clean($value); if ($v!=='' && !in_array($v,$phones,true)) $phones[]=$v; }
            elseif ($prop === 'ORG') { $p=explode(';',$value); $c['entreprise']=cimp_clean($p[0]??''); if (($p[1]??'')!=='' && $c['service']==='') $c['service']=cimp_clean($p[1]); }
            elseif ($prop === 'TITLE') $c['poste']=cimp_clean($value);
            elseif ($prop === 'ADR' && empty($address)) $address=explode(';',$value);
            elseif ($prop === 'BDAY') $c['date_naissance']=cimp_clean($value);
            elseif ($prop === 'URL' && $c['site_web']==='') $c['site_web']=cimp_clean($value);
            elseif ($prop === 'NOTE') $c['notes']=cimp_clean($value,12000);
            elseif ($prop === 'CATEGORIES') $c['tags']=cimp_clean($value);
            elseif ($prop === 'NICKNAME') $c['surnom']=cimp_clean($value);
        }
        if ($c['prenom']==='' && $c['nom']==='' && $fn!=='') {
            $parts=preg_split('/\s+/', trim($fn));
            if (count($parts)>1) { $c['nom']=array_pop($parts); $c['prenom']=implode(' ',$parts); } else $c['nom']=$fn;
        }
        $c['mail']=$emails[0]??''; $c['mail2']=$emails[1]??''; $c['tel']=$phones[0]??''; $c['tel2']=$phones[1]??'';
        if ($address) { $c['adresse']=cimp_clean($address[2]??''); $c['ville']=cimp_clean($address[3]??''); $c['code_postal']=cimp_clean($address[5]??''); $c['pays']=cimp_clean($address[6]??''); }
        $hasWork=($c['entreprise']!==''||$c['poste']!==''||$c['service']!==''); $c['is_pro']=$hasWork; $c['is_private']=!$hasWork;
        if (cimp_is_meaningful($c)) $contacts[]=$c;
        if (count($contacts)>=5000) break;
    }
    return array('source'=>'vCard / VCF','contacts'=>$contacts);
}
function cimp_duplicate($incoming, $existing) {
    $inEmails=array_filter(array_map('cimp_email',array($incoming['mail']??'',$incoming['mail2']??'')));
    $inPhones=array_filter(array_map('cimp_phone',array($incoming['tel']??'',$incoming['tel2']??'')), function($v){return strlen(preg_replace('/\D/','',$v))>=7;});
    $inName=cimp_key(($incoming['prenom']??'').'|'.($incoming['nom']??''));
    foreach ($existing as $c) {
        if (!is_array($c)) continue;
        $exEmails=array_filter(array_map('cimp_email',array($c['mail']??'',$c['mail2']??'')));
        foreach ($inEmails as $v) if ($v!=='' && in_array($v,$exEmails,true)) return array('id'=>(string)($c['id']??''),'reason'=>'Même adresse e-mail','contact'=>$c);
        $exPhones=array_filter(array_map('cimp_phone',array($c['tel']??'',$c['tel2']??'')));
        foreach ($inPhones as $v) if ($v!=='' && in_array($v,$exPhones,true)) return array('id'=>(string)($c['id']??''),'reason'=>'Même numéro de téléphone','contact'=>$c);
        $exName=cimp_key(($c['prenom']??'').'|'.($c['nom']??''));
        if ($inName!=='' && strlen($inName)>=5 && $inName===$exName) {
            $ic=cimp_key($incoming['entreprise']??''); $ec=cimp_key($c['entreprise']??'');
            if ($ic==='' || $ec==='' || $ic===$ec) return array('id'=>(string)($c['id']??''),'reason'=>'Même nom et prénom','contact'=>$c);
        }
    }
    return null;
}
function cimp_preview_contact($c) {
    return array_intersect_key($c, array_flip(array('prenom','nom','entreprise','poste','mail','mail2','tel','tel2','ville','pays','tags','notes')));
}
function cimp_merge_tags($a,$b) {
    $all=preg_split('/[,;]+/', (string)$a.';'.(string)$b); $out=array();
    foreach ($all as $v) { $v=trim($v); if ($v!=='' && !in_array(contact_lower($v), array_map('contact_lower',$out), true)) $out[]=$v; }
    return implode(', ',$out);
}
function cimp_merge_record($old,$inc,$source) {
    $old=is_array($old)?$old:array(); $inc=is_array($inc)?$inc:array(); $out=$old; $conflicts=array();
    foreach (array('civilite','prenom','nom','surnom','relation_private','relation_pro','entreprise','poste','service','siret','adresse','code_postal','ville','pays','date_naissance','statut_familial','site_web','linkedin') as $k) {
        $a=trim((string)($old[$k]??'')); $b=trim((string)($inc[$k]??''));
        if ($a==='' && $b!=='') $out[$k]=$b; elseif ($a!=='' && $b!=='' && cimp_key($a)!==cimp_key($b)) $conflicts[]=$k.': '.$b;
    }
    foreach (array('mail','tel') as $base) {
        $vals=array(); foreach (array($old[$base]??'',$old[$base.'2']??'',$inc[$base]??'',$inc[$base.'2']??'') as $v) { $v=trim((string)$v); if($v==='' )continue; $key=$base==='mail'?cimp_email($v):cimp_phone($v); $seen=false; foreach($vals as $vv){$kk=$base==='mail'?cimp_email($vv):cimp_phone($vv); if($kk===$key){$seen=true;break;}} if(!$seen)$vals[]=$v; }
        $out[$base]=$vals[0]??''; $out[$base.'2']=$vals[1]??''; if(count($vals)>2) for($i=2;$i<count($vals);$i++) $conflicts[]=($base==='mail'?'Email complémentaire':'Téléphone complémentaire').': '.$vals[$i];
    }
    $out['tags']=cimp_merge_tags($old['tags']??'',$inc['tags']??'');
    $notes=trim((string)($old['notes']??'')); $incomingNotes=trim((string)($inc['notes']??''));
    if ($incomingNotes!=='' && stripos($notes,$incomingNotes)===false) $notes=trim($notes.($notes!==''?"\n\n":'').'Import '.$source.":\n".$incomingNotes);
    if ($conflicts) $notes=trim($notes.($notes!==''?"\n\n":'').'Données complémentaires importées (valeurs existantes conservées) :'."\n- ".implode("\n- ",$conflicts));
    $out['notes']=$notes; $out['is_private']=!empty($old['is_private'])||!empty($inc['is_private']); $out['is_pro']=!empty($old['is_pro'])||!empty($inc['is_pro']);
    $out['updated_at']=date('c');
    return $out;
}
function cimp_new_record($inc) {
    $now=date('c'); $r=array_merge(cimp_empty_record(),is_array($inc)?$inc:array());
    $r['id']='c_'.bin2hex(random_bytes(12)); $r['shared_with']=array(); $r['shared_roles']=array(); $r['share_same_role']=false; $r['avatar']=''; $r['created_at']=$now; $r['updated_at']=$now;
    return $r;
}
function cimp_tmp_dir($email) {
    $base=contact_user_dir($email,true); if($base==='') return '';
    $dir=rtrim($base,'/\\').'/imports/'; if(!is_dir($dir)) @mkdir($dir,0750,true); return $dir;
}
function cimp_cleanup($dir) {
    foreach (glob(rtrim($dir,'/\\').'/*.json') ?: array() as $f) if (@filemtime($f) && filemtime($f)<time()-86400) @unlink($f);
}

$email=contact_current_email();
if($email==='') cimp_out(false,array('error'=>'AUTH','message'=>'Non connecté.'),403);
dmd_require_module_access(CONTACT_MODULE_ID,'view');
dmd_require_module_access(CONTACT_MODULE_ID,'create');
if($_SERVER['REQUEST_METHOD']!=='POST') cimp_out(false,array('error'=>'METHOD'),405);
$token=(string)($_POST['csrf_token']??'');
if($token===''||empty($_SESSION['csrf_contact'])||!hash_equals((string)$_SESSION['csrf_contact'],$token)) cimp_out(false,array('error'=>'CSRF','message'=>'Session expirée, recharge la page.'),403);
$action=trim((string)($_POST['action']??''));
$tmpDir=cimp_tmp_dir($email); if($tmpDir==='') cimp_out(false,array('error'=>'STORAGE','message'=>'Dossier utilisateur indisponible.'),500); cimp_cleanup($tmpDir);

if($action==='preview') {
    if(!isset($_FILES['contacts_file'])||!is_array($_FILES['contacts_file'])) cimp_out(false,array('error'=>'FILE','message'=>'Choisis un fichier CSV ou VCF.'),400);
    $f=$_FILES['contacts_file']; if(($f['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||!is_uploaded_file($f['tmp_name']??'')) cimp_out(false,array('error'=>'UPLOAD','message'=>'Le fichier n’a pas pu être reçu.'),400);
    $size=(int)($f['size']??0); if($size<1||$size>10*1024*1024) cimp_out(false,array('error'=>'SIZE','message'=>'Le fichier doit faire moins de 10 Mo.'),400);
    $name=(string)($f['name']??'contacts'); $ext=strtolower(pathinfo($name,PATHINFO_EXTENSION)); $raw=@file_get_contents($f['tmp_name']); if($raw===false) cimp_out(false,array('error'=>'READ','message'=>'Impossible de lire le fichier.'),400);
    if($ext==='vcf'||stripos(substr($raw,0,1000),'BEGIN:VCARD')!==false) $parsed=cimp_parse_vcf($raw); elseif(in_array($ext,array('csv','txt'),true)) $parsed=cimp_parse_csv($raw); else cimp_out(false,array('error'=>'FORMAT','message'=>'Format non pris en charge. Utilise CSV ou VCF/vCard.'),400);
    $rows=$parsed['contacts']??array(); if(!$rows) cimp_out(false,array('error'=>'EMPTY','message'=>'Aucun contact exploitable trouvé dans ce fichier.'),400);
    $existing=contact_read_json(contact_contacts_file($email,true),array()); $probe=$existing; $preview=array(); $duplicates=0;
    foreach($rows as $i=>$c){
        $dup=cimp_duplicate($c,$probe);
        if($dup)$duplicates++;
        $preview[]=array('index'=>$i,'contact'=>cimp_preview_contact($c),'duplicate'=>$dup?array('id'=>$dup['id'],'reason'=>$dup['reason'],'location'=>strpos((string)$dup['id'],'__import_')===0?'file':'existing','contact'=>cimp_preview_contact($dup['contact'])):null);
        $probeRow=$c; $probeRow['id']='__import_'.$i; $probe[]=$probeRow;
    }
    $importToken=bin2hex(random_bytes(20)); $payload=array('owner'=>$email,'created_at'=>time(),'source'=>(string)($parsed['source']??'Import'),'filename'=>basename($name),'contacts'=>$rows);
    if(!contact_write_json($tmpDir.'import_'.$importToken.'.json',$payload)) cimp_out(false,array('error'=>'WRITE','message'=>'Impossible de préparer l’import.'),500);
    cimp_out(true,array('token'=>$importToken,'source'=>$payload['source'],'filename'=>$payload['filename'],'count'=>count($rows),'duplicates'=>$duplicates,'items'=>$preview));
}

if($action==='commit') {
    $importToken=preg_replace('/[^a-f0-9]/','',strtolower((string)($_POST['import_token']??''))); if(strlen($importToken)!==40) cimp_out(false,array('error'=>'TOKEN','message'=>'Import invalide ou expiré.'),400);
    $path=$tmpDir.'import_'.$importToken.'.json'; $payload=contact_read_json($path,array()); if(!$payload||contact_lower($payload['owner']??'')!==contact_lower($email)) cimp_out(false,array('error'=>'EXPIRED','message'=>'Import expiré. Recommence avec le fichier.'),400);
    $decisions=json_decode((string)($_POST['decisions']??'{}'),true); if(!is_array($decisions))$decisions=array();
    $contacts=contact_read_json(contact_contacts_file($email,true),array()); $added=0;$merged=0;$skipped=0; $source=(string)($payload['source']??'Import');
    foreach((array)($payload['contacts']??array()) as $i=>$inc){
        if(!is_array($inc)||!cimp_is_meaningful($inc)){ $skipped++; continue; }
        $dup=cimp_duplicate($inc,$contacts); $choice=(string)($decisions[(string)$i]??($dup?'merge':'new'));
        if($choice==='skip'){ $skipped++; continue; }
        if($choice==='merge'&&$dup){$idx=contact_find_own($email,$dup['id'],$contacts); if($idx>=0){$contacts[$idx]=cimp_merge_record($contacts[$idx],$inc,$source); contact_emit_resource_event($email,'contact.import',$contacts[$idx],'success','Contact fusionné depuis '.$source.' : '.contact_full_name($contacts[$idx])); $merged++; continue;}}
        $record=cimp_new_record($inc); $contacts[]=$record; contact_emit_resource_event($email,'contact.import',$record,'success','Contact importé depuis '.$source.' : '.contact_full_name($record)); $added++;
    }
    usort($contacts,function($a,$b){return strcoll(contact_lower(contact_sort_key($a)),contact_lower(contact_sort_key($b)));});
    if(!contact_write_json(contact_contacts_file($email,true),array_values($contacts))) cimp_out(false,array('error'=>'WRITE','message'=>'Impossible d’enregistrer les contacts importés.'),500);
    contact_index_refresh_owner($email,$contacts); @unlink($path); contact_log($email,'contact.import','bulk','success',$added.' ajouté(s), '.$merged.' fusionné(s), '.$skipped.' ignoré(s) depuis '.$source);
    cimp_out(true,array('message'=>$added.' contact(s) ajouté(s), '.$merged.' fusionné(s), '.$skipped.' ignoré(s).','added'=>$added,'merged'=>$merged,'skipped'=>$skipped));
}

cimp_out(false,array('error'=>'NO_ROUTE'),400);
