<?php


/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if (session_status() === PHP_SESSION_NONE) session_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/contact_lib.php';

function contact_directory_out($ok, $data = array(), $code = 200) {
    http_response_code($code);
    echo json_encode(array_merge(array('ok'=>(bool)$ok), $data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

$email = contact_current_email();
if ($email === '') contact_directory_out(false, array('error'=>'AUTH'), 403);
dmd_require_module_access(CONTACT_MODULE_ID, 'view');

$mfa = contact_mfa_gate_state($email);
if (!empty($mfa['required']) && empty($mfa['verified'])) {
    contact_directory_out(false, array('error'=>'MFA_REQUIRED','mfa_required'=>true,'message'=>'Déverrouille DMD-Contact avec ton MFA avant la synchronisation.'), 403);
}

$action = trim((string)($_POST['action'] ?? $_GET['action'] ?? 'status'));
$status = contact_directory_provider_status($email);

if ($action === 'status') contact_directory_out(true, array('directory'=>$status));

if ($action === 'list') {
    dmd_require_module_access(CONTACT_MODULE_ID, 'directory_sync');
    if (empty($status['available'])) {
        contact_directory_out(false, array('error'=>'DIRECTORY_UNAVAILABLE','directory'=>$status,'message'=>'Active Directory / LDAP n’est pas encore disponible via le fournisseur central DoMyDesk.'), 409);
    }
    $search = trim((string)($_GET['q'] ?? ''));
    $entries = contact_directory_entries($email, $search);
    $existing = contact_directory_existing_external_ids($email);
    $publicEntries = array();
    foreach ($entries as $entry) {
        $external = trim((string)($entry['external_id'] ?? ''));
        $publicEntries[] = contact_directory_public_entry($entry, $external !== '' && isset($existing[$external]));
    }
    contact_directory_out(true, array('directory'=>$status,'entries'=>$publicEntries,'count'=>count($publicEntries)));
}

if ($action === 'sync') {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') contact_directory_out(false, array('error'=>'METHOD'), 405);
    dmd_require_module_access(CONTACT_MODULE_ID, 'directory_sync');
    $token = (string)($_POST['csrf_token'] ?? '');
    if ($token === '' || empty($_SESSION['csrf_contact']) || !hash_equals((string)$_SESSION['csrf_contact'], $token)) {
        contact_directory_out(false, array('error'=>'CSRF','message'=>'Formulaire expiré. Recharge la page.'), 403);
    }
    $selected = $_POST['selected'] ?? array();
    if (!is_array($selected)) $selected = array($selected);
    if (count($selected) > 500) contact_directory_out(false, array('error'=>'TOO_MANY','message'=>'Sélection trop importante.'), 400);
    $result = contact_directory_sync_selected($email, $selected);
    if (empty($result['ok'])) contact_directory_out(false, $result, 409);
    contact_directory_out(true, array_merge($result, array('message'=>(int)$result['created'].' créé(s), '.(int)$result['updated'].' mis à jour, '.(int)$result['skipped'].' ignoré(s).')));
}

contact_directory_out(false, array('error'=>'NO_ROUTE'), 400);
