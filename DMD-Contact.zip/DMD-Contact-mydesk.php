<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/contact_lib.php';

$email = contact_current_email();
if ($email === '') {
    echo '<div class="dmd-contact-mydesk dmd-contact-mydesk-denied">⛔ Connexion MyDesk requise.</div>';
    return;
}
dmd_require_module_access(CONTACT_MODULE_ID, 'view');

if (empty($_SESSION['csrf_contact'])) $_SESSION['csrf_contact'] = bin2hex(random_bytes(32));
$csrfContact = (string)$_SESSION['csrf_contact'];
$canCreate = dmd_current_user_has_module_permission(CONTACT_MODULE_ID, 'create');

function dmd_contact_mydesk_module_base() {
    $docRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
    $moduleDir = realpath(__DIR__) ?: __DIR__;
    if ($docRoot !== '' && strpos($moduleDir, $docRoot) === 0) {
        return '/' . ltrim(str_replace('\\', '/', substr($moduleDir, strlen($docRoot))), '/');
    }
    return '/modules/DMD-Contact';
}

function dmd_contact_mydesk_theme_url($email, $moduleBase) {
    $safe = function_exists('dmd_safe_user_key') ? dmd_safe_user_key($email) : basename((string)$email);
    $theme = 'default';
    $themeFile = DMD_ROOT . '/users/profiles/' . $safe . '/theme.json';
    if (is_file($themeFile)) {
        $data = json_decode((string)@file_get_contents($themeFile), true);
        if (is_array($data) && !empty($data['theme'])) {
            $candidate = basename((string)$data['theme']);
            if (is_file(DMD_ROOT . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
        }
    }
    $webRoot = preg_replace('~/modules/DMD-Contact/?$~', '', rtrim((string)$moduleBase, '/'));
    return ($webRoot !== '' ? $webRoot : '') . '/theme/' . rawurlencode($theme) . '/style.css';
}

$moduleBase = dmd_contact_mydesk_module_base();
$themeUrl = dmd_contact_mydesk_theme_url($email, $moduleBase);
$cssVersion = is_file(__DIR__ . '/contact-mydesk.css') ? (string)filemtime(__DIR__ . '/contact-mydesk.css') : '2.3.0';
$contacts = contact_accessible_contacts($email);
foreach ($contacts as &$contact) {
    if (!empty($contact['avatar'])) {
        $contact['avatar_url'] = rtrim($moduleBase, '/') . '/contact_media.php?owner=' . rawurlencode((string)$contact['owner_email']) . '&id=' . rawurlencode((string)$contact['id']);
    } else {
        $contact['avatar_url'] = '';
    }
}
unset($contact);

$contactsJson = json_encode($contacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
$fullUrl = rtrim($moduleBase, '/') . '/DMD-Contact.php?dmd_contact_mydesk_full=1';
$uid = 'dmd_contact_mydesk_' . bin2hex(random_bytes(5));
?>
<link rel="stylesheet" href="<?= contact_h($themeUrl) ?>">
<link rel="stylesheet" href="<?= contact_h(rtrim($moduleBase, '/') . '/contact-mydesk.css?v=' . $cssVersion) ?>">

<script>
(() => {
    function sourceWindow(){
        const candidates=[];
        try { if (window.opener && !window.opener.closed) candidates.push(window.opener); } catch (_) {}
        try { if (window.parent && window.parent !== window) candidates.push(window.parent); } catch (_) {}
        for (const candidate of candidates) {
            try { if (candidate.document && candidate.location.origin === window.location.origin) return candidate; } catch (_) {}
        }
        return null;
    }
    function syncTheme(){
        const source=sourceWindow();
        if (!source) return;
        const names=[
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color','--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg','--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];
        const targets=[document.documentElement,document.body].filter(Boolean);
        [source.document.documentElement,source.document.body].filter(Boolean).forEach(sourceRoot=>{
            const cs=source.getComputedStyle(sourceRoot);
            names.forEach(name=>{
                const value=cs.getPropertyValue(name);
                if(value && value.trim()) targets.forEach(target=>target.style.setProperty(name,value.trim()));
            });
        });
        try {
            const bs=source.getComputedStyle(source.document.body);
            targets.forEach(target=>{ target.style.fontFamily=bs.fontFamily||''; });
            if(!getComputedStyle(document.documentElement).getPropertyValue('--background-color').trim()) document.documentElement.style.setProperty('--background-color',bs.backgroundColor||'transparent');
            if(!getComputedStyle(document.documentElement).getPropertyValue('--text-color').trim()) document.documentElement.style.setProperty('--text-color',bs.color||'inherit');
        } catch (_) {}
        document.documentElement.classList.add('dmd-contact-mydesk-host');
        if(document.body) document.body.classList.add('dmd-contact-mydesk-host');
    }
    syncTheme();
    window.addEventListener('load',syncTheme,{once:true});
})();
</script>

<section
    class="dmd-contact-mydesk"
    id="<?= contact_h($uid) ?>"
    data-module-base="<?= contact_h($moduleBase) ?>"
    data-process-url="<?= contact_h(rtrim($moduleBase, '/') . '/contact_process.php') ?>"
    data-full-url="<?= contact_h($fullUrl) ?>"
    data-csrf="<?= contact_h($csrfContact) ?>"
    data-can-create="<?= $canCreate ? '1' : '0' ?>"
    data-dmd-module-id="DMD-Contact"
    data-dmd-context-type="contact_directory"
    data-dmd-context-id="DMD-Contact:directory"
    data-dmd-context-name="DMD-Contact"
>
    <header class="dcm-head">
        <div class="dcm-title">
            <img src="<?= contact_h(rtrim($moduleBase, '/') . '/icon.png') ?>" alt="" class="dcm-module-icon">
            <div><strong>DMD-Contact</strong><small>Carnet rapide</small></div>
        </div>
        <div class="dcm-head-actions">
            <span class="dcm-count" data-role="count" title="Contacts affichés"><?= count($contacts) ?></span>
            <button type="button" class="dcm-iconbtn" data-action="refresh" title="Actualiser" aria-label="Actualiser">↻</button>
            <?php if ($canCreate): ?><button type="button" class="dcm-iconbtn" data-action="new" title="Nouveau contact" aria-label="Nouveau contact">＋</button><?php endif; ?>
            <button type="button" class="dcm-iconbtn dcm-open-full" data-action="full" title="Ouvrir DMD-Contact complet dans DoMyDesk / PWA" aria-label="Ouvrir DMD-Contact complet">↗</button>
        </div>
    </header>

    <div class="dcm-search-row">
        <label class="dcm-search"><span aria-hidden="true">⌕</span><input type="search" data-role="search" autocomplete="off" placeholder="Nom, société, téléphone, email…"></label>
    </div>

    <nav class="dcm-filters" aria-label="Filtres">
        <button type="button" class="is-active" data-filter="all">Tous</button>
        <button type="button" data-filter="private">Privé</button>
        <button type="button" data-filter="pro">Pro</button>
        <button type="button" data-filter="shared">Partagés</button>
    </nav>

    <div class="dcm-message" data-role="message" hidden></div>

    <div class="dcm-list" data-role="list" aria-live="polite"></div>
    <div class="dcm-empty" data-role="empty" hidden>Aucun contact correspondant.</div>

    <?php if ($canCreate): ?>
    <section class="dcm-drawer" data-role="new-drawer" hidden aria-label="Nouveau contact">
        <div class="dcm-drawer-head"><strong>＋ Nouveau contact</strong><button type="button" class="dcm-iconbtn" data-action="new-close" title="Fermer">×</button></div>
        <form data-role="quick-form" class="dcm-quick-form">
            <div class="dcm-form-grid">
                <label><span>Prénom</span><input name="prenom" autocomplete="given-name"></label>
                <label><span>Nom</span><input name="nom" autocomplete="family-name"></label>
                <label class="wide"><span>Société</span><input name="entreprise" autocomplete="organization"></label>
                <label><span>Téléphone</span><input name="tel" inputmode="tel" autocomplete="tel"></label>
                <label><span>Email</span><input name="mail" type="email" autocomplete="email"></label>
            </div>
            <div class="dcm-type-line">
                <label><input type="checkbox" name="is_private" value="1" checked> Privé</label>
                <label><input type="checkbox" name="is_pro" value="1"> Pro</label>
            </div>
            <div class="dcm-form-actions"><button type="button" data-action="new-close">Annuler</button><button type="submit" class="primary">Enregistrer</button></div>
        </form>
    </section>
    <?php endif; ?>

    <section class="dcm-drawer dcm-detail" data-role="detail" hidden aria-label="Fiche contact"></section>
</section>

<script>
(() => {
    const root=document.getElementById(<?= json_encode($uid) ?>);
    if(!root || root.dataset.bound==='1') return;
    root.dataset.bound='1';

    const sourceContacts=<?= $contactsJson ?: '[]' ?>;
    let contacts=Array.isArray(sourceContacts)?sourceContacts:[];
    let filter='all';
    const processUrl=root.dataset.processUrl;
    const fullUrl=root.dataset.fullUrl;
    const csrf=root.dataset.csrf;
    const canCreate=root.dataset.canCreate==='1';
    const el={
        search:root.querySelector('[data-role="search"]'),
        list:root.querySelector('[data-role="list"]'),
        count:root.querySelector('[data-role="count"]'),
        empty:root.querySelector('[data-role="empty"]'),
        message:root.querySelector('[data-role="message"]'),
        detail:root.querySelector('[data-role="detail"]'),
        newDrawer:root.querySelector('[data-role="new-drawer"]'),
        quickForm:root.querySelector('[data-role="quick-form"]')
    };

    function esc(value){
        return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
    }
    function text(value){ return String(value??'').trim(); }
    function normalize(value){ return text(value).toLocaleLowerCase('fr'); }
    function cleanPhone(value){ return text(value).replace(/[^0-9+*#;,]/g,''); }
    function webUrl(value){
        const v=text(value); if(!v) return '';
        if(/^https?:\/\//i.test(v)) return v;
        return 'https://'+v;
    }
    function notify(message,error=false){
        if(!el.message) return;
        el.message.hidden=!message;
        el.message.textContent=message||'';
        el.message.dataset.error=error?'1':'0';
        if(message) window.setTimeout(()=>{ if(el.message.textContent===message) el.message.hidden=true; },3500);
    }
    function requestSize(){
        const height=Math.max(430,Math.min(680,root.scrollHeight+18));
        const detail={type:'dmd:mydesk-resize',module:'DMD-Contact',mode:'compact',width:390,height};
        try { if(window.opener && !window.opener.closed) window.opener.postMessage(detail,window.location.origin); } catch(_){}
        try { if(window.parent && window.parent!==window) window.parent.postMessage(detail,window.location.origin); } catch(_){}
        try { window.dispatchEvent(new CustomEvent('dmd:mydesk-resize',{detail})); } catch(_){}
    }
    function matches(c){
        if(filter==='private' && !c.is_private) return false;
        if(filter==='pro' && !c.is_pro) return false;
        if(filter==='shared' && !c.is_shared) return false;
        const q=normalize(el.search?.value);
        if(!q) return true;
        return normalize([c.display_name,c.prenom,c.nom,c.surnom,c.entreprise,c.poste,c.service,c.mail,c.mail2,c.tel,c.tel2,c.ville,c.tags].join(' ')).includes(q);
    }
    function badges(c){
        const out=[];
        if(c.is_private) out.push('<span>Privé</span>');
        if(c.is_pro) out.push('<span>Pro</span>');
        if(c.is_shared) out.push('<span class="shared">Partagé</span>');
        return out.join('');
    }
    function avatar(c){
        if(c.avatar_url) return `<img class="dcm-avatar" src="${esc(c.avatar_url)}" alt="">`;
        return `<span class="dcm-avatar dcm-initials">${esc(c.initials||'?')}</span>`;
    }
    function render(){
        const items=contacts.filter(matches);
        el.count.textContent=String(items.length);
        el.empty.hidden=items.length!==0;
        el.list.innerHTML=items.map(c=>{
            const primary=text(c.entreprise)||text(c.poste)||text(c.relation_pro)||text(c.relation_private)||text(c.mail)||text(c.tel)||'Contact';
            const phone=text(c.tel)||text(c.tel2);
            const mail=text(c.mail)||text(c.mail2);
            return `<article class="dcm-row" data-uid="${esc(c.uid)}" tabindex="0" role="button">
                ${avatar(c)}
                <div class="dcm-row-main"><div class="dcm-row-title"><strong>${esc(c.display_name||'(Sans nom)')}</strong><span class="dcm-badges">${badges(c)}</span></div><small>${esc(primary)}</small></div>
                <div class="dcm-row-actions">
                    ${phone?`<a href="tel:${esc(cleanPhone(phone))}" data-stop title="Appeler" aria-label="Appeler">☎</a>`:''}
                    ${mail?`<a href="mailto:${esc(mail)}" data-stop title="Envoyer un email" aria-label="Envoyer un email">✉</a>`:''}
                    <button type="button" data-open="${esc(c.uid)}" title="Voir la fiche" aria-label="Voir la fiche">›</button>
                </div>
            </article>`;
        }).join('');
        requestSize();
    }
    function info(label,value,href=''){
        const v=text(value); if(!v) return '';
        const content=href?`<a href="${esc(href)}" target="_blank" rel="noopener noreferrer">${esc(v)}</a>`:esc(v);
        return `<div class="dcm-info"><span>${esc(label)}</span><div>${content}</div></div>`;
    }
    function showDetail(uid){
        const c=contacts.find(x=>String(x.uid)===String(uid)); if(!c) return;
        if(el.newDrawer) el.newDrawer.hidden=true;
        const phone=text(c.tel)||text(c.tel2), mail=text(c.mail)||text(c.mail2), site=webUrl(c.site_web);
        const address=[c.adresse,[c.code_postal,c.ville].filter(Boolean).join(' '),c.pays].filter(Boolean).join(', ');
        el.detail.innerHTML=`
            <div class="dcm-drawer-head"><strong>Fiche contact</strong><button type="button" class="dcm-iconbtn" data-detail-close title="Fermer">×</button></div>
            <div class="dcm-profile">
                ${avatar(c)}
                <div><h3>${esc(c.display_name||'(Sans nom)')}</h3><div class="dcm-badges">${badges(c)}</div><small>${esc(c.entreprise||c.poste||c.relation_private||c.relation_pro||'')}</small></div>
            </div>
            <div class="dcm-detail-actions">
                ${phone?`<a href="tel:${esc(cleanPhone(phone))}">☎ Appeler</a>`:''}
                ${mail?`<a href="mailto:${esc(mail)}">✉ Email</a>`:''}
                ${site?`<a href="${esc(site)}" target="_blank" rel="noopener noreferrer">🌐 Site</a>`:''}
                ${phone?`<button type="button" data-copy="${esc(phone)}">📋 Téléphone</button>`:''}
            </div>
            <div class="dcm-info-grid">
                ${info('Téléphone',phone)}${info('Email',mail,'mailto:'+mail)}${info('Société',c.entreprise)}${info('Poste',c.poste)}${info('Service',c.service)}${info('Adresse',address)}${info('Ville',c.ville)}${info('Tags',c.tags)}${info('Notes',c.notes)}${c.is_shared?info('Partagé par',c.owner_email):''}
            </div>`;
        el.detail.hidden=false;
        el.detail.querySelector('[data-detail-close]')?.addEventListener('click',()=>{el.detail.hidden=true;requestSize();});
        el.detail.querySelectorAll('[data-copy]').forEach(btn=>btn.addEventListener('click',()=>copyText(btn.dataset.copy,btn)));
        requestSize();
    }
    async function copyText(value,button){
        const valueText=text(value); if(!valueText) return;
        try { await navigator.clipboard.writeText(valueText); }
        catch(_){ const t=document.createElement('textarea');t.value=valueText;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();document.execCommand('copy');t.remove(); }
        if(button){const old=button.textContent;button.textContent='✓ Copié';setTimeout(()=>{if(button.isConnected)button.textContent=old;},900);}
    }
    function openFull(){
        const detail={type:'dmd:mydesk-open-full',module:'DMD-Contact',url:fullUrl,target:'domydesk-pwa'};
        try { if(window.opener && !window.opener.closed) window.opener.postMessage(detail,window.location.origin); } catch(_){}
        try { if(window.parent && window.parent!==window) window.parent.postMessage(detail,window.location.origin); } catch(_){}
        try { window.dispatchEvent(new CustomEvent('dmd:mydesk-open-full',{detail})); } catch(_){}
        try {
            const opened=window.open(fullUrl,'_blank');
            if(opened) { try{ opened.focus(); }catch(_){} return; }
        } catch(_) {}
        window.location.assign(fullUrl);
    }
    async function quickSave(event){
        event.preventDefault();
        if(!canCreate || !el.quickForm) return;
        const fd=new FormData(el.quickForm);
        fd.set('action','save'); fd.set('csrf_token',csrf);
        const submit=el.quickForm.querySelector('button[type="submit"]'); if(submit) submit.disabled=true;
        try {
            const response=await fetch(processUrl,{method:'POST',body:fd,credentials:'same-origin',cache:'no-store'});
            const result=await response.json().catch(()=>({ok:false,error:'Réponse invalide'}));
            if(!response.ok || !result.ok) throw new Error(result.message||result.error||'Enregistrement impossible.');
            notify('Contact enregistré.');
            window.setTimeout(()=>window.location.reload(),180);
        } catch(error){ notify(error.message||String(error),true); if(submit) submit.disabled=false; }
    }

    root.addEventListener('click',event=>{
        if(event.target.closest('[data-stop]')) return;
        const filterBtn=event.target.closest('[data-filter]');
        if(filterBtn){ filter=filterBtn.dataset.filter||'all'; root.querySelectorAll('[data-filter]').forEach(b=>b.classList.toggle('is-active',b===filterBtn)); render(); return; }
        const actionBtn=event.target.closest('[data-action]');
        if(actionBtn){
            const action=actionBtn.dataset.action;
            if(action==='refresh') window.location.reload();
            if(action==='full') openFull();
            if(action==='new' && el.newDrawer){ el.detail.hidden=true; el.newDrawer.hidden=false; el.quickForm?.querySelector('input')?.focus(); requestSize(); }
            if(action==='new-close' && el.newDrawer){ el.newDrawer.hidden=true; requestSize(); }
            return;
        }
        const open=event.target.closest('[data-open]'); if(open){showDetail(open.dataset.open);return;}
        const row=event.target.closest('.dcm-row'); if(row) showDetail(row.dataset.uid);
    });
    root.addEventListener('keydown',event=>{ const row=event.target.closest('.dcm-row'); if(row && (event.key==='Enter'||event.key===' ')){event.preventDefault();showDetail(row.dataset.uid);} });
    el.search?.addEventListener('input',render);
    el.quickForm?.addEventListener('submit',quickSave);

    render();
})();
</script>
