<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!defined('DMD_ROOT')) {
    define('DMD_ROOT', dirname(__DIR__, 2));
}
require_once DMD_ROOT . '/core/dmd_permissions.php';
if (!defined('CONTACT_MODULE_ID')) define('CONTACT_MODULE_ID', 'DMD-Contact');
if (!defined('CONTACT_USER_STORAGE_KEY')) define('CONTACT_USER_STORAGE_KEY', 'contact');
if (!defined('CONTACT_LEGACY_SYSTEM_STORAGE_KEY')) define('CONTACT_LEGACY_SYSTEM_STORAGE_KEY', 'contact');

if (!function_exists('contact_lower')) {
    function contact_lower($value) {
        $value = trim((string)$value);
        return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    }
}
function contact_current_email() { return trim((string)($_SESSION['user']['email'] ?? '')); }
function contact_h($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function contact_read_json($file, $fallback = array()) {
    if (!is_file($file)) return $fallback;
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') return $fallback;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
}
function contact_write_json($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) return false;
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false) return false;
    $tmp = $file . '.tmp.' . bin2hex(random_bytes(4));
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    @chmod($tmp, 0640);
    if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
    @chmod($file, 0640);
    return true;
}
function contact_user_dir($email, $create = true) {
    return dmd_user_module_data_dir($email, CONTACT_USER_STORAGE_KEY, $create);
}
function contact_contacts_file($email, $create = true) {
    $dir = contact_user_dir($email, $create);
    if ($dir === '') return '';
    $file = $dir . 'contacts.json';
    if ($create && !is_file($file)) contact_write_json($file, array());
    return $file;
}
function contact_avatar_dir($email, $create = true) {
    $dir = contact_user_dir($email, $create);
    if ($dir === '') return '';
    $avatars = $dir . 'avatars/';
    if ($create && !is_dir($avatars)) @mkdir($avatars, 0750, true);
    return $avatars;
}
function contact_index_file($create = true) {
    $dir = dmd_module_system_data_dir(CONTACT_MODULE_ID, $create);
    if ($dir === '') return '';
    $file = $dir . 'shared_index.json';
    if (!is_file($file)) {
        $legacyFile = DMD_ROOT . '/data/modules/' . CONTACT_LEGACY_SYSTEM_STORAGE_KEY . '/shared_index.json';
        if (is_file($legacyFile)) {
            if (!is_dir($dir)) @mkdir($dir, 0750, true);
            @copy($legacyFile, $file);
            if (is_file($file)) @chmod($file, 0640);
        }
    }
    return $file;
}
function contact_index_lock_file() {
    $dir = dmd_module_system_data_dir(CONTACT_MODULE_ID, true);
    return $dir === '' ? '' : $dir . 'shared_index.lock';
}
function contact_profile_role($email) {
    $profile = dmd_read_profile($email);
    return trim((string)($profile['role_metier'] ?? ''));
}
function contact_record_has_share($c) {
    return !empty($c['shared_with']) || !empty($c['shared_roles']) || !empty($c['share_same_role']);
}
function contact_index_refresh_owner($email, $contacts = null) {
    $email = trim((string)$email);
    if ($email === '') return false;
    if ($contacts === null) $contacts = contact_read_json(contact_contacts_file($email, false), array());
    $shared = array();
    foreach ((array)$contacts as $c) {
        if (!is_array($c) || empty($c['id']) || !contact_record_has_share($c)) continue;
        $shared[] = $c;
    }
    $lockPath = contact_index_lock_file();
    if ($lockPath === '') return false;
    $fp = @fopen($lockPath, 'c+');
    if (!$fp) return false;
    @flock($fp, LOCK_EX);
    $file = contact_index_file(true);
    $index = contact_read_json($file, array('version'=>1, 'owners'=>array()));
    if (!isset($index['owners']) || !is_array($index['owners'])) $index['owners'] = array();
    if ($shared) {
        $index['owners'][$email] = array('role_metier'=>contact_profile_role($email), 'contacts'=>$shared, 'updated_at'=>date('c'));
    } else {
        unset($index['owners'][$email]);
    }
    $index['version'] = 1;
    $index['updated_at'] = date('c');
    $ok = contact_write_json($file, $index);
    @flock($fp, LOCK_UN); @fclose($fp);
    return $ok;
}
function contact_index_rebuild() {
    $profiles = DMD_ROOT . '/users/profiles/';
    $owners = array();
    foreach (glob($profiles . '*/contact/contacts.json') ?: array() as $file) {
        $owner = basename(dirname(dirname($file)));
        if (dmd_safe_user_key($owner) === '') continue;
        $rows = contact_read_json($file, array());
        $shared = array();
        foreach ($rows as $c) {
            if (is_array($c) && !empty($c['id']) && contact_record_has_share($c)) $shared[] = $c;
        }
        if ($shared) $owners[$owner] = array('role_metier'=>contact_profile_role($owner), 'contacts'=>$shared, 'updated_at'=>date('c'));
    }
    return contact_write_json(contact_index_file(true), array('version'=>1, 'rebuilt_at'=>date('c'), 'updated_at'=>date('c'), 'owners'=>$owners));
}
function contact_index_read() {
    $file = contact_index_file(true);
    if ($file === '') return array('version'=>1, 'owners'=>array());
    if (!is_file($file)) contact_index_rebuild();
    $index = contact_read_json($file, array('version'=>1, 'owners'=>array()));
    if (!isset($index['owners']) || !is_array($index['owners'])) $index['owners'] = array();
    return $index;
}
function contact_is_shared_to_viewer($c, $ownerEmail, $viewerEmail, $viewerRole, $ownerRole) {
    if (contact_lower($ownerEmail) === contact_lower($viewerEmail)) return true;
    $wanted = contact_lower($viewerEmail);
    foreach ((array)($c['shared_with'] ?? array()) as $mail) if (contact_lower($mail) === $wanted) return true;
    foreach ((array)($c['shared_roles'] ?? array()) as $role) if ($viewerRole !== '' && contact_lower($role) === contact_lower($viewerRole)) return true;
    return !empty($c['share_same_role']) && $viewerRole !== '' && $ownerRole !== '' && contact_lower($viewerRole) === contact_lower($ownerRole);
}
function contact_initials($c) {
    $p = trim((string)($c['prenom'] ?? '')); $n = trim((string)($c['nom'] ?? ''));
    $sub = function_exists('mb_substr') ? 'mb_substr' : 'substr';
    $a = $sub($p, 0, 1) . $sub($n, 0, 1);
    if ($a === '') $a = $sub((string)($c['entreprise'] ?? '?'), 0, 2);
    return function_exists('mb_strtoupper') ? mb_strtoupper($a ?: '?', 'UTF-8') : strtoupper($a ?: '?');
}
function contact_full_name($c) {
    $name = trim((string)($c['prenom'] ?? '') . ' ' . (string)($c['nom'] ?? ''));
    return $name !== '' ? $name : ((string)($c['entreprise'] ?? '') !== '' ? (string)$c['entreprise'] : '(Sans nom)');
}
function contact_sort_key($c) { return trim((string)($c['nom'] ?? '') . ' ' . (string)($c['prenom'] ?? '') . ' ' . (string)($c['entreprise'] ?? '')); }
function contact_letter($c) {
    $key = contact_sort_key($c);
    $first = function_exists('mb_substr') ? mb_substr($key, 0, 1, 'UTF-8') : substr($key, 0, 1);
    $first = function_exists('mb_strtoupper') ? mb_strtoupper($first, 'UTF-8') : strtoupper($first);
    return preg_match('/^[A-ZÀÂÄÇÉÈÊËÎÏÔÖÙÛÜŸ]$/u', $first) ? $first : '#';
}
function contact_normalize_record($c, $ownerEmail, $viewerEmail) {
    $defaults = array('civilite'=>'','prenom'=>'','nom'=>'','surnom'=>'','is_private'=>true,'is_pro'=>false,'relation_private'=>'','relation_pro'=>'','entreprise'=>'','poste'=>'','service'=>'','siret'=>'','mail'=>'','mail2'=>'','tel'=>'','tel2'=>'','adresse'=>'','code_postal'=>'','ville'=>'','pays'=>'','date_naissance'=>'','statut_familial'=>'','site_web'=>'','linkedin'=>'','tags'=>'','notes'=>'','shared_with'=>array(),'shared_roles'=>array(),'share_same_role'=>false,'avatar'=>'');
    $c = array_merge($defaults, is_array($c) ? $c : array());
    $c['id'] = (string)($c['id'] ?? '');
    $c['uid'] = hash('sha256', contact_lower($ownerEmail) . '|' . $c['id']);
    $c['owner_email'] = $ownerEmail;
    $c['is_owner'] = contact_lower($ownerEmail) === contact_lower($viewerEmail);
    $c['is_shared'] = !$c['is_owner'];
    $c['initials'] = contact_initials($c);
    $c['display_name'] = contact_full_name($c);
    $c['letter'] = contact_letter($c);
    $c['avatar_url'] = !empty($c['avatar']) ? 'modules/DMD-Contact/contact_media.php?owner=' . rawurlencode($ownerEmail) . '&id=' . rawurlencode($c['id']) : '';
    return $c;
}
function contact_accessible_contacts($viewerEmail, $wantedOwner = '', $wantedId = '') {
    $viewerEmail = trim((string)$viewerEmail);
    $viewerRole = contact_profile_role($viewerEmail);
    $out = array();
    if ($wantedOwner === '' || contact_lower($wantedOwner) === contact_lower($viewerEmail)) {
        foreach (contact_read_json(contact_contacts_file($viewerEmail, true), array()) as $c) {
            if (!is_array($c)) continue;
            if ($wantedId !== '' && (string)($c['id'] ?? '') !== $wantedId) continue;
            $out[] = contact_normalize_record($c, $viewerEmail, $viewerEmail);
        }
    }
    $index = contact_index_read();
    foreach ($index['owners'] as $owner => $meta) {
        if (contact_lower($owner) === contact_lower($viewerEmail)) continue;
        if ($wantedOwner !== '' && contact_lower($owner) !== contact_lower($wantedOwner)) continue;
        $ownerRole = trim((string)($meta['role_metier'] ?? ''));
        foreach ((array)($meta['contacts'] ?? array()) as $probe) {
            if (is_array($probe) && !empty($probe['share_same_role'])) { $ownerRole = contact_profile_role($owner); break; }
        }
        foreach ((array)($meta['contacts'] ?? array()) as $c) {
            if (!is_array($c)) continue;
            if ($wantedId !== '' && (string)($c['id'] ?? '') !== $wantedId) continue;
            if (contact_is_shared_to_viewer($c, $owner, $viewerEmail, $viewerRole, $ownerRole)) $out[] = contact_normalize_record($c, $owner, $viewerEmail);
        }
    }
    usort($out, function($a, $b) { return strcoll(contact_lower(contact_sort_key($a)), contact_lower(contact_sort_key($b))); });
    return $out;
}
function contact_available_users($currentEmail) {
    $users = array();
    foreach (glob(DMD_ROOT . '/users/profiles/*', GLOB_ONLYDIR) ?: array() as $profileDir) {
        $mail = basename($profileDir);
        if ($mail === '' || contact_lower($mail) === contact_lower($currentEmail)) continue;
        $p = dmd_read_profile($mail);
        if (!$p) continue;
        $real = trim((string)($p['email'] ?? $mail));
        $label = trim((string)($p['prenom'] ?? '') . ' ' . (string)($p['nom'] ?? ''));
        if ($label === '') $label = trim((string)($p['pseudo'] ?? ''));
        $users[] = array('email'=>$real ?: $mail, 'label'=>$label ?: ($real ?: $mail), 'role_metier'=>trim((string)($p['role_metier'] ?? '')));
    }
    usort($users, function($a,$b){ return strcoll(contact_lower($a['label']), contact_lower($b['label'])); });
    return $users;
}
function contact_user_label($email) {
    $p = dmd_read_profile($email);
    $label = trim((string)($p['prenom'] ?? '') . ' ' . (string)($p['nom'] ?? ''));
    if ($label === '') $label = trim((string)($p['pseudo'] ?? ''));
    return $label !== '' ? $label : (string)$email;
}
function contact_core_notification($recipientEmail, $title, $message, $actorEmail, $type = 'contact_share', $actionUrl = 'dashboard.php', $meta = array()) {
    $recipientEmail = trim((string)$recipientEmail);
    if ($recipientEmail === '' || contact_lower($recipientEmail) === contact_lower($actorEmail)) return false;
    $core = DMD_ROOT . '/core/dmd_system_services.php';
    if (is_file($core)) require_once $core;

    $payload = array(
        'recipient'=>$recipientEmail,
        'email'=>$recipientEmail,
        'title'=>(string)$title,
        'message'=>(string)$message,
        'type'=>(string)$type,
        'level'=>'info',
        'actor'=>(string)$actorEmail,
        'action_url'=>(string)$actionUrl,
        'action_label'=>'Ouvrir DoMyDesk',
        'requires_superadmin'=>false,
        'meta'=>is_array($meta) ? $meta : array()
    );

    $preferred = array(
        'dmd_notification_create','dmd_notification_add','dmd_notification_push','dmd_notification_send','dmd_notification_write','dmd_notification_append',
        'dmd_add_notification','dmd_create_notification','dmd_push_notification','dmd_send_notification','dmd_notify_user',
        'dmd_notification_emit','dmd_notification_publish','dmd_notification_queue','dmd_notification_store','dmd_emit_notification','dmd_publish_notification'
    );
    $candidates = array();
    foreach ($preferred as $fn) if (function_exists($fn)) $candidates[] = $fn;
    $defined = get_defined_functions();
    foreach ((array)($defined['user'] ?? array()) as $fn) {
        $low = strtolower((string)$fn);
        if (in_array($fn, $candidates, true)) continue;
        if (strpos($low, 'dmd_') !== 0) continue;
        if (strpos($low, 'notification') === false && strpos($low, 'notify') === false) continue;
        if (preg_match('/(?:state|list|read|clear|delete|remove|count|path|file|sanitize|normalize|render)/', $low)) continue;
        if (!preg_match('/(?:add|create|push|send|write|append|notify|emit|publish|queue|store)/', $low)) continue;
        $candidates[] = $fn;
    }

    foreach ($candidates as $fn) {
        try {
            $ref = new ReflectionFunction($fn);
            $args = array();
            $mappedAny = false;
            $valid = true;
            foreach ($ref->getParameters() as $param) {
                $name = strtolower((string)$param->getName());
                $mapped = true;
                if (in_array($name, array('recipient','recipient_email','recipientemail','target_email','targetemail','email','user_email','useremail','to','user'), true)) $value = $recipientEmail;
                elseif (in_array($name, array('title','subject'), true)) $value = (string)$title;
                elseif (in_array($name, array('message','text','body','description'), true)) $value = (string)$message;
                elseif (in_array($name, array('actor','actor_email','actoremail','from','from_email','fromemail','author'), true)) $value = (string)$actorEmail;
                elseif (in_array($name, array('type','notification_type','notificationtype'), true)) $value = (string)$type;
                elseif (in_array($name, array('level','severity'), true)) $value = 'info';
                elseif (in_array($name, array('action_url','actionurl','url','link'), true)) $value = (string)$actionUrl;
                elseif (in_array($name, array('action_label','actionlabel','link_label','linklabel'), true)) $value = 'Ouvrir DoMyDesk';
                elseif (in_array($name, array('meta','metadata','context'), true)) $value = $payload['meta'];
                elseif (in_array($name, array('notification','item','payload','data','entry'), true)) $value = $payload;
                elseif (in_array($name, array('requires_superadmin','superadmin'), true)) $value = false;
                else $mapped = false;

                if ($mapped) {
                    $args[] = $value;
                    $mappedAny = true;
                } elseif ($param->isDefaultValueAvailable()) {
                    $args[] = $param->getDefaultValue();
                } elseif ($param->isOptional()) {
                    continue;
                } else {
                    $valid = false;
                    break;
                }
            }
            if (!$valid || !$mappedAny) continue;
            $result = $ref->invokeArgs($args);
            if ($result !== false) return true;
        } catch (Throwable $e) {
            continue;
        }
    }
    return false;
}

function contact_log($email, $action, $target, $result, $details = '') {
    $safe = dmd_safe_user_key($email); if ($safe === '') return;
    $dir = DMD_ROOT . '/users/profiles/' . $safe . '/logs/' . CONTACT_MODULE_ID . '/';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $file = $dir . date('Y-m-d') . '.json';
    $rows = contact_read_json($file, array());
    $rows[] = array('datetime'=>date('c'),'user'=>$email,'action'=>$action,'target'=>$target,'result'=>$result,'details'=>$details);
    if (count($rows) > 1000) $rows = array_slice($rows, -1000);
    contact_write_json($file, $rows);
}

function contact_resource_activity_file($email) {
    $dir = contact_user_dir($email, true);
    return $dir === '' ? '' : $dir . 'resource_activity.json';
}
function contact_resource_activity_lock_file($email) {
    $dir = contact_user_dir($email, true);
    return $dir === '' ? '' : $dir . 'resource_activity.lock';
}
function contact_resource_activity_store($event) {
    if (!is_array($event) || empty($event['resource']['id'])) return false;
    $eventUser = trim((string)($event['user'] ?? ''));
    if ($eventUser === '') return false;
    $file = contact_resource_activity_file($eventUser);
    $lockPath = contact_resource_activity_lock_file($eventUser);
    if ($file === '' || $lockPath === '') return false;
    $fp = @fopen($lockPath, 'c+');
    if (!$fp) return false;
    @flock($fp, LOCK_EX);
    $index = contact_read_json($file, array('version'=>1, 'resources'=>array()));
    if (!isset($index['resources']) || !is_array($index['resources'])) $index['resources'] = array();

    $resource = (array)$event['resource'];
    $key = 'contact:' . (string)$resource['id'];
    $old = isset($index['resources'][$key]) && is_array($index['resources'][$key]) ? $index['resources'][$key] : array();
    $history = isset($old['events']) && is_array($old['events']) ? $old['events'] : array();
    $history[] = array(
        'datetime'=>(string)($event['datetime'] ?? date('c')),
        'user'=>(string)($event['user'] ?? ''),
        'action'=>(string)($event['action'] ?? ''),
        'result'=>(string)($event['result'] ?? ''),
        'details'=>(string)($event['details'] ?? '')
    );
    if (count($history) > 50) $history = array_slice($history, -50);

    $index['resources'][$key] = array(
        'type'=>'contact',
        'id'=>(string)$resource['id'],
        'source_id'=>(string)($resource['source_id'] ?? ''),
        'name'=>(string)($resource['name'] ?? ''),
        'owner_email'=>(string)($resource['owner_email'] ?? ''),
        'module'=>CONTACT_MODULE_ID,
        'last_action'=>(string)($event['action'] ?? ''),
        'last_at'=>(string)($event['datetime'] ?? date('c')),
        'last_user'=>(string)($event['user'] ?? ''),
        'event_count'=>(int)($old['event_count'] ?? 0) + 1,
        'events'=>$history
    );
    $index['version'] = 1;
    $index['updated_at'] = date('c');

    if (count($index['resources']) > 2000) {
        uasort($index['resources'], function($a, $b) {
            return strcmp((string)($b['last_at'] ?? ''), (string)($a['last_at'] ?? ''));
        });
        $index['resources'] = array_slice($index['resources'], 0, 2000, true);
    }

    $ok = contact_write_json($file, $index);
    @flock($fp, LOCK_UN);
    @fclose($fp);
    return $ok;
}
function contact_quick_session_boot() {
    $file = DMD_ROOT . '/core/dmd_quick_session.php';
    if (is_file($file)) require_once $file;
}
function contact_quick_session_writer_candidates() {
    $preferred = array(
        'dmd_qs_append_timeline_event','dmd_qs_add_timeline_event','dmd_qs_record_timeline_event',
        'dmd_qs_timeline_append','dmd_qs_timeline_add','dmd_qs_timeline_record',
        'dmd_qs_append_event','dmd_qs_add_event','dmd_qs_record_event','dmd_qs_push_event','dmd_qs_track_event','dmd_qs_capture_event','dmd_qs_write_event',
        'dmd_qs_append_activity','dmd_qs_add_activity','dmd_qs_record_activity','dmd_qs_push_activity','dmd_qs_track_activity',
        'dmd_qs_log_action','dmd_qs_record_action','dmd_qs_add_action'
    );
    $found = array();
    foreach ($preferred as $fn) if (function_exists($fn)) $found[] = $fn;
    $all = get_defined_functions();
    foreach ((array)($all['user'] ?? array()) as $fn) {
        $low = strtolower((string)$fn);
        if (strpos($low, 'dmd_qs_') !== 0 || in_array($fn, $found, true)) continue;
        if (preg_match('/(?:get|read|list|suggest|resolve|start|active|archive|delete|remove)/', $low)) continue;
        if (!preg_match('/(?:add|append|record|push|track|capture|write|log)/', $low)) continue;
        if (!preg_match('/(?:timeline|event|activity|action)/', $low)) continue;
        $found[] = $fn;
    }
    return $found;
}
function contact_qs_argument_for_parameter($param, $email, $active, $event, &$known) {
    $name = strtolower((string)$param->getName());
    $resource = (array)($event['resource'] ?? array());
    $sessionId = (string)($active['id'] ?? ($active['session_id'] ?? ($active['uid'] ?? '')));
    $value = null;
    $ok = true;

    if (in_array($name, array('email','mail','user_email','owner_email','actor_email'), true)) $value = $email;
    elseif (in_array($name, array('module','module_id','moduleid'), true)) $value = CONTACT_MODULE_ID;
    elseif (in_array($name, array('action','action_id','event_type','eventtype'), true)) $value = (string)($event['action'] ?? '');
    elseif (in_array($name, array('resource_type','resourcetype','object_type','target_type'), true)) $value = 'contact';
    elseif (in_array($name, array('resource_id','resourceid','object_id','target_id','target'), true)) $value = (string)($resource['id'] ?? '');
    elseif (in_array($name, array('resource_name','resourcename','object_name','target_name','name','title','label'), true)) $value = (string)($resource['name'] ?? '');
    elseif (in_array($name, array('result','status'), true)) $value = (string)($event['result'] ?? 'success');
    elseif (in_array($name, array('details','message','description','text'), true)) $value = (string)($event['details'] ?? '');
    elseif (in_array($name, array('resource','object'), true)) $value = $resource;
    elseif (in_array($name, array('event','activity','entry','timeline','timeline_entry','timelineentry','timeline_event','timelineevent','item','row','payload','data','meta','context'), true)) $value = $event;
    elseif (in_array($name, array('session_id','sessionid','quick_session_id','quick_session'), true)) $value = $sessionId;
    elseif ($name === 'session') {
        $type = $param->getType();
        $value = ($type && (string)$type === 'array') ? $active : ($sessionId !== '' ? $sessionId : $active);
    }
    elseif (in_array($name, array('user','actor'), true)) $value = $email;
    else $ok = false;

    if ($ok) $known = true;
    return array($ok, $value);
}
function contact_quick_session_append($email, $event) {
    contact_quick_session_boot();
    if (!function_exists('dmd_qs_get_active')) return false;
    try { $active = dmd_qs_get_active($email); } catch (Throwable $e) { return false; }
    if (!is_array($active)) return false;

    $event['quick_session_id'] = (string)($active['id'] ?? ($active['session_id'] ?? ($active['uid'] ?? '')));
    foreach (contact_quick_session_writer_candidates() as $fn) {
        try {
            $ref = new ReflectionFunction($fn);
            $args = array();
            $valid = true;
            $known = false;
            foreach ($ref->getParameters() as $param) {
                list($mapped, $value) = contact_qs_argument_for_parameter($param, $email, $active, $event, $known);
                if ($mapped) {
                    $args[] = $value;
                    continue;
                }
                if ($param->isDefaultValueAvailable()) {
                    $args[] = $param->getDefaultValue();
                    continue;
                }
                if ($param->isOptional()) continue;
                $valid = false;
                break;
            }
            if (!$valid || !$known) continue;
            $result = $ref->invokeArgs($args);
            if ($result !== false) return true;
        } catch (Throwable $e) {
            continue;
        }
    }
    return false;
}
function contact_emit_resource_event($email, $action, $record, $result = 'success', $details = '') {
    $record = is_array($record) ? $record : array('id'=>(string)$record);
    $normalized = contact_normalize_record($record, $email, $email);
    $resourceId = (string)($normalized['uid'] ?? '');
    if ($resourceId === '') $resourceId = hash('sha256', contact_lower($email) . '|' . (string)($record['id'] ?? ''));
    $name = contact_full_name($record);
    $now = time();
    $iso = date('c', $now);
    $labelMap = array(
        'contact.create'=>'Contact créé',
        'contact.edit'=>'Contact modifié',
        'contact.delete'=>'Contact supprimé',
        'contact.export'=>'Contact exporté',
        'contact.share'=>'Contact partagé',
        'contact.import'=>'Contact importé'
    );
    $event = array(
        /* Format activité ressource + format Timeline Core : les deux sont volontairement présents. */
        'timestamp'=>$now,
        'date_iso'=>$iso,
        'datetime'=>$iso,
        'user'=>$email,
        'module'=>CONTACT_MODULE_ID,
        'action'=>(string)$action,
        'label'=>(string)($labelMap[$action] ?? $action),
        'target'=>$resourceId,
        'status'=>(string)$result,
        'result'=>(string)$result,
        'resource'=>array(
            'type'=>'contact',
            'id'=>$resourceId,
            'source_id'=>(string)($record['id'] ?? ''),
            'name'=>$name,
            'owner_email'=>$email
        ),
        'details'=>$details !== '' ? (string)$details : $name
    );
    contact_log($email, $action, (string)($record['id'] ?? $resourceId), $result, $event['details']);
    contact_resource_activity_store($event);
    contact_quick_session_append($email, $event);
    return $event;
}

function contact_find_own($email, $id, &$contacts = null) {
    if ($contacts === null) $contacts = contact_read_json(contact_contacts_file($email, true), array());
    foreach ($contacts as $i => $c) if (is_array($c) && (string)($c['id'] ?? '') === (string)$id) return $i;
    return -1;
}
