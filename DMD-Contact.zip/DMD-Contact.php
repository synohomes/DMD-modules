<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */


if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/contact_lib.php';

$email = contact_current_email();
if ($email === '') { echo '<div class="contact-error">⛔ Non connecté</div>'; return; }
dmd_require_module_access(CONTACT_MODULE_ID, 'view');

if (empty($_SESSION['csrf_contact'])) $_SESSION['csrf_contact'] = bin2hex(random_bytes(32));
$csrfContact = (string)$_SESSION['csrf_contact'];
$canCreate = dmd_current_user_has_module_permission(CONTACT_MODULE_ID, 'create');
$canEdit = dmd_current_user_has_module_permission(CONTACT_MODULE_ID, 'edit');
$canDelete = dmd_current_user_has_module_permission(CONTACT_MODULE_ID, 'delete');
$canShare = dmd_current_user_has_module_permission(CONTACT_MODULE_ID, 'share');
$canExport = dmd_current_user_has_module_permission(CONTACT_MODULE_ID, 'export');

$contacts = contact_accessible_contacts($email);
$availableUsers = $canShare ? contact_available_users($email) : array();
$availableRoles = $canShare && function_exists('dmd_roles_catalog') ? dmd_roles_catalog() : array();
$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleBase = '/modules/DMD-Contact';
if ($documentRoot !== '' && strpos($moduleRealDir, $documentRoot) === 0) {
    $moduleBase = '/' . ltrim(str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot))), '/');
}
$moduleBase = rtrim($moduleBase, '/');
$myDeskFull = isset($_GET['dmd_contact_mydesk_full']) && (string)$_GET['dmd_contact_mydesk_full'] === '1';
$themeHref = '';
if ($myDeskFull) {
    $safeUser = function_exists('dmd_safe_user_key') ? dmd_safe_user_key($email) : basename((string)$email);
    $theme = 'default';
    $themeJson = DMD_ROOT . '/users/profiles/' . $safeUser . '/theme.json';
    if (is_file($themeJson)) {
        $td = json_decode((string)@file_get_contents($themeJson), true);
        if (is_array($td) && !empty($td['theme'])) {
            $candidate = basename((string)$td['theme']);
            if (is_file(DMD_ROOT . '/theme/' . $candidate . '/style.css')) $theme = $candidate;
        }
    }
    $webRoot = preg_replace('~/modules/DMD-Contact/?$~', '', $moduleBase);
    $themeHref = ($webRoot !== '' ? $webRoot : '') . '/theme/' . rawurlencode($theme) . '/style.css';
}
foreach ($contacts as &$contact) {
    if (!empty($contact['avatar'])) {
        $contact['avatar_url'] = $moduleBase . '/contact_media.php?owner=' . rawurlencode((string)$contact['owner_email']) . '&id=' . rawurlencode((string)$contact['id']);
    } else {
        $contact['avatar_url'] = '';
    }
}
unset($contact);

$cssFile = __DIR__ . '/contact.css';
$cssHref = $moduleBase . '/contact.css' . (is_file($cssFile) ? '?v=' . filemtime($cssFile) : '');
$myDeskCssFile = __DIR__ . '/contact-mydesk.css';
$myDeskCssHref = $moduleBase . '/contact-mydesk.css' . (is_file($myDeskCssFile) ? '?v=' . filemtime($myDeskCssFile) : '');
$letters = array('Tous','#','AB','CD','EF','GH','IJ','KL','MN','OP','QR','ST','UV','WX','YZ');
$contactJson = json_encode($contacts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
$contactUsersJson = json_encode($availableUsers, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
$contactRolesJson = json_encode($availableRoles, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
?>
<?php if ($myDeskFull): ?>
<link rel="stylesheet" href="<?= contact_h($themeHref) ?>">
<link rel="stylesheet" href="<?= contact_h($myDeskCssHref) ?>">
<script>
(() => {
  function sourceWindow(){
    const candidates=[];
    try { if(window.opener && !window.opener.closed) candidates.push(window.opener); } catch(_){}
    try { if(window.parent && window.parent!==window) candidates.push(window.parent); } catch(_){}
    for(const candidate of candidates){ try { if(candidate.document && candidate.location.origin===window.location.origin) return candidate; } catch(_){} }
    return null;
  }
  function syncTheme(){
    const source=sourceWindow();
    if(source){
      const names=['--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg','--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft','--border-color','--danger-color','--success-color','--warning-color','--shadow-color','--radius-sm','--radius','--radius-lg','--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow','--dmdm-input-bg'];
      const targets=[document.documentElement,document.body].filter(Boolean);
      [source.document.documentElement,source.document.body].filter(Boolean).forEach(sr=>{ const cs=source.getComputedStyle(sr); names.forEach(name=>{const value=cs.getPropertyValue(name);if(value&&value.trim())targets.forEach(t=>t.style.setProperty(name,value.trim()));}); });
      try { const bs=source.getComputedStyle(source.document.body); targets.forEach(t=>t.style.fontFamily=bs.fontFamily||''); } catch(_){}
    }
    document.documentElement.classList.add('dmd-contact-full-host');
    if(document.body) document.body.classList.add('dmd-contact-full-host');
  }
  syncTheme(); window.addEventListener('load',syncTheme,{once:true});
})();
</script>
<div class="dmd-contact-fullbar"><strong>👤 DMD-Contact · version complète</strong><button type="button" onclick="try{window.close()}catch(e){}">Fermer</button></div>
<?php endif; ?>
<link rel="stylesheet" href="<?= contact_h($cssHref) ?>">

<div class="contact-app" id="contactApp" data-dmd-module="DMD-Contact" data-dmd-resource-provider="contact">
  <div class="contact-toolbar">
    <input class="contact-search" id="contactSearch" type="search" placeholder="Rechercher nom, société, email, téléphone, ville...">
    <select class="contact-filter" id="contactScopeFilter" aria-label="Filtrer les contacts">
      <option value="all">Tous</option>
      <option value="private">Privé</option>
      <option value="pro">Pro</option>
      <option value="client">Clients</option>
      <option value="fournisseur">Fournisseurs</option>
      <option value="prospect">Prospects</option>
    </select>
    <button type="button" class="contact-btn ghost contact-print-all" id="contactPrintBtn">Imprimer</button>
    <?php if ($canExport): ?>
    <button type="button" class="contact-btn ghost" id="contactExportBtn">Exporter</button>
    <?php endif; ?>
    <?php if ($canCreate): ?><button type="button" class="contact-btn primary" id="contactNewBtn">+ Contact</button><?php endif; ?>
  </div>

  <div class="contact-layout">
    <nav class="contact-az" aria-label="Index alphabétique">
      <?php foreach ($letters as $i => $letter): ?>
        <button type="button" class="<?= $i === 0 ? 'active' : '' ?>" data-letter="<?= contact_h($letter) ?>"><?= contact_h($letter) ?></button>
      <?php endforeach; ?>
    </nav>

    <div class="contact-directory">
      <div class="contact-directory-head" aria-hidden="true">
        <span></span><span>Nom / prénom</span><span>Société</span><span>Email</span><span>Téléphone</span><span></span>
      </div>
      <div class="contact-list" id="contactList">
        <?php
        $currentLetter = null;
        foreach ($contacts as $c):
          $letter = $c['letter'];
          if ($letter !== $currentLetter):
            $currentLetter = $letter;
        ?>
          <div class="contact-letter" data-letter-title="<?= contact_h($letter) ?>"><?= contact_h($letter) ?></div>
        <?php endif; ?>
          <div class="contact-row"
               role="button"
               tabindex="0"
               data-contact-uid="<?= contact_h($c['uid']) ?>"
               data-contact-id="<?= contact_h($c['id']) ?>"
               data-owner-email="<?= contact_h($c['owner_email']) ?>"
               data-dmd-module="DMD-Contact"
               data-dmd-resource-type="contact"
               data-dmd-resource-id="<?= contact_h($c['uid']) ?>"
               data-dmd-resource-name="<?= contact_h($c['display_name']) ?>"
               data-dmd-resource-owner="<?= contact_h($c['owner_email']) ?>"
               data-resource-type="contact"
               data-resource-id="<?= contact_h($c['uid']) ?>"
               data-resource-name="<?= contact_h($c['display_name']) ?>"
               data-letter="<?= contact_h($letter) ?>"
               data-search="<?= contact_h(contact_lower(json_encode($c, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE))) ?>">
            <span>
              <?php if ($c['avatar_url']): ?>
                <img class="contact-avatar" src="<?= contact_h($c['avatar_url']) ?>" alt="">
              <?php else: ?>
                <span class="contact-initials"><?= contact_h($c['initials']) ?></span>
              <?php endif; ?>
            </span>
            <span>
              <span class="contact-main-name"><?= contact_h($c['display_name']) ?></span>
              <span class="contact-main-sub"><?= contact_h($c['poste'] ?: $c['relation_private'] ?: $c['relation_pro'] ?: $c['surnom']) ?></span>
            </span>
            <span class="contact-company contact-muted"><?= contact_h($c['entreprise'] ?: '—') ?></span>
            <span class="contact-muted"><?= contact_h($c['mail'] ?: $c['mail2'] ?: '—') ?></span>
            <span class="contact-phone contact-muted"><?= contact_h($c['tel'] ?: $c['tel2'] ?: '—') ?></span>
            <span class="contact-actions">
              <?php if (!empty($c['is_owner'])): ?>
                <?php if ($canEdit): ?><button class="contact-iconbtn contact-edit" type="button" title="Modifier" data-contact-uid="<?= contact_h($c['uid']) ?>" data-contact-id="<?= contact_h($c['id']) ?>">✎</button><?php endif; ?>
                <?php if ($canDelete): ?><button class="contact-iconbtn contact-delete" type="button" title="Supprimer" data-contact-uid="<?= contact_h($c['uid']) ?>" data-contact-id="<?= contact_h($c['id']) ?>">×</button><?php endif; ?>
              <?php else: ?>
                <span class="contact-shared-lock" title="Contact partagé en lecture seule">↗</span>
              <?php endif; ?>
            </span>
          </div>
        <?php endforeach; ?>
        <?php if (empty($contacts)): ?>
          <div class="contact-empty">Aucun contact pour l’instant.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script>
window.DMD_CONTACTS = <?= $contactJson ?: '[]' ?>;
window.DMD_CONTACT_USERS = <?= $contactUsersJson ?: '[]' ?>;
window.DMD_CONTACT_ROLES = <?= $contactRolesJson ?: '[]' ?>;
window.DMD_CONTACT_CSRF = <?= json_encode($csrfContact) ?>;
window.DMD_CONTACT_RIGHTS = <?= json_encode(array('create'=>$canCreate,'edit'=>$canEdit,'delete'=>$canDelete,'share'=>$canShare,'export'=>$canExport)) ?>;
window.DMD_CONTACT_MODULE_BASE = <?= json_encode($moduleBase, JSON_UNESCAPED_SLASHES) ?>;
(()=>{
  const moduleBase = String(window.DMD_CONTACT_MODULE_BASE || 'modules/DMD-Contact').replace(/\/$/, '');
  const contacts = Array.isArray(window.DMD_CONTACTS) ? window.DMD_CONTACTS : [];
  const shareUsers = Array.isArray(window.DMD_CONTACT_USERS) ? window.DMD_CONTACT_USERS : [];
  const shareRoles = Array.isArray(window.DMD_CONTACT_ROLES) ? window.DMD_CONTACT_ROLES : [];
  const byUid = new Map(contacts.map(c => [String(c.uid || (String(c.owner_email||'') + '|' + String(c.id||''))), c]));
  const list = document.getElementById('contactList');
  const search = document.getElementById('contactSearch');
  const scopeFilter = document.getElementById('contactScopeFilter');
  const az = document.querySelector('.contact-az');
  const newBtn = document.getElementById('contactNewBtn');
  const rights = window.DMD_CONTACT_RIGHTS || {};
  const csrfToken = String(window.DMD_CONTACT_CSRF || '');
  const printBtn = document.getElementById('contactPrintBtn');
  const exportBtn = document.getElementById('contactExportBtn');
  let activeLetter = 'Tous';
  let zTop = 4000;

  const esc = (v)=>String(v ?? '').replace(/[&<>'"]/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[s]));
  const fullName = (c)=>String(c.display_name || [c.prenom,c.nom].filter(Boolean).join(' ') || c.entreprise || '(Sans nom)');
  const telHref = (v)=>String(v || '').replace(/[^0-9+]/g,'');
  const normalize = (v)=>String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  const letterMatches = (active, letter)=>{
    active = String(active || 'Tous');
    letter = String(letter || '#').toUpperCase();
    if(active === 'Tous') return true;
    if(active === '#') return letter === '#';
    return active.toUpperCase().includes(letter);
  };

  function field(c, key){ return c && c[key] ? String(c[key]) : ''; }
  function info(label, value, wide=false){
    return `<div class="contact-info ${wide?'wide':''}"><label>${esc(label)}</label><div>${value ? esc(value) : '—'}</div></div>`;
  }
  function linkInfo(label, value, hrefPrefix='', wide=false){
    const v = String(value || '');
    const href = hrefPrefix === 'tel:' ? hrefPrefix + telHref(v) : hrefPrefix + v;
    return `<div class="contact-info ${wide?'wide':''}"><label>${esc(label)}</label><div>${v ? `<a href="${esc(href)}">${esc(v)}</a>` : '—'}</div></div>`;
  }
  function avatarHtml(c, big=false){
    if(c.avatar_url) return `<img class="contact-avatar" src="${esc(c.avatar_url)}" alt="">`;
    return `<span class="contact-initials">${esc(c.initials || '?')}</span>`;
  }
  function badges(c){
    const out = [];
    if(c.is_private) out.push('<span class="contact-badge">Privé</span>');
    if(c.is_pro) out.push('<span class="contact-badge">Pro</span>');
    if(c.relation_pro) out.push(`<span class="contact-badge">${esc(c.relation_pro)}</span>`);
    if(c.relation_private) out.push(`<span class="contact-badge">${esc(c.relation_private)}</span>`);
    return out.join('');
  }


  function printableCard(c){
    const name = fullName(c);
    const lines = [
      ['Prénom', c.prenom],
      ['Nom', c.nom],
      ['Civilité', c.civilite],
      ['Surnom', c.surnom],
      ['Privé', c.is_private ? 'Oui' : 'Non'], ['Pro', c.is_pro ? 'Oui' : 'Non'],
      ['Type privé', c.relation_private], ['Type pro', c.relation_pro],
      ['Entreprise', c.entreprise], ['Poste / fonction', c.poste], ['Service', c.service], ['SIRET', c.siret],
      ['Email principal', c.mail], ['Email secondaire', c.mail2],
      ['Téléphone', c.tel], ['Téléphone 2', c.tel2],
      ['Adresse', [c.adresse,c.code_postal,c.ville,c.pays].filter(Boolean).join(' ')],
      ['Date de naissance', c.date_naissance], ['Situation familiale', c.statut_familial],
      ['Site web', c.site_web], ['LinkedIn', c.linkedin],
      ['Tags', c.tags], ['Notes', c.notes]
    ];
    const photo = c.avatar_url
      ? `<img class="print-contact-photo" src="${esc(c.avatar_url)}" alt="Photo de ${esc(name)}">`
      : `<span class="print-contact-initials">${esc(c.initials || '?')}</span>`;
    return `<section class="print-contact">
      <div class="print-contact-head">
        ${photo}
        <div><h2>${esc(name)}</h2>${c.entreprise ? `<p class="print-sub">${esc(c.entreprise)}</p>` : ''}</div>
      </div>
      <table>${lines.map(([label,value])=>`<tr><th>${esc(label)}</th><td>${esc(value || '—')}</td></tr>`).join('')}</table>
    </section>`;
  }
  function printContacts(items, title='Contacts DoMyDesk'){
    const selected = Array.isArray(items) ? items.filter(Boolean) : [];
    const rows = selected.length ? selected.map(printableCard).join('') : '<section class="print-contact"><h2>Aucun contact à imprimer</h2><p class="print-sub">Aucun contact ne correspond à la sélection actuelle.</p></section>';
    let zone = document.getElementById('contactPrintArea');
    if(!zone){
      zone = document.createElement('div');
      zone.id = 'contactPrintArea';
      zone.className = 'contact-print-area';
      document.body.appendChild(zone);
    }
    zone.innerHTML = `<h1>${esc(title)}</h1>${rows}`;
    document.body.classList.add('contact-printing');

    const cleanup = ()=>{
      document.body.classList.remove('contact-printing');
      zone.innerHTML = '';
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup);

    const images = Array.from(zone.querySelectorAll('img'));
    const ready = images.map(img => img.complete
      ? Promise.resolve()
      : new Promise(resolve => {
          img.addEventListener('load', resolve, {once:true});
          img.addEventListener('error', resolve, {once:true});
          setTimeout(resolve, 1500);
        }));
    Promise.all(ready).then(()=>setTimeout(()=>{
      window.print();
      setTimeout(cleanup, 1200);
    }, 80));
  }

  function getVisibleContacts(){
    return Array.from(document.querySelectorAll('.contact-row'))
      .filter(row => !row.classList.contains('contact-filter-hidden'))
      .map(row => byUid.get(row.dataset.contactUid))
      .filter(Boolean);
  }

  function viewportSize(){
    return {
      w: Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0),
      h: Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0)
    };
  }
  function pageScroll(){
    return {
      x: window.pageXOffset || document.documentElement.scrollLeft || 0,
      y: window.pageYOffset || document.documentElement.scrollTop || 0
    };
  }
  function bring(win){
    if(!win) return;
    win.style.zIndex = ++zTop;
  }
  function getScrollPad(){
    let pad = document.getElementById('contact-scroll-pad');
    if(!pad){
      pad = document.createElement('div');
      pad.id = 'contact-scroll-pad';
      pad.setAttribute('aria-hidden','true');
      document.body.appendChild(pad);
    }
    return pad;
  }
  function updatePageScrollBounds(){
    const pad = getScrollPad();
    pad.style.width = '1px';
    pad.style.height = '1px';
    const vp = viewportSize();
    let neededW = vp.w;
    let neededH = vp.h;
    document.querySelectorAll('.contact-window').forEach(function(win){
      const left = parseInt(win.style.left || win.offsetLeft || 0, 10) || 0;
      const top = parseInt(win.style.top || win.offsetTop || 0, 10) || 0;
      neededW = Math.max(neededW, left + win.offsetWidth + 90);
      neededH = Math.max(neededH, top + win.offsetHeight + 90);
    });
    pad.style.width = Math.max(1, neededW) + 'px';
    pad.style.height = Math.max(1, neededH) + 'px';
  }
  function autoScrollWhileDragging(clientX, clientY){
    const margin = 34;
    const step = 28;
    const vp = viewportSize();
    let dx = 0;
    let dy = 0;
    if(clientX > vp.w - margin) dx = step;
    if(clientY > vp.h - margin) dy = step;
    if(clientX < margin) dx = -step;
    if(clientY < margin) dy = -step;
    if(dx || dy) window.scrollBy(dx, dy);
  }
  function fitWindowForMobile(win){
    const vp = viewportSize();
    if(vp.w > 760) return;
    const sc = pageScroll();
    win.style.width = Math.max(260, vp.w - 16) + 'px';
    win.style.height = Math.max(300, vp.h - 90) + 'px';
    win.style.left = (sc.x + 8) + 'px';
    win.style.top = (sc.y + 8) + 'px';
  }
  function makeMovable(win, handle){
    let dragging = false;
    let pointerId = null;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;

    handle.addEventListener('pointerdown', function(e){
      if(e.target.closest('button,a,input,select,textarea,label')) return;
      if(e.pointerType === 'mouse' && e.button !== 0) return;
      dragging = true;
      pointerId = e.pointerId;
      bring(win);
      startX = e.pageX;
      startY = e.pageY;
      startLeft = parseInt(win.style.left || win.offsetLeft || 0, 10) || 0;
      startTop = parseInt(win.style.top || win.offsetTop || 0, 10) || 0;
      try { handle.setPointerCapture(pointerId); } catch(_) {}
      e.preventDefault();
    });

    handle.addEventListener('pointermove', function(e){
      if(!dragging || e.pointerId !== pointerId) return;
      const left = Math.max(8, startLeft + (e.pageX - startX));
      const top = Math.max(8, startTop + (e.pageY - startY));
      win.style.left = left + 'px';
      win.style.top = top + 'px';
      updatePageScrollBounds();
      autoScrollWhileDragging(e.clientX, e.clientY);
      e.preventDefault();
    });

    const stop = function(e){
      if(!dragging || (e && e.pointerId !== pointerId)) return;
      dragging = false;
      try { handle.releasePointerCapture(pointerId); } catch(_) {}
      pointerId = null;
      updatePageScrollBounds();
    };
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
    win.addEventListener('pointerdown', function(){ bring(win); }, true);
  }
  function makeResizable(win, handle){
    let resizing = false;
    let pointerId = null;
    let startX = 0;
    let startY = 0;
    let startW = 0;
    let startH = 0;

    handle.addEventListener('pointerdown', function(e){
      if(e.pointerType === 'mouse' && e.button !== 0) return;
      resizing = true;
      pointerId = e.pointerId;
      bring(win);
      startX = e.pageX;
      startY = e.pageY;
      startW = win.offsetWidth;
      startH = win.offsetHeight;
      try { handle.setPointerCapture(pointerId); } catch(_) {}
      e.preventDefault();
      e.stopPropagation();
    });
    handle.addEventListener('pointermove', function(e){
      if(!resizing || e.pointerId !== pointerId) return;
      win.style.width = Math.max(330, startW + (e.pageX - startX)) + 'px';
      win.style.height = Math.max(250, startH + (e.pageY - startY)) + 'px';
      updatePageScrollBounds();
      autoScrollWhileDragging(e.clientX, e.clientY);
      e.preventDefault();
    });
    const stop = function(e){
      if(!resizing || (e && e.pointerId !== pointerId)) return;
      resizing = false;
      try { handle.releasePointerCapture(pointerId); } catch(_) {}
      pointerId = null;
      updatePageScrollBounds();
    };
    handle.addEventListener('pointerup', stop);
    handle.addEventListener('pointercancel', stop);
  }
  function decorateResource(el, c){
    if(!el || !c) return;
    const rid = String(c.uid || c.id || '');
    if(!rid) return;
    const name = fullName(c);
    el.dataset.dmdModule = 'DMD-Contact';
    el.dataset.dmdResourceType = 'contact';
    el.dataset.dmdResourceId = rid;
    el.dataset.dmdResourceName = name;
    el.dataset.dmdResourceOwner = String(c.owner_email || '');
    el.dataset.resourceType = 'contact';
    el.dataset.resourceId = rid;
    el.dataset.resourceName = name;
    if(window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function'){
      try { window.DMDActionHub.decorate(el); } catch(_) {}
    }
  }

  function windowBase(title, subtitle, left=90, top=80){
    const win = document.createElement('div');
    const sc = pageScroll();
    win.className = 'contact-window';
    win.style.width = '760px';
    win.style.height = '620px';
    win.style.left = (sc.x + Math.max(8, left)) + 'px';
    win.style.top = (sc.y + Math.max(8, top)) + 'px';
    win.style.zIndex = ++zTop;
    win.innerHTML = `<div class="contact-window-head">
      <div class="contact-window-title"><strong>${esc(title)}</strong><span class="contact-main-sub">${esc(subtitle || '')}</span></div>
      <div class="contact-window-tools"></div>
      <button type="button" class="contact-window-close" title="Fermer">×</button>
    </div><div class="contact-window-body"></div><span class="contact-window-resize" title="Redimensionner"></span>`;
    document.body.appendChild(win);
    fitWindowForMobile(win);
    win.querySelector('.contact-window-close').addEventListener('click',()=>{
      win.remove();
      updatePageScrollBounds();
    });
    makeMovable(win, win.querySelector('.contact-window-head'));
    makeResizable(win, win.querySelector('.contact-window-resize'));
    updatePageScrollBounds();
    return win;
  }

  function openDetail(c, anchor){
    const r = anchor ? anchor.getBoundingClientRect() : {left:90, bottom:80};
    const win = windowBase(fullName(c), c.entreprise || c.mail || '', r.left + 18, r.bottom + 8);
    const tools = win.querySelector('.contact-window-tools');
    tools.innerHTML = `<button type="button" class="contact-btn ghost contact-print-one">Imprimer</button>
                       ${rights.export ? `<button type="button" class="contact-btn ghost contact-export-one">Exporter</button>` : ''}
                       ${c.is_owner && rights.edit ? `<button type="button" class="contact-btn ghost contact-edit-one">Modifier</button>` : ''}
                       ${!c.is_owner ? `<span class="contact-shared-note">Partagé par ${esc(c.owner_email || '')}</span>` : ''}`;
    tools.querySelector('.contact-print-one').addEventListener('click',()=>printContacts([c]));
    const exportOne = tools.querySelector('.contact-export-one');
    if(exportOne) exportOne.addEventListener('click',()=>openExport(c, r.left + 44, r.bottom + 34));
    const editOne = tools.querySelector('.contact-edit-one');
    if(editOne) editOne.addEventListener('click',()=>openForm(c, r.left + 44, r.bottom + 34));
    win.querySelector('.contact-window-body').innerHTML = `
      <div class="contact-profile-top">
        <div>${avatarHtml(c,true)}</div>
        <div>
          <h3 class="contact-profile-name">${esc(fullName(c))}</h3>
          <div class="contact-badgebar">${badges(c)}</div>
          <div class="contact-main-sub">${esc([c.poste,c.service,c.entreprise].filter(Boolean).join(' • '))}</div>
        </div>
      </div>
      <div class="contact-info-grid">
        ${info('Civilité', c.civilite)}
        ${info('Surnom', c.surnom)}
        ${linkInfo('Email principal', c.mail, 'mailto:')}
        ${linkInfo('Email secondaire', c.mail2, 'mailto:')}
        ${linkInfo('Téléphone', c.tel, 'tel:')}
        ${linkInfo('Téléphone 2', c.tel2, 'tel:')}
        ${info('Entreprise', c.entreprise)}
        ${info('Poste / fonction', c.poste)}
        ${info('Service', c.service)}
        ${info('SIRET', c.siret)}
        ${info('Adresse', [c.adresse,c.code_postal,c.ville,c.pays].filter(Boolean).join(' '), true)}
        ${info('Date de naissance', c.date_naissance)}
        ${info('Situation familiale', c.statut_familial)}
        ${linkInfo('Site web', c.site_web, '')}
        ${linkInfo('LinkedIn', c.linkedin, '')}
        ${info('Tags', c.tags, true)}
        ${info('Notes', c.notes, true)}
      </div>`;
    decorateResource(win, c);
  }

  function openExport(c=null, left=120, top=90){
    if(!rights.export) return;
    const one = !!(c && c.id);
    const title = one ? 'Export PDF' : 'Export PDF des contacts';
    const subtitle = one ? fullName(c) : 'Contacts accessibles';
    const win = windowBase(title, subtitle, left, top);
    win.classList.add('contact-export-window');
    if(viewportSize().w > 760){
      win.style.width = '960px';
      win.style.height = '700px';
    } else {
      fitWindowForMobile(win);
    }

    const id = one ? String(c.id || '') : '';
    const owner = one ? String(c.owner_email || '') : '';
    const query = new URLSearchParams();
    if(id) query.set('id', id);
    if(owner) query.set('owner', owner);
    const qs = query.toString();
    const pdfBaseUrl = moduleBase + '/contact_exportpdf.php' + (qs ? '?' + qs : '');
    const pdfPreviewUrl = pdfBaseUrl + '#zoom=page-width&view=FitH';
    const pdfDownloadUrl = pdfBaseUrl + (qs ? '&' : '?') + 'download=1';
    const recipientOptions = shareUsers.map(u=>`<option value="${esc(u.email || '')}">${esc(u.label || u.email || '')}${u.role_metier ? ' — ' + esc(u.role_metier) : ''}</option>`).join('');
    const canSend = !!rights.share && shareUsers.length > 0;

    win.querySelector('.contact-window-body').innerHTML = `
      <div class="contact-export-layout">
        <div class="contact-export-toolbar">
          <div class="contact-export-toolbar-group">
            <strong>PDF</strong>
            <button type="button" class="contact-btn primary" data-export-download-pdf>PC</button>
            <button type="button" class="contact-btn ghost" data-export-save-pdf>Dossier DoMyDesk</button>
          </div>

          ${canSend ? `
          <div class="contact-export-toolbar-group contact-export-send-group">
            <strong>Destinataire</strong>
            <select class="contact-select" data-export-recipient>
              <option value="">Choisir un utilisateur…</option>${recipientOptions}
            </select>
            <button type="button" class="contact-btn ghost" data-export-share-pdf>Partager PDF</button>
            <button type="button" class="contact-btn primary" data-export-contact>Envoyer au module Contact</button>
          </div>
          <div class="contact-export-toolbar-group">
            <strong>CSV</strong>
            <button type="button" class="contact-btn ghost" data-export-save-csv>Dossier DoMyDesk</button>
            <button type="button" class="contact-btn ghost" data-export-share-csv>Partager CSV</button>
          </div>` : `
          <div class="contact-export-toolbar-group">
            <strong>CSV</strong>
            <button type="button" class="contact-btn ghost" data-export-save-csv>Dossier DoMyDesk</button>
          </div>`}
        </div>

        <div class="contact-export-status" data-export-status aria-live="polite"></div>
        <iframe class="contact-export-pdf-frame" title="Aperçu PDF" src="${esc(pdfPreviewUrl)}"></iframe>
      </div>`;

    const frame = win.querySelector('.contact-export-pdf-frame');
    const status = win.querySelector('[data-export-status]');
    const recipient = win.querySelector('[data-export-recipient]');

    function setExportStatus(text, isError=false){
      if(!status) return;
      status.textContent = text || '';
      status.dataset.error = isError ? '1' : '0';
      status.hidden = !text;
    }
    function triggerDownload(url){
      const holder = document.createElement('iframe');
      holder.className = 'contact-export-download-frame';
      holder.setAttribute('aria-hidden','true');
      holder.src = url;
      document.body.appendChild(holder);
      setTimeout(()=>holder.remove(), 45000);
    }
    async function exportAction(action){
      const fd = new FormData();
      fd.set('action', action);
      fd.set('csrf_token', csrfToken);
      if(id) fd.set('id', id);
      if(owner) fd.set('owner', owner);
      if(action.includes('share') || action === 'export_to_contact'){
        const target = recipient ? String(recipient.value || '') : '';
        if(!target){ setExportStatus('Choisis un utilisateur destinataire.', true); return; }
        fd.set('recipient', target);
      }
      setExportStatus('Traitement en cours…');
      try{
        const r = await fetch(moduleBase + '/contact_process.php', {method:'POST', body:fd, credentials:'same-origin'});
        const j = await r.json().catch(()=>({ok:false,message:'Réponse invalide du module.'}));
        if(!r.ok || !j.ok) throw new Error(j.message || j.error || ('HTTP ' + r.status));
        setExportStatus(j.message || 'Terminé.');
      }catch(err){
        setExportStatus('Erreur : ' + (err && err.message ? err.message : String(err)), true);
      }
    }

    const dlPdf = win.querySelector('[data-export-download-pdf]');
    if(dlPdf) dlPdf.addEventListener('click',()=>triggerDownload(pdfDownloadUrl));
    const savePdf = win.querySelector('[data-export-save-pdf]');
    if(savePdf) savePdf.addEventListener('click',()=>exportAction('export_save_pdf'));
    const saveCsv = win.querySelector('[data-export-save-csv]');
    if(saveCsv) saveCsv.addEventListener('click',()=>exportAction('export_save_csv'));
    const sharePdf = win.querySelector('[data-export-share-pdf]');
    if(sharePdf) sharePdf.addEventListener('click',()=>exportAction('export_share_pdf'));
    const shareCsv = win.querySelector('[data-export-share-csv]');
    if(shareCsv) shareCsv.addEventListener('click',()=>exportAction('export_share_csv'));
    const sendContact = win.querySelector('[data-export-contact]');
    if(sendContact) sendContact.addEventListener('click',()=>exportAction('export_to_contact'));

    if(one) decorateResource(win, c);
    updatePageScrollBounds();
  }

  function shareKey(value){ return normalize(value); }

  function initSharePickers(form, c){
    const selectedUsers = new Map();
    (c.shared_with || []).forEach(email=>{
      const found = shareUsers.find(u => shareKey(u.email) === shareKey(email));
      selectedUsers.set(shareKey(email), found || {email:String(email), label:String(email), role_metier:''});
    });

    const selectedRoles = new Set((c.shared_roles || []).map(String));
    const userPicker = form.querySelector('[data-share-picker="users"]');
    const rolePicker = form.querySelector('[data-share-picker="roles"]');

    const userLimit = 24;
    const roleLimit = 30;

    function userLabel(u){
      return String(u.label || u.email || '').trim() || '(Sans nom)';
    }
    function userMeta(u){
      return [u.email || '', u.role_metier || ''].filter(Boolean).join(' • ');
    }
    function userMatches(u, q){
      if(!q) return true;
      return normalize(`${u.label || ''} ${u.email || ''} ${u.role_metier || ''}`).includes(q);
    }
    function roleMatches(r, q){
      return !q || normalize(r).includes(q);
    }

    function renderUsers(){
      const selectedBox = userPicker.querySelector('[data-share-selected="users"]');
      const hiddenBox = userPicker.querySelector('[data-share-hidden="users"]');
      const resultsBox = userPicker.querySelector('[data-share-results="users"]');
      const countBox = userPicker.querySelector('[data-share-count="users"]');
      const q = normalize(userPicker.querySelector('.contact-share-search').value);
      const selected = Array.from(selectedUsers.values());

      countBox.textContent = selected.length ? `${selected.length} sélectionné(s)` : 'Aucun sélectionné';
      selectedBox.innerHTML = selected.length
        ? selected.map(u=>`<button type="button" class="contact-share-chip" data-remove-user="${esc(u.email)}" title="Retirer"><span>${esc(userLabel(u))}</span><small>${esc(userMeta(u))}</small><b>×</b></button>`).join('')
        : '<em>Aucun utilisateur sélectionné.</em>';
      hiddenBox.innerHTML = selected.map(u=>`<input type="hidden" name="shared_with[]" value="${esc(u.email)}">`).join('');

      if(!shareUsers.length){
        resultsBox.innerHTML = '<em>Aucun autre utilisateur inscrit sur le serveur.</em>';
        return;
      }

      const matchesAll = shareUsers
        .filter(u=>!selectedUsers.has(shareKey(u.email)))
        .filter(u=>userMatches(u, q));
      const matches = matchesAll.slice(0, userLimit);
      const intro = q
        ? `<div class="contact-share-helper">${matchesAll.length} résultat(s) pour la recherche.</div>`
        : `<div class="contact-share-helper">${shareUsers.length > userLimit ? `Affichage des ${userLimit} premiers utilisateurs. Utilise la recherche pour affiner.` : 'Utilisateurs disponibles.'}</div>`;

      resultsBox.innerHTML = matches.length
        ? intro + `<button type="button" class="contact-share-add-visible" data-add-visible-users>Ajouter les résultats visibles</button>` + matches.map(u=>`<button type="button" class="contact-share-result" data-add-user="${esc(u.email)}"><span>${esc(userLabel(u))}</span><small>${esc(userMeta(u))}</small></button>`).join('')
        : '<em>Aucun utilisateur ne correspond à cette recherche. Le partage se fait uniquement vers les utilisateurs inscrits.</em>';
    }

    function renderRoles(){
      const selectedBox = rolePicker.querySelector('[data-share-selected="roles"]');
      const hiddenBox = rolePicker.querySelector('[data-share-hidden="roles"]');
      const resultsBox = rolePicker.querySelector('[data-share-results="roles"]');
      const countBox = rolePicker.querySelector('[data-share-count="roles"]');
      const q = normalize(rolePicker.querySelector('.contact-share-search').value);
      const selected = Array.from(selectedRoles.values());

      countBox.textContent = selected.length ? `${selected.length} sélectionné(s)` : 'Aucun sélectionné';
      selectedBox.innerHTML = selected.length
        ? selected.map(r=>`<button type="button" class="contact-share-chip" data-remove-role="${esc(r)}" title="Retirer"><span>${esc(r)}</span><b>×</b></button>`).join('')
        : '<em>Aucun rôle sélectionné.</em>';
      hiddenBox.innerHTML = selected.map(r=>`<input type="hidden" name="shared_roles[]" value="${esc(r)}">`).join('');

      const matchesAll = shareRoles
        .filter(r=>!selectedRoles.has(r))
        .filter(r=>roleMatches(r, q));
      const matches = matchesAll.slice(0, roleLimit);
      resultsBox.innerHTML = matches.length
        ? `<button type="button" class="contact-share-add-visible" data-add-visible-roles>Ajouter les rôles visibles</button>` + matches.map(r=>`<button type="button" class="contact-share-result" data-add-role="${esc(r)}"><span>${esc(r)}</span></button>`).join('')
        : '<em>Aucun rôle disponible.</em>';
    }

    userPicker.addEventListener('input', e=>{ if(e.target.matches('.contact-share-search')) renderUsers(); });
    rolePicker.addEventListener('input', e=>{ if(e.target.matches('.contact-share-search')) renderRoles(); });

    userPicker.addEventListener('click', e=>{
      const add = e.target.closest('[data-add-user]');
      const remove = e.target.closest('[data-remove-user]');
      const addVisible = e.target.closest('[data-add-visible-users]');
      if(add){
        const u = shareUsers.find(x=>shareKey(x.email) === shareKey(add.dataset.addUser));
        if(u) selectedUsers.set(shareKey(u.email), u);
        renderUsers();
      }
      if(remove){ selectedUsers.delete(shareKey(remove.dataset.removeUser)); renderUsers(); }
      if(addVisible){
        userPicker.querySelectorAll('[data-add-user]').forEach(btn=>{
          const u = shareUsers.find(x=>shareKey(x.email) === shareKey(btn.dataset.addUser));
          if(u) selectedUsers.set(shareKey(u.email), u);
        });
        renderUsers();
      }
    });

    rolePicker.addEventListener('click', e=>{
      const add = e.target.closest('[data-add-role]');
      const remove = e.target.closest('[data-remove-role]');
      const addVisible = e.target.closest('[data-add-visible-roles]');
      if(add){ selectedRoles.add(add.dataset.addRole); renderRoles(); }
      if(remove){ selectedRoles.delete(remove.dataset.removeRole); renderRoles(); }
      if(addVisible){
        rolePicker.querySelectorAll('[data-add-role]').forEach(btn=>selectedRoles.add(btn.dataset.addRole));
        renderRoles();
      }
    });

    renderUsers();
    renderRoles();
  }

  function formTemplate(c){
    const checked = (v)=>v ? 'checked' : '';
    const sel = (a,b)=>String(a||'')===String(b||'')?'selected':'';
    return `<form id="contactForm" class="contact-form-grid" enctype="multipart/form-data">
      <input type="hidden" name="action" value="save"><input type="hidden" name="csrf_token" value="${esc(csrfToken)}"><input type="hidden" name="id" value="${esc(c.id||'')}">
      <div class="contact-field"><label>Civilité</label><select class="contact-select" name="civilite"><option value=""></option><option ${sel(c.civilite,'Madame')}>Madame</option><option ${sel(c.civilite,'Monsieur')}>Monsieur</option><option ${sel(c.civilite,'Autre')}>Autre</option></select></div>
      <div class="contact-field"><label>Photo / avatar</label><input class="contact-input" type="file" name="avatar" accept="image/*"></div>
      <div class="contact-field"><label>Prénom</label><input class="contact-input" name="prenom" value="${esc(c.prenom||'')}"></div>
      <div class="contact-field"><label>Nom</label><input class="contact-input" name="nom" value="${esc(c.nom||'')}"></div>
      <div class="contact-field"><label>Surnom</label><input class="contact-input" name="surnom" value="${esc(c.surnom||'')}"></div>
      <div class="contact-field"><label>Catégorie</label><div class="contact-checks"><label><input type="checkbox" name="is_private" value="1" ${checked(c.is_private)}> Privé</label><label><input type="checkbox" name="is_pro" value="1" ${checked(c.is_pro)}> Pro</label></div></div>
      <div class="contact-field contact-private-only"><label>Type privé</label><select class="contact-select" name="relation_private"><option value=""></option><option ${sel(c.relation_private,'Famille')}>Famille</option><option ${sel(c.relation_private,'Ami')}>Ami</option><option ${sel(c.relation_private,'Connaissance')}>Connaissance</option><option ${sel(c.relation_private,'Urgence')}>Urgence</option><option ${sel(c.relation_private,'Autre')}>Autre</option></select></div>
      <div class="contact-field contact-pro-only"><label>Type pro</label><select class="contact-select" name="relation_pro"><option value=""></option><option ${sel(c.relation_pro,'Client')}>Client</option><option ${sel(c.relation_pro,'Fournisseur')}>Fournisseur</option><option ${sel(c.relation_pro,'Prospect')}>Prospect</option><option ${sel(c.relation_pro,'Partenaire')}>Partenaire</option><option ${sel(c.relation_pro,'Prestataire')}>Prestataire</option><option ${sel(c.relation_pro,'Administration')}>Administration</option><option ${sel(c.relation_pro,'Autre')}>Autre</option></select></div>
      <div class="contact-field contact-pro-only"><label>Entreprise</label><input class="contact-input" name="entreprise" value="${esc(c.entreprise||'')}"></div>
      <div class="contact-field contact-pro-only"><label>Poste / fonction</label><input class="contact-input" name="poste" value="${esc(c.poste||'')}"></div>
      <div class="contact-field contact-pro-only"><label>Service</label><input class="contact-input" name="service" value="${esc(c.service||'')}"></div>
      <div class="contact-field contact-pro-only"><label>SIRET</label><input class="contact-input" name="siret" value="${esc(c.siret||'')}"></div>
      <div class="contact-field"><label>Email principal</label><input class="contact-input" type="email" name="mail" value="${esc(c.mail||'')}"></div>
      <div class="contact-field"><label>Email secondaire</label><input class="contact-input" type="email" name="mail2" value="${esc(c.mail2||'')}"></div>
      <div class="contact-field"><label>Téléphone</label><input class="contact-input" name="tel" value="${esc(c.tel||'')}"></div>
      <div class="contact-field"><label>Téléphone 2</label><input class="contact-input" name="tel2" value="${esc(c.tel2||'')}"></div>
      <div class="contact-field wide"><label>Adresse postale</label><input class="contact-input" name="adresse" value="${esc(c.adresse||'')}"></div>
      <div class="contact-field"><label>Code postal</label><input class="contact-input" name="code_postal" value="${esc(c.code_postal||'')}"></div>
      <div class="contact-field"><label>Ville</label><input class="contact-input" name="ville" value="${esc(c.ville||'')}"></div>
      <div class="contact-field"><label>Pays</label><input class="contact-input" name="pays" value="${esc(c.pays||'')}"></div>
      <div class="contact-field"><label>Date de naissance</label><input class="contact-input" type="date" name="date_naissance" value="${esc(c.date_naissance||'')}"></div>
      <div class="contact-field"><label>Situation familiale</label><select class="contact-select" name="statut_familial"><option value=""></option><option ${sel(c.statut_familial,'Célibataire')}>Célibataire</option><option ${sel(c.statut_familial,'Marié(e)')}>Marié(e)</option><option ${sel(c.statut_familial,'Pacsé(e)')}>Pacsé(e)</option><option ${sel(c.statut_familial,'Divorcé(e)')}>Divorcé(e)</option><option ${sel(c.statut_familial,'Veuf/Veuve')}>Veuf/Veuve</option><option ${sel(c.statut_familial,'Autre')}>Autre</option></select></div>
      <div class="contact-field"><label>Site web</label><input class="contact-input" name="site_web" value="${esc(c.site_web||'')}"></div>
      <div class="contact-field"><label>LinkedIn</label><input class="contact-input" name="linkedin" value="${esc(c.linkedin||'')}"></div>
      <div class="contact-field wide"><label>Tags</label><input class="contact-input" name="tags" placeholder="VIP, relance, compta..." value="${esc(c.tags||'')}"></div>
      <div class="contact-field wide"><label>Notes</label><textarea class="contact-textarea" name="notes">${esc(c.notes||'')}</textarea></div>
      ${rights.share ? `<div class="contact-field wide contact-share-box">
        <label>Partager ce contact</label>
        <div class="contact-share-grid contact-share-grid-pro">
          <div class="contact-share-picker" data-share-picker="users">
            <div class="contact-share-title">
              <strong>Utilisateurs</strong>
              <small data-share-count="users">Aucun sélectionné</small>
            </div>
            <input class="contact-input contact-share-search" type="search" placeholder="Nom, email ou rôle..." autocomplete="off">
            <div class="contact-share-selected" data-share-selected="users"></div>
            <div class="contact-share-hidden" data-share-hidden="users"></div>
            <div class="contact-share-results" data-share-results="users"></div>
          </div>
          <div class="contact-share-picker" data-share-picker="roles">
            <div class="contact-share-title">
              <strong>Rôles métier</strong>
              <small data-share-count="roles">Aucun sélectionné</small>
            </div>
            <input class="contact-input contact-share-search" type="search" placeholder="Rechercher un rôle..." autocomplete="off">
            <div class="contact-share-selected" data-share-selected="roles"></div>
            <div class="contact-share-hidden" data-share-hidden="roles"></div>
            <div class="contact-share-results" data-share-results="roles"></div>
            <label class="contact-share-same-role"><input type="checkbox" name="share_same_role" value="1" ${c.share_same_role?'checked':''}> Tous ceux du même rôle métier</label>
          </div>
        </div>
      </div>` : ''}
      <div class="contact-field wide"><div class="contact-msg" id="contactFormMsg"></div><div class="contact-form-actions"><button type="button" class="contact-btn ghost" data-close>Annuler</button><button type="submit" class="contact-btn primary">Enregistrer</button></div></div>
    </form>`;
  }

  function refreshVisibility(form){
    const isPro = form.querySelector('[name="is_pro"]').checked;
    const isPrivate = form.querySelector('[name="is_private"]').checked;
    form.querySelectorAll('.contact-pro-only').forEach(el=>el.classList.toggle('is-hidden', !isPro));
    form.querySelectorAll('.contact-private-only').forEach(el=>el.classList.toggle('is-hidden', !isPrivate));
  }
  function openForm(c={}, left=100, top=80){
    if(c.id && (c.is_owner === false || !rights.edit)) return;
    if(!c.id && !rights.create) return;
    const win = windowBase(c.id ? 'Modifier le contact' : 'Nouveau contact', c.id ? fullName(c) : 'Fiche complète', left, top);
    win.querySelector('.contact-window-body').innerHTML = formTemplate(c);
    const form = win.querySelector('#contactForm');
    const msg = win.querySelector('#contactFormMsg');
    form.querySelector('[data-close]').addEventListener('click',()=>{ win.remove(); updatePageScrollBounds(); });
    form.querySelectorAll('[name="is_private"],[name="is_pro"]').forEach(i=>i.addEventListener('change',()=>refreshVisibility(form)));
    refreshVisibility(form);
    if(c && c.id) decorateResource(win, c);
    if(rights.share) initSharePickers(form, c);
    form.addEventListener('submit', async (e)=>{
      e.preventDefault();
      msg.textContent = 'Enregistrement...';
      const fd = new FormData(form);
      try{
        const r = await fetch(moduleBase + '/contact_process.php', {method:'POST', body:fd, credentials:'same-origin'});
        const j = await r.json().catch(()=>({ok:false,error:'Réponse JSON invalide'}));
        if(!r.ok || !j.ok) throw new Error(j.error || ('HTTP '+r.status));
        location.reload();
      }catch(err){ msg.textContent = 'Erreur : ' + err.message; }
    });
  }

  function applyFilters(){
    const q = normalize(search.value);
    const filter = scopeFilter.value;
    const rows = Array.from(document.querySelectorAll('.contact-row'));
    let visibleLetters = new Set();
    rows.forEach(row=>{
      const uid = row.dataset.contactUid;
      const c = byUid.get(uid) || {};
      const letterOk = letterMatches(activeLetter, row.dataset.letter);
      const textOk = !q || normalize(row.dataset.search).includes(q);
      let typeOk = true;
      if(filter === 'private') typeOk = !!c.is_private;
      if(filter === 'pro') typeOk = !!c.is_pro;
      if(filter === 'client') typeOk = normalize(c.relation_pro) === 'client';
      if(filter === 'fournisseur') typeOk = normalize(c.relation_pro) === 'fournisseur';
      if(filter === 'prospect') typeOk = normalize(c.relation_pro) === 'prospect';
      const ok = letterOk && textOk && typeOk;
      row.classList.toggle('contact-filter-hidden', !ok);
      row.setAttribute('aria-hidden', ok ? 'false' : 'true');
      if(ok) visibleLetters.add(row.dataset.letter);
    });
    document.querySelectorAll('.contact-letter').forEach(h=>{
      const nextRows = [];
      let n = h.nextElementSibling;
      while(n && !n.classList.contains('contact-letter')){
        if(n.classList.contains('contact-row')) nextRows.push(n);
        n = n.nextElementSibling;
      }
      const showHeader = nextRows.some(r=>!r.classList.contains('contact-filter-hidden'));
      h.classList.toggle('contact-filter-hidden', !showHeader);
      h.setAttribute('aria-hidden', showHeader ? 'false' : 'true');
    });
  }

  list.addEventListener('keydown', (e)=>{
    const row = e.target.closest('.contact-row');
    if(!row || (e.key !== 'Enter' && e.key !== ' ')) return;
    if(e.target.closest('button,a,input,select,textarea,label')) return;
    e.preventDefault();
    openDetail(byUid.get(row.dataset.contactUid) || {}, row);
  });

  list.addEventListener('click', (e)=>{
    const edit = e.target.closest('.contact-edit');
    const del = e.target.closest('.contact-delete');
    const row = e.target.closest('.contact-row');
    if(edit){ openForm(byUid.get(edit.dataset.contactUid) || {}, e.clientX || 120, e.clientY || 80); return; }
    if(del){
      const c = byUid.get(del.dataset.contactUid) || {};
      if(!confirm('Supprimer '+fullName(c)+' ?')) return;
      const fd = new FormData(); fd.append('action','delete'); fd.append('csrf_token', csrfToken); fd.append('id', c.id || del.dataset.contactId);
      fetch(moduleBase + '/contact_process.php', {method:'POST', body:fd, credentials:'same-origin'}).then(()=>location.reload());
      return;
    }
    if(row) openDetail(byUid.get(row.dataset.contactUid) || {}, row);
  });
  if(newBtn) newBtn.addEventListener('click',()=>openForm({is_private:true,is_pro:false}, 110, 85));
  if(printBtn) printBtn.addEventListener('click',()=>printContacts(getVisibleContacts(), 'Contacts affichés'));
  if(exportBtn) exportBtn.addEventListener('click',(e)=>openExport(null, e.clientX || 120, e.clientY || 90));
  search.addEventListener('input', applyFilters);
  scopeFilter.addEventListener('change', applyFilters);
  az.addEventListener('click', (e)=>{
    const b = e.target.closest('button[data-letter]');
    if(!b) return;
    activeLetter = b.dataset.letter;
    az.querySelectorAll('button').forEach(x=>x.classList.toggle('active', x === b));
    applyFilters();
  });
  if(window.DMDActionHub && typeof window.DMDActionHub.decorate === 'function') {
    try { window.DMDActionHub.decorate(document.getElementById('contactApp')); } catch(_) {}
  }
  updatePageScrollBounds();
  window.addEventListener('resize', updatePageScrollBounds);
  applyFilters();
})();
</script>
