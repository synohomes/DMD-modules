<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */


require_once __DIR__ . '/contact_lib.php';

function contact_export_value($c, $key) {
    if ($key === 'adresse_full') {
        $parts = array($c['adresse'] ?? '', $c['code_postal'] ?? '', $c['ville'] ?? '', $c['pays'] ?? '');
        $parts = array_filter($parts, function($v){ return trim((string)$v) !== ''; });
        return trim(implode(' ', $parts));
    }
    $v = $c[$key] ?? '';
    if ($key === 'is_private' || $key === 'is_pro') return !empty($v) ? 'Oui' : 'Non';
    if (is_bool($v)) return $v ? 'Oui' : 'Non';
    if (is_array($v)) return implode(', ', array_map('strval', $v));
    return trim((string)$v);
}

function contact_export_columns() {
    return array(
        'owner_email'=>'Propriétaire','civilite'=>'Civilité','prenom'=>'Prénom','nom'=>'Nom','surnom'=>'Surnom',
        'is_private'=>'Privé','is_pro'=>'Pro','relation_private'=>'Type privé','relation_pro'=>'Type pro',
        'entreprise'=>'Entreprise','poste'=>'Poste','service'=>'Service','siret'=>'SIRET','mail'=>'Email principal',
        'mail2'=>'Email secondaire','tel'=>'Téléphone','tel2'=>'Téléphone 2','adresse_full'=>'Adresse complète',
        'date_naissance'=>'Date de naissance','statut_familial'=>'Situation familiale','site_web'=>'Site web',
        'linkedin'=>'LinkedIn','tags'=>'Tags','notes'=>'Notes','created_at'=>'Créé le','updated_at'=>'Modifié le'
    );
}

function contact_export_filename($format, $id = '') {
    $ext = strtolower((string)$format) === 'csv' ? 'csv' : 'pdf';
    $safeId = preg_replace('/[^a-zA-Z0-9_-]/', '_', (string)$id);
    return $safeId !== '' ? 'contact_' . $safeId . '.' . $ext : 'contacts.' . $ext;
}

function contact_export_csv_bytes($contacts) {
    $cols = contact_export_columns();
    $fp = fopen('php://temp', 'w+b');
    if (!$fp) return '';
    fwrite($fp, "\xEF\xBB\xBF");
    fputcsv($fp, array_values($cols), ';');
    foreach ((array)$contacts as $c) {
        $row = array();
        foreach ($cols as $key => $label) $row[] = contact_export_value($c, $key);
        fputcsv($fp, $row, ';');
    }
    rewind($fp);
    $bytes = stream_get_contents($fp);
    fclose($fp);
    return is_string($bytes) ? $bytes : '';
}

function contact_pdf_clean($text) {
    $text = str_replace(array("\r\n", "\r", "\n"), ' ', (string)$text);
    $text = preg_replace('/\s+/u', ' ', $text) ?: $text;
    return trim($text);
}
function contact_pdf_winansi($text) {
    $text = str_replace('—', '-', (string)$text);
    $bytes = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text);
    if ($bytes === false) $bytes = $text;
    $out = '';
    $len = strlen($bytes);
    for ($i = 0; $i < $len; $i++) {
        $ch = $bytes[$i];
        $o = ord($ch);
        if ($ch === '(' || $ch === ')' || $ch === '\\') $out .= '\\' . $ch;
        elseif ($o < 32 || $o > 126) $out .= sprintf('\\%03o', $o);
        else $out .= $ch;
    }
    return $out;
}
function contact_pdf_text($x, $y, $text, $size = 10, $font = 'F1') {
    return "BT /$font " . (int)$size . " Tf " . sprintf('%.2F %.2F', (float)$x, (float)$y) . " Td (" . contact_pdf_winansi($text) . ") Tj ET\n";
}
function contact_pdf_line($x1, $y1, $x2, $y2) {
    return sprintf('%.2F %.2F m %.2F %.2F l S', (float)$x1, (float)$y1, (float)$x2, (float)$y2) . "\n";
}
function contact_pdf_rect($x, $y, $w, $h, $fill = false) {
    return sprintf('%.2F %.2F %.2F %.2F re %s', (float)$x, (float)$y, (float)$w, (float)$h, $fill ? 'f' : 'S') . "\n";
}
function contact_pdf_len($text) { return function_exists('mb_strlen') ? mb_strlen((string)$text, 'UTF-8') : strlen((string)$text); }
function contact_pdf_sub($text, $start, $len = null) {
    if (function_exists('mb_substr')) return mb_substr((string)$text, (int)$start, $len === null ? null : (int)$len, 'UTF-8');
    return $len === null ? substr((string)$text, (int)$start) : substr((string)$text, (int)$start, (int)$len);
}
function contact_pdf_wrap($text, $max) {
    $text = contact_pdf_clean($text);
    if ($text === '') return array('-');
    $words = preg_split('/\s+/u', $text) ?: array($text);
    $lines = array();
    $line = '';
    foreach ($words as $w) {
        if ($line === '') { $line = $w; continue; }
        if (contact_pdf_len($line . ' ' . $w) <= $max) $line .= ' ' . $w;
        else { $lines[] = $line; $line = $w; }
    }
    if ($line !== '') $lines[] = $line;
    $out = array();
    foreach ($lines as $l) {
        while (contact_pdf_len($l) > $max) { $out[] = contact_pdf_sub($l, 0, $max); $l = contact_pdf_sub($l, $max); }
        $out[] = $l;
    }
    return $out ?: array('-');
}
function contact_pdf_upper($text) { return function_exists('mb_strtoupper') ? mb_strtoupper((string)$text, 'UTF-8') : strtoupper((string)$text); }

function contact_pdf_avatar_file($c) {
    $owner = trim((string)($c['owner_email'] ?? ''));
    $avatar = basename((string)($c['avatar'] ?? ''));
    if ($owner === '' || $avatar === '') return '';
    $dir = contact_avatar_dir($owner, false);
    if ($dir === '') return '';
    $file = $dir . $avatar;
    return is_file($file) ? $file : '';
}
function contact_pdf_paeth($a, $b, $c) {
    $p = $a + $b - $c;
    $pa = abs($p - $a); $pb = abs($p - $b); $pc = abs($p - $c);
    if ($pa <= $pb && $pa <= $pc) return $a;
    return $pb <= $pc ? $b : $c;
}
function contact_pdf_png_image($bytes) {
    if (substr($bytes, 0, 8) !== "\x89PNG\r\n\x1a\n") return false;
    $pos = 8; $len = strlen($bytes); $ihdr = null; $idat = ''; $palette = ''; $trns = '';
    while ($pos + 12 <= $len) {
        $sizeA = unpack('Nn', substr($bytes, $pos, 4));
        $size = (int)($sizeA['n'] ?? 0); $pos += 4;
        $type = substr($bytes, $pos, 4); $pos += 4;
        if ($size < 0 || $pos + $size + 4 > $len) return false;
        $data = substr($bytes, $pos, $size); $pos += $size + 4;
        if ($type === 'IHDR') $ihdr = $data;
        elseif ($type === 'IDAT') $idat .= $data;
        elseif ($type === 'PLTE') $palette = $data;
        elseif ($type === 'tRNS') $trns = $data;
        elseif ($type === 'IEND') break;
    }
    if ($ihdr === null || strlen($ihdr) < 13 || $idat === '') return false;
    $wA = unpack('Nn', substr($ihdr, 0, 4)); $hA = unpack('Nn', substr($ihdr, 4, 4));
    $w = (int)($wA['n'] ?? 0); $h = (int)($hA['n'] ?? 0);
    $bit = ord($ihdr[8]); $type = ord($ihdr[9]); $compression = ord($ihdr[10]); $filterMethod = ord($ihdr[11]); $interlace = ord($ihdr[12]);
    if ($w < 1 || $h < 1 || $w * $h > 20000000 || $bit !== 8 || $compression !== 0 || $filterMethod !== 0 || $interlace !== 0) return false;
    $bppMap = array(0=>1,2=>3,3=>1,4=>2,6=>4);
    if (!isset($bppMap[$type])) return false;
    $bpp = $bppMap[$type]; $rowBytes = $w * $bpp;
    $raw = @gzuncompress($idat);
    if ($raw === false && function_exists('zlib_decode')) $raw = @zlib_decode($idat);
    if (!is_string($raw) || strlen($raw) < ($rowBytes + 1) * $h) return false;
    $offset = 0; $prev = array_fill(0, $rowBytes, 0); $rows = array();
    for ($y = 0; $y < $h; $y++) {
        $filter = ord($raw[$offset++]); $row = array();
        for ($x = 0; $x < $rowBytes; $x++) {
            $v = ord($raw[$offset++]);
            $left = $x >= $bpp ? $row[$x - $bpp] : 0;
            $up = $prev[$x];
            $upLeft = $x >= $bpp ? $prev[$x - $bpp] : 0;
            if ($filter === 1) $v = ($v + $left) & 255;
            elseif ($filter === 2) $v = ($v + $up) & 255;
            elseif ($filter === 3) $v = ($v + (int)floor(($left + $up) / 2)) & 255;
            elseif ($filter === 4) $v = ($v + contact_pdf_paeth($left, $up, $upLeft)) & 255;
            elseif ($filter !== 0) return false;
            $row[$x] = $v;
        }
        $rows[] = $row; $prev = $row;
    }
    $color = ''; $alpha = ''; $colorspace = '/DeviceRGB';
    foreach ($rows as $row) {
        if ($type === 0) {
            $colorspace = '/DeviceGray';
            foreach ($row as $v) $color .= chr($v);
        } elseif ($type === 2) {
            foreach ($row as $v) $color .= chr($v);
        } elseif ($type === 4) {
            $colorspace = '/DeviceGray';
            for ($x=0; $x<$rowBytes; $x+=2) { $color .= chr($row[$x]); $alpha .= chr($row[$x+1]); }
        } elseif ($type === 6) {
            for ($x=0; $x<$rowBytes; $x+=4) {
                $color .= chr($row[$x]) . chr($row[$x+1]) . chr($row[$x+2]);
                $alpha .= chr($row[$x+3]);
            }
        } elseif ($type === 3) {
            if ($palette === '' || strlen($palette) < 3) return false;
            for ($x=0; $x<$rowBytes; $x++) {
                $idx = $row[$x]; $pp = $idx * 3;
                if ($pp + 2 >= strlen($palette)) { $color .= "\x00\x00\x00"; }
                else $color .= $palette[$pp] . $palette[$pp+1] . $palette[$pp+2];
                if ($trns !== '') $alpha .= chr($idx < strlen($trns) ? ord($trns[$idx]) : 255);
            }
        }
    }
    return array(
        'w'=>$w,'h'=>$h,'bits'=>8,'colorspace'=>$colorspace,'filter'=>'/FlateDecode',
        'data'=>gzcompress($color, 7),'alpha'=>$alpha !== '' ? gzcompress($alpha, 7) : ''
    );
}
function contact_pdf_jpeg_image($bytes) {
    $info = @getimagesizefromstring($bytes);
    if ($info === false || (string)($info['mime'] ?? '') !== 'image/jpeg') return false;
    $channels = (int)($info['channels'] ?? 3);
    $colorspace = $channels === 1 ? '/DeviceGray' : ($channels === 4 ? '/DeviceCMYK' : '/DeviceRGB');
    return array('w'=>(int)$info[0],'h'=>(int)$info[1],'bits'=>(int)($info['bits'] ?? 8),'colorspace'=>$colorspace,'filter'=>'/DCTDecode','data'=>$bytes,'alpha'=>'');
}
function contact_pdf_image_from_file($file) {
    if ($file === '' || !is_file($file)) return false;
    $bytes = @file_get_contents($file); if (!is_string($bytes) || $bytes === '') return false;
    $info = @getimagesizefromstring($bytes); if ($info === false) return false;
    $mime = (string)($info['mime'] ?? '');
    if ($mime === 'image/jpeg') return contact_pdf_jpeg_image($bytes);
    if ($mime === 'image/png') {
        $png = contact_pdf_png_image($bytes);
        if ($png !== false) return $png;
    }
    if (function_exists('imagecreatefromstring') && function_exists('imagejpeg')) {
        $src = @imagecreatefromstring($bytes);
        if ($src !== false) {
            $sw = imagesx($src); $sh = imagesy($src);
            $max = 1200; $scale = min(1, $max / max(1, $sw), $max / max(1, $sh));
            $dw = max(1, (int)round($sw * $scale)); $dh = max(1, (int)round($sh * $scale));
            $dst = imagecreatetruecolor($dw, $dh);
            $white = imagecolorallocate($dst, 255, 255, 255); imagefill($dst, 0, 0, $white);
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $dw, $dh, $sw, $sh);
            ob_start(); imagejpeg($dst, null, 88); $jpg = ob_get_clean();
            imagedestroy($dst); imagedestroy($src);
            if (is_string($jpg) && $jpg !== '') return contact_pdf_jpeg_image($jpg);
        }
    }
    return false;
}
function contact_pdf_image_command($resource, $img, $x, $y, $boxW, $boxH) {
    $iw = max(1, (int)($img['w'] ?? 1)); $ih = max(1, (int)($img['h'] ?? 1));
    $scale = min((float)$boxW / $iw, (float)$boxH / $ih);
    $w = $iw * $scale; $h = $ih * $scale;
    $dx = (float)$x + ((float)$boxW - $w) / 2; $dy = (float)$y + ((float)$boxH - $h) / 2;
    return sprintf("q %.2F 0 0 %.2F %.2F %.2F cm /%s Do Q\n", $w, $h, $dx, $dy, $resource);
}

function contact_export_pdf_bytes($contacts, $single = false) {
    $contacts = array_values(array_filter((array)$contacts, function($row){ return is_array($row); }));
    $pages = array(); $pageImages = array();
    $content = ''; $currentImage = null;
    $y = 0; $pageNo = 0;

    $finishPage = function() use (&$pages, &$pageImages, &$content, &$currentImage, &$pageNo) {
        if ($content === '') return;
        $content .= contact_pdf_text(505, 24, 'Page ' . $pageNo, 8, 'F1');
        $pages[] = $content; $pageImages[] = $currentImage;
        $content = ''; $currentImage = null;
    };

    $startPage = function($contactName = '') use (&$content, &$currentImage, &$y, &$pageNo, $single) {
        $pageNo++; $currentImage = null;
        $content = "0.15 w\n";
        $content .= contact_pdf_text(48, 812, 'DoMyDesk - Contact', 15, 'F2');
        $content .= contact_pdf_text(414, 814, date('d/m/Y H:i'), 8, 'F1');
        $content .= contact_pdf_line(48, 801, 547, 801);
        if ($contactName !== '') {
            $content .= contact_pdf_text(48, 772, contact_pdf_upper($contactName), 18, 'F2');
            $y = 742;
        } else {
            $content .= contact_pdf_text(48, 772, $single ? 'FICHE CONTACT' : 'CONTACTS', 18, 'F2');
            $y = 742;
        }
    };

    $ensure = function($needed, $contactName = '') use (&$y, &$finishPage, &$startPage) {
        if ($y - $needed < 46) { $finishPage(); $startPage($contactName); }
    };

    $section = function($title, $rows, $contactName = '') use (&$content, &$y, $ensure) {
        $cleanRows = array();
        foreach ((array)$rows as $row) {
            if (!is_array($row) || count($row) < 2) continue;
            $label = trim((string)$row[0]); $value = contact_pdf_clean((string)$row[1]);
            if ($value === '') continue; $cleanRows[] = array($label, $value);
        }
        if (!$cleanRows) return;
        $ensure(34, $contactName);
        $content .= "0.94 0.94 0.94 rg\n" . contact_pdf_rect(48, $y - 18, 499, 24, true) . "0 g\n";
        $content .= contact_pdf_text(58, $y - 10, contact_pdf_upper($title), 9, 'F2'); $y -= 31;
        foreach ($cleanRows as $row) {
            $lines = contact_pdf_wrap($row[1], 72); $rowH = max(20, 12 * count($lines) + 8);
            $ensure($rowH + 4, $contactName);
            $content .= "0.86 0.86 0.86 RG\n" . contact_pdf_line(48, $y - $rowH + 3, 547, $y - $rowH + 3) . "0 G\n";
            $content .= contact_pdf_text(58, $y - 8, $row[0], 8, 'F2'); $vy = $y - 8;
            foreach ($lines as $line) { $content .= contact_pdf_text(182, $vy, $line, 9, 'F1'); $vy -= 12; }
            $y -= $rowH;
        }
        $y -= 8;
    };

    if (!$contacts) {
        $startPage(''); $content .= contact_pdf_text(48, $y, 'Aucun contact trouvé.', 11, 'F1'); $finishPage();
    } else {
        foreach ($contacts as $c) {
            if ($content !== '') $finishPage();
            $name = contact_full_name($c); $startPage($name);
            $companyLine = trim(implode(' - ', array_filter(array(trim((string)($c['entreprise'] ?? '')), trim((string)($c['poste'] ?? ''))), function($v){ return $v !== ''; })));
            if ($companyLine !== '') { $content .= contact_pdf_text(48, $y, $companyLine, 10, 'F1'); $y -= 24; }

            $avatarFile = contact_pdf_avatar_file($c);
            $avatarImage = contact_pdf_image_from_file($avatarFile);
            if ($avatarImage !== false) {
                $currentImage = $avatarImage;
                $content .= contact_pdf_rect(476, 708, 71, 71, false);
                $content .= contact_pdf_image_command('ImContact', $avatarImage, 479, 711, 65, 65);
                if ($y > 696) $y = 696;
            }

            $types = array(); if (!empty($c['is_private'])) $types[] = 'Privé'; if (!empty($c['is_pro'])) $types[] = 'Professionnel';
            $section('Identité', array(
                array('Civilité', contact_export_value($c, 'civilite')), array('Prénom', contact_export_value($c, 'prenom')),
                array('Nom', contact_export_value($c, 'nom')), array('Surnom', contact_export_value($c, 'surnom')),
                array('Type', implode(' / ', $types)), array('Relation privée', contact_export_value($c, 'relation_private')),
                array('Relation pro', contact_export_value($c, 'relation_pro'))
            ), $name);
            $section('Coordonnées', array(
                array('Email principal', contact_export_value($c, 'mail')), array('Email secondaire', contact_export_value($c, 'mail2')),
                array('Téléphone', contact_export_value($c, 'tel')), array('Téléphone 2', contact_export_value($c, 'tel2')),
                array('Adresse', contact_export_value($c, 'adresse_full')), array('Site web', contact_export_value($c, 'site_web')),
                array('LinkedIn', contact_export_value($c, 'linkedin'))
            ), $name);
            $section('Professionnel', array(
                array('Entreprise', contact_export_value($c, 'entreprise')), array('Poste / fonction', contact_export_value($c, 'poste')),
                array('Service', contact_export_value($c, 'service')), array('SIRET', contact_export_value($c, 'siret'))
            ), $name);
            $section('Personnel', array(
                array('Date de naissance', contact_export_value($c, 'date_naissance')), array('Situation familiale', contact_export_value($c, 'statut_familial')),
                array('Tags', contact_export_value($c, 'tags'))
            ), $name);
            $section('Notes', array(array('Notes', contact_export_value($c, 'notes'))), $name);
        }
        $finishPage();
    }

    $objects = array(); $catalogId = 1; $pagesId = 2; $fontId = 3; $fontBoldId = 4; $nextId = 5;
    $pageIds = array(); $contentIds = array(); $imageIds = array(); $maskIds = array();
    foreach ($pages as $i => $_) {
        $pageIds[$i] = $nextId++; $contentIds[$i] = $nextId++;
        if (!empty($pageImages[$i]) && is_array($pageImages[$i])) {
            $imageIds[$i] = $nextId++;
            if (!empty($pageImages[$i]['alpha'])) $maskIds[$i] = $nextId++;
        }
    }
    $kids = array(); foreach ($pageIds as $pid) $kids[] = $pid . ' 0 R';
    $objects[$catalogId] = "<< /Type /Catalog /Pages $pagesId 0 R >>";
    $objects[$pagesId] = "<< /Type /Pages /Kids [" . implode(' ', $kids) . "] /Count " . count($pages) . " >>";
    $objects[$fontId] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
    $objects[$fontBoldId] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
    foreach ($pages as $i => $pc) {
        $resources = "/Font << /F1 $fontId 0 R /F2 $fontBoldId 0 R >>";
        if (isset($imageIds[$i])) $resources .= " /XObject << /ImContact {$imageIds[$i]} 0 R >>";
        $objects[$pageIds[$i]] = "<< /Type /Page /Parent $pagesId 0 R /MediaBox [0 0 595 842] /Resources << $resources >> /Contents {$contentIds[$i]} 0 R >>";
        $objects[$contentIds[$i]] = "<< /Length " . strlen($pc) . ">>\nstream\n$pc\nendstream";
        if (isset($imageIds[$i])) {
            $img = $pageImages[$i]; $smask = isset($maskIds[$i]) ? " /SMask {$maskIds[$i]} 0 R" : '';
            $data = (string)$img['data'];
            $objects[$imageIds[$i]] = "<< /Type /XObject /Subtype /Image /Width " . (int)$img['w'] . " /Height " . (int)$img['h'] . " /ColorSpace " . $img['colorspace'] . " /BitsPerComponent " . (int)$img['bits'] . " /Filter " . $img['filter'] . $smask . " /Length " . strlen($data) . ">>\nstream\n" . $data . "\nendstream";
            if (isset($maskIds[$i])) {
                $alpha = (string)$img['alpha'];
                $objects[$maskIds[$i]] = "<< /Type /XObject /Subtype /Image /Width " . (int)$img['w'] . " /Height " . (int)$img['h'] . " /ColorSpace /DeviceGray /BitsPerComponent 8 /Filter /FlateDecode /Length " . strlen($alpha) . ">>\nstream\n" . $alpha . "\nendstream";
            }
        }
    }
    ksort($objects); $pdf = "%PDF-1.4\n"; $offsets = array(0);
    foreach ($objects as $objId => $obj) { $offsets[$objId] = strlen($pdf); $pdf .= "$objId 0 obj\n$obj\nendobj\n"; }
    $xref = strlen($pdf); $max = max(array_keys($objects));
    $pdf .= "xref\n0 " . ($max + 1) . "\n0000000000 65535 f \n";
    for ($i = 1; $i <= $max; $i++) $pdf .= sprintf("%010d 00000 n \n", isset($offsets[$i]) ? $offsets[$i] : 0);
    $pdf .= "trailer\n<< /Size " . ($max + 1) . " /Root $catalogId 0 R >>\nstartxref\n$xref\n%%EOF";
    return $pdf;
}

function contact_export_resolve_user($identifier) {
    $identifier = trim((string)$identifier);
    if ($identifier === '') return false;
    $needle = contact_lower($identifier);
    $profilesRoot = DMD_ROOT . '/users/profiles/';
    foreach (glob($profilesRoot . '*', GLOB_ONLYDIR) ?: array() as $profileDir) {
        $key = basename($profileDir);
        if ($key === '') continue;
        $profile = dmd_read_profile($key);
        $profileEmail = trim((string)($profile['email'] ?? $key));
        if (contact_lower($key) === $needle || ($profileEmail !== '' && contact_lower($profileEmail) === $needle)) {
            return array('key'=>$key, 'email'=>$profileEmail !== '' ? $profileEmail : $key, 'root'=>rtrim($profileDir, '/\\') . '/');
        }
    }
    return false;
}

function contact_export_dir($email, $received = false, $create = true) {
    $resolved = contact_export_resolve_user($email);
    if (!$resolved) return '';
    $dir = $resolved['root'] . 'exports/contact/';
    if ($received) $dir .= 'received/';
    if ($create && !is_dir($dir)) @mkdir($dir, 0750, true);
    return $dir;
}

function contact_export_unique_path($dir, $filename) {
    $filename = basename((string)$filename);
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    $stem = pathinfo($filename, PATHINFO_FILENAME);
    $safeStem = preg_replace('/[^a-zA-Z0-9_-]/', '_', $stem);
    if ($safeStem === '') $safeStem = 'export';
    $safeExt = preg_replace('/[^a-zA-Z0-9]/', '', $ext);
    $base = $safeStem . '_' . date('Ymd_His');
    $path = rtrim($dir, '/\\') . '/' . $base . ($safeExt !== '' ? '.' . $safeExt : '');
    $i = 2;
    while (file_exists($path)) {
        $path = rtrim($dir, '/\\') . '/' . $base . '_' . $i . ($safeExt !== '' ? '.' . $safeExt : '');
        $i++;
    }
    return $path;
}

function contact_export_write_user_file($email, $bytes, $filename, $received = false) {
    $dir = contact_export_dir($email, $received, true);
    if ($dir === '' || !is_string($bytes)) return '';
    $path = contact_export_unique_path($dir, $filename);
    if (@file_put_contents($path, $bytes, LOCK_EX) === false) return '';
    @chmod($path, 0640);
    return $path;
}

function contact_export_relative_user_path($email, $path) {
    $resolved = contact_export_resolve_user($email);
    if (!$resolved) return basename((string)$path);
    $root = $resolved['root'];
    $normPath = str_replace('\\', '/', (string)$path);
    $normRoot = str_replace('\\', '/', $root);
    return strpos($normPath, $normRoot) === 0 ? substr($normPath, strlen($normRoot)) : basename($normPath);
}

function contact_export_user_exists($email) {
    return contact_export_resolve_user($email) !== false;
}

function contact_export_copy_to_contact_module($senderEmail, $recipientEmail, $records) {
    $resolvedRecipient = contact_export_resolve_user($recipientEmail);
    if (!$resolvedRecipient) return array('count'=>0, 'error'=>'RECIPIENT_NOT_FOUND');
    $recipientKey = $resolvedRecipient['key'];
    $recipientFile = contact_contacts_file($recipientKey, true);
    $recipientAvatarDir = contact_avatar_dir($recipientKey, true);
    $recipientContacts = contact_read_json($recipientFile, array());
    $imported = 0;

    foreach ((array)$records as $src) {
        if (!is_array($src)) continue;
        $owner = trim((string)($src['owner_email'] ?? $senderEmail));
        if ($owner === '') $owner = $senderEmail;

        $record = array(
            'id'=>'c_' . bin2hex(random_bytes(12)),
            'civilite'=>(string)($src['civilite'] ?? ''),'prenom'=>(string)($src['prenom'] ?? ''),'nom'=>(string)($src['nom'] ?? ''),'surnom'=>(string)($src['surnom'] ?? ''),
            'is_private'=>!empty($src['is_private']),'is_pro'=>!empty($src['is_pro']),'relation_private'=>(string)($src['relation_private'] ?? ''),'relation_pro'=>(string)($src['relation_pro'] ?? ''),
            'entreprise'=>(string)($src['entreprise'] ?? ''),'poste'=>(string)($src['poste'] ?? ''),'service'=>(string)($src['service'] ?? ''),'siret'=>(string)($src['siret'] ?? ''),
            'mail'=>(string)($src['mail'] ?? ''),'mail2'=>(string)($src['mail2'] ?? ''),'tel'=>(string)($src['tel'] ?? ''),'tel2'=>(string)($src['tel2'] ?? ''),
            'adresse'=>(string)($src['adresse'] ?? ''),'code_postal'=>(string)($src['code_postal'] ?? ''),'ville'=>(string)($src['ville'] ?? ''),'pays'=>(string)($src['pays'] ?? ''),
            'date_naissance'=>(string)($src['date_naissance'] ?? ''),'statut_familial'=>(string)($src['statut_familial'] ?? ''),'site_web'=>(string)($src['site_web'] ?? ''),
            'linkedin'=>(string)($src['linkedin'] ?? ''),'tags'=>(string)($src['tags'] ?? ''),'notes'=>(string)($src['notes'] ?? ''),
            'shared_with'=>array(),'shared_roles'=>array(),'share_same_role'=>false,
            'created_at'=>date('c'),'updated_at'=>date('c'),'avatar'=>'',
            'imported_from'=>array('email'=>$senderEmail,'source_owner'=>$owner,'source_id'=>(string)($src['id'] ?? ''),'date'=>date('c'))
        );

        if (!empty($src['avatar'])) {
            $srcAvatarDir = contact_avatar_dir($owner, false);
            $srcAvatar = $srcAvatarDir !== '' ? $srcAvatarDir . basename((string)$src['avatar']) : '';
            if ($srcAvatar !== '' && is_file($srcAvatar)) {
                $ext = strtolower(pathinfo($srcAvatar, PATHINFO_EXTENSION));
                if (!in_array($ext, array('jpg','jpeg','png','gif','webp'), true)) $ext = 'img';
                $avatarName = bin2hex(random_bytes(16)) . '.' . $ext;
                $destAvatar = rtrim($recipientAvatarDir, '/\\') . '/' . $avatarName;
                if (@copy($srcAvatar, $destAvatar)) { @chmod($destAvatar, 0640); $record['avatar'] = $avatarName; }
            }
        }

        $recipientContacts[] = $record;
        $imported++;
    }

    if ($imported < 1) return array('count'=>0, 'error'=>'NO_ACCESSIBLE_CONTACT');
    usort($recipientContacts, function($a, $b){ return strcoll(contact_lower(contact_sort_key($a)), contact_lower(contact_sort_key($b))); });
    if (!contact_write_json($recipientFile, array_values($recipientContacts))) return array('count'=>0, 'error'=>'WRITE');
    contact_index_refresh_owner($recipientKey, $recipientContacts);
    return array('count'=>$imported, 'error'=>'', 'recipient_key'=>$recipientKey, 'recipient_email'=>$resolvedRecipient['email']);
}
