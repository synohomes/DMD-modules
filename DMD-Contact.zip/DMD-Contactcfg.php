<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/contact_lib.php';

$email = contact_current_email();
if ($email === '') { echo '<div class="contact-cfg-error">Connexion requise.</div>'; return; }
dmd_require_module_access(CONTACT_MODULE_ID, 'view');

$isAdmin = contact_is_system_admin();
if (empty($_SESSION['csrf_contact_cfg'])) $_SESSION['csrf_contact_cfg'] = bin2hex(random_bytes(32));
$csrf = (string)$_SESSION['csrf_contact_cfg'];
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_cfg_action'])) {
    if (!$isAdmin) {
        $message = 'Seul un administrateur DoMyDesk peut modifier cette configuration.';
        $messageType = 'error';
    } elseif (empty($_POST['csrf_token']) || !hash_equals($csrf, (string)$_POST['csrf_token'])) {
        $message = 'Formulaire expiré. Recharge la configuration.';
        $messageType = 'error';
    } else {
        $action = trim((string)$_POST['contact_cfg_action']);
        if ($action === 'general') {
            $next = contact_module_config();
            $next['mfa_enabled'] = !empty($_POST['mfa_enabled']);
            $next['mfa_timeout_minutes'] = (int)($_POST['mfa_timeout_minutes'] ?? 15);
            if (contact_module_config_save($next)) {
                $message = 'Configuration MFA DMD-Contact enregistrée.';
                $messageType = 'success';
                contact_log($email, 'contact.config_update', 'mfa.module', 'success', !empty($next['mfa_enabled']) ? 'MFA module activé.' : 'MFA module désactivé.');
            } else {
                $message = 'Impossible d’enregistrer la configuration MFA.';
                $messageType = 'error';
            }
        }
    }
}

$cfg = contact_module_config();
$directory = contact_directory_provider_status($email);
?>
<style>
.dmd-contact-cfg,.dmd-contact-cfg *{box-sizing:border-box}
.dmd-contact-cfg{display:grid;gap:9px;padding:9px;color:var(--text-color);font:inherit}
.dmd-contact-cfg h3,.dmd-contact-cfg h4,.dmd-contact-cfg p{margin:0}
.dmd-contact-cfg-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
.dmd-contact-cfg-head p,.dmd-contact-cfg-note{color:var(--muted-color);font-size:10px;line-height:1.4}
.dmd-contact-cfg-card{border:1px solid var(--border-color);border-radius:9px;background:var(--panel-bg);padding:9px;display:grid;gap:8px}
.dmd-contact-cfg-title{display:flex;align-items:center;justify-content:space-between;gap:8px}
.dmd-contact-cfg-title h4{font-size:12px}
.dmd-contact-cfg-state{display:inline-flex;align-items:center;min-height:21px;padding:2px 7px;border:1px solid var(--border-color);border-radius:999px;background:var(--card-bg);font-size:9px;font-weight:800}
.dmd-contact-cfg-row{display:grid;grid-template-columns:minmax(0,1fr) minmax(160px,230px);gap:9px;align-items:center}
.dmd-contact-cfg-row label{font-size:10.5px;font-weight:800}
.dmd-contact-cfg select{width:100%;min-height:30px;border:1px solid var(--border-color);border-radius:7px;padding:4px 7px;background:var(--input-bg);color:var(--text-color);font:inherit;font-size:10px}
.dmd-contact-cfg-toggle{display:flex;align-items:center;justify-content:flex-end;gap:7px;font-size:10px;font-weight:800}
.dmd-contact-cfg-toggle input{width:15px;height:15px}
.dmd-contact-cfg-actions{display:flex;justify-content:flex-end;gap:5px}
.dmd-contact-cfg-btn{min-height:29px;border:1px solid var(--border-color);border-radius:7px;background:var(--primary-color);color:var(--button-text-color,var(--text-color));padding:5px 9px;font:inherit;font-size:10px;font-weight:800;cursor:pointer}
.dmd-contact-cfg-msg{border:1px solid var(--border-color);border-radius:8px;background:var(--card-bg);padding:7px 9px;font-size:10px}.dmd-contact-cfg-msg[data-type="error"]{color:var(--danger-color)}
.dmd-contact-cfg-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;border-top:1px solid var(--border-color);padding-top:7px}.dmd-contact-cfg-meta>div{min-width:0}.dmd-contact-cfg-meta span{display:block;color:var(--muted-color);font-size:8px;text-transform:uppercase;font-weight:800}.dmd-contact-cfg-meta strong{display:block;margin-top:2px;font-size:10px;overflow-wrap:anywhere}
@media(max-width:720px){.dmd-contact-cfg-row,.dmd-contact-cfg-meta{grid-template-columns:1fr}.dmd-contact-cfg-head{flex-direction:column}.dmd-contact-cfg-toggle{justify-content:flex-start}}
</style>

<div class="dmd-contact-cfg">
  <div class="dmd-contact-cfg-head">
    <div>
      <h3>DMD-Contact — Configuration</h3>
      <p>Le CFG active la protection MFA du module. Les niveaux par groupe/utilisateur se règlent dans l’administration centrale des droits.</p>
    </div>
    <span class="dmd-contact-cfg-state">V. 2.4.4</span>
  </div>

  <?php if ($message !== ''): ?>
    <div class="dmd-contact-cfg-msg" data-type="<?= contact_h($messageType) ?>"><?= contact_h($message) ?></div>
  <?php endif; ?>

  <form method="post" class="dmd-contact-cfg-card">
    <input type="hidden" name="csrf_token" value="<?= contact_h($csrf) ?>">
    <input type="hidden" name="contact_cfg_action" value="general">
    <div class="dmd-contact-cfg-title">
      <h4>🔐 MFA DMD-Contact</h4>
      <span class="dmd-contact-cfg-state"><?= !empty($cfg['mfa_enabled']) ? 'Activé' : 'Désactivé' ?></span>
    </div>
    <div class="dmd-contact-cfg-row">
      <div>
        <label>Activer le MFA pour DMD-Contact</label>
        <p class="dmd-contact-cfg-note">Désactivé : aucun droit MFA du module n’est appliqué. Activé : la politique effective vient des droits DMD-Contact attribués au groupe ou à l’utilisateur.</p>
      </div>
      <label class="dmd-contact-cfg-toggle"><input type="checkbox" name="mfa_enabled" value="1" <?= !empty($cfg['mfa_enabled']) ? 'checked' : '' ?> <?= !$isAdmin ? 'disabled' : '' ?>> Activer</label>
    </div>
    <div class="dmd-contact-cfg-row">
      <div>
        <label>Durée de validation MFA</label>
        <p class="dmd-contact-cfg-note">Utilisée uniquement lorsque le droit « MFA obligatoire » s’applique à l’utilisateur.</p>
      </div>
      <select name="mfa_timeout_minutes" <?= !$isAdmin ? 'disabled' : '' ?>>
        <?php foreach (array(5,15,30,60) as $minutes): ?>
          <option value="<?= $minutes ?>" <?= (int)$cfg['mfa_timeout_minutes'] === $minutes ? 'selected' : '' ?>><?= $minutes ?> minutes</option>
        <?php endforeach; ?>
      </select>
    </div>
    <?php if ($isAdmin): ?><div class="dmd-contact-cfg-actions"><button type="submit" class="dmd-contact-cfg-btn">Enregistrer</button></div><?php endif; ?>
  </form>



  <section class="dmd-contact-cfg-card">
    <div class="dmd-contact-cfg-title">
      <h4>🏢 Annuaire / Active Directory</h4>
      <span class="dmd-contact-cfg-state"><?= !empty($directory['available']) ? 'Disponible' : (!empty($directory['configured']) ? 'Partiel' : (!empty($directory['admin_directory_present']) ? 'Brique détectée' : 'Non configuré')) ?></span>
    </div>
    <p class="dmd-contact-cfg-note">Le droit <strong>« Synchroniser avec l’annuaire »</strong> est lui aussi géré dans <strong>Administration → Droits sur les modules → DMD-Contact → Paramétrer</strong>, indépendamment pour les groupes et les utilisateurs. Le contrôle est appliqué côté interface <em>et</em> côté endpoint PHP.</p>
    <div class="dmd-contact-cfg-meta">
      <div><span>Fournisseur détecté</span><strong><?= contact_h((string)$directory['provider']) ?></strong></div>
      <div><span>Liste de contacts</span><strong><?= !empty($directory['available']) ? 'Utilisateurs AD accessibles' : (!empty($directory['list_supported']) ? 'Service présent mais AD désactivé/incomplet' : (!empty($directory['admin_directory_present']) ? 'Brique présente, service central introuvable' : 'Annuaire absent')) ?></strong></div>
      <div><span>Mode</span><strong>Sélectif / sens unique</strong></div>
    </div>
  </section>
</div>
