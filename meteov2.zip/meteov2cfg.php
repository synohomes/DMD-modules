<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once dirname(__DIR__, 2) . '/functions.php';

$email = $_SESSION['user']['email'] ?? '';
if (!$email) {
    echo "<div class='meteov2cfg-pro'><div class='mv2cfg-msg'>⛔ Non connecté</div></div>";
    return;
}

if (!dmd_user_can_use_module($email, 'meteov2')) {
    echo "<div class='meteov2cfg-pro'><div class='mv2cfg-msg'>⛔ Module MétéoV2 non autorisé pour cet utilisateur.</div></div>";
    return;
}

function mv2cfg_profile_dir(string $email): string {
    if (!function_exists('dmd_user_module_data_dir')) {
        return '';
    }

    return rtrim(dmd_user_module_data_dir($email, 'meteov2', true), DIRECTORY_SEPARATOR);
}

function mv2cfg_default(): array {
    return [
        'locations' => [
            ['name' => 'Paris, France', 'lat' => 48.8566, 'lon' => 2.3522, 'tz' => 'Europe/Paris']
        ],
        'days' => 7,
        'unit' => 'metric',
        'default_view' => 'dashboard',
        'show_location_switch' => true,
        'show_view_switch' => true,
        'show_hourly' => true,
        'show_daily' => true,
        'show_details' => true,
        'refresh_minutes' => 20
    ];
}

function mv2cfg_load(string $file): array {
    $def = mv2cfg_default();
    if (!file_exists($file)) {
        @mkdir(dirname($file), 0775, true);
        @file_put_contents($file, json_encode($def, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
        return $def;
    }
    $cfg = json_decode((string)@file_get_contents($file), true);
    if (!is_array($cfg)) return $def;
    $cfg = array_replace_recursive($def, $cfg);
    $cfg['locations'] = array_values(array_filter($cfg['locations'] ?? [], static function ($l) {
        return is_array($l) && isset($l['lat'], $l['lon']) && is_numeric($l['lat']) && is_numeric($l['lon']);
    }));
    if (!$cfg['locations']) $cfg['locations'] = $def['locations'];
    return $cfg;
}

function mv2cfg_clean_location(array $l): ?array {
    $name = trim((string)($l['name'] ?? ''));
    $lat = $l['lat'] ?? null;
    $lon = $l['lon'] ?? null;
    $tz = trim((string)($l['tz'] ?? 'auto'));
    if ($name === '' || !is_numeric($lat) || !is_numeric($lon)) return null;
    $lat = (float)$lat;
    $lon = (float)$lon;
    if ($lat < -90 || $lat > 90 || $lon < -180 || $lon > 180) return null;
    if ($tz === '') $tz = 'auto';
    return [
        'name' => mb_substr($name, 0, 120),
        'lat' => round($lat, 6),
        'lon' => round($lon, 6),
        'tz' => mb_substr($tz, 0, 80)
    ];
}

$moduleDataDir = mv2cfg_profile_dir($email);
if ($moduleDataDir === '') {
    echo "<div class='meteov2cfg-pro'><div class='mv2cfg-msg'>⛔ Dossier de données MeteoV2 indisponible.</div></div>";
    return;
}
$cfgFile = $moduleDataDir . DIRECTORY_SEPARATOR . 'meteov2.json';
$cfg = mv2cfg_load($cfgFile);
$msg = '';
$error = '';

if (empty($_SESSION['mv2cfg_csrf'])) {
    $_SESSION['mv2cfg_csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['mv2cfg_csrf'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedCsrf = $_POST['csrf'] ?? '';
    if (!hash_equals($csrf, (string)$postedCsrf)) {
        $error = 'Session expirée ou formulaire invalide.';
    } else {
        $locations = $cfg['locations'] ?? [];

        $remove = array_map('intval', (array)($_POST['remove_idx'] ?? []));
        if ($remove) {
            $locations = array_values(array_filter($locations, static function ($l, $i) use ($remove) {
                return !in_array((int)$i, $remove, true);
            }, ARRAY_FILTER_USE_BOTH));
        }

        $manual = mv2cfg_clean_location([
            'name' => $_POST['manual_name'] ?? '',
            'lat' => $_POST['manual_lat'] ?? '',
            'lon' => $_POST['manual_lon'] ?? '',
            'tz' => $_POST['manual_tz'] ?? 'auto'
        ]);
        if ($manual) $locations[] = $manual;

        $jsonToAdd = (string)($_POST['add_locations_json'] ?? '');
        if ($jsonToAdd !== '') {
            $decoded = json_decode($jsonToAdd, true);
            if (is_array($decoded)) {
                foreach ($decoded as $loc) {
                    if (is_array($loc)) {
                        $clean = mv2cfg_clean_location($loc);
                        if ($clean) $locations[] = $clean;
                    }
                }
            }
        }

        $unique = [];
        foreach ($locations as $loc) {
            $clean = mv2cfg_clean_location($loc);
            if (!$clean) continue;
            $key = $clean['lat'] . ':' . $clean['lon'];
            $unique[$key] = $clean;
        }
        $locations = array_values($unique);
        if (!$locations) $locations = mv2cfg_default()['locations'];

        $cfg['locations'] = $locations;
        $cfg['days'] = max(1, min(16, (int)($_POST['days'] ?? 7)));
        $cfg['unit'] = (($_POST['unit'] ?? 'metric') === 'imperial') ? 'imperial' : 'metric';
        $view = $_POST['default_view'] ?? 'dashboard';
        $cfg['default_view'] = in_array($view, ['dashboard', 'daily', 'hourly', 'table'], true) ? $view : 'dashboard';
        $cfg['refresh_minutes'] = max(5, min(180, (int)($_POST['refresh_minutes'] ?? 20)));
        $cfg['show_location_switch'] = !empty($_POST['show_location_switch']);
        $cfg['show_view_switch'] = !empty($_POST['show_view_switch']);
        $cfg['show_hourly'] = !empty($_POST['show_hourly']);
        $cfg['show_daily'] = !empty($_POST['show_daily']);
        $cfg['show_details'] = !empty($_POST['show_details']);

        @mkdir(dirname($cfgFile), 0775, true);
        $ok = @file_put_contents($cfgFile, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
        $msg = $ok === false ? '' : 'Configuration météo enregistrée.';
        if ($ok === false) $error = 'Impossible d’écrire le fichier de configuration.';
    }
}

$isDirectModule = strpos($_SERVER['SCRIPT_NAME'] ?? '', '/modules/meteov2/') !== false;
$cssHref = $isDirectModule ? 'meteov2.css' : 'modules/meteov2/meteov2.css';
$cssFile = __DIR__ . '/meteov2.css';
$cssVersion = file_exists($cssFile) ? filemtime($cssFile) : time();
$formAction = '';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($cssHref, ENT_QUOTES, 'UTF-8') ?>?v=<?= (int)$cssVersion ?>">
<div class="meteov2cfg-pro">
  <div class="mv2cfg-shell">
    <header class="mv2cfg-header">
      <div class="mv2cfg-kicker">🌦️ MétéoV2 PRO</div>
      <div class="mv2cfg-title">Configuration météo</div>
      <div class="mv2cfg-sub">Ajoute tes villes, règle l’affichage du module et garde une météo lisible sur dashboard comme en popup.</div>
    </header>

    <?php if ($msg): ?><div class="mv2cfg-msg">✅ <?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
    <?php if ($error): ?><div class="mv2cfg-msg">❌ <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>

    <form method="post" action="<?= htmlspecialchars($formAction, ENT_QUOTES, 'UTF-8') ?>" class="mv2cfg-shell">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="add_locations_json" id="mv2cfg-add-json" value="">

      <section class="mv2cfg-panel">
        <div class="mv2cfg-panel-title">📍 Lieux configurés</div>
        <div class="mv2cfg-list">
          <?php foreach (($cfg['locations'] ?? []) as $i => $loc): ?>
            <div class="mv2cfg-location">
              <div class="mv2cfg-location-main">
                <div class="mv2cfg-location-title"><?= htmlspecialchars($loc['name'] ?? 'Lieu', ENT_QUOTES, 'UTF-8') ?></div>
                <div class="mv2cfg-location-meta">lat <?= htmlspecialchars((string)($loc['lat'] ?? ''), ENT_QUOTES, 'UTF-8') ?> · lon <?= htmlspecialchars((string)($loc['lon'] ?? ''), ENT_QUOTES, 'UTF-8') ?> · TZ <?= htmlspecialchars((string)($loc['tz'] ?? 'auto'), ENT_QUOTES, 'UTF-8') ?></div>
              </div>
              <label class="mv2cfg-check mv2cfg-danger">
                <input type="checkbox" name="remove_idx[]" value="<?= (int)$i ?>">
                <span>Supprimer</span>
              </label>
            </div>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="mv2cfg-panel">
        <div class="mv2cfg-panel-title">🔎 Ajouter une ville automatiquement</div>
        <div class="mv2cfg-grid two">
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="mv2cfg-q">Recherche</label>
            <input class="mv2cfg-input" type="text" id="mv2cfg-q" placeholder="ex : Pau, Bordeaux, Montréal">
            <div class="mv2cfg-help">La recherche utilise le géocodage Open-Meteo, sans clé API.</div>
          </div>
          <div class="mv2cfg-field">
            <label class="mv2cfg-label">Action</label>
            <button type="button" class="mv2cfg-btn primary" id="mv2cfg-search">Rechercher</button>
            <div class="mv2cfg-help">Tu peux ajouter plusieurs villes avant d’enregistrer.</div>
          </div>
        </div>
        <div class="mv2cfg-list" id="mv2cfg-results"></div>
        <div class="mv2cfg-list" id="mv2cfg-toadd"></div>
      </section>

      <section class="mv2cfg-panel">
        <div class="mv2cfg-panel-title">🧭 Ajouter un lieu manuellement</div>
        <div class="mv2cfg-grid">
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="manual_name">Nom</label>
            <input class="mv2cfg-input" type="text" name="manual_name" id="manual_name" placeholder="Maison, Bureau, Datacenter…">
          </div>
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="manual_lat">Latitude</label>
            <input class="mv2cfg-input" type="text" name="manual_lat" id="manual_lat" placeholder="48.8566">
          </div>
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="manual_lon">Longitude</label>
            <input class="mv2cfg-input" type="text" name="manual_lon" id="manual_lon" placeholder="2.3522">
          </div>
        </div>
        <div class="mv2cfg-grid two">
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="manual_tz">Fuseau horaire</label>
            <input class="mv2cfg-input" type="text" name="manual_tz" id="manual_tz" placeholder="Europe/Paris" value="Europe/Paris">
          </div>
          <div class="mv2cfg-field">
            <label class="mv2cfg-label">Info</label>
            <div class="mv2cfg-help">L’ajout manuel est pratique pour une maison, un site client, un NAS distant ou un datacenter.</div>
          </div>
        </div>
      </section>

      <section class="mv2cfg-panel">
        <div class="mv2cfg-panel-title">⚙️ Affichage</div>
        <div class="mv2cfg-grid">
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="days">Nombre de jours</label>
            <select class="mv2cfg-select" name="days" id="days">
              <?php for ($d = 1; $d <= 16; $d++): ?>
                <option value="<?= $d ?>" <?= ((int)($cfg['days'] ?? 7) === $d) ? 'selected' : '' ?>><?= $d ?> jour<?= $d > 1 ? 's' : '' ?></option>
              <?php endfor; ?>
            </select>
          </div>
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="unit">Unités</label>
            <select class="mv2cfg-select" name="unit" id="unit">
              <option value="metric" <?= (($cfg['unit'] ?? 'metric') === 'metric') ? 'selected' : '' ?>>Métrique — °C, km/h, mm</option>
              <option value="imperial" <?= (($cfg['unit'] ?? 'metric') === 'imperial') ? 'selected' : '' ?>>Impérial — °F, mph, inch</option>
            </select>
          </div>
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="default_view">Vue par défaut</label>
            <select class="mv2cfg-select" name="default_view" id="default_view">
              <option value="dashboard" <?= (($cfg['default_view'] ?? 'dashboard') === 'dashboard') ? 'selected' : '' ?>>Dashboard complet</option>
              <option value="daily" <?= (($cfg['default_view'] ?? 'dashboard') === 'daily') ? 'selected' : '' ?>>Jours</option>
              <option value="hourly" <?= (($cfg['default_view'] ?? 'dashboard') === 'hourly') ? 'selected' : '' ?>>Heures</option>
              <option value="table" <?= (($cfg['default_view'] ?? 'dashboard') === 'table') ? 'selected' : '' ?>>Table numérique</option>
            </select>
          </div>
        </div>
        <div class="mv2cfg-grid two">
          <div class="mv2cfg-field">
            <label class="mv2cfg-label" for="refresh_minutes">Actualisation automatique</label>
            <select class="mv2cfg-select" name="refresh_minutes" id="refresh_minutes">
              <?php foreach ([5,10,15,20,30,45,60,120,180] as $m): ?>
                <option value="<?= $m ?>" <?= ((int)($cfg['refresh_minutes'] ?? 20) === $m) ? 'selected' : '' ?>>Toutes les <?= $m ?> minutes</option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mv2cfg-field">
            <label class="mv2cfg-label">Options visibles</label>
            <div class="mv2cfg-help">Permet d’adapter le module à une petite vignette ou une grande fenêtre dashboard.</div>
          </div>
        </div>
        <div class="mv2cfg-checks">
          <label class="mv2cfg-check"><input type="checkbox" name="show_location_switch" <?= !empty($cfg['show_location_switch']) ? 'checked' : '' ?>> <span>Sélecteur de lieu dans le module</span></label>
          <label class="mv2cfg-check"><input type="checkbox" name="show_view_switch" <?= !empty($cfg['show_view_switch']) ? 'checked' : '' ?>> <span>Boutons de vues dans le module</span></label>
          <label class="mv2cfg-check"><input type="checkbox" name="show_hourly" <?= !empty($cfg['show_hourly']) ? 'checked' : '' ?>> <span>Bloc prochaines heures</span></label>
          <label class="mv2cfg-check"><input type="checkbox" name="show_daily" <?= !empty($cfg['show_daily']) ? 'checked' : '' ?>> <span>Bloc prévisions journalières</span></label>
          <label class="mv2cfg-check"><input type="checkbox" name="show_details" <?= !empty($cfg['show_details']) ? 'checked' : '' ?>> <span>Détails enrichis</span></label>
        </div>
      </section>

      <section class="mv2cfg-actions">
        <div class="mv2cfg-help">Fichier utilisateur : <strong>users/profiles/[email]/meteov2.json</strong></div>
        <button type="submit" class="mv2cfg-btn primary">💾 Enregistrer</button>
      </section>
    </form>
  </div>
</div>
<script>
(function(){
  const q = document.getElementById('mv2cfg-q');
  const searchBtn = document.getElementById('mv2cfg-search');
  const results = document.getElementById('mv2cfg-results');
  const toAdd = document.getElementById('mv2cfg-toadd');
  const addJson = document.getElementById('mv2cfg-add-json');
  let pending = [];
  let lastResults = [];

  function esc(s){ return String(s ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c])); }
  function sync(){ addJson.value = JSON.stringify(pending); }
  function cleanLoc(x){
    return {
      name: `${x.name || 'Lieu'}${x.admin1 ? ', ' + x.admin1 : ''}${x.country ? ', ' + x.country : ''}`,
      lat: Number(x.latitude),
      lon: Number(x.longitude),
      tz: x.timezone || 'auto'
    };
  }
  function renderPending(){
    sync();
    if (!pending.length) { toAdd.innerHTML = ''; return; }
    toAdd.innerHTML = '<div class="mv2cfg-panel-title">À ajouter au prochain enregistrement</div>' + pending.map((l, i) => `
      <div class="mv2cfg-additem">
        <div class="mv2cfg-result-main"><div class="mv2cfg-result-title">${esc(l.name)}</div><div class="mv2cfg-result-meta">lat ${esc(l.lat)} · lon ${esc(l.lon)} · TZ ${esc(l.tz)}</div></div>
        <button type="button" class="mv2cfg-btn" data-remove-pending="${i}">Retirer</button>
      </div>`).join('');
    toAdd.querySelectorAll('[data-remove-pending]').forEach(btn => btn.addEventListener('click', () => {
      pending.splice(parseInt(btn.dataset.removePending, 10), 1);
      renderPending();
    }));
  }
  function renderResults(list){
    lastResults = list;
    if (!list.length) { results.innerHTML = '<div class="mv2cfg-msg">Aucun résultat.</div>'; return; }
    results.innerHTML = list.map((l, i) => `
      <div class="mv2cfg-result">
        <div class="mv2cfg-result-main"><div class="mv2cfg-result-title">${esc(l.name)}</div><div class="mv2cfg-result-meta">lat ${esc(l.lat)} · lon ${esc(l.lon)} · TZ ${esc(l.tz)}</div></div>
        <button type="button" class="mv2cfg-btn primary" data-add-result="${i}">Ajouter</button>
      </div>`).join('');
    results.querySelectorAll('[data-add-result]').forEach(btn => btn.addEventListener('click', () => {
      const loc = lastResults[parseInt(btn.dataset.addResult, 10)];
      if (!loc) return;
      const key = loc.lat + ':' + loc.lon;
      if (!pending.some(x => x.lat + ':' + x.lon === key)) pending.push(loc);
      renderPending();
    }));
  }
  async function search(){
    const s = (q.value || '').trim();
    if (!s) { results.innerHTML = '<div class="mv2cfg-msg">Tape une ville à rechercher.</div>'; return; }
    results.innerHTML = '<div class="mv2cfg-msg">Recherche en cours…</div>';
    try {
      const url = new URL('https://geocoding-api.open-meteo.com/v1/search');
      url.searchParams.set('name', s);
      url.searchParams.set('language', 'fr');
      url.searchParams.set('format', 'json');
      url.searchParams.set('count', '10');
      const r = await fetch(url, {cache:'no-store'});
      if (!r.ok) throw new Error('HTTP ' + r.status);
      const j = await r.json();
      renderResults((j.results || []).map(cleanLoc));
    } catch (e) {
      results.innerHTML = '<div class="mv2cfg-msg">❌ Recherche indisponible pour le moment.</div>';
    }
  }
  searchBtn && searchBtn.addEventListener('click', search);
  q && q.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); search(); } });
})();
</script>
