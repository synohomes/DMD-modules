# DMD-MeteoV2

Module météo personnel pour **DoMyDesk 1.2.0**.

DMD-MeteoV2 affiche la météo actuelle et les prévisions d'un ou plusieurs lieux directement dans le dashboard DoMyDesk. Le module utilise **Open-Meteo**, sans clé API, et conserve sa configuration séparément pour chaque utilisateur.

---

## Informations du module

| Élément | Valeur |
|---|---|
| Nom affiché | **DMD-MeteoV2** |
| ID technique | `meteov2` |
| Version documentée | `2.0.0` |
| DoMyDesk minimum | `1.2.0` |
| Type de stockage | `user` |
| Accès par défaut | `everyone` |
| Base de données | **Aucune** |
| API météo | **Open-Meteo** |
| Clé API | **Non requise** |
| Point d'entrée | `meteov2.php` |
| Configuration | `meteov2cfg.php` |

Le nom affiché provient de `dmd_module.json`. L'ID `meteov2` reste l'identifiant technique utilisé par le Core, les chemins et les droits DoMyDesk.

---

## Fonctionnalités

DMD-MeteoV2 permet notamment :

- d'afficher la météo actuelle ;
- de gérer plusieurs lieux ;
- de passer rapidement d'un lieu à l'autre ;
- d'afficher jusqu'à **16 jours** de prévisions ;
- d'afficher les prochaines heures ;
- d'utiliser les unités métriques ou impériales ;
- de choisir une vue par défaut ;
- de régler la fréquence d'actualisation automatique ;
- d'activer ou masquer certains blocs pour adapter le module à la taille de sa fenêtre ;
- d'ajouter une ville automatiquement avec le géocodage Open-Meteo ;
- d'ajouter manuellement un lieu à partir de ses coordonnées GPS et de son fuseau horaire.

---

## Données météo affichées

Selon la vue et les options activées, le module exploite notamment les données suivantes :

### Conditions actuelles

- température ;
- température ressentie ;
- humidité relative ;
- état du ciel ;
- vitesse du vent ;
- direction du vent ;
- rafales ;
- pression au niveau de la mer ;
- précipitations ;
- couverture nuageuse ;
- période jour/nuit.

### Prévisions horaires

- température ;
- ressenti ;
- humidité ;
- probabilité de précipitations ;
- précipitations ;
- condition météo ;
- vent ;
- direction du vent ;
- indice UV ;
- visibilité.

### Prévisions journalières

- état météo ;
- température maximale et minimale ;
- ressenti maximal et minimal ;
- cumul de précipitations ;
- probabilité maximale de précipitations ;
- vent maximal ;
- rafales maximales ;
- indice UV maximal ;
- lever du soleil ;
- coucher du soleil.

Les codes météo retournés par Open-Meteo sont traduits en libellés et icônes directement par le module.

---

## Les vues disponibles

DMD-MeteoV2 propose quatre modes d'affichage.

### Dashboard complet

Vue générale réunissant :

- météo actuelle ;
- indicateurs principaux ;
- prochaines heures ;
- prévisions sur plusieurs jours.

### Jours

Vue orientée prévisions journalières.

### Heures

Vue consacrée aux prochaines heures.

### Table numérique

Vue compacte sous forme de tableau, pratique lorsque l'on souhaite lire rapidement les valeurs météo.

La vue utilisée au démarrage peut être choisie dans la configuration utilisateur.

---

## Configuration utilisateur

La configuration est personnelle : chaque utilisateur peut avoir ses propres villes et préférences.

Le fichier réellement utilisé par le module est :

```text
users/profiles/[email]/meteov2/meteov2.json
```

Le dossier est créé à la demande par le Core DoMyDesk.

### Configuration par défaut

Lors de la première utilisation, le module initialise notamment :

```text
Lieu                 : Paris, France
Latitude             : 48.8566
Longitude            : 2.3522
Fuseau horaire       : Europe/Paris
Prévisions           : 7 jours
Unités                : métriques
Vue                   : dashboard
Actualisation         : 20 minutes
Sélecteur de lieu     : activé
Sélecteur de vue      : activé
Prévisions horaires   : activées
Prévisions journalières : activées
Détails enrichis      : activés
```

### Nombre de jours

Valeur autorisée :

```text
1 à 16 jours
```

### Actualisation automatique

La fréquence est limitée par le module entre :

```text
5 et 180 minutes
```

L'interface propose actuellement :

```text
5 / 10 / 15 / 20 / 30 / 45 / 60 / 120 / 180 minutes
```

### Unités

Deux modes sont disponibles :

**Métrique**

```text
°C
km/h
mm
```

**Impérial**

```text
°F
mph
inch
```

---

## Ajouter un lieu automatiquement

La page de configuration possède un moteur de recherche utilisant :

```text
https://geocoding-api.open-meteo.com/v1/search
```

Aucune clé API n'est nécessaire.

Exemples de recherche :

```text
Pau
Bordeaux
Montréal
Chamonix-Mont-Blanc
```

La recherche permet de récupérer automatiquement :

- le nom du lieu ;
- la région lorsque disponible ;
- le pays ;
- la latitude ;
- la longitude ;
- le fuseau horaire.

Plusieurs résultats peuvent être préparés avant l'enregistrement de la configuration.

---

## Ajouter un lieu manuellement

Un lieu peut également être créé manuellement avec :

- un nom ;
- une latitude ;
- une longitude ;
- un fuseau horaire.

Exemple :

```text
Nom       : Datacenter Lyon
Latitude  : 45.7640
Longitude : 4.8357
Fuseau    : Europe/Paris
```

Les coordonnées sont contrôlées par le module :

```text
Latitude  : -90 à 90
Longitude : -180 à 180
```

Cette fonction peut servir pour une maison, un bureau, un site client, un datacenter ou tout autre emplacement dont les coordonnées sont connues.

---

## API Open-Meteo

Les prévisions sont récupérées directement depuis :

```text
https://api.open-meteo.com/v1/forecast
```

Les requêtes sont faites en HTTPS et avec `cache: no-store` côté navigateur.

La localisation configurée, ses coordonnées, le fuseau horaire et les paramètres nécessaires aux prévisions sont donc transmis à Open-Meteo lors de la récupération de la météo.

DMD-MeteoV2 ne stocke pas de clé API et n'a besoin d'aucun compte Open-Meteo.

---

## Stockage

DMD-MeteoV2 est un module de type **user**.

Il ne possède pas de stockage global dans `data/modules/` pour ses données météo.

Chaque utilisateur possède sa propre configuration :

```text
users/
└── profiles/
    └── utilisateur@example.com/
        └── meteov2/
            ├── .htaccess
            └── meteov2.json
```

La politique du manifeste est :

```text
create             : lazy
preserve_on_update : true
```

Les réglages utilisateur doivent donc être conservés lors d'une mise à jour normale du module.

---

## Sécurité et accès

DMD-MeteoV2 utilise le système d'accès aux modules de DoMyDesk.

Avant l'affichage du module ou de sa configuration, le code contrôle notamment :

```text
dmd_user_can_use_module($email, 'meteov2')
```

La page de configuration protège également les modifications avec un jeton **CSRF** stocké en session.

Le dossier utilisateur est créé via le système de stockage utilisateur du Core DoMyDesk.

Le module ne demande :

- aucun mot de passe météo ;
- aucune clé API ;
- aucun compte externe ;
- aucune base de données.

---

## Permissions DoMyDesk

Le manifeste actuel ne déclare pas de catalogue de capacités granulaires spécifique à MeteoV2.

L'accès repose donc principalement sur l'autorisation générale d'utiliser le module dans DoMyDesk.

Le manifeste indique :

```text
default_access : everyone
```

Cela n'empêche pas le Core DoMyDesk d'appliquer ses règles d'activation, de rôle métier ou ses exceptions utilisateur.

---

## Logs

La version documentée de DMD-MeteoV2 **ne crée pas de journal d'actions dédié au module**.

Les réglages sont enregistrés dans le fichier de configuration utilisateur, mais les changements de ville ou de préférences ne sont pas historisés dans un fichier de logs MeteoV2.

---

## Structure du module

```text
modules/
└── meteov2/
    ├── dmd_module.json
    ├── icon.png
    ├── meteov2.php
    ├── meteov2cfg.php
    └── meteov2.css
```

### `dmd_module.json`

Manifeste DoMyDesk 1.2.0 : identité, version, type de stockage, points d'entrée et contrat du package.

### `icon.png`

Icône du module utilisée par le dashboard et les interfaces du Core.

### `meteov2.php`

Interface principale du module et récupération des données Open-Meteo.

### `meteov2cfg.php`

Configuration utilisateur : lieux, unités, vues et actualisation.

### `meteov2.css`

Mise en forme du module. L'interface s'intègre aux variables visuelles de DoMyDesk.

---

## Installation

DMD-MeteoV2 est prévu pour être installé comme module DoMyDesk 1.2.0.

Le dossier technique attendu est :

```text
modules/meteov2/
```

Après installation :

1. autoriser ou activer le module pour l'utilisateur si nécessaire ;
2. ouvrir la configuration de DMD-MeteoV2 ;
3. ajouter les lieux désirés ;
4. sélectionner les unités et la vue par défaut ;
5. enregistrer ;
6. ajouter le module au dashboard.

Aucune initialisation de base de données n'est nécessaire.

---

## Mise à jour

La configuration étant stockée dans le profil utilisateur et la politique `preserve_on_update` étant activée, une mise à jour du code du module ne doit pas supprimer les réglages utilisateur.

Avant toute opération manuelle importante, le dossier à sauvegarder pour un utilisateur est :

```text
users/profiles/[email]/meteov2/
```

---

## Dépendances

### Serveur

- DoMyDesk `1.2.0` ou supérieur ;
- PHP compatible avec DoMyDesk 1.2.0 ;
- extension JSON PHP ;
- extension `mbstring` pour la configuration telle qu'elle est actuellement codée.

### Navigateur

Le navigateur doit disposer :

- de JavaScript ;
- de `fetch()` ;
- d'un accès HTTPS vers Open-Meteo.

### Réseau

L'instance ou le navigateur doit pouvoir joindre :

```text
api.open-meteo.com
geocoding-api.open-meteo.com
```

---

## Dépannage

### Le module affiche « Non connecté »

La session DoMyDesk n'est pas active.

### Le module affiche « Module MétéoV2 non autorisé »

Vérifier les droits et l'activation du module dans DoMyDesk.

### La météo reste sur « Chargement »

Vérifier :

- l'accès Internet du navigateur ;
- que `api.open-meteo.com` n'est pas bloqué ;
- la console réseau du navigateur ;
- les coordonnées du lieu configuré.

### La recherche de ville ne fonctionne pas

Vérifier l'accès à :

```text
geocoding-api.open-meteo.com
```

### Les préférences ne sont pas conservées

Vérifier les droits d'écriture sur :

```text
users/profiles/[email]/meteov2/
```

### La page de configuration provoque une erreur liée à `mb_substr`

Vérifier que l'extension PHP `mbstring` est chargée.

---

## Sauvegarde

Pour sauvegarder la configuration MeteoV2 d'un utilisateur, conserver :

```text
users/profiles/[email]/meteov2/
```

Le module ne possède pas de base SQL à exporter.

---

## Contrat DoMyDesk 1.2.0

Le module utilise un `dmd_module.json` au format de contrat DoMyDesk 1.2.0 avec :

```text
schema        : 1
id            : meteov2
name          : DMD-MeteoV2
version       : 2.0.0
min_domydesk  : 1.2.0
storage_scope : user
default_access: everyone
entrypoint    : meteov2.php
config        : meteov2cfg.php
package.strict: true
```

Si ce README est ajouté **dans le ZIP strict du module**, il doit aussi être ajouté à `package.files` dans `dmd_module.json`. Sinon, il peut rester comme documentation distribuée à côté du package.

---

## Résumé

DMD-MeteoV2 est un module météo utilisateur léger, sans base de données et sans clé API. Il permet d'afficher plusieurs lieux, les conditions actuelles, les prévisions horaires et journalières, avec une configuration propre à chaque utilisateur et une intégration directe dans le dashboard DoMyDesk.
