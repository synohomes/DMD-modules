<?php
/* Compatibilité : ancienne API de création, désormais branchée sur le moteur ProxV2 1.2.x. */
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/proxv2_lib.php';
header('Content-Type: application/json; charset=UTF-8');

if (!proxv2_has_module_access()) proxv2_json(false, 'Module ProxV2 non autorisé.', array(), 403);
$op = strtolower(trim((string)(isset($_REQUEST['op']) ? $_REQUEST['op'] : '')));
$serverId = trim((string)(isset($_REQUEST['server_id']) ? $_REQUEST['server_id'] : (isset($_REQUEST['srv']) ? $_REQUEST['srv'] : '')));
$server = proxv2_load_server($serverId);
if (!is_array($server)) proxv2_json(false, 'Serveur introuvable.', array(), 404);

$nodes = proxv2_api($server, 'nodes', 'GET', null, 12);
$node = trim((string)(isset($_REQUEST['node']) ? $_REQUEST['node'] : ''));
if ($node === '' && $nodes['ok'] && is_array($nodes['data']) && !empty($nodes['data'][0]['node'])) $node = (string)$nodes['data'][0]['node'];
if ($node === '') proxv2_json(false, 'Impossible de déterminer le node Proxmox.', array(), 400);

if ($op === 'listiso') {
    $out = array();
    $storages = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/storage', 'GET', null, 12);
    if ($storages['ok'] && is_array($storages['data'])) {
        foreach ($storages['data'] as $st) {
            $sid = isset($st['storage']) ? (string)$st['storage'] : '';
            if ($sid === '' || strpos((string)(isset($st['content']) ? $st['content'] : ''), 'iso') === false) continue;
            $r = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/storage/' . rawurlencode($sid) . '/content', 'GET', null, 12);
            if (!$r['ok'] || !is_array($r['data'])) continue;
            foreach ($r['data'] as $item) if (is_array($item) && (isset($item['content']) ? $item['content'] : '') === 'iso') $out[] = isset($item['volid']) ? $item['volid'] : '';
        }
    }
    echo json_encode(array_values(array_unique(array_filter($out))), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
}

if ($op === 'listbridges' || $op === 'listvlans') {
    $r = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/network', 'GET', null, 12);
    $out = array();
    if ($r['ok'] && is_array($r['data'])) foreach ($r['data'] as $net) {
        if (!is_array($net)) continue;
        if ($op === 'listbridges' && (isset($net['type']) ? $net['type'] : '') === 'bridge' && !empty($net['iface'])) $out[] = $net['iface'];
        if ($op === 'listvlans') {
            if (isset($net['tag']) && is_numeric($net['tag'])) $out[] = (int)$net['tag'];
            $iface = isset($net['iface']) ? (string)$net['iface'] : '';
            if (preg_match('/vlan(\d+)/i', $iface, $m)) $out[] = (int)$m[1];
        }
    }
    $out = array_values(array_unique($out)); sort($out, SORT_NATURAL); echo json_encode($out); exit;
}

if ($op === 'createvm') {
    if (!proxv2_user_can('vm.create')) proxv2_json(false, 'Droit de création VM refusé.', array(), 403);
    if (!proxv2_csrf_valid(isset($_POST['csrf']) ? $_POST['csrf'] : '')) proxv2_json(false, 'Jeton de sécurité expiré.', array(), 403);
    $vmidRaw = trim((string)(isset($_POST['vmid']) ? $_POST['vmid'] : ''));
    $vmid = $vmidRaw === '' ? proxv2_next_vmid($server) : (int)$vmidRaw;
    if ($vmid < 100) proxv2_json(false, 'VMID invalide.', array(), 400);
    if (proxv2_resolve_vm($server, $vmid, '') !== null) proxv2_json(false, 'VMID déjà utilisé : ' . $vmid, array(), 409);
    $name = trim((string)(isset($_POST['vmname']) ? $_POST['vmname'] : ''));
    $storageVm = trim((string)(isset($_POST['storage_vm']) ? $_POST['storage_vm'] : 'local-lvm'));
    $bridge = trim((string)(isset($_POST['bridge']) ? $_POST['bridge'] : 'vmbr0'));
    if ($name === '') proxv2_json(false, 'Nom VM obligatoire.', array(), 400);
    $vlan = (int)(isset($_POST['vlan']) ? $_POST['vlan'] : 0);
    $payload = array(
        'vmid' => $vmid,
        'name' => $name,
        'sockets' => 1,
        'cores' => max(1, (int)(isset($_POST['cpu']) ? $_POST['cpu'] : 2)),
        'memory' => max(128, (int)(isset($_POST['ram']) ? $_POST['ram'] : 2048)),
        'scsihw' => 'virtio-scsi-pci',
        'scsi0' => $storageVm . ':' . max(1, (int)(isset($_POST['disk']) ? $_POST['disk'] : 20)),
        'net0' => 'virtio,bridge=' . $bridge . ($vlan > 0 ? ',tag=' . $vlan : ''),
        'ostype' => trim((string)(isset($_POST['ostype']) ? $_POST['ostype'] : 'l26')),
        'agent' => 1
    );
    $iso = trim((string)(isset($_POST['iso']) ? $_POST['iso'] : ''));
    if ($iso !== '') $payload['ide2'] = $iso . ',media=cdrom';
    $r = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/qemu', 'POST', $payload, 30);
    if (!$r['ok']) proxv2_json(false, $r['error'], array('vmid' => $vmid), $r['http'] >= 400 ? $r['http'] : 502);
    proxv2_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'success', 'VM créée via API compatibilité', array('server_id' => $serverId, 'node' => $node, 'vmid' => $vmid));
    proxv2_json(true, 'VM créée.', array('vmid' => $vmid, 'node' => $node, 'upid' => $r['data']), 200);
}

proxv2_json(false, 'Opération inconnue.', array(), 400);
