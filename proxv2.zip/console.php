<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/proxv2_lib.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');

function proxv2_remote_error($message, $status) {
    http_response_code((int)$status);
    $safe = htmlspecialchars((string)$message, ENT_QUOTES, 'UTF-8');
    echo '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<style>html,body{height:100%;margin:0;background:#080b12;color:#e8edf7;font-family:system-ui,sans-serif}.e{height:100%;display:grid;place-items:center;padding:20px;box-sizing:border-box}.c{max-width:620px;padding:18px;border:1px solid rgba(255,255,255,.14);border-radius:12px;background:#111827}.c strong{display:block;margin-bottom:8px}.c p{margin:0;color:#aeb9cc;line-height:1.5}</style></head><body><div class="e"><div class="c"><strong>Remote ProxV2 indisponible</strong><p>' . $safe . '</p></div></div></body></html>';
    exit;
}

function proxv2_remote_is_https_request() {
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') return true;
    $proto = strtolower(trim((string)(isset($_SERVER['HTTP_X_FORWARDED_PROTO']) ? $_SERVER['HTTP_X_FORWARDED_PROTO'] : '')));
    return $proto === 'https';
}

function proxv2_remote_php_cli() {
    $candidates = array();
    if (defined('PHP_BINDIR')) $candidates[] = rtrim((string)PHP_BINDIR, '/\\') . DIRECTORY_SEPARATOR . 'php';
    $candidates[] = '/usr/bin/php';
    $candidates[] = '/usr/local/bin/php';
    $candidates[] = '/opt/bin/php';
    if (defined('PHP_BINARY')) $candidates[] = (string)PHP_BINARY;
    foreach (array_unique($candidates) as $candidate) {
        if ($candidate === '' || !is_file($candidate) || !is_executable($candidate)) continue;
        $base = strtolower(basename($candidate));
        if (strpos($base, 'php-fpm') !== false || strpos($base, 'php-cgi') !== false) continue;
        return $candidate;
    }
    return '';
}

function proxv2_remote_function_enabled($name) {
    if (!function_exists($name)) return false;
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    return !in_array($name, $disabled, true);
}

function proxv2_remote_port_is_free($port) {
    $fp = @fsockopen('127.0.0.1', (int)$port, $errno, $errstr, 0.08);
    if (is_resource($fp)) {
        fclose($fp);
        return false;
    }
    return true;
}

function proxv2_remote_pick_port() {
    $ports = range(6080, 6129);
    shuffle($ports);
    foreach ($ports as $port) {
        if (proxv2_remote_port_is_free($port)) return (int)$port;
    }
    return 0;
}

function proxv2_remote_start_bridge($phpCli, $configFile) {
    $script = __DIR__ . '/remote_bridge.php';
    if (!is_file($script)) return false;
    $cmd = escapeshellarg($phpCli) . ' ' . escapeshellarg($script) . ' ' . escapeshellarg($configFile);
    if (proxv2_remote_function_enabled('exec')) {
        @exec($cmd . ' > /dev/null 2>&1 &');
        return true;
    }
    if (proxv2_remote_function_enabled('shell_exec')) {
        @shell_exec($cmd . ' > /dev/null 2>&1 &');
        return true;
    }
    if (proxv2_remote_function_enabled('proc_open')) {
        $desc = array(0 => array('file', '/dev/null', 'r'), 1 => array('file', '/dev/null', 'a'), 2 => array('file', '/dev/null', 'a'));
        $proc = @proc_open($cmd . ' > /dev/null 2>&1 &', $desc, $pipes, __DIR__);
        if (is_resource($proc)) {
            foreach ($pipes as $pipe) if (is_resource($pipe)) fclose($pipe);
            return true;
        }
    }
    return false;
}

if (!proxv2_has_module_access() || !proxv2_user_can('console')) {
    proxv2_remote_error('Droit Remote refusé.', 403);
}
if (!proxv2_csrf_valid(isset($_GET['csrf']) ? $_GET['csrf'] : '')) {
    proxv2_remote_error('Jeton de sécurité invalide.', 403);
}
if (!is_file(__DIR__ . '/novnc/core/rfb.js')) {
    proxv2_remote_error('Le composant noVNC local est absent du module.', 501);
}
if (proxv2_remote_is_https_request()) {
    proxv2_remote_error('La V2 fournit le Remote en lecture seule sur le réseau local HTTP. Le tunnel Remote HTTPS/WSS renforcé est réservé à la V3.', 409);
}

$serverId = trim((string)(isset($_GET['server_id']) ? $_GET['server_id'] : ''));
$vmid = (int)(isset($_GET['vmid']) ? $_GET['vmid'] : 0);
$type = strtolower(trim((string)(isset($_GET['type']) ? $_GET['type'] : '')));
if ($serverId === '' || $vmid <= 0) proxv2_remote_error('Paramètres Remote incomplets.', 400);

$server = proxv2_load_server($serverId);
if (!is_array($server)) proxv2_remote_error('Serveur Proxmox introuvable.', 404);
$vm = proxv2_resolve_vm($server, $vmid, $type);
if (!is_array($vm)) proxv2_remote_error('VM/CT introuvable.', 404);

$node = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
$type = strtolower((string)(isset($vm['type']) ? $vm['type'] : 'qemu'));
if (!in_array($type, array('qemu', 'lxc'), true)) $type = 'qemu';
if ($node === '') proxv2_remote_error('Node Proxmox introuvable.', 404);

$serviceUser = trim((string)(isset($server['proxmox_user']) ? $server['proxmox_user'] : 'domydesk@pve'));
if ($serviceUser === '') $serviceUser = 'domydesk@pve';
$remotePassword = proxv2_decrypt_remote_password($server);
if ($remotePassword === '') {
    proxv2_remote_error('Ce serveur a été configuré avant l’activation du Remote. Dans le CFG ProxV2, renouvelle une fois la configuration automatique avec le compte administrateur Proxmox : le mot de passe root ne sera toujours pas conservé.', 409);
}

$ip = trim((string)(isset($server['ip']) ? $server['ip'] : ''));
$port = (int)(isset($server['port']) ? $server['port'] : 8006);
if ($port <= 0 || $port > 65535) $port = 8006;
if ($ip === '') proxv2_remote_error('Adresse Proxmox manquante.', 500);

/* Console Proxmox : elle exige un ticket utilisateur, pas le token API. */
$login = proxv2_password_login($ip, $port, $serviceUser, $remotePassword, 12);
$remotePassword = null;
if (empty($login['ok']) || !is_array($login['data'])) {
    proxv2_remote_error('Impossible d’obtenir le ticket utilisateur Remote : ' . (isset($login['error']) ? $login['error'] : 'erreur inconnue'), 502);
}
$auth = $login['data'];

$endpoint = 'nodes/' . rawurlencode($node) . '/' . $type . '/' . $vmid . '/vncproxy';
$res = proxv2_ticket_api($ip, $port, $auth, $endpoint, 'POST', array('websocket' => 1), 15);
if (empty($res['ok']) || !is_array($res['data'])) {
    proxv2_remote_error('Impossible d’ouvrir le proxy Remote Proxmox : ' . (isset($res['error']) ? $res['error'] : 'erreur inconnue'), 502);
}
$d = $res['data'];
if (empty($d['port']) || empty($d['ticket'])) proxv2_remote_error('Réponse Remote Proxmox incomplète.', 502);

$bridgePort = proxv2_remote_pick_port();
if ($bridgePort <= 0) proxv2_remote_error('Aucun port Remote local libre entre 6080 et 6129.', 503);
$phpCli = proxv2_remote_php_cli();
if ($phpCli === '') proxv2_remote_error('PHP CLI est nécessaire pour le tunnel Remote V2 et n’a pas été trouvé sur ce serveur.', 501);

$paths = proxv2_storage_paths();
$remoteDir = isset($paths['remote']) ? $paths['remote'] : '';
if ($remoteDir === '' || (!is_dir($remoteDir) && !@mkdir($remoteDir, 0750, true))) {
    proxv2_remote_error('Le dossier persistant Remote ProxV2 est inaccessible.', 500);
}

$sessionToken = bin2hex(random_bytes(24));
$wsPath = '/api2/json/nodes/' . rawurlencode($node) . '/' . $type . '/' . $vmid . '/vncwebsocket?port=' . rawurlencode((string)$d['port']) . '&vncticket=' . rawurlencode((string)$d['ticket']);
$configFile = rtrim($remoteDir, '/\\') . DIRECTORY_SEPARATOR . $sessionToken . '.json';
$readyFile = rtrim($remoteDir, '/\\') . DIRECTORY_SEPARATOR . $sessionToken . '.ready';
@unlink($readyFile);
$config = array(
    'listen_port' => $bridgePort,
    'session_token' => $sessionToken,
    'ready_file' => $readyFile,
    'upstream_host' => $ip,
    'upstream_port' => $port,
    'upstream_path' => $wsPath,
    'pve_auth_cookie' => (string)$auth['ticket'],
    'expires_at' => time() + 30,
    'max_runtime' => 14400
);
if (@file_put_contents($configFile, json_encode($config, JSON_UNESCAPED_SLASHES), LOCK_EX) === false) {
    proxv2_remote_error('Impossible de préparer le tunnel Remote.', 500);
}
@chmod($configFile, 0600);

if (!proxv2_remote_start_bridge($phpCli, $configFile)) {
    @unlink($configFile);
    proxv2_remote_error('Impossible de démarrer le tunnel Remote local. Vérifie que exec/shell_exec/proc_open est disponible pour PHP.', 501);
}

/*
 * IMPORTANT : ne jamais tester la disponibilité du bridge avec fsockopen().
 * Le bridge V2 est mono-client ; une sonde TCP consommerait la seule connexion
 * destinée à noVNC. Le processus CLI confirme donc son écoute via un fichier
 * éphémère .ready créé juste après le bind().
 */
$ready = false;
for ($i = 0; $i < 40; $i++) {
    usleep(50000);
    if (is_file($readyFile)) {
        $ready = true;
        break;
    }
}
if (!$ready) {
    @unlink($configFile);
    @unlink($readyFile);
    proxv2_remote_error('Le tunnel Remote ne s’est pas lancé sur le serveur DoMyDesk.', 502);
}

proxv2_log('remote_view', strtoupper($type) . ' #' . $vmid, 'success', 'Remote ProxV2 ouvert en lecture seule', array(
    'server_id' => $serverId,
    'node' => $node,
    'vmid' => $vmid,
    'type' => $type,
    'mode' => 'view-only'
));

$bridgeUrl = 'ws://' . (isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\\d+$/', '', (string)$_SERVER['HTTP_HOST']) : '127.0.0.1') . ':' . $bridgePort . '/' . $sessionToken;
$vncPassword = (string)$d['ticket'];
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="referrer" content="no-referrer">
<title>Remote lecture seule #<?= htmlspecialchars((string)$vmid, ENT_QUOTES, 'UTF-8') ?></title>
<style>
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#05070a;color:#e7edf6;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}
#screen{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;overflow:hidden;background:#000;pointer-events:none;user-select:none}
#screen canvas{max-width:100%!important;max-height:100%!important}
#bar{position:absolute;z-index:5;left:8px;right:8px;top:8px;display:flex;align-items:center;gap:8px;pointer-events:none}
.badge{padding:5px 8px;border-radius:999px;background:rgba(8,13,22,.88);border:1px solid rgba(255,255,255,.16);font-size:11px;font-weight:800;box-shadow:0 8px 24px rgba(0,0,0,.28)}
#state{margin-left:auto;color:#aab7c8;font-weight:650}
</style>
</head>
<body tabindex="-1">
<div id="screen"></div>
<div id="bar"><div class="badge">👁 Remote V2 · lecture seule</div><div class="badge">🔒 Clavier / souris · V3</div><div class="badge" id="state">Connexion…</div></div>
<script type="module">
import RFB from './novnc/core/rfb.js';

const screen = document.getElementById('screen');
const state = document.getElementById('state');
const url = <?= json_encode($bridgeUrl, JSON_UNESCAPED_SLASHES) ?>;
const password = <?= json_encode($vncPassword) ?>;

/* Blocage explicite des entrées locales de la V2. */
for (const eventName of ['keydown','keyup','keypress','beforeinput','paste','drop','contextmenu']) {
  window.addEventListener(eventName, (event) => { event.preventDefault(); event.stopImmediatePropagation(); }, true);
}

const rfb = new RFB(screen, url, { credentials: { password } });
rfb.viewOnly = true;
rfb.scaleViewport = true;
rfb.resizeSession = false;
rfb.clipViewport = false;
rfb.showDotCursor = false;

rfb.addEventListener('connect', () => { state.textContent = 'Connecté · clavier/souris bloqués'; });
rfb.addEventListener('disconnect', (event) => { state.textContent = event.detail && event.detail.clean ? 'Déconnecté' : 'Connexion interrompue'; });
rfb.addEventListener('credentialsrequired', () => { rfb.sendCredentials({ password }); });
rfb.addEventListener('securityfailure', () => { state.textContent = 'Authentification Remote refusée'; });
</script>
</body>
</html>
