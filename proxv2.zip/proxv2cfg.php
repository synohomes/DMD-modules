<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/proxv2_lib.php';

$CAN_SERVER_MANAGE = proxv2_user_can('server.manage');
$CAN_VM_CREATE = proxv2_user_can('vm.create');
$CAN_ISO_UPLOAD = proxv2_user_can('iso.upload');
$CAN_NETWORK_MANAGE = proxv2_user_can('network.manage');
$CAN_CFG_ACCESS = $CAN_SERVER_MANAGE || $CAN_VM_CREATE || $CAN_ISO_UPLOAD || $CAN_NETWORK_MANAGE;

if (!proxv2_has_module_access() || !$CAN_CFG_ACCESS) {
    http_response_code(403);
    echo "<div class='proxv2cfg-empty'>⛔ Aucune fonction de configuration ProxV2 ne vous a été attribuée.</div>";
    exit;
}

$csrf = proxv2_csrf_token();
$documentRoot = realpath(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '');
$moduleRealDir = realpath(__DIR__);
$proxv2CfgUrl = '/domydesk/modules/proxv2/proxv2cfg.php';
if ($documentRoot !== false && $moduleRealDir !== false && strpos($moduleRealDir, $documentRoot) === 0) {
    $rel = str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot)));
    $proxv2CfgUrl = '/' . trim($rel, '/') . '/proxv2cfg.php';
}
$proxv2BaseUrl = rtrim(str_replace('\\', '/', dirname($proxv2CfgUrl)), '/');

function proxv2cfg_require_csrf() {
    $token = isset($_POST['csrf']) ? $_POST['csrf'] : (isset($_GET['csrf']) ? $_GET['csrf'] : '');
    if (!proxv2_csrf_valid($token)) proxv2_json(false, 'Jeton de sécurité expiré.', array(), 403);
}

function proxv2cfg_public_server($server) {
    if (!is_array($server)) return array();
    unset($server['secret'], $server['secret_enc'], $server['remote_password_enc']);
    $fullServer = proxv2_load_server(isset($server['id']) ? $server['id'] : (isset($server['name']) ? $server['name'] : ''));
    $server['has_secret'] = proxv2_decrypt_secret($fullServer) !== '';
    $server['remote_ready'] = proxv2_decrypt_remote_password($fullServer) !== '';
    return $server;
}

function proxv2cfg_nodes($server) {
    $r = proxv2_api($server, 'nodes', 'GET', null, 12);
    if (!$r['ok'] || !is_array($r['data'])) return array();
    $out = array();
    foreach ($r['data'] as $n) {
        if (!is_array($n) || empty($n['node'])) continue;
        $out[] = array(
            'node' => (string)$n['node'],
            'status' => isset($n['status']) ? (string)$n['status'] : 'unknown',
            'cpu' => isset($n['cpu']) ? (float)$n['cpu'] : 0,
            'maxcpu' => isset($n['maxcpu']) ? (float)$n['maxcpu'] : 0,
            'mem' => isset($n['mem']) ? (float)$n['mem'] : 0,
            'maxmem' => isset($n['maxmem']) ? (float)$n['maxmem'] : 0
        );
    }
    return $out;
}

function proxv2cfg_node_exists($server, $node) {
    foreach (proxv2cfg_nodes($server) as $n) {
        if (strcasecmp((string)$n['node'], (string)$node) === 0) return true;
    }
    return false;
}

function proxv2cfg_upload_iso($server, $node, $storageId, $file) {
    if (!is_array($file) || (int)(isset($file['error']) ? $file['error'] : UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return array(false, 'Aucun fichier ISO valide reçu.');
    }
    $name = basename((string)$file['name']);
    if (strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'iso') return array(false, 'Seuls les fichiers .iso sont acceptés.');
    if (!is_uploaded_file($file['tmp_name'])) return array(false, 'Fichier temporaire invalide.');

    $ip = trim((string)(isset($server['ip']) ? $server['ip'] : ''));
    $port = (int)(isset($server['port']) ? $server['port'] : 8006);
    $token = trim((string)(isset($server['token_id']) ? $server['token_id'] : ''));
    $secret = proxv2_decrypt_secret($server);
    if ($ip === '' || $token === '' || $secret === '') return array(false, 'Configuration API incomplète.');

    $url = 'https://' . $ip . ':' . $port . '/api2/json/nodes/' . rawurlencode($node) . '/storage/' . rawurlencode($storageId) . '/upload';
    $mime = isset($file['type']) && $file['type'] !== '' ? $file['type'] : 'application/octet-stream';
    $cfile = new CURLFile($file['tmp_name'], $mime, $name);
    $post = array('content' => 'iso', 'filename' => $cfile);
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => array('Authorization: PVEAPIToken=' . $token . '=' . $secret),
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $post,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 0
    ));
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($raw === false || $err !== '') return array(false, $err !== '' ? $err : 'Erreur upload.');
    $json = json_decode($raw, true);
    if ($http < 200 || $http >= 300 || !is_array($json)) return array(false, 'HTTP ' . $http . ' - ' . $raw);
    return array(true, isset($json['data']) ? $json['data'] : 'Upload envoyé');
}

if (isset($_REQUEST['ajax'])) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    $ajax = strtolower(trim((string)$_REQUEST['ajax']));

    if ($ajax === 'servers') {
        $items = array();
        foreach (proxv2_list_servers(false) as $s) $items[] = proxv2cfg_public_server($s);
        proxv2_json(true, '', array('servers' => $items), 200);
    }

    if ($ajax === 'bootstrap_server') {
        proxv2cfg_require_csrf();
        if (!proxv2_user_can('server.manage')) proxv2_json(false, 'Droit de gestion serveur refusé.', array(), 403);

        $oldId = trim((string)(isset($_POST['old_id']) ? $_POST['old_id'] : ''));
        $name = trim((string)(isset($_POST['name']) ? $_POST['name'] : ''));
        $ip = trim((string)(isset($_POST['ip']) ? $_POST['ip'] : ''));
        $port = (int)(isset($_POST['port']) ? $_POST['port'] : 8006);
        $adminUser = trim((string)(isset($_POST['admin_user']) ? $_POST['admin_user'] : 'root@pam'));
        $adminPassword = (string)(isset($_POST['admin_password']) ? $_POST['admin_password'] : '');

        if ($name === '' || $ip === '' || $adminUser === '' || $adminPassword === '') {
            proxv2_json(false, 'Nom, IP/DNS, utilisateur administrateur et mot de passe sont obligatoires.', array(), 400);
        }
        if (strpos($adminUser, '@') === false) $adminUser .= '@pam';
        if ($port <= 0 || $port > 65535) $port = 8006;
        $id = proxv2_slug($name);
        if ($id === '') proxv2_json(false, 'Nom de serveur invalide.', array(), 400);

        $existing = $oldId !== '' ? proxv2_load_server($oldId) : proxv2_load_server($id);
        if ($oldId === '' && is_array($existing)) {
            proxv2_json(false, 'Un serveur portant ce nom existe déjà. Sélectionne-le pour renouveler son accès.', array(), 409);
        }

        /*
         * Une nouvelle intégration reçoit une identité technique unique.
         * Lors d'un renouvellement, on conserve l'identité déjà enregistrée
         * pour ne pas créer de compte/token orphelin.
         */
        $preferredServiceUser = is_array($existing) && !empty($existing['proxmox_user']) ? (string)$existing['proxmox_user'] : '';
        $preferredTokenName = is_array($existing) ? proxv2_token_name(isset($existing['token_id']) ? $existing['token_id'] : '') : '';
        $bootstrap = proxv2_bootstrap_api_access($ip, $port, $adminUser, $adminPassword, $preferredServiceUser, $preferredTokenName);
        /* Ne jamais conserver le mot de passe administrateur au-delà du bootstrap. */
        $adminPassword = null;
        unset($_POST['admin_password']);

        if (empty($bootstrap['ok'])) {
            proxv2_log('server_bootstrap', $name, 'error', 'Création automatique de l’accès ProxV2 en erreur', array(
                'server_id' => $id,
                'ip' => $ip,
                'port' => $port,
                'error' => isset($bootstrap['error']) ? $bootstrap['error'] : 'Erreur inconnue'
            ));
            proxv2_json(false, isset($bootstrap['error']) ? $bootstrap['error'] : 'Configuration automatique impossible.', array(), 502);
        }

        $secretEnc = proxv2_encrypt_secret((string)$bootstrap['secret']);
        if ($secretEnc === '') proxv2_json(false, 'Token créé sur Proxmox mais chiffrement local du secret impossible.', array(), 500);
        $remotePasswordEnc = proxv2_encrypt_secret((string)(isset($bootstrap['remote_password']) ? $bootstrap['remote_password'] : ''));
        if ($remotePasswordEnc === '') proxv2_json(false, 'Compte Remote créé sur Proxmox mais chiffrement local de son secret impossible.', array(), 500);

        $data = is_array($existing) ? $existing : array();
        $data['id'] = $id;
        $data['name'] = $name;
        $data['ip'] = $ip;
        $data['port'] = $port;
        $data['token_id'] = (string)$bootstrap['token_id'];
        $data['secret_enc'] = $secretEnc;
        $data['remote_password_enc'] = $remotePasswordEnc;
        $data['proxmox_user'] = (string)$bootstrap['user'];
        $data['proxmox_role'] = (string)$bootstrap['role'];
        $data['provisioning'] = 'automatic';
        unset($data['secret']);
        if (empty($data['created'])) $data['created'] = date('c');
        $data['updated'] = date('c');

        if (!proxv2_save_server($data, $oldId)) {
            proxv2_json(false, 'Accès créé sur Proxmox mais écriture de la configuration DoMyDesk impossible.', array(), 500);
        }

        /* Vérifie immédiatement que ProxV2 fonctionne bien avec le nouveau token, jamais avec root. */
        $verify = proxv2_api($data, 'version', 'GET', null, 10);
        $verified = !empty($verify['ok']);
        proxv2_log('server_bootstrap', $name, $verified ? 'success' : 'warning', $verified ? 'Compte technique et API Token ProxV2 uniques créés automatiquement' : 'Accès ProxV2 créé, mais le test final du token a échoué', array(
            'server_id' => $id,
            'ip' => $ip,
            'port' => $port,
            'proxmox_user' => (string)$bootstrap['user'],
            'token_id' => (string)$bootstrap['token_id'],
            'role' => (string)$bootstrap['role'],
            'created_user' => !empty($bootstrap['created_user']),
            'renewed_token' => !empty($bootstrap['renewed_token']),
            'verified' => $verified,
            'verify_error' => $verified ? '' : (isset($verify['error']) ? $verify['error'] : '')
        ));

        $message = $verified
            ? 'Configuration terminée : ' . (string)$bootstrap['user'] . ' + ' . (string)$bootstrap['token_id'] . ' créés et connexion validée.'
            : 'Utilisateur et token uniques créés/enregistrés, mais le test final a échoué : ' . (isset($verify['error']) ? $verify['error'] : 'erreur inconnue');
        proxv2_json(true, $message, array(
            'server' => proxv2cfg_public_server($data),
            'verified' => $verified,
            'proxmox_user' => (string)$bootstrap['user'],
            'token_id' => (string)$bootstrap['token_id'],
            'role' => (string)$bootstrap['role']
        ), 200);
    }

    if ($ajax === 'save_server') {
        proxv2cfg_require_csrf();
        if (!proxv2_user_can('server.manage')) proxv2_json(false, 'Droit de gestion serveur refusé.', array(), 403);
        $oldId = trim((string)(isset($_POST['old_id']) ? $_POST['old_id'] : ''));
        $name = trim((string)(isset($_POST['name']) ? $_POST['name'] : ''));
        $ip = trim((string)(isset($_POST['ip']) ? $_POST['ip'] : ''));
        $port = (int)(isset($_POST['port']) ? $_POST['port'] : 8006);
        $token = trim((string)(isset($_POST['token_id']) ? $_POST['token_id'] : ''));
        $secret = trim((string)(isset($_POST['secret']) ? $_POST['secret'] : ''));
        if ($name === '' || $ip === '' || $token === '') proxv2_json(false, 'Nom, IP/DNS et Token ID sont obligatoires.', array(), 400);
        if ($port <= 0 || $port > 65535) $port = 8006;
        $id = proxv2_slug($name);
        if ($id === '') proxv2_json(false, 'Nom de serveur invalide.', array(), 400);
        $existing = $oldId !== '' ? proxv2_load_server($oldId) : proxv2_load_server($id);
        if ($oldId === '' && is_array($existing)) proxv2_json(false, 'Un serveur portant ce nom existe déjà.', array(), 409);
        $data = is_array($existing) ? $existing : array();
        $data['id'] = $id;
        $data['name'] = $name;
        $data['ip'] = $ip;
        $data['port'] = $port;
        $data['token_id'] = $token;
        if ($secret !== '') {
            $enc = proxv2_encrypt_secret($secret);
            if ($enc === '') proxv2_json(false, 'Impossible de chiffrer le secret API.', array(), 500);
            $data['secret_enc'] = $enc;
            unset($data['secret']);
        } elseif (empty($data['secret_enc']) && empty($data['secret'])) {
            proxv2_json(false, 'Secret API obligatoire pour un nouveau serveur.', array(), 400);
        }
        if (empty($data['created'])) $data['created'] = date('c');
        $data['updated'] = date('c');
        if (!proxv2_save_server($data, $oldId)) proxv2_json(false, 'Écriture de la configuration impossible.', array(), 500);
        proxv2_log('server_save', $name, 'success', $existing ? 'Serveur Proxmox modifié' : 'Serveur Proxmox ajouté', array('server_id' => $id, 'ip' => $ip, 'port' => $port, 'token_id' => $token, 'secret_changed' => $secret !== ''));
        proxv2_json(true, 'Serveur enregistré.', array('server' => proxv2cfg_public_server($data)), 200);
    }

    if ($ajax === 'delete_server') {
        proxv2cfg_require_csrf();
        if (!proxv2_user_can('server.manage')) proxv2_json(false, 'Droit de gestion serveur refusé.', array(), 403);
        $id = trim((string)(isset($_POST['server_id']) ? $_POST['server_id'] : ''));
        $server = proxv2_load_server($id);
        if (!is_array($server)) proxv2_json(false, 'Serveur introuvable.', array(), 404);

        /*
         * Pour une configuration automatique, on révoque D'ABORD l'accès
         * créé par ProxV2 sur Proxmox. Si la révocation échoue, le JSON local
         * est conservé : on n'oublie jamais silencieusement un token actif.
         *
         * Les tokens ajoutés manuellement ne sont jamais supprimés à distance,
         * car ils peuvent être utilisés par autre chose que DoMyDesk.
         */
        $cleanup = proxv2_cleanup_automatic_access($server);
        if (empty($cleanup['ok'])) {
            proxv2_log('server_delete', isset($server['name']) ? $server['name'] : $id, 'error', 'Suppression ProxV2 annulée : révocation distante impossible', array(
                'server_id' => $id,
                'ip' => isset($server['ip']) ? $server['ip'] : '',
                'error' => isset($cleanup['error']) ? $cleanup['error'] : 'Erreur inconnue'
            ));
            proxv2_json(false, isset($cleanup['error']) ? $cleanup['error'] : 'Révocation distante impossible.', array(), 502);
        }

        $file = proxv2_server_file(isset($server['id']) ? $server['id'] : $id);
        $cache = proxv2_cache_file($server);
        $ok = is_file($file) ? @unlink($file) : false;
        if (is_file($cache)) @unlink($cache);
        if (!$ok) proxv2_json(false, 'Accès distant révoqué, mais suppression locale impossible.', array(), 500);

        $warning = isset($cleanup['warning']) ? trim((string)$cleanup['warning']) : '';
        $manual = !empty($cleanup['skipped']);
        $message = $manual
            ? 'Serveur supprimé de DoMyDesk. Le token manuel Proxmox n’a pas été touché.'
            : 'Serveur supprimé et accès ProxV2 révoqué sur Proxmox.';
        if ($warning !== '') $message .= ' ' . $warning;

        proxv2_log('server_delete', isset($server['name']) ? $server['name'] : $id, 'success', 'Serveur Proxmox supprimé', array(
            'server_id' => $id,
            'ip' => isset($server['ip']) ? $server['ip'] : '',
            'remote_cleanup' => !$manual,
            'token_deleted' => !empty($cleanup['token_deleted']),
            'user_deleted' => !empty($cleanup['user_deleted']),
            'warning' => $warning
        ));
        proxv2_json(true, $message, array(
            'token_deleted' => !empty($cleanup['token_deleted']),
            'user_deleted' => !empty($cleanup['user_deleted']),
            'manual_token_untouched' => $manual
        ), 200);
    }

    $serverId = trim((string)(isset($_REQUEST['server_id']) ? $_REQUEST['server_id'] : (isset($_REQUEST['srv']) ? $_REQUEST['srv'] : '')));
    $server = proxv2_load_server($serverId);
    if (!is_array($server)) proxv2_json(false, 'Serveur Proxmox introuvable.', array(), 404);

    if ($ajax === 'test') {
        if (!proxv2_user_can('server.manage')) proxv2_json(false, 'Droit de gestion serveur refusé.', array(), 403);
        $v = proxv2_api($server, 'version', 'GET', null, 10);
        $nodes = proxv2cfg_nodes($server);
        if (!$v['ok']) proxv2_json(false, $v['error'], array(), 502);
        proxv2_json(true, 'Connexion Proxmox OK.', array('version' => $v['data'], 'nodes' => $nodes), 200);
    }

    if ($ajax === 'context') {
        $nodes = proxv2cfg_nodes($server);
        $vms = proxv2_cluster_vms($server);
        $nextid = proxv2_next_vmid($server);
        proxv2_json(true, '', array('nodes' => $nodes, 'vms' => $vms['ok'] ? $vms['data'] : array(), 'nextid' => $nextid), 200);
    }

    if ($ajax === 'node_data') {
        $node = trim((string)(isset($_GET['node']) ? $_GET['node'] : ''));
        if ($node === '' || !proxv2cfg_node_exists($server, $node)) proxv2_json(false, 'Node Proxmox invalide.', array(), 400);
        $storagesRes = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/storage', 'GET', null, 12);
        $networkRes = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/network', 'GET', null, 12);
        $storages = $storagesRes['ok'] && is_array($storagesRes['data']) ? $storagesRes['data'] : array();
        $network = $networkRes['ok'] && is_array($networkRes['data']) ? $networkRes['data'] : array();
        $isos = array();
        foreach ($storages as $st) {
            $sid = isset($st['storage']) ? (string)$st['storage'] : '';
            if ($sid === '') continue;
            $content = isset($st['content']) ? (string)$st['content'] : '';
            if (strpos($content, 'iso') === false) continue;
            $r = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/storage/' . rawurlencode($sid) . '/content', 'GET', null, 12);
            if (!$r['ok'] || !is_array($r['data'])) continue;
            foreach ($r['data'] as $item) {
                if (!is_array($item) || (isset($item['content']) ? $item['content'] : '') !== 'iso') continue;
                $isos[] = array('volid' => isset($item['volid']) ? $item['volid'] : '', 'storage' => $sid, 'size' => isset($item['size']) ? $item['size'] : 0);
            }
        }
        $bridges = array();
        $vlans = array();
        foreach ($network as $net) {
            if (!is_array($net)) continue;
            if ((isset($net['type']) ? $net['type'] : '') === 'bridge' && !empty($net['iface'])) $bridges[] = $net['iface'];
            if (isset($net['tag']) && is_numeric($net['tag'])) $vlans[] = (int)$net['tag'];
            $iface = isset($net['iface']) ? (string)$net['iface'] : '';
            if (preg_match('/vlan(\d+)/i', $iface, $m)) $vlans[] = (int)$m[1];
            if (preg_match('/\.(\d{1,4})$/', $iface, $m)) $vlans[] = (int)$m[1];
        }
        $bridges = array_values(array_unique($bridges));
        $vlans = array_values(array_unique(array_filter($vlans, function($v) { return $v >= 1 && $v <= 4094; })));
        sort($vlans, SORT_NUMERIC);
        proxv2_json(true, '', array('storages' => $storages, 'isos' => $isos, 'bridges' => $bridges, 'vlans' => $vlans), 200);
    }

    if ($ajax === 'create_vm') {
        proxv2cfg_require_csrf();
        if (!proxv2_user_can('vm.create')) proxv2_json(false, 'Droit de création VM refusé.', array(), 403);
        $node = trim((string)(isset($_POST['node']) ? $_POST['node'] : ''));
        if ($node === '' || !proxv2cfg_node_exists($server, $node)) proxv2_json(false, 'Node Proxmox invalide.', array(), 400);
        $vmidRaw = trim((string)(isset($_POST['vmid']) ? $_POST['vmid'] : ''));
        $vmid = $vmidRaw === '' ? proxv2_next_vmid($server) : (int)$vmidRaw;
        if ($vmid < 100 || $vmid > 999999999) proxv2_json(false, 'VMID invalide.', array(), 400);
        if (proxv2_resolve_vm($server, $vmid, '') !== null) proxv2_json(false, 'Le VMID ' . $vmid . ' existe déjà sur ce Proxmox.', array(), 409);
        $name = trim((string)(isset($_POST['vmname']) ? $_POST['vmname'] : ''));
        $cpu = max(1, min(128, (int)(isset($_POST['cpu']) ? $_POST['cpu'] : 2)));
        $ram = max(128, (int)(isset($_POST['ram']) ? $_POST['ram'] : 2048));
        $disk = max(1, (int)(isset($_POST['disk']) ? $_POST['disk'] : 20));
        $iso = trim((string)(isset($_POST['iso']) ? $_POST['iso'] : ''));
        $bridge = trim((string)(isset($_POST['bridge']) ? $_POST['bridge'] : 'vmbr0'));
        $vlan = (int)(isset($_POST['vlan']) ? $_POST['vlan'] : 0);
        $ostype = trim((string)(isset($_POST['ostype']) ? $_POST['ostype'] : 'l26'));
        $storageVm = trim((string)(isset($_POST['storage_vm']) ? $_POST['storage_vm'] : 'local-lvm'));
        if ($name === '' || $storageVm === '' || $bridge === '') proxv2_json(false, 'Nom, stockage VM et bridge sont obligatoires.', array(), 400);
        if ($vlan < 0 || $vlan > 4094) proxv2_json(false, 'VLAN invalide.', array(), 400);
        $payload = array(
            'vmid' => $vmid,
            'name' => $name,
            'sockets' => 1,
            'cores' => $cpu,
            'memory' => $ram,
            'scsihw' => 'virtio-scsi-pci',
            'scsi0' => $storageVm . ':' . $disk,
            'net0' => 'virtio,bridge=' . $bridge . ($vlan > 0 ? ',tag=' . $vlan : ''),
            'ostype' => $ostype,
            'agent' => 1
        );
        if ($iso !== '') $payload['ide2'] = $iso . ',media=cdrom';
        $res = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/qemu', 'POST', $payload, 30);
        if (!$res['ok']) {
            proxv2_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'error', 'Création VM en erreur', array('server_id' => $serverId, 'node' => $node, 'vmid' => $vmid, 'error' => $res['error']));
            proxv2_json(false, $res['error'], array('vmid' => $vmid), $res['http'] >= 400 ? $res['http'] : 502);
        }
        proxv2_log('vm_create', 'QEMU #' . $vmid . ' ' . $name, 'success', 'VM créée sur Proxmox', array('server_id' => $serverId, 'node' => $node, 'vmid' => $vmid, 'storage' => $storageVm, 'iso' => $iso, 'upid' => $res['data']));
        proxv2_json(true, 'VM #' . $vmid . ' créée sur ' . $node . '.', array('vmid' => $vmid, 'node' => $node, 'upid' => $res['data']), 200);
    }

    if ($ajax === 'upload_iso') {
        proxv2cfg_require_csrf();
        if (!proxv2_user_can('iso.upload')) proxv2_json(false, 'Droit d’upload ISO refusé.', array(), 403);
        $node = trim((string)(isset($_POST['node']) ? $_POST['node'] : ''));
        $storageId = trim((string)(isset($_POST['storage_id']) ? $_POST['storage_id'] : ''));
        if ($node === '' || $storageId === '' || !proxv2cfg_node_exists($server, $node)) proxv2_json(false, 'Node ou stockage invalide.', array(), 400);
        list($ok, $msg) = proxv2cfg_upload_iso($server, $node, $storageId, isset($_FILES['iso_file']) ? $_FILES['iso_file'] : null);
        if (!$ok) proxv2_json(false, $msg, array(), 502);
        proxv2_log('iso_upload', isset($_FILES['iso_file']['name']) ? basename($_FILES['iso_file']['name']) : 'ISO', 'success', 'ISO envoyée vers Proxmox', array('server_id' => $serverId, 'node' => $node, 'storage' => $storageId, 'upid' => $msg));
        proxv2_json(true, 'Upload ISO envoyé à Proxmox.', array('upid' => $msg), 200);
    }

    proxv2_json(false, 'Opération inconnue.', array(), 400);
}

$serversPublic = array();
foreach (proxv2_list_servers(false) as $s) $serversPublic[] = proxv2cfg_public_server($s);
?>
<link rel="stylesheet" href="<?= htmlspecialchars($proxv2BaseUrl . '/proxv2cfg.css?v=1', ENT_QUOTES, 'UTF-8') ?>">
<div class="proxv2cfg" data-proxv2cfg data-api="<?= htmlspecialchars($proxv2CfgUrl, ENT_QUOTES, 'UTF-8') ?>" data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" data-can-server-manage="<?= $CAN_SERVER_MANAGE ? '1' : '0' ?>" data-can-vm-create="<?= $CAN_VM_CREATE ? '1' : '0' ?>" data-can-iso-upload="<?= $CAN_ISO_UPLOAD ? '1' : '0' ?>" data-can-network-manage="<?= $CAN_NETWORK_MANAGE ? '1' : '0' ?>">
  <header class="proxv2cfg-head">
    <div>
      <span class="proxv2cfg-kicker">Module système · DoMyDesk 1.2.x</span>
      <h3>ProxV2 · Administration Proxmox</h3>
      <p>Serveurs, nodes, VMID, stockage, ISO et réseau sont maintenant traités comme des objets distincts.</p>
    </div>
    <?php if ($CAN_SERVER_MANAGE): ?><button type="button" class="proxv2cfg-btn" data-new-server>+ Serveur</button><?php endif; ?>
  </header>

  <div class="proxv2cfg-grid">
    <aside class="proxv2cfg-side">
      <div class="proxv2cfg-side-title"><strong>Serveurs Proxmox</strong><span data-server-count><?= count($serversPublic) ?></span></div>
      <div class="proxv2cfg-server-list" data-server-list></div>
    </aside>

    <main class="proxv2cfg-main">
      <section class="proxv2cfg-panel"<?= $CAN_SERVER_MANAGE ? '' : ' hidden' ?>>
        <div class="proxv2cfg-panel-head"><div><h4>Connexion API</h4><p>Pour un homelab, ProxV2 peut créer lui-même <code>domydesk@pve</code> et son API Token. Le mot de passe administrateur n’est jamais enregistré.</p></div><span data-api-state class="proxv2cfg-badge">Non testé</span></div>
        <form data-server-form>
          <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" name="old_id" data-old-id>
          <div class="proxv2cfg-fields">
            <label><span>Nom</span><input name="name" data-name required placeholder="PVE-PROD"></label>
            <label><span>IP / DNS</span><input name="ip" data-ip required placeholder="10.10.3.20"></label>
            <label><span>Port</span><input type="number" name="port" data-port value="8006" min="1" max="65535"></label>
          </div>

          <div class="proxv2cfg-actions">
            <button class="proxv2cfg-btn" type="button" data-mode-auto>Configuration automatique</button>
            <button class="proxv2cfg-btn" type="button" data-mode-manual>J’ai déjà un API Token</button>
          </div>

          <div data-auto-fields>
            <div class="proxv2cfg-fields">
              <label><span>Utilisateur administrateur Proxmox</span><input name="admin_user" data-admin-user value="root@pam" autocomplete="username" placeholder="root@pam"></label>
              <label><span>Mot de passe administrateur</span><input type="password" name="admin_password" data-admin-password autocomplete="current-password" placeholder="Utilisé une seule fois"></label>
            </div>
            <p class="proxv2cfg-muted">ProxV2 se connecte une seule fois avec ce compte, crée <strong>domydesk@pve</strong>, lui attribue <strong>Administrator</strong>, crée <strong>domydesk@pve!proxv2</strong>, puis n’utilise plus que ce token.</p>
          </div>

          <div data-manual-fields hidden>
            <div class="proxv2cfg-fields">
              <label><span>Token ID</span><input name="token_id" data-token placeholder="user@pve!domydesk"></label>
              <label><span>Secret API</span><input type="password" name="secret" data-secret autocomplete="new-password" placeholder="Vide = conserver le secret déjà enregistré"></label>
            </div>
          </div>

          <div class="proxv2cfg-actions">
            <button class="proxv2cfg-btn" type="button" data-bootstrap-server>Créer l’accès ProxV2</button>
            <button class="proxv2cfg-btn" type="submit" data-manual-save hidden>Enregistrer le token</button>
            <button class="proxv2cfg-btn" type="button" data-test-server>Tester</button>
            <button class="proxv2cfg-btn danger" type="button" data-delete-server hidden>Supprimer</button>
          </div>
          <div class="proxv2cfg-msg" data-server-msg></div>
        </form>
      </section>

      <section class="proxv2cfg-panel" data-vm-panel hidden>
        <div class="proxv2cfg-panel-head">
          <div><h4>Créer une VM QEMU</h4><p>Si tu saisis un VMID, ProxV2 l’utilise exactement. Si tu le laisses vide, Proxmox fournit le prochain ID libre.</p></div>
          <span class="proxv2cfg-badge" data-nextid>VMID —</span>
        </div>
        <form data-vm-form>
          <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <div class="proxv2cfg-fields">
            <label><span>Node Proxmox</span><select name="node" data-node required></select></label>
            <label><span>VMID</span><input type="number" name="vmid" data-vmid min="100" placeholder="Auto"></label>
            <label><span>Nom VM</span><input name="vmname" required placeholder="VM-SQL01"></label>
            <label><span>Type système</span><select name="ostype"><option value="l26">Linux</option><option value="win11">Windows 11 / récent</option><option value="win10">Windows 10</option><option value="other">Autre</option></select></label>
            <label><span>CPU</span><input type="number" name="cpu" value="2" min="1" max="128"></label>
            <label><span>RAM (Mo)</span><input type="number" name="ram" value="2048" min="128" step="128"></label>
            <label><span>Disque (Go)</span><input type="number" name="disk" value="20" min="1"></label>
            <label><span>Stockage VM</span><select name="storage_vm" data-storage-vm required></select></label>
            <label><span>ISO</span><select name="iso" data-iso><option value="">Aucune ISO</option></select></label>
            <label><span>Bridge</span><select name="bridge" data-bridge required></select></label>
            <label><span>VLAN</span><select name="vlan" data-vlan><option value="">Aucun VLAN</option></select></label>
          </div>
          <div class="proxv2cfg-actions"><button class="proxv2cfg-btn" type="submit">Créer la VM</button></div>
          <div class="proxv2cfg-msg" data-vm-msg></div>
        </form>
      </section>

      <section class="proxv2cfg-panel" data-iso-panel hidden>
        <div class="proxv2cfg-panel-head"><div><h4>ISO</h4><p>Upload vers le node et le stockage ISO sélectionnés.</p></div></div>
        <form data-iso-form enctype="multipart/form-data">
          <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <div class="proxv2cfg-fields">
            <label><span>Node</span><select name="node" data-iso-node required></select></label>
            <label><span>Stockage ISO</span><select name="storage_id" data-storage-iso required></select></label>
            <label class="proxv2cfg-wide"><span>Fichier ISO</span><input type="file" name="iso_file" accept=".iso,application/octet-stream" required></label>
          </div>
          <div class="proxv2cfg-actions"><button class="proxv2cfg-btn" type="submit">Envoyer l’ISO</button></div>
          <div class="proxv2cfg-msg" data-iso-msg></div>
        </form>
      </section>

      <section class="proxv2cfg-panel" data-vm-list-panel hidden>
        <div class="proxv2cfg-panel-head"><div><h4>VM & conteneurs détectés</h4><p>Vue cluster : le node réel est conservé avec chaque VMID.</p></div><span class="proxv2cfg-badge" data-vm-count>0</span></div>
        <div class="proxv2cfg-table-wrap"><table><thead><tr><th>VMID</th><th>Type</th><th>Nom</th><th>Node</th><th>État</th></tr></thead><tbody data-vm-list></tbody></table></div>
      </section>
    </main>
  </div>
</div>

<script>
(function(){
  const root=document.querySelector('[data-proxv2cfg]'); if(!root || root.dataset.ready==='1') return; root.dataset.ready='1';
  const csrf=root.dataset.csrf||''; const apiUrl=root.dataset.api||'/domydesk/modules/proxv2/proxv2cfg.php';
  const canServerManage=root.dataset.canServerManage==='1';
  const canVmCreate=root.dataset.canVmCreate==='1';
  const canIsoUpload=root.dataset.canIsoUpload==='1';
  const canNetworkManage=root.dataset.canNetworkManage==='1';
  let servers=<?= json_encode($serversPublic, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  let current=null, context=null, nodeData=null, connectionMode='auto';
  const q=s=>root.querySelector(s);
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const msg=(el,text,ok)=>{if(!el)return;el.textContent=text||'';el.dataset.ok=ok?'1':'0';};

  async function api(action, opts={}){
    const method=opts.method||'GET'; const params=opts.params||{}; const body=opts.body||null;
    const url=new URL(apiUrl, window.location.origin);
    url.searchParams.set('ajax',action); Object.entries(params).forEach(([k,v])=>url.searchParams.set(k,v));
    const r=await fetch(url.toString(),{method,credentials:'same-origin',body});
    const t=await r.text(); let j; try{j=JSON.parse(t)}catch(e){throw new Error('Réponse invalide : '+t.slice(0,180))}
    if(!r.ok || !j.ok) throw new Error(j.message||('HTTP '+r.status)); return j;
  }

  function renderServers(){
    q('[data-server-count]').textContent=servers.length;
    q('[data-server-list]').innerHTML=servers.length?servers.map(s=>`<button type="button" class="proxv2cfg-server ${current&&current.id===s.id?'active':''}" data-server-id="${esc(s.id)}"><strong>${esc(s.name)}</strong><small>${esc(s.ip)}:${esc(s.port||8006)}</small></button>`).join(''):'<p class="proxv2cfg-muted">Aucun serveur.</p>';
  }
  function setConnectionMode(mode){
    connectionMode=mode==='manual'?'manual':'auto';
    q('[data-auto-fields]').hidden=connectionMode!=='auto';
    q('[data-manual-fields]').hidden=connectionMode!=='manual';
    q('[data-bootstrap-server]').hidden=connectionMode!=='auto';
    q('[data-manual-save]').hidden=connectionMode!=='manual';
    q('[data-mode-auto]').disabled=connectionMode==='auto';
    q('[data-mode-manual]').disabled=connectionMode==='manual';
  }
  function resetServerForm(){
    current=null; context=null; nodeData=null; q('[data-server-form]').reset(); q('[data-old-id]').value=''; q('[data-port]').value='8006'; q('[data-admin-user]').value='root@pam'; q('[data-delete-server]').hidden=true; q('[data-api-state]').textContent='Non testé'; setConnectionMode('auto');
    ['[data-vm-panel]','[data-iso-panel]','[data-vm-list-panel]'].forEach(s=>q(s).hidden=true); renderServers();
  }
  function fillServer(s){
    current=s; q('[data-old-id]').value=s.id||''; q('[data-name]').value=s.name||''; q('[data-ip]').value=s.ip||''; q('[data-port]').value=s.port||8006; q('[data-token]').value=s.token_id||''; q('[data-secret]').value=''; q('[data-admin-password]').value=''; q('[data-delete-server]').hidden=!canServerManage; q('[data-api-state]').textContent=s.has_secret?'API configurée':'Secret manquant'; setConnectionMode('manual'); renderServers(); loadContext();
  }
  async function refreshServers(selectId){
    const j=await api('servers'); servers=j.servers||[]; renderServers(); if(selectId){const s=servers.find(x=>x.id===selectId); if(s)fillServer(s);}
  }
  async function loadContext(){
    if(!current)return; msg(q('[data-server-msg]'),'Chargement du cluster…',true);
    try{
      const j=await api('context',{params:{server_id:current.id}}); context=j;
      const nodes=j.nodes||[]; const opts=nodes.map(n=>`<option value="${esc(n.node)}">${esc(n.node)} · ${esc(n.status)}</option>`).join('');
      q('[data-node]').innerHTML=opts; q('[data-iso-node]').innerHTML=opts; q('[data-nextid]').textContent='Prochain VMID '+(j.nextid||'—'); q('[data-vmid]').placeholder=j.nextid?String(j.nextid):'Auto';
      const vms=j.vms||[]; q('[data-vm-count]').textContent=vms.length; q('[data-vm-list]').innerHTML=vms.length?vms.sort((a,b)=>(a.vmid||0)-(b.vmid||0)).map(v=>`<tr><td>#${esc(v.vmid)}</td><td>${esc((v.type||'qemu').toUpperCase())}</td><td>${esc(v.name||'')}</td><td>${esc(v.node||'')}</td><td>${esc(v.status||'')}</td></tr>`).join(''):'<tr><td colspan="5">Aucune VM/CT.</td></tr>';
      q('[data-vm-panel]').hidden=!canVmCreate||!nodes.length; q('[data-iso-panel]').hidden=!canIsoUpload||!nodes.length; q('[data-vm-list-panel]').hidden=false; msg(q('[data-server-msg]'),'Cluster chargé.',true); if(nodes.length&&(canVmCreate||canIsoUpload||canNetworkManage))await loadNode(nodes[0].node);
    }catch(e){msg(q('[data-server-msg]'),e.message,false)}
  }
  async function loadNode(node){
    if(!current||!node)return; try{
      const j=await api('node_data',{params:{server_id:current.id,node}}); nodeData=j;
      const stores=j.storages||[]; const vmStores=stores.filter(s=>{const c=String(s.content||'');return c.includes('images')||c==='';}); const isoStores=stores.filter(s=>String(s.content||'').includes('iso'));
      q('[data-storage-vm]').innerHTML=vmStores.map(s=>`<option value="${esc(s.storage)}">${esc(s.storage)} · ${esc(s.type||'')}</option>`).join(''); q('[data-storage-iso]').innerHTML=isoStores.map(s=>`<option value="${esc(s.storage)}">${esc(s.storage)} · ${esc(s.type||'')}</option>`).join('');
      q('[data-iso]').innerHTML='<option value="">Aucune ISO</option>'+((j.isos||[]).map(i=>`<option value="${esc(i.volid)}">${esc(i.volid)}</option>`).join(''));
      q('[data-bridge]').innerHTML=(j.bridges||[]).map(b=>`<option value="${esc(b)}">${esc(b)}</option>`).join(''); q('[data-vlan]').innerHTML='<option value="">Aucun VLAN</option>'+((j.vlans||[]).map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join(''));
      q('[data-iso-node]').value=node;
    }catch(e){msg(q('[data-vm-msg]'),e.message,false)}
  }

  root.addEventListener('click',e=>{
    const s=e.target.closest('[data-server-id]'); if(s){const item=servers.find(x=>x.id===s.dataset.serverId); if(item)fillServer(item);return;}
    if(e.target.closest('[data-new-server]')){if(canServerManage)resetServerForm();return;}
    if(e.target.closest('[data-mode-auto]')){setConnectionMode('auto');return;}
    if(e.target.closest('[data-mode-manual]')){setConnectionMode('manual');return;}
  });
  q('[data-node]').addEventListener('change',e=>loadNode(e.target.value));
  q('[data-iso-node]').addEventListener('change',e=>{q('[data-node]').value=e.target.value;loadNode(e.target.value)});

  q('[data-bootstrap-server]').addEventListener('click',async()=>{if(!canServerManage)return;
    const form=q('[data-server-form]'); const f=new FormData(form); f.set('csrf',csrf);
    const pwd=q('[data-admin-password]'); const button=q('[data-bootstrap-server]');
    if(!String(f.get('name')||'').trim()||!String(f.get('ip')||'').trim()||!String(f.get('admin_user')||'').trim()||!String(f.get('admin_password')||'')){msg(q('[data-server-msg]'),'Renseigne le serveur, le compte administrateur Proxmox et son mot de passe.',false);return;}
    button.disabled=true; msg(q('[data-server-msg]'),'Connexion à Proxmox → création d’un compte technique unique → création du token unique…',true);
    try{
      const j=await api('bootstrap_server',{method:'POST',body:f});
      if(pwd)pwd.value='';
      await refreshServers(j.server.id);
      q('[data-api-state]').textContent=j.verified?'API OK':'À vérifier';
      msg(q('[data-server-msg]'),j.message,!!j.verified);
    }catch(err){if(pwd)pwd.value='';msg(q('[data-server-msg]'),err.message,false)}finally{button.disabled=false}
  });
  q('[data-server-form]').addEventListener('submit',async e=>{e.preventDefault();if(!canServerManage||connectionMode!=='manual')return;const f=new FormData(e.currentTarget);f.set('csrf',csrf);try{const j=await api('save_server',{method:'POST',body:f});msg(q('[data-server-msg]'),j.message,true);await refreshServers(j.server.id)}catch(err){msg(q('[data-server-msg]'),err.message,false)}});
  q('[data-test-server]').addEventListener('click',async()=>{if(!canServerManage)return;if(!current){msg(q('[data-server-msg]'),'Enregistre d’abord le serveur.',false);return}try{const j=await api('test',{params:{server_id:current.id}});q('[data-api-state]').textContent='API OK';msg(q('[data-server-msg]'),j.message,true)}catch(e){q('[data-api-state]').textContent='Erreur API';msg(q('[data-server-msg]'),e.message,false)}});
  q('[data-delete-server]').addEventListener('click',async()=>{if(!canServerManage)return;if(!current||!confirm('Supprimer '+current.name+' de ProxV2 ?\n\nSi cet accès a été créé automatiquement, son token API et son compte technique seront également révoqués sur Proxmox.'))return;const f=new FormData();f.set('csrf',csrf);f.set('server_id',current.id);try{const j=await api('delete_server',{method:'POST',body:f});msg(q('[data-server-msg]'),j.message,true);await refreshServers();resetServerForm()}catch(e){msg(q('[data-server-msg]'),e.message,false)}});
  q('[data-vm-form]').addEventListener('submit',async e=>{e.preventDefault();if(!canVmCreate||!current)return;const f=new FormData(e.currentTarget);f.set('csrf',csrf);f.set('server_id',current.id);msg(q('[data-vm-msg]'),'Création en cours…',true);try{const j=await api('create_vm',{method:'POST',body:f});msg(q('[data-vm-msg]'),j.message,true);await loadContext()}catch(err){msg(q('[data-vm-msg]'),err.message,false)}});
  q('[data-iso-form]').addEventListener('submit',async e=>{e.preventDefault();if(!canIsoUpload||!current)return;const f=new FormData(e.currentTarget);f.set('csrf',csrf);f.set('server_id',current.id);msg(q('[data-iso-msg]'),'Upload en cours…',true);try{const j=await api('upload_iso',{method:'POST',body:f});msg(q('[data-iso-msg]'),j.message,true);await loadNode(q('[data-node]').value)}catch(err){msg(q('[data-iso-msg]'),err.message,false)}});

  renderServers(); if(servers.length)fillServer(servers[0]); else resetServerForm();
})();
</script>
