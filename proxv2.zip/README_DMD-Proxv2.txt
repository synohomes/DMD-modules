DMD-ProxV2

Gestion Proxmox multi-node pour DoMyDesk

- Module : DMD-ProxV2
Version actuelle : 2.2.1
DoMyDesk minimum : 1.2.0

Stockage : système, persistant hors du dossier du module
Accès par défaut : contrôlé par les droits DoMyDesk

DMD-ProxV2 permet d'administrer un ou plusieurs serveurs Proxmox VE directement depuis DoMyDesk, sans avoir à garder l'interface Proxmox ouverte pour les opérations courantes.

La V2 est volontairement orientée homelab : installation simple, connexion rapide et administration quotidienne depuis DoMyDesk.

- Fonctionnalités de la V2

Supervision Proxmox
DMD-ProxV2 affiche les informations principales de chaque serveur configuré :

Etat du cluster ;
CPU utilisé ;
RAM utilisée ;
Nombre de nodes disponibles ;
Machines virtuelles QEMU ;
Conteneurs LXC ;
Etat running / stopped ;
Consommation CPU, RAM et disque des VM/CT ;


Cache local pour éviter de solliciter inutilement l'API Proxmox.
Le module prend en charge plusieurs serveurs Proxmox.
Fenêtres VM / CT
Un clic sur une VM ou un conteneur ouvre une fenêtre indépendante dans le dashboard DoMyDesk.

Les fenêtres peuvent :
-Etre ouvertes en plusieurs exemplaires simultanément ;
-Etre déplacées dans le dashboard ;
-Etre redimensionnées ;
-Etre remises au premier plan au clic ;


Rester indépendantes les unes des autres.
Cela permet par exemple de garder plusieurs VM sous les yeux pendant une intervention.
Actions sur les VM
Selon les droits attribués dans DoMyDesk, les actions suivantes sont disponibles :

Démarrer ;
Eteindre proprement ;
Arrêter de force ;
Redémarrer ;
Reset matériel pour les VM QEMU ;
Créer une VM QEMU.

Les actions sont contrôlées côté serveur par les permissions du module et ne reposent pas uniquement sur l'affichage des boutons.

Création de VM QEMU

Depuis la configuration ProxV2, il est possible de créer directement une VM avec notamment :

node Proxmox ;

VMID manuel ou automatique ;

nom ;

type de système ;

nombre de CPU ;

quantité de RAM ;

taille du disque ;

stockage cible ;

ISO ;

bridge réseau ;

VLAN.

ProxV2 récupère automatiquement les stockages, ISO, bridges et VLAN disponibles sur le node sélectionné.

Gestion des ISO

DMD-ProxV2 permet d'envoyer une image ISO directement vers un stockage Proxmox compatible.

Le module vérifie notamment :

le node sélectionné ;

le stockage ISO ;

le type de fichier .iso.

Configuration d'un serveur Proxmox

La V2 propose deux méthodes.

1. Configuration automatique — recommandée pour un homelab

Il suffit de renseigner :

Nom du serveur
IP ou DNS
Port Proxmox (8006 par défaut)
Utilisateur administrateur, par exemple root@pam
Mot de passe administrateur

Puis de cliquer sur :

Créer l'accès ProxV2

DMD-ProxV2 effectue automatiquement le bootstrap suivant :

Compte administrateur Proxmox
        ↓
Connexion temporaire à l'API
        ↓
Création de domydesk@pve
        ↓
Attribution du rôle Administrator
        ↓
Création de domydesk@pve!proxv2
        ↓
Récupération du secret API
        ↓
Chiffrement et stockage dans DoMyDesk
        ↓
Test du nouveau token
        ↓
Utilisation exclusive du token pour la suite

Important

Le mot de passe administrateur utilisé pendant le bootstrap :

n'est pas enregistré dans le fichier serveur ;

n'est pas conservé comme secret ProxV2 ;

n'est pas écrit dans les logs du module ;

n'est plus utilisé après la création du compte et du token.

Le compte utilisé quotidiennement par le module est :

domydesk@pve

et son API Token :

domydesk@pve!proxv2

Si le token proxv2 existe déjà sur ce compte, la configuration automatique le renouvelle.

2. API Token existant

Pour un serveur déjà configuré manuellement, il est également possible de choisir :

J'ai déjà un API Token

et de renseigner directement :

IP / DNS
Port
Token ID
Secret API

Cette méthode permet de conserver une configuration Proxmox préparée manuellement.

Sécurité des données

Les données sensibles ne sont pas conservées dans le dossier du module.

Le stockage persistant se trouve dans :

/data/modules/proxv2/

Structure principale :

/data/modules/proxv2/
├── cfg/
│   ├── .proxv2.key
│   └── serveurs/
├── cache/
└── logs/

Le secret des API Tokens est chiffré avec une clé locale dédiée à ProxV2.

Les dossiers de données reçoivent également une protection .htaccess afin d'empêcher leur consultation directe depuis le serveur Web lorsque cette protection est prise en charge.

Mise à jour du module

Le code du module se trouve dans :

/modules/proxv2/

Les données se trouvent dans :

/data/modules/proxv2/

Une mise à jour de DMD-ProxV2 peut donc remplacer le contenu du dossier du module sans supprimer :

les serveurs configurés ;

la clé de chiffrement ;

les secrets API ;

le cache ;

les logs.

Le module prévoit également la migration des anciens dossiers cfg, cache et logs vers le stockage persistant DoMyDesk 1.2.

Journal des tâches

DMD-ProxV2 possède son propre journal d'activité inspiré du journal de tâches Proxmox.

Le journal est affiché directement sous les VM et conserve notamment :

date et heure ;

utilisateur DoMyDesk ;

action ;

cible ;

résultat ;

serveur / node ;

détails de l'opération.

Exemples d'événements :

Démarrage d'une VM
Arrêt propre
Stop forcé
Redémarrage
Reset
Création de VM
Ajout ou modification d'un serveur
Configuration automatique de l'accès API
Upload ISO

Les logs sont stockés dans :

/data/modules/proxv2/logs/

Ils sont donc conservés lors des mises à jour du module.

Depuis l'interface, selon les droits de l'utilisateur, il est possible de :

actualiser le journal ;

exporter le journal en PDF ;

imprimer le journal ;

supprimer les logs.

Permissions DoMyDesk

DMD-ProxV2 utilise les droits fins de DoMyDesk 1.2.

Capacités actuellement déclarées :

view
refresh
console

vm.start
vm.shutdown
vm.reboot
vm.stop
vm.reset
vm.create

server.manage
iso.upload
network.manage

logs.view
logs.export
logs.delete

Un utilisateur peut donc avoir accès à ProxV2 sans nécessairement disposer de toutes les opérations d'administration.

Prérequis

DoMyDesk 1.2.0 minimum ;

un serveur Proxmox VE accessible depuis le serveur DoMyDesk ;

accès HTTPS au port API Proxmox, généralement 8006 ;

PHP avec cURL ;

PHP avec OpenSSL pour le chiffrement des secrets ;

droits d'écriture de DoMyDesk dans /data/modules/proxv2/.

Pour la configuration automatique, le compte fourni pendant le bootstrap doit disposer des droits nécessaires pour :

créer ou consulter les utilisateurs ;

définir les ACL ;

créer et supprimer des API Tokens.

Installation

Ouvrir Administration dans DoMyDesk.

Aller dans Installer un module.

Sélectionner le ZIP DMD-ProxV2.

Installer le module.

Autoriser ProxV2 aux utilisateurs ou rôles souhaités.

Ouvrir la configuration du module.

Ajouter le premier serveur Proxmox.

Pour un homelab, utiliser Configuration automatique.

Tester la connexion.

Ouvrir ProxV2 depuis le dashboard.

Aucune base de données supplémentaire n'est nécessaire.

Limites assumées de la V2

La V2 privilégie volontairement la simplicité pour les installations homelab.

Elle ne fournit pas encore la gestion avancée de :

double authentification Proxmox ;

validation du certificat HTTPS / fingerprint ;

stratégie de privilèges Proxmox minimale et personnalisable ;

durcissement avancé pour contexte professionnel ;

accès Remote/noVNC intégré prêt à l'emploi.

Certificats HTTPS en V2

La V2 accepte les certificats Proxmox auto-signés afin de simplifier l'installation dans un réseau local de confiance.

Cette version est donc principalement destinée à un homelab ou un environnement maîtrisé.

Remote / noVNC

Le code de ProxV2 possède déjà un point d'intégration pour une console noVNC, mais le paquet V2 standard ne fournit pas actuellement le composant noVNC complet.

La fonction Remote/noVNC intégrée est prévue pour la V3.

V3 — édition avancée prévue

La V3 est prévue comme une édition plus professionnelle et renforcée.

Fonctions envisagées :

support de la double authentification ;

validation du certificat HTTPS ;

contrôle / mémorisation du fingerprint ;

droits Proxmox plus fins ;

création de rôles dédiés au lieu d'un accès Administrator global ;

durcissement de la communication entre DoMyDesk et Proxmox ;

Remote intégré ;

console noVNC ;

amélioration des contrôles de sécurité ;

fonctions supplémentaires destinées aux environnements professionnels.

La V2 reste destinée à rester simple et efficace pour un homelab, tandis que la V3 doit fournir les fonctions de sécurité et d'administration avancées qui ne sont pas indispensables dans ce contexte.

Structure du paquet V2.2.1

action.php
console.php
dmd_module.json
icon.png
proxv2.css
proxv2.php
proxv2_create.php
proxv2_fetch.php
proxv2_lib.php
proxv2_logs.php
proxv2_storage.php
proxv2cfg.css
proxv2cfg.php

Les données utilisateur ou les identifiants Proxmox ne doivent pas être inclus dans le ZIP de distribution.

Dépannage rapide

Aucun serveur Proxmox configuré

Ouvrir la configuration de ProxV2 et ajouter un serveur.

La configuration automatique échoue

Vérifier :

l'adresse IP / DNS ;

le port 8006 ;

le compte administrateur ;

le mot de passe ;

l'accessibilité réseau entre DoMyDesk et Proxmox.

Les VM ne s'affichent pas

Tester la connexion API depuis la configuration puis actualiser le module.

Une action n'apparaît pas

Vérifier les permissions fines attribuées à l'utilisateur dans DoMyDesk.

Les logs ne s'affichent pas

Vérifier le droit :

logs.view

Pour l'export PDF :

logs.export

Pour la suppression :

logs.delete

Philosophie de DMD-ProxV2

L'objectif de ProxV2 V2 est simple :

Ajouter un Proxmox à DoMyDesk, laisser le module créer son propre accès API, puis administrer les opérations courantes sans devoir retourner en permanence dans l'interface Proxmox.

La V2 vise le homelab et la simplicité.

La V3 étendra cette base vers des usages plus professionnels, avec davantage de sécurité, de contrôle et l'intégration Remote/noVNC.