<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/proxv2_lib.php';

if (!proxv2_has_module_access() || !proxv2_user_can('refresh')) {
    http_response_code(403);
    exit('Module ProxV2 non autorisé pour cet utilisateur.');
}
if (!proxv2_csrf_valid(isset($_GET['csrf']) ? $_GET['csrf'] : (isset($_POST['csrf']) ? $_POST['csrf'] : ''))) {
    proxv2_json(false, 'Jeton de sécurité expiré.', array(), 403);
}

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$storage = proxv2_storage_paths();
$lockPath = rtrim($storage['cache'], '/\\') . DIRECTORY_SEPARATOR . '.refresh.lock';
$lockFp = @fopen($lockPath, 'c+');
if ($lockFp && !@flock($lockFp, LOCK_EX | LOCK_NB)) {
    echo json_encode(array('ok' => true, 'skipped' => true, 'message' => 'Actualisation ProxV2 déjà en cours.'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    fclose($lockFp);
    exit;
}

$servers = proxv2_list_servers(false);
if (!$servers) {
    echo json_encode(array('ok' => true, 'servers' => array(), 'message' => 'Aucun serveur défini.'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$report = array();
foreach ($servers as $server) {
    $id = isset($server['id']) ? $server['id'] : proxv2_slug(isset($server['name']) ? $server['name'] : 'server');
    $name = isset($server['name']) ? $server['name'] : $id;
    $cache = array(
        'server_id' => $id,
        'server_name' => $name,
        'version' => null,
        'nodes' => array(),
        'cluster' => array(
            'nodes_total' => 0,
            'nodes_online' => 0,
            'cpu' => 0,
            'mem' => 0,
            'maxmem' => 0,
            'disk' => 0,
            'maxdisk' => 0
        ),
        'vms' => array(),
        'error' => null
    );

    $version = proxv2_api($server, 'version', 'GET', null, 10);
    if ($version['ok']) {
        $cache['version'] = $version['data'];
    } else {
        $cache['error'] = array('where' => 'version', 'code' => $version['error']);
        proxv2_write_cache($server, $cache);
        $report[] = array('id' => $id, 'name' => $name, 'ok' => false, 'error' => $version['error']);
        continue;
    }

    $nodesRes = proxv2_api($server, 'nodes', 'GET', null, 12);
    if ($nodesRes['ok'] && is_array($nodesRes['data'])) {
        $cache['nodes'] = $nodesRes['data'];
        $weightedCpu = 0.0;
        $cpuWeight = 0.0;
        foreach ($nodesRes['data'] as $node) {
            if (!is_array($node)) continue;
            $cache['cluster']['nodes_total']++;
            if (strtolower((string)(isset($node['status']) ? $node['status'] : '')) === 'online') $cache['cluster']['nodes_online']++;
            $maxcpu = (float)(isset($node['maxcpu']) ? $node['maxcpu'] : 0);
            $cpu = (float)(isset($node['cpu']) ? $node['cpu'] : 0);
            if ($maxcpu > 0) {
                $weightedCpu += ($cpu * $maxcpu);
                $cpuWeight += $maxcpu;
            }
            $cache['cluster']['mem'] += (float)(isset($node['mem']) ? $node['mem'] : 0);
            $cache['cluster']['maxmem'] += (float)(isset($node['maxmem']) ? $node['maxmem'] : 0);
            $cache['cluster']['disk'] += (float)(isset($node['disk']) ? $node['disk'] : 0);
            $cache['cluster']['maxdisk'] += (float)(isset($node['maxdisk']) ? $node['maxdisk'] : 0);
        }
        $cache['cluster']['cpu'] = $cpuWeight > 0 ? ($weightedCpu / $cpuWeight) : 0;
    } else {
        $cache['error'] = array('where' => 'nodes', 'code' => $nodesRes['error']);
    }

    $vmsRes = proxv2_cluster_vms($server);
    if ($vmsRes['ok']) {
        $vms = array();
        foreach ($vmsRes['data'] as $vm) {
            if (!is_array($vm)) continue;
            $type = strtolower((string)(isset($vm['type']) ? $vm['type'] : 'qemu'));
            if ($type !== 'qemu' && $type !== 'lxc') $type = 'qemu';
            $vm['type'] = $type;
            $vms[] = $vm;
        }
        usort($vms, function($a, $b) {
            $na = (string)(isset($a['node']) ? $a['node'] : '');
            $nb = (string)(isset($b['node']) ? $b['node'] : '');
            if ($na !== $nb) return strcasecmp($na, $nb);
            return ((int)(isset($a['vmid']) ? $a['vmid'] : 0)) - ((int)(isset($b['vmid']) ? $b['vmid'] : 0));
        });
        $cache['vms'] = $vms;
    } else {
        $cache['error'] = array('where' => 'vms', 'code' => $vmsRes['error']);
    }

    proxv2_write_cache($server, $cache);
    $report[] = array(
        'id' => $id,
        'name' => $name,
        'ok' => empty($cache['error']),
        'nodes' => $cache['cluster']['nodes_total'],
        'vms' => count($cache['vms']),
        'error' => $cache['error']
    );
}

if ($lockFp) { @flock($lockFp, LOCK_UN); @fclose($lockFp); }
echo json_encode(array('ok' => true, 'servers' => $report, 'updated_at' => date('c')), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
