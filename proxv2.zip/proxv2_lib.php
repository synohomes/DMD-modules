<?php
/*
 * ProxV2 - moteur commun DoMyDesk 1.2.x
 * Compatible PHP 7.3+
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$proxv2RootFunctions = dirname(__DIR__, 2) . '/functions.php';
if (is_file($proxv2RootFunctions)) {
    require_once $proxv2RootFunctions;
}
require_once __DIR__ . '/proxv2_storage.php';

if (!function_exists('proxv2_root')) {
    function proxv2_root() {
        return dirname(__DIR__, 2);
    }
}

if (!function_exists('proxv2_user_email')) {
    function proxv2_user_email() {
        return trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : ''));
    }
}

if (!function_exists('proxv2_profile')) {
    function proxv2_profile() {
        $email = proxv2_user_email();
        if ($email === '') return array();
        if (function_exists('dmd_read_profile')) {
            $p = dmd_read_profile($email);
            if (is_array($p)) return $p;
        }
        return isset($_SESSION['user']) && is_array($_SESSION['user']) ? $_SESSION['user'] : array();
    }
}

if (!function_exists('proxv2_is_admin')) {
    function proxv2_is_admin() {
        $p = proxv2_profile();
        $role = strtolower(trim((string)(isset($p['role_system']) ? $p['role_system'] : (isset($_SESSION['user']['role_system']) ? $_SESSION['user']['role_system'] : ''))));
        return in_array($role, array('admin', 'superadmin', 'administrator'), true);
    }
}

if (!function_exists('proxv2_has_module_access')) {
    function proxv2_has_module_access() {
        $email = proxv2_user_email();
        if ($email === '') return false;

        /* ProxV2 2.2.2+ cible DoMyDesk 1.2.0 : si le moteur de droits n'est pas chargé, on refuse. */
        if (!function_exists('dmd_user_can_use_module')) {
            return false;
        }

        return (bool)dmd_user_can_use_module($email, 'proxv2');
    }
}

if (!function_exists('proxv2_capability_catalog')) {
    function proxv2_capability_catalog() {
        return array(
            'view' => 'Voir Proxmox',
            'refresh' => 'Actualiser les informations',
            'console' => 'Ouvrir la console',
            'vm.start' => 'Démarrer une VM/CT',
            'vm.shutdown' => 'Arrêter proprement une VM/CT',
            'vm.reboot' => 'Redémarrer une VM/CT',
            'vm.stop' => 'Forcer l’arrêt d’une VM/CT',
            'vm.reset' => 'Reset matériel d’une VM',
            'vm.create' => 'Créer une VM',
            'server.manage' => 'Gérer les serveurs Proxmox',
            'iso.upload' => 'Envoyer une ISO',
            'network.manage' => 'Gérer les éléments réseau',
            'logs.view' => 'Voir le journal des tâches',
            'logs.export' => 'Exporter / imprimer le journal des tâches',
            'logs.delete' => 'Supprimer le journal des tâches'
        );
    }
}

if (!function_exists('proxv2_user_can')) {
    function proxv2_user_can($capability) {
        $email = proxv2_user_email();
        $capability = trim((string)$capability);

        if ($email === '' || $capability === '' || !proxv2_has_module_access()) {
            return false;
        }

        /*
         * DoMyDesk 1.2.0 : UNE seule source de vérité.
         * Rôle métier + exception utilisateur + wildcard administrateur sont tous
         * calculés par le Core. Aucun droit n'est inventé dans le module.
         */
        if (!function_exists('dmd_user_has_module_permission')) {
            return false;
        }

        return (bool)dmd_user_has_module_permission($email, 'proxv2', $capability);
    }
}

if (!function_exists('proxv2_json')) {
    function proxv2_json($ok, $message, $extra, $httpCode) {
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=UTF-8');
            http_response_code((int)$httpCode);
        }
        $payload = array_merge(array('ok' => (bool)$ok, 'message' => (string)$message), is_array($extra) ? $extra : array());
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

if (!function_exists('proxv2_csrf_token')) {
    function proxv2_csrf_token() {
        if (empty($_SESSION['csrf_proxv2'])) {
            $_SESSION['csrf_proxv2'] = bin2hex(random_bytes(32));
        }
        return (string)$_SESSION['csrf_proxv2'];
    }
}

if (!function_exists('proxv2_csrf_valid')) {
    function proxv2_csrf_valid($token) {
        $stored = isset($_SESSION['csrf_proxv2']) ? (string)$_SESSION['csrf_proxv2'] : '';
        return $stored !== '' && is_string($token) && hash_equals($stored, $token);
    }
}

if (!function_exists('proxv2_slug')) {
    function proxv2_slug($value) {
        $value = strtolower(trim((string)$value));
        $value = preg_replace('/[^a-zA-Z0-9_-]+/', '_', $value);
        $value = trim((string)$value, '_-');
        return $value;
    }
}

if (!function_exists('proxv2_crypto_key')) {
    function proxv2_crypto_key($create) {
        $paths = proxv2_storage_paths();
        $keyFile = $paths['key'];
        $raw = trim((string)@file_get_contents($keyFile));
        if ($raw === '' && $create) {
            $raw = bin2hex(random_bytes(32));
            @file_put_contents($keyFile, $raw, LOCK_EX);
            @chmod($keyFile, 0640);
        }
        return $raw === '' ? '' : hash('sha256', $raw, true);
    }
}

if (!function_exists('proxv2_encrypt_secret')) {
    function proxv2_encrypt_secret($secret) {
        $secret = (string)$secret;
        if ($secret === '') return '';
        if (!function_exists('openssl_encrypt')) return '';
        $key = proxv2_crypto_key(true);
        if ($key === '') return '';
        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($secret, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($cipher === false) return '';
        return base64_encode(json_encode(array(
            'v' => 1,
            'alg' => 'aes-256-gcm',
            'iv' => base64_encode($iv),
            'tag' => base64_encode($tag),
            'data' => base64_encode($cipher)
        )));
    }
}

if (!function_exists('proxv2_decrypt_encrypted_value')) {
    function proxv2_decrypt_encrypted_value($encoded) {
        $encoded = (string)$encoded;
        if ($encoded === '' || !function_exists('openssl_decrypt')) return '';
        $decoded = base64_decode($encoded, true);
        if ($decoded === false) return '';
        $payload = json_decode($decoded, true);
        if (!is_array($payload)) return '';
        $iv = base64_decode(isset($payload['iv']) ? $payload['iv'] : '', true);
        $tag = base64_decode(isset($payload['tag']) ? $payload['tag'] : '', true);
        $data = base64_decode(isset($payload['data']) ? $payload['data'] : '', true);
        if ($iv === false || $tag === false || $data === false) return '';
        $key = proxv2_crypto_key(false);
        if ($key === '') return '';
        $plain = openssl_decrypt($data, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        return $plain === false ? '' : $plain;
    }
}

if (!function_exists('proxv2_decrypt_secret')) {
    function proxv2_decrypt_secret($server) {
        if (!is_array($server)) return '';
        if (!empty($server['secret'])) return (string)$server['secret'];
        return proxv2_decrypt_encrypted_value(isset($server['secret_enc']) ? $server['secret_enc'] : '');
    }
}

if (!function_exists('proxv2_decrypt_remote_password')) {
    function proxv2_decrypt_remote_password($server) {
        if (!is_array($server)) return '';
        return proxv2_decrypt_encrypted_value(isset($server['remote_password_enc']) ? $server['remote_password_enc'] : '');
    }
}

if (!function_exists('proxv2_server_file')) {
    function proxv2_server_file($serverId) {
        $paths = proxv2_storage_paths();
        return rtrim($paths['servers'], '/\\') . DIRECTORY_SEPARATOR . proxv2_slug($serverId) . '.json';
    }
}

if (!function_exists('proxv2_migrate_server_data')) {
    function proxv2_migrate_server_data($file, $data) {
        if (!is_array($data)) return array();
        $changed = false;
        if (empty($data['id'])) {
            $data['id'] = proxv2_slug(isset($data['name']) ? $data['name'] : pathinfo($file, PATHINFO_FILENAME));
            $changed = true;
        }
        if (!empty($data['secret']) && empty($data['secret_enc'])) {
            $enc = proxv2_encrypt_secret($data['secret']);
            if ($enc !== '') {
                $data['secret_enc'] = $enc;
                unset($data['secret']);
                $changed = true;
            }
        }
        if ($changed) {
            $data['updated'] = date('c');
            @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
            @chmod($file, 0640);
        }
        return $data;
    }
}

if (!function_exists('proxv2_list_servers')) {
    function proxv2_list_servers($publicOnly) {
        $paths = proxv2_storage_paths();
        $out = array();
        foreach ((array)glob(rtrim($paths['servers'], '/\\') . DIRECTORY_SEPARATOR . '*.json') as $file) {
            $data = json_decode((string)@file_get_contents($file), true);
            $data = proxv2_migrate_server_data($file, $data);
            if (!is_array($data) || empty($data['name'])) continue;
            if (empty($data['id'])) $data['id'] = proxv2_slug($data['name']);
            if ($publicOnly) {
                unset($data['secret'], $data['secret_enc']);
                $data['has_secret'] = proxv2_decrypt_secret(proxv2_migrate_server_data($file, json_decode((string)@file_get_contents($file), true))) !== '';
            }
            $out[] = $data;
        }
        usort($out, function($a, $b) {
            return strcasecmp((string)$a['name'], (string)$b['name']);
        });
        return $out;
    }
}

if (!function_exists('proxv2_load_server')) {
    function proxv2_load_server($idOrName) {
        $needle = trim((string)$idOrName);
        if ($needle === '') return null;
        $slug = proxv2_slug($needle);
        $direct = proxv2_server_file($slug);
        if (is_file($direct)) {
            $d = json_decode((string)@file_get_contents($direct), true);
            $d = proxv2_migrate_server_data($direct, $d);
            if (is_array($d)) return $d;
        }
        $paths = proxv2_storage_paths();
        foreach ((array)glob(rtrim($paths['servers'], '/\\') . DIRECTORY_SEPARATOR . '*.json') as $file) {
            $d = json_decode((string)@file_get_contents($file), true);
            $d = proxv2_migrate_server_data($file, $d);
            if (!is_array($d)) continue;
            if (strcasecmp((string)(isset($d['id']) ? $d['id'] : ''), $needle) === 0 || strcasecmp((string)(isset($d['name']) ? $d['name'] : ''), $needle) === 0) {
                return $d;
            }
        }
        return null;
    }
}

if (!function_exists('proxv2_save_server')) {
    function proxv2_save_server($server, $oldId) {
        if (!is_array($server)) return false;
        $id = proxv2_slug(isset($server['id']) ? $server['id'] : (isset($server['name']) ? $server['name'] : ''));
        if ($id === '') return false;
        $server['id'] = $id;
        $file = proxv2_server_file($id);
        if (@file_put_contents($file, json_encode($server, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) === false) return false;
        @chmod($file, 0640);
        $oldId = proxv2_slug($oldId);
        if ($oldId !== '' && $oldId !== $id) {
            $oldFile = proxv2_server_file($oldId);
            if (is_file($oldFile)) @unlink($oldFile);
        }
        return true;
    }
}

if (!function_exists('proxv2_http_json')) {
    function proxv2_http_json($url, $method, $data, $headers, $timeout) {
        $ch = curl_init($url);
        $opts = array(
            CURLOPT_RETURNTRANSFER => true,
            /* ProxV2 V2 homelab : validation TLS/fingerprint prévue pour la V3. */
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => (int)$timeout > 0 ? (int)$timeout : 12,
            CURLOPT_HTTPHEADER => is_array($headers) ? $headers : array()
        );
        $method = strtoupper((string)$method);
        if ($method === 'POST') {
            $opts[CURLOPT_POST] = true;
            $opts[CURLOPT_POSTFIELDS] = is_array($data) ? http_build_query($data) : (string)$data;
        } elseif ($method !== 'GET') {
            $opts[CURLOPT_CUSTOMREQUEST] = $method;
            if ($data !== null) $opts[CURLOPT_POSTFIELDS] = is_array($data) ? http_build_query($data) : (string)$data;
        }
        curl_setopt_array($ch, $opts);
        $raw = curl_exec($ch);
        $err = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($raw === false || $err !== '') {
            return array('ok' => false, 'http' => $http, 'error' => $err !== '' ? $err : 'Erreur cURL', 'data' => null, 'raw' => '');
        }
        $json = json_decode($raw, true);
        if (!is_array($json)) {
            return array('ok' => false, 'http' => $http, 'error' => 'Réponse Proxmox non JSON', 'data' => null, 'raw' => $raw);
        }
        if ($http < 200 || $http >= 300 || !empty($json['errors'])) {
            $msg = isset($json['message']) && trim((string)$json['message']) !== '' ? (string)$json['message'] : ('HTTP ' . $http);
            if (!empty($json['errors'])) $msg .= ' - ' . json_encode($json['errors'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            return array('ok' => false, 'http' => $http, 'error' => $msg, 'data' => isset($json['data']) ? $json['data'] : null, 'raw' => $raw);
        }
        return array('ok' => true, 'http' => $http, 'error' => '', 'data' => isset($json['data']) ? $json['data'] : null, 'raw' => $raw);
    }
}

if (!function_exists('proxv2_password_login')) {
    function proxv2_password_login($ip, $port, $username, $password, $timeout) {
        $ip = trim((string)$ip);
        $port = (int)$port;
        if ($port <= 0 || $port > 65535) $port = 8006;
        $username = trim((string)$username);
        $password = (string)$password;
        if ($ip === '' || $username === '' || $password === '') {
            return array('ok' => false, 'http' => 0, 'error' => 'IP/DNS, utilisateur administrateur et mot de passe sont obligatoires.', 'data' => null, 'raw' => '');
        }
        $url = 'https://' . $ip . ':' . $port . '/api2/json/access/ticket';
        $res = proxv2_http_json($url, 'POST', array('username' => $username, 'password' => $password), array(), $timeout);
        if (!$res['ok']) return $res;
        $data = is_array($res['data']) ? $res['data'] : array();
        $ticket = isset($data['ticket']) ? trim((string)$data['ticket']) : '';
        $csrf = isset($data['CSRFPreventionToken']) ? trim((string)$data['CSRFPreventionToken']) : '';
        if ($ticket === '' || $csrf === '') {
            return array('ok' => false, 'http' => $res['http'], 'error' => 'Authentification Proxmox incomplète : ticket/CSRF absent.', 'data' => null, 'raw' => $res['raw']);
        }
        return array('ok' => true, 'http' => $res['http'], 'error' => '', 'data' => array(
            'ticket' => $ticket,
            'csrf' => $csrf,
            'username' => isset($data['username']) ? (string)$data['username'] : $username
        ), 'raw' => $res['raw']);
    }
}

if (!function_exists('proxv2_ticket_api')) {
    function proxv2_ticket_api($ip, $port, $auth, $endpoint, $method, $data, $timeout) {
        if (!is_array($auth) || empty($auth['ticket'])) {
            return array('ok' => false, 'http' => 0, 'error' => 'Session administrateur Proxmox invalide.', 'data' => null, 'raw' => '');
        }
        $ip = trim((string)$ip);
        $port = (int)$port;
        if ($port <= 0 || $port > 65535) $port = 8006;
        $endpoint = ltrim((string)$endpoint, '/');
        $url = 'https://' . $ip . ':' . $port . '/api2/json/' . $endpoint;
        $headers = array('Cookie: PVEAuthCookie=' . (string)$auth['ticket']);
        if (strtoupper((string)$method) !== 'GET') {
            $headers[] = 'CSRFPreventionToken: ' . (string)(isset($auth['csrf']) ? $auth['csrf'] : '');
        }
        return proxv2_http_json($url, $method, $data, $headers, $timeout);
    }
}

if (!function_exists('proxv2_bootstrap_api_access')) {
    function proxv2_bootstrap_api_access($ip, $port, $adminUser, $adminPassword, $preferredServiceUser = '', $preferredTokenName = '') {
        /*
         * Bootstrap V2 : le mot de passe administrateur n'est utilisé que pour
         * obtenir un ticket Proxmox. Il n'est jamais écrit dans DoMyDesk.
         *
         * Chaque intégration automatique possède désormais son propre compte
         * Proxmox + son propre token. Deux DoMyDesk peuvent donc viser le même
         * Proxmox sans se battre pour un nom technique prédéfini.
         */
        $login = proxv2_password_login($ip, $port, $adminUser, $adminPassword, 15);
        if (!$login['ok']) return array('ok' => false, 'error' => 'Connexion administrateur refusée : ' . $login['error']);
        $auth = $login['data'];

        $users = proxv2_ticket_api($ip, $port, $auth, 'access/users', 'GET', null, 12);
        if (!$users['ok']) return array('ok' => false, 'error' => 'Impossible de lire les utilisateurs Proxmox : ' . $users['error']);

        $existingUsers = array();
        foreach ((array)$users['data'] as $user) {
            if (is_array($user) && !empty($user['userid'])) {
                $existingUsers[strtolower((string)$user['userid'])] = true;
            }
        }

        $preferredServiceUser = trim((string)$preferredServiceUser);
        $preferredTokenName = trim((string)$preferredTokenName);
        $serviceUser = '';
        $tokenName = '';

        if ($preferredServiceUser !== '' && strpos($preferredServiceUser, '@') !== false) {
            $serviceUser = $preferredServiceUser;
            $tokenName = $preferredTokenName !== '' ? $preferredTokenName : 'proxv2';
        } else {
            for ($attempt = 0; $attempt < 30; $attempt++) {
                $suffix = strtolower(bin2hex(random_bytes(4)));
                $candidateUser = 'domydesk_' . $suffix . '@pve';
                if (isset($existingUsers[strtolower($candidateUser)])) continue;
                $serviceUser = $candidateUser;
                $tokenName = 'proxv2_' . $suffix;
                break;
            }
        }

        if ($serviceUser === '' || $tokenName === '') {
            return array('ok' => false, 'error' => 'Impossible de générer un compte ProxV2 unique sur ce serveur.');
        }

        $fullTokenId = $serviceUser . '!' . $tokenName;
        $createdUser = false;
        $renewedToken = false;

        /*
         * Le Remote Proxmox exige un vrai ticket utilisateur.
         * Ce mot de passe aléatoire appartient uniquement au compte technique
         * ProxV2 et est chiffré dans le stockage persistant DoMyDesk.
         */
        $servicePassword = bin2hex(random_bytes(24));
        $exists = isset($existingUsers[strtolower($serviceUser)]);

        if (!$exists) {
            $createUser = proxv2_ticket_api($ip, $port, $auth, 'access/users', 'POST', array(
                'userid' => $serviceUser,
                'password' => $servicePassword,
                'enable' => 1,
                'expire' => 0,
                'comment' => 'DoMyDesk ProxV2 - compte API/Remote dédié'
            ), 12);
            if (!$createUser['ok']) return array('ok' => false, 'error' => 'Création de ' . $serviceUser . ' impossible : ' . $createUser['error']);
            $createdUser = true;
        } else {
            /* Renouvelle le secret Remote uniquement pour CETTE intégration. */
            $passwordUpdate = proxv2_ticket_api($ip, $port, $auth, 'access/password', 'PUT', array(
                'userid' => $serviceUser,
                'password' => $servicePassword
            ), 12);
            if (!$passwordUpdate['ok']) {
                return array('ok' => false, 'error' => 'Mise à jour du compte Remote ' . $serviceUser . ' impossible : ' . $passwordUpdate['error']);
            }
        }

        $acl = proxv2_ticket_api($ip, $port, $auth, 'access/acl', 'PUT', array(
            'path' => '/',
            'users' => $serviceUser,
            'roles' => 'Administrator',
            'propagate' => 1
        ), 12);
        if (!$acl['ok']) return array('ok' => false, 'error' => 'Attribution du rôle Administrator impossible : ' . $acl['error']);

        $tokenPath = 'access/users/' . rawurlencode($serviceUser) . '/token';
        $tokens = proxv2_ticket_api($ip, $port, $auth, $tokenPath, 'GET', null, 12);
        if (!$tokens['ok']) return array('ok' => false, 'error' => 'Lecture des API Tokens impossible : ' . $tokens['error']);
        foreach ((array)$tokens['data'] as $token) {
            if (!is_array($token) || !isset($token['tokenid']) || (string)$token['tokenid'] !== $tokenName) continue;
            $delete = proxv2_ticket_api($ip, $port, $auth, $tokenPath . '/' . rawurlencode($tokenName), 'DELETE', null, 12);
            if (!$delete['ok']) return array('ok' => false, 'error' => 'Renouvellement du token existant impossible : ' . $delete['error']);
            $renewedToken = true;
            break;
        }

        $tokenCreate = proxv2_ticket_api($ip, $port, $auth, $tokenPath . '/' . rawurlencode($tokenName), 'POST', array(
            'privsep' => 0,
            'expire' => 0,
            'comment' => 'DoMyDesk ProxV2'
        ), 12);
        if (!$tokenCreate['ok']) return array('ok' => false, 'error' => 'Création de l’API Token impossible : ' . $tokenCreate['error']);
        $tokenData = is_array($tokenCreate['data']) ? $tokenCreate['data'] : array();
        $secret = isset($tokenData['value']) ? trim((string)$tokenData['value']) : '';
        if ($secret === '') return array('ok' => false, 'error' => 'Proxmox a créé le token mais n’a pas retourné son secret.');
        if (!empty($tokenData['full-tokenid'])) $fullTokenId = (string)$tokenData['full-tokenid'];

        return array(
            'ok' => true,
            'error' => '',
            'user' => $serviceUser,
            'token_name' => $tokenName,
            'token_id' => $fullTokenId,
            'secret' => $secret,
            'role' => 'Administrator',
            'remote_password' => $servicePassword,
            'created_user' => $createdUser,
            'renewed_token' => $renewedToken
        );
    }
}

if (!function_exists('proxv2_token_name')) {
    function proxv2_token_name($fullTokenId) {
        $fullTokenId = trim((string)$fullTokenId);
        $pos = strrpos($fullTokenId, '!');
        if ($pos === false) return '';
        return trim((string)substr($fullTokenId, $pos + 1));
    }
}

if (!function_exists('proxv2_cleanup_automatic_access')) {
    function proxv2_cleanup_automatic_access($server) {
        if (!is_array($server)) return array('ok' => false, 'error' => 'Serveur invalide.');
        if (strtolower(trim((string)(isset($server['provisioning']) ? $server['provisioning'] : ''))) !== 'automatic') {
            return array('ok' => true, 'skipped' => true, 'token_deleted' => false, 'user_deleted' => false, 'warning' => '');
        }

        $ip = trim((string)(isset($server['ip']) ? $server['ip'] : ''));
        $port = (int)(isset($server['port']) ? $server['port'] : 8006);
        if ($port <= 0 || $port > 65535) $port = 8006;
        $serviceUser = trim((string)(isset($server['proxmox_user']) ? $server['proxmox_user'] : ''));
        $tokenName = proxv2_token_name(isset($server['token_id']) ? $server['token_id'] : '');
        $remotePassword = proxv2_decrypt_remote_password($server);

        if ($ip === '' || $serviceUser === '' || $tokenName === '') {
            return array('ok' => false, 'error' => 'Identité technique ProxV2 incomplète : suppression distante annulée.');
        }

        $auth = null;
        if ($remotePassword !== '') {
            $login = proxv2_password_login($ip, $port, $serviceUser, $remotePassword, 12);
            $remotePassword = null;
            if (!empty($login['ok']) && is_array($login['data'])) {
                $auth = $login['data'];
            }
        }

        $tokenDeleted = false;
        $userDeleted = false;
        $warning = '';

        if (is_array($auth)) {
            $tokenPath = 'access/users/' . rawurlencode($serviceUser) . '/token/' . rawurlencode($tokenName);
            $delToken = proxv2_ticket_api($ip, $port, $auth, $tokenPath, 'DELETE', null, 12);
            if (!empty($delToken['ok']) || (int)(isset($delToken['http']) ? $delToken['http'] : 0) === 404) {
                $tokenDeleted = true;
            } else {
                return array('ok' => false, 'error' => 'Le token API n’a pas pu être supprimé sur Proxmox : ' . (isset($delToken['error']) ? $delToken['error'] : 'erreur inconnue'));
            }

            $delUser = proxv2_ticket_api($ip, $port, $auth, 'access/users/' . rawurlencode($serviceUser), 'DELETE', null, 12);
            if (!empty($delUser['ok']) || (int)(isset($delUser['http']) ? $delUser['http'] : 0) === 404) {
                $userDeleted = true;
            } else {
                $disable = proxv2_ticket_api($ip, $port, $auth, 'access/users/' . rawurlencode($serviceUser), 'PUT', array('enable' => 0), 12);
                if (empty($disable['ok'])) {
                    return array(
                        'ok' => false,
                        'error' => 'Token supprimé, mais le compte technique ' . $serviceUser . ' n’a pas pu être supprimé ni désactivé. La configuration locale est conservée pour permettre une nouvelle tentative.'
                    );
                }
                $warning = 'Token supprimé. Le compte technique n’a pas pu être supprimé par Proxmox mais il a été désactivé.';
            }

            return array(
                'ok' => true,
                'skipped' => false,
                'token_deleted' => $tokenDeleted,
                'user_deleted' => $userDeleted,
                'warning' => $warning
            );
        }

        /*
         * Compatibilité anciennes configurations automatiques : tentative de
         * révocation du token avec le token lui-même. Si Proxmox refuse, on
         * conserve le JSON local pour éviter d'oublier un accès distant actif.
         */
        $fallback = proxv2_api($server, 'access/users/' . rawurlencode($serviceUser) . '/token/' . rawurlencode($tokenName), 'DELETE', null, 12);
        if (!empty($fallback['ok']) || (int)(isset($fallback['http']) ? $fallback['http'] : 0) === 404) {
            return array(
                'ok' => true,
                'skipped' => false,
                'token_deleted' => true,
                'user_deleted' => false,
                'warning' => 'Token supprimé. Ancienne configuration : le compte technique Proxmox reste présent.'
            );
        }

        return array(
            'ok' => false,
            'error' => 'Impossible de supprimer automatiquement le token API sur Proxmox. La configuration locale n’a pas été supprimée afin d’éviter de laisser un accès distant oublié.'
        );
    }
}

if (!function_exists('proxv2_api')) {
    function proxv2_api($server, $endpoint, $method, $data, $timeout) {
        if (!is_array($server)) return array('ok' => false, 'http' => 0, 'error' => 'Serveur invalide', 'data' => null, 'raw' => '');
        $ip = trim((string)(isset($server['ip']) ? $server['ip'] : ''));
        $port = (int)(isset($server['port']) ? $server['port'] : 8006);
        if ($port <= 0 || $port > 65535) $port = 8006;
        $token = trim((string)(isset($server['token_id']) ? $server['token_id'] : (isset($server['token']) ? $server['token'] : '')));
        $secret = proxv2_decrypt_secret($server);
        if ($ip === '' || $token === '' || $secret === '') {
            return array('ok' => false, 'http' => 0, 'error' => 'Configuration API incomplète', 'data' => null, 'raw' => '');
        }
        $endpoint = ltrim((string)$endpoint, '/');
        $url = 'https://' . $ip . ':' . $port . '/api2/json/' . $endpoint;
        $ch = curl_init($url);
        $opts = array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => array('Authorization: PVEAPIToken=' . $token . '=' . $secret),
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => (int)$timeout > 0 ? (int)$timeout : 12
        );
        $method = strtoupper((string)$method);
        if ($method === 'POST') {
            $opts[CURLOPT_POST] = true;
            $opts[CURLOPT_POSTFIELDS] = is_array($data) ? http_build_query($data) : (string)$data;
        } elseif ($method !== 'GET') {
            $opts[CURLOPT_CUSTOMREQUEST] = $method;
            if ($data !== null) $opts[CURLOPT_POSTFIELDS] = is_array($data) ? http_build_query($data) : (string)$data;
        }
        curl_setopt_array($ch, $opts);
        $raw = curl_exec($ch);
        $err = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($raw === false || $err !== '') return array('ok' => false, 'http' => $http, 'error' => $err !== '' ? $err : 'Erreur cURL', 'data' => null, 'raw' => '');
        $json = json_decode($raw, true);
        if (!is_array($json)) return array('ok' => false, 'http' => $http, 'error' => 'Réponse Proxmox non JSON', 'data' => null, 'raw' => $raw);
        if ($http < 200 || $http >= 300 || array_key_exists('errors', $json)) {
            $msg = isset($json['message']) ? $json['message'] : ('HTTP ' . $http);
            if (!empty($json['errors'])) $msg .= ' - ' . json_encode($json['errors'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            return array('ok' => false, 'http' => $http, 'error' => $msg, 'data' => isset($json['data']) ? $json['data'] : null, 'raw' => $raw);
        }
        return array('ok' => true, 'http' => $http, 'error' => '', 'data' => isset($json['data']) ? $json['data'] : null, 'raw' => $raw);
    }
}

if (!function_exists('proxv2_cluster_vms')) {
    function proxv2_cluster_vms($server) {
        $res = proxv2_api($server, 'cluster/resources?type=vm', 'GET', null, 15);
        if ($res['ok'] && is_array($res['data'])) {
            $out = array();
            foreach ($res['data'] as $vm) {
                if (!is_array($vm)) continue;
                $type = strtolower((string)(isset($vm['type']) ? $vm['type'] : ''));
                if ($type !== 'qemu' && $type !== 'lxc') continue;
                $vm['type'] = $type;
                $out[] = $vm;
            }
            return array('ok' => true, 'data' => $out, 'error' => '');
        }

        /* Fallback pour certains tokens à privilèges séparés. */
        $nodesRes = proxv2_api($server, 'nodes', 'GET', null, 12);
        if (!$nodesRes['ok'] || !is_array($nodesRes['data'])) return array('ok' => false, 'data' => array(), 'error' => $res['error']);
        $out = array();
        foreach ($nodesRes['data'] as $nodeInfo) {
            $node = isset($nodeInfo['node']) ? (string)$nodeInfo['node'] : '';
            if ($node === '') continue;
            foreach (array('qemu', 'lxc') as $type) {
                $r = proxv2_api($server, 'nodes/' . rawurlencode($node) . '/' . $type, 'GET', null, 12);
                if (!$r['ok'] || !is_array($r['data'])) continue;
                foreach ($r['data'] as $vm) {
                    if (!is_array($vm)) continue;
                    $vm['type'] = $type;
                    $vm['node'] = $node;
                    $out[] = $vm;
                }
            }
        }
        return array('ok' => true, 'data' => $out, 'error' => '');
    }
}

if (!function_exists('proxv2_resolve_vm')) {
    function proxv2_resolve_vm($server, $vmid, $preferredType) {
        $vmid = (int)$vmid;
        $preferredType = strtolower(trim((string)$preferredType));
        $all = proxv2_cluster_vms($server);
        if (!$all['ok']) return null;
        foreach ($all['data'] as $vm) {
            if ((int)(isset($vm['vmid']) ? $vm['vmid'] : 0) !== $vmid) continue;
            $type = strtolower((string)(isset($vm['type']) ? $vm['type'] : 'qemu'));
            if ($preferredType !== '' && in_array($preferredType, array('qemu', 'lxc'), true) && $type !== $preferredType) continue;
            return $vm;
        }
        return null;
    }
}

if (!function_exists('proxv2_next_vmid')) {
    function proxv2_next_vmid($server) {
        $r = proxv2_api($server, 'cluster/nextid', 'GET', null, 10);
        if (!$r['ok']) return 0;
        return (int)$r['data'];
    }
}

if (!function_exists('proxv2_cache_file')) {
    function proxv2_cache_file($server) {
        $paths = proxv2_storage_paths();
        $id = proxv2_slug(isset($server['id']) ? $server['id'] : (isset($server['name']) ? $server['name'] : 'server'));
        return rtrim($paths['cache'], '/\\') . DIRECTORY_SEPARATOR . $id . '.json';
    }
}

if (!function_exists('proxv2_write_cache')) {
    function proxv2_write_cache($server, $data) {
        $file = proxv2_cache_file($server);
        $data['ts'] = time();
        $data['updated_at'] = date('c');
        return @file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX) !== false;
    }
}

if (!function_exists('proxv2_read_cache')) {
    function proxv2_read_cache($server) {
        $file = proxv2_cache_file($server);
        if (!is_file($file)) return null;
        $d = json_decode((string)@file_get_contents($file), true);
        return is_array($d) ? $d : null;
    }
}

if (!function_exists('proxv2_logs_dir')) {
    function proxv2_logs_dir() {
        $paths = proxv2_storage_paths();
        $dir = isset($paths['logs']) ? $paths['logs'] : (rtrim($paths['root'], '/\\') . DIRECTORY_SEPARATOR . 'logs');
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        @chmod($dir, 0750);

        $marker = $dir . DIRECTORY_SEPARATOR . '.legacy_user_logs_migrated';
        if (!is_file($marker)) {
            $legacyFiles = (array)glob(proxv2_root() . '/users/profiles/*/logs/proxv2/*.json');
            $byDate = array();

            foreach ($legacyFiles as $legacyFile) {
                $items = json_decode((string)@file_get_contents($legacyFile), true);
                if (!is_array($items)) continue;
                foreach ($items as $entry) {
                    if (!is_array($entry)) continue;
                    $ts = isset($entry['timestamp']) ? (int)$entry['timestamp'] : 0;
                    $dateKey = $ts > 0 ? date('Y-m-d', $ts) : basename($legacyFile, '.json');
                    if (!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $dateKey)) $dateKey = date('Y-m-d');
                    if (!isset($byDate[$dateKey])) $byDate[$dateKey] = array();
                    $byDate[$dateKey][] = $entry;
                }
            }

            foreach ($byDate as $dateKey => $legacyEntries) {
                $target = $dir . DIRECTORY_SEPARATOR . $dateKey . '.json';
                $current = json_decode((string)@file_get_contents($target), true);
                if (!is_array($current)) $current = array();

                $seen = array();
                foreach ($current as $entry) {
                    if (!is_array($entry)) continue;
                    $seen[proxv2_log_signature($entry)] = true;
                }
                foreach ($legacyEntries as $entry) {
                    $sig = proxv2_log_signature($entry);
                    if (isset($seen[$sig])) continue;
                    $seen[$sig] = true;
                    $current[] = $entry;
                }

                usort($current, function($a, $b) {
                    return (int)(isset($a['timestamp']) ? $a['timestamp'] : 0) <=> (int)(isset($b['timestamp']) ? $b['timestamp'] : 0);
                });
                @file_put_contents($target, json_encode($current, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
                @chmod($target, 0640);
            }

            @file_put_contents($marker, date('c') . "\n", LOCK_EX);
            @chmod($marker, 0640);
        }

        return rtrim($dir, '/\\');
    }
}

if (!function_exists('proxv2_log_signature')) {
    function proxv2_log_signature($entry) {
        if (!is_array($entry)) return '';
        $base = array(
            isset($entry['date']) ? $entry['date'] : '',
            isset($entry['timestamp']) ? $entry['timestamp'] : '',
            isset($entry['user']) ? $entry['user'] : '',
            isset($entry['action']) ? $entry['action'] : '',
            isset($entry['target']) ? $entry['target'] : '',
            isset($entry['status']) ? $entry['status'] : '',
            isset($entry['details']) ? $entry['details'] : '',
            isset($entry['extra']) ? $entry['extra'] : array()
        );
        return sha1(json_encode($base, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
}

if (!function_exists('proxv2_logs_read')) {
    function proxv2_logs_read($limit) {
        $limit = max(1, min(5000, (int)$limit));
        $files = (array)glob(proxv2_logs_dir() . DIRECTORY_SEPARATOR . '*.json');
        rsort($files, SORT_STRING);
        $out = array();

        foreach ($files as $file) {
            $items = json_decode((string)@file_get_contents($file), true);
            if (!is_array($items)) continue;
            for ($i = count($items) - 1; $i >= 0; $i--) {
                if (!is_array($items[$i])) continue;
                $out[] = $items[$i];
                if (count($out) >= $limit) break 2;
            }
        }

        usort($out, function($a, $b) {
            return (int)(isset($b['timestamp']) ? $b['timestamp'] : 0) <=> (int)(isset($a['timestamp']) ? $a['timestamp'] : 0);
        });
        return $out;
    }
}

if (!function_exists('proxv2_logs_clear')) {
    function proxv2_logs_clear() {
        $removed = 0;
        foreach ((array)glob(proxv2_logs_dir() . DIRECTORY_SEPARATOR . '*.json') as $file) {
            $items = json_decode((string)@file_get_contents($file), true);
            if (is_array($items)) $removed += count($items);
            @unlink($file);
        }
        return $removed;
    }
}

if (!function_exists('proxv2_log_action_label')) {
    function proxv2_log_action_label($action) {
        $labels = array(
            'vm_start' => 'Démarrage',
            'vm_shutdown' => 'Arrêt propre',
            'vm_stop' => 'Arrêt forcé',
            'vm_reboot' => 'Redémarrage',
            'vm_reset' => 'Reset',
            'vm_create' => 'Création VM',
            'console_open' => 'Ouverture console',
            'server_save' => 'Serveur enregistré',
            'server_bootstrap' => 'Accès API créé',
            'server_delete' => 'Serveur supprimé',
            'iso_upload' => 'ISO envoyée'
        );
        return isset($labels[$action]) ? $labels[$action] : str_replace('_', ' ', ucfirst((string)$action));
    }
}

if (!function_exists('proxv2_log')) {
    function proxv2_log($action, $target, $status, $details, $extra) {
        $email = proxv2_user_email();
        if ($email === '') return false;

        $dir = proxv2_logs_dir();
        $file = $dir . DIRECTORY_SEPARATOR . date('Y-m-d') . '.json';
        $profile = proxv2_profile();
        $entry = array(
            'id' => date('YmdHis') . '-' . bin2hex(random_bytes(5)),
            'timestamp' => time(),
            'date' => date('c'),
            'module' => 'proxv2',
            'user' => $email,
            'role_system' => isset($profile['role_system']) ? $profile['role_system'] : '',
            'action' => (string)$action,
            'target' => (string)$target,
            'status' => (string)$status,
            'details' => (string)$details,
            'ip' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
            'extra' => is_array($extra) ? $extra : array()
        );

        $fp = @fopen($file, 'c+');
        if (!$fp) return false;
        $written = false;
        if (@flock($fp, LOCK_EX)) {
            rewind($fp);
            $raw = stream_get_contents($fp);
            $items = json_decode((string)$raw, true);
            if (!is_array($items)) $items = array();
            $items[] = $entry;
            ftruncate($fp, 0);
            rewind($fp);
            $written = fwrite($fp, json_encode($items, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) !== false;
            fflush($fp);
            flock($fp, LOCK_UN);
        }
        fclose($fp);
        @chmod($file, 0640);

        if ($written) proxv2_quick_session_event($entry);
        return $written;
    }
}

if (!function_exists('proxv2_quick_session_event')) {
    function proxv2_quick_session_event($entry) {
        $email = proxv2_user_email();
        if ($email === '') return;
        $dir = proxv2_root() . '/users/profiles/' . basename($email) . '/quick-session';
        if (!is_dir($dir)) return;
        $files = (array)glob($dir . '/*.json');
        if (!$files) return;
        usort($files, function($a, $b) { return @filemtime($b) - @filemtime($a); });
        foreach ($files as $file) {
            $qs = json_decode((string)@file_get_contents($file), true);
            if (!is_array($qs)) continue;
            $status = strtolower((string)(isset($qs['status']) ? $qs['status'] : ''));
            if (!in_array($status, array('active', 'open', 'running', 'in_progress'), true)) continue;
            if (!isset($qs['timeline']) || !is_array($qs['timeline'])) $qs['timeline'] = array();
            $qs['timeline'][] = array(
                'timestamp' => isset($entry['timestamp']) ? $entry['timestamp'] : time(),
                'date_iso' => isset($entry['date']) ? $entry['date'] : date('c'),
                'module' => 'proxv2',
                'action' => isset($entry['action']) ? $entry['action'] : 'action',
                'label' => isset($entry['details']) && $entry['details'] !== '' ? $entry['details'] : 'Action ProxV2',
                'target' => isset($entry['target']) ? $entry['target'] : '',
                'status' => isset($entry['status']) ? $entry['status'] : 'info',
                'details' => !empty($entry['extra']) ? json_encode($entry['extra'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : ''
            );
            $qs['updated_at'] = time();
            @file_put_contents($file, json_encode($qs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
            break;
        }
    }
}
