<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
require_once __DIR__ . '/proxv2_lib.php';

if (!proxv2_has_module_access() || !proxv2_user_can('view')) {
  echo "<div class='proxv2-empty'>⛔ Ce module ne vous a pas été attribué.</div>";
  return;
}

$ENABLE_CONSOLE = is_file(__DIR__ . '/novnc/core/rfb.js') && is_file(__DIR__ . '/remote_bridge.php') && proxv2_user_can('console');
$CACHE_TTL = 120;
$CSRF_PROXV2 = proxv2_csrf_token();
$CAN_REFRESH = proxv2_user_can('refresh');
$CAN_START = proxv2_user_can('vm.start');
$CAN_SHUTDOWN = proxv2_user_can('vm.shutdown');
$CAN_STOP = proxv2_user_can('vm.stop');
$CAN_REBOOT = proxv2_user_can('vm.reboot');
$CAN_RESET = proxv2_user_can('vm.reset');
$CAN_LOG_VIEW = proxv2_user_can('logs.view');
$CAN_LOG_EXPORT = proxv2_user_can('logs.export');
$CAN_LOG_DELETE = proxv2_user_can('logs.delete');

$servers = proxv2_list_servers(false);

function proxv2_e($value) {
  return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function proxv2_ago($ts) {
  $d = time() - (int)$ts;
  if ($d < 60) return $d . 's';
  if ($d < 3600) return floor($d / 60) . 'm';
  if ($d < 86400) return floor($d / 3600) . 'h';
  return floor($d / 86400) . 'j';
}

function proxv2_bytes_to_gb($bytes, $decimals = 1) {
  $bytes = (float)$bytes;
  if ($bytes <= 0) return '0';
  return number_format($bytes / (1024 * 1024 * 1024), $decimals, '.', ' ');
}

function proxv2_bytes_to_mb($bytes, $decimals = 1) {
  $bytes = (float)$bytes;
  if ($bytes <= 0) return '0';
  return number_format($bytes / (1024 * 1024), $decimals, '.', ' ');
}

function proxv2_pct($value, $decimals = 1) {
  return round(((float)$value) * 100, $decimals);
}

function proxv2_json_attr($data) {
  return htmlspecialchars(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
}

if (empty($servers)) {
  echo "<link rel='stylesheet' href='modules/proxv2/proxv2.css?v=5'>";
  echo "<div class='proxv2-empty'>Aucun serveur Proxmox configuré.</div>";
  return;
}

echo "<link rel='stylesheet' href='modules/proxv2/proxv2.css?v=5'>";

$needUpdate = false;
?>

<div class="proxv2-root" data-proxv2-root>
<?php foreach ($servers as $srv): ?>
  <?php
    $srvName = isset($srv['name']) ? $srv['name'] : (isset($srv['ip']) ? $srv['ip'] : 'pve');
    $srvId = isset($srv['id']) ? $srv['id'] : proxv2_slug($srvName);
    $srvIp = $srv['ip'] ?? '-';
    $cache = proxv2_read_cache($srv);

    $stale = true;
    if ($cache && isset($cache['ts'])) {
      $stale = (time() - (int)$cache['ts'] > $CACHE_TTL);
    }

    if (!$cache || $stale) {
      $needUpdate = true;
    }

    $cluster = (isset($cache['cluster']) && is_array($cache['cluster'])) ? $cache['cluster'] : array();
    $cpuUsage = isset($cluster['cpu']) ? proxv2_pct($cluster['cpu']) : 0;
    $memUsedGb = isset($cluster['mem']) ? proxv2_bytes_to_gb($cluster['mem'], 1) : '0';
    $memTotalGb = isset($cluster['maxmem']) ? proxv2_bytes_to_gb($cluster['maxmem'], 1) : '0';
    $nodesOnline = (int)(isset($cluster['nodes_online']) ? $cluster['nodes_online'] : 0);
    $nodesTotal = (int)(isset($cluster['nodes_total']) ? $cluster['nodes_total'] : 0);

    $vmsArr = $cache['vms'] ?? [];
    if (is_array($vmsArr)) {
      usort($vmsArr, function($a, $b) {
        if (($a['status'] ?? '') !== ($b['status'] ?? '')) {
          return (($a['status'] ?? '') === 'running') ? -1 : 1;
        }

        return ((int)($a['vmid'] ?? 0)) <=> ((int)($b['vmid'] ?? 0));
      });
    } else {
      $vmsArr = [];
    }

    $runningCount = 0;
    foreach ($vmsArr as $vmCount) {
      if (($vmCount['status'] ?? '') === 'running') {
        $runningCount++;
      }
    }
  ?>

  <section class="proxv2-server-card" data-server-card data-server="<?= proxv2_e($srvId) ?>">
    <header class="proxv2-server-head">
      <button type="button" class="proxv2-server-title" data-server-toggle aria-label="Afficher ou masquer les machines virtuelles">
        <span class="proxv2-server-icon">▣</span>
        <span class="proxv2-server-name"><?= proxv2_e($srvName) ?></span>
        <span class="proxv2-server-ip"><?= proxv2_e($srvIp) ?></span>
      </button>

      <div class="proxv2-server-tools">
        <?php if ($cache && isset($cache['ts'])): ?>
          <span class="proxv2-cache-badge <?= $stale ? 'is-stale' : 'is-fresh' ?>">
            cache <?= proxv2_e(proxv2_ago($cache['ts'])) ?>
          </span>
        <?php else: ?>
          <span class="proxv2-cache-badge is-stale">initialisation</span>
        <?php endif; ?>

        <?php if ($CAN_REFRESH): ?><button type="button" class="proxv2-refresh-btn" data-proxv2-refresh>↻ maj</button><?php endif; ?>
        <span class="proxv2-server-chevron">⌄</span>
      </div>
    </header>

    <div class="proxv2-server-body">
      <?php if (!empty($cache['error'])): ?>
        <div class="proxv2-api-warning">
          ⚠️ Erreur API <?= proxv2_e($cache['error']['where'] ?? '?') ?> — <?= proxv2_e($cache['error']['code'] ?? '?') ?>.
          Affichage basé sur le dernier cache disponible.
        </div>
      <?php endif; ?>

      <?php if (!$cache): ?>
        <div class="proxv2-loading">Chargement des données…</div>
        <div class="proxv2-vm-grid">
          <div class="proxv2-skeleton"></div>
          <div class="proxv2-skeleton"></div>
          <div class="proxv2-skeleton"></div>
        </div>
      <?php else: ?>
        <div class="proxv2-server-metrics">
          <div class="proxv2-metric">
            <span class="proxv2-metric-label">RAM utilisée</span>
            <strong><?= proxv2_e($memUsedGb) ?> / <?= proxv2_e($memTotalGb) ?> Go</strong>
          </div>
          <div class="proxv2-metric">
            <span class="proxv2-metric-label">CPU utilisé</span>
            <strong><?= proxv2_e($cpuUsage) ?>%</strong>
          </div>
          <div class="proxv2-metric">
            <span class="proxv2-metric-label">VM / CT · Nodes</span>
            <strong><?= count($vmsArr) ?> dont <?= $runningCount ?> actifs · <?= $nodesOnline ?>/<?= $nodesTotal ?> nodes</strong>
          </div>
        </div>

        <?php if (empty($vmsArr)): ?>
          <div class="proxv2-empty">Aucune machine virtuelle dans le cache.</div>
        <?php else: ?>
          <div class="proxv2-vm-grid">
            <?php foreach ($vmsArr as $vm): ?>
              <?php
                $vmid = (int)($vm['vmid'] ?? 0);
                $name = trim((string)($vm['name'] ?? ('VM-' . ($vmid ?: '?'))));
                $running = (($vm['status'] ?? '') === 'running');
                $statusText = $running ? 'running' : (($vm['status'] ?? '') ?: 'stopped');

                $typeForVm = strtolower((string)($vm['type'] ?? 'qemu'));
                if ($typeForVm !== 'lxc') {
                  $typeForVm = 'qemu';
                }

                $nodeForAction = $srvId;
                $realNode = isset($vm['node']) ? $vm['node'] : '-';

                $cpu = isset($vm['cpu']) ? proxv2_pct($vm['cpu']) : 0;
                $ramUsedMb = isset($vm['mem']) ? proxv2_bytes_to_mb($vm['mem'], 1) : '0';
                $ramMaxMb = (isset($vm['maxmem']) && (float)$vm['maxmem'] > 0) ? proxv2_bytes_to_mb($vm['maxmem'], 1) : '0';
                $ramPct = ((float)($vm['maxmem'] ?? 0) > 0) ? round(((float)($vm['mem'] ?? 0) / (float)$vm['maxmem']) * 100, 1) : 0;

                $diskUsedGb = isset($vm['disk']) ? proxv2_bytes_to_gb($vm['disk'], 1) : '0';
                $diskMaxGb = (isset($vm['maxdisk']) && (float)$vm['maxdisk'] > 0) ? proxv2_bytes_to_gb($vm['maxdisk'], 1) : '0';
                $diskPct = ((float)($vm['maxdisk'] ?? 0) > 0) ? round(((float)($vm['disk'] ?? 0) / (float)$vm['maxdisk']) * 100, 1) : 0;

                $vmPayload = [
                  'server' => $srvName,
                  'server_id' => $srvId,
                  'server_ip' => $srvIp,
                  'node' => $nodeForAction,
                  'real_node' => $realNode,
                  'vmid' => $vmid,
                  'name' => $name,
                  'status' => $statusText,
                  'running' => $running,
                  'type' => $typeForVm,
                  'cpu' => $cpu,
                  'ram_used' => $ramUsedMb,
                  'ram_total' => $ramMaxMb,
                  'ram_pct' => $ramPct,
                  'disk_used' => $diskUsedGb,
                  'disk_total' => $diskMaxGb,
                  'disk_pct' => $diskPct
                ];
              ?>

              <button
                type="button"
                class="proxv2-vm-tile <?= $running ? 'is-running' : 'is-stopped' ?>"
                data-vm-card
                data-vm="<?= proxv2_json_attr($vmPayload) ?>"
                title="Ouvrir les options de <?= proxv2_e($name) ?>"
              >
                <span class="proxv2-vm-topline">
                  <span class="proxv2-vm-status-dot"></span>
                  <span class="proxv2-vm-id">#<?= $vmid ?></span>
                  <span class="proxv2-vm-state"><?= proxv2_e($statusText) ?></span>
                </span>

                <span class="proxv2-vm-name"><?= proxv2_e($name) ?></span>

                <span class="proxv2-vm-mini-metrics">
                  <span>CPU <?= proxv2_e($cpu) ?>%</span>
                  <span>RAM <?= proxv2_e($ramPct) ?>%</span>
                </span>
              </button>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
    </div>
  </section>
<?php endforeach; ?>

<?php if ($CAN_LOG_VIEW): ?>
  <section class="proxv2-task-panel" data-proxv2-task-panel>
    <header class="proxv2-task-head">
      <div>
        <span class="proxv2-task-kicker">Historique ProxV2</span>
        <h4>Journal des tâches</h4>
      </div>
      <div class="proxv2-task-tools">
        <button type="button" data-proxv2-log-refresh>↻ Actualiser</button>
        <?php if ($CAN_LOG_EXPORT): ?>
          <a href="modules/proxv2/proxv2_logs.php?mode=pdf" data-proxv2-log-pdf>PDF</a>
          <button type="button" data-proxv2-log-print>Imprimer</button>
        <?php endif; ?>
        <?php if ($CAN_LOG_DELETE): ?>
          <button type="button" class="danger" data-proxv2-log-clear>Supprimer les logs</button>
        <?php endif; ?>
      </div>
    </header>

    <div class="proxv2-task-table-wrap">
      <table class="proxv2-task-table">
        <thead>
          <tr>
            <th>Date / heure</th>
            <th>Utilisateur</th>
            <th>Action</th>
            <th>Cible</th>
            <th>État</th>
            <th>Serveur / node</th>
            <th>Détails</th>
          </tr>
        </thead>
        <tbody data-proxv2-log-rows>
          <tr><td colspan="7" class="proxv2-task-empty">Chargement du journal…</td></tr>
        </tbody>
      </table>
    </div>

    <footer class="proxv2-task-foot">
      <span data-proxv2-log-count>0 tâche</span>
      <span>Stockage persistant : /data/modules/proxv2/logs</span>
    </footer>
  </section>
<?php endif; ?>

  <div class="proxv2-toast" data-proxv2-toast></div>
</div>

<template id="proxv2-vm-window-template">
  <section class="proxv2-modal-window proxv2-vm-window" data-proxv2-vm-window role="dialog" aria-modal="false">
    <header class="proxv2-modal-head" data-proxv2-drag-handle>
      <div>
        <span class="proxv2-modal-kicker">Machine virtuelle</span>
        <h3 data-proxv2-window-title>VM</h3>
      </div>
      <button type="button" class="proxv2-modal-close" data-proxv2-window-close aria-label="Fermer">×</button>
    </header>

    <div class="proxv2-modal-body">
      <div class="proxv2-modal-summary">
        <div>
          <span class="proxv2-detail-label">Serveur</span>
          <strong data-window-server>-</strong>
        </div>
        <div>
          <span class="proxv2-detail-label">Node Proxmox</span>
          <strong data-window-real-node>-</strong>
        </div>
        <div>
          <span class="proxv2-detail-label">Type</span>
          <strong data-window-type>-</strong>
        </div>
        <div>
          <span class="proxv2-detail-label">Statut</span>
          <strong data-window-status>-</strong>
        </div>
      </div>

      <div class="proxv2-resource-grid">
        <div class="proxv2-resource-card">
          <span class="proxv2-detail-label">CPU</span>
          <strong data-window-cpu>0%</strong>
          <div class="proxv2-progress"><span data-window-cpu-bar></span></div>
        </div>

        <div class="proxv2-resource-card">
          <span class="proxv2-detail-label">RAM</span>
          <strong data-window-ram>0 / 0 Mo</strong>
          <div class="proxv2-progress"><span data-window-ram-bar></span></div>
        </div>

        <div class="proxv2-resource-card">
          <span class="proxv2-detail-label">Disque</span>
          <strong data-window-disk>0 / 0 Go</strong>
          <div class="proxv2-progress"><span data-window-disk-bar></span></div>
        </div>
      </div>

      <div class="proxv2-actions">
        <?php if ($CAN_START): ?><button type="button" data-window-action="start">Démarrer</button><?php endif; ?>
        <?php if ($CAN_SHUTDOWN): ?><button type="button" data-window-action="shutdown">Éteindre proprement</button><?php endif; ?>
        <?php if ($CAN_STOP): ?><button type="button" data-window-action="stop">Stop forcé</button><?php endif; ?>
        <?php if ($CAN_REBOOT): ?><button type="button" data-window-action="reboot">Redémarrer</button><?php endif; ?>
        <?php if ($CAN_RESET): ?><button type="button" data-window-action="reset">Reset</button><?php endif; ?>
        <?php if ($ENABLE_CONSOLE): ?><button type="button" data-window-remote>Remote · lecture seule</button><?php endif; ?>
      </div>

      <?php if (!$ENABLE_CONSOLE): ?>
      <div class="proxv2-premium-note">
        Remote noVNC indisponible : composants locaux absents.
      </div>
      <?php endif; ?>
    </div>

    <div class="proxv2-vm-resize" data-proxv2-resize title="Redimensionner"></div>
  </section>
</template>

<div id="pv1-desktop"></div>
<div id="pv1-console" aria-modal="true" role="dialog">
  <div class="title">
    <span id="pv1-cap">Console</span>
    <button class="close" type="button">×</button>
  </div>
  <div class="body">
    <iframe id="pv1-iframe" src="about:blank" referrerpolicy="no-referrer"></iframe>
  </div>
  <div class="grip" title="Redimensionner"></div>
</div>

<script>
(function(){
  const root = document.querySelector('[data-proxv2-root]');
  const CSRF_PROXV2 = <?= json_encode($CSRF_PROXV2) ?>;
  const CAN_LOG_VIEW = <?= $CAN_LOG_VIEW ? 'true' : 'false' ?>;
  const CAN_LOG_EXPORT = <?= $CAN_LOG_EXPORT ? 'true' : 'false' ?>;
  const CAN_LOG_DELETE = <?= $CAN_LOG_DELETE ? 'true' : 'false' ?>;
  const PROXV2_LOGS_URL = 'modules/proxv2/proxv2_logs.php';
  const ENABLE_CONSOLE = <?= $ENABLE_CONSOLE ? 'true' : 'false' ?>;
  if (!root) return;

  const vmTemplate = document.getElementById('proxv2-vm-window-template');
  const toastBox = document.querySelector('[data-proxv2-toast]');
  const desktop = document.getElementById('pv1-desktop');
  const consoleWin = document.getElementById('pv1-console');
  const consoleCap = document.getElementById('pv1-cap');
  const consoleFrame = document.getElementById('pv1-iframe');
  const logRows = root.querySelector('[data-proxv2-log-rows]');
  const logCount = root.querySelector('[data-proxv2-log-count]');
  let lastLogItems = [];

  let vmWindowSequence = 0;
  let topZ = 10080;

  function toast(message) {
    if (!toastBox) return;
    toastBox.textContent = message;
    toastBox.classList.add('is-visible');
    clearTimeout(window.__proxv2_toast);
    window.__proxv2_toast = setTimeout(() => {
      toastBox.classList.remove('is-visible');
    }, 2200);
  }

  function escHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function formatLogDate(item) {
    const ts = Number(item && item.timestamp ? item.timestamp : 0);
    if (ts > 0) {
      const d = new Date(ts * 1000);
      return d.toLocaleString('fr-FR', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit', second:'2-digit'});
    }
    return item && item.date ? String(item.date) : '-';
  }

  function logStatusMeta(status) {
    const value = String(status || '').toLowerCase();
    if (['success', 'ok', 'done'].includes(value)) return {label:'OK', cls:'is-success'};
    if (['error', 'failed', 'danger'].includes(value)) return {label:'Erreur', cls:'is-error'};
    return {label: value || 'Info', cls:'is-info'};
  }

  function renderTaskLogs(items) {
    if (!logRows) return;
    lastLogItems = Array.isArray(items) ? items : [];

    if (!lastLogItems.length) {
      logRows.innerHTML = '<tr><td colspan="7" class="proxv2-task-empty">Aucune tâche enregistrée.</td></tr>';
      if (logCount) logCount.textContent = '0 tâche';
      return;
    }

    logRows.innerHTML = lastLogItems.map((item) => {
      const meta = logStatusMeta(item.status);
      return `<tr>
        <td class="proxv2-task-nowrap">${escHtml(formatLogDate(item))}</td>
        <td>${escHtml(item.user || '-')}</td>
        <td><strong>${escHtml(item.action_label || item.action || '-')}</strong></td>
        <td>${escHtml(item.target || '-')}</td>
        <td><span class="proxv2-task-status ${meta.cls}"><span></span>${escHtml(meta.label)}</span></td>
        <td>${escHtml(item.where || '-')}</td>
        <td class="proxv2-task-details">${escHtml(item.details || '-')}</td>
      </tr>`;
    }).join('');

    if (logCount) logCount.textContent = `${lastLogItems.length} tâche${lastLogItems.length > 1 ? 's' : ''} affichée${lastLogItems.length > 1 ? 's' : ''}`;
  }

  async function loadTaskLogs() {
    if (!CAN_LOG_VIEW || !logRows) return;
    try {
      const response = await fetch(PROXV2_LOGS_URL + '?mode=list&limit=200&t=' + Date.now(), {cache:'no-store'});
      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload || !payload.ok) throw new Error(payload && payload.message ? payload.message : `HTTP ${response.status}`);
      renderTaskLogs(payload.items || []);
    } catch (error) {
      logRows.innerHTML = `<tr><td colspan="7" class="proxv2-task-empty">Impossible de charger le journal : ${escHtml(error.message)}</td></tr>`;
    }
  }

  function printTaskLogs() {
    if (!CAN_LOG_EXPORT || !lastLogItems.length) {
      toast('ℹ️ Aucun log à imprimer.');
      return;
    }

    const rows = lastLogItems.map((item) => {
      const meta = logStatusMeta(item.status);
      return `<tr><td>${escHtml(formatLogDate(item))}</td><td>${escHtml(item.user || '-')}</td><td>${escHtml(item.action_label || item.action || '-')}</td><td>${escHtml(item.target || '-')}</td><td>${escHtml(meta.label)}</td><td>${escHtml(item.where || '-')}</td><td>${escHtml(item.details || '-')}</td></tr>`;
    }).join('');

    const iframe = document.createElement('iframe');
    iframe.setAttribute('aria-hidden', 'true');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '1px';
    iframe.style.height = '1px';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    iframe.onload = () => {
      setTimeout(() => {
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } finally {
          setTimeout(() => iframe.remove(), 1200);
        }
      }, 80);
    };

    iframe.srcdoc = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>ProxV2 - Journal des tâches</title><style>
      body{font-family:Arial,sans-serif;margin:18px;color:#111}h1{font-size:18px;margin:0 0 4px}p{font-size:11px;margin:0 0 14px;color:#555}table{width:100%;border-collapse:collapse;font-size:9px}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#eee}tr{break-inside:avoid}@page{size:landscape;margin:10mm}
    </style></head><body><h1>ProxV2 — Journal des tâches</h1><p>Imprimé le ${escHtml(new Date().toLocaleString('fr-FR'))}</p><table><thead><tr><th>Date / heure</th><th>Utilisateur</th><th>Action</th><th>Cible</th><th>État</th><th>Serveur / node</th><th>Détails</th></tr></thead><tbody>${rows}</tbody></table></body></html>`;
  }

  async function clearTaskLogs() {
    if (!CAN_LOG_DELETE) return;
    if (!confirm('Supprimer définitivement tous les logs ProxV2 ?')) return;
    try {
      const response = await fetch(PROXV2_LOGS_URL, {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({csrf:CSRF_PROXV2, action:'clear'})
      });
      const payload = await response.json().catch(() => null);
      if (!response.ok || !payload || !payload.ok) throw new Error(payload && payload.message ? payload.message : `HTTP ${response.status}`);
      renderTaskLogs([]);
      toast(`✅ ${Number(payload.removed || 0)} log(s) supprimé(s)`);
    } catch (error) {
      toast('❌ ' + error.message);
    }
  }

  function clampPct(value) {
    const n = Number(value);
    if (!Number.isFinite(n)) return 0;
    return Math.max(0, Math.min(100, n));
  }

  function setText(win, selector, value) {
    const el = win.querySelector(selector);
    if (el) el.textContent = value;
  }

  function setBar(win, selector, value) {
    const el = win.querySelector(selector);
    if (el) el.style.width = clampPct(value) + '%';
  }

  function bringToFront(win) {
    if (!win) return;
    topZ += 1;
    win.style.zIndex = String(topZ);
  }

  function updateActionState(win, vm) {
    const running = !!vm.running;

    win.querySelectorAll('[data-window-action]').forEach((button) => {
      const action = button.getAttribute('data-window-action');

      if (action === 'start') {
        button.disabled = running;
      } else if (action === 'reset' && (vm.type || 'qemu') !== 'qemu') {
        button.disabled = true;
      } else {
        button.disabled = !running;
      }
    });
  }

  function syncWindowStatus(win, vm) {
    setText(win, '[data-window-status]', vm.status || '-');
    updateActionState(win, vm);
  }

  function defaultWindowPosition() {
    const offset = (vmWindowSequence % 8) * 28;
    const width = Math.min(760, Math.max(320, window.innerWidth - 32));
    const left = window.scrollX + Math.max(16, Math.round((window.innerWidth - width) / 2)) + offset;
    const top = window.scrollY + 72 + offset;
    return {left, top};
  }

  function openVmWindow(vm) {
    if (!vmTemplate) {
      toast('❌ Gabarit de fenêtre VM introuvable');
      return;
    }

    vmWindowSequence += 1;
    const fragment = vmTemplate.content.cloneNode(true);
    const win = fragment.querySelector('[data-proxv2-vm-window]');
    if (!win) return;

    win.__proxv2Vm = Object.assign({}, vm);

    // Géométrie critique appliquée en inline : même si le navigateur a encore
    // l'ancienne feuille CSS en cache, une fenêtre VM reste une vraie fenêtre.
    win.style.position = 'absolute';
    win.style.boxSizing = 'border-box';
    win.style.width = Math.min(760, Math.max(320, window.innerWidth - 32)) + 'px';
    win.style.maxWidth = 'calc(100vw - 32px)';
    win.style.maxHeight = 'calc(100vh - 36px)';
    win.style.overflow = 'auto';
    win.style.pointerEvents = 'auto';

    setText(win, '[data-proxv2-window-title]', `#${vm.vmid} — ${vm.name}`);
    setText(win, '[data-window-server]', vm.server || '-');
    setText(win, '[data-window-real-node]', vm.real_node || '-');
    setText(win, '[data-window-type]', vm.type || 'qemu');
    setText(win, '[data-window-status]', vm.status || '-');
    setText(win, '[data-window-cpu]', `${vm.cpu || 0}%`);
    setText(win, '[data-window-ram]', `${vm.ram_used || 0} / ${vm.ram_total || 0} Mo`);
    setText(win, '[data-window-disk]', `${vm.disk_used || 0} / ${vm.disk_total || 0} Go`);

    setBar(win, '[data-window-cpu-bar]', vm.cpu || 0);
    setBar(win, '[data-window-ram-bar]', vm.ram_pct || 0);
    setBar(win, '[data-window-disk-bar]', vm.disk_pct || 0);
    updateActionState(win, win.__proxv2Vm);

    const pos = defaultWindowPosition();
    win.style.left = pos.left + 'px';
    win.style.top = pos.top + 'px';

    document.body.appendChild(win);
    bringToFront(win);
    installVmWindowInteractions(win);
    recomputeDesktopBounds();
  }

  function closeVmWindow(win) {
    if (!win) return;
    win.remove();
    recomputeDesktopBounds();
  }

  function installVmWindowInteractions(win) {
    const bar = win.querySelector('[data-proxv2-drag-handle]');
    const grip = win.querySelector('[data-proxv2-resize]');
    const closeButton = win.querySelector('[data-proxv2-window-close]');

    win.addEventListener('pointerdown', () => bringToFront(win));

    if (closeButton) {
      closeButton.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        closeVmWindow(win);
      });
    }

    win.addEventListener('click', (event) => {
      const actionButton = event.target.closest('[data-window-action]');
      if (actionButton && !actionButton.disabled) {
        runVmAction(win, actionButton.getAttribute('data-window-action'));
        return;
      }

      const remoteButton = event.target.closest('[data-window-remote]');
      if (remoteButton && win.__proxv2Vm) {
        openConsole(win.__proxv2Vm);
      }
    });

    if (bar) {
      bar.addEventListener('pointerdown', (event) => {
        if (event.target.closest('button, a, input, select, textarea')) return;

        bringToFront(win);
        const r = win.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;
        const startLeft = r.left + window.scrollX;
        const startTop = r.top + window.scrollY;

        bar.setPointerCapture?.(event.pointerId);
        win.classList.add('is-dragging');
        event.preventDefault();

        const onMove = (moveEvent) => {
          const nextLeft = Math.max(0, startLeft + moveEvent.clientX - startX);
          const nextTop = Math.max(0, startTop + moveEvent.clientY - startY);
          win.style.left = nextLeft + 'px';
          win.style.top = nextTop + 'px';
          recomputeDesktopBounds();
        };

        const onEnd = () => {
          win.classList.remove('is-dragging');
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', onEnd);
          window.removeEventListener('pointercancel', onEnd);
          recomputeDesktopBounds();
        };

        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', onEnd);
        window.addEventListener('pointercancel', onEnd);
      });
    }

    if (grip) {
      grip.addEventListener('pointerdown', (event) => {
        bringToFront(win);
        const r = win.getBoundingClientRect();
        const startX = event.clientX;
        const startY = event.clientY;
        const startWidth = r.width;
        const startHeight = r.height;
        const minWidth = Math.min(420, Math.max(280, window.innerWidth - 20));
        const minHeight = 270;

        grip.setPointerCapture?.(event.pointerId);
        win.classList.add('is-resizing');
        event.preventDefault();
        event.stopPropagation();

        const onMove = (moveEvent) => {
          win.style.width = Math.max(minWidth, startWidth + moveEvent.clientX - startX) + 'px';
          win.style.height = Math.max(minHeight, startHeight + moveEvent.clientY - startY) + 'px';
          win.style.maxHeight = 'none';
          recomputeDesktopBounds();
        };

        const onEnd = () => {
          win.classList.remove('is-resizing');
          window.removeEventListener('pointermove', onMove);
          window.removeEventListener('pointerup', onEnd);
          window.removeEventListener('pointercancel', onEnd);
          recomputeDesktopBounds();
        };

        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', onEnd);
        window.addEventListener('pointercancel', onEnd);
      });
    }
  }

  async function runVmAction(win, action) {
    const vm = win && win.__proxv2Vm;
    if (!vm) return;

    if (['stop', 'reset'].includes(action)) {
      if (!confirm(`Confirmer ${action.toUpperCase()} sur la VM #${vm.vmid} ?`)) {
        return;
      }
    }

    const buttons = Array.from(win.querySelectorAll('[data-window-action]'));
    buttons.forEach((button) => button.disabled = true);

    try {
      const response = await fetch('modules/proxv2/action.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          csrf: CSRF_PROXV2,
          server_id: vm.server_id || vm.node,
          vmid: vm.vmid,
          type: vm.type || 'qemu',
          action
        })
      });

      const payload = await response.json().catch(() => null);

      if (!response.ok || !payload || !payload.ok) {
        throw new Error((payload && (payload.message || payload.error)) ? (payload.message || payload.error) : `HTTP ${response.status}`);
      }

      if (action === 'start') {
        vm.running = true;
        vm.status = 'running';
      } else if (action === 'stop' || action === 'shutdown') {
        vm.running = false;
        vm.status = 'stopped';
      }

      syncWindowStatus(win, vm);
      toast(`✅ ${action} lancé sur VM #${vm.vmid}`);
      loadTaskLogs();
      fetch('modules/proxv2/proxv2_fetch.php?csrf=' + encodeURIComponent(CSRF_PROXV2) + '&t=' + Date.now(), {cache:'no-store'})
        .catch(() => {});
    } catch (error) {
      toast(`❌ ${error.message}`);
      updateActionState(win, vm);
      loadTaskLogs();
    }
  }

  function openConsole(vm) {
    if (!consoleWin || !consoleFrame) return;

    consoleCap.textContent = `Remote lecture seule · VM #${vm.vmid} (${vm.server})`;
    if (!ENABLE_CONSOLE) { toast('ℹ️ Remote noVNC n’est pas disponible.'); return; }
    consoleFrame.src = `modules/proxv2/console.php?server_id=${encodeURIComponent(vm.server_id || vm.node)}&vmid=${encodeURIComponent(vm.vmid)}&type=${encodeURIComponent(vm.type || 'qemu')}&csrf=${encodeURIComponent(CSRF_PROXV2)}`;
    consoleWin.style.display = 'block';
    bringToFront(consoleWin);
    recomputeDesktopBounds();
  }

  root.addEventListener('click', (event) => {
    const refreshLogs = event.target.closest('[data-proxv2-log-refresh]');
    if (refreshLogs) {
      event.preventDefault();
      loadTaskLogs();
      return;
    }

    const printLogs = event.target.closest('[data-proxv2-log-print]');
    if (printLogs) {
      event.preventDefault();
      printTaskLogs();
      return;
    }

    const clearLogs = event.target.closest('[data-proxv2-log-clear]');
    if (clearLogs) {
      event.preventDefault();
      clearTaskLogs();
    }
  });

  root.addEventListener('click', (event) => {
    const refresh = event.target.closest('[data-proxv2-refresh]');
    if (!refresh) return;

    event.preventDefault();
    event.stopPropagation();

    toast('⏳ Mise à jour du cache...');
    fetch('modules/proxv2/proxv2_fetch.php?csrf=' + encodeURIComponent(CSRF_PROXV2) + '&t=' + Date.now(), {cache:'no-store'})
      .then(() => setTimeout(() => location.reload(), 600))
      .catch((error) => toast('❌ ' + error.message));
  });

  root.addEventListener('click', (event) => {
    const toggle = event.target.closest('[data-server-toggle]');
    if (!toggle) return;

    const card = toggle.closest('[data-server-card]');
    if (!card) return;

    card.classList.toggle('is-collapsed');
  });

  root.addEventListener('click', (event) => {
    const tile = event.target.closest('[data-vm-card]');
    if (!tile) return;

    try {
      const vm = JSON.parse(tile.getAttribute('data-vm') || '{}');
      openVmWindow(vm);
    } catch (error) {
      toast('❌ Données VM illisibles');
    }
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;

    const windows = Array.from(document.querySelectorAll('[data-proxv2-vm-window]'));
    if (!windows.length) return;

    windows.sort((a, b) => (parseInt(b.style.zIndex || '0', 10) - parseInt(a.style.zIndex || '0', 10)));
    closeVmWindow(windows[0]);
  });

  if (consoleWin) {
    const closeButton = consoleWin.querySelector('.close');
    const bar = consoleWin.querySelector('.title');
    const grip = consoleWin.querySelector('.grip');

    if (consoleWin.parentElement !== document.body) {
      document.body.appendChild(consoleWin);
    }

    if (desktop && desktop.parentElement !== document.body) {
      document.body.appendChild(desktop);
    }

    consoleWin.addEventListener('pointerdown', () => bringToFront(consoleWin));

    if (closeButton) {
      closeButton.addEventListener('click', () => {
        consoleFrame.src = 'about:blank';
        consoleWin.style.display = 'none';
        recomputeDesktopBounds();
      });
    }

    let drag = null;
    if (bar) {
      bar.addEventListener('mousedown', (event) => {
        const r = consoleWin.getBoundingClientRect();
        drag = {
          ox: event.clientX,
          oy: event.clientY,
          left: r.left + window.scrollX,
          top: r.top + window.scrollY
        };
        bringToFront(consoleWin);
        event.preventDefault();
      });
    }

    window.addEventListener('mousemove', (event) => {
      if (!drag) return;

      consoleWin.style.left = (drag.left + event.clientX - drag.ox) + 'px';
      consoleWin.style.top = (drag.top + event.clientY - drag.oy) + 'px';
      recomputeDesktopBounds();
    });

    window.addEventListener('mouseup', () => {
      drag = null;
      recomputeDesktopBounds();
    });

    let resize = null;
    if (grip) {
      grip.addEventListener('mousedown', (event) => {
        const r = consoleWin.getBoundingClientRect();
        resize = {
          ox: event.clientX,
          oy: event.clientY,
          w: r.width,
          h: r.height
        };
        bringToFront(consoleWin);
        event.preventDefault();
      });
    }

    window.addEventListener('mousemove', (event) => {
      if (!resize) return;

      consoleWin.style.width = Math.max(520, resize.w + event.clientX - resize.ox) + 'px';
      consoleWin.style.height = Math.max(320, resize.h + event.clientY - resize.oy) + 'px';
      recomputeDesktopBounds();
    });

    window.addEventListener('mouseup', () => {
      resize = null;
      recomputeDesktopBounds();
    });
  }

  function recomputeDesktopBounds() {
    if (!desktop) return;

    const viewportWidth = document.documentElement.clientWidth || window.innerWidth;
    const viewportHeight = document.documentElement.clientHeight || window.innerHeight;
    let maxRight = viewportWidth;
    let maxBottom = viewportHeight;

    document.querySelectorAll('[data-proxv2-vm-window]').forEach((win) => {
      const r = win.getBoundingClientRect();
      maxRight = Math.max(maxRight, r.left + window.scrollX + r.width + 40);
      maxBottom = Math.max(maxBottom, r.top + window.scrollY + r.height + 40);
    });

    if (consoleWin && consoleWin.style.display !== 'none') {
      const r = consoleWin.getBoundingClientRect();
      maxRight = Math.max(maxRight, r.left + window.scrollX + r.width + 40);
      maxBottom = Math.max(maxBottom, r.top + window.scrollY + r.height + 40);
    }

    desktop.style.width = Math.ceil(maxRight) + 'px';
    desktop.style.height = Math.ceil(maxBottom) + 'px';
  }

  loadTaskLogs();

  const NEED_UPDATE = <?= $needUpdate ? 'true' : 'false'; ?>;
  if (NEED_UPDATE) {
    const key = 'proxv2_last_bg_refresh';
    const now = Date.now();
    const ttl = 15000;
    const last = parseInt(sessionStorage.getItem(key) || '0', 10);

    if (now - last >= ttl) {
      sessionStorage.setItem(key, String(now));
      fetch('modules/proxv2/proxv2_fetch.php?csrf=' + encodeURIComponent(CSRF_PROXV2) + '&t=' + Date.now(), {cache:'no-store'})
        .then(() => setTimeout(() => location.reload(), 700))
        .catch(() => {});
    }
  }
})();
</script>
