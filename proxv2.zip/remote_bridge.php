<?php
/*
 * ProxV2 V2 - tunnel WebSocket éphémère pour noVNC.
 * CLI uniquement. Une session = un listener = un client, puis arrêt.
 * Le tunnel injecte le PVEAuthCookie côté serveur afin que le navigateur
 * n'ait jamais besoin d'être connecté à l'interface Proxmox.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

function pv2b_fail($message, $configFile, $readyFile = '') {
    if ($configFile && is_file($configFile)) @unlink($configFile);
    if ($readyFile && is_file($readyFile)) @unlink($readyFile);
    fwrite(STDERR, (string)$message . PHP_EOL);
    exit(1);
}

function pv2b_read_headers($stream, $maxBytes, $timeoutSeconds) {
    stream_set_timeout($stream, $timeoutSeconds);
    $buf = '';
    while (strpos($buf, "\r\n\r\n") === false && strlen($buf) < $maxBytes && !feof($stream)) {
        $chunk = fread($stream, 4096);
        if ($chunk === false || $chunk === '') {
            $meta = stream_get_meta_data($stream);
            if (!empty($meta['timed_out'])) break;
            usleep(10000);
            continue;
        }
        $buf .= $chunk;
    }
    return $buf;
}

function pv2b_header($headers, $name) {
    $name = strtolower($name);
    foreach (preg_split('/\r\n/', $headers) as $line) {
        $pos = strpos($line, ':');
        if ($pos === false) continue;
        if (strtolower(trim(substr($line, 0, $pos))) === $name) return trim(substr($line, $pos + 1));
    }
    return '';
}

function pv2b_ws_accept($key) {
    return base64_encode(sha1(trim($key) . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11', true));
}


function pv2b_write_all($stream, $data) {
    $len = strlen($data);
    $off = 0;
    while ($off < $len) {
        $written = @fwrite($stream, substr($data, $off));
        if ($written === false || $written === 0) return false;
        $off += $written;
    }
    return true;
}

/*
 * Décode une frame WebSocket navigateur -> bridge sans la modifier.
 * Le raw original (masqué comme l'exige WebSocket côté client) est conservé
 * afin d'être transmis tel quel à Proxmox lorsque la frame est autorisée.
 */
function pv2b_ws_take_frame(&$buffer) {
    $size = strlen($buffer);
    if ($size < 2) return null;

    $b1 = ord($buffer[0]);
    $b2 = ord($buffer[1]);
    $opcode = $b1 & 0x0f;
    $fin = (($b1 & 0x80) !== 0);
    $masked = (($b2 & 0x80) !== 0);
    $len = $b2 & 0x7f;
    $pos = 2;

    if ($len === 126) {
        if ($size < 4) return null;
        $tmp = unpack('nlen', substr($buffer, 2, 2));
        $len = (int)$tmp['len'];
        $pos = 4;
    } elseif ($len === 127) {
        if ($size < 10) return null;
        $tmp = unpack('Nhi/Nlo', substr($buffer, 2, 8));
        if ((int)$tmp['hi'] !== 0 || (int)$tmp['lo'] > 8388608) {
            return array('error' => 'Frame WebSocket trop grande.');
        }
        $len = (int)$tmp['lo'];
        $pos = 10;
    }

    $maskKey = '';
    if ($masked) {
        if ($size < $pos + 4) return null;
        $maskKey = substr($buffer, $pos, 4);
        $pos += 4;
    }

    $total = $pos + $len;
    if ($size < $total) return null;

    $raw = substr($buffer, 0, $total);
    $payload = substr($buffer, $pos, $len);
    $buffer = (string)substr($buffer, $total);

    if ($masked && $len > 0) {
        $decoded = '';
        for ($i = 0; $i < $len; $i++) {
            $decoded .= chr(ord($payload[$i]) ^ ord($maskKey[$i % 4]));
        }
        $payload = $decoded;
    }

    return array(
        'error' => '',
        'raw' => $raw,
        'opcode' => $opcode,
        'fin' => $fin,
        'payload' => $payload
    );
}

/*
 * V2 = lecture seule côté SERVEUR.
 *
 * viewOnly dans noVNC reste activé pour l'UX, mais ce bridge constitue la
 * vraie barrière : même si quelqu'un réactive clavier/souris dans le JS,
 * les messages RFB d'entrée sont jetés avant d'atteindre Proxmox.
 *
 * Messages client RFB bloqués :
 *   4   KeyEvent
 *   5   PointerEvent
 *   6   ClientCutText / presse-papiers étendu
 *   255 QEMU Extended Key Event
 */
function pv2b_rfb_input_blocked($payload, &$state) {
    $len = strlen($payload);
    if ($len === 0) return false;

    $phase = isset($state['phase']) ? (int)$state['phase'] : 0;

    /*
     * Ne jamais filtrer pendant l'authentification VNC : la réponse challenge
     * est binaire et pourrait commencer par 04/05/06 par hasard.
     * Proxmox/noVNC suit ici : version -> sécurité -> challenge -> ClientInit.
     */
    if ($phase < 4) {
        if ($phase === 0 && $len >= 12 && substr($payload, 0, 4) === 'RFB ') {
            $state['phase'] = 1;
            return false;
        }
        if ($phase === 1 && $len === 1) {
            $state['phase'] = 2;
            return false;
        }
        if ($phase === 2 && $len === 16) {
            $state['phase'] = 3;
            return false;
        }
        if ($phase === 3 && $len === 1) {
            $state['phase'] = 4;
            return false;
        }

        /*
         * Filet de sécurité si une version noVNC regroupe différemment les
         * paquets : la première vraie commande de configuration marque la fin
         * du handshake, sans bloquer cette commande légitime.
         */
        $type = ord($payload[0]);
        if (($type === 0 && $len === 20) ||
            ($type === 2 && $len >= 4 && (($len - 4) % 4) === 0) ||
            ($type === 3 && $len === 10) ||
            ($type === 251 && $len >= 8)) {
            $state['phase'] = 4;
        }
        return false;
    }

    $type = ord($payload[0]);
    if ($type === 4 && $len === 8) return true;
    if ($type === 5 && $len === 6) return true;
    if ($type === 6 && $len >= 8) return true;
    if ($type === 255 && $len === 12 && ord($payload[1]) === 0) return true;

    return false;
}

$configFile = isset($argv[1]) ? (string)$argv[1] : '';
if ($configFile === '' || !is_file($configFile)) pv2b_fail('Configuration Remote absente.', $configFile);
$cfg = json_decode((string)@file_get_contents($configFile), true);
if (!is_array($cfg)) pv2b_fail('Configuration Remote invalide.', $configFile);
if ((int)(isset($cfg['expires_at']) ? $cfg['expires_at'] : 0) < time()) pv2b_fail('Configuration Remote expirée.', $configFile);

$listenPort = (int)(isset($cfg['listen_port']) ? $cfg['listen_port'] : 0);
$token = (string)(isset($cfg['session_token']) ? $cfg['session_token'] : '');
$readyFile = (string)(isset($cfg['ready_file']) ? $cfg['ready_file'] : '');
$upHost = (string)(isset($cfg['upstream_host']) ? $cfg['upstream_host'] : '');
$upPort = (int)(isset($cfg['upstream_port']) ? $cfg['upstream_port'] : 8006);
$upPath = (string)(isset($cfg['upstream_path']) ? $cfg['upstream_path'] : '');
$authCookie = (string)(isset($cfg['pve_auth_cookie']) ? $cfg['pve_auth_cookie'] : '');
$maxRuntime = max(60, min(14400, (int)(isset($cfg['max_runtime']) ? $cfg['max_runtime'] : 14400)));
if ($listenPort < 1 || $token === '' || $upHost === '' || $upPath === '' || $authCookie === '' || $readyFile === '') pv2b_fail('Configuration Remote incomplète.', $configFile, $readyFile);

$errno = 0; $errstr = '';
$server = @stream_socket_server('tcp://0.0.0.0:' . $listenPort, $errno, $errstr, STREAM_SERVER_BIND | STREAM_SERVER_LISTEN);
if (!$server) pv2b_fail('Écoute Remote impossible : ' . $errstr, $configFile, $readyFile);
stream_set_blocking($server, false);

/* Signal de disponibilité sans ouvrir de connexion TCP au listener. */
if (@file_put_contents($readyFile, (string)getmypid(), LOCK_EX) === false) {
    @fclose($server);
    pv2b_fail('Impossible de signaler la disponibilité du tunnel Remote.', $configFile, $readyFile);
}
@chmod($readyFile, 0600);

$client = null;
$deadline = microtime(true) + 20.0;
while (microtime(true) < $deadline) {
    $client = @stream_socket_accept($server, 0);
    if (is_resource($client)) break;
    usleep(50000);
}
@fclose($server);
@unlink($readyFile);
@unlink($configFile); // Le ticket ne reste jamais sur disque pendant la session.
if (!is_resource($client)) pv2b_fail('Aucun client Remote.', '', $readyFile);

$request = pv2b_read_headers($client, 32768, 5);
if ($request === '' || stripos($request, 'upgrade: websocket') === false) { @fclose($client); pv2b_fail('Handshake WebSocket client invalide.', ''); }
$first = strtok($request, "\r\n");
if (!preg_match('~^GET\s+([^\s]+)\s+HTTP/~', (string)$first, $m)) { @fclose($client); pv2b_fail('Requête WebSocket invalide.', ''); }
$path = parse_url($m[1], PHP_URL_PATH);
if (!is_string($path) || trim($path, '/') !== $token) { @fclose($client); pv2b_fail('Jeton Remote invalide.', ''); }
$clientKey = pv2b_header($request, 'Sec-WebSocket-Key');
if ($clientKey === '') { @fclose($client); pv2b_fail('Clé WebSocket absente.', ''); }
$clientProtocol = pv2b_header($request, 'Sec-WebSocket-Protocol');

$ssl = stream_context_create(array('ssl' => array(
    'verify_peer' => false,
    'verify_peer_name' => false,
    'allow_self_signed' => true,
    'SNI_enabled' => true,
    'peer_name' => $upHost
)));
$upstream = @stream_socket_client('tls://' . $upHost . ':' . $upPort, $errno, $errstr, 8, STREAM_CLIENT_CONNECT, $ssl);
if (!$upstream) {
    @fwrite($client, "HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n");
    @fclose($client);
    pv2b_fail('Connexion Proxmox impossible : ' . $errstr, '');
}

$upKey = base64_encode(random_bytes(16));
$hostHeader = $upHost . ':' . $upPort;
$upReq = "GET " . $upPath . " HTTP/1.1\r\n";
$upReq .= "Host: " . $hostHeader . "\r\n";
$upReq .= "Upgrade: websocket\r\nConnection: Upgrade\r\n";
$upReq .= "Sec-WebSocket-Key: " . $upKey . "\r\nSec-WebSocket-Version: 13\r\n";
$upReq .= "Sec-WebSocket-Protocol: binary\r\n";
$upReq .= "Cookie: PVEAuthCookie=" . $authCookie . "\r\n";
$upReq .= "Origin: https://" . $hostHeader . "\r\n\r\n";
@fwrite($upstream, $upReq);
$upResp = pv2b_read_headers($upstream, 32768, 8);
if (!preg_match('~^HTTP/1\.[01]\s+101\b~i', $upResp)) {
    @fwrite($client, "HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\n\r\n");
    @fclose($client); @fclose($upstream);
    pv2b_fail('Proxmox a refusé le WebSocket Remote.', '');
}

$response = "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n";
$response .= "Sec-WebSocket-Accept: " . pv2b_ws_accept($clientKey) . "\r\n";
if ($clientProtocol !== '' && stripos($clientProtocol, 'binary') !== false) $response .= "Sec-WebSocket-Protocol: binary\r\n";
$response .= "\r\n";
@fwrite($client, $response);

stream_set_blocking($client, false);
stream_set_blocking($upstream, false);
$endAt = time() + $maxRuntime;
$clientWsBuffer = '';
$rfbFilterState = array('phase' => 0);
$relayOk = true;

while ($relayOk && time() < $endAt && !feof($client) && !feof($upstream)) {
    $read = array($client, $upstream); $write = null; $except = null;
    $n = @stream_select($read, $write, $except, 1, 0);
    if ($n === false) break;
    if ($n === 0) continue;

    foreach ($read as $src) {
        $buf = @fread($src, 65536);
        if ($buf === false || $buf === '') continue;

        if ($src === $upstream) {
            if (!pv2b_write_all($client, $buf)) {
                $relayOk = false;
                break;
            }
            continue;
        }

        /*
         * Sens navigateur -> Proxmox : on travaille frame par frame afin de
         * bloquer les entrées V2 côté serveur. Les frames autorisées sont
         * relayées dans leur forme WebSocket originale.
         */
        $clientWsBuffer .= $buf;
        if (strlen($clientWsBuffer) > 16777216) {
            $relayOk = false;
            break;
        }

        while (true) {
            $frame = pv2b_ws_take_frame($clientWsBuffer);
            if ($frame === null) break;
            if (!empty($frame['error'])) {
                $relayOk = false;
                break 2;
            }

            $blocked = false;
            if ((int)$frame['opcode'] === 2 && !empty($frame['fin'])) {
                $blocked = pv2b_rfb_input_blocked((string)$frame['payload'], $rfbFilterState);
            }

            if ($blocked) {
                continue;
            }

            if (!pv2b_write_all($upstream, (string)$frame['raw'])) {
                $relayOk = false;
                break 2;
            }
        }
    }
}
@fclose($client);
@fclose($upstream);
exit(0);
