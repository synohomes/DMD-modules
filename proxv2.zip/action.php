<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/proxv2_lib.php';

$raw = (string)file_get_contents('php://input');
$input = json_decode($raw, true);
if (!is_array($input)) $input = $_POST;

if (!proxv2_has_module_access()) {
    proxv2_json(false, 'Module ProxV2 non autorisé pour cet utilisateur.', array(), 403);
}
if (!proxv2_csrf_valid(isset($input['csrf']) ? $input['csrf'] : '')) {
    proxv2_json(false, 'Jeton de sécurité expiré. Recharge la page.', array(), 403);
}

$serverId = trim((string)(isset($input['server_id']) ? $input['server_id'] : (isset($input['node']) ? $input['node'] : '')));
$vmid = (int)(isset($input['vmid']) ? $input['vmid'] : 0);
$type = strtolower(trim((string)(isset($input['type']) ? $input['type'] : '')));
$action = strtolower(trim((string)(isset($input['action']) ? $input['action'] : '')));

$allowed = array('start', 'shutdown', 'stop', 'reboot', 'reset');
if ($serverId === '' || $vmid <= 0 || !in_array($action, $allowed, true)) {
    proxv2_json(false, 'Requête Proxmox incomplète ou action invalide.', array(), 400);
}

$capability = 'vm.' . $action;
if (!proxv2_user_can($capability)) {
    proxv2_json(false, 'Tu n’as pas le droit d’exécuter cette action Proxmox.', array('capability' => $capability), 403);
}

$server = proxv2_load_server($serverId);
if (!is_array($server)) {
    proxv2_json(false, 'Serveur Proxmox introuvable.', array(), 404);
}

/*
 * Important : on ne fait PAS confiance au node envoyé par le navigateur.
 * On retrouve la VM par son VMID dans Proxmox puis on récupère son vrai node/type.
 */
$vm = proxv2_resolve_vm($server, $vmid, $type);
if (!is_array($vm)) {
    proxv2_json(false, 'VM/CT #' . $vmid . ' introuvable sur ce serveur Proxmox.', array(), 404);
}

$realNode = trim((string)(isset($vm['node']) ? $vm['node'] : ''));
$realType = strtolower(trim((string)(isset($vm['type']) ? $vm['type'] : 'qemu')));
if ($realType !== 'qemu' && $realType !== 'lxc') $realType = 'qemu';
if ($realNode === '') {
    proxv2_json(false, 'Impossible de déterminer le node propriétaire de la VM/CT.', array(), 409);
}
if ($action === 'reset' && $realType !== 'qemu') {
    proxv2_json(false, 'Le reset matériel est réservé aux VM QEMU.', array(), 400);
}

$endpoint = 'nodes/' . rawurlencode($realNode) . '/' . $realType . '/' . $vmid . '/status/' . rawurlencode($action);
$res = proxv2_api($server, $endpoint, 'POST', array(), 15);
$name = trim((string)(isset($vm['name']) ? $vm['name'] : ''));
$target = strtoupper($realType) . ' #' . $vmid . ($name !== '' ? ' ' . $name : '');
$extra = array(
    'server_id' => isset($server['id']) ? $server['id'] : proxv2_slug(isset($server['name']) ? $server['name'] : ''),
    'server_name' => isset($server['name']) ? $server['name'] : '',
    'server_ip' => isset($server['ip']) ? $server['ip'] : '',
    'node' => $realNode,
    'vmid' => $vmid,
    'type' => $realType,
    'action' => $action,
    'http_code' => isset($res['http']) ? $res['http'] : 0
);

if (!$res['ok']) {
    $extra['error'] = $res['error'];
    proxv2_log('vm_' . $action, $target, 'error', 'Action Proxmox refusée ou en erreur', $extra);
    proxv2_json(false, $res['error'], array('vmid' => $vmid, 'node' => $realNode, 'type' => $realType), $res['http'] >= 400 ? $res['http'] : 502);
}

$extra['upid'] = $res['data'];
$cacheFile = proxv2_cache_file($server);
if (is_file($cacheFile)) @unlink($cacheFile);
proxv2_log('vm_' . $action, $target, 'success', 'Action Proxmox exécutée', $extra);
proxv2_json(true, 'Action envoyée à Proxmox.', array(
    'action' => $action,
    'vmid' => $vmid,
    'node' => $realNode,
    'type' => $realType,
    'upid' => $res['data']
), 200);
