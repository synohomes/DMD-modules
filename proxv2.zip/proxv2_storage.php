<?php
/*
 * ProxV2 - stockage persistant DoMyDesk 1.2.0
 *
 * Code du module :
 *   /modules/proxv2/
 *
 * Données système persistantes :
 *   /data/modules/proxv2/
 *
 * La première exécution migre automatiquement les anciens dossiers
 * /modules/proxv2/cfg et /modules/proxv2/cache sans écraser un fichier
 * déjà présent dans la nouvelle destination.
 */

if (!function_exists('proxv2_storage_copy_tree')) {
    function proxv2_storage_copy_tree($source, $target) {
        if (!is_dir($source)) {
            return true;
        }

        if (!is_dir($target) && !@mkdir($target, 0775, true) && !is_dir($target)) {
            return false;
        }

        $ok = true;

        foreach (array_diff(scandir($source), array('.', '..')) as $item) {
            $src = rtrim($source, '/\\') . DIRECTORY_SEPARATOR . $item;
            $dst = rtrim($target, '/\\') . DIRECTORY_SEPARATOR . $item;

            if (is_dir($src)) {
                if (!proxv2_storage_copy_tree($src, $dst)) {
                    $ok = false;
                }

                if (is_dir($src) && count(array_diff(scandir($src), array('.', '..'))) === 0) {
                    @rmdir($src);
                }

                continue;
            }

            if (is_file($dst)) {
                $same = @filesize($src) === @filesize($dst)
                    && @sha1_file($src) === @sha1_file($dst);

                if ($same) {
                    @unlink($src);
                } else {
                    $ok = false;
                }

                continue;
            }

            if (!@rename($src, $dst)) {
                if (@copy($src, $dst)) {
                    @chmod($dst, basename($dst) === '.proxv2.key' ? 0640 : 0640);
                    @unlink($src);
                } else {
                    $ok = false;
                }
            }
        }

        if (is_dir($source) && count(array_diff(scandir($source), array('.', '..'))) === 0) {
            @rmdir($source);
        }

        return $ok;
    }
}

if (!function_exists('proxv2_storage_move_tree')) {
    function proxv2_storage_move_tree($source, $target) {
        if (!is_dir($source)) {
            return true;
        }

        if (!file_exists($target)) {
            @mkdir(dirname($target), 0775, true);

            if (@rename($source, $target)) {
                return true;
            }
        }

        return proxv2_storage_copy_tree($source, $target);
    }
}

if (!function_exists('proxv2_storage_paths')) {
    function proxv2_storage_paths() {
        static $paths = null;

        if (is_array($paths)) {
            return $paths;
        }

        if (!function_exists('dmd_module_system_data_dir')) {
            $root = dirname(__DIR__, 2) . '/data/modules/proxv2/';
        } else {
            $root = dmd_module_system_data_dir('proxv2', true);
        }

        if ($root === '') {
            $root = dirname(__DIR__, 2) . '/data/modules/proxv2/';
        }

        $root = rtrim($root, '/\\') . DIRECTORY_SEPARATOR;
        @mkdir($root, 0775, true);

        /*
         * Migration 1.1.x -> 1.2.0.
         * cfg est déplacé en bloc pour conserver ensemble la clé de chiffrement
         * et les JSON des serveurs Proxmox.
         */
        proxv2_storage_move_tree(__DIR__ . '/cfg', $root . 'cfg');
        proxv2_storage_move_tree(__DIR__ . '/cache', $root . 'cache');
        proxv2_storage_move_tree(__DIR__ . '/logs', $root . 'logs');

        $cfg = $root . 'cfg';
        $servers = $cfg . DIRECTORY_SEPARATOR . 'serveurs';
        $cache = $root . 'cache';
        $logs = $root . 'logs';
        $remote = $root . 'remote';

        foreach (array($cfg, $servers, $cache, $logs, $remote) as $dir) {
            if (!is_dir($dir)) {
                @mkdir($dir, 0750, true);
            }
            @chmod($dir, 0750);
            $ht = rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . '.htaccess';
            if (!is_file($ht)) {
                @file_put_contents($ht, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n");
                @chmod($ht, 0640);
            }
        }
        @chmod($root, 0750);
        if (is_file($cfg . DIRECTORY_SEPARATOR . '.proxv2.key')) @chmod($cfg . DIRECTORY_SEPARATOR . '.proxv2.key', 0640);
        foreach ((array)glob($servers . DIRECTORY_SEPARATOR . '*.json') as $serverFile) @chmod($serverFile, 0640);
        foreach ((array)glob($cache . DIRECTORY_SEPARATOR . '*.json') as $cacheFile) @chmod($cacheFile, 0640);
        foreach ((array)glob($logs . DIRECTORY_SEPARATOR . '*.json') as $logFile) @chmod($logFile, 0640);

        $paths = array(
            'root' => $root,
            'cfg' => $cfg,
            'servers' => $servers,
            'cache' => $cache,
            'logs' => $logs,
            'remote' => $remote,
            'key' => $cfg . DIRECTORY_SEPARATOR . '.proxv2.key',
        );

        return $paths;
    }
}
