<?php
/**
 * DoMyDesk 1.2.0 - Inventaire
 * Stockage JSON uniquement. Données persistantes hors /modules.
 */
if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

define('INV_MODULE_ID', 'DMD-Inventaire');
define('INV_MODULE_DIR', __DIR__);
define('INV_DMD_ROOT', realpath(__DIR__ . '/../..') ?: dirname(__DIR__, 2));

function inv_module_web_base(): string {
    $moduleDir = str_replace('\\', '/', realpath(INV_MODULE_DIR) ?: INV_MODULE_DIR);
    $docRoot = rtrim(str_replace('\\', '/', (string)($_SERVER['DOCUMENT_ROOT'] ?? '')), '/');
    if ($docRoot !== '' && ($moduleDir === $docRoot || strpos($moduleDir . '/', $docRoot . '/') === 0)) {
        $relative = ltrim(substr($moduleDir, strlen($docRoot)), '/');
        if ($relative !== '') return '/' . $relative . '/';
    }

    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $marker = '/modules/' . INV_MODULE_ID . '/';
    $pos = strpos($script, $marker);
    if ($pos !== false) return substr($script, 0, $pos) . $marker;

    $base = rtrim(str_replace('\\', '/', dirname($script)), '/');
    if (substr($base, -4) === '/adm') $base = rtrim(str_replace('\\', '/', dirname($base)), '/');
    if ($base === '.' || $base === '/') $base = '';
    return $base . '/modules/' . INV_MODULE_ID . '/';
}

function inv_dashboard_web_url(): string {
    $moduleBase = rtrim(inv_module_web_base(), '/');
    $suffix = '/modules/' . INV_MODULE_ID;
    if (substr($moduleBase, -strlen($suffix)) === $suffix) {
        $root = substr($moduleBase, 0, -strlen($suffix));
        return ($root !== '' ? $root : '') . '/dashboard.php';
    }
    return '/dashboard.php';
}

$invPermissionsFile = INV_DMD_ROOT . '/core/dmd_permissions.php';
$invServicesFile = INV_DMD_ROOT . '/core/dmd_system_services.php';
$invQuickSessionFile = INV_DMD_ROOT . '/core/dmd_quick_session.php';
if (is_file($invPermissionsFile)) require_once $invPermissionsFile;
if (is_file($invServicesFile)) require_once $invServicesFile;
if (is_file($invQuickSessionFile)) require_once $invQuickSessionFile;

function inv_current_email(): string {
    return trim((string)($_SESSION['user']['email'] ?? $_SESSION['email'] ?? $_SESSION['user_email'] ?? ''));
}

function inv_current_role(): string {
    return strtolower(trim((string)($_SESSION['user']['role_system'] ?? $_SESSION['role_system'] ?? $_SESSION['user']['role'] ?? $_SESSION['role'] ?? $_SESSION['user_role'] ?? 'user')));
}

function inv_is_admin(): bool {
    return in_array(inv_current_role(), ['admin', 'administrator', 'superadmin'], true);
}

function inv_require_login(): void {
    if (inv_current_email() === '') {
        http_response_code(403);
        exit('Connexion requise.');
    }
}

function inv_has_permission(string $permission = 'use', ?string $email = null): bool {
    $email = $email !== null ? trim($email) : inv_current_email();
    if ($email === '') return false;
    if (function_exists('dmd_user_has_module_permission')) {
        return dmd_user_has_module_permission($email, INV_MODULE_ID, $permission);
    }
    // Compatibilité de secours avec un ancien Core : seuls les administrateurs ont les droits fins.
    return inv_is_admin();
}

function inv_require_permission(string $permission): void {
    inv_require_login();
    if (!inv_has_permission($permission)) {
        inv_log('permission_denied', [
            'message' => 'Permission Inventaire refusée.',
            'permission' => $permission,
            'request_action' => (string)($_GET['action'] ?? $_POST['action'] ?? ''),
        ], 'denied', $permission);
        inv_json_response(['ok' => false, 'error' => 'Droit requis : ' . $permission . '.'], 403);
    }
}

function inv_permissions_snapshot(): array {
    $ids = [
        'item.list','item.view','item.create','item.edit','item.archive','item.restore','item.delete','item.attach','stock.adjust','item.history.view',
        'template.view','template.create','template.edit','template.delete',
        'export.pdf','export.csv','export.json',
        'log.view','log.export','log.delete',
        'action_hub.use','notifications.receive',
        'config.view','config.edit'
    ];
    $out = ['use' => inv_has_permission('use')];
    foreach ($ids as $id) $out[$id] = inv_has_permission($id);
    return $out;
}

function inv_data_root(): string {
    if (function_exists('dmd_module_system_data_dir')) {
        $dir = (string)dmd_module_system_data_dir(INV_MODULE_ID, true);
        if ($dir !== '') return rtrim($dir, '/\\');
    }
    return INV_DMD_ROOT . '/data/modules/' . INV_MODULE_ID;
}

function inv_dir(string $name = ''): string {
    $base = inv_data_root();
    return $name === '' ? $base : $base . '/' . trim($name, '/\\');
}

function inv_ensure_dir(string $dir): bool {
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) return false;
    $deny = rtrim($dir, '/\\') . '/.htaccess';
    if (!is_file($deny)) @file_put_contents($deny, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n", LOCK_EX);
    return true;
}

function inv_copy_missing_tree(string $from, string $to): void {
    if (!is_dir($from)) return;
    inv_ensure_dir($to);
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($from, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($it as $node) {
        $rel = ltrim(str_replace('\\', '/', substr($node->getPathname(), strlen($from))), '/');
        if ($rel === '' || basename($rel) === '.htaccess') continue;
        $dest = $to . '/' . $rel;
        if ($node->isDir()) {
            if (!is_dir($dest)) @mkdir($dest, 0775, true);
        } elseif ($node->isFile() && !is_file($dest)) {
            if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0775, true);
            @copy($node->getPathname(), $dest);
        }
    }
}

function inv_migrate_legacy_data(): void {
    $root = inv_data_root();
    $marker = $root . '/.migrated-dmd-inventaire-1.2.0';
    if (is_file($marker)) return;

    /*
     * Compatibilité des versions précédentes :
     * - première refonte 1.2.0 : /data/modules/inventaire ;
     * - ancien module : /modules/inventaire/data ;
     * - éventuel ancien data/ présent dans le dossier courant.
     *
     * inv_copy_missing_tree() n'écrase jamais une donnée déjà présente dans
     * /data/modules/DMD-Inventaire.
     */
    $legacyRoots = [
        INV_DMD_ROOT . '/data/modules/inventaire',
        INV_DMD_ROOT . '/modules/inventaire/data',
        INV_MODULE_DIR . '/data',
    ];

    $targetReal = realpath($root) ?: $root;
    foreach ($legacyRoots as $legacy) {
        if (!is_dir($legacy)) continue;
        $legacyReal = realpath($legacy) ?: $legacy;
        if ($legacyReal === $targetReal) continue;
        inv_copy_missing_tree($legacy, $root);
    }

    @file_put_contents($marker, date('c') . "\n", LOCK_EX);
}

function inv_bootstrap(): void {
    inv_require_login();
    foreach (['', 'templates', 'items', 'exports', 'logs', 'attachments', 'alerts'] as $name) inv_ensure_dir(inv_dir($name));
    inv_migrate_legacy_data();
    if (empty($_SESSION['inventaire_csrf'])) $_SESSION['inventaire_csrf'] = bin2hex(random_bytes(24));
    inv_seed_default_template();
    inv_seed_config();
}

function inv_csrf(): string {
    if (empty($_SESSION['inventaire_csrf'])) $_SESSION['inventaire_csrf'] = bin2hex(random_bytes(24));
    return (string)$_SESSION['inventaire_csrf'];
}

function inv_check_csrf(): void {
    $token = (string)($_POST['csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if ($token === '' || !hash_equals(inv_csrf(), $token)) {
        inv_log('csrf_denied', [
            'message' => 'Token CSRF invalide.',
            'request_action' => (string)($_GET['action'] ?? $_POST['action'] ?? ''),
        ], 'denied', 'csrf');
        inv_json_response(['ok'=>false,'error'=>'Token CSRF invalide.'], 403);
    }
}

function inv_slug(string $s): string {
    $s = trim($s);
    $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
    if (is_string($ascii) && $ascii !== '') $s = $ascii;
    $s = strtolower($s);
    $s = preg_replace('/[^a-z0-9]+/', '-', $s) ?: '';
    return trim($s !== '' ? $s : 'item', '-');
}

function inv_clean_id(string $id): string {
    return (string)(preg_replace('/[^a-zA-Z0-9_\-]/', '', $id) ?? '');
}

function inv_read_json(string $file, $default = []) {
    if (!is_file($file)) return $default;
    $raw = @file_get_contents($file);
    if (!is_string($raw) || trim($raw) === '') return $default;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $default;
}

function inv_write_json(string $file, array $data): bool {
    if (!inv_ensure_dir(dirname($file))) return false;
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    $tmp = $file . '.tmp-' . bin2hex(random_bytes(3));
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    $ok = @rename($tmp, $file);
    if (!$ok) @unlink($tmp);
    return $ok;
}

function inv_json_response(array $payload, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function inv_config_file(): string { return inv_dir() . '/config.json'; }

function inv_default_config(): array {
    return [
        'notifications' => [
            'enabled' => true,
            'items' => true,
            'templates' => true,
            'attachments' => true,
            'alerts' => true,
            'config' => true,
            'logs' => true,
        ],
        'expiry_alert_days' => 30,
        'max_upload_mb' => 10,
    ];
}

function inv_seed_config(): void {
    $file = inv_config_file();
    if (!is_file($file)) inv_write_json($file, inv_default_config());
}

function inv_config(): array {
    $cfg = array_replace_recursive(inv_default_config(), inv_read_json(inv_config_file(), []));
    $cfg['expiry_alert_days'] = max(1, min(3650, (int)($cfg['expiry_alert_days'] ?? 30)));
    $cfg['max_upload_mb'] = max(1, min(100, (int)($cfg['max_upload_mb'] ?? 10)));
    return $cfg;
}

function inv_save_config(array $cfg): bool {
    $base = inv_default_config();
    foreach (array_keys($base['notifications']) as $key) {
        $base['notifications'][$key] = !empty($cfg['notifications'][$key]);
    }
    $base['expiry_alert_days'] = max(1, min(3650, (int)($cfg['expiry_alert_days'] ?? 30)));
    $base['max_upload_mb'] = max(1, min(100, (int)($cfg['max_upload_mb'] ?? 10)));
    return inv_write_json(inv_config_file(), $base);
}

function inv_log(string $action, array $details = [], string $result = 'success', string $target = ''): void {
    $entry = [
        'datetime' => date('c'),
        'date' => date('Y-m-d H:i:s'),
        'user' => inv_current_email(),
        'role' => inv_current_role(),
        'module' => INV_MODULE_ID,
        'action' => $action,
        'target' => $target,
        'result' => $result,
        'ip' => (string)($_SERVER['REMOTE_ADDR'] ?? ''),
        'details' => $details,
    ];
    $encoded = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $written = false;
    if ($encoded !== false && inv_ensure_dir(inv_dir('logs'))) {
        $file = inv_dir('logs') . '/' . date('Y-m') . '.jsonl';
        $written = @file_put_contents($file, $encoded . "\n", FILE_APPEND | LOCK_EX) !== false;
    }
    /*
     * Les logs opérationnels restent dans le journal du module.
     * Le journal système Core n'est utilisé qu'en secours si l'écriture du
     * journal Inventaire échoue, conformément à la séparation 1.2.0.
     */
    if (!$written && function_exists('dmd_system_log')) {
        @dmd_system_log(
            'inventaire_module_log_failed',
            $target !== '' ? $target : INV_MODULE_ID,
            'error',
            'Impossible d’écrire le journal du module Inventaire pour l’action ' . $action . '.'
        );
    }
}

function inv_fail(string $message, int $code = 400, string $action = 'request_error', string $target = '', array $details = []): void {
    $details['message'] = $message;
    $details['http_code'] = $code;
    if (!isset($details['request_action'])) $details['request_action'] = (string)($_GET['action'] ?? $_POST['action'] ?? '');
    inv_log($action, $details, $code === 403 ? 'denied' : 'error', $target);
    inv_json_response(['ok'=>false,'error'=>$message], $code);
}

function inv_resource_descriptor(array $item): array {
    $id = inv_clean_id((string)($item['id'] ?? ''));
    return [
        'type' => 'inventory_item',
        'id' => $id === '' ? '' : 'DMD-Inventaire:' . $id,
        'name' => (string)($item['title'] ?? $id),
    ];
}

function inv_activity_resource(array $item, string $action, array $details = [], string $result = 'success'): void {
    /*
     * DoMyDesk 1.2.0 : l'index d'activité est alimenté par l'action elle-même.
     * Il ne dépend PAS du droit d'ouvrir Quick-Session. Le Core décidera ensuite,
     * selon la session active et la ressource, ce qui rejoint sa timeline.
     */
    $resource = inv_resource_descriptor($item);
    if ($resource['id'] === '') return;
    $safeResource = preg_replace('/[^a-zA-Z0-9_.\-]/', '_', $resource['id']) ?: inv_clean_id((string)($item['id'] ?? ''));
    $dir = INV_DMD_ROOT . '/data/secure/activity/resources/' . $resource['type'] . '/' . $safeResource;
    if (!is_dir($dir) && !@mkdir($dir, 0770, true)) {
        inv_log('activity_index_failed', ['message'=>'Impossible de créer l’index d’activité de la ressource.','resource'=>$resource,'source_action'=>$action], 'error', $resource['id']);
        return;
    }
    $entry = [
        'ts' => time(),
        'datetime' => date('c'),
        'user' => inv_current_email(),
        'module' => INV_MODULE_ID,
        'module_id' => INV_MODULE_ID,
        'action' => $action,
        'result' => $result,
        'target' => $resource['name'],
        'resource_type' => $resource['type'],
        'resource_id' => $resource['id'],
        'resource_name' => $resource['name'],
        'resource' => $resource,
        'details' => $details,
    ];
    $encoded = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $ok = $encoded !== false && @file_put_contents($dir . '/' . date('Y-m-d') . '.jsonl', $encoded . "\n", FILE_APPEND | LOCK_EX) !== false;
    if (!$ok) inv_log('activity_index_failed', ['message'=>'Impossible d’écrire l’index d’activité de la ressource.','resource'=>$resource,'source_action'=>$action], 'error', $resource['id']);
}

function inv_profiles_emails(): array {
    $emails = [];
    $profiles = INV_DMD_ROOT . '/users/profiles';
    foreach (glob($profiles . '/*', GLOB_ONLYDIR) ?: [] as $dir) {
        $email = basename($dir);
        if ($email !== '' && strpos($email, '..') === false) $emails[] = $email;
    }
    return array_values(array_unique($emails));
}

function inv_module_users(): array {
    /* Le Core 1.2.0 maintient déjà l'index modules -> utilisateurs. */
    if (function_exists('dmd_notification_index')) {
        $index = dmd_notification_index();
        if (is_array($index) && isset($index['modules'][INV_MODULE_ID]) && is_array($index['modules'][INV_MODULE_ID])) {
            return array_values(array_unique(array_filter(array_map('strval', $index['modules'][INV_MODULE_ID]))));
        }
    }
    /* Secours ancien Core uniquement : profils qui ont réellement accès au module. */
    $out = [];
    foreach (inv_profiles_emails() as $email) if (inv_has_permission('use', $email)) $out[] = $email;
    return array_values(array_unique($out));
}

function inv_filter_notification_recipients(array $emails, bool $includeActor = false): array {
    $actor = inv_current_email();
    $out = [];
    foreach ($emails as $email) {
        $email = trim((string)$email);
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) continue;
        if (!$includeActor && strcasecmp($email, $actor) === 0) continue;
        if (!inv_has_permission('use', $email) || !inv_has_permission('notifications.receive', $email)) continue;
        $out[strtolower($email)] = $email;
    }
    return array_values($out);
}

function inv_notification_recipients(bool $includeActor = false): array {
    return inv_filter_notification_recipients(inv_module_users(), $includeActor);
}

function inv_item_affected_emails(array $item): array {
    $emails = [];
    foreach (['created_by','owner_email','assigned_to','responsible_email'] as $key) {
        if (!empty($item[$key])) $emails[] = (string)$item[$key];
    }
    foreach (['watchers','shared_with','notify_users'] as $key) {
        if (empty($item[$key])) continue;
        $values = is_array($item[$key]) ? $item[$key] : preg_split('/[;,\s]+/', (string)$item[$key]);
        foreach ((array)$values as $value) if (is_string($value) && trim($value) !== '') $emails[] = trim($value);
    }
    return array_values(array_unique($emails));
}

function inv_notify_to(array $recipients, string $group, string $type, string $title, string $message, array $meta = [], bool $includeActor = false, string $level = 'info'): void {
    if (!function_exists('dmd_notify_user')) return;
    $cfg = inv_config();
    if (empty($cfg['notifications']['enabled']) || empty($cfg['notifications'][$group])) return;
    foreach (inv_filter_notification_recipients($recipients, $includeActor) as $email) {
        @dmd_notify_user($email, $type, $title, $message, [
            'level' => $level,
            'action_url' => inv_dashboard_web_url(),
            'action_label' => 'Ouvrir DoMyDesk',
            'meta' => array_merge(['module'=>INV_MODULE_ID,'scope'=>'inventory'], $meta),
        ]);
    }
}

function inv_notify(string $group, string $type, string $title, string $message, array $meta = [], bool $includeActor = false, string $level = 'info'): void {
    inv_notify_to(inv_module_users(), $group, $type, $title, $message, $meta, $includeActor, $level);
}

function inv_notify_item(array $item, string $group, string $type, string $title, string $message, array $meta = [], string $level = 'info'): void {
    inv_notify_to(inv_item_affected_emails($item), $group, $type, $title, $message, $meta, false, $level);
}

function inv_template_file(string $id): string { return inv_dir('templates') . '/' . inv_clean_id($id) . '.json'; }
function inv_item_file(string $id): string { return inv_dir('items') . '/' . inv_clean_id($id) . '.json'; }

function inv_load_templates(): array {
    $out = [];
    foreach (glob(inv_dir('templates') . '/*.json') ?: [] as $file) {
        $tpl = inv_read_json($file, []);
        if (!empty($tpl['id'])) $out[] = $tpl;
    }
    usort($out, static function ($a, $b) { return strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? '')); });
    return $out;
}

function inv_load_template(string $id): ?array {
    $tpl = inv_read_json(inv_template_file($id), []);
    return !empty($tpl['id']) ? $tpl : null;
}

function inv_load_items(): array {
    $out = [];
    foreach (glob(inv_dir('items') . '/*.json') ?: [] as $file) {
        $item = inv_read_json($file, []);
        if (!empty($item['id'])) $out[] = inv_apply_computed_status($item);
    }
    usort($out, static function ($a, $b) { return strcmp((string)($b['updated_at'] ?? ''), (string)($a['updated_at'] ?? '')); });
    return $out;
}

function inv_load_item(string $id): ?array {
    $item = inv_read_json(inv_item_file($id), []);
    return !empty($item['id']) ? inv_apply_computed_status($item) : null;
}

function inv_apply_computed_status(array $item): array {
    $qty = array_key_exists('quantity', $item) && $item['quantity'] !== '' ? (float)$item['quantity'] : null;
    $min = array_key_exists('min_quantity', $item) && $item['min_quantity'] !== '' ? (float)$item['min_quantity'] : null;
    $expires = trim((string)($item['expires_at'] ?? ''));
    $alertDays = max(1, (int)($item['expiry_alert_days'] ?? inv_config()['expiry_alert_days']));
    $expiryStatus = 'none';
    $daysLeft = null;
    if ($expires !== '') {
        try {
            $today = new DateTimeImmutable('today');
            $exp = new DateTimeImmutable($expires);
            $daysLeft = (int)$today->diff($exp)->format('%r%a');
            $expiryStatus = $daysLeft < 0 ? 'expired' : ($daysLeft <= $alertDays ? 'soon' : 'ok');
        } catch (Throwable $e) { $expiryStatus = 'none'; }
    }
    $stockStatus = ($qty !== null && $min !== null && $min > 0 && $qty <= $min) ? 'low' : 'ok';
    $global = $expiryStatus === 'expired' ? 'expired' : ($expiryStatus === 'soon' ? 'soon' : ($stockStatus === 'low' ? 'low' : 'ok'));
    $item['_computed'] = ['expiry_status'=>$expiryStatus,'stock_status'=>$stockStatus,'global_status'=>$global,'days_left'=>$daysLeft];
    return $item;
}

function inv_alert_state_file(string $itemId): string {
    return inv_dir('alerts') . '/' . inv_clean_id($itemId) . '.json';
}

function inv_alert_state(array $item): array {
    $item = inv_apply_computed_status($item);
    return [
        'stock_status' => (string)($item['_computed']['stock_status'] ?? 'ok'),
        'expiry_status' => (string)($item['_computed']['expiry_status'] ?? 'none'),
        'updated_at' => date('c'),
    ];
}

function inv_emit_alert_transitions(array $beforeState, array $after): void {
    $after = inv_apply_computed_status($after);
    $id = (string)($after['id'] ?? '');
    if ($id === '') return;
    $title = (string)($after['title'] ?? $id);
    $resource = inv_resource_descriptor($after);
    $newState = inv_alert_state($after);
    $oldStock = (string)($beforeState['stock_status'] ?? 'ok');
    $newStock = (string)$newState['stock_status'];
    if ($newStock === 'low' && $oldStock !== 'low') {
        inv_notify('alerts','inventory_low_stock','Stock bas : ' . $title,'Le seuil de stock bas vient d’être atteint.', ['resource_type'=>$resource['type'],'resource_id'=>$resource['id'],'item_id'=>$id], true, 'warning');
        inv_log('alert_low_stock', ['message'=>'Alerte stock bas émise.','id'=>$id,'title'=>$title], 'success', $id);
    }
    $oldExpiry = (string)($beforeState['expiry_status'] ?? 'none');
    $newExpiry = (string)$newState['expiry_status'];
    if ($newExpiry === 'soon' && $oldExpiry !== 'soon') {
        inv_notify('alerts','inventory_expiry','Péremption proche : ' . $title,'Cette fiche arrive dans sa période d’alerte de péremption.', ['resource_type'=>$resource['type'],'resource_id'=>$resource['id'],'item_id'=>$id], true, 'warning');
        inv_log('alert_expiry_soon', ['message'=>'Alerte péremption proche émise.','id'=>$id,'title'=>$title], 'success', $id);
    }
    if ($newExpiry === 'expired' && $oldExpiry !== 'expired') {
        inv_notify('alerts','inventory_expired','Périmé : ' . $title,'La date de péremption de cette fiche est dépassée.', ['resource_type'=>$resource['type'],'resource_id'=>$resource['id'],'item_id'=>$id], true, 'warning');
        inv_log('alert_expired', ['message'=>'Alerte péremption dépassée émise.','id'=>$id,'title'=>$title], 'success', $id);
    }
    if (!inv_write_json(inv_alert_state_file($id), $newState)) {
        inv_log('alert_state_write_failed', ['message'=>'Impossible de mémoriser l’état des alertes.','id'=>$id], 'error', $id);
    }
}

function inv_status_transition_notifications(?array $before, array $after): void {
    $id = (string)($after['id'] ?? '');
    if ($id === '') return;
    if ($before) {
        $beforeState = inv_alert_state($before);
    } else {
        $beforeState = inv_read_json(inv_alert_state_file($id), ['stock_status'=>'ok','expiry_status'=>'none']);
    }
    inv_emit_alert_transitions($beforeState, $after);
}

function inv_process_passive_alerts(array $items): void {
    /* Appelé uniquement pendant un chargement demandé par l'utilisateur : aucun polling. */
    foreach ($items as $item) {
        $id = inv_clean_id((string)($item['id'] ?? ''));
        if ($id === '') continue;
        $beforeState = inv_read_json(inv_alert_state_file($id), ['stock_status'=>'ok','expiry_status'=>'none']);
        $currentState = inv_alert_state($item);
        if ((string)($beforeState['stock_status'] ?? '') !== (string)$currentState['stock_status']
            || (string)($beforeState['expiry_status'] ?? '') !== (string)$currentState['expiry_status']) {
            inv_emit_alert_transitions($beforeState, $item);
        }
    }
}

function inv_field_types(): array {
    return [
        'text'=>'Texte court','textarea'=>'Texte long','wide_text'=>'Texte large','number'=>'Nombre','quantity'=>'Quantité','select'=>'Liste déroulante',
        'checkbox'=>'Cases à cocher','boolean'=>'Oui / Non','date'=>'Date simple','calendar_multi'=>'Calendrier multiple','purchase_date'=>'Date d’achat',
        'expiry_date'=>'Date de péremption','warranty_date'=>'Fin garantie','price'=>'Prix','unit'=>'Unité','location'=>'Emplacement','state'=>'État',
        'barcode'=>'Code-barres / QR','photo'=>'Photo','file'=>'Pièce jointe','url'=>'Lien externe'
    ];
}

function inv_seed_default_template(): void {
    $file = inv_template_file('stock-general');
    if (is_file($file)) return;
    $now = date('Y-m-d H:i:s');
    inv_write_json($file, [
        'id'=>'stock-general','name'=>'Stock général','description'=>'Modèle polyvalent pour maison, entreprise, atelier ou stock courant.',
        'expiry_alert_days'=>30,'created_at'=>$now,'updated_at'=>$now,
        'fields'=>[
            ['id'=>'category','label'=>'Catégorie','type'=>'select','required'=>false,'list'=>true,'filter'=>true,'width'=>'medium','options'=>['Maison','Bureau','Atelier','Informatique','Produit','Document']],
            ['id'=>'quantity','label'=>'Quantité','type'=>'quantity','required'=>true,'list'=>true,'filter'=>false,'width'=>'small','default'=>'1'],
            ['id'=>'unit','label'=>'Unité','type'=>'unit','required'=>false,'list'=>true,'filter'=>true,'width'=>'small','options'=>['pièce','kg','g','L','mL','boîte','lot']],
            ['id'=>'location','label'=>'Emplacement','type'=>'location','required'=>false,'list'=>true,'filter'=>true,'width'=>'medium'],
            ['id'=>'expires_at','label'=>'Date de péremption','type'=>'expiry_date','required'=>false,'list'=>true,'filter'=>true,'width'=>'small'],
            ['id'=>'min_quantity','label'=>'Seuil stock bas','type'=>'number','required'=>false,'list'=>false,'filter'=>false,'width'=>'small'],
            ['id'=>'state','label'=>'État','type'=>'state','required'=>false,'list'=>true,'filter'=>true,'width'=>'medium','options'=>['Neuf','Bon','À contrôler','Abîmé','Archivé']],
            ['id'=>'comment','label'=>'Commentaire','type'=>'textarea','required'=>false,'list'=>false,'filter'=>false,'width'=>'large'],
        ]
    ]);
}

function inv_allowed_upload(string $name): bool {
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    return in_array($ext, ['jpg','jpeg','png','webp','gif','pdf','txt','csv','json','doc','docx','xls','xlsx'], true);
}

function inv_handle_uploads(string $itemId): array {
    $saved = [];
    if (empty($_FILES['attachments']) || empty($_FILES['attachments']['name']) || !is_array($_FILES['attachments']['name'])) return $saved;
    $base = inv_dir('attachments') . '/' . inv_clean_id($itemId);
    if (!inv_ensure_dir($base)) throw new RuntimeException('Impossible de préparer le dossier des pièces jointes.');
    $names = $_FILES['attachments']['name'];
    $tmp = $_FILES['attachments']['tmp_name'];
    $sizes = $_FILES['attachments']['size'];
    $errors = $_FILES['attachments']['error'] ?? [];
    $max = inv_config()['max_upload_mb'] * 1024 * 1024;
    foreach ($names as $i => $name) {
        $name = basename((string)$name);
        if ($name === '') continue;
        $uploadError = (int)($errors[$i] ?? UPLOAD_ERR_OK);
        if ($uploadError !== UPLOAD_ERR_OK || empty($tmp[$i]) || !is_uploaded_file($tmp[$i])) {
            inv_log('attachment_upload_rejected', ['message'=>'Téléversement de pièce jointe refusé.','file'=>$name,'upload_error'=>$uploadError], 'error', $itemId);
            continue;
        }
        if (!inv_allowed_upload($name)) {
            inv_log('attachment_upload_rejected', ['message'=>'Extension de pièce jointe refusée.','file'=>$name], 'denied', $itemId);
            continue;
        }
        if ((int)($sizes[$i] ?? 0) > $max) {
            inv_log('attachment_upload_rejected', ['message'=>'Pièce jointe trop volumineuse.','file'=>$name,'size'=>(int)($sizes[$i] ?? 0),'max'=>$max], 'denied', $itemId);
            continue;
        }
        $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $name);
        $safe = date('YmdHis') . '-' . bin2hex(random_bytes(3)) . '-' . $safeName;
        $dest = $base . '/' . $safe;
        if (@move_uploaded_file($tmp[$i], $dest)) {
            $saved[] = ['name'=>$name,'stored'=>$safe,'size'=>(int)($sizes[$i] ?? 0),'uploaded_at'=>date('Y-m-d H:i:s'),'uploaded_by'=>inv_current_email()];
        } else {
            inv_log('attachment_upload_failed', ['message'=>'Échec de déplacement de la pièce jointe.','file'=>$name], 'error', $itemId);
        }
    }
    return $saved;
}

function inv_remove_attachment(array &$item, string $stored): bool {
    $stored = basename($stored);
    if ($stored === '') return false;
    $changed = false;
    $kept = [];
    foreach (($item['attachments'] ?? []) as $att) {
        $candidate = basename((string)($att['stored'] ?? $att['file'] ?? ''));
        if ($candidate === $stored) { $changed = true; continue; }
        $kept[] = $att;
    }
    if (!$changed) return false;
    $item['attachments'] = $kept;
    $file = inv_dir('attachments') . '/' . inv_clean_id((string)$item['id']) . '/' . $stored;
    if (is_file($file)) @unlink($file);
    return true;
}

function inv_attachment_path(array $item, string $stored): string {
    $stored = basename($stored);
    if ($stored === '') return '';
    $new = inv_dir('attachments') . '/' . inv_clean_id((string)$item['id']) . '/' . $stored;
    if (is_file($new)) return $new;
    // Compatibilité des métadonnées V2 stockant "data/attachments/...".
    foreach (($item['attachments'] ?? []) as $att) {
        if (basename((string)($att['stored'] ?? $att['file'] ?? '')) !== $stored) continue;
        $legacy = INV_MODULE_DIR . '/' . ltrim((string)($att['file'] ?? ''), '/');
        if (is_file($legacy)) return $legacy;
    }
    return '';
}

function inv_post_value(array $field, ?array $old) {
    $id = inv_clean_id((string)($field['id'] ?? ''));
    $type = (string)($field['type'] ?? 'text');
    $default = $old['fields'][$id] ?? $old[$id] ?? ($field['default'] ?? '');
    if ($type === 'checkbox') {
        $raw = $_POST[$id] ?? [];
        return is_array($raw) ? array_values(array_map('strval', $raw)) : ($raw === '' ? [] : [(string)$raw]);
    }
    if ($type === 'boolean') return !empty($_POST[$id]) ? '1' : '0';
    if ($type === 'calendar_multi') {
        $raw = $_POST[$id] ?? $default;
        if (is_array($raw)) return array_values(array_filter(array_map('strval', $raw)));
        return array_values(array_filter(array_map('trim', preg_split('/[\r\n,;]+/', (string)$raw) ?: [])));
    }
    $value = $_POST[$id] ?? $default;
    if (is_array($value)) return array_values(array_map('strval', $value));
    $value = trim((string)$value);
    if (in_array($type, ['number','quantity','price'], true) && $value !== '') return (float)str_replace(',', '.', $value);
    return $value;
}

function inv_normalize_item_from_post(?array $old = null): array {
    $id = inv_clean_id((string)($old['id'] ?? ($_POST['id'] ?? '')));
    if ($id === '') $id = 'INV-' . date('Ymd-His') . '-' . strtoupper(bin2hex(random_bytes(2)));
    $template = inv_clean_id((string)($_POST['template'] ?? ($old['template'] ?? 'stock-general')));
    $tpl = inv_load_template($template);
    if (!$tpl) throw new RuntimeException('Modèle introuvable.');
    $title = trim((string)($_POST['title'] ?? ($old['title'] ?? '')));
    if ($title === '') $title = 'Sans titre';
    $item = is_array($old) ? $old : [];
    $item['id'] = $id;
    $item['template'] = $template;
    $item['title'] = $title;
    $item['expiry_alert_days'] = (int)($tpl['expiry_alert_days'] ?? inv_config()['expiry_alert_days']);
    $item['fields'] = isset($old['fields']) && is_array($old['fields']) ? $old['fields'] : [];
    foreach (($tpl['fields'] ?? []) as $field) {
        $fid = inv_clean_id((string)($field['id'] ?? ''));
        if ($fid === '') continue;
        $value = inv_post_value($field, $old);
        $item['fields'][$fid] = $value;
        // Miroir compatible avec les champs de synthèse V2 et les vues/listes rapides.
        $item[$fid] = $value;
    }
    $now = date('Y-m-d H:i:s');
    $item['created_at'] = (string)($old['created_at'] ?? $now);
    $item['created_by'] = (string)($old['created_by'] ?? inv_current_email());
    $item['updated_at'] = $now;
    $item['updated_by'] = inv_current_email();
    $item['archived'] = !empty($old['archived']);
    $item['attachments'] = isset($old['attachments']) && is_array($old['attachments']) ? $old['attachments'] : [];
    $uploads = inv_handle_uploads($id);
    if ($uploads) $item['attachments'] = array_values(array_merge($item['attachments'], $uploads));
    $item['history'] = isset($old['history']) && is_array($old['history']) ? $old['history'] : [];
    $item['history'][] = ['date'=>$now,'user'=>inv_current_email(),'action'=>$old ? 'update' : 'create'];
    return inv_apply_computed_status($item);
}

function inv_changed_fields(?array $before, array $after): array {
    if (!$before) return ['created'];
    $changed = [];
    $skip = ['history','_computed','updated_at','updated_by','attachments'];
    $keys = array_values(array_unique(array_merge(array_keys($before), array_keys($after))));
    foreach ($keys as $key) {
        if (in_array($key, $skip, true)) continue;
        if ($key === 'fields') continue;
        $a = $before[$key] ?? null;
        $b = $after[$key] ?? null;
        if (json_encode($a) !== json_encode($b)) $changed[] = (string)$key;
    }
    $beforeFields = isset($before['fields']) && is_array($before['fields']) ? $before['fields'] : [];
    $afterFields = isset($after['fields']) && is_array($after['fields']) ? $after['fields'] : [];
    $fieldKeys = array_values(array_unique(array_merge(array_keys($beforeFields), array_keys($afterFields))));
    foreach ($fieldKeys as $key) {
        if (json_encode($beforeFields[$key] ?? null) !== json_encode($afterFields[$key] ?? null)) $changed[] = 'fields.' . $key;
    }
    return array_values(array_unique($changed));
}

function inv_stock_field_ids(string $templateId): array {
    $ids = ['quantity','min_quantity','unit'];
    $tpl = inv_load_template($templateId);
    foreach (($tpl['fields'] ?? []) as $field) {
        $id = inv_clean_id((string)($field['id'] ?? ''));
        $type = strtolower((string)($field['type'] ?? ''));
        if ($id !== '' && (in_array($type, ['quantity','unit'], true) || in_array($id, ['quantity','min_quantity','unit'], true))) $ids[] = $id;
    }
    return array_values(array_unique($ids));
}

function inv_strip_stock_post(string $templateId): void {
    foreach (inv_stock_field_ids($templateId) as $key) unset($_POST[$key]);
}

function inv_stock_fields_changed(?array $before, array $after): bool {
    if (!$before) return false;
    $templateId = (string)($after['template'] ?? $before['template'] ?? '');
    foreach (inv_stock_field_ids($templateId) as $key) {
        $beforeValue = $before['fields'][$key] ?? $before[$key] ?? '';
        $afterValue = $after['fields'][$key] ?? $after[$key] ?? '';
        if ((string)$beforeValue !== (string)$afterValue) return true;
    }
    return false;
}

function inv_filter_items(array $items, array $query): array {
    $q = mb_strtolower(trim((string)($query['q'] ?? $query['search'] ?? '')));
    $template = inv_clean_id((string)($query['template'] ?? ''));
    $status = strtolower(trim((string)($query['status'] ?? '')));
    $archived = (string)($query['archived'] ?? '0');
    return array_values(array_filter($items, static function(array $item) use ($q,$template,$status,$archived): bool {
        if ($template !== '' && (string)($item['template'] ?? '') !== $template) return false;
        if ($archived !== 'all' && (!empty($item['archived']) !== ($archived === '1'))) return false;
        if ($status !== '' && $status !== 'all' && (string)($item['_computed']['global_status'] ?? 'ok') !== $status) return false;
        if ($q !== '') {
            $hay = mb_strtolower(json_encode($item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '');
            if (mb_strpos($hay, $q) === false) return false;
        }
        return true;
    }));
}

function inv_item_public(array $item): array {
    $out = $item;
    foreach (($out['attachments'] ?? []) as $i => $att) {
        $stored = basename((string)($att['stored'] ?? $att['file'] ?? ''));
        $out['attachments'][$i]['stored'] = $stored;
        unset($out['attachments'][$i]['file']);
    }
    if (!inv_has_permission('item.history.view')) unset($out['history']);
    return $out;
}

function inv_item_summary(array $item): array {
    return [
        'id'=>(string)($item['id'] ?? ''),'title'=>(string)($item['title'] ?? ''),'template'=>(string)($item['template'] ?? ''),
        'category'=>$item['category'] ?? ($item['fields']['category'] ?? ''),'quantity'=>$item['quantity'] ?? ($item['fields']['quantity'] ?? ''),'unit'=>$item['unit'] ?? ($item['fields']['unit'] ?? ''),
        'location'=>$item['location'] ?? ($item['fields']['location'] ?? ''),'expires_at'=>$item['expires_at'] ?? ($item['fields']['expires_at'] ?? ''),'archived'=>!empty($item['archived']),
        'updated_at'=>$item['updated_at'] ?? '','_computed'=>$item['_computed'] ?? [],
    ];
}

function inv_load_logs(): array {
    $rows = [];
    foreach (glob(inv_dir('logs') . '/*.jsonl') ?: [] as $file) {
        $fh = @fopen($file, 'rb');
        if (!$fh) continue;
        while (($line = fgets($fh)) !== false) {
            $row = json_decode(trim($line), true);
            if (is_array($row)) $rows[] = $row;
        }
        fclose($fh);
    }
    usort($rows, static function ($a, $b) { return strcmp((string)($b['datetime'] ?? ''), (string)($a['datetime'] ?? '')); });
    return $rows;
}
?>
