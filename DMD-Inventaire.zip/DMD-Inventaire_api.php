<?php
require_once __DIR__ . '/DMD-Inventaire_lib.php';
inv_bootstrap();

$action = (string)($_GET['action'] ?? $_POST['action'] ?? 'list');
if ($_SERVER['REQUEST_METHOD'] === 'POST') inv_check_csrf();

function inv_api_item_or_404(string $id): array {
    $clean = inv_clean_id($id);
    $item = $clean !== '' ? inv_load_item($clean) : null;
    if (!$item) inv_fail('Élément introuvable.', 404, 'item_not_found', $clean, ['id'=>$clean]);
    return $item;
}

function inv_api_write_item(array $item, string $sourceAction): void {
    $id = inv_clean_id((string)($item['id'] ?? ''));
    if ($id === '' || !inv_write_json(inv_item_file($id), $item)) {
        inv_fail('Impossible d’enregistrer la fiche.', 500, 'item_write_failed', $id, ['source_action'=>$sourceAction]);
    }
}

function inv_api_write_template(array $tpl, string $sourceAction): void {
    $id = inv_clean_id((string)($tpl['id'] ?? ''));
    if ($id === '' || !inv_write_json(inv_template_file($id), $tpl)) {
        inv_fail('Impossible d’enregistrer le modèle.', 500, 'template_write_failed', $id, ['source_action'=>$sourceAction]);
    }
}

switch ($action) {
    case 'meta':
        inv_require_permission('use');
        $templates = inv_has_permission('template.view') ? inv_load_templates() : [];
        inv_process_passive_alerts(inv_load_items());
        inv_json_response([
            'ok'=>true,
            'csrf'=>inv_csrf(),
            'is_admin'=>inv_is_admin(),
            'field_types'=>inv_field_types(),
            'templates'=>$templates,
            'permissions'=>inv_permissions_snapshot(),
            'config'=>inv_has_permission('config.view') ? inv_config() : null,
            'resource_type'=>'inventory_item',
            'module_id'=>INV_MODULE_ID,
        ]);

    case 'list':
        inv_require_permission('item.list');
        $items = array_map('inv_item_summary', inv_filter_items(inv_load_items(), $_GET));
        inv_json_response(['ok'=>true,'items'=>$items,'templates'=>inv_has_permission('template.view') ? inv_load_templates() : []]);

    case 'get':
        inv_require_permission('item.view');
        $item = inv_api_item_or_404((string)($_GET['id'] ?? ''));
        inv_json_response(['ok'=>true,'item'=>inv_item_public($item),'template'=>inv_load_template((string)($item['template'] ?? ''))]);

    case 'save_item':
        $postedId = inv_clean_id((string)($_POST['id'] ?? ''));
        $old = $postedId !== '' ? inv_load_item($postedId) : null;
        inv_require_permission($old ? 'item.edit' : 'item.create');

        $uploadNames = $_FILES['attachments']['name'] ?? [];
        $hasUploads = is_array($uploadNames)
            ? (bool)array_filter($uploadNames, static function ($v) { return trim((string)$v) !== ''; })
            : trim((string)$uploadNames) !== '';
        if ($hasUploads) inv_require_permission('item.attach');

        if (!$old && !inv_has_permission('stock.adjust')) {
            inv_strip_stock_post(inv_clean_id((string)($_POST['template'] ?? 'stock-general')));
        }

        try {
            $item = inv_normalize_item_from_post($old);
        } catch (Throwable $e) {
            inv_fail($e->getMessage(), 400, 'item_validation_failed', $postedId, ['exception'=>get_class($e)]);
        }

        if ($old && inv_stock_fields_changed($old, $item) && !inv_has_permission('stock.adjust')) {
            inv_log('permission_denied', ['message'=>'Modification du stock refusée.','permission'=>'stock.adjust','request_action'=>'save_item'], 'denied', (string)$item['id']);
            inv_json_response(['ok'=>false,'error'=>'Droit requis : stock.adjust.'], 403);
        }

        $changedFields = inv_changed_fields($old, $item);
        inv_api_write_item($item, 'save_item');
        $event = $old ? 'item_update' : 'item_create';
        $verb = $old ? 'modifiée' : 'créée';
        $resource = inv_resource_descriptor($item);
        inv_log($event, ['message'=>'Fiche '.$verb.'.','id'=>$item['id'],'title'=>$item['title'],'changed_fields'=>$changedFields,'resource'=>$resource], 'success', (string)$item['id']);
        inv_activity_resource($item, $event, ['title'=>$item['title']]);

        /* Une modification normale est un log. Notification seulement aux personnes réellement affectées. */
        inv_notify_item(
            $item,
            'items',
            'inventory_item_changed',
            'Inventaire : fiche ' . $verb,
            (string)$item['title'] . ' a été ' . $verb . ' par ' . inv_current_email() . '.',
            ['resource_type'=>$resource['type'],'resource_id'=>$resource['id'],'item_id'=>$item['id'],'action'=>$event]
        );

        $oldAttachmentCount = count($old['attachments'] ?? []);
        $newAttachmentCount = count($item['attachments'] ?? []);
        if ($newAttachmentCount > $oldAttachmentCount) {
            inv_log('attachment_add', ['message'=>'Pièce(s) jointe(s) ajoutée(s).','id'=>$item['id'],'count'=>$newAttachmentCount-$oldAttachmentCount], 'success', (string)$item['id']);
            inv_activity_resource($item, 'attachment_add', ['count'=>$newAttachmentCount-$oldAttachmentCount]);
            inv_notify_item($item,'attachments','inventory_attachment','Inventaire : pièce jointe ajoutée','Une pièce jointe a été ajoutée à ' . (string)$item['title'] . '.', ['resource_type'=>$resource['type'],'resource_id'=>$resource['id'],'item_id'=>$item['id']]);
        }

        inv_status_transition_notifications($old, $item);
        inv_json_response(['ok'=>true,'item'=>inv_item_public($item)]);

    case 'archive_item':
    case 'restore_item':
        $permission = $action === 'archive_item' ? 'item.archive' : 'item.restore';
        inv_require_permission($permission);
        $item = inv_api_item_or_404((string)($_POST['id'] ?? ''));
        $item['archived'] = $action === 'archive_item';
        $item['updated_at'] = date('Y-m-d H:i:s');
        $item['updated_by'] = inv_current_email();
        if (!isset($item['history']) || !is_array($item['history'])) $item['history'] = [];
        $item['history'][] = ['date'=>$item['updated_at'],'user'=>inv_current_email(),'action'=>$item['archived'] ? 'archive' : 'restore'];
        inv_api_write_item($item, $action);
        $event = $item['archived'] ? 'item_archive' : 'item_restore';
        $verb = $item['archived'] ? 'archivée' : 'restaurée';
        $resource = inv_resource_descriptor($item);
        inv_log($event, ['message'=>'Fiche '.$verb.'.','id'=>$item['id'],'title'=>$item['title'],'changed_fields'=>['archived'],'resource'=>$resource], 'success', (string)$item['id']);
        inv_activity_resource($item, $event);
        inv_notify_item($item,'items','inventory_item_changed','Inventaire : fiche ' . $verb,(string)$item['title'] . ' a été ' . $verb . ' par ' . inv_current_email() . '.', ['resource_type'=>$resource['type'],'resource_id'=>$resource['id'],'item_id'=>$item['id'],'action'=>$event]);
        inv_json_response(['ok'=>true,'item'=>inv_item_public($item)]);

    case 'delete_item':
        inv_require_permission('item.delete');
        $item = inv_api_item_or_404((string)($_POST['id'] ?? ''));
        $id = (string)$item['id'];
        $file = inv_item_file($id);
        if (is_file($file) && !@unlink($file)) {
            inv_fail('Impossible de supprimer la fiche.', 500, 'item_delete_failed', $id, ['file'=>basename($file)]);
        }
        $attDir = inv_dir('attachments') . '/' . inv_clean_id($id);
        $attachmentFailures = 0;
        if (is_dir($attDir)) {
            foreach (glob($attDir . '/*') ?: [] as $f) if (is_file($f) && !@unlink($f)) $attachmentFailures++;
            if ($attachmentFailures === 0) @rmdir($attDir);
        }
        $alertStateFile = inv_alert_state_file($id);
        $alertStateFailure = is_file($alertStateFile) && !@unlink($alertStateFile);
        $resource = inv_resource_descriptor($item);
        inv_log('item_delete', ['message'=>'Fiche supprimée.','id'=>$id,'title'=>$item['title'],'attachment_failures'=>$attachmentFailures,'alert_state_failure'=>$alertStateFailure,'resource'=>$resource], ($attachmentFailures || $alertStateFailure) ? 'warning' : 'success', $id);
        inv_activity_resource($item, 'item_delete', ['attachment_failures'=>$attachmentFailures,'alert_state_failure'=>$alertStateFailure], ($attachmentFailures || $alertStateFailure) ? 'warning' : 'success');
        inv_notify_item($item,'items','inventory_item_deleted','Inventaire : fiche supprimée',(string)$item['title'] . ' a été supprimée par ' . inv_current_email() . '.', ['resource_type'=>$resource['type'],'resource_id'=>$resource['id'],'item_id'=>$id,'action'=>'item_delete'], 'warning');
        inv_json_response(['ok'=>true,'attachment_failures'=>$attachmentFailures,'alert_state_failure'=>$alertStateFailure]);

    case 'remove_attachment':
        inv_require_permission('item.attach');
        $item = inv_api_item_or_404((string)($_POST['id'] ?? ''));
        $stored = basename((string)($_POST['stored'] ?? ''));
        if ($stored === '' || !inv_remove_attachment($item, $stored)) {
            inv_fail('Pièce jointe introuvable.', 404, 'attachment_remove_failed', (string)$item['id'], ['stored'=>$stored]);
        }
        $item['updated_at'] = date('Y-m-d H:i:s');
        $item['updated_by'] = inv_current_email();
        if (!isset($item['history']) || !is_array($item['history'])) $item['history'] = [];
        $item['history'][] = ['date'=>$item['updated_at'],'user'=>inv_current_email(),'action'=>'attachment_remove'];
        inv_api_write_item($item, 'remove_attachment');
        $resource = inv_resource_descriptor($item);
        inv_log('attachment_remove', ['message'=>'Pièce jointe supprimée.','id'=>$item['id'],'stored'=>$stored,'resource'=>$resource], 'success', (string)$item['id']);
        inv_activity_resource($item, 'attachment_remove', ['stored'=>$stored]);
        inv_notify_item($item,'attachments','inventory_attachment','Inventaire : pièce jointe supprimée','Une pièce jointe a été supprimée de ' . (string)$item['title'] . '.', ['resource_type'=>$resource['type'],'resource_id'=>$resource['id'],'item_id'=>$item['id']]);
        inv_json_response(['ok'=>true,'item'=>inv_item_public($item)]);

    case 'save_template':
        $raw = (string)($_POST['template_json'] ?? '');
        $tpl = json_decode($raw, true);
        if (!is_array($tpl)) inv_fail('JSON modèle invalide.', 400, 'template_validation_failed', '', ['json_error'=>json_last_error_msg()]);
        $name = trim((string)($tpl['name'] ?? 'Modèle'));
        $id = inv_clean_id((string)($tpl['id'] ?? inv_slug($name)));
        if ($id === '') $id = inv_slug($name);
        $old = inv_load_template($id);
        inv_require_permission($old ? 'template.edit' : 'template.create');
        $tpl['id'] = $id;
        $tpl['name'] = $name !== '' ? $name : 'Modèle';
        $tpl['description'] = trim((string)($tpl['description'] ?? ''));
        $tpl['expiry_alert_days'] = max(1, min(3650, (int)($tpl['expiry_alert_days'] ?? 30)));
        $allowedTypes = array_keys(inv_field_types());
        $fields = [];
        foreach (($tpl['fields'] ?? []) as $field) {
            if (!is_array($field)) continue;
            $fid = inv_clean_id((string)($field['id'] ?? inv_slug((string)($field['label'] ?? ''))));
            $label = trim((string)($field['label'] ?? ''));
            if ($fid === '' || $label === '') continue;
            $type = (string)($field['type'] ?? 'text');
            if (!in_array($type, $allowedTypes, true)) $type = 'text';
            $fields[] = [
                'id'=>$fid,'label'=>$label,'type'=>$type,
                'width'=>in_array(($field['width'] ?? ''),['small','medium','large','full'],true)?$field['width']:'medium',
                'required'=>!empty($field['required']),'list'=>!empty($field['list']),'filter'=>!empty($field['filter']),
                'options'=>array_values(array_filter(array_map('strval',(array)($field['options'] ?? [])))),
                'default'=>(string)($field['default'] ?? '')
            ];
        }
        $tpl['fields'] = $fields;
        $tpl['updated_at'] = date('Y-m-d H:i:s');
        $tpl['updated_by'] = inv_current_email();
        if (empty($tpl['created_at'])) $tpl['created_at'] = $tpl['updated_at'];
        if (empty($tpl['created_by'])) $tpl['created_by'] = inv_current_email();
        inv_api_write_template($tpl, 'save_template');
        $event = $old ? 'template_update' : 'template_create';
        inv_log($event, ['message'=>'Modèle enregistré.','id'=>$id,'name'=>$tpl['name']], 'success', $id);
        inv_notify('templates','inventory_template_changed','Inventaire : modèle enregistré',(string)$tpl['name'] . ' a été enregistré par ' . inv_current_email() . '.', ['template_id'=>$id,'action'=>$event]);
        inv_json_response(['ok'=>true,'template'=>$tpl]);

    case 'delete_template':
        inv_require_permission('template.delete');
        $id = inv_clean_id((string)($_POST['id'] ?? ''));
        if ($id === 'stock-general') inv_fail('Le modèle par défaut ne peut pas être supprimé.', 400, 'template_delete_failed', $id, ['reason'=>'default_template']);
        $tpl = inv_load_template($id);
        if (!$tpl) inv_fail('Modèle introuvable.', 404, 'template_delete_failed', $id, ['reason'=>'not_found']);
        $used = array_filter(inv_load_items(), static function ($it) use ($id) { return (string)($it['template'] ?? '') === $id; });
        if ($used) inv_fail('Modèle utilisé par des fiches.', 400, 'template_delete_failed', $id, ['reason'=>'in_use','items'=>count($used)]);
        $file = inv_template_file($id);
        if (!is_file($file) || !@unlink($file)) inv_fail('Impossible de supprimer le modèle.', 500, 'template_delete_failed', $id, ['reason'=>'filesystem']);
        inv_log('template_delete', ['message'=>'Modèle supprimé.','id'=>$id,'name'=>$tpl['name']], 'success', $id);
        inv_notify('templates','inventory_template_changed','Inventaire : modèle supprimé',(string)$tpl['name'] . ' a été supprimé par ' . inv_current_email() . '.', ['template_id'=>$id,'action'=>'template_delete'], false, 'warning');
        inv_json_response(['ok'=>true]);

    case 'save_config':
        inv_require_permission('config.edit');
        $beforeCfg = inv_config();
        $cfg = [
            'notifications'=>[],
            'expiry_alert_days'=>(int)($_POST['expiry_alert_days'] ?? 30),
            'max_upload_mb'=>(int)($_POST['max_upload_mb'] ?? 10)
        ];
        foreach (array_keys(inv_default_config()['notifications']) as $key) $cfg['notifications'][$key] = !empty($_POST['notify_' . $key]);
        if (!inv_save_config($cfg)) inv_fail('Impossible d’enregistrer la configuration.', 500, 'config_update_failed', 'config');
        $afterCfg = inv_config();
        $changes = [];
        if ((int)$beforeCfg['expiry_alert_days'] !== (int)$afterCfg['expiry_alert_days']) $changes[] = 'Alerte péremption : ' . (int)$beforeCfg['expiry_alert_days'] . ' → ' . (int)$afterCfg['expiry_alert_days'] . ' jours';
        if ((int)$beforeCfg['max_upload_mb'] !== (int)$afterCfg['max_upload_mb']) $changes[] = 'Taille pièce jointe : ' . (int)$beforeCfg['max_upload_mb'] . ' → ' . (int)$afterCfg['max_upload_mb'] . ' Mo';
        foreach (array_keys(inv_default_config()['notifications']) as $key) {
            if (!empty($beforeCfg['notifications'][$key]) !== !empty($afterCfg['notifications'][$key])) $changes[] = 'Notification ' . $key . ' : ' . (!empty($afterCfg['notifications'][$key]) ? 'activée' : 'désactivée');
        }
        $detail = $changes ? implode(' ; ', $changes) : 'Aucune différence fonctionnelle détectée.';
        inv_log('config_update', ['message'=>'Configuration Inventaire modifiée.','changes'=>$changes], 'success', 'config');
        inv_notify('config','inventory_config_changed','Inventaire : configuration modifiée','La configuration Inventaire a été modifiée par ' . inv_current_email() . '. ' . $detail, ['action'=>'config_update','changes'=>$changes]);
        inv_json_response(['ok'=>true,'config'=>$afterCfg,'changes'=>$changes]);

    case 'logs':
        inv_require_permission('log.view');
        inv_json_response(['ok'=>true,'logs'=>array_slice(inv_load_logs(), 0, 500)]);

    case 'delete_logs':
        inv_require_permission('log.delete');
        $deleted = 0;
        $failed = 0;
        foreach (glob(inv_dir('logs') . '/*.jsonl') ?: [] as $file) {
            if (@unlink($file)) $deleted++; else $failed++;
        }
        inv_log('logs_delete', ['message'=>'Journal Inventaire purgé.','files'=>$deleted,'failed'=>$failed], $failed ? 'warning' : 'success', 'logs');
        /* La purge affecte ceux qui ont le droit de consulter les logs, pas tous les utilisateurs. */
        $logUsers = [];
        foreach (inv_module_users() as $email) if (inv_has_permission('log.view', $email)) $logUsers[] = $email;
        inv_notify_to($logUsers,'logs','inventory_log_deleted','Inventaire : journal purgé',inv_current_email() . ' a purgé le journal Inventaire.', ['files'=>$deleted,'failed'=>$failed,'action'=>'logs_delete'], false, 'warning');
        inv_json_response(['ok'=>true,'deleted'=>$deleted,'failed'=>$failed]);

    case 'download_attachment':
        inv_require_permission('item.view');
        $item = inv_api_item_or_404((string)($_GET['id'] ?? ''));
        $stored = basename((string)($_GET['stored'] ?? ''));
        $path = inv_attachment_path($item, $stored);
        if ($path === '' || !is_file($path)) inv_fail('Fichier introuvable.', 404, 'attachment_download_failed', (string)$item['id'], ['stored'=>$stored]);
        inv_log('attachment_download', ['message'=>'Pièce jointe téléchargée.','id'=>$item['id'],'stored'=>$stored], 'success', (string)$item['id']);
        inv_activity_resource($item, 'attachment_download', ['stored'=>$stored]);
        /* Téléchargement normal = log + activité, pas de notification globale. */
        $name = $stored;
        foreach (($item['attachments'] ?? []) as $att) {
            if (basename((string)($att['stored'] ?? $att['file'] ?? '')) === $stored) $name = (string)($att['name'] ?? $stored);
        }
        header('Content-Type: application/octet-stream');
        header('X-Content-Type-Options: nosniff');
        header('Content-Disposition: attachment; filename="' . str_replace('"','', basename($name)) . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;

    default:
        inv_fail('Action inconnue.', 400, 'unknown_action', $action, ['method'=>(string)($_SERVER['REQUEST_METHOD'] ?? '')]);
}
