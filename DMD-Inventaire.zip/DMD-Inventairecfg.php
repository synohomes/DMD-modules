<?php
require_once __DIR__ . '/DMD-Inventaire_lib.php';

inv_bootstrap();

if (!inv_has_permission('use')) {
    inv_log('config_access_denied', ['message'=>'Accès à la configuration Inventaire refusé.'], 'denied', 'config');
    echo '<div class="inv-app"><div class="inv-empty">Accès à DMD-Inventaire refusé.</div></div>';
    return;
}

$canTemplates = inv_has_permission('template.view')
    || inv_has_permission('template.create')
    || inv_has_permission('template.edit')
    || inv_has_permission('template.delete');
$canConfig = inv_has_permission('config.view') || inv_has_permission('config.edit');
$canLogs = inv_has_permission('log.view') || inv_has_permission('log.export') || inv_has_permission('log.delete');

if (!$canTemplates && !$canConfig && !$canLogs) {
    echo '<div class="inv-app"><div class="inv-empty">Aucun droit de configuration DMD-Inventaire.</div></div>';
    return;
}

$uid = 'dmd-inventaire-cfg-' . bin2hex(random_bytes(4));
$moduleBase = inv_module_web_base();
$templates = inv_has_permission('template.view') ? inv_load_templates() : [];
$fieldTypes = inv_field_types();
$config = inv_config();
$perms = inv_permissions_snapshot();
$csrf = inv_csrf();

function inv_cfg_h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<link rel="stylesheet" href="<?= inv_cfg_h($moduleBase) ?>DMD-Inventaire.css?v=122">

<section
    id="<?= inv_cfg_h($uid) ?>"
    class="inv-app inv-cfg"
    data-api="<?= inv_cfg_h($moduleBase) ?>DMD-Inventaire_api.php" data-export="<?= inv_cfg_h($moduleBase) ?>DMD-Inventaire_export_pdf.php"
>
    <header class="inv-head inv-cfg-header">
        <div>
            <p class="inv-kicker">DoMyDesk 1.2.0</p>
            <h2>DMD-Inventaire — Configuration</h2>
            <p class="inv-muted">Configure les modèles de fiches, les alertes et le journal du module.</p>
        </div>
    </header>

    <nav class="inv-tabs" aria-label="Configuration DMD-Inventaire">
        <?php if ($canTemplates): ?>
            <button type="button" class="inv-btn" data-tab-btn="templates">Modèles de fiches</button>
        <?php endif; ?>
        <?php if ($canConfig): ?>
            <button type="button" class="inv-btn" data-tab-btn="settings">Notifications &amp; alertes</button>
        <?php endif; ?>
        <?php if ($canLogs): ?>
            <button type="button" class="inv-btn" data-tab-btn="logs">Journal d’activité</button>
        <?php endif; ?>
    </nav>

    <?php if ($canTemplates): ?>
        <div class="inv-tab-panel" data-tab="templates">
            <div class="inv-cfg-grid">
                <aside class="inv-cfg-side">
                    <div class="inv-block-head">
                        <div>
                            <h3>Modèles</h3>
                            <p class="inv-help">Un modèle définit les champs disponibles dans une fiche.</p>
                        </div>
                        <?php if ($perms['template.create']): ?>
                            <button type="button" class="inv-btn inv-btn-main" data-new-template>Nouveau modèle</button>
                        <?php endif; ?>
                    </div>

                    <div class="inv-side-list" data-template-list>
                        <?php if ($templates): ?>
                            <?php foreach ($templates as $tpl): ?>
                                <button
                                    type="button"
                                    class="inv-side-item"
                                    data-edit-template="<?= inv_cfg_h(json_encode($tpl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>"
                                >
                                    <strong><?= inv_cfg_h($tpl['name'] ?? 'Modèle') ?></strong>
                                    <small><?= inv_cfg_h($tpl['description'] ?? 'Sans description') ?></small>
                                </button>
                            <?php endforeach; ?>
                        <?php elseif (!$perms['template.create']): ?>
                            <div class="inv-empty">Aucun modèle accessible.</div>
                        <?php endif; ?>
                    </div>
                </aside>

                <section class="inv-cfg-panel">
                    <form data-template-form>
                        <input type="hidden" name="csrf" value="<?= inv_cfg_h($csrf) ?>">

                        <div class="inv-section-title">
                            <div>
                                <h3>Informations du modèle</h3>
                                <p class="inv-help">Le nom est visible par les utilisateurs. L’identifiant technique sert uniquement au stockage.</p>
                            </div>
                        </div>

                        <div class="inv-form-grid">
                            <label class="inv-field inv-field-medium">
                                <span>Nom du modèle</span>
                                <input data-tpl-name required placeholder="Ex. Matériel informatique">
                            </label>

                            <label class="inv-field inv-field-medium">
                                <span>Identifiant technique</span>
                                <input data-tpl-id placeholder="matériel-informatique">
                                <small class="inv-help">Généré automatiquement à partir du nom. Évite de le modifier après utilisation du modèle.</small>
                            </label>

                            <label class="inv-field inv-field-small">
                                <span>Alerte péremption</span>
                                <div class="inv-input-suffix">
                                    <input data-tpl-alert type="number" min="1" max="3650">
                                    <span>jours</span>
                                </div>
                            </label>

                            <label class="inv-field inv-field-large">
                                <span>Description</span>
                                <textarea data-tpl-desc placeholder="À quoi sert ce modèle ?"></textarea>
                            </label>
                        </div>

                        <section class="inv-block inv-fields-block">
                            <div class="inv-block-head">
                                <div>
                                    <h3>Champs de la fiche</h3>
                                    <p class="inv-help">Choisis les informations que les utilisateurs pourront renseigner.</p>
                                </div>
                                <?php if ($perms['template.create'] || $perms['template.edit']): ?>
                                    <button type="button" class="inv-btn" data-add-field>Ajouter un champ</button>
                                <?php endif; ?>
                            </div>
                            <div data-fields-editor></div>
                        </section>

                        <div class="inv-msg" data-template-msg aria-live="polite"></div>

                        <footer class="inv-form-actions">
                            <?php if ($perms['template.delete']): ?>
                                <button type="button" class="inv-btn inv-btn-danger" data-delete-template>Supprimer le modèle</button>
                            <?php endif; ?>
                            <?php if ($perms['template.create'] || $perms['template.edit']): ?>
                                <button type="submit" class="inv-btn inv-btn-main" data-save-template>Enregistrer le modèle</button>
                            <?php endif; ?>
                        </footer>
                    </form>
                </section>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($canConfig): ?>
        <div class="inv-tab-panel" data-tab="settings">
            <form class="inv-settings-layout" data-config-form>
                <input type="hidden" name="csrf" value="<?= inv_cfg_h($csrf) ?>">

                <section class="inv-cfg-panel">
                    <div class="inv-section-title">
                        <div>
                            <h3>Notifications DMD-Inventaire</h3>
                            <p class="inv-help">Les notifications sont envoyées par le Core DoMyDesk aux utilisateurs concernés disposant du droit « Recevoir les notifications ».</p>
                        </div>
                    </div>

                    <label class="inv-switch-row inv-switch-master">
                        <span>
                            <strong>Activer les notifications</strong>
                            <small>Interrupteur général du module.</small>
                        </span>
                        <input
                            type="checkbox"
                            name="notify_enabled"
                            value="1"
                            <?= !empty($config['notifications']['enabled']) ? 'checked' : '' ?>
                            <?= !$perms['config.edit'] ? 'disabled' : '' ?>
                        >
                    </label>
                </section>

                <section class="inv-cfg-panel">
                    <div class="inv-section-title">
                        <div>
                            <h3>Événements à notifier</h3>
                            <p class="inv-help">Tu peux désactiver une famille de notifications sans désactiver les autres.</p>
                        </div>
                    </div>

                    <div class="inv-notify-grid">
                        <?php
                        $notificationOptions = [
                            'items' => ['Fiches', 'Modifications importantes envoyées uniquement aux personnes réellement affectées.'],
                            'templates' => ['Modèles', 'Création, modification et suppression des modèles.'],
                            'attachments' => ['Pièces jointes', 'Ajout et retrait, uniquement pour les personnes réellement affectées.'],
                            'alerts' => ['Alertes', 'Stock bas et dates de péremption.'],
                            'config' => ['Configuration', 'Modification des réglages du module.'],
                            'logs' => ['Journal', 'Purge du journal pour les utilisateurs autorisés à le consulter.'],
                        ];
                        ?>
                        <?php foreach ($notificationOptions as $key => [$title, $description]): ?>
                            <label class="inv-switch-row">
                                <span>
                                    <strong><?= inv_cfg_h($title) ?></strong>
                                    <small><?= inv_cfg_h($description) ?></small>
                                </span>
                                <input
                                    type="checkbox"
                                    name="notify_<?= inv_cfg_h($key) ?>"
                                    value="1"
                                    <?= !empty($config['notifications'][$key]) ? 'checked' : '' ?>
                                    <?= !$perms['config.edit'] ? 'disabled' : '' ?>
                                >
                            </label>
                        <?php endforeach; ?>
                    </div>
                </section>

                <div class="inv-settings-two-cols">
                    <section class="inv-cfg-panel">
                        <div class="inv-section-title">
                            <div>
                                <h3>Péremption</h3>
                                <p class="inv-help">Valeur utilisée par défaut lorsqu’un modèle ne définit pas son propre délai.</p>
                            </div>
                        </div>
                        <label class="inv-field">
                            <span>Prévenir avant la date</span>
                            <div class="inv-input-suffix">
                                <input
                                    type="number"
                                    name="expiry_alert_days"
                                    value="<?= (int)$config['expiry_alert_days'] ?>"
                                    min="1"
                                    max="3650"
                                    <?= !$perms['config.edit'] ? 'disabled' : '' ?>
                                >
                                <span>jours</span>
                            </div>
                        </label>
                    </section>

                    <section class="inv-cfg-panel">
                        <div class="inv-section-title">
                            <div>
                                <h3>Pièces jointes</h3>
                                <p class="inv-help">Limite appliquée à chaque fichier envoyé dans une fiche.</p>
                            </div>
                        </div>
                        <label class="inv-field">
                            <span>Taille maximale par fichier</span>
                            <div class="inv-input-suffix">
                                <input
                                    type="number"
                                    name="max_upload_mb"
                                    value="<?= (int)$config['max_upload_mb'] ?>"
                                    min="1"
                                    max="100"
                                    <?= !$perms['config.edit'] ? 'disabled' : '' ?>
                                >
                                <span>Mo</span>
                            </div>
                        </label>
                    </section>
                </div>

                <div class="inv-msg" data-config-msg aria-live="polite"></div>

                <?php if ($perms['config.edit']): ?>
                    <footer class="inv-form-actions inv-settings-actions">
                        <button type="submit" class="inv-btn inv-btn-main">Enregistrer la configuration</button>
                    </footer>
                <?php else: ?>
                    <p class="inv-readonly-note">Configuration en lecture seule : le droit « Modifier la configuration » n’est pas attribué.</p>
                <?php endif; ?>
            </form>
        </div>
    <?php endif; ?>

    <?php if ($canLogs): ?>
        <div class="inv-tab-panel" data-tab="logs">
            <section class="inv-cfg-panel">
                <div class="inv-block-head inv-log-toolbar">
                    <div>
                        <h3>Journal d’activité</h3>
                        <p class="inv-help">Historique des actions effectuées dans DMD-Inventaire.</p>
                    </div>
                    <div class="inv-actions">
                        <?php if ($perms['log.export']): ?>
                            <button type="button" class="inv-btn" data-export-logs>Exporter en CSV</button>
                        <?php endif; ?>
                        <?php if ($perms['log.delete']): ?>
                            <button type="button" class="inv-btn inv-btn-danger" data-delete-logs>Vider le journal</button>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($perms['log.view']): ?>
                    <div class="inv-log-table" data-logs>
                        <div class="inv-log-head">
                            <span>Date</span>
                            <span>Utilisateur</span>
                            <span>Action</span>
                            <span>Cible / résultat</span>
                        </div>
                        <div class="inv-empty">Chargement du journal…</div>
                    </div>
                <?php else: ?>
                    <div class="inv-empty">Tu peux exporter ou purger le journal, mais tu n’as pas le droit de le consulter.</div>
                <?php endif; ?>

                <div class="inv-msg" data-log-msg aria-live="polite"></div>
            </section>
        </div>
    <?php endif; ?>
</section>

<script>
(() => {
    const root = document.getElementById(<?= json_encode($uid) ?>);
    if (!root) return;

    const api = root.dataset.api;
    const exportUrl = root.dataset.export;
    const csrf = <?= json_encode($csrf) ?>;
    const perms = <?= json_encode($perms) ?>;
    const fieldTypes = <?= json_encode($fieldTypes, JSON_UNESCAPED_UNICODE) ?>;
    const widthLabels = {
        small: 'Petit',
        medium: 'Moyen',
        large: 'Large',
        full: 'Pleine largeur'
    };

    let currentTemplate = null;
    let currentIsNew = false;

    const escapeHtml = value => String(value ?? '').replace(/[&<>'"]/g, char => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#039;',
        '"': '&quot;'
    })[char]);

    const slug = value => String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');

    async function post(action, formData = new FormData()) {
        formData.append('action', action);
        if (!formData.has('csrf')) formData.append('csrf', csrf);

        const response = await fetch(api, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        });
        const data = await response.json();

        if (!response.ok || !data.ok) {
            throw new Error(data.error || 'Erreur DMD-Inventaire.');
        }
        return data;
    }

    function setMessage(element, message, isError = false) {
        if (!element) return;
        element.textContent = message || '';
        element.dataset.error = isError ? '1' : '0';
    }

    /* Navigation */
    const tabButtons = [...root.querySelectorAll('[data-tab-btn]')];
    const tabPanels = [...root.querySelectorAll('[data-tab]')];

    function openTab(name) {
        tabButtons.forEach(button => {
            button.classList.toggle('inv-btn-main', button.dataset.tabBtn === name);
        });
        tabPanels.forEach(panel => {
            panel.classList.toggle('is-active', panel.dataset.tab === name);
        });
        if (name === 'logs') loadLogs();
    }

    tabButtons.forEach(button => {
        button.addEventListener('click', () => openTab(button.dataset.tabBtn));
    });
    if (tabButtons[0]) openTab(tabButtons[0].dataset.tabBtn);

    /* Modèles */
    const fieldsEditor = root.querySelector('[data-fields-editor]');
    const templateForm = root.querySelector('[data-template-form]');
    const templateMessage = root.querySelector('[data-template-msg]');

    function templateWritable() {
        if (!currentTemplate) return false;
        return currentIsNew ? !!perms['template.create'] : !!perms['template.edit'];
    }

    function applyTemplateRights() {
        if (!templateForm) return;

        const writable = templateWritable();
        templateForm.querySelectorAll('[data-tpl-name],[data-tpl-id],[data-tpl-desc],[data-tpl-alert]')
            .forEach(element => { element.disabled = !writable; });

        const addField = root.querySelector('[data-add-field]');
        const saveTemplate = root.querySelector('[data-save-template]');
        const deleteTemplate = root.querySelector('[data-delete-template]');

        if (addField) addField.hidden = !writable;
        if (saveTemplate) saveTemplate.hidden = !writable;
        if (deleteTemplate) {
            deleteTemplate.hidden = !(
                currentTemplate
                && !currentIsNew
                && currentTemplate.id
                && perms['template.delete']
            );
        }

        fieldsEditor?.querySelectorAll('[data-field-value],[data-remove-field]')
            .forEach(element => { element.disabled = !writable; });
    }

    function blankTemplate() {
        currentIsNew = true;
        setTemplate({
            id: '',
            name: '',
            description: '',
            expiry_alert_days: 30,
            fields: [
                {
                    id: 'category',
                    label: 'Catégorie',
                    type: 'select',
                    width: 'medium',
                    list: true,
                    filter: true,
                    options: ['Maison', 'Bureau', 'Atelier']
                },
                {
                    id: 'quantity',
                    label: 'Quantité',
                    type: 'quantity',
                    width: 'small',
                    list: true,
                    required: true,
                    default: '1'
                },
                {
                    id: 'location',
                    label: 'Emplacement',
                    type: 'location',
                    width: 'medium',
                    list: true,
                    filter: true
                }
            ]
        });
    }

    function setTemplate(template) {
        currentTemplate = JSON.parse(JSON.stringify(template || {}));
        fillTemplateForm();
    }

    function fillTemplateForm() {
        if (!templateForm || !currentTemplate) return;

        root.querySelector('[data-tpl-name]').value = currentTemplate.name || '';
        root.querySelector('[data-tpl-id]').value = currentTemplate.id || '';
        root.querySelector('[data-tpl-desc]').value = currentTemplate.description || '';
        root.querySelector('[data-tpl-alert]').value = currentTemplate.expiry_alert_days || 30;

        renderFields();
        applyTemplateRights();
    }

    function syncTemplateFromForm() {
        if (!currentTemplate || !fieldsEditor || !templateWritable()) return;

        currentTemplate.name = root.querySelector('[data-tpl-name]').value.trim();
        currentTemplate.id = root.querySelector('[data-tpl-id]').value.trim() || slug(currentTemplate.name);
        currentTemplate.description = root.querySelector('[data-tpl-desc]').value.trim();
        currentTemplate.expiry_alert_days = Number(root.querySelector('[data-tpl-alert]').value || 30);

        fieldsEditor.querySelectorAll('[data-field-index]').forEach(row => {
            const index = Number(row.dataset.fieldIndex);
            const field = currentTemplate.fields[index];
            if (!field) return;

            row.querySelectorAll('[data-field-value]').forEach(element => {
                const key = element.dataset.fieldValue;

                if (['required', 'list', 'filter'].includes(key)) {
                    field[key] = element.checked;
                } else if (key === 'options') {
                    field[key] = element.value
                        .split(',')
                        .map(value => value.trim())
                        .filter(Boolean);
                } else {
                    field[key] = element.value;
                }
            });

            if (!field.id) field.id = slug(field.label);
        });
    }

    function renderFields() {
        if (!fieldsEditor || !currentTemplate) return;

        const writable = templateWritable();
        const fields = Array.isArray(currentTemplate.fields) ? currentTemplate.fields : [];

        if (!fields.length) {
            fieldsEditor.innerHTML = '<div class="inv-empty">Ce modèle ne contient encore aucun champ.</div>';
            return;
        }

        fieldsEditor.innerHTML = fields.map((field, index) => `
            <article class="inv-field-row" data-field-index="${index}">
                <div class="inv-field-row-head">
                    <div>
                        <strong>${escapeHtml(field.label || 'Champ sans nom')}</strong>
                        <small>${escapeHtml(field.id || 'identifiant à définir')}</small>
                    </div>
                    ${writable ? `<button type="button" class="inv-btn inv-btn-danger" data-remove-field="${index}">Supprimer ce champ</button>` : ''}
                </div>

                <div class="inv-form-grid">
                    <label class="inv-field inv-field-medium">
                        <span>Libellé affiché</span>
                        <input data-field-value="label" value="${escapeHtml(field.label || '')}" ${writable ? '' : 'disabled'}>
                    </label>

                    <label class="inv-field inv-field-medium">
                        <span>Identifiant technique</span>
                        <input data-field-value="id" value="${escapeHtml(field.id || '')}" ${writable ? '' : 'disabled'}>
                    </label>

                    <label class="inv-field inv-field-small">
                        <span>Type de champ</span>
                        <select data-field-value="type" ${writable ? '' : 'disabled'}>
                            ${Object.entries(fieldTypes).map(([key, label]) => `
                                <option value="${escapeHtml(key)}" ${field.type === key ? 'selected' : ''}>${escapeHtml(label)}</option>
                            `).join('')}
                        </select>
                    </label>

                    <label class="inv-field inv-field-small">
                        <span>Largeur</span>
                        <select data-field-value="width" ${writable ? '' : 'disabled'}>
                            ${Object.entries(widthLabels).map(([key, label]) => `
                                <option value="${key}" ${(field.width || 'medium') === key ? 'selected' : ''}>${label}</option>
                            `).join('')}
                        </select>
                    </label>

                    <label class="inv-field inv-field-medium">
                        <span>Valeur par défaut</span>
                        <input data-field-value="default" value="${escapeHtml(field.default || '')}" placeholder="Facultatif" ${writable ? '' : 'disabled'}>
                    </label>

                    <label class="inv-field inv-field-large">
                        <span>Choix possibles</span>
                        <input data-field-value="options" value="${escapeHtml((field.options || []).join(', '))}" placeholder="Ex. Neuf, Bon, À contrôler" ${writable ? '' : 'disabled'}>
                        <small class="inv-help">Utilisé pour les listes et cases à cocher. Sépare les valeurs par des virgules.</small>
                    </label>

                    <div class="inv-field inv-field-large">
                        <span>Comportement</span>
                        <div class="inv-checks">
                            <label class="inv-check">
                                <input type="checkbox" data-field-value="required" ${field.required ? 'checked' : ''} ${writable ? '' : 'disabled'}>
                                Obligatoire
                            </label>
                            <label class="inv-check">
                                <input type="checkbox" data-field-value="list" ${field.list ? 'checked' : ''} ${writable ? '' : 'disabled'}>
                                Afficher dans la liste
                            </label>
                            <label class="inv-check">
                                <input type="checkbox" data-field-value="filter" ${field.filter ? 'checked' : ''} ${writable ? '' : 'disabled'}>
                                Utiliser comme filtre
                            </label>
                        </div>
                    </div>
                </div>
            </article>
        `).join('');

        fieldsEditor.querySelectorAll('[data-field-value]').forEach(element => {
            element.addEventListener('input', syncTemplateFromForm);
            element.addEventListener('change', syncTemplateFromForm);
        });

        fieldsEditor.querySelectorAll('[data-remove-field]').forEach(button => {
            button.addEventListener('click', () => {
                if (!templateWritable()) return;
                syncTemplateFromForm();
                currentTemplate.fields.splice(Number(button.dataset.removeField), 1);
                renderFields();
                applyTemplateRights();
            });
        });
    }

    root.querySelectorAll('[data-edit-template]').forEach(button => {
        button.addEventListener('click', () => {
            currentIsNew = false;
            setTemplate(JSON.parse(button.dataset.editTemplate));
        });
    });

    root.querySelector('[data-new-template]')?.addEventListener('click', blankTemplate);

    root.querySelector('[data-add-field]')?.addEventListener('click', () => {
        if (!templateWritable()) return;
        syncTemplateFromForm();
        currentTemplate.fields = Array.isArray(currentTemplate.fields) ? currentTemplate.fields : [];
        currentTemplate.fields.push({
            id: '',
            label: 'Nouveau champ',
            type: 'text',
            width: 'medium',
            list: false,
            filter: false,
            required: false,
            options: [],
            default: ''
        });
        renderFields();
        applyTemplateRights();
    });

    templateForm?.addEventListener('submit', async event => {
        event.preventDefault();
        if (!templateWritable()) return;

        syncTemplateFromForm();

        try {
            const formData = new FormData();
            formData.append('template_json', JSON.stringify(currentTemplate));
            await post('save_template', formData);
            setMessage(templateMessage, 'Modèle enregistré.');
            window.location.reload();
        } catch (error) {
            setMessage(templateMessage, error.message, true);
        }
    });

    root.querySelector('[data-delete-template]')?.addEventListener('click', async () => {
        if (!currentTemplate?.id) return;
        if (!window.confirm(`Supprimer le modèle « ${currentTemplate.name || currentTemplate.id} » ?`)) return;

        try {
            const formData = new FormData();
            formData.append('id', currentTemplate.id);
            await post('delete_template', formData);
            window.location.reload();
        } catch (error) {
            setMessage(templateMessage, error.message, true);
        }
    });

    if (fieldsEditor) {
        const firstTemplate = root.querySelector('[data-edit-template]');
        if (firstTemplate) firstTemplate.click();
        else if (perms['template.create']) blankTemplate();
    }

    /* Notifications et alertes */
    root.querySelector('[data-config-form]')?.addEventListener('submit', async event => {
        event.preventDefault();
        const message = root.querySelector('[data-config-msg]');

        try {
            await post('save_config', new FormData(event.currentTarget));
            setMessage(message, 'Configuration enregistrée.');
        } catch (error) {
            setMessage(message, error.message, true);
        }
    });

    /* Journal */
    const actionLabels = {
        item_create: 'Fiche créée',
        item_update: 'Fiche modifiée',
        item_archive: 'Fiche archivée',
        item_restore: 'Fiche restaurée',
        item_delete: 'Fiche supprimée',
        attachment_add: 'Pièce jointe ajoutée',
        attachment_remove: 'Pièce jointe supprimée',
        attachment_download: 'Pièce jointe téléchargée',
        template_create: 'Modèle créé',
        template_update: 'Modèle modifié',
        template_delete: 'Modèle supprimé',
        config_update: 'Configuration modifiée',
        export_pdf: 'Export PDF',
        export_csv: 'Export CSV',
        export_json: 'Export JSON',
        log_export: 'Journal exporté',
        logs_delete: 'Journal purgé',
        permission_denied: 'Droit refusé',
        csrf_denied: 'CSRF refusé',
        module_access_denied: 'Accès module refusé',
        config_access_denied: 'Accès configuration refusé',
        item_not_found: 'Fiche introuvable',
        item_validation_failed: 'Validation fiche refusée',
        item_write_failed: 'Échec écriture fiche',
        item_delete_failed: 'Échec suppression fiche',
        attachment_remove_failed: 'Échec suppression pièce jointe',
        attachment_download_failed: 'Échec téléchargement pièce jointe',
        template_validation_failed: 'Validation modèle refusée',
        template_write_failed: 'Échec écriture modèle',
        template_delete_failed: 'Échec suppression modèle',
        config_update_failed: 'Échec configuration',
        unknown_action: 'Action API inconnue',
        activity_index_failed: 'Échec index activité',
        alert_low_stock: 'Alerte stock bas',
        alert_expiry_soon: 'Alerte péremption proche',
        alert_expired: 'Alerte péremption dépassée',
        alert_state_write_failed: 'Échec mémoire des alertes'
    };

    async function loadLogs(force = false) {
        const box = root.querySelector('[data-logs]');
        if (!box || !perms['log.view']) return;
        if (!force && box.dataset.loaded === '1') return;

        try {
            const response = await fetch(`${api}?action=logs`, { credentials: 'same-origin' });
            const data = await response.json();
            if (!response.ok || !data.ok) throw new Error(data.error || 'Impossible de charger le journal.');

            box.dataset.loaded = '1';
            const rows = data.logs || [];

            box.innerHTML = `
                <div class="inv-log-head">
                    <span>Date</span>
                    <span>Utilisateur</span>
                    <span>Action</span>
                    <span>Cible / résultat</span>
                </div>
                ${rows.length ? rows.map(log => {
                    const date = log.date || log.datetime || '-';
                    const user = log.user || '-';
                    const action = actionLabels[log.action] || log.action || '-';
                    const target = log.target || '';
                    const result = log.result || '';
                    const details = log.details ? JSON.stringify(log.details) : '';
                    return `
                        <div class="inv-log-row" title="${escapeHtml(details)}">
                            <small>${escapeHtml(date)}</small>
                            <strong>${escapeHtml(user)}</strong>
                            <span>${escapeHtml(action)}</span>
                            <span>${escapeHtml([target, result].filter(Boolean).join(' — ') || '-')}</span>
                        </div>
                    `;
                }).join('') : '<div class="inv-empty">Journal vide.</div>'}
            `;
        } catch (error) {
            box.innerHTML = `<div class="inv-empty">${escapeHtml(error.message)}</div>`;
        }
    }

    root.querySelector('[data-delete-logs]')?.addEventListener('click', async () => {
        if (!window.confirm('Vider définitivement le journal DMD-Inventaire ?')) return;
        const message = root.querySelector('[data-log-msg]');

        try {
            await post('delete_logs');
            setMessage(message, 'Journal vidé.');
            await loadLogs(true);
        } catch (error) {
            setMessage(message, error.message, true);
        }
    });

    root.querySelector('[data-export-logs]')?.addEventListener('click', () => {
        const a = document.createElement('a');
        a.href = exportUrl + '?format=log_csv';
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        a.remove();
    });
})();
</script>
