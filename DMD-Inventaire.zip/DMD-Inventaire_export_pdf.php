<?php
require_once __DIR__ . '/DMD-Inventaire_lib.php';
inv_bootstrap();
$format = strtolower((string)($_GET['format'] ?? 'pdf'));
if ($format === 'pdf') inv_require_permission('export.pdf');
elseif ($format === 'csv') inv_require_permission('export.csv');
elseif ($format === 'json') inv_require_permission('export.json');
elseif ($format === 'log_csv') inv_require_permission('log.export');
else inv_fail('Format d’export inconnu.', 400, 'export_failed', $format, ['reason'=>'unknown_format']);

function inv_export_filename(string $ext, string $prefix='inventaire'): string { return $prefix . '-' . date('Ymd-His') . '.' . $ext; }
function inv_csv_cell($v): string { return '"' . str_replace('"', '""', is_array($v) ? implode(', ', $v) : (string)$v) . '"'; }

if ($format === 'log_csv') {
    $logs = inv_load_logs();
    inv_log('log_export', ['message'=>'Journal exporté en CSV.','count'=>count($logs)]);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . inv_export_filename('csv','inventaire-journal') . '"');
    echo "\xEF\xBB\xBF" . implode(';', ['Date','Utilisateur','Rôle','Action','Cible','Résultat','IP','Détails']) . "\n";
    foreach ($logs as $l) echo implode(';', array_map('inv_csv_cell', [$l['date']??$l['datetime']??'',$l['user']??'',$l['role']??'',$l['action']??'',$l['target']??'',$l['result']??'',$l['ip']??'',json_encode($l['details']??[],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)])) . "\n";
    exit;
}

$items = inv_filter_items(inv_load_items(), $_GET);
$eventMeta = ['format'=>$format,'count'=>count($items)];
inv_log('export_' . $format, ['message'=>'Inventaire exporté.'] + $eventMeta);

if ($format === 'json') {
    header('Content-Type: application/json; charset=utf-8'); header('Content-Disposition: attachment; filename="'.inv_export_filename('json').'"');
    echo json_encode(['exported_at'=>date('Y-m-d H:i:s'),'exported_by'=>inv_current_email(),'items'=>$items], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
}
if ($format === 'csv') {
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="'.inv_export_filename('csv').'"'); echo "\xEF\xBB\xBF";
    echo implode(';',['ID','Titre','Modèle','Catégorie','Quantité','Unité','Emplacement','Péremption','État','Stock','MAJ'])."\n";
    foreach($items as $it) echo implode(';',array_map('inv_csv_cell',[$it['id']??'',$it['title']??'',$it['template']??'',$it['category']??'',$it['quantity']??'',$it['unit']??'',$it['location']??'',$it['expires_at']??'',$it['_computed']['expiry_status']??'',$it['_computed']['stock_status']??'',$it['updated_at']??'']))."\n";
    exit;
}
class InvMiniPdf {
    private $pages = []; private $current = ''; private $y = 800; private $pageNo = 0;
    private function enc(string $s): string { $s=@iconv('UTF-8','Windows-1252//TRANSLIT//IGNORE',$s)?:$s; return str_replace(['\\','(',')'],['\\\\','\\(','\\)'],$s); }
    public function addPage(): void { if($this->current)$this->pages[]=$this->current;$this->current='';$this->y=800;$this->pageNo++;$this->text(40,820,'Inventaire - DoMyDesk 1.2.0',13,true);$this->line(40,812,555,812); }
    public function text(int $x,int $y,string $txt,int $size=9,bool $bold=false): void {$font=$bold?'F2':'F1';$this->current.="BT /$font $size Tf $x $y Td (".$this->enc($txt).") Tj ET\n";}
    public function line(int $x1,int $y1,int $x2,int $y2): void {$this->current.="$x1 $y1 m $x2 $y2 l S\n";}
    public function row(array $cols,array $w,bool $head=false): void {if($this->y<55)$this->addPage();$x=40;$h=18;foreach($cols as $i=>$c){$this->current.="$x ".($this->y-5)." ".$w[$i]." $h re S\n";$this->text($x+3,$this->y,mb_strimwidth((string)$c,0,(int)($w[$i]/4.2),'…','UTF-8'),$head?8:7,$head);$x+=$w[$i];}$this->y-=$h;}
    public function br(int $n=12): void {$this->y-=$n;}
    public function output(): string {if($this->current)$this->pages[]=$this->current;$objects=[];$kids=[];$obj=1;$f1=$obj++;$f2=$obj++;$pages=$obj++;foreach($this->pages as $p){$co=$obj++;$po=$obj++;$objects[$co]="<< /Length ".strlen($p)." >>\nstream\n$p\nendstream";$objects[$po]="<< /Type /Page /Parent $pages 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 $f1 0 R /F2 $f2 0 R >> >> /Contents $co 0 R >>";$kids[]="$po 0 R";}$cat=$obj++;$objects[$f1]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';$objects[$f2]='<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>';$objects[$pages]='<< /Type /Pages /Kids ['.implode(' ',$kids).'] /Count '.count($kids).' >>';$objects[$cat]="<< /Type /Catalog /Pages $pages 0 R >>";ksort($objects);$pdf="%PDF-1.4\n";$xref=[0=>'0000000000 65535 f '];foreach($objects as $id=>$body){$xref[$id]=sprintf('%010d 00000 n ',strlen($pdf));$pdf.="$id 0 obj\n$body\nendobj\n";}$start=strlen($pdf);$pdf.="xref\n0 ".(count($objects)+1)."\n";for($i=0;$i<=count($objects);$i++)$pdf.=($xref[$i]??'0000000000 00000 f ')."\n";$pdf.="trailer << /Size ".(count($objects)+1)." /Root $cat 0 R >>\nstartxref\n$start\n%%EOF";return $pdf;}
}
$total=count($items);$low=count(array_filter($items, function ($i) { return ($i['_computed']['stock_status'] ?? '') === 'low'; }));$soon=count(array_filter($items, function ($i) { return ($i['_computed']['expiry_status'] ?? '') === 'soon'; }));$expired=count(array_filter($items, function ($i) { return ($i['_computed']['expiry_status'] ?? '') === 'expired'; }));
$pdf=new InvMiniPdf();$pdf->addPage();$pdf->text(40,790,'Exporté le '.date('d/m/Y H:i').' par '.inv_current_email(),9);$pdf->br(28);$pdf->text(40,765,"Résumé : total $total | stock bas $low | bientôt périmé $soon | périmé $expired",10,true);$pdf->br(25);$pdf->row(['Titre','Catégorie','Qté','Emplacement','Péremption','État'],[130,90,45,110,70,70],true);foreach($items as $it){$pdf->row([$it['title']??'',$it['category']??'',trim((string)($it['quantity']??'-').' '.(string)($it['unit']??'')),$it['location']??'',$it['expires_at']??'',$it['_computed']['global_status']??'ok'],[130,90,45,110,70,70]);}$out=$pdf->output();header('Content-Type: application/pdf');header('Content-Disposition: inline; filename="'.inv_export_filename('pdf').'"');header('Content-Length: '.strlen($out));echo $out;
?>
