<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
require_once __DIR__ . '/DMD-Infra-IT_lib.php';

function dmdi_api_out($ok, $message = '', $extra = array(), $status = 200) {
    http_response_code((int)$status);
    echo json_encode(array_merge(array('ok'=>(bool)$ok,'message'=>(string)$message), $extra), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function dmdi_api_fail($message, $status = 400, $extra = array()) { dmdi_api_out(false, $message, $extra, $status); }
function dmdi_api_require_csrf($body) {
    $token = (string)($body['csrf'] ?? ($_SERVER['HTTP_X_DMD_CSRF'] ?? ''));
    if (!dmdi_check_csrf($token)) dmdi_api_fail('Jeton de sécurité invalide.', 403);
}
function dmdi_api_summary($doc, $me) {
    $d = is_array($doc['data'] ?? null) ? $doc['data'] : array();
    return array(
        'id'=>(string)($doc['id'] ?? ''),
        'owner'=>(string)($doc['owner'] ?? ''),
        'title'=>(string)($doc['title'] ?? 'Infrastructure'),
        'description'=>(string)($d['header']['description'] ?? ''),
        'site'=>(string)($d['header']['site'] ?? ''),
        'updated_at'=>(string)($doc['updated_at'] ?? ''),
        'shared'=>strcasecmp((string)($doc['owner'] ?? ''), (string)$me) !== 0,
        'shared_count'=>count(is_array($doc['acl'] ?? null) ? $doc['acl'] : array()),
        'counts'=>array(
            'internet'=>count(is_array($d['internet'] ?? null) ? $d['internet'] : array()),
            'firewalls'=>count(is_array($d['firewalls'] ?? null) ? $d['firewalls'] : array()),
            'vlans'=>count(is_array($d['vlans'] ?? null) ? $d['vlans'] : array()),
            'switches'=>count(is_array($d['switches'] ?? null) ? $d['switches'] : array()),
            'devices'=>count(is_array($d['devices'] ?? null) ? $d['devices'] : array())
        ),
        'permissions'=>array(
            'view'=>dmdi_can_doc($doc,$me,'view'),
            'edit'=>dmdi_can_doc($doc,$me,'edit'),
            'export'=>dmdi_can_doc($doc,$me,'export'),
            'share'=>dmdi_can_doc($doc,$me,'share'),
            'delete'=>dmdi_can_doc($doc,$me,'delete')
        ),
        'resource'=>dmdi_resource($doc)
    );
}
function dmdi_api_replace_doc($owner, $newDoc) {
    $docs = dmdi_load_own_docs($owner); $found = false;
    foreach ($docs as $i=>$doc) {
        if ((string)($doc['id'] ?? '') === (string)$newDoc['id']) { $docs[$i] = $newDoc; $found = true; break; }
    }
    if (!$found) $docs[] = $newDoc;
    return dmdi_save_own_docs($owner, $docs);
}
function dmdi_api_acl_map($acl) {
    $out = array();
    foreach (is_array($acl) ? $acl : array() as $row) {
        $email = strtolower((string)($row['email'] ?? '')); if ($email === '') continue;
        $p = is_array($row['permissions'] ?? null) ? $row['permissions'] : array(); sort($p);
        $out[$email] = $p;
    }
    return $out;
}

$me = strtolower(dmdi_email());
if ($me === '') dmdi_api_fail('Connexion requise.', 401);
$action = trim((string)($_GET['action'] ?? $_POST['action'] ?? 'bootstrap'));
$body = dmdi_read_body();
if (isset($body['action'])) $action = trim((string)$body['action']);

try {
    if ($action === 'bootstrap') {
        dmdi_require_permission('module.view');
        $docs = dmdi_list_accessible_docs($me); $summaries = array();
        foreach ($docs as $doc) $summaries[] = dmdi_api_summary($doc, $me);
        dmdi_api_out(true, '', array(
            'csrf'=>dmdi_csrf_token(),
            'documents'=>$summaries,
            'users'=>dmdi_share_users($me),
            'permissions'=>array(
                'view'=>dmdi_has_permission('module.view'),
                'create'=>dmdi_has_permission('infra.create'),
                'edit'=>dmdi_has_permission('infra.edit'),
                'delete'=>dmdi_has_permission('infra.delete'),
                'share'=>dmdi_has_permission('infra.share'),
                'export'=>dmdi_has_permission('infra.export'),
                'logs_view'=>dmdi_has_permission('logs.view'),
                'logs_export'=>dmdi_has_permission('logs.export'),
                'logs_delete'=>dmdi_has_permission('logs.delete')
            )
        ));
    }

    if ($action === 'get') {
        dmdi_require_permission('module.view');
        $owner = strtolower(trim((string)($_GET['owner'] ?? $body['owner'] ?? $me)));
        $id = trim((string)($_GET['id'] ?? $body['id'] ?? ''));
        if ($id === '') dmdi_api_fail('Infrastructure non indiquée.');
        $doc = dmdi_get_accessible_doc($owner, $id, 'view');
        if (!$doc) dmdi_api_fail('Infrastructure introuvable ou accès refusé.', 404);
        dmdi_api_out(true, '', array('doc'=>$doc,'summary'=>dmdi_api_summary($doc,$me)));
    }

    if ($action === 'create') {
        dmdi_require_permission('infra.create'); dmdi_api_require_csrf($body);
        $data = dmdi_migrate_data($body['data'] ?? array());
        if (empty($data['header']['title'])) $data['header']['title'] = 'Nouvelle infrastructure';
        $doc = dmdi_normalize_doc(array('id'=>dmdi_new_id(),'data'=>$data,'acl'=>array()), $me);
        if (!dmdi_api_replace_doc($me, $doc)) dmdi_api_fail('Impossible de créer l’infrastructure.', 500);
        $event = dmdi_audit('create','success',$doc,'Infrastructure créée.',array('owner'=>$me));
        dmdi_api_out(true, 'Infrastructure créée.', array('doc'=>$doc,'summary'=>dmdi_api_summary($doc,$me),'activity_event'=>$event));
    }

    if ($action === 'save') {
        dmdi_require_permission('infra.edit'); dmdi_api_require_csrf($body);
        $owner = strtolower(trim((string)($body['owner'] ?? $me))); if ($owner === '') $owner = $me;
        $id = trim((string)($body['id'] ?? ''));
        if ($id === '') dmdi_api_fail('Infrastructure non indiquée.');
        $old = dmdi_get_accessible_doc($owner, $id, 'edit');
        if (!$old) dmdi_api_fail('Modification refusée ou infrastructure introuvable.', 403);
        $data = dmdi_migrate_data($body['data'] ?? array());
        $title = trim((string)($data['header']['title'] ?? $old['title'])); if ($title === '') $title = 'Infrastructure';
        $doc = $old; $doc['data'] = $data; $doc['title'] = $title; $doc['updated_at'] = date('c');
        $doc['owner'] = $old['owner']; $doc['acl'] = $old['acl'];
        if (!dmdi_api_replace_doc($owner, $doc)) dmdi_api_fail('Impossible d’enregistrer l’infrastructure.', 500);
        if (strcasecmp($owner,$me) === 0) dmdi_sync_refs_for_doc($doc, $old['acl']);
        $event = dmdi_audit('edit','success',$doc,'Infrastructure mise à jour.',array('owner'=>$owner));
        if (strcasecmp($owner, $me) !== 0) {
            dmdi_notify($owner,'dmd_infra_it_updated','Infrastructure mise à jour par un collaborateur',($doc['title'] ?? 'Infrastructure').' a été modifiée par '.$me.'.','info');
        }
        foreach ($doc['acl'] as $row) {
            dmdi_notify((string)$row['email'],'dmd_infra_it_updated','Infrastructure partagée mise à jour',($doc['title'] ?? 'Infrastructure').' a été modifiée par '.$me.'.','info');
        }
        dmdi_api_out(true, 'Infrastructure enregistrée.', array('doc'=>$doc,'summary'=>dmdi_api_summary($doc,$me),'activity_event'=>$event));
    }

    if ($action === 'delete') {
        dmdi_require_permission('infra.delete'); dmdi_api_require_csrf($body);
        $owner = strtolower(trim((string)($body['owner'] ?? $me))); $id = trim((string)($body['id'] ?? ''));
        if ($owner !== $me) dmdi_api_fail('Seul le propriétaire peut supprimer cette infrastructure.', 403);
        $old = dmdi_get_accessible_doc($owner, $id, 'delete');
        if (!$old) dmdi_api_fail('Suppression refusée ou infrastructure introuvable.', 403);
        $docs = dmdi_load_own_docs($owner); $next = array();
        foreach ($docs as $doc) if ((string)$doc['id'] !== $id) $next[] = $doc;
        if (!dmdi_save_own_docs($owner,$next)) dmdi_api_fail('Impossible de supprimer l’infrastructure.',500);
        dmdi_remove_refs_for_doc($old);
        $event = dmdi_audit('delete','success',$old,'Infrastructure supprimée.',array('owner'=>$owner));
        foreach ($old['acl'] as $row) dmdi_notify((string)$row['email'],'dmd_infra_it_removed','Partage d’infrastructure supprimé',($old['title'] ?? 'Infrastructure').' n’est plus disponible.','warning');
        dmdi_api_out(true,'Infrastructure supprimée.',array('activity_event'=>$event));
    }

    if ($action === 'share') {
        dmdi_require_permission('infra.share'); dmdi_api_require_csrf($body);
        $owner = strtolower(trim((string)($body['owner'] ?? $me))); $id = trim((string)($body['id'] ?? ''));
        if ($owner !== $me) dmdi_api_fail('Seul le propriétaire peut modifier les partages.',403);
        $old = dmdi_get_accessible_doc($owner,$id,'share');
        if (!$old) dmdi_api_fail('Partage refusé ou infrastructure introuvable.',403);
        $oldAcl = $old['acl'];
        foreach (is_array($body['acl'] ?? null) ? $body['acl'] : array() as $row) {
            if (!is_array($row)) continue;
            $target = strtolower(trim((string)($row['email'] ?? '')));
            if ($target === '') continue;
            if (!dmdi_profile_email_exists($target)) dmdi_api_fail('Utilisateur DoMyDesk introuvable dans users/profiles : ' . $target, 400);
            if ($target === strtolower($owner)) dmdi_api_fail('Le propriétaire ne peut pas se partager sa propre infrastructure.', 400);
        }
        $newAcl = dmdi_normalize_acl($body['acl'] ?? array(), $owner);
        $doc = $old; $doc['acl'] = $newAcl; $doc['updated_at'] = date('c');
        if (!dmdi_api_replace_doc($owner,$doc)) dmdi_api_fail('Impossible d’enregistrer les partages.',500);
        dmdi_sync_refs_for_doc($doc,$oldAcl);
        $before = dmdi_api_acl_map($oldAcl); $after = dmdi_api_acl_map($newAcl);
        foreach ($after as $email=>$perms) {
            if (!isset($before[$email])) dmdi_notify($email,'dmd_infra_it_shared','Une infrastructure vous a été partagée',($doc['title'] ?? 'Infrastructure').' est maintenant accessible dans DMD-Infra-IT.','info');
            elseif ($before[$email] !== $perms) dmdi_notify($email,'dmd_infra_it_share_changed','Vos droits de partage ont changé','Les droits sur '.($doc['title'] ?? 'Infrastructure').' ont été modifiés.','warning');
        }
        foreach ($before as $email=>$perms) if (!isset($after[$email])) dmdi_notify($email,'dmd_infra_it_share_revoked','Un partage a été retiré','Vous n’avez plus accès à '.($doc['title'] ?? 'Infrastructure').'.','warning');
        $event = dmdi_audit('share','success',$doc,'Partages de l’infrastructure mis à jour.',array('shared_with'=>array_keys($after)));
        dmdi_api_out(true,'Partages enregistrés.',array('doc'=>$doc,'summary'=>dmdi_api_summary($doc,$me),'activity_event'=>$event));
    }

    if ($action === 'logs') {
        dmdi_require_permission('logs.view');
        dmdi_api_out(true,'',array('rows'=>dmdi_log_rows((int)($_GET['limit'] ?? $body['limit'] ?? 150))));
    }

    if ($action === 'logs_export') {
        dmdi_require_permission('logs.export');
        $rows = dmdi_log_rows(500);
        dmdi_log('logs_export','success',DMDI_MODULE_ID,'Journal DMD-Infra-IT exporté.',array('rows'=>count($rows)),$me);
        header_remove('Content-Type'); header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="dmd-infra-it-logs-'.date('Ymd-His').'.json"');
        echo json_encode($rows, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
    }

    if ($action === 'logs_clear') {
        dmdi_require_permission('logs.delete'); dmdi_api_require_csrf($body); dmdi_ensure_runtime();
        if (@file_put_contents(dmdi_log_file(),'') === false) dmdi_api_fail('Impossible de vider le journal.',500);
        dmdi_log('logs_clear','success',DMDI_MODULE_ID,'Journal DMD-Infra-IT purgé.',array(),$me);
        dmdi_api_out(true,'Journal vidé.');
    }

    dmdi_api_fail('Action inconnue.',404);
} catch (Throwable $e) {
    if (http_response_code() < 400) http_response_code(500);
    dmdi_api_out(false, $e->getMessage() ?: 'Erreur interne.', array(), http_response_code());
}
