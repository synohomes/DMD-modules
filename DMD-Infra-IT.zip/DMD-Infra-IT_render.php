<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
require_once __DIR__ . '/DMD-Infra-IT_lib.php';
$me = strtolower(dmdi_email());
if ($me === '') { http_response_code(401); exit('Connexion requise.'); }
try { dmdi_require_permission('module.view'); } catch (Throwable $e) { http_response_code(403); exit('Accès refusé.'); }
$owner = strtolower(trim((string)($_GET['owner'] ?? $me)));
$id = trim((string)($_GET['doc'] ?? ''));
$embed = !empty($_GET['embed']);
$printRequest = !empty($_GET['print']);
$action = $printRequest ? 'export' : 'view';
$doc = dmdi_get_accessible_doc($owner,$id,$action);
if (!$doc) { http_response_code(404); exit('Infrastructure introuvable ou accès refusé.'); }
if ($printRequest) dmdi_audit('export','success',$doc,'Rapport infrastructure ouvert pour impression / PDF.',array('format'=>'print'));
$data = is_array($doc['data'] ?? null) ? dmdi_migrate_data($doc['data']) : dmdi_default_data();
$h = is_array($data['header'] ?? null) ? $data['header'] : array();
$internet = is_array($data['internet'] ?? null) ? $data['internet'] : array();
$firewalls = is_array($data['firewalls'] ?? null) ? $data['firewalls'] : array();
$vlans = is_array($data['vlans'] ?? null) ? $data['vlans'] : array();
$switches = is_array($data['switches'] ?? null) ? $data['switches'] : array();
$devices = is_array($data['devices'] ?? null) ? $data['devices'] : array();
$vmap = array(); foreach($vlans as $v){ $vid=(string)($v['id']??''); if($vid!=='')$vmap[$vid]=$v; }
function dmdi_r_arr($x){ return is_array($x)?$x:array(); }
function dmdi_r_first($a,$b){ return trim((string)$a)!==''?$a:$b; }
function dmdi_r_vlan($id,$map){ $id=(string)$id; if($id==='')return '—'; $v=$map[$id]??array(); return 'VLAN '.$id.(!empty($v['name'])?' — '.$v['name']:''); }
$date = (($h['dateMode'] ?? 'auto') === 'fixed' && !empty($h['fixedDate'])) ? (string)$h['fixedDate'] : date('d/m/Y');
$title = trim((string)($h['title'] ?? $doc['title'] ?? 'Infrastructure')); if($title==='')$title='Infrastructure';
$theme='default';
$themeFile=dmdi_root().'/users/profiles/'.dmdi_safe_email($me).'/theme.json';
if(is_file($themeFile)){
    $tj=dmdi_json_read($themeFile,array());$candidate=preg_replace('/[^a-zA-Z0-9_-]/','',(string)($tj['theme']??$tj['name']??''));
    if($candidate!=='' && is_file(dmdi_root().'/theme/'.$candidate.'/style.css'))$theme=$candidate;
}
function dmdi_r_root_url(){
    $docRoot=realpath((string)($_SERVER['DOCUMENT_ROOT']??''));$root=realpath(dmdi_root());
    if($docRoot&&$root&&strpos($root,$docRoot)===0)return '/'.trim(str_replace('\\','/',substr($root,strlen($docRoot))),'/');
    $script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));$p=strpos($script,'/modules/');return $p!==false?substr($script,0,$p):'';
}
$rootUrl=rtrim(dmdi_r_root_url(),'/');
?>
<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= dmdi_h($title) ?></title>
<link rel="stylesheet" href="<?= dmdi_h($rootUrl) ?>/theme/<?= dmdi_h($theme) ?>/style.css">
<link rel="stylesheet" href="DMD-Infra-IT.css?v=1.2.0">
</head>
<body class="dmdi-render-body">
<main class="dmdi-report" data-dmd-module-id="DMD-Infra-IT" data-dmd-context-type="infrastructure" data-dmd-context-id="<?= dmdi_h(dmdi_resource($doc)['id']) ?>" data-dmd-context-name="<?= dmdi_h($title) ?>" data-dmd-action-hub="1">
<?php if(!$embed): ?><div class="dmdi-printbar"><button type="button" class="dmdi-btn dmdi-btn-primary" id="dmdiPrint">Exporter PDF / imprimer</button></div><?php endif; ?>
<header class="dmdi-hero">
  <h1><?= dmdi_h($title) ?></h1>
  <p><?= dmdi_h($h['description'] ?? '') ?></p>
  <div class="dmdi-kpis">
    <div class="dmdi-kpi"><span>Site</span><b><?= dmdi_h($h['site'] ?? '—') ?></b></div>
    <div class="dmdi-kpi"><span>Référent</span><b><?= dmdi_h($h['owner'] ?? '—') ?></b></div>
    <div class="dmdi-kpi"><span>Mise à jour</span><b><?= dmdi_h($date) ?></b></div>
    <div class="dmdi-kpi"><span>VLANs</span><b><?= count($vlans) ?></b></div>
    <div class="dmdi-kpi"><span>Switchs</span><b><?= count($switches) ?></b></div>
    <div class="dmdi-kpi"><span>Équipements</span><b><?= count($devices) ?></b></div>
  </div>
</header>
<div class="dmdi-render-grid">
  <section class="dmdi-r-card">
    <h2>Vue réseau</h2>
    <div class="dmdi-flow">
      <div class="dmdi-flowbox"><strong>Internet</strong><?php if(!$internet): ?><div class="dmdi-muted">Non documenté</div><?php endif; ?><?php foreach($internet as $w): ?><div><?= dmdi_h(dmdi_r_first($w['name']??'',$w['operator']??'WAN')) ?> <span class="dmdi-muted"><?= dmdi_h($w['public_ip']??'') ?></span></div><?php endforeach; ?></div>
      <div class="dmdi-flowbox"><strong>Firewalls</strong><?php if(!$firewalls): ?><div class="dmdi-muted">Non documenté</div><?php endif; ?><?php foreach($firewalls as $f): ?><div><?= dmdi_h($f['name']??'Firewall') ?> <span class="dmdi-muted"><?= dmdi_h($f['vendor_model']??'') ?></span></div><?php endforeach; ?></div>
      <div class="dmdi-flowbox"><strong>VLANs</strong><div><?= count($vlans) ?> réseau(x) documenté(s)</div></div>
      <div class="dmdi-flowbox"><strong>Distribution</strong><div><?= count($switches) ?> switch(s), <?= count($devices) ?> équipement(s)</div></div>
    </div>
  </section>

  <section class="dmdi-r-card">
    <h2>VLANs</h2>
    <?php if(!$vlans): ?><div class="dmdi-muted">Aucun VLAN documenté.</div><?php else: ?>
    <div class="dmdi-vlans">
      <?php foreach($vlans as $v): ?>
      <article class="dmdi-vlan-card"><b>VLAN <?= dmdi_h($v['id']??'') ?> — <?= dmdi_h($v['name']??'') ?></b><div class="dmdi-muted"><?= dmdi_h($v['cidr']??'') ?> · GW <?= dmdi_h($v['gateway']??'') ?></div><div><?= dmdi_h($v['description']??'') ?></div><?php if(!empty($v['color'])):?><div class="dmdi-muted">Repère : <?= dmdi_h($v['color']) ?></div><?php endif;?></article>
      <?php endforeach; ?>
    </div><?php endif; ?>
  </section>

  <section class="dmdi-r-card half">
    <h2>Connexions internet</h2>
    <div class="dmdi-r-list">
      <?php if(!$internet): ?><div class="dmdi-muted">Aucune connexion documentée.</div><?php endif; ?>
      <?php foreach($internet as $w): ?>
      <div class="dmdi-r-row"><div><span>Nom</span><b><?= dmdi_h($w['name']??'') ?></b></div><div><span>Opérateur</span><?= dmdi_h($w['operator']??'') ?></div><div><span>Type / statut</span><?= dmdi_h(trim((string)($w['type']??'').' '.(string)($w['status']??''))) ?></div><div><span>IP publique / débit</span><code><?= dmdi_h($w['public_ip']??'') ?></code> <?= dmdi_h($w['bandwidth']??'') ?><br><?= dmdi_h($w['note']??'') ?></div></div>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="dmdi-r-card half">
    <h2>Firewalls</h2>
    <div class="dmdi-r-list">
      <?php if(!$firewalls): ?><div class="dmdi-muted">Aucun firewall documenté.</div><?php endif; ?>
      <?php foreach($firewalls as $f): ?>
      <div class="dmdi-r-row"><div><span>Firewall</span><b><?= dmdi_h($f['name']??'') ?></b><br><?= dmdi_h($f['role']??'') ?></div><div><span>Modèle</span><?= dmdi_h($f['vendor_model']??'') ?></div><div><span>WAN / LAN</span><code><?= dmdi_h($f['wan_ip']??'') ?></code><br><code><?= dmdi_h($f['lan_ip']??'') ?></code></div><div><span>VLAN mgmt / Internet</span><?= dmdi_h(dmdi_r_vlan($f['mgmt_vlan']??'',$vmap)) ?><br><?= dmdi_h($f['internet']??'') ?><br><?= dmdi_h($f['note']??'') ?></div></div>
      <?php endforeach; ?>
    </div>
  </section>

  <?php foreach($switches as $sw): ?>
  <section class="dmdi-r-card">
    <h2><?= dmdi_h($sw['name']??'Switch') ?> <span class="dmdi-muted"><?= dmdi_h($sw['model']??'') ?> · <?= dmdi_h($sw['location']??'') ?></span></h2>
    <div class="dmdi-r-list">
      <div class="dmdi-r-row"><div><span>IP management</span><code><?= dmdi_h($sw['mgmt_ip']??'') ?></code></div><div><span>VLAN management</span><?= dmdi_h(dmdi_r_vlan($sw['mgmt_vlan']??'',$vmap)) ?></div><div><span>Uplink</span><?= dmdi_h($sw['uplink']??'') ?></div><div><span>Ports documentés</span><?= count(dmdi_r_arr($sw['ports']??array())) ?></div></div>
      <?php foreach(dmdi_r_arr($sw['ports']??array()) as $p): ?>
      <div class="dmdi-r-row"><div><span>Port</span><b><?= dmdi_h($p['port']??'') ?></b></div><div><span>Mode</span><?= dmdi_h($p['mode']??'') ?></div><div><span>VLAN</span><?= dmdi_h(dmdi_r_vlan($p['vlan']??'',$vmap)) ?></div><div><span>Description</span><?= dmdi_h($p['description']??'') ?></div></div>
      <?php endforeach; ?>
    </div>
  </section>
  <?php endforeach; ?>

  <section class="dmdi-r-card">
    <h2>Périphériques / plan réseau</h2>
    <div class="dmdi-r-list">
      <?php if(!$devices): ?><div class="dmdi-muted">Aucun périphérique documenté.</div><?php endif; ?>
      <?php foreach($devices as $d): ?>
      <div class="dmdi-r-row"><div><span>Nom</span><b><?= dmdi_h($d['name']??'') ?></b><br><span><?= dmdi_h($d['type']??'') ?></span></div><div><span>IP</span><code><?= dmdi_h($d['ip']??($d['addr']??'')) ?></code></div><div><span>VLAN</span><?= dmdi_h(dmdi_r_vlan($d['vlan']??'',$vmap)) ?></div><div><span>Switch / port</span><?= dmdi_h($d['switch']??'') ?> <?= dmdi_h($d['port']??'') ?><br><?= dmdi_h($d['description']??'') ?></div></div>
      <?php endforeach; ?>
    </div>
  </section>
</div>
</main>
<script>
(() => {
  const b=document.getElementById('dmdiPrint'); if(b) b.addEventListener('click',()=>window.print());
  try { if(window.DMDActionHub && typeof window.DMDActionHub.decorate==='function') window.DMDActionHub.decorate(document.querySelector('.dmdi-report')); } catch(_) { }
})();
</script>
</body>
</html>
