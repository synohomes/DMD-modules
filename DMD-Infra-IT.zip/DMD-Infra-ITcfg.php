<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/DMD-Infra-IT_lib.php';
$me = strtolower(dmdi_email());
if ($me === '') { echo '<div class="dmdi-empty">Connexion requise.</div>'; return; }
try { dmdi_require_permission('module.view'); } catch (Throwable $e) { echo '<div class="dmdi-empty">Accès DMD-Infra-IT refusé.</div>'; return; }
function dmdi_cfg_base_url(){
    $script=str_replace('\\','/',(string)($_SERVER['SCRIPT_NAME']??''));
    if(strpos($script,'/modules/')!==false)return rtrim(dirname($script),'/');
    $docRoot=realpath((string)($_SERVER['DOCUMENT_ROOT']??''));$dir=realpath(__DIR__);
    if($docRoot&&$dir&&strpos($dir,$docRoot)===0)return '/'.trim(str_replace('\\','/',substr($dir,strlen($docRoot))),'/');
    return 'modules/DMD-Infra-IT';
}
$baseUrl=dmdi_cfg_base_url();$uid='dmdi_cfg_'.substr(bin2hex(random_bytes(5)),0,10);
?>
<link rel="stylesheet" href="<?= dmdi_h($baseUrl) ?>/DMD-Infra-IT.css?v=1.2.0">
<section id="<?= dmdi_h($uid) ?>" class="dmdi-config" data-api="<?= dmdi_h($baseUrl) ?>/DMD-Infra-IT_api.php" data-render="<?= dmdi_h($baseUrl) ?>/DMD-Infra-IT_render.php" data-dmd-module-id="DMD-Infra-IT" data-dmd-module-name="DMD-Infra-IT">
  <header class="dmdi-cfg-head">
    <div><h2 class="dmdi-title">DMD-Infra-IT — Configuration</h2><p class="dmdi-subtitle">Fiches réseau, partage, journal et droits DoMyDesk 1.2.0</p></div>
    <div class="dmdi-toolbar-actions" data-top-actions></div>
  </header>
  <div class="dmdi-cfg-layout">
    <aside class="dmdi-cfg-side">
      <div class="dmdi-side-actions" data-side-actions></div>
      <div class="dmdi-doc-list" data-doc-list><div class="dmdi-empty">Chargement…</div></div>
    </aside>
    <div class="dmdi-cfg-main">
      <nav class="dmdi-tabs" data-tabs></nav>
      <div data-editor><div class="dmdi-empty">Chargement de la configuration…</div></div>
      <div class="dmdi-cfg-bottom"><div class="dmdi-message" data-message aria-live="polite"></div><div class="dmdi-toolbar-actions" data-bottom-actions></div></div>
    </div>
  </div>
</section>
<script>
(() => {
  const root=document.getElementById(<?= json_encode($uid) ?>); if(!root || root.dataset.bound==='1')return; root.dataset.bound='1';
  const api=root.dataset.api, renderUrl=root.dataset.render;
  const $=(s,p=root)=>p.querySelector(s), $$=(s,p=root)=>Array.from(p.querySelectorAll(s));
  const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const clone=v=>JSON.parse(JSON.stringify(v));
  const DEFAULT={moduleName:'Infra',header:{title:'Infrastructure',description:'',site:'',owner:'',color:'',dateMode:'auto',fixedDate:''},internet:[],firewalls:[],vlans:[],switches:[],devices:[]};
  const st={csrf:'',docs:[],users:[],perms:{},doc:null,summary:null,tab:'general',logs:[]};
  function msg(t,kind=''){const e=$('[data-message]');e.textContent=t||'';e.dataset.kind=kind;}
  function emitActivity(ev){if(!ev)return;try{window.dispatchEvent(new CustomEvent('dmd:resource-activity',{detail:ev}));}catch(_){} }
  async function call(action,payload={},method='POST'){
    const opt={credentials:'same-origin',cache:'no-store'}; let url=api+'?action='+encodeURIComponent(action);
    if(method==='GET'){const q=new URLSearchParams(payload);if([...q].length)url+='&'+q.toString();opt.method='GET';}
    else {opt.method='POST';opt.headers={'Content-Type':'application/json','Accept':'application/json'};opt.body=JSON.stringify(Object.assign({action,csrf:st.csrf},payload));}
    const r=await fetch(url,opt), txt=await r.text(); let j; try{j=JSON.parse(txt)}catch(e){throw new Error('Réponse API invalide.');}
    if(!r.ok||!j.ok)throw new Error(j.message||'Erreur API'); return j;
  }
  function field(label,key,obj,placeholder='',col=3,type='text'){
    return `<div class="dmdi-field dmdi-col-${col}"><label>${esc(label)}</label><input type="${esc(type)}" data-key="${esc(key)}" value="${esc(obj?.[key]??'')}" placeholder="${esc(placeholder)}"></div>`;
  }
  function colorField(label,key,obj,col=3){
    const raw=String(obj?.[key]??'');
    const valid=/^#[0-9a-f]{6}$/i.test(raw);
    return `<div class="dmdi-field dmdi-col-${col}"><label>${esc(label)}</label><div class="dmdi-color-control"><input class="dmdi-color-picker" type="color" data-color-key="${esc(key)}" value="${valid?esc(raw):'#000000'}" title="Choisir une couleur"><span class="dmdi-color-value" data-color-value>${valid?esc(raw):'Aucune'}</span><button type="button" class="dmdi-btn dmdi-color-clear" data-color-clear="${esc(key)}">Effacer</button></div></div>`;
  }
  function textarea(label,key,obj,placeholder='',col=12){return `<div class="dmdi-field dmdi-col-${col}"><label>${esc(label)}</label><textarea data-key="${esc(key)}" placeholder="${esc(placeholder)}">${esc(obj?.[key]??'')}</textarea></div>`;}
  function selectField(label,key,obj,options,col=3){return `<div class="dmdi-field dmdi-col-${col}"><label>${esc(label)}</label><select data-key="${esc(key)}">${options}</select></div>`;}
  function options(values,current,empty='—'){return `<option value="">${esc(empty)}</option>`+values.map(v=>`<option value="${esc(v.value)}" ${String(v.value)===String(current??'')?'selected':''}>${esc(v.label)}</option>`).join('');}
  function bind(container,obj){
    $$('[data-key]',container).forEach(el=>{const fn=()=>{obj[el.dataset.key]=el.value;};el.addEventListener('input',fn);el.addEventListener('change',fn);});
    $$('[data-color-key]',container).forEach(el=>{
      const fn=()=>{obj[el.dataset.colorKey]=el.value;const wrap=el.closest('.dmdi-color-control');const value=wrap&&$('[data-color-value]',wrap);if(value)value.textContent=el.value;};
      el.addEventListener('input',fn);el.addEventListener('change',fn);
    });
    $$('[data-color-clear]',container).forEach(btn=>btn.addEventListener('click',()=>{
      const key=btn.dataset.colorClear;obj[key]='';const wrap=btn.closest('.dmdi-color-control');const value=wrap&&$('[data-color-value]',wrap);if(value)value.textContent='Aucune';
    }));
  }
  function ensureData(){if(!st.doc)return;const d=st.doc.data||(st.doc.data=clone(DEFAULT));for(const k of ['internet','firewalls','vlans','switches','devices'])if(!Array.isArray(d[k]))d[k]=[];d.header=d.header&&typeof d.header==='object'?d.header:clone(DEFAULT.header);}
  function vlanOpts(cur){ensureData();return options((st.doc?.data?.vlans||[]).map(v=>({value:v.id??'',label:`VLAN ${v.id??''}${v.name?' — '+v.name:''}`})),cur,'Aucun');}
  function switchOpts(cur){ensureData();return options((st.doc?.data?.switches||[]).map(v=>({value:v.name??'',label:v.name||'Switch'})),cur,'Aucun');}
  function internetOpts(cur){ensureData();return options((st.doc?.data?.internet||[]).map(v=>({value:v.name??'',label:v.name||v.operator||'Internet'})),cur,'Aucune');}
  function item(title,body,del=true){return `<div class="dmdi-item"><div class="dmdi-item-head"><div class="dmdi-item-title">${esc(title)}</div>${del?'<button type="button" class="dmdi-btn dmdi-btn-danger" data-del>Supprimer</button>':''}</div>${body}</div>`;}

  function renderDocs(){
    const c=$('[data-doc-list]'); if(!st.docs.length){c.innerHTML='<div class="dmdi-empty">Aucune infrastructure accessible.</div>';return;}
    c.innerHTML=st.docs.map(d=>`<button type="button" class="dmdi-doc-select ${st.doc&&d.id===st.doc.id&&d.owner===st.doc.owner?'is-active':''}" data-open-doc data-owner="${esc(d.owner)}" data-id="${esc(d.id)}"><strong>${esc(d.title)}</strong><small>${d.shared?'Partagée par '+esc(d.owner):esc(d.site||d.owner)} · ${esc((d.updated_at||'').slice(0,10))}</small></button>`).join('');
  }
  function tabs(){
    const base=[['general','Général'],['internet','Internet'],['firewalls','Firewalls'],['vlans','VLANs'],['switches','Switchs / ports'],['devices','Périphériques']];
    if(st.doc&&st.summary?.permissions?.share)base.push(['sharing','Partage']); if(st.perms.logs_view)base.push(['logs','Journal']);
    if(!base.some(x=>x[0]===st.tab))st.tab=base[0][0];
    $('[data-tabs]').innerHTML=base.map(([id,l])=>`<button type="button" class="dmdi-tab ${st.tab===id?'is-active':''}" data-tab="${id}">${esc(l)}</button>`).join('');
  }
  function renderGeneral(){ensureData();const h=st.doc.data.header;return `<div class="dmdi-panel"><div class="dmdi-panel-head"><h3>Fiche infrastructure</h3></div><div class="dmdi-panel-body"><div class="dmdi-form-grid">${field('Titre','title',h,'Infrastructure principale',6)}${field('Site / lieu','site',h,'Maison, bureau, client…',3)}${field('Référent','owner',h,'Nom / service',3)}${colorField('Repère couleur','color',h,3)}${selectField('Date du rapport','dateMode',h,`<option value="auto" ${h.dateMode==='auto'?'selected':''}>Automatique</option><option value="fixed" ${h.dateMode==='fixed'?'selected':''}>Date fixe</option>`,3)}${field('Date fixe','fixedDate',h,'JJ/MM/AAAA',3)}${textarea('Description','description',h,'Objectif, contexte, remarques…',12)}</div></div></div>`;}
  function renderGeneric(key,title,make,defaults){ensureData();const arr=st.doc.data[key];return `<div class="dmdi-panel"><div class="dmdi-panel-head"><h3>${esc(title)}</h3><button type="button" class="dmdi-btn dmdi-btn-primary" data-add="${key}">+ Ajouter</button></div><div class="dmdi-panel-body"><div class="dmdi-list">${arr.map((o,i)=>item(make.title(o,i),`<div class="dmdi-form-grid" data-bind-item="${i}">${make.body(o,i)}</div>`)).join('')||'<div class="dmdi-muted">Aucune entrée.</div>'}</div></div></div>`;}
  const generic={
    internet:{title:'Connexions internet',defaults:{name:'',operator:'',type:'',status:'',public_ip:'',bandwidth:'',note:''},make:{title:o=>o.name||o.operator||'Connexion internet',body:o=>field('Nom','name',o,'WAN principal',3)+field('Opérateur','operator',o,'Opérateur',3)+field('Type','type',o,'Fibre, 4G, Starlink…',2)+field('Statut','status',o,'Actif / secours',2)+field('IP publique','public_ip',o,'x.x.x.x',2)+field('Débit / usage','bandwidth',o,'1 Gb/s, backup…',4)+textarea('Note','note',o,'Informations utiles',8)}},
    firewalls:{title:'Firewalls',defaults:{name:'',vendor_model:'',role:'',wan_ip:'',lan_ip:'',mgmt_vlan:'',internet:'',note:''},make:{title:o=>o.name||'Firewall',body:o=>field('Nom firewall','name',o,'Firewall principal',3)+field('Marque / modèle','vendor_model',o,'pfSense, Fortigate…',3)+field('Rôle','role',o,'Edge, VPN, filtrage…',3)+selectField('VLAN management','mgmt_vlan',o,vlanOpts(o.mgmt_vlan),3)+field('IP WAN','wan_ip',o,'',3)+field('IP LAN / Admin','lan_ip',o,'',3)+selectField('Connexion associée','internet',o,internetOpts(o.internet),3)+textarea('Note','note',o,'Règles, VPN, NAT…',12)}},
    vlans:{title:'VLANs centralisés',defaults:{id:'',name:'',cidr:'',gateway:'',color:'',description:''},make:{title:o=>(o.id?'VLAN '+o.id+' — ':'')+(o.name||'VLAN'),body:o=>field('ID VLAN','id',o,'101',2)+field('Nom','name',o,'LAN, IoT, Invités…',3)+field('CIDR','cidr',o,'192.168.101.0/24',3)+field('Gateway','gateway',o,'192.168.101.1',2)+colorField('Repère couleur','color',o,2)+textarea('Description','description',o,'Usage du VLAN',12)}},
    devices:{title:'Périphériques / plan réseau',defaults:{name:'',type:'',ip:'',vlan:'',switch:'',port:'',description:''},make:{title:o=>o.name||'Périphérique',body:o=>field('Nom','name',o,'NAS, AP Salon…',3)+field('Type','type',o,'Serveur, Wi-Fi, caméra…',2)+field('IP','ip',o,'',2)+selectField('VLAN','vlan',o,vlanOpts(o.vlan),2)+selectField('Switch','switch',o,switchOpts(o.switch),2)+field('Port','port',o,'',1)+textarea('Description','description',o,'Usage, remarques…',12)}}
  };
  function renderSwitches(){ensureData();const a=st.doc.data.switches;return `<div class="dmdi-panel"><div class="dmdi-panel-head"><h3>Switchs et ports</h3><button type="button" class="dmdi-btn dmdi-btn-primary" data-add-switch>+ Switch</button></div><div class="dmdi-panel-body"><div class="dmdi-list">${a.map((sw,i)=>{sw.ports=Array.isArray(sw.ports)?sw.ports:[];return `<div class="dmdi-item" data-switch="${i}"><div class="dmdi-item-head"><div class="dmdi-item-title">${esc(sw.name||'Switch')}</div><button type="button" class="dmdi-btn dmdi-btn-danger" data-del-switch>Supprimer</button></div><div class="dmdi-form-grid" data-switch-fields>${field('Nom','name',sw,'Switch principal',3)}${field('Modèle','model',sw,'',3)}${field('Lieu','location',sw,'Baie réseau',2)}${field('IP management','mgmt_ip',sw,'',2)}${selectField('VLAN management','mgmt_vlan',sw,vlanOpts(sw.mgmt_vlan),2)}${field('Uplink','uplink',sw,'Firewall / switch amont',12)}</div><div class="dmdi-item-head"><div class="dmdi-item-title">Ports</div><button type="button" class="dmdi-btn" data-add-port>+ Port</button></div><div class="dmdi-port-list">${sw.ports.map((p,pi)=>`<div class="dmdi-port" data-port="${pi}"><div class="dmdi-form-grid">${field('Port','port',p,'1, Gi1/0/1…',2)}${selectField('Mode','mode',p,`<option value="access" ${p.mode==='access'?'selected':''}>Access</option><option value="trunk" ${p.mode==='trunk'?'selected':''}>Trunk</option><option value="lag" ${p.mode==='lag'?'selected':''}>LAG</option>`,2)}${selectField('VLAN','vlan',p,vlanOpts(p.vlan),3)}${field('Description','description',p,'Destination / usage',4)}<div class="dmdi-field dmdi-col-1"><label>Action</label><button type="button" class="dmdi-btn dmdi-btn-danger" data-del-port>✕</button></div></div></div>`).join('')||'<div class="dmdi-muted">Aucun port documenté.</div>'}</div></div>`}).join('')||'<div class="dmdi-muted">Aucun switch documenté.</div>'}</div></div></div>`;}
  function shareUserOptions(current=''){
    const cur=String(current||'').toLowerCase();
    let html='<option value="">Sélectionner un utilisateur…</option>';
    for(const u of st.users){const email=String(u.email||'');const selected=email.toLowerCase()===cur?'selected':'';html+=`<option value="${esc(email)}" ${selected}>${esc(u.label||email)}</option>`;}
    return html;
  }
  function renderSharing(){
    const acl=Array.isArray(st.doc?.acl)?st.doc.acl:[];
    const noUsers=!st.users.length;
    return `<div class="dmdi-panel"><div class="dmdi-panel-head"><h3>Partage de cette infrastructure</h3><button type="button" class="dmdi-btn dmdi-btn-primary" data-add-share ${noUsers?'disabled':''}>+ Utilisateur</button></div><div class="dmdi-panel-body"><p class="dmdi-muted">Les utilisateurs viennent directement des dossiers <code>users/profiles/&lt;adresse-email&gt;/</code>. Aucune saisie libre. Lecture est toujours incluse ; édition et export sont accordés séparément.</p>${noUsers?'<div class="dmdi-empty">Aucun autre dossier utilisateur valide trouvé dans users/profiles/.</div>':`<div class="dmdi-share-list">${acl.map((r,i)=>`<div class="dmdi-share-row" data-share="${i}"><select class="dmdi-share-user" data-share-user>${shareUserOptions(r.email||'')}</select><label class="dmdi-check"><input type="checkbox" data-share-edit ${(r.permissions||[]).includes('edit')?'checked':''}> Édition</label><label class="dmdi-check"><input type="checkbox" data-share-export ${(r.permissions||[]).includes('export')?'checked':''}> Export</label><button type="button" class="dmdi-btn dmdi-btn-danger" data-del-share>Retirer</button></div>`).join('')||'<div class="dmdi-muted">Aucun partage.</div>'}</div>`}</div></div>`;
  }
  function renderLogs(){return `<div class="dmdi-panel"><div class="dmdi-panel-head"><h3>Journal DMD-Infra-IT</h3></div><div class="dmdi-panel-body"><div class="dmdi-log-tools"><button type="button" class="dmdi-btn" data-refresh-logs>Actualiser</button>${st.perms.logs_export?'<button type="button" class="dmdi-btn" data-export-logs>Exporter JSON</button>':''}${st.perms.logs_delete?'<button type="button" class="dmdi-btn dmdi-btn-danger" data-clear-logs>Vider le journal</button>':''}</div><div class="dmdi-log-wrap"><table class="dmdi-log-table"><thead><tr><th>Date</th><th>Utilisateur</th><th>Action</th><th>Cible</th><th>Résultat</th><th>Détails</th></tr></thead><tbody>${st.logs.map(r=>`<tr><td>${esc(r.timestamp||'')}</td><td>${esc(r.user||'')}</td><td>${esc(r.action||'')}</td><td><code>${esc(r.target||'')}</code></td><td>${esc(r.result||'')}</td><td>${esc(r.details||'')}</td></tr>`).join('')||'<tr><td colspan="6">Aucune entrée chargée.</td></tr>'}</tbody></table></div></div></div>`;}

  function renderEditor(){
    tabs(); const e=$('[data-editor]');
    if(st.tab==='logs'){e.innerHTML=renderLogs();bindActions();return;}
    if(!st.doc){e.innerHTML='<div class="dmdi-empty">Sélectionne ou crée une infrastructure.</div>';bindActions();return;}
    ensureData(); let html='';
    if(st.tab==='general')html=renderGeneral();
    else if(generic[st.tab])html=renderGeneric(st.tab,generic[st.tab].title,generic[st.tab].make,generic[st.tab].defaults);
    else if(st.tab==='switches')html=renderSwitches();
    else if(st.tab==='sharing')html=renderSharing();
    e.innerHTML=html; bindEditor(); bindActions();
  }
  function renderTopActions(){
    const top=$('[data-top-actions]'), side=$('[data-side-actions]'), bottom=$('[data-bottom-actions]');
    top.innerHTML='';side.innerHTML=st.perms.create?'<button type="button" class="dmdi-btn dmdi-btn-primary" data-new>+ Nouvelle</button>':'';
    if(st.doc){
      const p=st.summary?.permissions||{};
      top.innerHTML=`<button type="button" class="dmdi-btn" data-preview>Ouvrir le rapport</button>${p.export?'<button type="button" class="dmdi-btn" data-print>PDF / imprimer</button>':''}`;
      const saveButton=(st.tab!=='sharing'&&st.tab!=='logs'&&p.edit)?'<button type="button" class="dmdi-btn dmdi-btn-primary" data-save>Enregistrer</button>':'';
      const shareButton=(st.tab==='sharing'&&p.share)?'<button type="button" class="dmdi-btn" data-save-share>Enregistrer les partages</button>':'';
      const deleteButton=(st.tab!=='logs'&&p.delete)?'<button type="button" class="dmdi-btn dmdi-btn-danger" data-delete>Supprimer</button>':'';
      bottom.innerHTML=saveButton+shareButton+deleteButton;
    } else bottom.innerHTML='';
  }
  function renderAll(){renderDocs();renderTopActions();renderEditor();}
  function bindEditor(){
    if(!st.doc)return;ensureData(); const e=$('[data-editor]');
    if(st.tab==='general')bind(e,st.doc.data.header);
    if(generic[st.tab]){$$('[data-bind-item]',e).forEach(n=>bind(n,st.doc.data[st.tab][Number(n.dataset.bindItem)]));}
    if(st.tab==='switches'){$$('[data-switch]',e).forEach(n=>{const sw=st.doc.data.switches[Number(n.dataset.switch)];bind($('[data-switch-fields]',n),sw);$$('[data-port]',n).forEach(p=>bind(p,sw.ports[Number(p.dataset.port)]));});}
    if(st.tab==='sharing'){$$('[data-share]',e).forEach(n=>{const r=st.doc.acl[Number(n.dataset.share)];$('[data-share-user]',n).addEventListener('change',x=>r.email=x.target.value);$('[data-share-edit]',n).addEventListener('change',()=>syncShare(n,r));$('[data-share-export]',n).addEventListener('change',()=>syncShare(n,r));});}
    const editable=!!(st.summary&&st.summary.permissions&&st.summary.permissions.edit);
    if(!editable && st.tab!=='sharing' && st.tab!=='logs') {
      $$('input,select,textarea,button[data-add],button[data-del],button[data-add-switch],button[data-del-switch],button[data-add-port],button[data-del-port]',e).forEach(n=>n.disabled=true);
    }
  }
  function syncShare(n,r){r.permissions=['view'];if($('[data-share-edit]',n).checked)r.permissions.push('edit');if($('[data-share-export]',n).checked)r.permissions.push('export');}
  function bindActions(){
    const e=$('[data-editor]');
    $$('[data-add]',e).forEach(b=>b.onclick=()=>{const k=b.dataset.add;st.doc.data[k].push(clone(generic[k].defaults));renderEditor();});
    $$('[data-bind-item]',e).forEach(n=>{const parent=n.closest('.dmdi-item'),idx=Number(n.dataset.bindItem);const del=$('[data-del]',parent);if(del)del.onclick=()=>{st.doc.data[st.tab].splice(idx,1);renderEditor();};});
    const as=$('[data-add-switch]',e);if(as)as.onclick=()=>{st.doc.data.switches.push({name:'',model:'',location:'',mgmt_ip:'',mgmt_vlan:'',uplink:'',ports:[]});renderEditor();};
    $$('[data-switch]',e).forEach(n=>{const i=Number(n.dataset.switch),sw=st.doc.data.switches[i];const ds=$('[data-del-switch]',n);if(ds)ds.onclick=()=>{st.doc.data.switches.splice(i,1);renderEditor();};const ap=$('[data-add-port]',n);if(ap)ap.onclick=()=>{sw.ports.push({port:'',mode:'access',vlan:'',description:''});renderEditor();};$$('[data-port]',n).forEach(p=>{const pi=Number(p.dataset.port),dp=$('[data-del-port]',p);if(dp)dp.onclick=()=>{sw.ports.splice(pi,1);renderEditor();};});});
    const addShare=$('[data-add-share]',e);if(addShare)addShare.onclick=()=>{st.doc.acl=Array.isArray(st.doc.acl)?st.doc.acl:[];st.doc.acl.push({email:'',permissions:['view']});renderEditor();};
    $$('[data-share]',e).forEach(n=>{const i=Number(n.dataset.share),d=$('[data-del-share]',n);if(d)d.onclick=()=>{st.doc.acl.splice(i,1);renderEditor();};});
    const rl=$('[data-refresh-logs]',e);if(rl)rl.onclick=loadLogs;const xl=$('[data-export-logs]',e);if(xl)xl.onclick=()=>{window.location.href=api+'?action=logs_export';};const cl=$('[data-clear-logs]',e);if(cl)cl.onclick=clearLogs;
  }
  async function bootstrap(){try{const j=await call('bootstrap',{},'GET');st.csrf=j.csrf;st.docs=j.documents||[];st.users=j.users||[];st.perms=j.permissions||{};renderAll();if(st.docs.length)await loadDoc(st.docs[0].owner,st.docs[0].id);else if(st.perms.logs_view){st.tab='logs';renderAll();}}catch(e){msg(e.message,'error');$('[data-editor]').innerHTML='<div class="dmdi-empty">'+esc(e.message)+'</div>';}}
  async function refreshList(selectOwner='',selectId=''){const j=await call('bootstrap',{},'GET');st.csrf=j.csrf;st.docs=j.documents||[];st.users=j.users||st.users;st.perms=j.permissions||st.perms;if(selectId){const x=st.docs.find(d=>d.id===selectId&&d.owner===selectOwner);if(x)st.summary=x;}renderDocs();renderTopActions();}
  async function loadDoc(owner,id){try{const j=await call('get',{owner,id},'GET');st.doc=j.doc;st.summary=j.summary;renderAll();}catch(e){msg(e.message,'error');}}
  async function createDoc(){try{const j=await call('create',{data:clone(DEFAULT)});st.doc=j.doc;st.summary=j.summary;emitActivity(j.activity_event);await refreshList(j.doc.owner,j.doc.id);renderAll();msg('Infrastructure créée.','success');}catch(e){msg(e.message,'error');}}
  async function saveDoc(){if(!st.doc)return;try{const j=await call('save',{owner:st.doc.owner,id:st.doc.id,data:st.doc.data});st.doc=j.doc;st.summary=j.summary;emitActivity(j.activity_event);await refreshList(j.doc.owner,j.doc.id);renderAll();msg('Infrastructure enregistrée.','success');}catch(e){msg(e.message,'error');}}
  async function saveShare(){if(!st.doc)return;try{const j=await call('share',{owner:st.doc.owner,id:st.doc.id,acl:st.doc.acl||[]});st.doc=j.doc;st.summary=j.summary;emitActivity(j.activity_event);await refreshList(j.doc.owner,j.doc.id);renderAll();msg('Partages enregistrés.','success');}catch(e){msg(e.message,'error');}}
  async function deleteDoc(){if(!st.doc||!confirm('Supprimer définitivement cette infrastructure ?'))return;try{const o=st.doc.owner,id=st.doc.id,j=await call('delete',{owner:o,id});emitActivity(j.activity_event);st.doc=null;st.summary=null;await refreshList();renderAll();if(st.docs.length)await loadDoc(st.docs[0].owner,st.docs[0].id);msg('Infrastructure supprimée.','success');}catch(e){msg(e.message,'error');}}
  async function loadLogs(){try{const j=await call('logs',{limit:200},'GET');st.logs=j.rows||[];renderEditor();}catch(e){msg(e.message,'error');}}
  async function clearLogs(){if(!confirm('Vider le journal DMD-Infra-IT ?'))return;try{await call('logs_clear',{});await loadLogs();msg('Journal vidé.','success');}catch(e){msg(e.message,'error');}}
  function openReport(print=false){
    if(!st.doc)return;
    const owner=st.doc.owner,id=st.doc.id,title=st.doc.title||'Infrastructure';
    const win=document.createElement('section');win.className='dmdi-window';win.dataset.dmdiWindow='1';
    const n=document.querySelectorAll('.dmdi-window[data-dmdi-window="1"]').length;
    win.style.left=(80+n*22+window.scrollX)+'px';win.style.top=(80+n*22+window.scrollY)+'px';
    win.innerHTML=`<header class="dmdi-window-head"><div class="dmdi-window-title"><strong>${esc(title)}</strong><small>${esc(owner)}</small></div><div class="dmdi-window-actions"><button type="button" class="dmdi-btn" data-local-close>✕</button></div></header><div class="dmdi-window-body"><iframe class="dmdi-window-frame" title="${esc(title)}"></iframe></div>`;
    document.body.appendChild(win);const frame=$('iframe',win);const u=`${renderUrl}?owner=${encodeURIComponent(owner)}&doc=${encodeURIComponent(id)}&embed=1${print?'&print=1':''}`;frame.src=u;
    let z=Number(window.__DMDInfraITZ||5200)+1;window.__DMDInfraITZ=z;win.style.zIndex=String(z);
    let drag=null;const head=$('.dmdi-window-head',win);head.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;const r=win.getBoundingClientRect();drag={x:e.clientX,y:e.clientY,l:r.left+window.scrollX,t:r.top+window.scrollY};head.setPointerCapture(e.pointerId);});head.addEventListener('pointermove',e=>{if(!drag)return;win.style.left=Math.max(0,drag.l+e.clientX-drag.x)+'px';win.style.top=Math.max(0,drag.t+e.clientY-drag.y)+'px';});head.addEventListener('pointerup',()=>drag=null);win.addEventListener('pointerdown',()=>{z=Number(window.__DMDInfraITZ||z)+1;window.__DMDInfraITZ=z;win.style.zIndex=String(z);});$('[data-local-close]',win).onclick=()=>win.remove();
    if(print)frame.addEventListener('load',()=>{try{frame.contentWindow.focus();frame.contentWindow.print();}catch(_){msg('Impression bloquée par le navigateur.','error');}},{once:true});
  }
  root.addEventListener('click',e=>{
    const d=e.target.closest('[data-open-doc]');if(d){loadDoc(d.dataset.owner,d.dataset.id);return;}
    const t=e.target.closest('[data-tab]');if(t){st.tab=t.dataset.tab;renderTopActions();renderEditor();if(st.tab==='logs'&&!st.logs.length)loadLogs();return;}
    if(e.target.closest('[data-new]'))createDoc();if(e.target.closest('[data-save]'))saveDoc();if(e.target.closest('[data-save-share]'))saveShare();if(e.target.closest('[data-delete]'))deleteDoc();if(e.target.closest('[data-preview]'))openReport(false);if(e.target.closest('[data-print]'))openReport(true);
  });
  bootstrap();
})();
</script>
