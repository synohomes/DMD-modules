<?php
if (!defined('DMDI_MODULE_ID')) define('DMDI_MODULE_ID', 'DMD-Infra-IT');
if (!defined('DMDI_MODULE_NAME')) define('DMDI_MODULE_NAME', 'DMD-Infra-IT');

function dmdi_module_root() {
    /*
     * Contrat DoMyDesk 1.2.0 : le module est dans
     * <DMD_ROOT>/modules/DMD-Infra-IT/.
     * On part donc du dossier du module, sans deviner la racine depuis l'URL.
     */
    return dirname(__DIR__, 2);
}
function dmdi_root() {
    if (defined('DMD_ROOT')) {
        return rtrim((string)DMD_ROOT, '/\\');
    }
    return dmdi_module_root();
}
function dmdi_boot_core() {
    /*
     * IMPORTANT : charger d'abord le Core depuis la position physique du module.
     * core/dmd_permissions.php définit lui-même DMD_ROOT = dirname(__DIR__).
     */
    $moduleRoot = dmdi_module_root();
    $permissions = $moduleRoot . '/core/dmd_permissions.php';
    if (is_file($permissions)) require_once $permissions;

    $root = defined('DMD_ROOT') ? rtrim((string)DMD_ROOT, '/\\') : $moduleRoot;
    foreach (array(
        $root . '/core/dmd_system_services.php',
        $root . '/core/dmd_quick_session.php'
    ) as $file) {
        if (is_file($file)) require_once $file;
    }
}
dmdi_boot_core();

function dmdi_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function dmdi_email() {
    return trim((string)($_SESSION['user']['email'] ?? $_SESSION['email'] ?? $_SESSION['user_email'] ?? ''));
}
function dmdi_safe_email($email) { return preg_replace('~[^a-zA-Z0-9@._+-]~', '_', (string)$email); }
function dmdi_profiles_root() {
    /* Source unique : exactement la même que le Core DoMyDesk 1.2.0. */
    $root = defined('DMD_ROOT') ? rtrim((string)DMD_ROOT, '/\\') : dmdi_module_root();
    return $root . '/users/profiles';
}
function dmdi_profile_users() {
    /*
     * Ne lit AUCUN profile.json.
     * Un utilisateur partageable = un dossier physique présent directement dans
     * DMD_ROOT/users/profiles/. Le nom du dossier est l'identifiant utilisateur.
     */
    $out = array();
    $root = dmdi_profiles_root();
    clearstatcache(true, $root);
    if (!is_dir($root)) return $out;

    $entries = @scandir($root);
    if (!is_array($entries)) $entries = array();

    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..' || $entry === '') continue;
        $path = $root . '/' . $entry;
        if (!is_dir($path)) continue;

        /* Même règle de sûreté que le Core quand elle est disponible. */
        if (function_exists('dmd_safe_user_key')) {
            $safe = dmd_safe_user_key($entry);
            if ($safe === '') continue;
            $entry = $safe;
        } else {
            if (strpos($entry, '..') !== false || strpos($entry, '/') !== false || strpos($entry, '\\') !== false || basename($entry) !== $entry) continue;
        }

        $out[strtolower($entry)] = $entry;
    }

    /* Fallback très simple si scandir est désactivé mais glob autorisé. */
    if (!$out) {
        foreach (glob(rtrim($root, '/\\') . '/*', GLOB_ONLYDIR) ?: array() as $path) {
            $entry = basename((string)$path);
            if ($entry === '') continue;
            if (function_exists('dmd_safe_user_key') && dmd_safe_user_key($entry) === '') continue;
            $out[strtolower($entry)] = $entry;
        }
    }

    ksort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return $out;
}
function dmdi_profile_email_exists($email) {
    $email = strtolower(trim((string)$email));
    if ($email === '') return false;
    $users = dmdi_profile_users();
    return isset($users[$email]);
}
function dmdi_profile_dir_name($email) {
    $email = strtolower(trim((string)$email));
    $users = dmdi_profile_users();
    return isset($users[$email]) ? $users[$email] : dmdi_safe_email($email);
}
function dmdi_share_users($excludeEmail = '') {
    $excludeEmail = strtolower(trim((string)$excludeEmail));
    $out = array();
    foreach (dmdi_profile_users() as $lower => $dirName) {
        if ($lower === $excludeEmail) continue;
        $out[] = array('email'=>$dirName, 'label'=>$dirName);
    }
    return $out;
}
function dmdi_is_admin() {
    $a = strtolower((string)($_SESSION['user']['role_system'] ?? $_SESSION['role_system'] ?? ''));
    $b = strtolower((string)($_SESSION['user']['role'] ?? $_SESSION['role'] ?? ''));
    return in_array($a, array('admin','administrator','superadmin'), true) || in_array($b, array('admin','administrator','superadmin'), true);
}
function dmdi_has_permission($permission) {
    if (function_exists('dmd_current_user_has_module_permission')) {
        return (bool)dmd_current_user_has_module_permission(DMDI_MODULE_ID, (string)$permission);
    }
    return dmdi_email() !== '' && ($permission === 'module.view' || $permission === 'use' || dmdi_is_admin());
}
function dmdi_require_permission($permission) {
    if (function_exists('dmd_require_module_access')) {
        dmd_require_module_access(DMDI_MODULE_ID, (string)$permission);
        return;
    }
    if (!dmdi_has_permission($permission)) {
        http_response_code(403);
        throw new RuntimeException('Permission refusée : ' . $permission);
    }
}
function dmdi_json_read($file, $fallback) {
    if (!is_file($file)) return $fallback;
    $raw = @file_get_contents($file);
    $data = json_decode((string)$raw, true);
    return json_last_error() === JSON_ERROR_NONE ? $data : $fallback;
}
function dmdi_json_write($file, $data) {
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) return false;
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    $tmp = $file . '.tmp-' . bin2hex(random_bytes(3));
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    if (@rename($tmp, $file)) return true;
    @unlink($tmp);
    return @file_put_contents($file, $json, LOCK_EX) !== false;
}
function dmdi_user_dir($email) { return dmdi_profiles_root() . '/' . dmdi_profile_dir_name($email) . '/DMD-Infra-IT'; }
function dmdi_docs_file($email) { return dmdi_user_dir($email) . '/infra_docs.json'; }
function dmdi_refs_file($email) { return dmdi_user_dir($email) . '/shared_refs.json'; }
function dmdi_legacy_user_dirs($email) {
    $base = dmdi_profiles_root() . '/' . dmdi_profile_dir_name($email);
    return array($base . '/dmd-infra-it', $base . '/infra');
}
function dmdi_runtime_dir() { return dmdi_root() . '/data/modules/DMD-Infra-IT'; }
function dmdi_legacy_runtime_dir() { return dmdi_root() . '/data/modules/dmd-infra-it'; }
function dmdi_log_file() { return dmdi_runtime_dir() . '/logs/events.jsonl'; }
function dmdi_activity_file() { return dmdi_runtime_dir() . '/activity/events.jsonl'; }
function dmdi_copy_if_missing($source, $target) {
    if (is_file($target) || !is_file($source)) return;
    $dir = dirname($target);
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    @copy($source, $target);
}
function dmdi_ensure_runtime() {
    /* Compatibilité avec le premier paquet 1.2.0 qui utilisait par erreur l'ID en minuscules. */
    dmdi_copy_if_missing(dmdi_legacy_runtime_dir() . '/logs/events.jsonl', dmdi_log_file());
    dmdi_copy_if_missing(dmdi_legacy_runtime_dir() . '/activity/events.jsonl', dmdi_activity_file());
    foreach (array(dirname(dmdi_log_file()), dirname(dmdi_activity_file())) as $dir) {
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        $ht = $dir . '/.htaccess';
        if (!is_file($ht)) @file_put_contents($ht, "Require all denied\nOptions -Indexes\n");
    }
}
function dmdi_default_data() {
    return array(
        'moduleName' => 'DMD-Infra-IT',
        'header' => array('title'=>'Infrastructure','description'=>'','site'=>'','owner'=>'','color'=>'','dateMode'=>'auto','fixedDate'=>''),
        'internet' => array(),
        'firewalls' => array(),
        'vlans' => array(),
        'switches' => array(),
        'devices' => array()
    );
}
function dmdi_is_list($a) { return is_array($a) && ($a === array() || array_keys($a) === range(0, count($a)-1)); }
function dmdi_merge($a, $b) {
    if (!is_array($a)) return $b !== null ? $b : $a;
    if (!is_array($b)) return $a;
    if (dmdi_is_list($a) || dmdi_is_list($b)) return $b;
    foreach ($b as $k=>$v) $a[$k] = dmdi_merge(isset($a[$k]) ? $a[$k] : null, $v);
    return $a;
}
function dmdi_migrate_data($raw) {
    $raw = is_array($raw) ? $raw : array();
    $d = dmdi_merge(dmdi_default_data(), $raw);
    if (empty($d['vlans']) && !empty($raw['legend']) && is_array($raw['legend'])) {
        $d['vlans'] = array();
        foreach ($raw['legend'] as $l) {
            $label = $l['label'] ?? ($l['text'] ?? ''); $class = $l['class'] ?? ''; $id = '';
            if (preg_match('~(\d{1,4})~', (string)$class, $m)) $id = $m[1];
            elseif (preg_match('~(\d{1,4})~', (string)$label, $m)) $id = $m[1];
            if ($label !== '') $d['vlans'][] = array('id'=>$id,'name'=>$label,'cidr'=>'','gateway'=>'','color'=>$l['color'] ?? '','description'=>'');
        }
    }
    if (!empty($raw['addressPlan']) && is_array($raw['addressPlan'])) {
        foreach ($raw['addressPlan'] as $r) {
            $id = preg_replace('~\D+~', '', (string)($r['vlan'] ?? '')); if ($id === '') continue;
            $found = false;
            foreach ($d['vlans'] as &$v) {
                if ((string)($v['id'] ?? '') === $id) {
                    $found = true;
                    if (empty($v['cidr'])) $v['cidr'] = $r['subnet'] ?? '';
                    if (empty($v['gateway'])) $v['gateway'] = $r['gw'] ?? '';
                    if (empty($v['description'])) $v['description'] = $r['role'] ?? '';
                }
            }
            unset($v);
            if (!$found) $d['vlans'][] = array('id'=>$id,'name'=>$r['name'] ?? ('VLAN '.$id),'cidr'=>$r['subnet'] ?? '','gateway'=>$r['gw'] ?? '','color'=>'','description'=>$r['role'] ?? '');
        }
    }
    if (empty($d['internet']) && !empty($raw['wan']) && is_array($raw['wan'])) {
        $d['internet'] = array();
        foreach ($raw['wan'] as $w) $d['internet'][] = array('name'=>$w['provider'] ?? 'WAN','operator'=>$w['provider'] ?? '','type'=>$w['type'] ?? '','status'=>'','public_ip'=>$w['publicIp'] ?? '','bandwidth'=>$w['mask'] ?? '','note'=>'');
    }
    if (empty($d['devices']) && !empty($raw['vms']) && is_array($raw['vms'])) {
        $d['devices'] = array();
        foreach ($raw['vms'] as $vm) $d['devices'][] = array('name'=>$vm['vm'] ?? '','type'=>'VM','ip'=>$vm['addr'] ?? '','vlan'=>preg_replace('~\D+~','',(string)($vm['vlan'] ?? '')),'switch'=>'','port'=>'','description'=>$vm['role'] ?? '');
    }
    foreach (array('internet','firewalls','vlans','switches','devices') as $key) if (!is_array($d[$key] ?? null)) $d[$key] = array();
    return $d;
}
function dmdi_new_id() { return 'infra_' . date('Ymd_His') . '_' . substr(bin2hex(random_bytes(5)), 0, 10); }
function dmdi_normalize_acl($acl, $owner) {
    $out = array(); $seen = array();
    foreach (is_array($acl) ? $acl : array() as $row) {
        if (!is_array($row)) continue;
        $email = strtolower(trim((string)($row['email'] ?? '')));
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !dmdi_profile_email_exists($email) || strcasecmp($email, $owner) === 0 || isset($seen[$email])) continue;
        $perms = array();
        foreach (is_array($row['permissions'] ?? null) ? $row['permissions'] : array('view') as $p) {
            if (in_array($p, array('view','edit','export'), true)) $perms[] = $p;
        }
        if (!in_array('view', $perms, true)) $perms[] = 'view';
        $out[] = array('email'=>$email,'permissions'=>array_values(array_unique($perms)));
        $seen[$email] = true;
    }
    return $out;
}
function dmdi_normalize_doc($doc, $owner) {
    $now = date('c');
    $doc = is_array($doc) ? $doc : array();
    $data = dmdi_migrate_data($doc['data'] ?? array());
    $id = trim((string)($doc['id'] ?? '')); if ($id === '') $id = dmdi_new_id();
    $title = trim((string)($doc['title'] ?? ($data['header']['title'] ?? 'Infrastructure'))); if ($title === '') $title = 'Infrastructure';
    return array(
        'id'=>$id,
        'owner'=>strtolower((string)$owner),
        'title'=>$title,
        'created_at'=>$doc['created_at'] ?? $now,
        'updated_at'=>$doc['updated_at'] ?? $now,
        'acl'=>dmdi_normalize_acl($doc['acl'] ?? array(), $owner),
        'data'=>$data
    );
}
function dmdi_migrate_legacy($email) {
    $new = dmdi_docs_file($email);
    if (!is_file($new)) {
        foreach (dmdi_legacy_user_dirs($email) as $legacyDir) {
            $legacy = $legacyDir . '/infra_docs.json';
            if (!is_file($legacy)) continue;
            $old = dmdi_json_read($legacy, array());
            if (isset($old['documents']) && is_array($old['documents'])) $old = $old['documents'];
            if (!is_array($old)) continue;
            $docs = array();
            foreach ($old as $doc) if (is_array($doc)) $docs[] = dmdi_normalize_doc($doc, $email);
            if (dmdi_json_write($new, array('version'=>2,'documents'=>$docs))) {
                dmdi_log('legacy_migrated', 'success', '', 'Anciennes données Infra copiées vers DMD-Infra-IT.', array('count'=>count($docs),'source'=>$legacy), $email);
            }
            break;
        }
    }
    $newRefs = dmdi_refs_file($email);
    if (!is_file($newRefs)) {
        foreach (dmdi_legacy_user_dirs($email) as $legacyDir) {
            $legacyRefs = $legacyDir . '/shared_refs.json';
            if (!is_file($legacyRefs)) continue;
            dmdi_copy_if_missing($legacyRefs, $newRefs);
            break;
        }
    }
}
function dmdi_load_own_docs($email) {
    dmdi_migrate_legacy($email);
    $raw = dmdi_json_read(dmdi_docs_file($email), array('version'=>2,'documents'=>array()));
    $rows = isset($raw['documents']) && is_array($raw['documents']) ? $raw['documents'] : (dmdi_is_list($raw) ? $raw : array());
    $out = array();
    foreach ($rows as $doc) if (is_array($doc)) $out[] = dmdi_normalize_doc($doc, $email);
    return $out;
}
function dmdi_save_own_docs($email, $docs) { return dmdi_json_write(dmdi_docs_file($email), array('version'=>2,'documents'=>array_values($docs))); }
function dmdi_find_own_doc($owner, $id) {
    foreach (dmdi_load_own_docs($owner) as $doc) if ((string)$doc['id'] === (string)$id) return $doc;
    return null;
}
function dmdi_acl_permissions($doc, $email) {
    if (!is_array($doc)) return array();
    if (strcasecmp((string)($doc['owner'] ?? ''), (string)$email) === 0) return array('view','edit','export','share','delete');
    foreach ($doc['acl'] ?? array() as $row) if (strcasecmp((string)($row['email'] ?? ''), (string)$email) === 0) return $row['permissions'] ?? array('view');
    return array();
}
function dmdi_can_doc($doc, $email, $action) {
    $global = array('view'=>'module.view','edit'=>'infra.edit','export'=>'infra.export','share'=>'infra.share','delete'=>'infra.delete');
    if (!isset($global[$action]) || !dmdi_has_permission($global[$action])) return false;
    $perms = dmdi_acl_permissions($doc, $email);
    return in_array($action, $perms, true) || ($action === 'view' && in_array('view', $perms, true));
}
function dmdi_load_refs($email) {
    dmdi_migrate_legacy($email);
    $raw = dmdi_json_read(dmdi_refs_file($email), array('version'=>1,'refs'=>array()));
    return isset($raw['refs']) && is_array($raw['refs']) ? $raw['refs'] : array();
}
function dmdi_save_refs($email, $refs) { return dmdi_json_write(dmdi_refs_file($email), array('version'=>1,'refs'=>array_values($refs))); }
function dmdi_sync_refs_for_doc($doc, $oldAcl) {
    $owner = (string)$doc['owner']; $id = (string)$doc['id'];
    $emails = array();
    foreach (array_merge(is_array($oldAcl)?$oldAcl:array(), is_array($doc['acl'] ?? null)?$doc['acl']:array()) as $r) if (!empty($r['email'])) $emails[strtolower($r['email'])] = true;
    foreach (array_keys($emails) as $email) {
        $refs = dmdi_load_refs($email); $next = array();
        foreach ($refs as $ref) if (!(strcasecmp((string)($ref['owner'] ?? ''), $owner) === 0 && (string)($ref['id'] ?? '') === $id)) $next[] = $ref;
        $perms = dmdi_acl_permissions($doc, $email);
        if ($perms) $next[] = array('owner'=>$owner,'id'=>$id,'title'=>$doc['title'],'permissions'=>$perms,'updated_at'=>$doc['updated_at']);
        dmdi_save_refs($email, $next);
    }
}
function dmdi_remove_refs_for_doc($doc) {
    foreach ($doc['acl'] ?? array() as $r) {
        $email = (string)($r['email'] ?? ''); if ($email === '') continue;
        $refs = dmdi_load_refs($email); $next = array();
        foreach ($refs as $ref) if (!(strcasecmp((string)($ref['owner'] ?? ''), (string)$doc['owner']) === 0 && (string)($ref['id'] ?? '') === (string)$doc['id'])) $next[] = $ref;
        dmdi_save_refs($email, $next);
    }
}
function dmdi_list_accessible_docs($email) {
    $out = array();
    foreach (dmdi_load_own_docs($email) as $doc) {
        if (dmdi_can_doc($doc, $email, 'view')) { $doc['_shared'] = false; $out[] = $doc; }
    }
    $refs = dmdi_load_refs($email); $validRefs = array();
    foreach ($refs as $ref) {
        $owner = (string)($ref['owner'] ?? ''); $id = (string)($ref['id'] ?? '');
        if ($owner === '' || $id === '') continue;
        $doc = dmdi_find_own_doc($owner, $id);
        if ($doc && dmdi_can_doc($doc, $email, 'view')) {
            $doc['_shared'] = true; $out[] = $doc;
            $validRefs[] = array('owner'=>$owner,'id'=>$id,'title'=>$doc['title'],'permissions'=>dmdi_acl_permissions($doc,$email),'updated_at'=>$doc['updated_at']);
        }
    }
    if (count($validRefs) !== count($refs)) dmdi_save_refs($email, $validRefs);
    usort($out, function($a,$b){ return strcmp((string)($b['updated_at'] ?? ''), (string)($a['updated_at'] ?? '')); });
    return $out;
}
function dmdi_get_accessible_doc($owner, $id, $action) {
    $me = strtolower(dmdi_email());
    $owner = strtolower(trim((string)$owner));
    if ($owner === '') $owner = $me;
    $doc = dmdi_find_own_doc($owner, $id);
    if (!$doc || !dmdi_can_doc($doc, $me, $action)) return null;
    return $doc;
}
function dmdi_resource($doc) {
    return array('type'=>'infrastructure','id'=>'DMD-Infra-IT:infrastructure:'.($doc['owner'] ?? '').':'.($doc['id'] ?? ''),'local_id'=>$doc['id'] ?? '','name'=>$doc['title'] ?? 'Infrastructure');
}
function dmdi_log($action, $status, $resourceId, $message, $details, $actor) {
    dmdi_ensure_runtime();
    $entry = array('timestamp'=>date('c'),'user'=>$actor ?: dmdi_email(),'action'=>$action,'target'=>$resourceId,'result'=>$status,'details'=>$message,'meta'=>is_array($details)?$details:array());
    @file_put_contents(dmdi_log_file(), json_encode($entry, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL, FILE_APPEND|LOCK_EX);
    if (function_exists('dmd_system_log')) {
        try { dmd_system_log('dmd_infra_it_'.$action, $resourceId ?: DMDI_MODULE_ID, $status, $message); } catch (Throwable $e) { }
    }
    return $entry;
}
function dmdi_record_activity($action, $doc, $message, $details) {
    dmdi_ensure_runtime();
    $resource = dmdi_resource($doc);
    $event = array('timestamp'=>date('c'),'module'=>DMDI_MODULE_ID,'user'=>dmdi_email(),'action'=>$action,'message'=>$message,'resource'=>$resource,'details'=>is_array($details)?$details:array());
    @file_put_contents(dmdi_activity_file(), json_encode($event, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL, FILE_APPEND|LOCK_EX);
    /* Pont 1.2 : le Core peut fournir l'un de ces hooks selon sa révision. */
    $hooks = array('dmd_quick_session_record_resource_activity','dmd_quick_session_record_activity','dmd_quick_session_append_event');
    foreach ($hooks as $hook) {
        if (!function_exists($hook)) continue;
        try {
            $rf = new ReflectionFunction($hook); $n = $rf->getNumberOfParameters();
            if ($n <= 1) call_user_func($hook, $event);
            elseif ($n === 2) call_user_func($hook, dmdi_email(), $event);
            elseif ($n === 3) call_user_func($hook, DMDI_MODULE_ID, $resource, $event);
            else call_user_func($hook, DMDI_MODULE_ID, $resource, $action, $message, $details);
            break;
        } catch (Throwable $e) { }
    }
    return $event;
}
function dmdi_audit($action, $status, $doc, $message, $details) {
    $resource = is_array($doc) ? dmdi_resource($doc) : array('id'=>'');
    dmdi_log($action, $status, $resource['id'] ?? '', $message, $details, dmdi_email());
    if ($status === 'success' && is_array($doc)) return dmdi_record_activity($action, $doc, $message, $details);
    return null;
}
function dmdi_notify($email, $type, $title, $message, $level) {
    $email = strtolower(trim((string)$email));
    if ($email === '' || strcasecmp($email, dmdi_email()) === 0 || !filter_var($email, FILTER_VALIDATE_EMAIL)) return;
    if (function_exists('dmd_notify_user')) {
        try { dmd_notify_user($email, $type, $title, $message, array('level'=>$level,'action_url'=>'dashboard.php','action_label'=>'Ouvrir DoMyDesk')); return; } catch (Throwable $e) { }
    }
}
function dmdi_csrf_token() {
    if (empty($_SESSION['dmd_infra_it_csrf'])) $_SESSION['dmd_infra_it_csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['dmd_infra_it_csrf'];
}
function dmdi_check_csrf($token) { return is_string($token) && !empty($_SESSION['dmd_infra_it_csrf']) && hash_equals($_SESSION['dmd_infra_it_csrf'], $token); }
function dmdi_read_body() {
    $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
    if (strpos($ct, 'application/json') !== false) {
        $j = json_decode((string)file_get_contents('php://input'), true);
        return is_array($j) ? $j : array();
    }
    return $_POST;
}
function dmdi_log_rows($limit) {
    $limit = max(1, min(500, (int)$limit));
    if (!is_file(dmdi_log_file())) return array();
    $lines = @file(dmdi_log_file(), FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES); if (!is_array($lines)) return array();
    $lines = array_slice($lines, -$limit); $rows = array();
    foreach (array_reverse($lines) as $line) { $j=json_decode($line,true); if (is_array($j)) $rows[]=$j; }
    return $rows;
}
