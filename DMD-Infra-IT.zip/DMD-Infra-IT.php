<?php
if (session_status() === PHP_SESSION_NONE) session_start();
header('X-Content-Type-Options: nosniff');
require_once __DIR__ . '/DMD-Infra-IT_lib.php';
$me = strtolower(dmdi_email());
if ($me === '') { echo '<div class="dmdi-empty">Connexion requise.</div>'; return; }
try { dmdi_require_permission('module.view'); } catch (Throwable $e) { echo '<div class="dmdi-empty">Accès DMD-Infra-IT refusé.</div>'; return; }

function dmdi_module_base_url() {
    $script = str_replace('\\','/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    if (strpos($script, '/modules/') !== false) return rtrim(dirname($script), '/');
    $docRoot = realpath((string)($_SERVER['DOCUMENT_ROOT'] ?? ''));
    $dir = realpath(__DIR__);
    if ($docRoot && $dir && strpos($dir, $docRoot) === 0) return '/' . trim(str_replace('\\','/',substr($dir, strlen($docRoot))), '/');
    return 'modules/DMD-Infra-IT';
}
$baseUrl = dmdi_module_base_url();
$docs = dmdi_list_accessible_docs($me);
$uid = 'dmdi_' . substr(bin2hex(random_bytes(5)),0,10);
?>
<link rel="stylesheet" href="<?= dmdi_h($baseUrl) ?>/DMD-Infra-IT.css?v=1.2.0">
<section id="<?= dmdi_h($uid) ?>" class="dmdi-app" data-dmd-module-id="DMD-Infra-IT" data-dmd-module-name="DMD-Infra-IT" data-api="<?= dmdi_h($baseUrl) ?>/DMD-Infra-IT_api.php" data-render="<?= dmdi_h($baseUrl) ?>/DMD-Infra-IT_render.php">
  <header class="dmdi-toolbar">
    <div class="dmdi-toolbar-main">
      <div>
        <h2 class="dmdi-title">DMD-Infra-IT</h2>
        <p class="dmdi-subtitle">Documentation réseau et infrastructures partagées</p>
      </div>
    </div>
  </header>

  <div class="dmdi-grid" data-dmdi-grid>
    <?php if (!$docs): ?>
      <div class="dmdi-empty">Aucune infrastructure accessible.</div>
    <?php endif; ?>
    <?php foreach ($docs as $doc):
      $data = is_array($doc['data'] ?? null) ? $doc['data'] : array();
      $counts = array(
        'vlans'=>count(is_array($data['vlans'] ?? null)?$data['vlans']:array()),
        'switches'=>count(is_array($data['switches'] ?? null)?$data['switches']:array()),
        'devices'=>count(is_array($data['devices'] ?? null)?$data['devices']:array())
      );
      $resource = dmdi_resource($doc);
      $shared = strcasecmp((string)$doc['owner'],$me)!==0;
      $canExport = dmdi_can_doc($doc,$me,'export');
    ?>
    <article class="dmdi-card"
      data-shared="<?= $shared ? '1':'0' ?>"
      data-dmdi-card
      data-owner="<?= dmdi_h($doc['owner']) ?>"
      data-doc="<?= dmdi_h($doc['id']) ?>"
      data-title="<?= dmdi_h($doc['title']) ?>"
      data-can-export="<?= $canExport ? '1':'0' ?>"
      data-dmd-module-id="DMD-Infra-IT"
      data-dmd-context-type="infrastructure"
      data-dmd-context-id="<?= dmdi_h($resource['id']) ?>"
      data-dmd-context-name="<?= dmdi_h($resource['name']) ?>"
      data-dmd-action-hub="1">
      <div class="dmdi-card-head">
        <div>
          <h3 class="dmdi-card-title"><?= dmdi_h($doc['title']) ?></h3>
          <div class="dmdi-card-desc"><?= dmdi_h($data['header']['description'] ?? '') ?></div>
        </div>
        <?php if ($shared): ?><span class="dmdi-badge">Partagée</span><?php elseif (!empty($doc['acl'])): ?><span class="dmdi-badge"><?= count($doc['acl']) ?> partage(s)</span><?php endif; ?>
      </div>
      <div class="dmdi-card-meta">
        <div class="dmdi-stat"><span>Site</span><strong><?= dmdi_h($data['header']['site'] ?? '—') ?></strong></div>
        <div class="dmdi-stat"><span>VLANs</span><strong><?= (int)$counts['vlans'] ?></strong></div>
        <div class="dmdi-stat"><span>Switchs</span><strong><?= (int)$counts['switches'] ?></strong></div>
        <div class="dmdi-stat"><span>Équipements</span><strong><?= (int)$counts['devices'] ?></strong></div>
        <div class="dmdi-stat"><span>Propriétaire</span><strong><?= dmdi_h($doc['owner']) ?></strong></div>
        <div class="dmdi-stat"><span>Modifiée</span><strong><?= dmdi_h(substr((string)$doc['updated_at'],0,10)) ?></strong></div>
      </div>
      <div class="dmdi-card-actions">
        <button type="button" class="dmdi-btn dmdi-btn-primary" data-open-report>Ouvrir</button>
        <?php if ($canExport): ?><button type="button" class="dmdi-btn" data-print-report>PDF / imprimer</button><?php endif; ?>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
  <div class="dmdi-message" data-dmdi-message aria-live="polite"></div>
</section>
<script>
(() => {
  const root = document.getElementById(<?= json_encode($uid) ?>);
  if (!root || root.dataset.bound === '1') return;
  root.dataset.bound = '1';
  const renderUrl = root.dataset.render;
  let z = Number(window.__DMDInfraITZ || 5200);
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  function message(t, kind='') { const e=root.querySelector('[data-dmdi-message]'); if(e){e.textContent=t||'';e.dataset.kind=kind;} }
  function bring(win){ z += 1; window.__DMDInfraITZ=z; win.style.zIndex=String(z); }
  function pad(){
    let p=document.getElementById('dmdi-scroll-pad-global');
    if(!p){p=document.createElement('div');p.id='dmdi-scroll-pad-global';p.className='dmdi-scroll-pad';document.body.appendChild(p);}
    let maxR=document.documentElement.clientWidth, maxB=document.documentElement.clientHeight;
    document.querySelectorAll('.dmdi-window[data-dmdi-window="1"]').forEach(w=>{ const r=w.getBoundingClientRect(); maxR=Math.max(maxR,r.right+window.scrollX+24);maxB=Math.max(maxB,r.bottom+window.scrollY+24); });
    p.style.width=Math.ceil(maxR)+'px'; p.style.height=Math.ceil(maxB)+'px';
  }
  function drag(win, head){
    let start=null;
    head.addEventListener('pointerdown', e=>{
      if(e.target.closest('button')) return;
      const r=win.getBoundingClientRect();
      start={x:e.clientX,y:e.clientY,left:r.left+window.scrollX,top:r.top+window.scrollY};
      head.setPointerCapture(e.pointerId); bring(win); e.preventDefault();
    });
    head.addEventListener('pointermove', e=>{
      if(!start) return;
      win.style.left=Math.max(0,start.left+(e.clientX-start.x))+'px';
      win.style.top=Math.max(0,start.top+(e.clientY-start.y))+'px'; pad();
    });
    const stop=e=>{ if(start){start=null;try{head.releasePointerCapture(e.pointerId)}catch(_){ }pad();} };
    head.addEventListener('pointerup',stop); head.addEventListener('pointercancel',stop);
  }
  function makeWindow(card, printNow=false){
    const owner=card.dataset.owner, id=card.dataset.doc, title=card.dataset.title || 'Infrastructure';
    const key=encodeURIComponent(owner)+'__'+encodeURIComponent(id)+'__'+Date.now();
    const win=document.createElement('section'); win.className='dmdi-window'; win.dataset.dmdiWindow='1'; win.dataset.key=key;
    const offset=document.querySelectorAll('.dmdi-window[data-dmdi-window="1"]').length*24;
    win.style.left=(90+offset+window.scrollX)+'px'; win.style.top=(90+offset+window.scrollY)+'px';
    win.innerHTML=`<header class="dmdi-window-head"><div class="dmdi-window-title"><strong>${esc(title)}</strong><small>${esc(owner)}</small></div><div class="dmdi-window-actions">${card.dataset.canExport==='1'?'<button type="button" class="dmdi-btn" data-win-print title="PDF / imprimer">🖨</button>':''}<button type="button" class="dmdi-btn" data-win-max title="Agrandir / restaurer">□</button><button type="button" class="dmdi-btn" data-win-close title="Fermer">✕</button></div></header><div class="dmdi-window-body"><iframe class="dmdi-window-frame" title="${esc(title)}"></iframe></div>`;
    document.body.appendChild(win); bring(win); drag(win,win.querySelector('.dmdi-window-head')); pad();
    const frame=win.querySelector('iframe');
    const base=`${renderUrl}?owner=${encodeURIComponent(owner)}&doc=${encodeURIComponent(id)}&embed=1`;
    frame.src=base;
    win.addEventListener('pointerdown',()=>bring(win));
    if(window.ResizeObserver){ const ro=new ResizeObserver(pad); ro.observe(win); win._dmdiRO=ro; }
    win.querySelector('[data-win-close]').addEventListener('click',()=>{ if(win._dmdiRO)win._dmdiRO.disconnect();win.remove();pad(); });
    const max=win.querySelector('[data-win-max]');
    max.addEventListener('click',()=>{
      if(win.classList.contains('is-maximized')){
        const s=JSON.parse(win.dataset.restore||'{}'); ['left','top','width','height'].forEach(k=>{if(s[k])win.style[k]=s[k]}); win.classList.remove('is-maximized');
      } else {
        win.dataset.restore=JSON.stringify({left:win.style.left,top:win.style.top,width:win.style.width||getComputedStyle(win).width,height:win.style.height||getComputedStyle(win).height});
        win.style.left=(window.scrollX+16)+'px';win.style.top=(window.scrollY+16)+'px';win.style.width='calc(100vw - 32px)';win.style.height='calc(100vh - 32px)';win.classList.add('is-maximized');
      } bring(win);pad();
    });
    const printBtn=win.querySelector('[data-win-print]');
    function requestPrint(){
      let done=false; const onload=()=>{ if(done)return;done=true;frame.removeEventListener('load',onload);try{frame.contentWindow.focus();frame.contentWindow.print();}catch(_){message('Impression bloquée par le navigateur.','error');} };
      frame.addEventListener('load',onload); frame.src=base+'&print=1&_='+Date.now();
    }
    if(printBtn) printBtn.addEventListener('click',requestPrint);
    if(printNow && printBtn) requestPrint();
    return win;
  }
  root.addEventListener('click', e=>{
    const card=e.target.closest('[data-dmdi-card]'); if(!card) return;
    if(e.target.closest('[data-open-report]')) makeWindow(card,false);
    if(e.target.closest('[data-print-report]')) makeWindow(card,true);
  });
  try { if(window.DMDActionHub && typeof window.DMDActionHub.decorate==='function') window.DMDActionHub.decorate(root); } catch(_) { }
})();
</script>
