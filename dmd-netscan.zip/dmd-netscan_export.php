<?php
require_once __DIR__ . '/dmd-netscan_lib.php';
$email = ns_require_login();
$token = isset($_GET['csrf']) ? (string)$_GET['csrf'] : '';
if (!ns_csrf_check($token)) { http_response_code(403); exit('Jeton invalide.'); }
$scope = strtolower((string)(isset($_GET['scope'])?$_GET['scope']:'scan'));
$format = strtolower((string)(isset($_GET['format'])?$_GET['format']:'csv'));
$shareId = trim((string)(isset($_GET['share_id'])?$_GET['share_id']:''));
if ($scope === 'logs') {
    if (!ns_can('logs.export',$email)) { http_response_code(403); exit('Export des logs refusé.'); }
    $rows = ns_read_logs($email, 90, 5000);
    if ($format === 'json') {
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="netscan_logs_'.date('Ymd_His').'.json"');
        echo json_encode(array('module'=>'netscan','generated_at'=>ns_iso_now(),'logs'=>$rows), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit;
    }
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="netscan_logs_'.date('Ymd_His').'.csv"');
    $fh=fopen('php://output','w'); fwrite($fh,"\xEF\xBB\xBF"); fputcsv($fh,array('Date','Utilisateur','Action','Cible','Résultat','Détails'),';');
    foreach($rows as$r)fputcsv($fh,array(isset($r['datetime'])?$r['datetime']:'',isset($r['user'])?$r['user']:'',isset($r['action'])?$r['action']:'',isset($r['target'])?$r['target']:'',isset($r['result'])?$r['result']:'',json_encode(isset($r['details'])?$r['details']:array(),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),';'); fclose($fh); exit;
}
if ($shareId !== '') {
    if (!ns_can('scan.share',$email)) { http_response_code(403); exit('Accès partage refusé.'); }
    list($scan,$share)=ns_scan_from_share_or_own($email,$shareId,true); if(!$scan){http_response_code(403);exit('Export du partage non autorisé.');}
    $label='partage_'.preg_replace('/[^a-zA-Z0-9_-]/','_',substr($shareId,0,16));
    ns_log($email,'share.export',$shareId,'success',array('format'=>$format,'owner'=>$share['owner']),array('type'=>'network_scan','id'=>isset($scan['id'])?$scan['id']:'','name'=>$share['title']));
} else {
    if (!ns_can('scan.export',$email)) { http_response_code(403); exit('Export refusé.'); }
    $scan=ns_last_scan($email);$label='scan_'.(isset($scan['id'])&&$scan['id']!==''?$scan['id']:date('Ymd_His'));
    ns_log($email,'scan.export',$label,'success',array('format'=>$format),array('type'=>'network_scan','id'=>isset($scan['id'])?$scan['id']:'','name'=>'Dernier scan'));
}
$rows=isset($scan['results'])&&is_array($scan['results'])?$scan['results']:array();
if($format==='json'){header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="netscan_'.$label.'.json"');echo json_encode($scan,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="netscan_'.$label.'.csv"');echo ns_csv($rows);
