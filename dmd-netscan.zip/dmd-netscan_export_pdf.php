<?php
require_once __DIR__ . '/dmd-netscan_lib.php';
$email=ns_require_login();$token=isset($_GET['csrf'])?(string)$_GET['csrf']:'';if(!ns_csrf_check($token)){http_response_code(403);exit('Jeton invalide.');}
$scope=strtolower((string)(isset($_GET['scope'])?$_GET['scope']:'scan'));$shareId=trim((string)(isset($_GET['share_id'])?$_GET['share_id']:''));
if($scope==='logs'){
    if(!ns_can('logs.export',$email)){http_response_code(403);exit('Export des logs refusé.');}$logs=ns_read_logs($email,90,5000);$rows=array();foreach($logs as$l)$rows[]=array('ip'=>isset($l['datetime'])?$l['datetime']:'','host'=>isset($l['user'])?$l['user']:'','os_guess'=>isset($l['action'])?$l['action']:'','mac'=>isset($l['result'])?$l['result']:'','services'=>array(isset($l['target'])?$l['target']:''),'details'=>isset($l['details'])?$l['details']:array());$pdf=ns_pdf_document('DoMyDesk NetScan - Logs',$rows);$name='netscan_logs_'.date('Ymd_His').'.pdf';
}else{
    if($shareId!==''){if(!ns_can('scan.share',$email)){http_response_code(403);exit('Accès partage refusé.');}list($scan,$share)=ns_scan_from_share_or_own($email,$shareId,true);if(!$scan){http_response_code(403);exit('Export du partage non autorisé.');}$title='DoMyDesk NetScan - '.(isset($share['title'])?$share['title']:'Partage');ns_log($email,'share.export',$shareId,'success',array('format'=>'pdf','owner'=>$share['owner']),array('type'=>'network_scan','id'=>isset($scan['id'])?$scan['id']:'','name'=>$title));}
    else{if(!ns_can('scan.export',$email)){http_response_code(403);exit('Export refusé.');}$scan=ns_last_scan($email);$title='DoMyDesk NetScan - Rapport réseau';ns_log($email,'scan.export','pdf','success',array('format'=>'pdf'),array('type'=>'network_scan','id'=>isset($scan['id'])?$scan['id']:'','name'=>'Dernier scan'));}
    $pdf=ns_pdf_document($title,isset($scan['results'])?$scan['results']:array());$name='netscan_'.date('Ymd_His').'.pdf';
}
header('Content-Type: application/pdf');header('Content-Disposition: inline; filename="'.$name.'"');header('Content-Length: '.strlen($pdf));echo $pdf;
