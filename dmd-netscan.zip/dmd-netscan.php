<?php

/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



require_once __DIR__ . '/dmd-netscan_lib.php';
$email = ns_require('module.view');
$cfg = ns_load_config($email);
$scan = ns_last_scan($email);
$permissions = ns_permissions_snapshot($email);
$csrf = ns_csrf();
$uid = 'netscan_' . bin2hex(random_bytes(4));
$cssVersion = @filemtime(__DIR__ . '/dmd-netscan.css') ?: time();
$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/dmd-netscan';
if ($documentRoot !== '' && strpos($moduleRealDir, $documentRoot) === 0) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot))), '/');
}
$moduleWebPath = rtrim($moduleWebPath, '/');
$apiUrl = $moduleWebPath . '/dmd-netscan_api.php';
$exportUrl = $moduleWebPath . '/dmd-netscan_export.php';
$exportPdfUrl = $moduleWebPath . '/dmd-netscan_export_pdf.php';
?>
<link rel="stylesheet" href="<?= ns_h($moduleWebPath) ?>/dmd-netscan.css?v=<?= ns_h($cssVersion) ?>">
<div class="netscan" id="<?= ns_h($uid) ?>" data-csrf="<?= ns_h($csrf) ?>">
  <div class="netscan-head">
    <div class="netscan-brand"><img src="<?= ns_h($moduleWebPath) ?>/icon.png" alt=""><div class="netscan-brand-copy"><span class="netscan-kicker">DoMyDesk 1.2.0</span><strong>DMD-NetScan</strong><small>Scanner réseau et inventaire rapide</small></div></div>
    <span class="netscan-state" data-state-label>Prêt</span>
  </div>

  <div class="netscan-toolbar">
    <button class="netscan-btn" type="button" data-open="results">Hôtes</button>
    <?php if ($permissions['actionhub.use']): ?><button class="netscan-btn" type="button" data-open="actionhub">⚡ ActionHub</button><?php endif; ?>
    <?php if ($permissions['scan.share']): ?><button class="netscan-btn" type="button" data-open="shares">Partages</button><?php endif; ?>
    <?php if ($permissions['logs.view']): ?><button class="netscan-btn" type="button" data-open="logs">Logs</button><?php endif; ?>
    <?php if ($permissions['scan.export']): ?><button class="netscan-btn" type="button" data-open="exports">Exports</button><?php endif; ?>
    <?php if ($permissions['scan.jobs']): ?><button class="netscan-btn" type="button" data-open="jobs">Planification</button><?php endif; ?>
    <span class="netscan-spacer"></span>
    <?php if ($permissions['infra.push']): ?><button class="netscan-btn" type="button" data-infra>Envoyer à Infra</button><?php endif; ?>
  </div>

  <section class="netscan-card">
    <div class="netscan-form-grid">
      <label><span>Réseaux CIDR</span><input data-cidrs value="<?= ns_h(implode(', ', $cfg['cidrs'])) ?>" placeholder="192.168.0.0/24"></label>
      <label><span>Ports TCP/UDP</span><input data-ports value="<?= ns_h(implode(',', $cfg['ports'])) ?>" placeholder="22,53,80,443"></label>
      <label><span>Limite hôtes</span><input data-max type="number" min="16" max="4096" value="<?= (int)$cfg['max_hosts'] ?>"></label>
    </div>
    <div class="netscan-checks">
      <label class="netscan-check"><input data-resolve type="checkbox" <?= $cfg['resolve']?'checked':'' ?>><span>Reverse DNS</span></label>
      <label class="netscan-check"><input data-deep type="checkbox" <?= $cfg['deep']?'checked':'' ?>><span>Scan approfondi</span></label>
    </div>
    <div class="netscan-scan-actions">
      <?php if ($permissions['scan.configure']): ?><button class="netscan-btn" type="button" data-save>Enregistrer</button><?php endif; ?>
      <?php if ($permissions['scan.start']): ?><button class="netscan-btn netscan-btn--primary" type="button" data-start>Scanner</button><?php endif; ?>
      <?php if ($permissions['scan.stop']): ?><button class="netscan-btn" type="button" data-stop disabled>Stop</button><?php endif; ?>
      <?php if ($permissions['scan.arp']): ?><button class="netscan-btn" type="button" data-arp>ARP</button><?php endif; ?>
      <span class="netscan-inline-msg" data-msg>Prêt.</span>
    </div>
  </section>

  <div class="netscan-progress-wrap"><div class="netscan-progress"><span data-progress></span></div><span class="netscan-progress-label" data-progress-label>0 %</span></div>
  <div class="netscan-stats">
    <div class="netscan-stat is-ok"><span>Hôtes détectés</span><strong data-count><?= count(isset($scan['results'])?$scan['results']:array()) ?></strong></div>
    <div class="netscan-stat"><span>Réseau</span><strong data-network><?= ns_h(isset($scan['cidrs'][0])?$scan['cidrs'][0]:$cfg['cidrs'][0]) ?></strong></div>
    <div class="netscan-stat"><span>Dernier scan</span><strong data-last><?= ns_h(isset($scan['finished_at'])&&$scan['finished_at']?$scan['finished_at']:'—') ?></strong></div>
    <div class="netscan-stat"><span>État</span><strong data-status>Prêt</strong></div>
  </div>
  <section class="netscan-card netscan-card--tight netscan-preview">
    <div class="netscan-preview-head"><div><strong>Aperçu</strong><div class="netscan-muted"><?= $permissions['actionhub.use'] ? 'Clique un hôte pour le détail et son contexte ActionHub.' : 'Clique un hôte pour afficher son détail.' ?></div></div><button class="netscan-btn" type="button" data-open="results">Tout afficher</button></div>
    <div class="netscan-chips" data-preview></div>
  </section>
</div>
<script>
(function(){
  'use strict';
  var root=document.getElementById(<?= json_encode($uid) ?>); if(!root)return;
  var csrf=root.dataset.csrf, api=<?= json_encode($apiUrl, JSON_UNESCAPED_SLASHES) ?>, exportBase=<?= json_encode($exportUrl, JSON_UNESCAPED_SLASHES) ?>, exportPdfBase=<?= json_encode($exportPdfUrl, JSON_UNESCAPED_SLASHES) ?>;
  var state={scan:<?= json_encode($scan, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>, permissions:<?= json_encode($permissions) ?>, stateId:'', running:false, z:100100, windows:[]};
  var q=function(sel,ctx){return (ctx||root).querySelector(sel)}, qa=function(sel,ctx){return Array.prototype.slice.call((ctx||root).querySelectorAll(sel))};
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];});}
  function can(p){return state.permissions[p]===true;}
  async function call(action,payload){var body=Object.assign({action:action,csrf:csrf},payload||{});var r=await fetch(api,{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});var j;try{j=await r.json();}catch(e){throw new Error('Réponse serveur invalide.');}if(!r.ok||!j.ok)throw new Error(j.message||'Erreur NetScan');return j;}
  function setMsg(text,type){var el=q('[data-msg]');el.textContent=text||'';el.classList.toggle('is-error',type==='error');el.classList.toggle('is-ok',type==='ok');}
  function setStatus(text){q('[data-status]').textContent=text;q('[data-state-label]').textContent=text;}
  function setProgress(p,label){p=Math.max(0,Math.min(100,Number(p)||0));q('[data-progress]').style.width=p+'%';q('[data-progress-label]').textContent=label||p.toFixed(p%1?1:0)+' %';}
  function rows(){return state.scan&&Array.isArray(state.scan.results)?state.scan.results:[];}
  function resourceAttrs(r){var name=r.host||r.ip||'Hôte';return ' data-dmd-module-id="dmd-netscan" data-dmd-context-type="network_host" data-dmd-context-id="'+esc('dmd-netscan:host:'+(r.ip||''))+'" data-dmd-context-name="'+esc(name)+'" data-dmd-action-hub="1"';}
  function decorate(scope){if(!can('actionhub.use'))return;try{if(window.DMDActionHub&&typeof window.DMDActionHub.decorate==='function')window.DMDActionHub.decorate(scope||root);}catch(e){}}
  function renderPreview(){var list=rows();q('[data-count]').textContent=list.length;q('[data-network]').textContent=(state.scan.cidrs&&state.scan.cidrs[0])||q('[data-cidrs]').value||'—';q('[data-last]').textContent=state.scan.finished_at||'—';var html=list.slice(0,12).map(function(r){return '<button type="button" class="netscan-chip" data-host="'+esc(r.ip)+'"'+resourceAttrs(r)+'>'+esc(r.host||r.ip)+'</button>';}).join('');if(list.length>12)html+='<span class="netscan-chip">+'+(list.length-12)+'</span>';q('[data-preview]').innerHTML=html||'<span class="netscan-empty">Aucun résultat. Lance un scan.</span>';decorate(q('[data-preview]'));}
  function findHost(ip){return rows().filter(function(r){return r.ip===ip;})[0]||null;}
  function badges(arr){arr=Array.isArray(arr)?arr:[];return arr.length?'<div class="netscan-badges">'+arr.map(function(x){return '<span class="netscan-badge">'+esc(x)+'</span>';}).join('')+'</div>':'<span class="netscan-muted">Aucun service détecté</span>';}
  function detailsText(obj){var list=[];Object.keys(obj||{}).forEach(function(k){list.push('<div><span>'+esc(k)+'</span><code>'+esc(typeof obj[k]==='object'?JSON.stringify(obj[k]):obj[k])+'</code></div>');});return list.join('')||'<div><span>Détails</span><strong>—</strong></div>';}

  function ensureSpacer(){var s=document.getElementById('netscan-desk-scroll-spacer');if(!s){s=document.createElement('div');s.id='netscan-desk-scroll-spacer';s.setAttribute('aria-hidden','true');s.style.position='absolute';s.style.width='1px';s.style.height='1px';s.style.pointerEvents='none';document.body.appendChild(s);}return s;}
  function syncSpacer(){var s=ensureSpacer(),right=Math.max(document.documentElement.clientWidth,window.innerWidth),bottom=Math.max(document.documentElement.clientHeight,window.innerHeight);state.windows=state.windows.filter(function(w){return w&&w.isConnected;});state.windows.forEach(function(w){right=Math.max(right,w.offsetLeft+w.offsetWidth+24);bottom=Math.max(bottom,w.offsetTop+w.offsetHeight+24);});s.style.left=right+'px';s.style.top=bottom+'px';}
  function autoScroll(x,y){var edge=46,step=28,dx=0,dy=0;if(x>window.innerWidth-edge)dx=step;else if(x<edge)dx=-step;if(y>window.innerHeight-edge)dy=step;else if(y<edge)dy=-step;if(dx||dy)window.scrollBy(dx,dy);}
  function front(w){state.z+=1;w.style.zIndex=String(state.z);}
  function bindMoveResize(w){
    var head=q('.netscan-pophead',w),res=q('.netscan-resizer',w),drag=null,resize=null;
    w.addEventListener('pointerdown',function(){front(w);});
    head.addEventListener('pointerdown',function(e){if(e.target.closest('button'))return;e.preventDefault();front(w);drag={x:e.pageX,y:e.pageY,l:w.offsetLeft,t:w.offsetTop};head.setPointerCapture(e.pointerId);w.classList.add('is-dragging');});
    head.addEventListener('pointermove',function(e){if(!drag)return;w.style.left=Math.max(4,drag.l+e.pageX-drag.x)+'px';w.style.top=Math.max(4,drag.t+e.pageY-drag.y)+'px';syncSpacer();autoScroll(e.clientX,e.clientY);});
    function endDrag(e){if(!drag)return;drag=null;w.classList.remove('is-dragging');try{head.releasePointerCapture(e.pointerId);}catch(x){}syncSpacer();}
    head.addEventListener('pointerup',endDrag);head.addEventListener('pointercancel',endDrag);
    res.addEventListener('pointerdown',function(e){e.preventDefault();e.stopPropagation();front(w);resize={x:e.pageX,y:e.pageY,w:w.offsetWidth,h:w.offsetHeight};res.setPointerCapture(e.pointerId);w.classList.add('is-resizing');});
    res.addEventListener('pointermove',function(e){if(!resize)return;w.style.width=Math.max(300,resize.w+e.pageX-resize.x)+'px';w.style.height=Math.max(220,resize.h+e.pageY-resize.y)+'px';syncSpacer();autoScroll(e.clientX,e.clientY);});
    function endResize(e){if(!resize)return;resize=null;w.classList.remove('is-resizing');try{res.releasePointerCapture(e.pointerId);}catch(x){}syncSpacer();}
    res.addEventListener('pointerup',endResize);res.addEventListener('pointercancel',endResize);
  }
  function makeWin(title,html,size,key){
    var w=document.createElement('section');w.className='netscan-popwin '+(size||'');w.dataset.netscanWindow=key||'';var offset=state.windows.length*24,mobile=window.innerWidth<=760;w.style.left=(Math.max(4,window.scrollX+(mobile?6:70+offset)))+'px';w.style.top=(Math.max(4,window.scrollY+(mobile?12+Math.min(offset,48):80+offset)))+'px';
    w.innerHTML='<header class="netscan-pophead"><div class="netscan-poptitle"><strong>'+esc(title)+'</strong></div><div class="netscan-popactions"><button type="button" data-close title="Fermer">×</button></div></header><div class="netscan-popbody">'+html+'</div><div class="netscan-resizer" aria-hidden="true"></div>';
    document.body.appendChild(w);state.windows.push(w);front(w);bindMoveResize(w);q('[data-close]',w).addEventListener('click',function(){w.remove();syncSpacer();});syncSpacer();decorate(w);return w;
  }
  function hostHtml(r){var d=r.details||{};return '<div class="netscan-detail-grid"><div><span>IP</span><strong>'+esc(r.ip)+'</strong></div><div><span>Nom DNS</span><strong>'+esc(r.host||'—')+'</strong></div><div><span>MAC</span><strong>'+esc(r.mac||'—')+'</strong></div><div><span>OS estimé</span><strong>'+esc(r.os_guess||'Inconnu')+'</strong></div><div><span>Ping</span><strong>'+esc(r.ping_ms==null?'—':r.ping_ms+' ms')+'</strong></div><div><span>TTL</span><strong>'+esc(r.ttl==null?'—':r.ttl)+'</strong></div></div><div class="netscan-card netscan-gap-top"><div class="netscan-section-title"><div><h4>Services</h4></div></div>'+badges(r.services)+'</div><div class="netscan-card netscan-gap-top"><div class="netscan-section-title"><div><h4>Bannières / détails</h4></div></div><div class="netscan-detail-grid">'+detailsText(d)+'</div></div><div class="netscan-actions">'+(can('quicksession.use')?'<button type="button" class="netscan-btn netscan-btn--primary" data-qs>Ajouter à Quick-Session</button>':'')+'</div>';
  }
  function openHost(r){var w=makeWin('Hôte · '+(r.host||r.ip),hostHtml(r),'is-small','host-'+r.ip);w.dataset.dmdModuleId='dmd-netscan';w.dataset.dmdContextType='network_host';w.dataset.dmdContextId='dmd-netscan:host:'+r.ip;w.dataset.dmdContextName=r.host||r.ip;w.dataset.dmdActionHub='1';decorate(w);var b=q('[data-qs]',w);if(b)b.addEventListener('click',async function(){b.disabled=true;try{var j=await call('quicksession_event',{ip:r.ip,name:r.host||r.ip});b.textContent=j.message;var ev=new CustomEvent('domydesk:quicksession:event',{detail:j.resource});document.dispatchEvent(ev);}catch(e){b.textContent=e.message;}finally{setTimeout(function(){b.disabled=false;b.textContent='Ajouter à Quick-Session';},1800);}});}
  function resultsHtml(list){return '<div class="netscan-form-grid"><label class="netscan-wide"><span>Filtrer</span><input data-filter placeholder="IP, nom, OS, service..."></label></div><div class="netscan-table-wrap netscan-gap-top"><table class="netscan-table"><thead><tr><th>IP</th><th>Nom</th><th>MAC</th><th>OS</th><th>Ping</th><th>Services</th><th></th></tr></thead><tbody data-result-body></tbody></table></div>';}
  function openResults(){var w=makeWin('Résultats NetScan',resultsHtml(rows()),'is-large','results');var input=q('[data-filter]',w),body=q('[data-result-body]',w);function draw(){var s=(input.value||'').toLowerCase();var list=rows().filter(function(r){return !s||JSON.stringify(r).toLowerCase().indexOf(s)>=0;});body.innerHTML=list.map(function(r){return '<tr'+resourceAttrs(r)+'><td><code>'+esc(r.ip)+'</code></td><td>'+esc(r.host||'—')+'</td><td>'+esc(r.mac||'—')+'</td><td>'+esc(r.os_guess||'Inconnu')+'</td><td>'+esc(r.ping_ms==null?'—':r.ping_ms+' ms')+'</td><td>'+badges(r.services)+'</td><td><button class="netscan-btn" type="button" data-open-host="'+esc(r.ip)+'">Détail</button></td></tr>';}).join('')||'<tr><td colspan="7"><span class="netscan-empty">Aucun résultat.</span></td></tr>';decorate(body);}draw();input.addEventListener('input',draw);body.addEventListener('click',function(e){var b=e.target.closest('[data-open-host]');if(b){var r=findHost(b.dataset.openHost);if(r)openHost(r);}});}
  function openActionHub(){var list=rows();var html='<div class="netscan-section-title"><div><h4>Ressources réseau publiées</h4><p>Ces hôtes sont décorés pour le Core ActionHub et filtrés par tes droits.</p></div></div><div class="netscan-list">'+list.map(function(r){return '<button type="button" class="netscan-list-item" data-host="'+esc(r.ip)+'"'+resourceAttrs(r)+'><span><strong>'+esc(r.host||r.ip)+'</strong><small>'+esc(r.ip)+' · '+esc(r.os_guess||'Inconnu')+'</small></span><span>⚡</span></button>';}).join('')+'</div>';var w=makeWin('⚡ ActionHub · NetScan',html,'is-small','actionhub');decorate(w);w.addEventListener('click',function(e){var b=e.target.closest('[data-host]');if(b){var r=findHost(b.dataset.host);if(r)openHost(r);}});}
  async function openLogs(){var w=makeWin('Logs NetScan','<div class="netscan-inline-msg" data-loading>Chargement…</div>','is-large','logs');try{var j=await call('logs',{days:30,limit:1000});var body=q('.netscan-popbody',w);body.innerHTML='<div class="netscan-actions">'+(can('logs.export')?'<button class="netscan-btn" data-log-export="csv">CSV</button><button class="netscan-btn" data-log-export="json">JSON</button><button class="netscan-btn" data-log-pdf>PDF</button>':'')+(can('logs.delete')?'<button class="netscan-btn netscan-btn--danger" data-log-delete>Supprimer mes logs</button>':'')+'</div><div class="netscan-table-wrap netscan-gap-top"><table class="netscan-table"><thead><tr><th>Date</th><th>Action</th><th>Cible</th><th>Résultat</th><th>Détails</th></tr></thead><tbody>'+j.logs.map(function(l){return '<tr><td>'+esc(l.datetime)+'</td><td>'+esc(l.action)+'</td><td>'+esc(l.target)+'</td><td>'+esc(l.result)+'</td><td class="netscan-log-details">'+esc(JSON.stringify(l.details||{}))+'</td></tr>';}).join('')+'</tbody></table></div>';body.addEventListener('click',async function(e){var ex=e.target.closest('[data-log-export]');if(ex)downloadExport('logs',ex.dataset.logExport,'');if(e.target.closest('[data-log-pdf]'))openPdf('logs','');if(e.target.closest('[data-log-delete]')){if(!confirm('Supprimer tous tes logs NetScan ?'))return;try{var x=await call('logs_delete',{});setMsg(x.message,'ok');w.remove();syncSpacer();}catch(err){alert(err.message);}}});}catch(e){q('.netscan-popbody',w).innerHTML='<span class="netscan-empty">'+esc(e.message)+'</span>';}}
  function exportUrl(scope,format,shareId,pdf){var u=(pdf?exportPdfBase:exportBase)+'?csrf='+encodeURIComponent(csrf)+'&scope='+encodeURIComponent(scope);if(!pdf)u+='&format='+encodeURIComponent(format);if(shareId)u+='&share_id='+encodeURIComponent(shareId);return u;}
  async function downloadExport(scope,format,shareId){try{var url=exportUrl(scope,format,shareId,false);var r=await fetch(url,{cache:'no-store'});if(!r.ok)throw new Error(await r.text());var blob=await r.blob();var a=document.createElement('a'),obj=URL.createObjectURL(blob);a.href=obj;a.download='netscan_'+scope+'_'+new Date().toISOString().replace(/[:.]/g,'-')+'.'+format;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(obj);},2000);}catch(e){setMsg(e.message,'error');}}
  async function openPdf(scope,shareId){var w=makeWin('Aperçu PDF','<div class="netscan-inline-msg">Génération du PDF…</div>','is-large','pdf');try{var r=await fetch(exportUrl(scope,'pdf',shareId,true),{cache:'no-store'});if(!r.ok)throw new Error(await r.text());var blob=await r.blob(),obj=URL.createObjectURL(blob),body=q('.netscan-popbody',w);body.innerHTML='<div class="netscan-pdf-shell"><div class="netscan-pdf-actions"><button class="netscan-btn netscan-btn--primary" data-pdf-save>Exporter sur le PC</button><button class="netscan-btn" data-pdf-print>Imprimer</button></div><div class="netscan-pdf-holder"><iframe class="netscan-pdf-frame" title="Aperçu PDF"></iframe></div></div>';var frame=q('iframe',w);frame.src=obj;q('[data-pdf-save]',w).addEventListener('click',function(){var a=document.createElement('a');a.href=obj;a.download='netscan_'+new Date().toISOString().replace(/[:.]/g,'-')+'.pdf';a.click();});q('[data-pdf-print]',w).addEventListener('click',function(){try{frame.contentWindow.focus();frame.contentWindow.print();}catch(e){}});q('[data-close]',w).addEventListener('click',function(){setTimeout(function(){URL.revokeObjectURL(obj);},1000);},{once:true});}catch(e){q('.netscan-popbody',w).innerHTML='<span class="netscan-empty">'+esc(e.message)+'</span>';}}
  function openExports(){var html='<div class="netscan-section-title"><div><h4>Centre d’export</h4><p>Aucun nouvel onglet : téléchargement direct ou aperçu PDF dans une fenêtre du dashboard.</p></div></div><div class="netscan-actions"><button class="netscan-btn" data-export="csv">CSV</button><button class="netscan-btn" data-export="json">JSON</button><button class="netscan-btn netscan-btn--primary" data-pdf>PDF / Impression</button></div>';var w=makeWin('Exports NetScan',html,'is-small','exports');w.addEventListener('click',function(e){var b=e.target.closest('[data-export]');if(b)downloadExport('scan',b.dataset.export,'');if(e.target.closest('[data-pdf]'))openPdf('scan','');});}
  async function openShares(){var w=makeWin('Partages NetScan','<div class="netscan-inline-msg">Chargement…</div>','is-large','shares');try{var data=await Promise.all([call('users_list',{}),call('shares_list',{})]),users=data[0].users||[],shares=data[1].shares||{};var body=q('.netscan-popbody',w);body.innerHTML='<div class="netscan-tabs"><button class="netscan-btn netscan-tab is-active" data-tab="new">Nouveau partage</button><button class="netscan-btn netscan-tab" data-tab="received">Reçus ('+(shares.received||[]).length+')</button><button class="netscan-btn netscan-tab" data-tab="sent">Envoyés ('+(shares.sent||[]).length+')</button></div><section class="netscan-tab-panel is-active" data-panel="new"><div class="netscan-form-grid"><label class="netscan-wide"><span>Titre</span><input data-share-title placeholder="Scan réseau bureau"></label></div><div class="netscan-user-list netscan-gap-top">'+users.map(function(u){return '<label class="netscan-user"><input type="checkbox" value="'+esc(u.email)+'"><span><strong>'+esc(u.name||u.email)+'</strong><small>'+esc(u.email)+'</small></span></label>';}).join('')+'</div><div class="netscan-actions"><label class="netscan-check"><input type="checkbox" data-share-export checked><span>Autoriser aussi l’export CSV / JSON / PDF</span></label><button class="netscan-btn netscan-btn--primary" data-share-create>Partager le dernier scan</button><span class="netscan-inline-msg" data-share-msg></span></div></section><section class="netscan-tab-panel" data-panel="received"><div class="netscan-list">'+shareListHtml(shares.received||[],'received')+'</div></section><section class="netscan-tab-panel" data-panel="sent"><div class="netscan-list">'+shareListHtml(shares.sent||[],'sent')+'</div></section>';bindTabs(body);q('[data-share-create]',body).addEventListener('click',async function(){var btn=this,rec=qa('.netscan-user input:checked',body).map(function(x){return x.value;}),msg=q('[data-share-msg]',body);btn.disabled=true;try{var j=await call('share_create',{title:q('[data-share-title]',body).value,recipients:rec,can_export:q('[data-share-export]',body).checked});msg.textContent=j.message;msg.className='netscan-inline-msg is-ok';setTimeout(function(){w.remove();syncSpacer();openShares();},500);}catch(e){msg.textContent=e.message;msg.className='netscan-inline-msg is-error';}finally{btn.disabled=false;}});body.addEventListener('click',async function(e){var open=e.target.closest('[data-share-open]');if(open){try{var j=await call('share_open',{share_id:open.dataset.shareOpen});openSharedScan(j.share);}catch(err){alert(err.message);}}var pdf=e.target.closest('[data-share-pdf]');if(pdf){openPdf('scan',pdf.dataset.sharePdf);}var revoke=e.target.closest('[data-share-revoke]');if(revoke){if(!confirm('Retirer ce partage ?'))return;try{await call('share_revoke',{share_id:revoke.dataset.shareRevoke});w.remove();syncSpacer();openShares();}catch(err){alert(err.message);}}});}catch(e){q('.netscan-popbody',w).innerHTML='<span class="netscan-empty">'+esc(e.message)+'</span>';}}
  function shareListHtml(list,type){return list.length?list.map(function(s){var p=s.my_permissions||{};return '<div class="netscan-list-item"><span><strong>'+esc(s.title||'NetScan')+'</strong><small>'+(type==='received'?'Par '+esc(s.owner):esc(Object.keys(s.permissions||{}).length)+' destinataire(s)')+' · '+esc(s.host_count||0)+' hôte(s) · '+esc(s.created_at||'')+'</small></span><span class="netscan-actions"><button class="netscan-btn" data-share-open="'+esc(s.id)+'">Ouvrir</button>'+(type==='received'&&p.export?'<button class="netscan-btn" data-share-pdf="'+esc(s.id)+'">PDF</button>':'')+(type==='sent'&&can('scan.share')?'<button class="netscan-btn netscan-btn--danger" data-share-revoke="'+esc(s.id)+'">Retirer</button>':'')+'</span></div>';}).join(''):'<span class="netscan-empty">Aucun partage.</span>';}
  function bindTabs(scope){scope.addEventListener('click',function(e){var b=e.target.closest('[data-tab]');if(!b)return;qa('[data-tab]',scope).forEach(function(x){x.classList.toggle('is-active',x===b);});qa('[data-panel]',scope).forEach(function(x){x.classList.toggle('is-active',x.dataset.panel===b.dataset.tab);});});}
  function openSharedScan(share){var list=share.scan&&Array.isArray(share.scan.results)?share.scan.results:[];var html='<div class="netscan-section-title"><div><h4>'+esc(share.title)+'</h4><p>Partagé par '+esc(share.owner)+' · '+list.length+' hôte(s)</p></div></div><div class="netscan-actions">'+(share.viewer_permissions&&share.viewer_permissions.export?'<button class="netscan-btn" data-shcsv>CSV</button><button class="netscan-btn" data-shjson>JSON</button><button class="netscan-btn netscan-btn--primary" data-shpdf>PDF</button>':'')+'</div><div class="netscan-table-wrap netscan-gap-top"><table class="netscan-table"><thead><tr><th>IP</th><th>Nom</th><th>MAC</th><th>OS</th><th>Services</th></tr></thead><tbody>'+list.map(function(r){return '<tr><td>'+esc(r.ip)+'</td><td>'+esc(r.host||'—')+'</td><td>'+esc(r.mac||'—')+'</td><td>'+esc(r.os_guess||'Inconnu')+'</td><td>'+badges(r.services)+'</td></tr>';}).join('')+'</tbody></table></div>';var w=makeWin('Partage · '+share.title,html,'is-large','shared-'+share.id);w.addEventListener('click',function(e){if(e.target.closest('[data-shcsv]'))downloadExport('scan','csv',share.id);if(e.target.closest('[data-shjson]'))downloadExport('scan','json',share.id);if(e.target.closest('[data-shpdf]'))openPdf('scan',share.id);});}
  async function openJobs(){var w=makeWin('Planification NetScan','<div class="netscan-inline-msg">Chargement…</div>','is-large','jobs');try{var j=await call('get_jobs',{}),jobs=j.jobs||[],body=q('.netscan-popbody',w);body.innerHTML='<div class="netscan-section-title"><div><h4>Jobs planifiés</h4><p>Le cron décide quand exécuter les jobs. “Exécuter maintenant” pose une demande ciblée, sans processus permanent.</p></div></div><div data-jobs></div><div class="netscan-actions"><button class="netscan-btn" data-add-job>+ Job</button><button class="netscan-btn netscan-btn--primary" data-save-jobs>Enregistrer</button><button class="netscan-btn" data-run-jobs>Exécuter maintenant</button><span class="netscan-inline-msg" data-job-msg></span></div>';var wrap=q('[data-jobs]',body);function drawJobs(){wrap.innerHTML=jobs.map(function(job,i){return '<div class="netscan-job" data-job="'+i+'"><label><span>Nom</span><input data-jname value="'+esc(job.name||'Scan planifié')+'"></label><label><span>CIDR</span><input data-jcidr value="'+esc((job.cidrs||[]).join(', '))+'"></label><label><span>Ports</span><input data-jports value="'+esc((job.ports||[]).join(','))+'"></label><label><span>Intervalle h</span><input type="number" min="1" max="720" data-jint value="'+esc(job.interval_h||24)+'"></label><label><span>Actif</span><select data-jen><option value="1" '+(job.enabled!==false?'selected':'')+'>Oui</option><option value="0" '+(job.enabled===false?'selected':'')+'>Non</option></select></label><button class="netscan-btn netscan-btn--danger" data-rm-job="'+i+'">×</button></div>';}).join('')||'<span class="netscan-empty">Aucun job.</span>';}
    function collect(){jobs=qa('[data-job]',wrap).map(function(el){var old=jobs[Number(el.dataset.job)]||{};return {id:old.id||'',name:q('[data-jname]',el).value,cidrs:q('[data-jcidr]',el).value.split(',').map(function(x){return x.trim();}),ports:q('[data-jports]',el).value.split(',').map(Number),interval_h:Number(q('[data-jint]',el).value)||24,enabled:q('[data-jen]',el).value==='1',resolve:true,deep:false,max_hosts:4096,last_run:old.last_run||null};});return jobs;}
    drawJobs();body.addEventListener('click',async function(e){var rm=e.target.closest('[data-rm-job]');if(rm){collect();jobs.splice(Number(rm.dataset.rmJob),1);drawJobs();return;}if(e.target.closest('[data-add-job]')){collect();jobs.push({id:'',name:'Scan planifié',cidrs:[q('[data-cidrs]').value.split(',')[0].trim()],ports:[22,80,443],interval_h:24,enabled:true,resolve:true,deep:false,max_hosts:4096});drawJobs();return;}if(e.target.closest('[data-save-jobs]')){try{var x=await call('save_jobs',{jobs:collect()});q('[data-job-msg]',body).textContent=x.message;jobs=x.jobs||jobs;drawJobs();}catch(err){q('[data-job-msg]',body).textContent=err.message;}}if(e.target.closest('[data-run-jobs]')){try{var y=await call('run_jobs',{});q('[data-job-msg]',body).textContent=y.message;}catch(err){q('[data-job-msg]',body).textContent=err.message;}}});
  }catch(e){q('.netscan-popbody',w).innerHTML='<span class="netscan-empty">'+esc(e.message)+'</span>';}}
  async function showArp(){try{setMsg('Lecture ARP…');var j=await call('arp',{});var html='<div class="netscan-table-wrap"><table class="netscan-table"><thead><tr><th>IP</th><th>MAC</th></tr></thead><tbody>'+j.entries.map(function(a){return '<tr><td>'+esc(a.ip)+'</td><td>'+esc(a.mac)+'</td></tr>';}).join('')+'</tbody></table></div>';makeWin('Table ARP locale',html,'is-small','arp');setMsg(j.message,'ok');}catch(e){setMsg(e.message,'error');}}
  function collectScanForm(){return {cidrs:q('[data-cidrs]').value,ports:q('[data-ports]').value,resolve:q('[data-resolve]').checked,deep:q('[data-deep]').checked,max_hosts:Number(q('[data-max]').value)||4096};}
  async function saveConfig(){try{var j=await call('save_config',collectScanForm());setMsg(j.message,'ok');}catch(e){setMsg(e.message,'error');}}
  async function startScan(){if(state.running)return;state.running=true;setStatus('Initialisation');setProgress(0);setMsg('Initialisation du scan…');var startBtn=q('[data-start]'),stopBtn=q('[data-stop]');if(startBtn)startBtn.disabled=true;if(stopBtn)stopBtn.disabled=false;try{var j=await call('start',collectScanForm());state.stateId=j.state.id;await scanLoop();}catch(e){setMsg(e.message,'error');setStatus('Erreur');finishRun();}}
  async function scanLoop(){while(state.running&&state.stateId){try{var j=await call('step',{state_id:state.stateId}),s=j.state;setProgress(s.progress);q('[data-count]').textContent=s.found;setStatus(s.stopped?'Arrêté':(s.finished?'Terminé':'Scan '+s.done+'/'+s.total));setMsg(s.done+'/'+s.total+' traités · '+s.found+' hôte(s) détecté(s)');if(s.finished){var x=await call('status',{state_id:state.stateId});state.scan=x.scan||state.scan;if(!x.scan||!Array.isArray(x.scan.results)){var boot=await call('bootstrap',{});state.scan=boot.scan||state.scan;}renderPreview();setProgress(100);setMsg(s.stopped?'Scan arrêté.':'Scan terminé.','ok');finishRun();break;}}catch(e){setMsg(e.message,'error');setStatus('Erreur');finishRun();break;}}
  }
  function finishRun(){state.running=false;var startBtn=q('[data-start]'),stopBtn=q('[data-stop]');if(startBtn)startBtn.disabled=false;if(stopBtn)stopBtn.disabled=true;}
  async function stopScan(){if(!state.stateId)return;try{await call('stop',{state_id:state.stateId});state.running=false;setStatus('Arrêté');setMsg('Scan arrêté.','ok');finishRun();}catch(e){setMsg(e.message,'error');}}
  root.addEventListener('click',function(e){var open=e.target.closest('[data-open]');if(open){var k=open.dataset.open;if(k==='results')openResults();if(k==='actionhub')openActionHub();if(k==='logs')openLogs();if(k==='shares')openShares();if(k==='exports')openExports();if(k==='jobs')openJobs();return;}var host=e.target.closest('[data-host]');if(host){var r=findHost(host.dataset.host);if(r)openHost(r);return;}if(e.target.closest('[data-save]'))saveConfig();if(e.target.closest('[data-start]'))startScan();if(e.target.closest('[data-stop]'))stopScan();if(e.target.closest('[data-arp]'))showArp();if(e.target.closest('[data-infra]')){(async function(){try{setMsg('Envoi vers Infra…');var j=await call('push_infra',{});setMsg(j.message,j.ok?'ok':'error');}catch(err){setMsg(err.message,'error');}})();}});
  renderPreview();decorate(root);window.addEventListener('resize',syncSpacer);
})();
</script>
