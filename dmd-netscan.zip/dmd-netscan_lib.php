<?php
/**
 * NetScan for DoMyDesk 1.2.0
 * Shared runtime helpers. PHP 7.3 compatible.
 */
if (session_status() === PHP_SESSION_NONE && PHP_SAPI !== 'cli') { session_start(); }

if (!defined('NETSCAN_MODULE_ID')) define('NETSCAN_MODULE_ID', 'dmd-netscan');
if (!defined('NETSCAN_MODULE_VERSION')) define('NETSCAN_MODULE_VERSION', '1.2.0');
if (!defined('NETSCAN_ROOT')) {
    $root = realpath(__DIR__ . '/../..');
    define('NETSCAN_ROOT', $root ?: dirname(__DIR__, 2));
}

foreach (array(NETSCAN_ROOT . '/core/dmd_permissions.php', NETSCAN_ROOT . '/core/dmd_system_services.php', NETSCAN_ROOT . '/core/dmd_quick_session.php') as $coreFile) {
    if (is_file($coreFile)) { require_once $coreFile; }
}

function ns_now() { return date('Y-m-d H:i:s'); }
function ns_iso_now() { return date('c'); }
function ns_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function ns_email() {
    return trim((string)(isset($_SESSION['user']['email']) ? $_SESSION['user']['email'] : (isset($_SESSION['email']) ? $_SESSION['email'] : (isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''))));
}
function ns_role() {
    $role = strtolower(trim((string)(isset($_SESSION['user']['role_system']) ? $_SESSION['user']['role_system'] : (isset($_SESSION['role_system']) ? $_SESSION['role_system'] : (isset($_SESSION['user']['role']) ? $_SESSION['user']['role'] : '')))));
    return $role;
}
function ns_is_admin() { return in_array(ns_role(), array('admin','administrator','superadmin'), true); }
function ns_safe_user_key($email) {
    if (function_exists('dmd_safe_user_key')) return dmd_safe_user_key($email);
    $email = trim((string)$email);
    return preg_replace('/[^a-zA-Z0-9@._+\-]/', '_', $email);
}
function ns_profile_exists($email) {
    $email = ns_safe_user_key($email);
    return $email !== '' && is_dir(NETSCAN_ROOT . '/users/profiles/' . $email);
}
function ns_user_root($email) { return NETSCAN_ROOT . '/users/profiles/' . ns_safe_user_key($email) . '/dmd-netscan'; }
function ns_system_root() { return NETSCAN_ROOT . '/data/modules/dmd-netscan'; }
function ns_mkdir($dir) {
    if (is_dir($dir)) return true;
    return @mkdir($dir, 0775, true) || is_dir($dir);
}
function ns_private_dir($dir) {
    if (!ns_mkdir($dir)) return false;
    $ht = rtrim($dir, '/\\') . '/.htaccess';
    if (!is_file($ht)) @file_put_contents($ht, "Require all denied\nOrder allow,deny\nDeny from all\nOptions -Indexes\n", LOCK_EX);
    return true;
}
function ns_boot_user_storage($email) {
    $root = ns_user_root($email);
    ns_private_dir($root);
    foreach (array('states','history','logs') as $d) ns_private_dir($root . '/' . $d);
    return $root;
}
function ns_boot_system_storage() {
    $root = ns_system_root();
    ns_private_dir($root);
    foreach (array('shares','share-index','actionhub','activity','activity-index','notification-outbox','secrets') as $d) ns_private_dir($root . '/' . $d);
    return $root;
}
function ns_json_read($file, $default) {
    if (!is_file($file)) return $default;
    $raw = @file_get_contents($file);
    if ($raw === false) return $default;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $default;
}
function ns_json_write($file, $data) {
    if (!ns_private_dir(dirname($file))) return false;
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;
    $tmp = $file . '.tmp.' . bin2hex(random_bytes(3));
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    if (@rename($tmp, $file)) return true;
    @unlink($tmp);
    return false;
}
function ns_jsonl_append($file, $row) {
    if (!ns_private_dir(dirname($file))) return false;
    $line = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return $line !== false && @file_put_contents($file, $line . "\n", FILE_APPEND | LOCK_EX) !== false;
}
function ns_csrf() {
    if (PHP_SAPI === 'cli') return '';
    if (empty($_SESSION['netscan_csrf'])) $_SESSION['netscan_csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['netscan_csrf'];
}
function ns_csrf_check($token) {
    if (PHP_SAPI === 'cli') return true;
    return isset($_SESSION['netscan_csrf']) && is_string($token) && hash_equals($_SESSION['netscan_csrf'], $token);
}
function ns_require_login() {
    $email = ns_email();
    if ($email === '') { http_response_code(403); exit('Connexion requise.'); }
    return $email;
}
function ns_can($permission, $email) {
    $email = $email ?: ns_email();
    if ($email === '') return false;
    if (function_exists('dmd_user_has_module_permission')) {
        return (bool)dmd_user_has_module_permission($email, NETSCAN_MODULE_ID, $permission);
    }
    if (ns_is_admin()) return true;
    return !in_array($permission, array('logs.delete','scan.share.manage','config.edit'), true);
}
function ns_require($permission) {
    $email = ns_require_login();
    if (function_exists('dmd_require_module_access')) {
        dmd_require_module_access(NETSCAN_MODULE_ID, $permission);
        return $email;
    }
    if (!ns_can($permission, $email)) { http_response_code(403); exit('Accès refusé.'); }
    return $email;
}
function ns_permissions_snapshot($email) {
    $list = array('module.view','scan.configure','scan.start','scan.stop','scan.arp','scan.jobs','scan.export','scan.share','scan.share.manage','logs.view','logs.export','logs.delete','infra.push','config.edit','actionhub.use','quicksession.use');
    $out = array();
    foreach ($list as $p) $out[$p] = ns_can($p, $email);
    return $out;
}
function ns_default_config() {
    return array(
        'schema'=>2,
        'cidrs'=>array('192.168.0.0/24'),
        'ports'=>array(22,80,443),
        'resolve'=>true,
        'deep'=>true,
        'max_hosts'=>4096,
        'infra'=>array('mode'=>'none','filedrop_path'=>'','webhook_url'=>'','webhook_token_enc'=>''),
        'jobs'=>array(),
        'updated_at'=>null
    );
}
function ns_clean_ports($raw) {
    if (is_string($raw)) $raw = preg_split('/[,;\s]+/', trim($raw));
    if (!is_array($raw)) $raw = array();
    $ports = array();
    foreach ($raw as $p) {
        $p = (int)$p;
        if ($p >= 1 && $p <= 65535 && !in_array($p, $ports, true)) $ports[] = $p;
        if (count($ports) >= 128) break;
    }
    sort($ports, SORT_NUMERIC);
    return $ports;
}
function ns_clean_cidrs($raw) {
    if (is_string($raw)) $raw = preg_split('/[,;\r\n]+/', $raw);
    if (!is_array($raw)) $raw = array();
    $out = array();
    foreach ($raw as $cidr) {
        $cidr = trim((string)$cidr);
        if ($cidr === '') continue;
        if (strpos($cidr, '/') === false && filter_var($cidr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) $cidr .= '/32';
        if (!preg_match('~^(\d{1,3}(?:\.\d{1,3}){3})/(\d{1,2})$~', $cidr, $m)) continue;
        if (!filter_var($m[1], FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) continue;
        $mask = (int)$m[2];
        if ($mask < 0 || $mask > 32) continue;
        if (!in_array($cidr, $out, true)) $out[] = $cidr;
        if (count($out) >= 32) break;
    }
    return $out;
}
function ns_clean_jobs($jobs) {
    if (!is_array($jobs)) return array();
    $out = array();
    foreach ($jobs as $job) {
        if (!is_array($job)) continue;
        $cidrs = ns_clean_cidrs(isset($job['cidrs']) ? $job['cidrs'] : array());
        if (!$cidrs) continue;
        $ports = ns_clean_ports(isset($job['ports']) ? $job['ports'] : array(22,80,443));
        if (!$ports) $ports = array(22,80,443);
        $out[] = array(
            'id'=>preg_match('/^[a-f0-9]{8,32}$/', (string)(isset($job['id']) ? $job['id'] : '')) ? $job['id'] : bin2hex(random_bytes(5)),
            'name'=>substr(trim((string)(isset($job['name']) ? $job['name'] : 'Scan planifié')), 0, 80),
            'cidrs'=>$cidrs,
            'ports'=>$ports,
            'resolve'=>!empty($job['resolve']),
            'deep'=>!empty($job['deep']),
            'max_hosts'=>max(16, min(4096, (int)(isset($job['max_hosts']) ? $job['max_hosts'] : 4096))),
            'interval_h'=>max(1, min(720, (int)(isset($job['interval_h']) ? $job['interval_h'] : 24))),
            'enabled'=>array_key_exists('enabled', $job) ? !empty($job['enabled']) : true,
            'last_run'=>isset($job['last_run']) ? $job['last_run'] : null
        );
        if (count($out) >= 50) break;
    }
    return $out;
}
function ns_config_clean($cfg) {
    $def = ns_default_config();
    if (!is_array($cfg)) $cfg = array();
    $out = $def;
    $cidrs = ns_clean_cidrs(isset($cfg['cidrs']) ? $cfg['cidrs'] : $def['cidrs']);
    $out['cidrs'] = $cidrs ? $cidrs : $def['cidrs'];
    $ports = ns_clean_ports(isset($cfg['ports']) ? $cfg['ports'] : $def['ports']);
    $out['ports'] = $ports ? $ports : $def['ports'];
    $out['resolve'] = array_key_exists('resolve', $cfg) ? !empty($cfg['resolve']) : true;
    $out['deep'] = array_key_exists('deep', $cfg) ? !empty($cfg['deep']) : true;
    $out['max_hosts'] = max(16, min(4096, (int)(isset($cfg['max_hosts']) ? $cfg['max_hosts'] : 4096)));
    $infra = isset($cfg['infra']) && is_array($cfg['infra']) ? $cfg['infra'] : array();
    $mode = isset($infra['mode']) ? strtolower(trim((string)$infra['mode'])) : 'none';
    if (!in_array($mode, array('none','filedrop','webhook'), true)) $mode = 'none';
    $out['infra'] = array(
        'mode'=>$mode,
        'filedrop_path'=>trim((string)(isset($infra['filedrop_path']) ? $infra['filedrop_path'] : '')),
        'webhook_url'=>trim((string)(isset($infra['webhook_url']) ? $infra['webhook_url'] : '')),
        'webhook_token_enc'=>trim((string)(isset($infra['webhook_token_enc']) ? $infra['webhook_token_enc'] : ''))
    );
    $out['jobs'] = ns_clean_jobs(isset($cfg['jobs']) ? $cfg['jobs'] : array());
    $out['updated_at'] = isset($cfg['updated_at']) ? $cfg['updated_at'] : null;
    return $out;
}
function ns_migrate_legacy($email) {
    $root = ns_boot_user_storage($email);
    $marker = $root . '/.migration_v2.json';
    if (is_file($marker)) return;
    $legacyCfg = NETSCAN_ROOT . '/users/profiles/' . ns_safe_user_key($email) . '/netscan.json';
    $report = array('at'=>ns_iso_now(),'config'=>false,'last_results'=>false,'history'=>0);
    if (is_file($legacyCfg) && !is_file($root . '/config.json')) {
        $old = ns_json_read($legacyCfg, array());
        if ($old) {
            $cfg = ns_config_clean($old);
            $legacyToken = isset($old['infra']['webhook_token']) ? trim((string)$old['infra']['webhook_token']) : '';
            if ($legacyToken !== '' && empty($cfg['infra']['webhook_token_enc'])) {
                $cfg['infra']['webhook_token_enc'] = ns_encrypt_secret($legacyToken);
            }
            ns_json_write($root . '/config.json', $cfg);
            $report['config'] = true;
            if (!empty($old['last_results']) && is_array($old['last_results'])) {
                $scan = array('schema'=>2,'id'=>'legacy-' . date('YmdHis'),'source'=>'migration','cidrs'=>$cfg['cidrs'],'ports'=>$cfg['ports'],'started_at'=>null,'finished_at'=>ns_iso_now(),'duration_s'=>null,'results'=>array_values($old['last_results']));
                ns_json_write($root . '/last_scan.json', $scan);
                $report['last_results'] = true;
            }
        }
    }
    $legacyHist = NETSCAN_ROOT . '/users/profiles/' . ns_safe_user_key($email) . '/netscan_history';
    if (is_dir($legacyHist)) {
        $files = glob($legacyHist . '/*.json');
        if (is_array($files)) foreach ($files as $file) {
            $target = $root . '/history/legacy_' . basename($file);
            if (!is_file($target) && @copy($file, $target)) $report['history']++;
        }
    }
    ns_json_write($marker, $report);
}
function ns_load_config($email) {
    ns_migrate_legacy($email);
    $file = ns_user_root($email) . '/config.json';
    if (!is_file($file)) ns_json_write($file, ns_default_config());
    return ns_config_clean(ns_json_read($file, ns_default_config()));
}
function ns_save_config($email, $cfg) {
    ns_boot_user_storage($email);
    $cfg = ns_config_clean($cfg);
    $cfg['updated_at'] = ns_iso_now();
    return ns_json_write(ns_user_root($email) . '/config.json', $cfg) ? $cfg : false;
}
function ns_last_scan($email) {
    ns_migrate_legacy($email);
    return ns_json_read(ns_user_root($email) . '/last_scan.json', array('schema'=>2,'id'=>'','results'=>array()));
}
function ns_public_config($cfg) {
    $out = $cfg;
    if (isset($out['infra']['webhook_token_enc'])) {
        $out['infra']['webhook_token_saved'] = $out['infra']['webhook_token_enc'] !== '';
        unset($out['infra']['webhook_token_enc']);
    }
    return $out;
}
function ns_secret_key() {
    $file = ns_boot_system_storage() . '/secrets/module.key';
    if (!is_file($file)) {
        $key = base64_encode(random_bytes(32));
        if (@file_put_contents($file, $key, LOCK_EX) === false) return '';
        @chmod($file, 0600);
    }
    $raw = trim((string)@file_get_contents($file));
    $key = base64_decode($raw, true);
    return is_string($key) && strlen($key) === 32 ? $key : '';
}
function ns_encrypt_secret($plain) {
    $plain = (string)$plain;
    if ($plain === '') return '';
    if (!function_exists('openssl_encrypt')) return '';
    $key = ns_secret_key(); if ($key === '') return '';
    $iv = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
    if ($cipher === false) return '';
    return 'gcm:' . base64_encode($iv . $tag . $cipher);
}
function ns_decrypt_secret($enc) {
    $enc = (string)$enc;
    if (strpos($enc, 'gcm:') !== 0 || !function_exists('openssl_decrypt')) return '';
    $raw = base64_decode(substr($enc, 4), true);
    if (!is_string($raw) || strlen($raw) < 29) return '';
    $key = ns_secret_key(); if ($key === '') return '';
    $iv = substr($raw, 0, 12); $tag = substr($raw, 12, 16); $cipher = substr($raw, 28);
    $plain = openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
    return $plain === false ? '' : $plain;
}
function ns_core_log_try($email, $action, $target, $result, $details, $resource) {
    if (!function_exists('dmd_log_action')) return false;
    try {
        $rf = new ReflectionFunction('dmd_log_action');
        $args = array();
        foreach ($rf->getParameters() as $p) {
            $n = strtolower($p->getName());
            $set = true; $value = null;
            if (strpos($n, 'module') !== false) $value = NETSCAN_MODULE_ID;
            elseif (strpos($n, 'email') !== false || $n === 'user' || strpos($n, 'actor') !== false || strpos($n, 'utilisateur') !== false) $value = $email;
            elseif ($n === 'role' || strpos($n, 'role_') !== false) $value = ns_role();
            elseif ($n === 'action' || strpos($n, 'event') !== false) $value = $action;
            elseif (strpos($n, 'target') !== false || strpos($n, 'cible') !== false || strpos($n, 'subject') !== false) $value = $target;
            elseif ($n === 'result' || strpos($n, 'status') !== false || strpos($n, 'outcome') !== false || strpos($n, 'resultat') !== false) $value = $result;
            elseif (strpos($n, 'resource') !== false || strpos($n, 'ressource') !== false) $value = $resource;
            elseif (strpos($n, 'detail') !== false || strpos($n, 'meta') !== false || strpos($n, 'extra') !== false || $n === 'data') $value = $details;
            elseif ($n === 'context' || strpos($n, 'contexte') !== false) $value = $resource !== null ? $resource : $details;
            elseif ($n === 'ip' || strpos($n, 'remote_addr') !== false) $value = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';
            elseif (strpos($n, 'date') !== false || strpos($n, 'time') !== false) $value = ns_iso_now();
            elseif (strpos($n, 'message') !== false || strpos($n, 'description') !== false) $value = $action . ($target !== '' ? ' · ' . $target : '');
            else $set = false;
            if (!$set) {
                if ($p->isDefaultValueAvailable() || $p->isOptional()) continue;
                return false;
            }
            $args[] = $value;
        }
        $rf->invokeArgs($args);
        return true;
    } catch (Throwable $e) { return false; }
}

function ns_log($email, $action, $target, $result, $details, $resource) {
    $email = $email ?: ns_email();
    if (!is_array($details)) $details = array('message'=>(string)$details);
    if (!is_array($resource)) $resource = null;
    unset($details['webhook_token'], $details['webhook_token_enc'], $details['token'], $details['password']);
    $row = array('datetime'=>ns_iso_now(),'timestamp'=>time(),'module'=>NETSCAN_MODULE_ID,'user'=>$email,'action'=>$action,'target'=>(string)$target,'result'=>(string)$result,'details'=>$details,'resource'=>$resource);
    ns_core_log_try($email, $action, (string)$target, (string)$result, $details, $resource);
    ns_boot_user_storage($email);
    ns_jsonl_append(ns_user_root($email) . '/logs/' . date('Y-m-d') . '.jsonl', $row);
    ns_activity_emit($email, $row);
    return $row;
}
function ns_activity_emit($email, $row) {
    $root = ns_boot_system_storage();
    $event = array('datetime'=>$row['datetime'],'module'=>NETSCAN_MODULE_ID,'user'=>$email,'action'=>$row['action'],'result'=>$row['result'],'resource'=>$row['resource'],'target'=>$row['target']);
    ns_jsonl_append($root . '/activity/' . date('Y-m-d') . '.jsonl', $event);
    if (!empty($row['resource']['type']) && !empty($row['resource']['id'])) {
        $key = hash('sha256', $row['resource']['type'] . ':' . $row['resource']['id']);
        $file = $root . '/activity-index/' . $key . '.json';
        $index = ns_json_read($file, array('resource'=>$row['resource'],'events'=>array()));
        $index['resource'] = $row['resource'];
        $index['events'][] = $event;
        if (count($index['events']) > 100) $index['events'] = array_slice($index['events'], -100);
        ns_json_write($file, $index);
    }
}
function ns_read_logs($email, $days, $limit) {
    ns_boot_user_storage($email);
    $days = max(1, min(90, (int)$days)); $limit = max(1, min(2000, (int)$limit)); $rows = array();
    for ($i=0; $i<$days; $i++) {
        $file = ns_user_root($email) . '/logs/' . date('Y-m-d', time() - $i*86400) . '.jsonl';
        if (!is_file($file)) continue;
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) continue;
        for ($n=count($lines)-1; $n>=0; $n--) {
            $row = json_decode($lines[$n], true);
            if (is_array($row)) $rows[] = $row;
            if (count($rows) >= $limit) break 2;
        }
    }
    return $rows;
}
function ns_delete_logs($email) {
    $dir = ns_user_root($email) . '/logs'; $count = 0;
    $files = is_dir($dir) ? glob($dir . '/*.jsonl') : array();
    if (is_array($files)) foreach ($files as $file) if (@unlink($file)) $count++;
    return $count;
}
function ns_core_notify_try($recipient, $title, $message, $level, $meta) {
    $names = array('dmd_notification_add','dmd_notification_create','dmd_create_notification','dmd_push_notification','dmd_notify_user');
    foreach ($names as $name) {
        if (!function_exists($name)) continue;
        try {
            $rf = new ReflectionFunction($name); $args = array(); $ok = true;
            foreach ($rf->getParameters() as $p) {
                $n = strtolower($p->getName()); $valueSet = true; $value = null;
                if (strpos($n,'email') !== false || strpos($n,'recipient') !== false || strpos($n,'user') !== false || strpos($n,'target') !== false) $value = $recipient;
                elseif (strpos($n,'title') !== false || strpos($n,'subject') !== false) $value = $title;
                elseif (strpos($n,'message') !== false || strpos($n,'body') !== false || strpos($n,'content') !== false || strpos($n,'text') !== false) $value = $message;
                elseif ($n === 'level' || strpos($n,'severity') !== false) $value = $level;
                elseif ($n === 'type' || strpos($n,'category') !== false) $value = 'module';
                elseif (strpos($n,'module') !== false) $value = NETSCAN_MODULE_ID;
                elseif (strpos($n,'actor') !== false || strpos($n,'sender') !== false) $value = ns_email();
                elseif (strpos($n,'meta') !== false || strpos($n,'detail') !== false || strpos($n,'data') !== false || strpos($n,'extra') !== false) $value = $meta;
                elseif (strpos($n,'url') !== false || strpos($n,'link') !== false) $value = '';
                else $valueSet = false;
                if (!$valueSet) {
                    if ($p->isDefaultValueAvailable()) continue;
                    if ($p->isOptional()) continue;
                    $ok = false; break;
                }
                $args[] = $value;
            }
            if ($ok) { $rf->invokeArgs($args); return true; }
        } catch (Throwable $e) { }
    }
    return false;
}
function ns_notify($recipient, $title, $message, $level, $meta) {
    $recipient = trim((string)$recipient); if ($recipient === '') return false;
    if (!is_array($meta)) $meta = array();
    $delivered = ns_core_notify_try($recipient, $title, $message, $level, $meta);
    $row = array('datetime'=>ns_iso_now(),'recipient'=>$recipient,'actor'=>ns_email(),'module'=>NETSCAN_MODULE_ID,'title'=>$title,'message'=>$message,'level'=>$level,'meta'=>$meta,'delivered_core'=>$delivered);
    ns_jsonl_append(ns_boot_system_storage() . '/notification-outbox/' . hash('sha256',$recipient) . '.jsonl', $row);
    return $delivered;
}
function ns_list_users($current) {
    $root = NETSCAN_ROOT . '/users/profiles'; $out = array();
    $dirs = is_dir($root) ? glob($root . '/*', GLOB_ONLYDIR) : array();
    if (!is_array($dirs)) return $out;
    foreach ($dirs as $dir) {
        $email = basename($dir); if ($email === ns_safe_user_key($current)) continue;
        $profile = ns_json_read($dir . '/profile/profile.json', array());
        if (!$profile) $profile = ns_json_read($dir . '/profile.json', array());
        $realEmail = trim((string)(isset($profile['email']) ? $profile['email'] : $email));
        $name = trim((string)((isset($profile['prenom']) ? $profile['prenom'] : '') . ' ' . (isset($profile['nom']) ? $profile['nom'] : '')));
        if ($name === '') $name = trim((string)(isset($profile['pseudo']) ? $profile['pseudo'] : $realEmail));
        $out[] = array('email'=>$realEmail,'name'=>$name);
    }
    usort($out, function($a,$b){ return strcasecmp($a['name'], $b['name']); });
    return $out;
}
function ns_share_index_file($email) { return ns_boot_system_storage() . '/share-index/' . hash('sha256', strtolower(trim((string)$email))) . '.json'; }
function ns_share_index($email) { return ns_json_read(ns_share_index_file($email), array('email'=>$email,'received'=>array(),'sent'=>array())); }
function ns_share_index_add($email, $field, $id) {
    $idx = ns_share_index($email); if (!isset($idx[$field]) || !is_array($idx[$field])) $idx[$field] = array();
    if (!in_array($id,$idx[$field],true)) $idx[$field][]=$id;
    ns_json_write(ns_share_index_file($email), $idx);
}
function ns_share_index_remove($email, $field, $id) {
    $idx = ns_share_index($email); $list = isset($idx[$field]) && is_array($idx[$field]) ? $idx[$field] : array();
    $idx[$field] = array_values(array_diff($list, array($id))); ns_json_write(ns_share_index_file($email), $idx);
}
function ns_share_file($id) { return ns_boot_system_storage() . '/shares/' . preg_replace('/[^a-f0-9\-]/','',(string)$id) . '.json'; }
function ns_create_share($owner, $title, $recipients, $canExport) {
    $scan = ns_last_scan($owner); if (empty($scan['results'])) return array(false,'Aucun scan à partager.',null);
    if (!is_array($recipients)) $recipients = array();
    $perms = array();
    foreach ($recipients as $recipient) {
        $recipient = trim((string)$recipient);
        if ($recipient === '' || strcasecmp($recipient,$owner)===0 || !ns_profile_exists($recipient)) continue;
        $perms[$recipient] = array('view'=>true,'export'=>!empty($canExport));
        if (count($perms) >= 50) break;
    }
    if (!$perms) return array(false,'Aucun utilisateur valide sélectionné.',null);
    $id = bin2hex(random_bytes(12));
    $share = array('schema'=>1,'id'=>$id,'title'=>substr(trim((string)$title),0,120),'owner'=>$owner,'created_at'=>ns_iso_now(),'updated_at'=>ns_iso_now(),'permissions'=>$perms,'scan'=>$scan);
    if ($share['title']==='') $share['title']='Scan réseau ' . date('d/m/Y H:i');
    if (!ns_json_write(ns_share_file($id),$share)) return array(false,'Impossible d’enregistrer le partage.',null);
    ns_share_index_add($owner,'sent',$id);
    foreach ($perms as $recipient=>$p) {
        ns_share_index_add($recipient,'received',$id);
        ns_notify($recipient,'NetScan partagé',$owner . ' a partagé « ' . $share['title'] . ' » avec vous.','info',array('share_id'=>$id,'can_export'=>$p['export']));
    }
    ns_log($owner,'share.create',$id,'success',array('title'=>$share['title'],'recipients'=>array_keys($perms),'can_export'=>!empty($canExport)),array('type'=>'network_scan','id'=>$scan['id'],'name'=>$share['title']));
    return array(true,'Partage créé.',$share);
}
function ns_share_permission_for($share, $viewer) {
    $viewer = trim((string)$viewer);
    if ($viewer === '' || !isset($share['permissions']) || !is_array($share['permissions'])) return null;
    foreach ($share['permissions'] as $recipient => $permission) {
        if (strcasecmp((string)$recipient, $viewer) === 0 && is_array($permission)) return $permission;
    }
    return null;
}
function ns_get_share($id, $viewer, $needExport) {
    $share = ns_json_read(ns_share_file($id), array()); if (!$share) return null;
    if (strcasecmp((string)$share['owner'],(string)$viewer)===0) return $share;
    $p = ns_share_permission_for($share, $viewer);
    if (!is_array($p) || empty($p['view'])) return null;
    if ($needExport && empty($p['export'])) return null;
    return $share;
}
function ns_list_shares($email) {
    $idx = ns_share_index($email); $out = array('received'=>array(),'sent'=>array());
    foreach (array('received','sent') as $field) {
        $ids = isset($idx[$field]) && is_array($idx[$field]) ? $idx[$field] : array();
        foreach ($ids as $id) {
            $s = ns_json_read(ns_share_file($id), array()); if (!$s) continue;
            $copy = $s; unset($copy['scan']['results']); $copy['host_count'] = isset($s['scan']['results']) && is_array($s['scan']['results']) ? count($s['scan']['results']) : 0;
            if ($field==='received') { $mine = ns_share_permission_for($s, $email); $copy['my_permissions'] = is_array($mine) ? $mine : array(); }
            $out[$field][]=$copy;
        }
    }
    return $out;
}
function ns_revoke_share($owner, $id) {
    $share = ns_json_read(ns_share_file($id), array());
    if (!$share || strcasecmp((string)(isset($share['owner'])?$share['owner']:''),$owner)!==0) return array(false,'Partage introuvable.');
    foreach ((array)$share['permissions'] as $recipient=>$p) {
        ns_share_index_remove($recipient,'received',$id);
        ns_notify($recipient,'Partage NetScan retiré',$owner . ' a retiré le partage « ' . (isset($share['title'])?$share['title']:'NetScan') . ' ».','warning',array('share_id'=>$id));
    }
    ns_share_index_remove($owner,'sent',$id); @unlink(ns_share_file($id));
    ns_log($owner,'share.revoke',$id,'success',array('title'=>isset($share['title'])?$share['title']:''),null);
    return array(true,'Partage retiré.');
}
function ns_cidr_to_list($cidr, $max) {
    $cidr = trim((string)$cidr); $max=max(1,(int)$max);
    if (strpos($cidr,'/')===false) $cidr.='/32';
    $parts=explode('/',$cidr,2); if(count($parts)!==2) return array();
    $ip=$parts[0]; $mask=(int)$parts[1]; $l=ip2long($ip); if($l===false||$mask<0||$mask>32)return array();
    $hostBits=32-$mask; $size=$hostBits===32 ? 4294967296 : pow(2,$hostBits); $net=$l & (-1 << $hostBits);
    $start=$net; $end=$net+$size-1; if($mask<=30){$start++;$end--;}
    $out=array(); for($i=$start;$i<=$end && count($out)<$max;$i++) $out[]=long2ip($i); return $out;
}
function ns_ping_ttl($ip) {
    $out=array();$ret=1;
    if(strncasecmp(PHP_OS,'WIN',3)===0) @exec('ping -n 1 -w 800 '.escapeshellarg($ip),$out,$ret);
    else @exec('ping -c 1 -W 1 '.escapeshellarg($ip),$out,$ret);
    $txt=implode("\n",$out);$ttl=null;$timeMs=null;
    if(preg_match('/ttl[=:\s](\d+)/i',$txt,$m))$ttl=(int)$m[1];
    if(preg_match('/time[=<]\s*([\d\.]+)\s*ms/i',$txt,$m))$timeMs=(float)$m[1];
    return array($ret===0,$ttl,$timeMs);
}
function ns_reverse_host($ip){$h=@gethostbyaddr($ip);return($h&&$h!==$ip)?$h:'';}
function ns_tcp_banner($ip,$port,$timeout){
    $errno=0;$errstr='';$t=microtime(true);$fp=@fsockopen($ip,(int)$port,$errno,$errstr,(float)$timeout);$ms=(int)round((microtime(true)-$t)*1000);
    if(!$fp)return array(false,'',$ms,$errstr);
    stream_set_timeout($fp,0,250000);
    if(!in_array((int)$port,array(25,110,143,21,22,23),true)) @fwrite($fp,"HEAD / HTTP/1.0\r\nHost: $ip\r\n\r\n");
    $data=@fread($fp,512);@fclose($fp);$banner='';
    if(is_string($data)&&$data!=='')$banner=trim((string)preg_replace('/[\x00-\x1F\x7F]+/',' ',substr($data,0,160)));
    return array(true,$banner,$ms,'');
}
function ns_udp53_probe($ip,$timeout){
    $errno=0;$errstr='';$sock=@stream_socket_client('udp://'.$ip.':53',$errno,$errstr,(float)$timeout);if(!$sock)return array(false,$errstr);
    stream_set_timeout($sock,0,250000);$id=random_int(0,65535);$hdr=pack('nnnnnn',$id,0x0100,1,0,0,0);$q='';foreach(explode('.','example.com')as$p)$q.=chr(strlen($p)).$p;$q.="\0".pack('nn',1,1);@fwrite($sock,$hdr.$q);$r=@fread($sock,512);@fclose($sock);return array(is_string($r)&&strlen($r)>=12,'');
}
function ns_guess_os($ttl,$openPorts,$banners){
    $scores=array('Windows'=>0,'Linux/Unix'=>0,'Network/Appliance'=>0);
    if($ttl!==null){if($ttl>=110&&$ttl<200)$scores['Windows']+=2;elseif($ttl>=50&&$ttl<=90)$scores['Linux/Unix']+=2;elseif($ttl>=200)$scores['Network/Appliance']+=2;}
    if(in_array(445,$openPorts,true)||in_array(3389,$openPorts,true))$scores['Windows']+=2;if(in_array(22,$openPorts,true))$scores['Linux/Unix']+=1;if(in_array(161,$openPorts,true)||in_array(8291,$openPorts,true))$scores['Network/Appliance']+=1;
    $all=strtolower(implode(' ',array_filter($banners)));if(strpos($all,'microsoft')!==false||strpos($all,'iis')!==false)$scores['Windows']+=2;if(strpos($all,'ubuntu')!==false||strpos($all,'debian')!==false||strpos($all,'openssh')!==false)$scores['Linux/Unix']+=2;arsort($scores);$keys=array_keys($scores);$top=$keys[0];return$scores[$top]>=2?$top:'Inconnu';
}
function ns_read_arp(){
    $out=array();$ret=0;@exec('arp -a',$out,$ret);$rows=array();foreach($out as$line){if(preg_match('/\(?((?:\d{1,3}\.){3}\d{1,3})\)?\s+([0-9a-f:\-]{11,17})/i',$line,$m)){$mac=strtolower(str_replace('-',':',$m[2]));$rows[]=array('ip'=>$m[1],'mac'=>$mac);}}return$rows;
}
function ns_resource_from_row($row) {
    $ip = isset($row['ip']) ? (string)$row['ip'] : ''; $name = trim((string)(isset($row['host'])?$row['host']:'')); if($name==='')$name=$ip;
    return array('type'=>'network_host','id'=>'dmd-netscan:host:'.$ip,'local_id'=>$ip,'name'=>$name,'module'=>NETSCAN_MODULE_ID,'context'=>array('ip'=>$ip,'mac'=>isset($row['mac'])?$row['mac']:'','os'=>isset($row['os_guess'])?$row['os_guess']:'','services'=>isset($row['services'])?$row['services']:array()));
}
function ns_publish_actionhub($email, $scan) {
    $resources=array(); foreach((array)(isset($scan['results'])?$scan['results']:array()) as$row)$resources[]=ns_resource_from_row($row);
    $payload=array('schema'=>1,'module'=>NETSCAN_MODULE_ID,'user'=>$email,'updated_at'=>ns_iso_now(),'scan_id'=>isset($scan['id'])?$scan['id']:'','resources'=>$resources);
    ns_json_write(ns_boot_system_storage().'/actionhub/'.hash('sha256',$email).'.json',$payload); return $payload;
}
function ns_actionhub_payload($email) {
    $file=ns_boot_system_storage().'/actionhub/'.hash('sha256',$email).'.json';$p=ns_json_read($file,array());if(!$p){$scan=ns_last_scan($email);$p=ns_publish_actionhub($email,$scan);}return$p;
}
function ns_state_file($email,$id){if(!preg_match('/^[a-f0-9]{12,32}$/',(string)$id))return'';return ns_user_root($email).'/states/'.$id.'.json';}
function ns_scan_targets($cidrs,$maxHosts){$targets=array();foreach($cidrs as$c){$left=$maxHosts-count($targets);if($left<=0)break;$targets=array_merge($targets,ns_cidr_to_list($c,$left));}$targets=array_values(array_unique($targets));if(count($targets)>$maxHosts)$targets=array_slice($targets,0,$maxHosts);return$targets;}
function ns_scan_one($ip,$ports,$resolve,$deep){
    list($alive,$ttl,$pingMs)=ns_ping_ttl($ip);
    if(!$alive){foreach(array(80,22,443)as$p){list($ok)=ns_tcp_banner($ip,$p,0.25);if($ok){$alive=true;break;}}}
    if(!$alive)return null;
    $host=$resolve?ns_reverse_host($ip):'';$services=array();$details=array();$banners=array();$open=array();
    foreach($ports as$p){$p=(int)$p;if($p===53){list($ok,$err)=ns_udp53_probe($ip,$deep?0.6:0.35);if($ok){$services[]='53/udp';$open[]=53;}continue;}list($ok,$ban,$lat,$err)=ns_tcp_banner($ip,$p,$deep?0.65:0.35);if($ok){$services[]=$p.'/tcp';$open[]=$p;if($ban!==''){$details[(string)$p]=$ban;$banners[]=$ban;}}}
    $row=array('ip'=>$ip,'host'=>$host,'os_guess'=>ns_guess_os($ttl,$open,$banners),'services'=>$services,'details'=>$details,'ping_ms'=>$pingMs,'ttl'=>$ttl,'mac'=>'');return$row;
}
function ns_arp_merge(&$rows){$arp=ns_read_arp();$by=array();foreach($arp as$a)$by[$a['ip']]=$a['mac'];foreach($rows as&$r)if(isset($by[$r['ip']]))$r['mac']=$by[$r['ip']];unset($r);}
function ns_finalize_scan($email,&$state,$source){
    if(!empty($state['finalized']))return;
    ns_arp_merge($state['results']);$state['finished_at']=time();$state['finalized']=true;$state['running']=false;
    $scan=array('schema'=>2,'id'=>$state['id'],'source'=>$source,'cidrs'=>$state['cidrs'],'ports'=>$state['ports'],'resolve'=>$state['resolve'],'deep'=>$state['deep'],'started_at'=>date('c',$state['started_at']),'finished_at'=>date('c',$state['finished_at']),'duration_s'=>max(0,$state['finished_at']-$state['started_at']),'results'=>array_values($state['results']));
    ns_json_write(ns_user_root($email).'/last_scan.json',$scan);ns_json_write(ns_user_root($email).'/history/scan_'.date('Ymd_His',$state['finished_at']).'_'.$state['id'].'.json',$scan);ns_publish_actionhub($email,$scan);
    $resource=array('type'=>'network_scan','id'=>'dmd-netscan:scan:'.$state['id'],'name'=>'Scan '.$state['cidrs'][0]);ns_log($email,'scan.complete',$state['id'],'success',array('hosts'=>count($state['results']),'targets'=>count($state['targets']),'duration_s'=>$scan['duration_s'],'source'=>$source),$resource);
}
function ns_start_scan($email,$params,$source){
    ns_boot_user_storage($email);$cfg=ns_load_config($email);$cidrs=ns_clean_cidrs(isset($params['cidrs'])?$params['cidrs']:$cfg['cidrs']);if(!$cidrs)return array(false,'CIDR invalide.',null);
    $ports=ns_clean_ports(isset($params['ports'])?$params['ports']:$cfg['ports']);if(!$ports)$ports=$cfg['ports'];$resolve=array_key_exists('resolve',$params)?!empty($params['resolve']):$cfg['resolve'];$deep=array_key_exists('deep',$params)?!empty($params['deep']):$cfg['deep'];$max=max(16,min(4096,(int)(isset($params['max_hosts'])?$params['max_hosts']:$cfg['max_hosts'])));
    if($deep){foreach(array(53,135,139,445,3389,8000,8080,8443,161,8291)as$p)if(!in_array($p,$ports,true))$ports[]=$p;sort($ports,SORT_NUMERIC);}
    $targets=ns_scan_targets($cidrs,$max);if(!$targets)return array(false,'Aucune IP à scanner.',null);
    $id=bin2hex(random_bytes(8));$state=array('schema'=>2,'id'=>$id,'source'=>$source,'cidrs'=>$cidrs,'targets'=>$targets,'idx'=>0,'ports'=>$ports,'resolve'=>$resolve,'deep'=>$deep,'results'=>array(),'stop'=>false,'running'=>true,'finalized'=>false,'started_at'=>time(),'finished_at'=>null);
    ns_json_write(ns_state_file($email,$id),$state);$resource=array('type'=>'network_scan','id'=>'dmd-netscan:scan:'.$id,'name'=>'Scan '.$cidrs[0]);ns_log($email,'scan.start',$id,'success',array('cidrs'=>$cidrs,'ports'=>$ports,'targets'=>count($targets),'source'=>$source),$resource);return array(true,'Scan initialisé.',$state);
}
function ns_step_scan($email,$id,$batch){
    $file=ns_state_file($email,$id);if($file===''||!is_file($file))return array(false,'État de scan introuvable.',null);$lock=$file.'.lock';$fh=@fopen($lock,'c+');if(!$fh)return array(false,'Verrou de scan indisponible.',null);flock($fh,LOCK_EX);
    $state=ns_json_read($file,array());if(!$state){flock($fh,LOCK_UN);fclose($fh);return array(false,'État de scan illisible.',null);}
    if(!empty($state['stop'])){$state['running']=false;ns_json_write($file,$state);flock($fh,LOCK_UN);fclose($fh);return array(true,'Scan arrêté.',$state);}
    $total=count($state['targets']);$start=(int)$state['idx'];$max=min($total,$start+max(1,min(64,(int)$batch)));$append=array();
    for($i=$start;$i<$max;$i++){$row=ns_scan_one($state['targets'][$i],$state['ports'],!empty($state['resolve']),!empty($state['deep']));if($row){$state['results'][]=$row;$append[]=$row;}}
    $state['idx']=$max;if($state['idx']>=$total)ns_finalize_scan($email,$state,isset($state['source'])?$state['source']:'manual');ns_json_write($file,$state);flock($fh,LOCK_UN);fclose($fh);
    $state['append']=$append;return array(true,'Scan en cours.',$state);
}
function ns_stop_scan($email,$id){$file=ns_state_file($email,$id);if($file===''||!is_file($file))return false;$state=ns_json_read($file,array());if(!$state)return false;$state['stop']=true;$state['running']=false;ns_json_write($file,$state);ns_log($email,'scan.stop',$id,'success',array(),array('type'=>'network_scan','id'=>'dmd-netscan:scan:'.$id,'name'=>'Scan réseau'));return true;}
function ns_state_public($state){$total=count(isset($state['targets'])?$state['targets']:array());$done=(int)(isset($state['idx'])?$state['idx']:0);return array('id'=>isset($state['id'])?$state['id']:'','done'=>$done,'total'=>$total,'found'=>count(isset($state['results'])?$state['results']:array()),'progress'=>$total?round($done*100/$total,1):100,'finished'=>!empty($state['finalized'])||!empty($state['stop'])||$done>=$total,'stopped'=>!empty($state['stop']),'results'=>isset($state['results'])?$state['results']:array(),'append'=>isset($state['append'])?$state['append']:array());}
function ns_push_infra($email){
    $cfg=ns_load_config($email);$scan=ns_last_scan($email);$rows=isset($scan['results'])?$scan['results']:array();if(!$rows)return array(false,'Aucun résultat à envoyer.',array());$payload=array('source'=>'netscan','when'=>ns_iso_now(),'scan_id'=>isset($scan['id'])?$scan['id']:'','data'=>$rows);$mode=$cfg['infra']['mode'];
    if($mode==='filedrop'){$path=$cfg['infra']['filedrop_path'];if($path==='')return array(false,'Chemin filedrop non configuré.',array());if(!is_dir($path)&&!@mkdir($path,0775,true))return array(false,'Impossible de créer le dossier filedrop.',array());$file=rtrim($path,'/\\').'/netscan_'.date('Ymd_His').'.json';$ok=@file_put_contents($file,json_encode($payload,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX)!==false;ns_log($email,'infra.push','filedrop',$ok?'success':'error',array('file'=>$file),array('type'=>'network_scan','id'=>'dmd-netscan:scan:'.(isset($scan['id'])?$scan['id']:''),'name'=>'Dernier scan'));return array($ok,$ok?'Export Infra déposé.':'Échec filedrop.',array('mode'=>'filedrop','file'=>$file));}
    if($mode==='webhook'){$url=$cfg['infra']['webhook_url'];if(!preg_match('#^https?://#i',$url))return array(false,'URL webhook invalide.',array());$tok=ns_decrypt_secret($cfg['infra']['webhook_token_enc']);$headers="Content-Type: application/json\r\n".($tok!==''?'Authorization: Bearer '.$tok."\r\n":'');$ctx=stream_context_create(array('http'=>array('method'=>'POST','header'=>$headers,'content'=>json_encode($payload),'timeout'=>5,'ignore_errors'=>true)));$resp=@file_get_contents($url,false,$ctx);$ok=$resp!==false;ns_log($email,'infra.push','webhook',$ok?'success':'error',array('url'=>$url),array('type'=>'network_scan','id'=>'dmd-netscan:scan:'.(isset($scan['id'])?$scan['id']:''),'name'=>'Dernier scan'));return array($ok,$ok?'Webhook Infra envoyé.':'Échec webhook.',array('mode'=>'webhook'));}
    return array(false,'Aucune intégration Infra active.',array());
}
function ns_scan_from_share_or_own($email,$shareId,$needExport){if($shareId!==''){$share=ns_get_share($shareId,$email,$needExport);if(!$share)return array(null,null);return array($share['scan'],$share);}return array(ns_last_scan($email),null);}
function ns_csv($rows){$fh=fopen('php://temp','r+');fputcsv($fh,array('IP','Nom','MAC','OS','Ping ms','TTL','Services','Détails'),';');foreach($rows as$r)fputcsv($fh,array(isset($r['ip'])?$r['ip']:'',isset($r['host'])?$r['host']:'',isset($r['mac'])?$r['mac']:'',isset($r['os_guess'])?$r['os_guess']:'',isset($r['ping_ms'])?$r['ping_ms']:'',isset($r['ttl'])?$r['ttl']:'',implode(', ',(array)(isset($r['services'])?$r['services']:array())),json_encode(isset($r['details'])?$r['details']:array(),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),';');rewind($fh);$s=stream_get_contents($fh);fclose($fh);return "\xEF\xBB\xBF".$s;}
function ns_pdf_text($text){$text=(string)$text;if(function_exists('iconv')){$x=@iconv('UTF-8','Windows-1252//TRANSLIT',$text);if($x!==false)$text=$x;}return str_replace(array('\\','(',')'),array('\\\\','\\(','\\)'),$text);}
function ns_wrap_line($line,$width){$line=preg_replace('/\s+/',' ',trim((string)$line));return $line===''?array(''):explode("\n",wordwrap($line,$width,"\n",true));}
function ns_pdf_document($title,$rows){
    $lines=array($title,'Généré le '.date('d/m/Y H:i:s'),'');foreach($rows as$r){$head=(isset($r['ip'])?$r['ip']:'').' | '.(isset($r['host'])?$r['host']:'').' | '.(isset($r['os_guess'])?$r['os_guess']:'Inconnu').' | '.(isset($r['mac'])?$r['mac']:'');foreach(ns_wrap_line($head,125)as$l)$lines[]=$l;$services='Services : '.implode(', ',(array)(isset($r['services'])?$r['services']:array()));foreach(ns_wrap_line($services,125)as$l)$lines[]=$l;$details=isset($r['details'])&&is_array($r['details'])?$r['details']:array();foreach($details as$k=>$v)foreach(ns_wrap_line('  '.$k.' : '.(is_scalar($v)?$v:json_encode($v)),125)as$l)$lines[]=$l;$lines[]='';}
    if(count($rows)===0)$lines[]='Aucune donnée.';$per=43;$pages=array_chunk($lines,$per);$objects=array();$objects[1]='<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>';$pageIds=array();$id=4;
    foreach($pages as$pi=>$pageLines){$contentId=$id++;$pageId=$id++;$pageIds[]=$pageId;$content="BT\n/F1 8 Tf\n26 565 Td\n11 TL\n";foreach($pageLines as$line)$content.='('.ns_pdf_text($line).") Tj\nT*\n";$content.="ET\n";$objects[$contentId]='<< /Length '.strlen($content).' >>'."\nstream\n".$content."endstream";$objects[$pageId]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /Font << /F1 1 0 R >> >> /Contents '.$contentId.' 0 R >>';}
    $kids='';foreach($pageIds as$p)$kids.=$p.' 0 R ';$objects[2]='<< /Type /Pages /Kids [ '.$kids.'] /Count '.count($pageIds).' >>';$objects[3]='<< /Type /Catalog /Pages 2 0 R >>';ksort($objects);$pdf="%PDF-1.4\n";$offsets=array(0);$max=max(array_keys($objects));for($i=1;$i<=$max;$i++){if(!isset($objects[$i]))$objects[$i]='<< >>';$offsets[$i]=strlen($pdf);$pdf.=$i." 0 obj\n".$objects[$i]."\nendobj\n";}$xref=strlen($pdf);$pdf.="xref\n0 ".($max+1)."\n0000000000 65535 f \n";for($i=1;$i<=$max;$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i])."\n";$pdf.="trailer\n<< /Size ".($max+1)." /Root 3 0 R >>\nstartxref\n".$xref."\n%%EOF\n";return$pdf;
}
