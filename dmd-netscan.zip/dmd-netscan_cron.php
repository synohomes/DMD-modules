<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */



require_once __DIR__ . '/dmd-netscan_lib.php';

function ns_cron_profiles() {
    $root = NETSCAN_ROOT . '/users/profiles';
    $out = array();
    $dirs = is_dir($root) ? glob($root . '/*', GLOB_ONLYDIR) : array();
    if (!is_array($dirs)) return $out;
    foreach ($dirs as $dir) {
        $folder = basename($dir);
        $profile = ns_json_read($dir . '/profile/profile.json', array());
        if (!$profile) $profile = ns_json_read($dir . '/profile.json', array());
        $email = trim((string)(isset($profile['email']) ? $profile['email'] : $folder));
        if ($email !== '') $out[] = $email;
    }
    return array_values(array_unique($out));
}

function ns_cron_job_due($job, $force) {
    if (empty($job['enabled'])) return false;
    if ($force) return true;
    $last = isset($job['last_run']) ? trim((string)$job['last_run']) : '';
    if ($last === '') return true;
    $ts = strtotime($last);
    if ($ts === false) return true;
    $interval = max(1, min(720, (int)(isset($job['interval_h']) ? $job['interval_h'] : 24))) * 3600;
    return ($ts + $interval) <= time();
}

function ns_cron_run_user($email) {
    $email = trim((string)$email);
    if ($email === '' || !ns_profile_exists($email)) return array('user'=>$email,'ok'=>false,'message'=>'Profil introuvable.','jobs'=>array());

    $userRoot = ns_boot_user_storage($email);
    $forceFile = $userRoot . '/run_jobs.flag';
    $force = is_file($forceFile);
    $cfg = ns_load_config($email);
    $jobs = isset($cfg['jobs']) && is_array($cfg['jobs']) ? $cfg['jobs'] : array();
    $report = array();
    $changed = false;

    foreach ($jobs as $i => $job) {
        if (!ns_cron_job_due($job, $force)) continue;
        $name = isset($job['name']) && trim((string)$job['name']) !== '' ? trim((string)$job['name']) : 'Scan planifié';
        list($ok, $msg, $state) = ns_start_scan($email, $job, 'cron');
        if (!$ok || !is_array($state)) {
            $report[] = array('id'=>isset($job['id'])?$job['id']:'','name'=>$name,'ok'=>false,'message'=>$msg);
            ns_log($email, 'jobs.run', isset($job['id'])?$job['id']:'', 'error', array('name'=>$name,'message'=>$msg), null);
            ns_notify($email, 'NetScan planifié en échec', $name . ' : ' . $msg, 'error', array('job_id'=>isset($job['id'])?$job['id']:'','job_name'=>$name));
            continue;
        }

        $guard = 0;
        while (empty($state['finalized']) && empty($state['stop']) && $guard < 10000) {
            list($stepOk, $stepMsg, $next) = ns_step_scan($email, $state['id'], 64);
            if (!$stepOk || !is_array($next)) {
                $ok = false;
                $msg = $stepMsg;
                break;
            }
            $state = $next;
            $guard++;
        }
        if ($guard >= 10000) {
            $ok = false;
            $msg = 'Limite de sécurité atteinte pendant le scan planifié.';
            ns_stop_scan($email, $state['id']);
        }

        if ($ok && !empty($state['finalized'])) {
            $jobs[$i]['last_run'] = ns_iso_now();
            $changed = true;
            $report[] = array('id'=>isset($job['id'])?$job['id']:'','name'=>$name,'ok'=>true,'message'=>'Scan terminé.','hosts'=>count(isset($state['results'])?$state['results']:array()));
            $hostCount = count(isset($state['results'])?$state['results']:array());
            ns_log($email, 'jobs.run', isset($job['id'])?$job['id']:'', 'success', array('name'=>$name,'scan_id'=>$state['id'],'hosts'=>$hostCount), array('type'=>'network_scan','id'=>'dmd-netscan:scan:'.$state['id'],'name'=>$name));
            ns_notify($email, 'NetScan planifié terminé', $name . ' : ' . $hostCount . ' hôte(s) détecté(s).', 'success', array('job_id'=>isset($job['id'])?$job['id']:'','job_name'=>$name,'scan_id'=>$state['id'],'hosts'=>$hostCount));
        } else {
            $report[] = array('id'=>isset($job['id'])?$job['id']:'','name'=>$name,'ok'=>false,'message'=>$msg);
            ns_log($email, 'jobs.run', isset($job['id'])?$job['id']:'', 'error', array('name'=>$name,'message'=>$msg), null);
            ns_notify($email, 'NetScan planifié en échec', $name . ' : ' . $msg, 'error', array('job_id'=>isset($job['id'])?$job['id']:'','job_name'=>$name,'scan_id'=>isset($state['id'])?$state['id']:''));
        }
    }

    if ($changed) {
        $cfg['jobs'] = $jobs;
        ns_save_config($email, $cfg);
    }
    if ($force) @unlink($forceFile);
    return array('user'=>$email,'ok'=>true,'forced'=>$force,'jobs'=>$report);
}

$isCli = PHP_SAPI === 'cli';
$targets = array();

if ($isCli) {
    $requested = '';
    if (isset($argv) && is_array($argv)) {
        foreach ($argv as $arg) {
            if (strpos($arg, '--user=') === 0) $requested = trim(substr($arg, 7));
        }
    }
    $targets = $requested !== '' ? array($requested) : ns_cron_profiles();
} else {
    header('Content-Type: application/json; charset=utf-8');
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(array('ok'=>false,'message'=>'POST requis.'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
    $email = ns_require('scan.jobs');
    $token = isset($_POST['csrf']) ? (string)$_POST['csrf'] : '';
    if (!ns_csrf_check($token)) {
        http_response_code(419);
        echo json_encode(array('ok'=>false,'message'=>'Jeton CSRF invalide.'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
    $targets = array($email);
}

$systemRoot = ns_boot_system_storage();
$lockHandle = @fopen($systemRoot . '/cron.lock', 'c+');
if (!$lockHandle || !flock($lockHandle, LOCK_EX | LOCK_NB)) {
    $payload = array('ok'=>false,'message'=>'Une exécution NetScan est déjà en cours.');
    if ($isCli) fwrite(STDOUT, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL);
    else echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit(2);
}

$results = array();
foreach ($targets as $email) $results[] = ns_cron_run_user($email);
$payload = array('ok'=>true,'ran_at'=>ns_iso_now(),'users'=>$results);

flock($lockHandle, LOCK_UN);
fclose($lockHandle);

if ($isCli) fwrite(STDOUT, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL);
else echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
