<?php
require_once __DIR__ . '/dmd-netscan_lib.php';
$email = ns_require('config.edit');
$cfg = ns_load_config($email);
$pub = ns_public_config($cfg);
$csrf = ns_csrf();
$uid = 'nscfg_' . bin2hex(random_bytes(4));
$cssVersion = @filemtime(__DIR__ . '/dmd-netscan.css') ?: time();
$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/dmd-netscan';
if ($documentRoot !== '' && strpos($moduleRealDir, $documentRoot) === 0) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot))), '/');
}
$moduleWebPath = rtrim($moduleWebPath, '/');
$apiUrl = $moduleWebPath . '/dmd-netscan_api.php';
?>
<link rel="stylesheet" href="<?= ns_h($moduleWebPath) ?>/dmd-netscan.css?v=<?= ns_h($cssVersion) ?>">
<div class="netscan-cfg" id="<?= ns_h($uid) ?>" data-csrf="<?= ns_h($csrf) ?>">
  <header class="netscan-cfg__head">
    <div><span class="netscan-kicker">NetScan · DoMyDesk 1.2.0</span><h3>Configuration du module</h3><p>Réglages d’intégration persistants hors du dossier module.</p></div>
    <span class="netscan-state">v<?= ns_h(NETSCAN_MODULE_VERSION) ?></span>
  </header>
  <section class="netscan-card">
    <div class="netscan-section-title"><div><h4>Connexion à DMD-INFRA</h4><p>L’envoi reste manuel depuis le module. Le jeton webhook est chiffré côté serveur.</p></div></div>
    <div class="netscan-form-grid">
      <label><span>Mode</span><select data-mode><option value="none">Aucun</option><option value="filedrop">Dépôt de fichier</option><option value="webhook">Webhook HTTP(S)</option></select></label>
      <label><span>Dossier filedrop</span><input data-filedrop placeholder="/volume1/.../imports"></label>
      <label class="netscan-wide"><span>URL webhook</span><input data-webhook-url placeholder="https://.../api/import"></label>
      <label class="netscan-wide"><span>Jeton webhook</span><input type="password" data-webhook-token autocomplete="new-password" placeholder="Vide = conserver le jeton actuel"></label>
    </div>
    <label class="netscan-check"><input type="checkbox" data-clear-token><span>Supprimer le jeton webhook enregistré</span></label>
    <div class="netscan-actions"><button type="button" class="netscan-btn netscan-btn--primary" data-save>Enregistrer</button><span class="netscan-inline-msg" data-msg></span></div>
  </section>
  <section class="netscan-card">
    <div class="netscan-section-title"><div><h4>Stockage 1.2.0</h4><p>Les données utilisateur survivent aux mises à jour du ZIP.</p></div></div>
    <div class="netscan-paths">
      <code>users/profiles/&lt;email&gt;/dmd-netscan/</code>
      <code>data/modules/dmd-netscan/</code>
    </div>
  </section>
</div>
<script>
(function(){
  var root=document.getElementById(<?= json_encode($uid) ?>); if(!root)return;
  var csrf=root.dataset.csrf, api=<?= json_encode($apiUrl, JSON_UNESCAPED_SLASHES) ?>;
  var initial=<?= json_encode($pub, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
  var infra=initial.infra||{};
  root.querySelector('[data-mode]').value=infra.mode||'none';
  root.querySelector('[data-filedrop]').value=infra.filedrop_path||'';
  root.querySelector('[data-webhook-url]').value=infra.webhook_url||'';
  if(infra.webhook_token_saved) root.querySelector('[data-webhook-token]').placeholder='Jeton enregistré — vide = conserver';
  async function call(body){body.csrf=csrf;var r=await fetch(api,{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});var j=await r.json();if(!r.ok||!j.ok)throw new Error(j.message||'Erreur');return j;}
  root.querySelector('[data-save]').addEventListener('click',async function(){
    var btn=this,msg=root.querySelector('[data-msg]');btn.disabled=true;msg.textContent='Enregistrement…';
    try{var j=await call({action:'save_admin_config',mode:root.querySelector('[data-mode]').value,filedrop_path:root.querySelector('[data-filedrop]').value,webhook_url:root.querySelector('[data-webhook-url]').value,webhook_token:root.querySelector('[data-webhook-token]').value,clear_webhook_token:root.querySelector('[data-clear-token]').checked});msg.textContent=j.message;root.querySelector('[data-webhook-token]').value='';root.querySelector('[data-clear-token]').checked=false;}
    catch(e){msg.textContent=e.message;}finally{btn.disabled=false;}
  });
})();
</script>
