<?php
require_once __DIR__ . '/dmd-netscan_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function ns_api_out($ok, $message, $extra) {
    $body = array_merge(array('ok'=>(bool)$ok,'message'=>(string)$message), is_array($extra)?$extra:array());
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function ns_api_input() {
    $raw = (string)file_get_contents('php://input');
    if ($raw !== '') {
        $j = json_decode($raw, true);
        if (is_array($j)) return $j;
    }
    return $_POST;
}
function ns_api_guard($permission, $in) {
    $email = ns_require($permission);
    $token = isset($in['csrf']) ? (string)$in['csrf'] : '';
    if (!ns_csrf_check($token)) ns_api_out(false, 'Session expirée ou requête invalide.', array('code'=>'csrf'));
    return $email;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); ns_api_out(false,'POST requis.',array()); }
$in = ns_api_input();
$action = strtolower(trim((string)(isset($in['action'])?$in['action']:'')));

if ($action === 'bootstrap') {
    $email = ns_api_guard('module.view', $in);
    $cfg = ns_load_config($email); $scan = ns_last_scan($email);
    ns_api_out(true,'OK',array(
        'config'=>ns_public_config($cfg),
        'scan'=>$scan,
        'permissions'=>ns_permissions_snapshot($email),
        'actionhub'=>ns_can('actionhub.use',$email)?ns_actionhub_payload($email):array('resources'=>array()),
        'shares'=>ns_can('scan.share',$email)?ns_list_shares($email):array('received'=>array(),'sent'=>array())
    ));
}
if ($action === 'save_config') {
    $email = ns_api_guard('scan.configure',$in); $old=ns_load_config($email);
    $cfg = array(
        'cidrs'=>isset($in['cidrs'])?$in['cidrs']:$old['cidrs'], 'ports'=>isset($in['ports'])?$in['ports']:$old['ports'],
        'resolve'=>!empty($in['resolve']), 'deep'=>!empty($in['deep']), 'max_hosts'=>isset($in['max_hosts'])?$in['max_hosts']:$old['max_hosts'],
        'infra'=>$old['infra'], 'jobs'=>$old['jobs']
    );
    $saved=ns_save_config($email,$cfg); if(!$saved)ns_api_out(false,'Impossible d’enregistrer.',array());
    ns_log($email,'config.scan','netscan','success',array('cidrs'=>$saved['cidrs'],'ports'=>$saved['ports'],'resolve'=>$saved['resolve'],'deep'=>$saved['deep'],'max_hosts'=>$saved['max_hosts']),null);
    ns_api_out(true,'Configuration du scan enregistrée.',array('config'=>ns_public_config($saved)));
}
if ($action === 'save_admin_config') {
    $email=ns_api_guard('config.edit',$in);$cfg=ns_load_config($email);$infra=$cfg['infra'];
    $mode=strtolower(trim((string)(isset($in['mode'])?$in['mode']:'none')));if(!in_array($mode,array('none','filedrop','webhook'),true))$mode='none';
    $infra['mode']=$mode;$infra['filedrop_path']=trim((string)(isset($in['filedrop_path'])?$in['filedrop_path']:''));$infra['webhook_url']=trim((string)(isset($in['webhook_url'])?$in['webhook_url']:''));
    if(array_key_exists('clear_webhook_token',$in)&&!empty($in['clear_webhook_token']))$infra['webhook_token_enc']='';
    $token=trim((string)(isset($in['webhook_token'])?$in['webhook_token']:''));if($token!==''){$enc=ns_encrypt_secret($token);if($enc==='')ns_api_out(false,'Impossible de chiffrer le jeton webhook.',array());$infra['webhook_token_enc']=$enc;}
    $cfg['infra']=$infra;$saved=ns_save_config($email,$cfg);if(!$saved)ns_api_out(false,'Impossible d’enregistrer la configuration.',array());
    ns_log($email,'config.infra','netscan','success',array('mode'=>$mode,'filedrop_path'=>$infra['filedrop_path'],'webhook_url'=>$infra['webhook_url'],'webhook_token_saved'=>$infra['webhook_token_enc']!==''),null);
    ns_api_out(true,'Configuration NetScan enregistrée.',array('config'=>ns_public_config($saved)));
}
if ($action === 'start') {
    $email=ns_api_guard('scan.start',$in);
    list($ok,$msg,$state)=ns_start_scan($email,$in,'manual');
    ns_api_out($ok,$msg,$ok?array('state'=>ns_state_public($state)):array());
}
if ($action === 'step') {
    $email=ns_api_guard('scan.start',$in); $id=isset($in['state_id'])?$in['state_id']:'';
    list($ok,$msg,$state)=ns_step_scan($email,$id,24);
    ns_api_out($ok,$msg,$ok?array('state'=>ns_state_public($state)):array());
}
if ($action === 'status') {
    $email=ns_api_guard('module.view',$in); $id=isset($in['state_id'])?(string)$in['state_id']:'';
    if($id!==''){$file=ns_state_file($email,$id);$state=$file!==''?ns_json_read($file,array()):array();if($state)ns_api_out(true,'OK',array('state'=>ns_state_public($state)));}
    ns_api_out(true,'OK',array('scan'=>ns_last_scan($email)));
}
if ($action === 'stop') {
    $email=ns_api_guard('scan.stop',$in);$ok=ns_stop_scan($email,isset($in['state_id'])?$in['state_id']:'');ns_api_out($ok,$ok?'Scan arrêté.':'Scan introuvable.',array());
}
if ($action === 'arp') {
    $email=ns_api_guard('scan.arp',$in);$rows=ns_read_arp();ns_log($email,'arp.read','local','success',array('entries'=>count($rows)),null);ns_api_out(true,count($rows).' entrée(s) ARP.',array('entries'=>$rows));
}
if ($action === 'get_jobs') {
    $email=ns_api_guard('scan.jobs',$in);$cfg=ns_load_config($email);ns_api_out(true,'OK',array('jobs'=>$cfg['jobs']));
}
if ($action === 'save_jobs') {
    $email=ns_api_guard('scan.jobs',$in);$cfg=ns_load_config($email);$cfg['jobs']=ns_clean_jobs(isset($in['jobs'])?$in['jobs']:array());$saved=ns_save_config($email,$cfg);if(!$saved)ns_api_out(false,'Écriture impossible.',array());ns_log($email,'jobs.save','scheduler','success',array('count'=>count($saved['jobs'])),null);ns_api_out(true,'Planification enregistrée.',array('jobs'=>$saved['jobs']));
}
if ($action === 'run_jobs') {
    $email=ns_api_guard('scan.jobs',$in);$flag=ns_boot_user_storage($email).'/run_jobs.flag';@file_put_contents($flag,(string)time(),LOCK_EX);ns_log($email,'jobs.request','scheduler','success',array(),null);ns_api_out(true,'Exécution demandée au cron NetScan.',array());
}
if ($action === 'push_infra') {
    $email=ns_api_guard('infra.push',$in);list($ok,$msg,$extra)=ns_push_infra($email);ns_api_out($ok,$msg,$extra);
}
if ($action === 'logs') {
    $email=ns_api_guard('logs.view',$in);$rows=ns_read_logs($email,isset($in['days'])?$in['days']:30,isset($in['limit'])?$in['limit']:500);ns_api_out(true,'OK',array('logs'=>$rows));
}
if ($action === 'logs_delete') {
    $email=ns_api_guard('logs.delete',$in);$count=ns_delete_logs($email);ns_log($email,'logs.delete','netscan','success',array('files_deleted'=>$count),null);ns_api_out(true,$count.' fichier(s) de logs supprimé(s).',array('count'=>$count));
}
if ($action === 'users_list') {
    $email=ns_api_guard('scan.share',$in);ns_api_out(true,'OK',array('users'=>ns_list_users($email)));
}
if ($action === 'shares_list') {
    $email=ns_api_guard('scan.share',$in);ns_api_out(true,'OK',array('shares'=>ns_list_shares($email)));
}
if ($action === 'share_create') {
    $email=ns_api_guard('scan.share',$in);$recipients=isset($in['recipients'])?$in['recipients']:array();list($ok,$msg,$share)=ns_create_share($email,isset($in['title'])?$in['title']:'',$recipients,!empty($in['can_export']));ns_api_out($ok,$msg,$share?array('share'=>$share):array());
}
if ($action === 'share_revoke') {
    $email=ns_api_guard('scan.share',$in);list($ok,$msg)=ns_revoke_share($email,isset($in['share_id'])?$in['share_id']:'');ns_api_out($ok,$msg,array());
}
if ($action === 'share_open') {
    $email=ns_api_guard('scan.share',$in);$share=ns_get_share(isset($in['share_id'])?$in['share_id']:'',$email,false);if(!$share)ns_api_out(false,'Partage indisponible ou accès retiré.',array());$viewerPerm=strcasecmp((string)$share['owner'],$email)===0?array('view'=>true,'export'=>true):ns_share_permission_for($share,$email);$share['viewer_permissions']=is_array($viewerPerm)?$viewerPerm:array('view'=>true,'export'=>false);ns_log($email,'share.open',$share['id'],'success',array('owner'=>$share['owner']),array('type'=>'network_scan','id'=>isset($share['scan']['id'])?$share['scan']['id']:'','name'=>$share['title']));ns_api_out(true,'OK',array('share'=>$share));
}
if ($action === 'actionhub') {
    $email=ns_api_guard('actionhub.use',$in);ns_api_out(true,'OK',array('actionhub'=>ns_actionhub_payload($email)));
}
if ($action === 'quicksession_event') {
    $email=ns_api_guard('quicksession.use',$in);$ip=trim((string)(isset($in['ip'])?$in['ip']:''));if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4))ns_api_out(false,'Hôte invalide.',array());$resource=array('type'=>'network_host','id'=>'dmd-netscan:host:'.$ip,'name'=>isset($in['name'])&&$in['name']!==''?$in['name']:$ip);ns_log($email,'quicksession.context',$ip,'success',array('label'=>'Contexte NetScan ajouté à la Quick-Session'),$resource);ns_api_out(true,'Contexte envoyé à la Quick-Session.',array('resource'=>$resource));
}
ns_api_out(false,'Action inconnue.',array());
