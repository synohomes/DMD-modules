<?php
/* * =====================================================================
								DoMyDesk 
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.
* 
Ce fichier fait partie du logiciel DoMyDesk. 
* 
Toute reproduction, redistribution, revente, publication ou 
intégration de tout ou partie de ce code dans un autre produit 
sans autorisation préalable de SynoHomes est interdite.
* 
La modification du logiciel dans le cadre de son utilisation 
* 
autorisée ne transfère aucun droit de propriété sur le code source.
*
Produit : DoMyDesk * Version : 1.2.0 
* 
Éditeur : SynoHomes 

* * ===================================================================== * */




if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['user']['email'])) {
    http_response_code(403);
    return;
}

$domyDeskRoot = realpath(__DIR__ . '/../..');
if ($domyDeskRoot === false) {
    $domyDeskRoot = dirname(__DIR__, 2);
}

if (!function_exists('dmd_require_module_access')) {
    $permissionsFile = $domyDeskRoot . '/core/dmd_permissions.php';
    if (is_file($permissionsFile)) {
        require_once $permissionsFile;
    }
}

if (!function_exists('dmd_require_module_access')) {
    http_response_code(500);
    exit('Core des permissions DoMyDesk 1.2.0 indisponible.');
}

dmd_require_module_access('DMD-Converter', 'module.view');

$documentRoot = realpath(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '');
$moduleRealDir = realpath(__DIR__);
$moduleWebPath = '/modules/DMD-Converter';

if ($documentRoot && $moduleRealDir && strpos($moduleRealDir, $documentRoot) === 0) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot))), '/');
}

$instanceId = 'dmdconvert-' . bin2hex(random_bytes(5));
$cssUrl = rtrim($moduleWebPath, '/') . '/dmdconvert.css?v=2.0.2';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($cssUrl, ENT_QUOTES, 'UTF-8') ?>">

<section
    id="<?= htmlspecialchars($instanceId, ENT_QUOTES, 'UTF-8') ?>"
    class="dmdconvert"
    data-dmdconvert
    aria-labelledby="<?= htmlspecialchars($instanceId, ENT_QUOTES, 'UTF-8') ?>-title"
>
    <header class="dmdconvert__header">
        <div class="dmdconvert__heading">
            
            <h2 id="<?= htmlspecialchars($instanceId, ENT_QUOTES, 'UTF-8') ?>-title" class="dmdconvert__title">Convertisseur d’unités</h2>

        </div>
        <div class="dmdconvert__badge" aria-hidden="true">⇄</div>
    </header>

    <form class="dmdconvert__panel" data-converter-form novalidate>
        <div class="dmdconvert__grid dmdconvert__grid--primary">
            <label class="dmdconvert__field">
                <span class="dmdconvert__label">Type de mesure</span>
                <select class="dmdconvert__control" data-category>
                    <option value="length">📏 Longueur</option>
                    <option value="weight">⚖️ Poids</option>
                    <option value="volume">🧴 Volume</option>
                    <option value="speed">🚗 Vitesse</option>
                    <option value="data">💾 Données</option>
                    <option value="energy">⚡ Énergie</option>
                    <option value="pressure">🧯 Pression</option>
                    <option value="power">🔌 Puissance</option>
                </select>
            </label>

            <label class="dmdconvert__field">
                <span class="dmdconvert__label">Valeur à convertir</span>
                <input
                    class="dmdconvert__control dmdconvert__control--value"
                    data-value
                    type="text"
                    inputmode="decimal"
                    placeholder="Ex. : 10 ou 10,5"
                    autocomplete="off"
                    spellcheck="false"
                >
            </label>
        </div>

        <div class="dmdconvert__direction" aria-hidden="true">
            <span></span>
            <strong>Vers</strong>
            <span></span>
        </div>

        <div class="dmdconvert__grid">
            <label class="dmdconvert__field">
                <span class="dmdconvert__label">Unité de départ</span>
                <select class="dmdconvert__control" data-from></select>
            </label>

            <label class="dmdconvert__field">
                <span class="dmdconvert__label">Unité d’arrivée</span>
                <select class="dmdconvert__control" data-to></select>
            </label>
        </div>

        <div class="dmdconvert__actions">
            <button class="dmdconvert__button dmdconvert__button--secondary" data-swap type="button">
                <span aria-hidden="true">⇄</span>
                Inverser
            </button>
            <button class="dmdconvert__button dmdconvert__button--secondary" data-reset type="button">
                <span aria-hidden="true">↺</span>
                Effacer
            </button>
            <button class="dmdconvert__button dmdconvert__button--primary" type="submit">
                <span aria-hidden="true">✓</span>
                Convertir
            </button>
        </div>
    </form>

    <div class="dmdconvert__result" data-result role="status" aria-live="polite" aria-atomic="true">
        <div class="dmdconvert__result-copy">
            <span class="dmdconvert__result-label">Résultat</span>
            <strong class="dmdconvert__result-value" data-result-value>Saisissez une valeur pour commencer.</strong>
        </div>
        <button class="dmdconvert__copy" data-copy type="button" disabled aria-label="Copier le résultat">Copier</button>
    </div>

    <p class="dmdconvert__note" data-note>Les conversions de données utilisent une base 1024, comme le module d’origine.</p>
</section>

<script>
(function () {
    'use strict';

    var root = document.getElementById(<?= json_encode($instanceId, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>);
    if (!root || root.getAttribute('data-ready') === '1') {
        return;
    }
    root.setAttribute('data-ready', '1');

    var categories = {
        length: {
            units: {
                m: { factor: 1, label: 'Mètre (m)', symbol: 'm' },
                km: { factor: 1000, label: 'Kilomètre (km)', symbol: 'km' },
                cm: { factor: 0.01, label: 'Centimètre (cm)', symbol: 'cm' },
                mm: { factor: 0.001, label: 'Millimètre (mm)', symbol: 'mm' },
                mile: { factor: 1609.34, label: 'Mile (mi)', symbol: 'mi' },
                ft: { factor: 0.3048, label: 'Pied (ft)', symbol: 'ft' }
            }
        },
        weight: {
            units: {
                kg: { factor: 1, label: 'Kilogramme (kg)', symbol: 'kg' },
                g: { factor: 0.001, label: 'Gramme (g)', symbol: 'g' },
                mg: { factor: 0.000001, label: 'Milligramme (mg)', symbol: 'mg' },
                lb: { factor: 0.453592, label: 'Livre (lb)', symbol: 'lb' },
                oz: { factor: 0.0283495, label: 'Once (oz)', symbol: 'oz' }
            }
        },
        volume: {
            units: {
                l: { factor: 1, label: 'Litre (L)', symbol: 'L' },
                ml: { factor: 0.001, label: 'Millilitre (mL)', symbol: 'mL' },
                m3: { factor: 1000, label: 'Mètre cube (m³)', symbol: 'm³' },
                gal: { factor: 3.78541, label: 'Gallon US (gal)', symbol: 'gal' }
            }
        },
        speed: {
            units: {
                ms: { factor: 1, label: 'Mètre/seconde (m/s)', symbol: 'm/s' },
                kmh: { factor: 0.277778, label: 'Kilomètre/heure (km/h)', symbol: 'km/h' },
                mph: { factor: 0.44704, label: 'Mile/heure (mph)', symbol: 'mph' }
            }
        },
        data: {
            units: {
                b: { factor: 1, label: 'Octet (B)', symbol: 'B' },
                kb: { factor: 1024, label: 'Kilo-octet (KB)', symbol: 'KB' },
                mb: { factor: 1048576, label: 'Mégaoctet (MB)', symbol: 'MB' },
                gb: { factor: 1073741824, label: 'Gigaoctet (GB)', symbol: 'GB' },
                tb: { factor: 1099511627776, label: 'Téraoctet (TB)', symbol: 'TB' }
            }
        },
        energy: {
            units: {
                j: { factor: 1, label: 'Joule (J)', symbol: 'J' },
                kj: { factor: 1000, label: 'Kilojoule (kJ)', symbol: 'kJ' },
                cal: { factor: 4.184, label: 'Calorie (cal)', symbol: 'cal' },
                kcal: { factor: 4184, label: 'Kilocalorie (kcal)', symbol: 'kcal' },
                wh: { factor: 3600, label: 'Watt-heure (Wh)', symbol: 'Wh' },
                kwh: { factor: 3600000, label: 'Kilowatt-heure (kWh)', symbol: 'kWh' }
            }
        },
        pressure: {
            units: {
                pa: { factor: 1, label: 'Pascal (Pa)', symbol: 'Pa' },
                bar: { factor: 100000, label: 'Bar', symbol: 'bar' },
                psi: { factor: 6894.76, label: 'PSI', symbol: 'psi' },
                atm: { factor: 101325, label: 'Atmosphère (atm)', symbol: 'atm' }
            }
        },
        power: {
            units: {
                w: { factor: 1, label: 'Watt (W)', symbol: 'W' },
                kw: { factor: 1000, label: 'Kilowatt (kW)', symbol: 'kW' },
                hp: { factor: 745.7, label: 'Cheval-vapeur (hp)', symbol: 'hp' }
            }
        }
    };

    var form = root.querySelector('[data-converter-form]');
    var category = root.querySelector('[data-category]');
    var valueInput = root.querySelector('[data-value]');
    var from = root.querySelector('[data-from]');
    var to = root.querySelector('[data-to]');
    var swap = root.querySelector('[data-swap]');
    var reset = root.querySelector('[data-reset]');
    var result = root.querySelector('[data-result]');
    var resultValue = root.querySelector('[data-result-value]');
    var copy = root.querySelector('[data-copy]');
    var note = root.querySelector('[data-note]');
    var lastResultText = '';

    function parseLocalizedNumber(raw) {
        var normalized = String(raw || '')
            .trim()
            .replace(/[\s\u00A0\u202F]/g, '')
            .replace(',', '.');

        if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(normalized)) {
            return NaN;
        }

        var value = Number(normalized);
        return Number.isFinite(value) ? value : NaN;
    }

    function formatNumber(value) {
        var absolute = Math.abs(value);

        if (value !== 0 && (absolute >= 1e15 || absolute < 1e-8)) {
            return value.toExponential(8).replace('.', ',');
        }

        return new Intl.NumberFormat('fr-FR', {
            maximumFractionDigits: 10
        }).format(value);
    }

    function currentUnits() {
        var current = categories[category.value];
        return current ? current.units : null;
    }

    function setNeutral(message) {
        result.classList.remove('is-error', 'is-success');
        resultValue.textContent = message;
        lastResultText = '';
        copy.disabled = true;
    }

    function setError(message) {
        result.classList.remove('is-success');
        result.classList.add('is-error');
        resultValue.textContent = message;
        lastResultText = '';
        copy.disabled = true;
    }

    function fillUnits() {
        var units = currentUnits();
        var keys = units ? Object.keys(units) : [];

        from.innerHTML = '';
        to.innerHTML = '';

        keys.forEach(function (key) {
            var meta = units[key];
            from.add(new Option(meta.label, key));
            to.add(new Option(meta.label, key));
        });

        if (keys.length > 1) {
            to.value = keys[1];
        }

        note.hidden = category.value !== 'data';
        setNeutral('Saisissez une valeur pour commencer.');
    }

    function convert(focusOnError) {
        var value = parseLocalizedNumber(valueInput.value);
        var units = currentUnits();

        if (!units || !units[from.value] || !units[to.value]) {
            setError('Unité de conversion indisponible.');
            return false;
        }

        if (!Number.isFinite(value)) {
            setError('Veuillez saisir une valeur numérique valide.');
            if (focusOnError) {
                valueInput.focus();
            }
            return false;
        }

        var output = (value * units[from.value].factor) / units[to.value].factor;
        if (!Number.isFinite(output)) {
            setError('Le résultat dépasse la plage numérique disponible.');
            return false;
        }

        var fromText = formatNumber(value) + ' ' + units[from.value].symbol;
        var toText = formatNumber(output) + ' ' + units[to.value].symbol;
        lastResultText = fromText + ' → ' + toText;

        result.classList.remove('is-error');
        result.classList.add('is-success');
        resultValue.textContent = lastResultText;
        copy.disabled = false;
        return true;
    }

    function copyResult() {
        if (!lastResultText) {
            return;
        }

        function copied() {
            var original = copy.textContent;
            copy.textContent = 'Copié';
            window.setTimeout(function () {
                copy.textContent = original;
            }, 1200);
        }

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(lastResultText).then(copied).catch(function () {});
            return;
        }

        var helper = document.createElement('textarea');
        helper.value = lastResultText;
        helper.setAttribute('readonly', 'readonly');
        helper.className = 'dmdconvert__clipboard-helper';
        document.body.appendChild(helper);
        helper.select();
        try {
            if (document.execCommand('copy')) {
                copied();
            }
        } catch (ignore) {}
        document.body.removeChild(helper);
    }

    form.addEventListener('submit', function (event) {
        event.preventDefault();
        convert(true);
    });

    category.addEventListener('change', fillUnits);

    from.addEventListener('change', function () {
        if (valueInput.value.trim() !== '') {
            convert(false);
        }
    });

    to.addEventListener('change', function () {
        if (valueInput.value.trim() !== '') {
            convert(false);
        }
    });

    swap.addEventListener('click', function () {
        var currentFrom = from.value;
        from.value = to.value;
        to.value = currentFrom;

        if (valueInput.value.trim() !== '') {
            convert(false);
        }
    });

    reset.addEventListener('click', function () {
        valueInput.value = '';
        setNeutral('Saisissez une valeur pour commencer.');
        valueInput.focus();
    });

    copy.addEventListener('click', copyResult);

    fillUnits();
}());
</script>
