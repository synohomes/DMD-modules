<?php
/* * =====================================================================
                                DoMyDesk
     =====================================================================

Copyright (c) 2026 SynoHomes / Tous droits réservés.

Ce fichier fait partie du logiciel DoMyDesk.
Toute reproduction, redistribution, revente, publication ou
intégration de tout ou partie de ce code dans un autre produit
sans autorisation préalable de SynoHomes est interdite.

Produit : DoMyDesk
Éditeur : SynoHomes
* * ===================================================================== * */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$email = trim((string)($_SESSION['user']['email'] ?? ''));
$domyDeskRoot = realpath(__DIR__ . '/../..');
if ($domyDeskRoot === false) {
    $domyDeskRoot = dirname(__DIR__, 2);
}

/* Le thème MyDesk doit être celui de l'utilisateur connecté, pas un thème
 * codé dans le module. C'est la même logique que les modules MyDesk natifs. */
$theme = 'default';
if ($email !== '') {
    $safeUser = basename($email);
    $themeFile = $domyDeskRoot . '/users/profiles/' . $safeUser . '/theme.json';
    if (is_file($themeFile)) {
        $themeData = json_decode((string)@file_get_contents($themeFile), true);
        if (is_array($themeData) && !empty($themeData['theme'])) {
            $candidate = basename((string)$themeData['theme']);
            if ($candidate !== '' && is_file($domyDeskRoot . '/theme/' . $candidate . '/style.css')) {
                $theme = $candidate;
            }
        }
    }
}

$scriptName = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
$webRoot = preg_replace('~/modules/DMD-Converter/.*$~', '', $scriptName);
if (!is_string($webRoot)) {
    $webRoot = '';
}
$themeUrl = rtrim($webRoot, '/') . '/theme/' . rawurlencode($theme) . '/style.css';
$mydeskCssUrl = rtrim(dirname($scriptName), '/') . '/dmdconvert-mydesk.css?v=' . (is_file(__DIR__ . '/dmdconvert-mydesk.css') ? filemtime(__DIR__ . '/dmdconvert-mydesk.css') : '1');
?>
<link rel="stylesheet" href="<?= htmlspecialchars($themeUrl, ENT_QUOTES, 'UTF-8') ?>">
<?php
/* Le module d'origine reste intact. */
require __DIR__ . '/DMD-Converter.php';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($mydeskCssUrl, ENT_QUOTES, 'UTF-8') ?>">
<script>
(function () {
    'use strict';

    function applyMyDeskDocumentClass() {
        document.documentElement.classList.add('dmd-converter-mydesk-host');
        if (document.body) document.body.classList.add('dmd-converter-mydesk-host');
    }

    /* Si le runtime MyDesk expose aussi ses variables dans un parent/opener,
       elles gagnent sur le CSS chargé côté serveur. Aucun coloris n'est fixé ici. */
    function syncThemeFromHost() {
        var host = null;
        try {
            if (window.opener && !window.opener.closed && window.opener.location.origin === window.location.origin) {
                host = window.opener;
            }
        } catch (_) {}
        try {
            if (!host && window.parent && window.parent !== window && window.parent.location.origin === window.location.origin) {
                host = window.parent;
            }
        } catch (_) {}

        if (!host || !host.document) return;

        var names = [
            '--background-color','--page-bg','--section-bg','--panel-bg','--card-bg','--input-bg',
            '--text-color','--muted-color','--title-color','--primary-color','--primary-dark','--primary-soft',
            '--border-color','--danger-color','--success-color','--warning-color','--shadow-color',
            '--radius-sm','--radius','--radius-lg','--font-family',
            '--dmdm-background','--dmdm-front','--dmdm-text','--dmdm-border','--dmdm-accent','--dmdm-shadow',
            '--dmdm-background-bg','--dmdm-front-bg','--dmdm-text-color','--dmdm-muted-color',
            '--dmdm-title-color','--dmdm-primary-color','--dmdm-border-color','--dmdm-input-bg',
            '--dmdm-radius-sm','--dmdm-radius','--dmdm-radius-lg'
        ];

        var targets = [document.documentElement, document.body].filter(Boolean);
        [host.document.documentElement, host.document.body].filter(Boolean).forEach(function (sourceRoot) {
            var cs = host.getComputedStyle(sourceRoot);
            names.forEach(function (name) {
                var value = cs.getPropertyValue(name).trim();
                if (value) targets.forEach(function (target) { target.style.setProperty(name, value); });
            });
        });
    }

    applyMyDeskDocumentClass();
    syncThemeFromHost();
    window.addEventListener('DOMContentLoaded', function () {
        applyMyDeskDocumentClass();
        syncThemeFromHost();
    }, { once: true });
})();
</script>
