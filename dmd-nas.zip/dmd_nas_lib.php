<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

define('DMD_NAS_MODULE_ID', 'dmd-nas');

function dmd_nas_core_root() {
    $root = realpath(__DIR__ . '/../..');
    return $root !== false ? $root : dirname(__DIR__, 2);
}
function dmd_nas_boot_core() {
    $root = dmd_nas_core_root();
    foreach (array(
        $root . '/core/dmd_permissions.php',
        $root . '/core/dmd_system_services.php',
        $root . '/core/dmd_activity.php',
        $root . '/core/dmd_module_logs.php',
        $root . '/core/dmd_module_events.php',
        $root . '/core/dmd_quick_session.php',
        $root . '/Quick-Session/dmd_quick_session.php'
    ) as $file) {
        if (is_file($file)) require_once $file;
    }
}
function dmd_nas_session_email() {
    return trim((string)($_SESSION['user']['email'] ?? $_SESSION['email'] ?? $_SESSION['user_email'] ?? ''));
}
function dmd_nas_core_is_admin() {
    $rs = strtolower((string)($_SESSION['role_system'] ?? ($_SESSION['user']['role_system'] ?? '')));
    $r = strtolower((string)($_SESSION['role'] ?? ($_SESSION['user']['role'] ?? '')));
    return in_array($rs, array('admin','administrator','superadmin'), true) || in_array($r, array('admin','administrator','superadmin'), true);
}
function dmd_nas_user_can($email, $permission) {
    $email = trim((string)$email);
    if ($email === '') return false;
    dmd_nas_boot_core();
    if (function_exists('dmd_user_has_module_permission')) {
        try { return (bool)dmd_user_has_module_permission($email, DMD_NAS_MODULE_ID, (string)$permission); }
        catch (Throwable $e) { return false; }
    }
    return false;
}
function dmd_nas_can($permission) {
    $email = dmd_nas_session_email();
    if ($email === '') return false;
    dmd_nas_boot_core();
    if (function_exists('dmd_user_has_module_permission')) {
        try { return (bool)dmd_user_has_module_permission($email, DMD_NAS_MODULE_ID, (string)$permission); }
        catch (Throwable $e) { return false; }
    }
    return false;
}
function dmd_nas_require($permission, $json = false) {
    if (dmd_nas_can($permission)) return true;
    http_response_code(403);
    if ($json) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('ok'=>false,'message'=>'Accès refusé.','permission'=>(string)$permission), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    } else {
        echo 'Accès refusé.';
    }
    exit;
}
function dmd_nas_permissions_snapshot() {
    $ids = array(
        'module.view','nas.list','nas.create','nas.edit','nas.delete','nas.test','nas.scan',
        'nas.refresh','nas.apps.view','nas.apps.manage','nas.containers.view','nas.containers.manage',
        'nas.users.view','nas.users.manage','nas.groups.view','nas.groups.manage','nas.shares.view',
        'nas.shares.manage','nas.shares.permissions','nas.share','nas.audit','config.view','config.edit','actionhub.use'
    );
    $out = array(); foreach ($ids as $id) $out[$id] = dmd_nas_can($id); return $out;
}

function dmd_nas_profile($email) {
    $email = trim((string)$email);
    if ($email === '') return array();
    dmd_nas_boot_core();
    if (function_exists('dmd_read_profile')) {
        try { $p = dmd_read_profile($email); if (is_array($p)) return $p; } catch (Throwable $e) {}
    }
    $root = dmd_nas_core_root() . '/users/profiles/' . $email;
    foreach (array($root.'/profile/profile.json', $root.'/profile.json') as $file) {
        if (is_file($file)) { $j=json_decode((string)@file_get_contents($file),true); if (is_array($j)) return $j; }
    }
    return array();
}
function dmd_nas_user_group_names($email) {
    $p = dmd_nas_profile($email);
    $out = array();
    foreach (array('role_metier','group','groupe') as $k) {
        if (!empty($p[$k]) && is_string($p[$k])) $out[] = trim($p[$k]);
    }
    foreach (array('roles_metier','groups','groupes') as $k) {
        if (!empty($p[$k]) && is_array($p[$k])) foreach ($p[$k] as $v) {
            if (is_string($v) && trim($v)!=='') $out[] = trim($v);
            elseif (is_array($v)) { $n=trim((string)($v['name']??$v['label']??'')); if($n!=='') $out[]=$n; }
        }
    }
    return array_values(array_unique(array_filter($out)));
}
function dmd_nas_item_owner($item) {
    return trim((string)($item['owner_email'] ?? $item['_owner_email'] ?? ''));
}
function dmd_nas_item_shared_with($item, $email) {
    $email = trim((string)$email);
    if ($email === '') return false;
    $owner = dmd_nas_item_owner($item);
    if ($owner !== '' && strcasecmp($owner,$email)===0) return true;
    $users = is_array($item['shared_users'] ?? null) ? $item['shared_users'] : array();
    foreach ($users as $u) if (strcasecmp(trim((string)$u),$email)===0) return true;
    $groups = is_array($item['shared_groups'] ?? null) ? $item['shared_groups'] : array();
    if ($groups) {
        foreach (dmd_nas_user_group_names($email) as $g) foreach ($groups as $want) {
            if (strcasecmp(trim((string)$g),trim((string)$want))===0) return true;
        }
    }
    return false;
}
function dmd_nas_share_catalog() {
    $root = dmd_nas_core_root(); $current=dmd_nas_session_email(); $users=array();
    foreach (glob($root.'/users/profiles/*', GLOB_ONLYDIR) ?: array() as $dir) {
        $email=basename($dir); if ($email==='' || strcasecmp($email,$current)===0) continue;
        $p=dmd_nas_profile($email); $mail=trim((string)($p['email']??$email));
        $label=trim((string)($p['prenom']??'').' '.(string)($p['nom']??'')); if($label==='') $label=$mail;
        $users[]=array('email'=>$mail,'label'=>$label,'role_metier'=>trim((string)($p['role_metier']??'')));
    }
    usort($users,function($a,$b){return strcasecmp($a['label'],$b['label']);});
    $groups=array();
    dmd_nas_boot_core();
    if (function_exists('dmd_roles_catalog')) { try { $groups=dmd_roles_catalog(); } catch(Throwable $e){} }
    if (!$groups) { $f=$root.'/data/roles_metier.json'; $j=is_file($f)?json_decode((string)@file_get_contents($f),true):array(); if(is_array($j)) foreach($j as $k=>$v){$n=is_string($v)?$v:(is_array($v)?($v['name']??$v['label']??(is_string($k)?$k:'')):(is_string($k)?$k:''));$n=trim((string)$n);if($n!=='')$groups[]=$n;} }
    $groups=array_values(array_unique(array_filter($groups))); sort($groups,SORT_NATURAL|SORT_FLAG_CASE);
    return array('users'=>$users,'groups'=>$groups);
}

function dmd_nas_csrf_token() {
    if (empty($_SESSION['dmd_nas_csrf'])) $_SESSION['dmd_nas_csrf'] = bin2hex(random_bytes(24));
    return (string)$_SESSION['dmd_nas_csrf'];
}
function dmd_nas_csrf_check($token) {
    return isset($_SESSION['dmd_nas_csrf']) && is_string($token) && hash_equals((string)$_SESSION['dmd_nas_csrf'], $token);
}
function dmd_nas_require_csrf($json = true) {
    $token = (string)($_POST['csrf'] ?? $_SERVER['HTTP_X_DMD_CSRF'] ?? '');
    if (dmd_nas_csrf_check($token)) return true;
    http_response_code(419);
    if ($json) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(array('ok'=>false,'message'=>'Jeton CSRF invalide ou expiré.'), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }
    exit;
}
function dmd_nas_user_data_root($email = null) {
    $email = trim((string)($email ?: dmd_nas_session_email()));
    if ($email === '') return null;
    return dmd_nas_core_root() . '/users/profiles/' . $email . '/dmd_nas';
}
function dmd_nas_private_dir($dir) {
    if (!$dir) return false;
    if (!is_dir($dir) && !@mkdir($dir, 0770, true) && !is_dir($dir)) return false;
    $ht = rtrim($dir, '/\\') . '/.htaccess';
    if (!is_file($ht)) @file_put_contents($ht, "Require all denied\nDeny from all\n");
    return true;
}
function dmd_nas_copy_tree($src, $dst, $move = false) {
    if (!is_dir($src)) return false;
    dmd_nas_private_dir($dst);
    foreach (scandir($src) ?: array() as $name) {
        if ($name === '.' || $name === '..' || $name === '.htaccess') continue;
        $s=$src.'/'.$name; $d=$dst.'/'.$name;
        if (is_dir($s)) {
            dmd_nas_copy_tree($s,$d,$move);
            if ($move) @rmdir($s);
        } else {
            if (!is_file($d)) @copy($s,$d);
            if ($move && is_file($d)) @unlink($s);
        }
    }
    return true;
}
function dmd_nas_migrate_personal_storage() {
    $dst = dmd_nas_user_data_root();
    if (!$dst) return null;
    foreach (array($dst, $dst.'/logs', $dst.'/secure', $dst.'/activity') as $dir) dmd_nas_private_dir($dir);

    /* Répare les versions précédentes qui stockaient à tort les données personnelles en système/public. */
    $legacyRoots = array(
        dmd_nas_core_root() . '/data/modules/dmd_nas/public',
        dmd_nas_core_root() . '/data/modules/dmd-nas/public',
        __DIR__ . '/data/public'
    );
    foreach ($legacyRoots as $legacy) {
        if (!is_dir($legacy)) continue;
        foreach (scandir($legacy) ?: array() as $vendor) {
            if ($vendor === '.' || $vendor === '..' || $vendor === '.htaccess') continue;
            $srcVendor = $legacy.'/'.$vendor;
            if (!is_dir($srcVendor)) continue;
            $dstVendor = $dst.'/'.$vendor;
            dmd_nas_private_dir($dstVendor);
            foreach (glob($srcVendor.'/*.json') ?: array() as $file) {
                $target=$dstVendor.'/'.basename($file);
                if (!is_file($target)) {
                    $j=json_decode((string)@file_get_contents($file),true);
                    if (is_array($j)) { $j['storage_mode']='private'; @file_put_contents($target,json_encode($j,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX); }
                    else @copy($file,$target);
                }
                if (is_file($target)) @unlink($file);
            }
        }
    }

    /* La clé de chiffrement et les logs appartiennent eux aussi à l'utilisateur. */
    foreach (array(
        dmd_nas_core_root().'/data/modules/dmd_nas/secure/dmd_nas.key',
        dmd_nas_core_root().'/data/modules/dmd-nas/secure/dmd_nas.key',
        __DIR__.'/data/secure/dmd_nas.key'
    ) as $key) {
        if (is_file($key) && !is_file($dst.'/secure/dmd_nas.key')) { @copy($key,$dst.'/secure/dmd_nas.key'); @chmod($dst.'/secure/dmd_nas.key',0600); }
    }
    foreach (array(
        dmd_nas_core_root().'/data/modules/dmd_nas/logs/dmd_nas.log',
        dmd_nas_core_root().'/data/modules/dmd-nas/logs/dmd_nas.log',
        __DIR__.'/data/logs/dmd_nas.log'
    ) as $log) {
        if (is_file($log)) { @file_put_contents($dst.'/logs/dmd_nas.log',(string)@file_get_contents($log),FILE_APPEND|LOCK_EX); @unlink($log); }
    }
    return $dst;
}
function dmd_nas_boot_storage() { return dmd_nas_migrate_personal_storage(); }
function dmd_nas_core_event($event, $resource, $details = array()) {
    dmd_nas_boot_core();
    $payload = array('module'=>DMD_NAS_MODULE_ID,'event'=>$event,'resource'=>$resource,'details'=>$details,'user'=>dmd_nas_session_email());
    if (function_exists('dmd_module_event')) {
        try { dmd_module_event(DMD_NAS_MODULE_ID, $event, $payload); } catch (Throwable $e) {}
    }
    return $payload;
}
