<?php
/** Case compatibility dashboard entrypoint. */
require __DIR__ . '/dmd_nas.php';
