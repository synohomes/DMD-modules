<?php
/** Legacy/alternate MyDesk filename compatibility. */
require __DIR__ . '/DMD-NAS-mydesk.php';
