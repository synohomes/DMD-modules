<?php
/**
 * DoMyDesk - dmd-nascfg.php
 * CFG propre du module dmd_nas.
 * - Pas de couleur imposée : hérite du thème.
 * - Sauvegarde via dmd_nas_api.php action=save/delete/list.
 * - Mot de passe API : champ vide = conservation côté API.
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/dmd_nas_lib.php';
dmd_nas_boot_core();
dmd_nas_boot_storage();
dmd_nas_require('config.view');
$csrf = dmd_nas_csrf_token();
$dmdNasPermissions = dmd_nas_permissions_snapshot();

$vendors = [
    'synology' => 'Synology',
    'qnap' => 'QNAP',
    'asustor' => 'ASUSTOR',
    'truenas' => 'TrueNAS',
    'omv' => 'OpenMediaVault',
    'other' => 'Autre'
];

$roleSystem = strtolower((string)($_SESSION['role_system'] ?? ($_SESSION['user']['role_system'] ?? '')));
$role = strtolower((string)($_SESSION['role'] ?? ($_SESSION['user']['role'] ?? '')));
$isAdmin = in_array($roleSystem, ['admin','administrator','superadmin'], true) || in_array($role, ['admin','administrator','superadmin'], true);

$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/dmd-nas';
if ($documentRoot !== '' && strpos($moduleRealDir, $documentRoot) === 0) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot))), '/');
}
$apiUrl = rtrim($moduleWebPath, '/') . '/dmd_nas_api.php';

function dmdnas_cfg_email(): string {
    return trim((string)($_SESSION['email'] ?? $_SESSION['user_email'] ?? ($_SESSION['user']['email'] ?? '')));
}
function dmdnas_cfg_slug(string $v): string {
    $v = trim($v);
    $v = str_replace(['\\','/','..'], '-', $v);
    $v = preg_replace('/[^a-zA-Z0-9_\-.]+/', '-', $v);
    $v = trim($v, '-_.');
    return $v !== '' ? strtolower($v) : '';
}
function dmdnas_cfg_read_items(array $vendors, bool $isAdmin): array {
    $items = [];
    $moduleDir = __DIR__;
    $domyRoot = realpath($moduleDir . '/../..') ?: dirname($moduleDir, 2);
    $roots = [];
    $email = dmdnas_cfg_email();
    if ($email !== '') {
        $roots[] = ['private', $domyRoot . '/users/profiles/' . $email . '/dmd_nas'];
    }
    $seen = [];
    foreach ($roots as [$storage, $root]) {
        if (!is_dir($root)) continue;
        foreach ($vendors as $vendor => $label) {
            $dir = $root . '/' . $vendor;
            if (!is_dir($dir)) continue;
            foreach (glob($dir . '/*.json') ?: [] as $file) {
                $key = realpath($file) ?: $file;
                if (isset($seen[$key])) continue;
                $seen[$key] = true;
                $json = json_decode((string)@file_get_contents($file), true);
                if (!is_array($json)) continue;
                $id = dmdnas_cfg_slug((string)($json['id'] ?? pathinfo($file, PATHINFO_FILENAME)));
                if ($id === '') continue;
                $v = strtolower((string)($json['vendor'] ?? $vendor));
                $v = array_key_exists($v, $vendors) ? $v : 'other';
                $json['id'] = $id;
                $json['vendor'] = $v;
                $json['vendor_label'] = $vendors[$v] ?? 'Autre';
                $json['storage_mode'] = $storage;
                $json['source_file'] = $key;
                unset($json['api_pass'], $json['api_pass_enc']);
                $json['api_password_saved'] = true;
                $items[] = $json;
            }
        }
    }
    usort($items, static fn($a, $b) => strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? '')));
    return $items;
}
$initialItems = dmdnas_cfg_read_items($vendors, $isAdmin);
$shareCatalog = dmd_nas_share_catalog();

$uid = 'dmdNasCfg_' . substr(md5(__DIR__ . microtime(true)), 0, 8);
?>
<div class="dmdnas-cfg" id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>" data-api="<?= htmlspecialchars($apiUrl, ENT_QUOTES, 'UTF-8') ?>" data-admin="<?= $isAdmin ? '1' : '0' ?>" data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
    <div class="dmdnas-cfg-top">
        <div>
            <h3>NAS</h3>
            <p>Gestion des NAS enregistrés, accès admin, API constructeur, applications, Docker et partages.</p>
        </div>
        <button type="button" class="dmdnas-btn" data-new>+ Nouveau NAS</button>
    </div>

    <div class="dmdnas-cfg-grid">
        <aside class="dmdnas-cfg-side">
            <div class="dmdnas-side-head">
                <strong>NAS enregistrés</strong>
                <small data-count>0</small>
            </div>
            <div class="dmdnas-nas-list" data-list></div>
        </aside>

        <section class="dmdnas-cfg-panel">
            <form data-form>
                <input type="hidden" name="action" value="save">
                <input type="hidden" name="id" data-id>
                <input type="hidden" name="original_id" data-original-id>
                <input type="hidden" name="original_vendor" data-original-vendor>
                <input type="hidden" name="original_storage_mode" data-original-storage>
                <input type="hidden" name="applications_json" data-apps-json value="[]">
                <input type="hidden" name="dockers_json" data-dockers-json value="[]">
                <input type="hidden" name="shares_json" data-shares-json value="[]">
                <input type="hidden" name="shared_users_json" data-shared-users-json value="[]">
                <input type="hidden" name="shared_groups_json" data-shared-groups-json value="[]">

                <div class="dmdnas-form-head">
                    <h4 data-title>Ajouter un NAS</h4>
                    <div class="dmdnas-form-actions dmdnas-form-actions-top">
                        <button type="submit" class="dmdnas-btn">Enregistrer</button>
                        <button type="button" class="dmdnas-btn" data-reset>Réinitialiser</button>
                        <button type="button" class="dmdnas-btn dmdnas-danger" data-delete hidden>Supprimer</button>
                    </div>
                </div>

                <nav class="dmdnas-tabs" aria-label="Sections configuration NAS">
                    <button type="button" class="is-active" data-tab-btn="identity">Identité</button>
                    <button type="button" data-tab-btn="api">API NAS</button>
                    <button type="button" data-tab-btn="apps">Applications / Docker</button>
                    <button type="button" data-tab-btn="shares">Partages / Notes</button>
                    <?php if (!empty($dmdNasPermissions['nas.share'])): ?><button type="button" data-tab-btn="access">Partager le NAS</button><?php endif; ?>
                </nav>

                <div class="dmdnas-tab is-active" data-tab="identity">
                    <div class="dmdnas-fields">
                        <label><span>Nom</span><input name="name" data-name required placeholder="NAS-DEV"></label>
                        <label><span>Constructeur</span><select name="vendor" data-vendor><?php foreach ($vendors as $k => $v): ?><option value="<?= htmlspecialchars($k, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($v, ENT_QUOTES, 'UTF-8') ?></option><?php endforeach; ?></select></label>
                        <label><span>Modèle</span><input name="model" data-model placeholder="DS420, DS923+, TS-464..."></label>
                        <label><span>IP</span><input name="ip" data-ip placeholder="10.10.3.110"></label>
                        <label><span>Hostname</span><input name="hostname" data-hostname placeholder="nas.local"></label>
                        <label><span>Protocole</span><select name="protocol" data-protocol><option value="http">HTTP</option><option value="https">HTTPS</option></select></label>
                        <label><span>Port admin</span><input name="admin_port" data-port placeholder="5000 / 5001 / 8080"></label>
                        <label><span>URL admin</span><input name="admin_url" data-admin-url placeholder="http://10.10.3.110:5000"></label>
                        <input type="hidden" name="storage_mode" data-storage value="private">
                        <label><span>Actif</span><select name="enabled" data-enabled><option value="1">Oui</option><option value="0">Non</option></select></label>
                    </div>
                </div>

                <div class="dmdnas-tab" data-tab="api">
                    <div class="dmdnas-help">
                        Choisis le constructeur : DMD-NAS adapte automatiquement l’API. Synology utilise l’URL racine DSM ; QNAP utilise l’URL racine QTS/QuTS (ex. <code>http://10.10.3.120:8080</code>).
                    </div>
                    <div class="dmdnas-fields">
                        <label><span>API constructeur</span><select name="api_type" data-api-type><option value="none">Aucune</option><option value="synology">Synology DSM</option><option value="qnap">QNAP QTS</option></select></label>
                        <label><span>URL API</span><input name="api_url" data-api-url placeholder="http://10.10.3.110:5000"></label>
                        <label><span>Utilisateur API</span><input name="api_user" data-api-user autocomplete="off" placeholder="domydesk_api"></label>
                        <label><span>Mot de passe API</span><input type="password" name="api_pass" data-api-pass autocomplete="new-password" placeholder="Vide = conserver le mot de passe enregistré"></label>
                        <label><span>Session API</span><input name="api_session" data-api-session placeholder="DSM"></label>
                    </div>
                    <div class="dmdnas-form-actions" style="margin-top:8px"><button type="button" class="dmdnas-btn" data-probe-api>Tester la connexion API</button></div>
                    <p class="dmdnas-muted">Le mot de passe n’est pas réaffiché. Il est transmis uniquement si tu remplis ce champ. Pour un nouveau QNAP, sélectionne QNAP : le port 8080 et l’API QTS sont préconfigurés automatiquement.</p>
                </div>

                <div class="dmdnas-tab" data-tab="apps">
                    <h5>Applications déclarées</h5>
                    <div class="dmdnas-chip-box" data-apps></div>
                    <div class="dmdnas-inline">
                        <input data-app-name placeholder="Nom application">
                        <input data-app-url placeholder="URL">
                        <button type="button" class="dmdnas-btn" data-add-app>Ajouter</button>
                    </div>

                    <h5>Docker / containers déclarés</h5>
                    <div class="dmdnas-chip-box" data-dockers></div>
                    <div class="dmdnas-inline dmdnas-inline-4">
                        <input data-docker-name placeholder="Nom">
                        <input data-docker-url placeholder="URL">
                        <input data-docker-port placeholder="Port">
                        <button type="button" class="dmdnas-btn" data-add-docker>Ajouter</button>
                    </div>
                </div>

                <div class="dmdnas-tab" data-tab="shares">
                    <h5>Partages / chemins</h5>
                    <div class="dmdnas-chip-box" data-shares></div>
                    <div class="dmdnas-inline dmdnas-inline-4">
                        <input data-share-name placeholder="Nom">
                        <select data-share-volume>
                            <option value="custom">Chemin complet</option>
                        </select>
                        <input data-share-folder placeholder="Backups/DoMyDesk ou chemin complet">
                        <button type="button" class="dmdnas-btn" data-add-share>Ajouter</button>
                    </div>

                    <div class="dmdnas-fields dmdnas-fields-one">
                        <label><span>Chemin backup</span><input name="backup_path" data-backup placeholder="/volume1/Backups/DoMyDesk"></label>
                        <label><span>Notes</span><textarea name="notes" data-notes rows="5" placeholder="Notes internes..."></textarea></label>
                    </div>
                </div>

                <?php if (!empty($dmdNasPermissions['nas.share'])): ?>
                <div class="dmdnas-tab" data-tab="access">
                    <div class="dmdnas-help">Le NAS reste enregistré dans ton dossier personnel. Les personnes et groupes sélectionnés le verront sur leur dashboard et pourront agir uniquement selon leurs propres droits DMD-NAS.</div>
                    <div class="dmdnas-share-grid">
                        <label><span>Utilisateurs DoMyDesk</span><select multiple size="8" data-shared-users><?php foreach (($shareCatalog['users'] ?? []) as $u): ?><option value="<?= htmlspecialchars($u['email'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($u['label'].' · '.$u['email'], ENT_QUOTES, 'UTF-8') ?></option><?php endforeach; ?></select></label>
                        <label><span>Groupes / rôles métier</span><select multiple size="8" data-shared-groups><?php foreach (($shareCatalog['groups'] ?? []) as $g): ?><option value="<?= htmlspecialchars($g, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($g, ENT_QUOTES, 'UTF-8') ?></option><?php endforeach; ?></select></label>
                    </div>
                    <div class="dmdnas-share-actions">
                        <button type="button" class="dmdnas-btn" data-apply-sharing>Appliquer le partage</button>
                        <button type="button" class="dmdnas-btn" data-clear-sharing>Rendre privé</button>
                        <span class="dmdnas-muted" data-sharing-state></span>
                    </div>
                    <p class="dmdnas-muted">Ctrl/Cmd + clic pour sélectionner plusieurs entrées, puis clique sur <strong>Appliquer le partage</strong>.</p>
                </div>
                <?php endif; ?>

                <p class="dmdnas-msg" data-msg></p>
            </form>
        </section>
    </div>
</div>

<script>
(function(){
    const root = document.getElementById(<?= json_encode($uid) ?>);
    if (!root || root.dataset.ready === '1') return;
    root.dataset.ready = '1';

    const api = root.dataset.api;
    const csrf = root.dataset.csrf || '';
    const permissions = <?= json_encode($dmdNasPermissions, JSON_UNESCAPED_UNICODE) ?>;
    const vendors = <?= json_encode($vendors, JSON_UNESCAPED_UNICODE) ?>;
    let items = <?= json_encode($initialItems, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>, current = null, apps = [], dockers = [], shares = [], sharedUsers = [], sharedGroups = [];
    const initialItems = items.slice();

    const form = root.querySelector('[data-form]');
    const list = root.querySelector('[data-list]');
    const msg = root.querySelector('[data-msg]');
    const count = root.querySelector('[data-count]');

    const css = document.createElement('style');
    css.textContent = `
#${root.id}{box-sizing:border-box;padding:14px;max-width:100%;overflow:visible;color:var(--text-color,inherit);background:transparent}
#${root.id} *{box-sizing:border-box}
#${root.id} h3,#${root.id} h4,#${root.id} h5{color:var(--title-color,var(--primary-color,inherit))}
#${root.id} input,#${root.id} select,#${root.id} textarea,#${root.id} button{font:inherit;color:var(--text-color,inherit);border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px)}
#${root.id} input,#${root.id} select,#${root.id} textarea{width:100%;padding:9px 10px;min-height:38px;background:var(--input-bg,var(--panel-bg,transparent))}
#${root.id} textarea{resize:vertical}
#${root.id} button{cursor:pointer;padding:8px 12px;background:var(--button-bg,var(--panel-bg,transparent))}
#${root.id} button:hover{background:var(--button-hover,var(--primary-soft,var(--card-bg,transparent)))}
#${root.id} .dmdnas-btn{background:var(--button-bg,var(--panel-bg,transparent));border-color:var(--border-color,currentColor)}
#${root.id} .dmdnas-btn:hover{background:var(--button-hover,var(--primary-soft,var(--card-bg,transparent)))}
#${root.id} .dmdnas-danger{color:var(--danger-color,inherit);border-color:var(--danger-color,var(--border-color,currentColor))}
#${root.id} h3,#${root.id} h4,#${root.id} h5,#${root.id} p{margin-top:0}
#${root.id} .dmdnas-cfg-top{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px}
#${root.id} .dmdnas-cfg-top p{color:var(--muted-color,inherit);opacity:1;margin-bottom:0}
#${root.id} .dmdnas-cfg-grid{display:grid;grid-template-columns:minmax(230px,330px) minmax(0,1fr);gap:16px;align-items:start}
#${root.id} .dmdnas-cfg-side,#${root.id} .dmdnas-cfg-panel{border:1px solid var(--border-color,currentColor);border-radius:var(--radius,12px);padding:14px;min-width:0;background:var(--section-bg,transparent);box-shadow:0 8px 24px var(--shadow-color,transparent)}
#${root.id} .dmdnas-side-head,#${root.id} .dmdnas-form-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
#${root.id} .dmdnas-nas-list{display:grid;gap:8px}
#${root.id} .dmdnas-nas-card{width:100%;text-align:left;display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;padding:11px 12px;background:var(--card-bg,var(--panel-bg,transparent));border-color:var(--border-color,currentColor)}
#${root.id} .dmdnas-nas-card:hover{background:var(--primary-soft,var(--panel-bg,transparent))}
#${root.id} .dmdnas-nas-card small,#${root.id} .dmdnas-muted,#${root.id} .dmdnas-help{color:var(--muted-color,inherit);opacity:1}
#${root.id} .dmdnas-nas-card.is-active{outline:2px solid var(--primary-color,currentColor);outline-offset:2px}
#${root.id} .dmdnas-form-actions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
#${root.id} .dmdnas-tabs{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 14px}
#${root.id} .dmdnas-tabs button{opacity:.82}
#${root.id} .dmdnas-tabs button.is-active{opacity:1;color:var(--primary-color,inherit);border-color:var(--primary-color,var(--border-color,currentColor));background:var(--primary-soft,var(--panel-bg,transparent));outline:none}
#${root.id} .dmdnas-tab{display:none}
#${root.id} .dmdnas-tab.is-active{display:block}
#${root.id} .dmdnas-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
#${root.id} .dmdnas-fields-one{grid-template-columns:1fr;margin-top:14px}
#${root.id} label span{display:block;font-weight:700;margin-bottom:5px;color:var(--text-color,inherit)}
#${root.id} .dmdnas-help{border:1px dashed var(--border-color,currentColor);border-radius:var(--radius-sm,8px);padding:10px;margin-bottom:12px;background:var(--panel-bg,transparent)}
#${root.id} .dmdnas-inline{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr) auto;gap:8px;margin:8px 0 18px}
#${root.id} .dmdnas-inline-4{grid-template-columns:minmax(0,1fr) minmax(0,1fr) 130px auto}
#${root.id} .dmdnas-chip-box{display:flex;gap:7px;flex-wrap:wrap;margin:8px 0 10px;min-height:28px}
#${root.id} .dmdnas-chip{display:inline-flex;align-items:center;gap:6px;border:1px dashed var(--border-color,currentColor);border-radius:999px;padding:5px 8px;max-width:100%;background:var(--card-bg,var(--panel-bg,transparent))}
#${root.id} .dmdnas-chip button{padding:0 6px;border-radius:999px;min-height:24px}
#${root.id} .dmdnas-msg{margin:12px 0 0;font-weight:700;min-height:22px;color:var(--text-color,inherit)}
#${root.id} .dmdnas-msg[data-ok="1"]{color:var(--success-color,var(--text-color,inherit))}
#${root.id} .dmdnas-msg[data-ok="0"]{color:var(--danger-color,var(--text-color,inherit))}
@media(max-width:850px){#${root.id} .dmdnas-cfg-grid{grid-template-columns:1fr}#${root.id} .dmdnas-fields,#${root.id} .dmdnas-inline,#${root.id} .dmdnas-inline-4,#${root.id} .dmdnas-share-grid{grid-template-columns:1fr}#${root.id} .dmdnas-form-head{align-items:flex-start;flex-direction:column}#${root.id} .dmdnas-form-actions{justify-content:flex-start}}
`;
    document.head.appendChild(css);

    function esc(v){return String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));}
    function setMsg(text, ok){msg.textContent = text || ''; msg.dataset.ok = ok ? '1' : '0';}

    async function apiCall(action, body){
        body = body || new URLSearchParams();
        body.set('action', action); body.set('csrf', root.dataset.csrf || '');
        body.set('csrf', csrf);
        const res = await fetch(api, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body});
        const txt = await res.text();
        let json;
        try { json = JSON.parse(txt); } catch(e) { throw new Error('API non JSON : ' + txt.slice(0, 220)); }
        if (!json.ok) throw new Error(json.message || 'Erreur API');
        return json;
    }

    async function load(){
        const res = await fetch(api + '?action=list', {credentials:'same-origin'});
        const txt = await res.text();
        let json;
        try { json = JSON.parse(txt); } catch(e) { throw new Error('Liste NAS non JSON : ' + txt.slice(0, 220)); }
        const apiItems = Array.isArray(json.items) ? json.items : [];
        items = apiItems.length ? apiItems : initialItems;
        renderList();
    }

    function renderList(){
        count.textContent = items.length;
        if (!items.length) { list.innerHTML = '<p>Aucun NAS enregistré.</p>'; return; }
        list.innerHTML = items.map(item => {
            const active = current && current.id === item.id && current.vendor === item.vendor && current.storage_mode === item.storage_mode ? ' is-active' : '';
            return `<button type="button" class="dmdnas-nas-card${active}" data-id="${esc(item.id)}" data-vendor="${esc(item.vendor)}" data-storage="${esc(item.storage_mode)}">
                <span><strong>${esc(item.name || 'NAS')}</strong><br><small>${esc(vendors[item.vendor] || 'Autre')} · ${esc(item.ip || item.hostname || '-')} · privé</small></span>
                <small>${item.api_type && item.api_type !== 'none' ? 'API' : ''}</small>
            </button>`;
        }).join('');
    }

    function normalizeArrays(item){
        apps = Array.isArray(item.applications) ? item.applications.slice() : (Array.isArray(item.modules) ? item.modules.slice() : []);
        dockers = Array.isArray(item.dockers) ? item.dockers.slice() : [];
        shares = Array.isArray(item.shares) ? item.shares.slice() : [];
        sharedUsers = Array.isArray(item.shared_users) ? item.shared_users.slice() : [];
        sharedGroups = Array.isArray(item.shared_groups) ? item.shared_groups.slice() : [];
    }


    function collectRealVolumesFromObject(obj, found){
        if (!obj || typeof obj !== 'object') return;
        if (Array.isArray(obj)) {
            obj.forEach(v => collectRealVolumesFromObject(v, found));
            return;
        }
        Object.keys(obj).forEach(k => {
            const v = obj[k];
            if (typeof v === 'string') {
                const m = v.match(/(\/volume\d+)(?:\/|$)/i);
                if (m) found.add(m[1]);
                if (/^Volume\s*\d+$/i.test(v)) found.add('/volume' + (v.match(/\d+/)||['1'])[0]);
            } else if (v && typeof v === 'object') {
                collectRealVolumesFromObject(v, found);
            }
        });
    }

    function getNasVolumes(item){
        const found = new Set();
        if (item && item.dsm_info) {
            if (Array.isArray(item.dsm_info.volumes)) {
                item.dsm_info.volumes.forEach(v => {
                    const path = v.path || v.volume_path || v.mount_path || v.id || v.name || '';
                    if (typeof path === 'string') {
                        const m = path.match(/(\/volume\d+)(?:\/|$)/i);
                        if (m) found.add(m[1]);
                        if (/^Volume\s*\d+$/i.test(path)) found.add('/volume' + (path.match(/\d+/)||['1'])[0]);
                    }
                });
            }
            collectRealVolumesFromObject(item.dsm_info.shares || item.dsm_info.shared_folders || [], found);
            collectRealVolumesFromObject(item.dsm_info, found);
        }
        return Array.from(found).sort((a,b)=>a.localeCompare(b, undefined, {numeric:true}));
    }

    function renderVolumeSelect(){
        const sel = root.querySelector('[data-share-volume]');
        if (!sel) return;
        const volumes = current ? getNasVolumes(current) : [];
        if (!volumes.length) {
            sel.innerHTML = '<option value="custom">Chemin complet</option>';
            sel.title = 'Aucun volume réel détecté. Fais Actualiser DSM dans la fiche NAS puis recharge le CFG.';
            return;
        }
        sel.innerHTML = volumes.map(v => `<option value="${esc(v)}">${esc(v)}</option>`).join('') + '<option value="custom">Chemin complet</option>';
        sel.title = 'Volumes détectés depuis les infos DSM du NAS sélectionné.';
    }

    function syncSharingSelections(){
        const us = root.querySelector('[data-shared-users]');
        const gs = root.querySelector('[data-shared-groups]');
        if (us) Array.from(us.options).forEach(o => { o.selected = sharedUsers.includes(o.value); });
        if (gs) Array.from(gs.options).forEach(o => { o.selected = sharedGroups.includes(o.value); });
        const state = root.querySelector('[data-sharing-state]');
        if (state) state.textContent = (sharedUsers.length || sharedGroups.length) ? `${sharedUsers.length} utilisateur(s) · ${sharedGroups.length} groupe(s)` : 'NAS privé';
    }

    function collectSharingSelections(){
        const us = root.querySelector('[data-shared-users]');
        const gs = root.querySelector('[data-shared-groups]');
        sharedUsers = us ? Array.from(us.selectedOptions).map(o => o.value) : [];
        sharedGroups = gs ? Array.from(gs.selectedOptions).map(o => o.value) : [];
    }

    async function applySharing(){
        if (!current || !current.id) throw new Error('Sélectionne d’abord un NAS enregistré.');
        collectSharingSelections();
        const body = new URLSearchParams();
        body.set('id', current.id);
        body.set('vendor', current.vendor || 'other');
        body.set('storage_mode', current.storage_mode || 'private');
        body.set('shared_users_json', JSON.stringify(sharedUsers));
        body.set('shared_groups_json', JSON.stringify(sharedGroups));
        const json = await apiCall('share_update', body);
        if (json.item) {
            const idx = items.findIndex(x => x.id === json.item.id && x.vendor === json.item.vendor && x.storage_mode === json.item.storage_mode);
            if (idx >= 0) items[idx] = json.item;
            current = json.item;
            normalizeArrays(json.item);
            syncSharingSelections();
            renderList();
        }
        return json;
    }

    function buildSaveBody(){
        renderArrays();
        return new URLSearchParams(new FormData(form));
    }

    async function saveCurrentSilent(){
        const body = buildSaveBody();
        const json = await apiCall('save', body);
        if (json.item) {
            const idx = items.findIndex(x => x.id === json.item.id && x.vendor === json.item.vendor && x.storage_mode === json.item.storage_mode);
            if (idx >= 0) items[idx] = json.item; else items.push(json.item);
            current = json.item;
            renderList();
            fillForm(json.item);
        }
        return json;
    }

    function renderArrays(){
        root.querySelector('[data-apps-json]').value = JSON.stringify(apps);
        root.querySelector('[data-dockers-json]').value = JSON.stringify(dockers);
        root.querySelector('[data-shares-json]').value = JSON.stringify(shares);
        const su = root.querySelector('[data-shared-users-json]'); if (su) su.value = JSON.stringify(sharedUsers);
        const sg = root.querySelector('[data-shared-groups-json]'); if (sg) sg.value = JSON.stringify(sharedGroups);

        root.querySelector('[data-apps]').innerHTML = apps.length ? apps.map((x,i) => `<span class="dmdnas-chip"><strong>${esc(x.name || 'App')}</strong>${x.url ? `<small>${esc(x.url)}</small>` : ''}<button type="button" data-rm-app="${i}">×</button></span>`).join('') : '<p>Aucune application.</p>';
        root.querySelector('[data-dockers]').innerHTML = dockers.length ? dockers.map((x,i) => `<span class="dmdnas-chip"><strong>${esc(x.name || 'Docker')}</strong>${x.port ? `<small>:${esc(x.port)}</small>` : ''}<button type="button" data-rm-docker="${i}">×</button></span>`).join('') : '<p>Aucun Docker.</p>';
        root.querySelector('[data-shares]').innerHTML = shares.length ? shares.map((x,i) => `<span class="dmdnas-chip"><strong>${esc(x.name || x.path || 'Partage')}</strong>${x.path ? `<small>${esc(x.path)}</small>` : ''}<button type="button" data-rm-share="${i}">×</button></span>`).join('') : '<p>Aucun partage.</p>';
    }

    function resetForm(){
        current = null; apps = []; dockers = []; shares = []; sharedUsers = []; sharedGroups = [];
        form.reset();
        root.querySelector('[data-id]').value = '';
        root.querySelector('[data-original-id]').value = '';
        root.querySelector('[data-original-vendor]').value = '';
        root.querySelector('[data-original-storage]').value = '';
        root.querySelector('[data-title]').textContent = 'Ajouter un NAS';
        root.querySelector('[data-delete]').hidden = true;
        root.querySelector('[data-api-session]').value = 'DSM';
        root.querySelector('[data-vendor]').value = 'synology';
        root.querySelector('[data-api-type]').value = 'synology';
        renderArrays(); syncSharingSelections(); renderList(); setMsg('', true);
        openTab('identity');
    }

    function fillForm(item){
        current = item; normalizeArrays(item);
        root.querySelector('[data-id]').value = item.id || '';
        root.querySelector('[data-original-id]').value = item.id || '';
        root.querySelector('[data-original-vendor]').value = item.vendor || 'other';
        root.querySelector('[data-original-storage]').value = item.storage_mode || 'private';
        root.querySelector('[data-name]').value = item.name || '';
        root.querySelector('[data-vendor]').value = item.vendor || 'other';
        root.querySelector('[data-model]').value = item.model || '';
        root.querySelector('[data-ip]').value = item.ip || '';
        root.querySelector('[data-hostname]').value = item.hostname || '';
        root.querySelector('[data-protocol]').value = item.protocol || 'http';
        root.querySelector('[data-port]').value = item.admin_port || '';
        root.querySelector('[data-admin-url]').value = item.admin_url || '';
        root.querySelector('[data-storage]').value = item.storage_mode || 'private';
        root.querySelector('[data-enabled]').value = item.enabled === false ? '0' : '1';
        root.querySelector('[data-api-type]').value = item.api_type || 'none';
        root.querySelector('[data-api-url]').value = item.api_url || '';
        root.querySelector('[data-api-user]').value = item.api_user || '';
        root.querySelector('[data-api-pass]').value = '';
        root.querySelector('[data-api-session]').value = item.api_session || 'DSM';
        root.querySelector('[data-backup]').value = item.backup_path || '';
        root.querySelector('[data-notes]').value = item.notes || '';
        root.querySelector('[data-title]').textContent = 'Modifier un NAS';
        root.querySelector('[data-delete]').hidden = false;
        renderArrays();
        syncSharingSelections();
        renderVolumeSelect(); renderList(); setMsg('', true);
    }

    function openTab(tab){
        root.querySelectorAll('[data-tab-btn]').forEach(btn => btn.classList.toggle('is-active', btn.dataset.tabBtn === tab));
        root.querySelectorAll('[data-tab]').forEach(panel => panel.classList.toggle('is-active', panel.dataset.tab === tab));
    }

    function syncVendorDefaults(force=false){
        const vendor = root.querySelector('[data-vendor]').value || 'other';
        const protocol = root.querySelector('[data-protocol]').value || 'http';
        const ip = root.querySelector('[data-ip]').value.trim();
        const host = root.querySelector('[data-hostname]').value.trim();
        const target = ip || host;
        const portEl = root.querySelector('[data-port]');
        const apiType = root.querySelector('[data-api-type]');
        const apiUrl = root.querySelector('[data-api-url]');
        const adminUrl = root.querySelector('[data-admin-url]');
        const sess = root.querySelector('[data-api-session]');
        if (vendor === 'qnap') {
            apiType.value = 'qnap';
            if (force || !portEl.value.trim() || ['5000','5001'].includes(portEl.value.trim())) portEl.value = protocol === 'https' ? '443' : '8080';
            sess.value = 'QTS';
        } else if (vendor === 'synology') {
            apiType.value = 'synology';
            if (force || !portEl.value.trim() || ['8080','443'].includes(portEl.value.trim())) portEl.value = protocol === 'https' ? '5001' : '5000';
            sess.value = 'DSM';
        }
        if (target) {
            const u = protocol + '://' + target + (portEl.value.trim() ? ':' + portEl.value.trim() : '');
            if (force || !adminUrl.value.trim()) adminUrl.value = u;
            if (force || !apiUrl.value.trim()) apiUrl.value = u;
        }
    }

    root.querySelector('[data-vendor]').addEventListener('change', ()=>syncVendorDefaults(true));
    root.querySelector('[data-protocol]').addEventListener('change', ()=>syncVendorDefaults(true));
    root.querySelector('[data-ip]').addEventListener('blur', ()=>syncVendorDefaults(false));
    root.querySelector('[data-hostname]').addEventListener('blur', ()=>syncVendorDefaults(false));

    root.addEventListener('click', async function(e){
        const tabBtn = e.target.closest('[data-tab-btn]');
        if (tabBtn) { openTab(tabBtn.dataset.tabBtn); return; }

        if (e.target.closest('[data-probe-api]')) {
            syncVendorDefaults(false);
            setMsg('Test de connexion API...', true);
            try {
                const body = new URLSearchParams(new FormData(form));
                const json = await apiCall('probe_config', body);
                setMsg(json.message || 'Connexion API réussie.', true);
            } catch(err) { setMsg(err.message || String(err), false); }
            return;
        }

        if (e.target.closest('[data-apply-sharing]')) {
            setMsg('Application du partage...', true);
            try { const json = await applySharing(); setMsg(json.message || 'Partage appliqué.', true); }
            catch(err) { setMsg(err.message || String(err), false); }
            return;
        }
        if (e.target.closest('[data-clear-sharing]')) {
            const us = root.querySelector('[data-shared-users]'); const gs = root.querySelector('[data-shared-groups]');
            if (us) Array.from(us.options).forEach(o => o.selected = false);
            if (gs) Array.from(gs.options).forEach(o => o.selected = false);
            sharedUsers = []; sharedGroups = [];
            setMsg('Suppression du partage...', true);
            try { const json = await applySharing(); setMsg(json.message || 'NAS rendu privé.', true); }
            catch(err) { setMsg(err.message || String(err), false); }
            return;
        }

        const nasBtn = e.target.closest('.dmdnas-nas-card');
        if (nasBtn) {
            const item = items.find(x => x.id === nasBtn.dataset.id && x.vendor === nasBtn.dataset.vendor && x.storage_mode === nasBtn.dataset.storage);
            if (item) fillForm(item);
            return;
        }

        if (e.target.closest('[data-new]')) { resetForm(); return; }
        if (e.target.closest('[data-reset]')) { resetForm(); return; }

        if (e.target.closest('[data-add-app]')) {
            const name = root.querySelector('[data-app-name]').value.trim();
            const url = root.querySelector('[data-app-url]').value.trim();
            if (name) { apps.push({name, url}); root.querySelector('[data-app-name]').value=''; root.querySelector('[data-app-url]').value=''; renderArrays(); }
            return;
        }
        if (e.target.closest('[data-add-docker]')) {
            const name = root.querySelector('[data-docker-name]').value.trim();
            const url = root.querySelector('[data-docker-url]').value.trim();
            const port = root.querySelector('[data-docker-port]').value.trim();
            if (name) { dockers.push({name, url, port}); root.querySelector('[data-docker-name]').value=''; root.querySelector('[data-docker-url]').value=''; root.querySelector('[data-docker-port]').value=''; renderArrays(); }
            return;
        }
        if (e.target.closest('[data-add-share]')) {
            const name = root.querySelector('[data-share-name]').value.trim();
            const volume = root.querySelector('[data-share-volume]').value;
            const folder = root.querySelector('[data-share-folder]').value.trim().replace(/^\/+/, '');
            let path = '';
            if (volume === 'custom') path = folder;
            else path = folder ? (volume.replace(/\/$/, '') + '/' + folder) : volume;
            if (name || path) {
                shares.push({name: name || path, path, volume: volume === 'custom' ? '' : volume});
                root.querySelector('[data-share-name]').value='';
                root.querySelector('[data-share-folder]').value='';
                renderArrays();
                if (current && current.id) {
                    setMsg('Partage ajouté, enregistrement...', true);
                    try { await saveCurrentSilent(); setMsg('Partage enregistré dans le NAS existant.', true); }
                    catch(err) { setMsg(err.message || String(err), false); }
                } else {
                    setMsg('Partage ajouté. Clique Enregistrer pour créer le NAS.', true);
                }
            }
            return;
        }

        const rmApp = e.target.closest('[data-rm-app]');
        if (rmApp) { apps.splice(parseInt(rmApp.dataset.rmApp,10),1); renderArrays(); return; }
        const rmDocker = e.target.closest('[data-rm-docker]');
        if (rmDocker) { dockers.splice(parseInt(rmDocker.dataset.rmDocker,10),1); renderArrays(); return; }
        const rmShare = e.target.closest('[data-rm-share]');
        if (rmShare) { shares.splice(parseInt(rmShare.dataset.rmShare,10),1); renderArrays(); return; }
    });

    form.addEventListener('submit', async function(e){
        e.preventDefault();
        renderArrays();
        setMsg('Enregistrement...', true);
        try {
            const json = await apiCall('save', buildSaveBody());
            setMsg(json.message || 'NAS enregistré.', true);
            await load();
            if (json.item) fillForm(json.item);
        } catch(err) {
            setMsg(err.message, false);
        }
    });

    root.querySelector('[data-delete]').addEventListener('click', async function(){
        if (!current || !confirm('Supprimer ce NAS ?')) return;
        setMsg('Suppression...', true);
        try {
            const body = new URLSearchParams();
            body.set('id', current.id);
            body.set('vendor', current.vendor);
            body.set('storage_mode', current.storage_mode);
            const json = await apiCall('delete', body);
            setMsg(json.message || 'NAS supprimé.', true);
            resetForm();
            await load();
        } catch(err) {
            setMsg(err.message, false);
        }
    });

    resetForm();
    renderList();
    load().catch(err => { renderList(); setMsg(err.message, false); });
})();
</script>
