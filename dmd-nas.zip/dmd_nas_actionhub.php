<?php
require_once __DIR__ . '/dmd_nas_lib.php';
function dmd_nas_actionhub_local_id($resource) {
    if (!is_array($resource)) return '';
    $id=trim((string)($resource['id']??''));
    if (strpos($id,'dmd-nas:nas:')===0) $id=substr($id,strlen('dmd-nas:nas:'));
    elseif (strpos($id,'dmd_nas:nas:')===0) $id=substr($id,strlen('dmd_nas:nas:')); // compat anciennes ressources
    return preg_replace('/[^a-zA-Z0-9_.-]+/','',$id);
}
function dmd_nas_actionhub_handle($context) {
    $context=is_array($context)?$context:array(); $email=trim((string)($context['email']??''));
    $action=is_array($context['action']??null)?$context['action']:array(); $actionId=trim((string)($action['id']??''));
    $resource=is_array($context['resource']??null)?$context['resource']:array(); $payload=is_array($context['payload']??null)?$context['payload']:array();
    if ($email==='') return array('ok'=>false,'error'=>'invalid_user','message'=>'Utilisateur ActionHub invalide.');
    $permMap=array('nas.open'=>'module.view','nas.open-admin'=>'module.view','nas.test'=>'nas.test','nas.refresh'=>'nas.refresh','nas.scan'=>'nas.scan','nas.system'=>'nas.system.view','nas.storage'=>'nas.storage.view','nas.network'=>'nas.network.view','nas.updates'=>'nas.updates.view','nas.security'=>'nas.security.view','nas.tasks'=>'nas.tasks.view','nas.reboot'=>'nas.power.manage','nas.shutdown'=>'nas.power.manage');
    $required=$permMap[$actionId] ?? 'actionhub.use';
    if (!dmd_nas_user_can($email,$required) || !dmd_nas_user_can($email,'actionhub.use')) return array('ok'=>false,'error'=>'forbidden','message'=>'Droit ActionHub DMD-NAS refusé.');
    if ($actionId==='nas.open') return array('ok'=>true,'message'=>'Ouverture du NAS.','data'=>array('module'=>DMD_NAS_MODULE_ID,'command'=>'open-nas','nas_id'=>dmd_nas_actionhub_local_id($resource)),'event_emitted'=>true);
    if ($actionId==='nas.open-admin') return array('ok'=>true,'message'=>'Ouverture de l’administration du NAS.','data'=>array('module'=>DMD_NAS_MODULE_ID,'command'=>'open-admin','nas_id'=>dmd_nas_actionhub_local_id($resource)),'event_emitted'=>true);
    if (in_array($actionId,array('nas.test','nas.refresh','nas.scan','nas.system','nas.storage','nas.network','nas.updates','nas.security','nas.tasks','nas.reboot','nas.shutdown'),true)) return array('ok'=>true,'message'=>'Action NAS transmise au module.','data'=>array('module'=>DMD_NAS_MODULE_ID,'command'=>$actionId,'nas_id'=>dmd_nas_actionhub_local_id($resource),'payload'=>$payload),'event_emitted'=>true);
    return array('ok'=>false,'error'=>'unknown_action','message'=>'Action ActionHub DMD-NAS inconnue.');
}
