<?php
/**
 * DMD-NAS — connecteur QNAP QTS / QuTS hero.
 * Compatibilité: QTS 4.x/5.x, QuTS hero lorsque les CGI classiques sont exposés.
 * Les capacités sont détectées dynamiquement; aucune version de NAS n'est codée en dur.
 */

function dmd_nas_qnap_base($item) {
    $base = trim((string)($item['api_url'] ?? $item['admin_url'] ?? ''));
    if ($base === '') {
        $host = trim((string)($item['ip'] ?? $item['hostname'] ?? ''));
        if ($host === '') return '';
        $proto = strtolower((string)($item['protocol'] ?? 'https')) === 'http' ? 'http' : 'https';
        $port = trim((string)($item['admin_port'] ?? ''));
        $base = $proto.'://'.$host.($port !== '' ? ':'.$port : '');
    }
    return rtrim(preg_replace('~/cgi-bin/.*$~i', '', $base), '/');
}

function dmd_nas_qnap_http($url, $params=array(), $method='GET', $headers=array(), $timeout=25, $jsonBody=null, $cookieFile=null) {
    if (!function_exists('curl_init')) return array(false,'','Extension PHP cURL absente.',0);
    $method = strtoupper($method);
    if ($method === 'GET' && $params) $url .= (strpos($url,'?')===false?'?':'&').http_build_query($params,'','&',PHP_QUERY_RFC3986);
    $ch = curl_init($url);
    $h = array_merge(array('Accept: application/json, text/xml, application/xml, */*','User-Agent: DoMyDesk-DMD-NAS/1.2.0'), $headers);
    $opt = array(
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_FOLLOWLOCATION=>true, CURLOPT_MAXREDIRS=>4,
        CURLOPT_CONNECTTIMEOUT=>8, CURLOPT_TIMEOUT=>$timeout,
        CURLOPT_SSL_VERIFYPEER=>false, CURLOPT_SSL_VERIFYHOST=>0,
        CURLOPT_HTTPHEADER=>$h,
    );
    if ($cookieFile) { $opt[CURLOPT_COOKIEJAR]=$cookieFile; $opt[CURLOPT_COOKIEFILE]=$cookieFile; }
    if ($method !== 'GET') {
        $opt[CURLOPT_CUSTOMREQUEST]=$method;
        if ($jsonBody !== null) {
            $opt[CURLOPT_POSTFIELDS]=json_encode($jsonBody, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
            $opt[CURLOPT_HTTPHEADER]=array_merge($h,array('Content-Type: application/json'));
        } elseif ($params) {
            $opt[CURLOPT_POSTFIELDS]=http_build_query($params,'','&',PHP_QUERY_RFC3986);
            $opt[CURLOPT_HTTPHEADER]=array_merge($h,array('Content-Type: application/x-www-form-urlencoded'));
        }
    }
    curl_setopt_array($ch,$opt);
    $raw=curl_exec($ch); $err=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    if ($raw===false) return array(false,'','Connexion QNAP impossible : '.$err,$code);
    if ($code>=400) return array(false,(string)$raw,'HTTP QNAP '.$code.'.',$code);
    return array(true,(string)$raw,'',$code);
}

function dmd_nas_qnap_xml_value($xml,$tag) {
    if (preg_match('~<'.preg_quote($tag,'~').'>\s*(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?\s*</'.preg_quote($tag,'~').'>~si',(string)$xml,$m)) return trim(html_entity_decode(strip_tags($m[1]),ENT_QUOTES|ENT_XML1,'UTF-8'));
    return '';
}
function dmd_nas_qnap_xml_array($xml) {
    if (!function_exists('simplexml_load_string')) return array();
    libxml_use_internal_errors(true); $sx=@simplexml_load_string((string)$xml,'SimpleXMLElement',LIBXML_NOCDATA); libxml_clear_errors();
    if ($sx===false) return array();
    $a=json_decode(json_encode($sx),true); return is_array($a)?$a:array();
}
function dmd_nas_qnap_decode($raw) {
    $j=json_decode(trim((string)$raw),true); return is_array($j)?$j:dmd_nas_qnap_xml_array($raw);
}
function dmd_nas_qnap_is_list($v) {
    if (!is_array($v)) return false; $i=0; foreach($v as $k=>$_){ if($k!==$i++) return false; } return true;
}
function dmd_nas_qnap_listify($v) { if(!is_array($v)) return array(); return dmd_nas_qnap_is_list($v)?$v:array($v); }
function dmd_nas_qnap_find($a,$key) {
    if(!is_array($a)) return null;
    foreach($a as $k=>$v){ if(strcasecmp((string)$k,(string)$key)===0) return $v; if(is_array($v)){ $r=dmd_nas_qnap_find($v,$key); if($r!==null)return $r; }} return null;
}
function dmd_nas_qnap_first($a,$keys,$default='') {
    if(!is_array($a)) return $default;
    foreach($keys as $k) if(array_key_exists($k,$a) && !is_array($a[$k]) && $a[$k]!=='' && $a[$k]!==null) return $a[$k];
    foreach($a as $v) if(is_array($v)){ $r=dmd_nas_qnap_first($v,$keys,null); if($r!==null && $r!=='') return $r; }
    return $default;
}
function dmd_nas_qnap_flat($a,$prefix='',$depth=0,&$out=null) {
    if($out===null)$out=array(); if($depth>8||!is_array($a))return $out;
    foreach($a as $k=>$v){$key=$prefix===''?(string)$k:$prefix.'.'.$k;if(is_array($v))dmd_nas_qnap_flat($v,$key,$depth+1,$out);elseif($v!==''&&count($out)<240)$out[$key]=$v;} return $out;
}
function dmd_nas_qnap_assoc_get($a,$path,$default='') {
    foreach(explode('.',$path) as $p){ if(!is_array($a)||!array_key_exists($p,$a))return $default; $a=$a[$p]; } return $a;
}

function dmd_nas_qnap_login($item) {
    $base=dmd_nas_qnap_base($item); $user=trim((string)($item['api_user']??'')); $pass=dmd_nas_get_api_pass($item);
    if($base===''||$user===''||$pass==='')return array(false,null,null,'API QNAP incomplète : URL, utilisateur ou mot de passe manquant.',array());
    $params=array('user'=>$user,'pwd'=>base64_encode($pass),'remme'=>0,'serviceKey'=>1,'service'=>1);
    list($ok,$raw,$err)=dmd_nas_qnap_http($base.'/cgi-bin/authLogin.cgi',$params,'POST');
    if(!$ok)return array(false,null,null,$err,array());
    $sid=dmd_nas_qnap_xml_value($raw,'authSid'); $passed=dmd_nas_qnap_xml_value($raw,'authPassed');
    if($sid===''||($passed!==''&&$passed!=='1'))return array(false,null,null,'Authentification QNAP refusée.',array('raw'=>substr($raw,0,500)));
    return array(true,$base,$sid,'',dmd_nas_qnap_decode($raw));
}

function dmd_nas_qnap_cgi($base,$path,$params,$sid,$token='access_token') {
    $params[$token]=$sid;
    list($ok,$raw,$err)=dmd_nas_qnap_http($base.$path,$params,'GET');
    if(!$ok)return array(false,array(),$err,$raw);
    $data=dmd_nas_qnap_decode($raw);
    if(!is_array($data)||!count($data))return array(false,array(),'Réponse QNAP vide/illisible pour '.$path.'.',substr($raw,0,700));
    $authPassed=dmd_nas_qnap_first($data,array('authPassed'));
    if($authPassed!=='' && (string)$authPassed==='0') return array(false,$data,'Session QNAP refusée/expirée sur '.$path.'.',$raw);
    return array(true,$data,'',$raw);
}
function dmd_nas_qnap_cgi_fallback($base,$path,$params,$sid,$firstToken='access_token') {
    $tokens=$firstToken==='sid'?array('sid','access_token'):array('access_token','sid'); $last=array(false,array(),'','');
    foreach($tokens as $t){$last=dmd_nas_qnap_cgi($base,$path,$params,$sid,$t); if($last[0])return $last;} return $last;
}

function dmd_nas_qnap_system($base,$sid) {
    list($ok,$data,$err,$raw)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/management/manaRequest.cgi',array('subfunc'=>'sysinfo','hd'=>'no','multicpu'=>1),$sid,'sid');
    if(!$ok)return array(array(),$err,array('raw'=>substr((string)$raw,0,700)));
    $model=dmd_nas_qnap_find($data,'model'); $firm=dmd_nas_qnap_find($data,'firmware');
    $func=dmd_nas_qnap_find($data,'func'); $own=is_array($func)?dmd_nas_qnap_find($func,'ownContent'):null; $root=is_array($own)?dmd_nas_qnap_find($own,'root'):null;
    if(!is_array($model))$model=array(); if(!is_array($firm))$firm=array(); if(!is_array($root))$root=array();
    $uptimeParts=array_filter(array(
        dmd_nas_qnap_first($root,array('uptime_day'))!==''?dmd_nas_qnap_first($root,array('uptime_day')).' j':'',
        dmd_nas_qnap_first($root,array('uptime_hour'))!==''?dmd_nas_qnap_first($root,array('uptime_hour')).' h':'',
        dmd_nas_qnap_first($root,array('uptime_min'))!==''?dmd_nas_qnap_first($root,array('uptime_min')).' min':'',
    ));
    $sys=array(
        'hostname'=>dmd_nas_qnap_first($root,array('server_name','serverName','hostname','servername')),
        'model'=>dmd_nas_qnap_first($model,array('displayModelName','customModelName','modelName','internalModelName')),
        'internal_model'=>dmd_nas_qnap_first($model,array('internalModelName','modelName')),
        'platform'=>dmd_nas_qnap_first($model,array('platform_ex','platform')),
        'is_zfs'=>dmd_nas_qnap_first($model,array('is_zfs')),
        'serial'=>dmd_nas_qnap_first($root,array('serial_number','serialNumber','serial')),
        'firmware_version'=>dmd_nas_qnap_first($firm,array('version')),
        'firmware_build'=>dmd_nas_qnap_first($firm,array('build')),
        'firmware_number'=>dmd_nas_qnap_first($firm,array('number')),
        'firmware_patch'=>dmd_nas_qnap_first($firm,array('patch')),
        'firmware_build_time'=>dmd_nas_qnap_first($firm,array('buildTime')),
        'cpu_model'=>dmd_nas_qnap_first($root,array('cpu_model','cpuModel','cpu_name','cpuName')),
        'cpu_usage'=>dmd_nas_qnap_first($root,array('cpu_usage','cpuUsage','cpu_percent','cpuUse')),
        'cpu_temp'=>dmd_nas_qnap_first($root,array('cpu_tempc','cpu_temp','cpuTemperature','cpu_temperature')),
        'memory_total'=>dmd_nas_qnap_first($root,array('total_memory','memory_total','mem_total','memory_size','totalMem')),
        'memory_free'=>dmd_nas_qnap_first($root,array('free_memory','memory_free','mem_free','freeMem')),
        'system_temp'=>dmd_nas_qnap_first($root,array('sys_tempc','system_temp','sys_temp','systemTemperature','temperature')),
        'timezone'=>dmd_nas_qnap_first($root,array('timezone')),
        'uptime'=>implode(' ', $uptimeParts),
        'nic_count'=>dmd_nas_qnap_first($root,array('nic_cnt','nic_count')),
    );
    foreach($sys as $k=>$v)if($v===''||is_array($v))unset($sys[$k]);
    return array($sys,'',array('endpoint'=>'management/manaRequest.cgi?subfunc=sysinfo&hd=no&multicpu=1'));
}

function dmd_nas_qnap_disks($base,$sid) {
    list($ok,$data,$err,$raw)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/disk/qsmart.cgi',array('func'=>'all_hd_data'),$sid,'access_token');
    if(!$ok)return array(array(),$err,array('raw'=>substr((string)$raw,0,700)));
    $node=dmd_nas_qnap_find($data,'Disk_Info'); $entries=is_array($node)?dmd_nas_qnap_find($node,'entry'):null; $rows=dmd_nas_qnap_listify($entries);
    $out=array();
    foreach($rows as $r){ if(!is_array($r))continue; $temp=dmd_nas_qnap_find($r,'Temperature'); if(!is_array($temp))$temp=array();
        $out[]=array(
            'type'=>'disk','name'=>dmd_nas_qnap_first($r,array('Disk_Alias','HDNo'))?:'Disque',
            'slot'=>dmd_nas_qnap_first($r,array('HDNo')),'model'=>dmd_nas_qnap_first($r,array('Model')),
            'vendor'=>dmd_nas_qnap_first($r,array('Vendor')),'serial'=>dmd_nas_qnap_first($r,array('Serial')),
            'firmware'=>dmd_nas_qnap_first($r,array('FirmVersion')),'capacity'=>dmd_nas_qnap_first($r,array('Capacity')),
            'health'=>dmd_nas_qnap_first($r,array('Health')),'status'=>dmd_nas_qnap_first($r,array('Disk_Status')),
            'temperature'=>dmd_nas_qnap_first($temp,array('oC')),'ssd'=>dmd_nas_qnap_first($r,array('hd_is_ssd')),
            'smart_supported'=>dmd_nas_qnap_first($r,array('Support_SMART')),'selftest_supported'=>dmd_nas_qnap_first($r,array('Support_SelfTest')),
            'last_test_status'=>dmd_nas_qnap_first($r,array('LastTestSts')),'last_test_type'=>dmd_nas_qnap_first($r,array('LastTestType')),'last_test_time'=>dmd_nas_qnap_first($r,array('LastTestTime')),
        );
    }
    return array($out,'',array('endpoint'=>'disk/qsmart.cgi?func=all_hd_data','count'=>count($out)));
}

function dmd_nas_qnap_volumes($base,$sid) {
    list($ok,$data,$err,$raw)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/management/chartReq.cgi',array('chart_func'=>'disk_usage','disk_select'=>'all','include'=>'all'),$sid,'sid');
    if(!$ok)return array(array(),$err,array('raw'=>substr((string)$raw,0,700)));
    $volList=dmd_nas_qnap_find($data,'volumeList'); $useList=dmd_nas_qnap_find($data,'volumeUseList');
    $volRows=is_array($volList)?dmd_nas_qnap_listify(dmd_nas_qnap_find($volList,'volume')):array();
    $useRows=is_array($useList)?dmd_nas_qnap_listify(dmd_nas_qnap_find($useList,'volumeUse')):array();
    $byId=array();
    foreach($volRows as $v){
        if(!is_array($v))continue; $id=(string)dmd_nas_qnap_first($v,array('volumeValue','id','volume_id')); if($id==='')continue;
        $byId[$id]=array('type'=>'volume','volume_id'=>$id,'volume_name'=>dmd_nas_qnap_first($v,array('volumeLabel','label','name'))?:('Volume '.$id));
    }
    foreach($useRows as $u){
        if(!is_array($u))continue; $id=(string)dmd_nas_qnap_first($u,array('volumeValue','id','volume_id')); if($id==='')continue;
        if(!isset($byId[$id]))$byId[$id]=array('type'=>'volume','volume_id'=>$id,'volume_name'=>'Volume '.$id);
        $byId[$id]['free_size']=dmd_nas_qnap_first($u,array('free_size','free','available'));
        $byId[$id]['capacity']=dmd_nas_qnap_first($u,array('total_size','capacity','size'));
        $total=(float)($byId[$id]['capacity']?:0); $free=(float)($byId[$id]['free_size']?:0);
        if($total>0)$byId[$id]['used_size']=(string)max(0,$total-$free);
        $folders=dmd_nas_qnap_find($u,'folder_element'); if(is_array($folders))$byId[$id]['folders']=dmd_nas_qnap_listify($folders);
    }
    if(!$byId){
        list($ok2,$data2,$err2,$raw2)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/filemanager/utilRequest.cgi',array('func'=>'get_tree','hidden_file'=>1,'is_iso'=>0,'node'=>'vol_root'),$sid,'sid');
        if($ok2){
            $rows=dmd_nas_qnap_is_list($data2)?$data2:array(); if(!$rows){$n=dmd_nas_qnap_find($data2,'data');if(is_array($n))$rows=dmd_nas_qnap_listify($n);}
            foreach($rows as $r){if(!is_array($r))continue;$name=dmd_nas_qnap_first($r,array('volume_name','name','text','volume_id'));if($name==='')continue;$byId[] = array('type'=>'volume','volume_name'=>$name,'volume_id'=>dmd_nas_qnap_first($r,array('volume_id','id')),'capacity'=>dmd_nas_qnap_first($r,array('capacity','total_size','size')),'free_size'=>dmd_nas_qnap_first($r,array('free_size','free','available')),'status'=>dmd_nas_qnap_first($r,array('volume_status','status','state')));}
        }
    }
    return array(array_values($byId),'',array('endpoint'=>'management/chartReq.cgi?chart_func=disk_usage&disk_select=all&include=all','count'=>count($byId)));
}

function dmd_nas_qnap_storage($base,$sid) {
    list($vol,$ve,$vg)=dmd_nas_qnap_volumes($base,$sid); list($disks,$de,$dg)=dmd_nas_qnap_disks($base,$sid);
    return array(array_values(array_merge($vol,$disks)),trim($ve.' '.$de),array('volumes'=>$vg,'disks'=>$dg));
}

function dmd_nas_qnap_network($base,$sid) {
    $out=array('interfaces'=>array(),'dns'=>array(),'default_gateway'=>'','local_ip'=>'','external_ip'=>'');
    $errors=array(); $diag=array();

    /* QTS 4/5: les infos réseau fiables sont déjà dans sysinfo. */
    list($ok,$data,$err,$raw)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/management/manaRequest.cgi',array('subfunc'=>'sysinfo','hd'=>'no','multicpu'=>1),$sid,'sid');
    if($ok){
        $func=dmd_nas_qnap_find($data,'func'); $own=is_array($func)?dmd_nas_qnap_find($func,'ownContent'):null; $root=is_array($own)?dmd_nas_qnap_find($own,'root'):null;
        if(!is_array($root))$root=dmd_nas_qnap_find($data,'root'); if(!is_array($root))$root=array();
        $cnt=(int)dmd_nas_qnap_first($root,array('nic_cnt','nic_count'),0);
        if($cnt<=0){
            /* Certains modèles ne remplissent pas nic_cnt mais fournissent eth_ipN. */
            for($n=1;$n<=16;$n++){ if(dmd_nas_qnap_first($root,array('eth_ip'.$n,'eth_mac'.$n,'eth_status'.$n))!=='')$cnt=$n; }
        }
        for($n=1;$n<=$cnt;$n++){
            $ip=dmd_nas_qnap_first($root,array('eth_ip'.$n)); $mac=dmd_nas_qnap_first($root,array('eth_mac'.$n)); $status=dmd_nas_qnap_first($root,array('eth_status'.$n));
            $mask=dmd_nas_qnap_first($root,array('eth_mask'.$n)); $speed=dmd_nas_qnap_first($root,array('eth_max_speed'.$n)); $usage=dmd_nas_qnap_first($root,array('eth_usage'.$n));
            if($ip===''&&$mac===''&&$status==='')continue;
            $out['interfaces'][]=array(
                'id'=>'eth'.($n-1),'name'=>'Ethernet '.$n,
                'status'=>(string)$status==='1'?'up':((string)$status==='0'?'down':(string)$status),
                'ip'=>$ip,'mask'=>$mask,'mac'=>$mac,'max_speed'=>$speed,'usage'=>$usage,
                'rx_packets'=>dmd_nas_qnap_first($root,array('rx_packet'.$n)),
                'tx_packets'=>dmd_nas_qnap_first($root,array('tx_packet'.$n)),
                'err_packets'=>dmd_nas_qnap_first($root,array('err_packet'.$n)),
            );
        }
        $dnsInfo=dmd_nas_qnap_find($root,'dnsInfo');
        if(is_array($dnsInfo)){
            $dnsList=dmd_nas_qnap_find($dnsInfo,'DNS_LIST');
            foreach(dmd_nas_qnap_listify($dnsList) as $d){
                $v=is_array($d)?dmd_nas_qnap_first($d,array('value','dns','ip','name')):(string)$d;
                if($v!==''&&!in_array($v,$out['dns'],true))$out['dns'][]=$v;
            }
        }
        foreach(array('dns1','dns2','primary_dns','secondary_dns') as $k){$v=dmd_nas_qnap_first($root,array($k));if($v!==''&&!in_array($v,$out['dns'],true))$out['dns'][]=$v;}
        $out['default_gateway']=dmd_nas_qnap_first($root,array('default_gateway','gateway','df_gateway'));
        $diag['sysinfo']='ok';
    } else { $errors[]=$err; $diag['sysinfo']=substr((string)$raw,0,400); }

    /* Débit + passerelle par interface. */
    $bwData=null;
    foreach(array('QSM40bandwidth','bandwidth') as $chart){
        list($bok,$bd,$be,$br)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/management/chartReq.cgi',array('chart_func'=>$chart),$sid,'sid');
        if($bok && is_array($bd) && dmd_nas_qnap_find($bd,'bandwidth_info')!==null){$bwData=$bd;$diag['bandwidth']=$chart;break;}
    }
    if(is_array($bwData)){
        $bi=dmd_nas_qnap_find($bwData,'bandwidth_info'); $gw=dmd_nas_qnap_first($bwData,array('df_gateway'));
        if($gw==='')$gw=dmd_nas_qnap_first($bi,array('df_gateway')); if($gw!==''&&$out['default_gateway']==='')$out['default_gateway']=$gw;
        $items=dmd_nas_qnap_find($bi,'item');
        foreach(dmd_nas_qnap_listify($items) as $it){
            if(!is_array($it))continue; $id=(string)dmd_nas_qnap_first($it,array('id','name')); if($id==='')continue;
            foreach($out['interfaces'] as &$iface){ if($iface['id']===$id){$iface['display_name']=dmd_nas_qnap_first($it,array('dname','name'));$iface['rx']=dmd_nas_qnap_first($it,array('rx'));$iface['tx']=dmd_nas_qnap_first($it,array('tx'));$iface['is_default']=($id===$gw);break;} } unset($iface);
        }
    }

    /* File Station expose au minimum IP LAN/externe, utile en dernier recours. */
    list($fok,$fd,$fe,$fr)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/filemanager/utilRequest.cgi',array('func'=>'get_domain_ip_list'),$sid,'sid');
    if($fok){
        $out['local_ip']=dmd_nas_qnap_first($fd,array('local_ip','host_ip'));
        $out['external_ip']=dmd_nas_qnap_first($fd,array('external_ip'));
        $diag['domain_ip']='ok';
    }

    if(!$out['interfaces'] && $out['local_ip']!=='')$out['interfaces'][]=array('id'=>'lan','name'=>'LAN','status'=>'up','ip'=>$out['local_ip']);
    if(!$out['interfaces'] && $out['local_ip']==='' && $out['external_ip']===''){
        return array(array(),trim(implode(' ',array_filter($errors)))?:'QNAP ne renvoie aucune information réseau exploitable avec ce compte.',array('diagnostic'=>$diag));
    }
    return array($out,'',array('endpoint'=>'management/manaRequest.cgi sysinfo + chartReq bandwidth','diagnostic'=>$diag,'interfaces'=>count($out['interfaces'])));
}

function dmd_nas_qnap_named_list($base,$sid,$type) {
    list($ok,$data,$err,$raw)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/filemanager/utilRequest.cgi',array('func'=>'get_all_list_out','type'=>$type,'filter'=>''),$sid,'sid');
    if(!$ok)return array(array(),$err,array('raw'=>substr((string)$raw,0,700)));
    $list=dmd_nas_qnap_find($data,'list'); $rows=dmd_nas_qnap_listify($list); $out=array();
    foreach($rows as $r){if(is_string($r))$n=$r;else $n=dmd_nas_qnap_first($r,array('name','username','groupname'));if($n!=='')$out[]=array('name'=>$n);}
    return array($out,'',array('endpoint'=>'File Station get_all_list_out','type'=>$type,'count'=>count($out)));
}
function dmd_nas_qnap_users($base,$sid){return dmd_nas_qnap_named_list($base,$sid,1);} function dmd_nas_qnap_groups($base,$sid){return dmd_nas_qnap_named_list($base,$sid,2);}

function dmd_nas_qnap_shares($base,$sid) {
    list($ok,$data,$err,$raw)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/filemanager/utilRequest.cgi',array('func'=>'get_tree','hidden_file'=>1,'is_iso'=>0,'node'=>'share_root'),$sid,'sid');
    if(!$ok)return array(array(),$err,array('raw'=>substr((string)$raw,0,700)));
    $rows=dmd_nas_qnap_is_list($data)?$data:array(); if(!$rows){$n=dmd_nas_qnap_find($data,'datas');if(is_array($n))$rows=dmd_nas_qnap_listify($n);}
    $out=array(); foreach($rows as $r){if(!is_array($r))continue;$name=dmd_nas_qnap_first($r,array('text','filename','name','share_name','id'));if($name==='')continue;$out[]=array('name'=>$name,'text'=>$name,'path'=>dmd_nas_qnap_first($r,array('path','id','filename')),'privilege'=>dmd_nas_qnap_first($r,array('privilege','acl','cls')),'owner'=>dmd_nas_qnap_first($r,array('owner')),'group'=>dmd_nas_qnap_first($r,array('group')),'acl_enabled'=>dmd_nas_qnap_first($r,array('is_acl_enable','noSupportACL')));}
    return array($out,'',array('endpoint'=>'File Station share_root','count'=>count($out)));
}

function dmd_nas_qnap_packages_raw($base,$sid) {
    $tries=array(array('action'=>'reload','subfunc'=>'qpkg'),array('subfunc'=>'qpkg','action'=>'get'),array('subfunc'=>'qpkg'));
    $last='';$lastRaw='';
    foreach($tries as $params){list($ok,$data,$err,$raw)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/application/appRequest.cgi',$params,$sid,'sid');$last=$err;$lastRaw=$raw;if(!$ok)continue;
        $node=dmd_nas_qnap_find($data,'qItem');if(!is_array($node))$node=dmd_nas_qnap_find($data,'item');if(!is_array($node))continue;$rows=dmd_nas_qnap_listify($node);$out=array();
        foreach($rows as $r){if(!is_array($r))continue;$name=dmd_nas_qnap_first($r,array('display_name','Display_Name','name','Name','QPKG_NAME'));if($name==='')continue;$out[]=array('display_name'=>$name,'name'=>dmd_nas_qnap_first($r,array('name','Name','QPKG_NAME'))?:$name,'version'=>dmd_nas_qnap_first($r,array('version','Version')),'status'=>dmd_nas_qnap_first($r,array('enable','enabled','status','Enable')),'install_path'=>dmd_nas_qnap_first($r,array('installPath','install_path')));}
        return array($out,'',array('endpoint'=>'application/appRequest.cgi?subfunc=qpkg','count'=>count($out)));
    }
    return array(array(),$last?:'App Center QNAP n’a renvoyé aucune donnée.',array('raw'=>substr((string)$lastRaw,0,700)));
}

function dmd_nas_qnap_container_session($item) {
    $base=dmd_nas_qnap_base($item);$user=trim((string)($item['api_user']??''));$pass=dmd_nas_get_api_pass($item);if($base===''||$user===''||$pass==='')return array(false,null,null,'API QNAP incomplète.');
    $cookie=tempnam(sys_get_temp_dir(),'dmdnas_qnap_cs_');
    foreach(array('/container-station/api/v1','/api/v1') as $prefix){
        list($ok,$raw,$err)=dmd_nas_qnap_http($base.$prefix.'/login',array('username'=>$user,'password'=>$pass),'POST',array(),20,null,$cookie);
        if(!$ok)continue; $j=json_decode($raw,true); if(is_array($j) || trim($raw)==='' || stripos($raw,'success')!==false)return array(true,$base.$prefix,$cookie,'');
    }
    @unlink($cookie);return array(false,null,null,'Container Station installé mais authentification API impossible.');
}
function dmd_nas_qnap_cs_call($prefix,$cookie,$path,$method='GET',$body=null) {
    list($ok,$raw,$err)=dmd_nas_qnap_http($prefix.$path,array(),$method,array(),25,$body,$cookie); if(!$ok)return array(false,null,$err);
    $j=json_decode($raw,true); if($j===null && trim($raw)!=='')return array(false,null,'Réponse Container Station non JSON.'); return array(true,$j===null?array():$j,'');
}
function dmd_nas_qnap_docker($item,$query='') {
    list($ok,$prefix,$cookie,$err)=dmd_nas_qnap_container_session($item);if(!$ok)return array(false,null,$err);
    $containers=array();$images=array();$errors=array();
    foreach(array('/container','/containers') as $p){list($x,$j,$e)=dmd_nas_qnap_cs_call($prefix,$cookie,$p);if($x&&is_array($j)){$containers=dmd_nas_qnap_is_list($j)?$j:(isset($j['containers'])&&is_array($j['containers'])?$j['containers']:array());if($containers)break;}if($e)$errors[]=$e;}
    foreach(array('/image','/images') as $p){list($x,$j,$e)=dmd_nas_qnap_cs_call($prefix,$cookie,$p);if($x&&is_array($j)){$images=dmd_nas_qnap_is_list($j)?$j:(isset($j['images'])&&is_array($j['images'])?$j['images']:array());if($images)break;}if($e)$errors[]=$e;}
    @unlink($cookie);
    if($query!==''){$q=strtolower($query);$containers=array_values(array_filter($containers,function($x)use($q){return strpos(strtolower(json_encode($x)),$q)!==false;}));}
    return array(true,array('containers'=>$containers,'images'=>$images,'registry'=>array(),'errors'=>$errors),'Container Station : '.count($containers).' conteneur(s), '.count($images).' image(s).');
}
function dmd_nas_qnap_container_action($item,$container,$op){
    list($ok,$prefix,$cookie,$err)=dmd_nas_qnap_container_session($item);if(!$ok)return array(false,null,$err);
    $type='docker';$id=$container;if(strpos($container,':')!==false){list($type,$id)=explode(':',$container,2);} $type=preg_replace('/[^a-z0-9_-]/i','',$type);$id=rawurlencode($id);
    $map=array('start'=>array('POST','/container/'.$type.'/'.$id.'/start'),'stop'=>array('POST','/container/'.$type.'/'.$id.'/stop'),'restart'=>array('POST','/container/'.$type.'/'.$id.'/restart'),'delete'=>array('DELETE','/container/'.$type.'/'.$id));
    if(!isset($map[$op])){@unlink($cookie);return array(false,null,'Action Container Station inconnue.');}
    list($x,$j,$e)=dmd_nas_qnap_cs_call($prefix,$cookie,$map[$op][1],$map[$op][0],array());@unlink($cookie);
    return $x?array(true,$j,'Container '.$op.' envoyé à QNAP.'):array(false,null,$e);
}
function dmd_nas_qnap_package_action($item,$package,$op){
    list($ok,$base,$sid,$err)=dmd_nas_qnap_login($item);if(!$ok)return array(false,null,$err);
    $applyMap=array('enable'=>3,'start'=>3); if(!isset($applyMap[$op]))return array(false,null,'Cette action QPKG n’est pas exposée de façon suffisamment stable par les API QNAP détectées.');
    list($x,$data,$e)=dmd_nas_qnap_cgi_fallback($base,'/cgi-bin/application/appRequest.cgi',array('subfunc'=>'qpkg','apply'=>$applyMap[$op],'qname'=>$package),$sid,'sid');
    return $x?array(true,$data,'Application QNAP activée.'):array(false,null,$e);
}

function dmd_nas_qnap_refresh($item) {
    list($ok,$base,$sid,$err,$auth)=dmd_nas_qnap_login($item);if(!$ok)return array(false,null,$err);
    $out=array('refreshed_at'=>date('Y-m-d H:i:s'),'summary'=>array(),'system'=>array(),'storage'=>array(),'network'=>array(),'users'=>array(),'groups'=>array(),'shares'=>array(),'packages'=>array(),'containers'=>array(),'images'=>array(),'errors'=>array(),'capabilities'=>array(),'diagnostic'=>array());
    $calls=array(
        'system'=>function()use($base,$sid){return dmd_nas_qnap_system($base,$sid);},
        'storage'=>function()use($base,$sid){return dmd_nas_qnap_storage($base,$sid);},
        'network'=>function()use($base,$sid){return dmd_nas_qnap_network($base,$sid);},
        'users'=>function()use($base,$sid){return dmd_nas_qnap_users($base,$sid);},
        'groups'=>function()use($base,$sid){return dmd_nas_qnap_groups($base,$sid);},
        'shares'=>function()use($base,$sid){return dmd_nas_qnap_shares($base,$sid);},
        'packages'=>function()use($base,$sid){return dmd_nas_qnap_packages_raw($base,$sid);},
    );
    foreach($calls as $k=>$fn){list($v,$e,$g)=$fn();$out[$k]=$v;$out['capabilities'][$k]=empty($e);if($e)$out['errors'][]=$k.': '.$e;$out['diagnostic'][$k]=$g;}
    list($dok,$docker,$dmsg)=dmd_nas_qnap_docker($item); if($dok&&is_array($docker)){$out['containers']=$docker['containers']??array();$out['images']=$docker['images']??array();$out['capabilities']['container_station']=true;}else{$out['capabilities']['container_station']=false;if($dmsg)$out['errors'][]='container_station: '.$dmsg;}
    $disks=array_values(array_filter($out['storage'],function($x){return is_array($x)&&(($x['type']??'')==='disk');}));$vols=array_values(array_filter($out['storage'],function($x){return is_array($x)&&(($x['type']??'')==='volume');}));
    $out['summary']=array('hostname'=>$out['system']['hostname']??($item['hostname']??''),'model'=>$out['system']['model']??($item['model']??''),'firmware'=>$out['system']['firmware_version']??'','qts_family'=>(string)($out['system']['is_zfs']??'')==='1'?'QuTS hero':'QTS','disks'=>count($disks),'volumes'=>count($vols),'shares'=>count($out['shares']),'users'=>count($out['users']),'groups'=>count($out['groups']),'packages'=>count($out['packages']),'containers'=>count($out['containers']));
    return array(true,$out,'QNAP actualisé : '.count($disks).' disque(s), '.count($vols).' volume(s), '.count($out['shares']).' partage(s), '.count($out['users']).' utilisateur(s), '.count($out['groups']).' groupe(s).');
}
function dmd_nas_qnap_packages($item){list($ok,$base,$sid,$err)=dmd_nas_qnap_login($item);if(!$ok)return array(false,null,$err);list($rows,$e)=dmd_nas_qnap_packages_raw($base,$sid);return $e&&!$rows?array(false,null,$e):array(true,array('installed'=>$rows,'available'=>array()),count($rows).' application(s) QNAP détectée(s).');}
