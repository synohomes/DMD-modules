<?php
/**
 * DoMyDesk - Connecteur Synology DSM
 * Ne contient que la logique constructeur Synology.
 * Chargé par dmd_nas_api.php si le fichier existe.
 */

function dmd_nas_dsm_has_explicit_port($url) {
    $p = @parse_url((string)$url);
    return is_array($p) && array_key_exists('port', $p) && (int)$p['port'] > 0;
}
function dmd_nas_dsm_normalize_base_url($base, $port = '', $protocol = 'http') {
    $base = trim((string)$base);
    $port = trim((string)$port);
    $protocol = strtolower((string)$protocol) === 'https' ? 'https' : 'http';
    if ($base === '') return '';
    if (!preg_match('#^https?://#i', $base)) $base = $protocol . '://' . $base;
    $base = preg_replace('#/webapi/.*$#i', '', $base);
    $base = rtrim($base, '/');
    if ($port !== '' && preg_match('/^\d+$/', $port) && !dmd_nas_dsm_has_explicit_port($base)) {
        $p = @parse_url($base);
        if (is_array($p) && !empty($p['host'])) {
            $scheme = $p['scheme'] ?? $protocol;
            $user = isset($p['user']) ? $p['user'] . (isset($p['pass']) ? ':' . $p['pass'] : '') . '@' : '';
            $path = $p['path'] ?? '';
            $base = $scheme . '://' . $user . $p['host'] . ':' . $port . $path;
        }
    }
    return rtrim($base, '/');
}
function dmd_nas_dsm_base_from_item($item) {
    $base = trim((string)($item['api_url'] ?? ''));
    if ($base === '') $base = trim((string)($item['admin_url'] ?? ''));
    return dmd_nas_dsm_normalize_base_url($base, (string)($item['admin_port'] ?? ''), (string)($item['protocol'] ?? 'http'));
}

function dmd_nas_dsm_http_json($url, $params = [], $method = 'GET', $timeout = 12, $synoToken = '', $sid = '') {
    $method = strtoupper((string)$method) === 'POST' ? 'POST' : 'GET';
    $query = http_build_query($params);
    $headers = "Accept: application/json\r\n";
    $headers .= "X-Requested-With: XMLHttpRequest\r\n";
    $headers .= "Content-Type: application/x-www-form-urlencoded\r\n";
    if ($synoToken !== '') $headers .= "X-SYNO-TOKEN: " . $synoToken . "\r\n";
    if ($sid !== '') {
        /* Plusieurs actions DSM (Package Center / User / Share) acceptent _sid en paramètre
           pour la lecture, mais réclament aussi le cookie de session pour les écritures. */
        $headers .= "Cookie: id=" . rawurlencode($sid) . ";\r\n";
    }
    $opts = [
        'http' => ['timeout' => $timeout, 'ignore_errors' => true, 'method' => $method, 'header' => $headers],
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
    ];
    if ($method === 'POST') {
        $opts['http']['content'] = $query;
    } else {
        $url .= (strpos($url, '?') === false ? '?' : '&') . $query;
    }
    $ctx = stream_context_create($opts);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) return [false, null, 'HTTP impossible : ' . $url];
    $j = json_decode($raw, true);
    if (!is_array($j)) return [false, null, 'Réponse DSM non JSON : ' . substr($raw, 0, 220)];
    return [true, $j, ''];
}
function dmd_nas_dsm_call($base, $path, $params, $sid = null, $method = 'GET', $synoToken = '') {
    $base = dmd_nas_dsm_normalize_base_url($base);
    if ($base === '') return [false, null, 'URL API vide'];
    if ($sid) $params['_sid'] = $sid;
    return dmd_nas_dsm_http_json($base . '/webapi/' . ltrim($path, '/'), $params, $method, 12, $synoToken, (string)($sid ?? ''));
}
function dmd_nas_array_is_list_compat($arr) {
    if (!is_array($arr)) return false;
    $i = 0;
    foreach ($arr as $k => $_) { if ($k !== $i++) return false; }
    return true;
}
function dmd_nas_dsm_pick_api($apiInfo, $apiName) {
    if (!is_array($apiInfo)) return null;
    $data = $apiInfo['data'] ?? $apiInfo;
    if (!is_array($data) || empty($data[$apiName]) || !is_array($data[$apiName])) return null;
    return $data[$apiName];
}
function dmd_nas_dsm_call_api($base, $apiInfo, $apiName, $method, $params, $sid) {
    $meta = dmd_nas_dsm_pick_api($apiInfo, $apiName);
    if (!$meta) return [false, null, 'API absente : ' . $apiName];
    $path = (string)($meta['path'] ?? 'entry.cgi');
    $maxVersion = (int)($meta['maxVersion'] ?? $meta['max_version'] ?? $meta['version'] ?? 1);
    if ($maxVersion < 1) $maxVersion = 1;
    $token = is_array($apiInfo) ? (string)($apiInfo['__synotoken'] ?? '') : '';
    $writeMethods = ['create','add','delete','remove','set','start','stop','restart','install','install_package','easy_install','install_from_server','uninstall','download','pull','check','check_installation'];
    $httpMethod = in_array(strtolower((string)$method), $writeMethods, true) ? 'POST' : 'GET';

    /* DSM annonce parfois une maxVersion, mais certaines méthodes Package/User
       retournent 103 à cette version et fonctionnent en version 1. On essaye
       toutes les versions avant de conclure que DSM refuse vraiment. */
    $last = [false, null, ''];
    for ($version = $maxVersion; $version >= 1; $version--) {
        $callParams = array_merge(['api'=>$apiName, 'version'=>$version, 'method'=>$method], $params);
        if ($token !== '') $callParams['SynoToken'] = $token;
        [$ok, $data, $err] = dmd_nas_dsm_call($base, $path, $callParams, $sid, $httpMethod, $token);
        if (!$ok) {
            $last = [$ok, $data, $err];
            continue;
        }
        if (!empty($data['success'])) return [$ok, $data, ''];
        $code = $data['error']['code'] ?? null;
        $last = [$ok, $data, $apiName . '.' . $method . ' v' . $version . ' => ' . json_encode($data['error'] ?? $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)];
        if (!in_array((int)$code, [102,103,104,105], true)) break;
    }
    return $last;
}

function dmd_nas_dsm_batch_request($base, $apiInfo, $sid, $compound, $mode = 'sequential') {
    $meta = dmd_nas_dsm_pick_api($apiInfo, 'SYNO.Entry.Request');
    if (!$meta) return [false, null, 'API absente : SYNO.Entry.Request'];
    $path = (string)($meta['path'] ?? 'entry.cgi');
    $version = (int)($meta['maxVersion'] ?? $meta['max_version'] ?? 1);
    if ($version < 1) $version = 1;
    $token = is_array($apiInfo) ? (string)($apiInfo['__synotoken'] ?? '') : '';
    $params = [
        'api' => 'SYNO.Entry.Request',
        'method' => 'request',
        'version' => $version,
        'mode' => $mode,
        'stop_when_error' => 'true',
        'compound' => json_encode(array_values($compound), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
    ];
    if ($token !== '') $params['SynoToken'] = $token;
    [$ok, $data, $err] = dmd_nas_dsm_call($base, $path, $params, $sid, 'POST', $token);
    if (!$ok) return [false, $data, $err];
    if (!is_array($data)) return [false, $data, 'Réponse DSM batch invalide.'];
    if (empty($data['success'])) {
        return [false, $data, 'SYNO.Entry.Request.request => ' . json_encode($data['error'] ?? $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)];
    }
    return [true, $data, ''];
}

function dmd_nas_dsm_refresh($item) {
    $base = dmd_nas_dsm_base_from_item($item);
    $user = trim((string)($item['api_user'] ?? ''));
    $pass = dmd_nas_get_api_pass($item);
    if ($base === '' || $user === '' || $pass === '') return [false, null, 'API Synology incomplète : URL, utilisateur ou mot de passe manquant.'];

    [$ok, $auth, $err] = dmd_nas_dsm_call($base, 'auth.cgi', [
        'api' => 'SYNO.API.Auth', 'version' => 6, 'method' => 'login',
        'account' => $user, 'passwd' => $pass, 'session' => 'DSM', 'format' => 'sid'
    ]);
    if (!$ok) return [false, null, $err];
    if (empty($auth['success']) || empty($auth['data']['sid'])) return [false, null, 'Login DSM refusé : ' . json_encode($auth, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)];
    $sid = $auth['data']['sid'];

    $result = [
        'refreshed_at' => date('Y-m-d H:i:s'),
        'summary' => [],
        'system' => null,
        'utilization' => null,
        'storage' => null,
        'packages' => [],
        'users' => [],
        'groups' => [],
        'shares' => [],
        'services' => [],
        'network' => null,
        'errors' => [],
        'raw' => []
    ];

    [$iok, $apiInfo, $ierr] = dmd_nas_dsm_call($base, 'query.cgi', ['api'=>'SYNO.API.Info','version'=>1,'method'=>'query','query'=>'all'], $sid);
    if (!$iok || empty($apiInfo['success'])) {
        dmd_nas_dsm_call($base, 'auth.cgi', ['api'=>'SYNO.API.Auth','version'=>6,'method'=>'logout','session'=>'DSM'], $sid);
        return [false, null, 'Découverte API DSM impossible : ' . ($ierr ?: json_encode($apiInfo, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))];
    }
    $result['raw']['api_info'] = $apiInfo;
    $result['available_count'] = is_array($apiInfo['data'] ?? null) ? count($apiInfo['data']) : 0;

    $calls = [
        'system'      => ['SYNO.Core.System', 'info', []],
        'utilization' => ['SYNO.Core.System.Utilization', 'get', []],
        'storage'     => ['SYNO.Storage.CGI.Storage', 'load_info', []],
        'packages'    => ['SYNO.Core.Package', 'list', []],
        'users'       => ['SYNO.Core.User', 'list', []],
        'groups'      => ['SYNO.Core.Group', 'list', []],
        'shares'      => ['SYNO.Core.Share', 'list', []],
        'services'    => ['SYNO.Core.Service', 'list', []],
        'network'     => ['SYNO.Core.Network', 'get', []],
    ];

    foreach ($calls as $key => $spec) {
        [$apiName, $method, $params] = $spec;
        [$cok, $data, $cerr] = dmd_nas_dsm_call_api($base, $apiInfo, $apiName, $method, $params, $sid);
        $result['raw'][$key] = $cok ? $data : ['success'=>false, 'error'=>$cerr];
        if (!$cok || empty($data['success'])) {
            $result['errors'][$key] = $cerr ?: ($data['error']['code'] ?? 'Réponse refusée');
            continue;
        }
        $payload = $data['data'] ?? $data;
        if (in_array($key, ['packages','users','groups','shares','services'], true)) {
            if (isset($payload['packages']) && is_array($payload['packages'])) $payload = $payload['packages'];
            elseif (isset($payload['users']) && is_array($payload['users'])) $payload = $payload['users'];
            elseif (isset($payload['groups']) && is_array($payload['groups'])) $payload = $payload['groups'];
            elseif (isset($payload['shares']) && is_array($payload['shares'])) $payload = $payload['shares'];
            elseif (isset($payload['services']) && is_array($payload['services'])) $payload = $payload['services'];
            elseif (isset($payload['items']) && is_array($payload['items'])) $payload = $payload['items'];
            elseif (isset($payload['list']) && is_array($payload['list'])) $payload = $payload['list'];
            elseif (!dmd_nas_array_is_list_compat($payload)) $payload = [];
        }
        $result[$key] = $payload;
    }

    if (is_array($result['system'])) {
        $result['summary']['model'] = $result['system']['model'] ?? $result['system']['support_model'] ?? '';
        $result['summary']['firmware'] = $result['system']['firmware_ver'] ?? $result['system']['firmware'] ?? '';
        $result['summary']['serial'] = $result['system']['serial'] ?? $result['system']['serial_num'] ?? '';
        $result['summary']['uptime'] = $result['system']['up_time'] ?? $result['system']['uptime'] ?? '';
    }
    $result['summary']['packages_count'] = is_array($result['packages']) ? count($result['packages']) : 0;
    $result['summary']['users_count'] = is_array($result['users']) ? count($result['users']) : 0;
    $result['summary']['groups_count'] = is_array($result['groups']) ? count($result['groups']) : 0;
    $result['summary']['shares_count'] = is_array($result['shares']) ? count($result['shares']) : 0;
    $result['summary']['services_count'] = is_array($result['services']) ? count($result['services']) : 0;

    dmd_nas_dsm_call($base, 'auth.cgi', ['api'=>'SYNO.API.Auth','version'=>6,'method'=>'logout','session'=>'DSM'], $sid);
    return [true, $result, 'DSM actualisé : ' . $result['summary']['packages_count'] . ' paquet(s), ' . $result['summary']['users_count'] . ' utilisateur(s), ' . $result['summary']['groups_count'] . ' groupe(s), ' . $result['summary']['shares_count'] . ' partage(s).'];
}


function dmd_nas_dsm_session($item) {
    $base = dmd_nas_dsm_base_from_item($item);
    $user = trim((string)($item['api_user'] ?? ''));
    $pass = dmd_nas_get_api_pass($item);
    if ($base === '' || $user === '' || $pass === '') return [false, null, null, null, 'API Synology incomplète.'];
    [$ok, $auth, $err] = dmd_nas_dsm_call($base, 'auth.cgi', [
        'api'=>'SYNO.API.Auth',
        'version'=>6,
        'method'=>'login',
        'account'=>$user,
        'passwd'=>$pass,
        'session'=>'DSM',
        'format'=>'sid',
        'enable_syno_token'=>'yes'
    ]);
    if (!$ok) return [false, null, null, null, $err];
    if (empty($auth['success']) || empty($auth['data']['sid'])) return [false, null, null, null, 'Login DSM refusé : ' . json_encode($auth, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)];
    $sid = $auth['data']['sid'];
    $synoToken = (string)($auth['data']['synotoken'] ?? $auth['data']['SynoToken'] ?? $auth['data']['syno_token'] ?? '');
    [$iok, $apiInfo, $ierr] = dmd_nas_dsm_call($base, 'query.cgi', ['api'=>'SYNO.API.Info','version'=>1,'method'=>'query','query'=>'all'], $sid);
    if (!$iok || empty($apiInfo['success'])) {
        dmd_nas_dsm_call($base, 'auth.cgi', ['api'=>'SYNO.API.Auth','version'=>6,'method'=>'logout','session'=>'DSM'], $sid);
        return [false, null, null, null, 'Découverte API DSM impossible : ' . ($ierr ?: json_encode($apiInfo, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES))];
    }
    if (is_array($apiInfo) && $synoToken !== '') $apiInfo['__synotoken'] = $synoToken;
    return [true, $base, $sid, $apiInfo, ''];
}
function dmd_nas_dsm_logout($base, $sid) {
    if ($base && $sid) dmd_nas_dsm_call($base, 'auth.cgi', ['api'=>'SYNO.API.Auth','version'=>6,'method'=>'logout','session'=>'DSM'], $sid);
}
function dmd_nas_dsm_code_label($code) {
    $code = (string)$code;
    $map = [
        '101' => 'paramètre invalide ou manquant',
        '102' => 'API/méthode inconnue',
        '103' => 'API/méthode refusée ou non disponible sur ce DSM',
        '104' => 'version API non supportée',
        '105' => 'session non connectée',
        '106' => 'session expirée',
        '107' => 'permission insuffisante',
        '119' => 'SID/session invalide'
    ];
    return $map[$code] ?? 'code métier DSM non documenté côté module';
}
function dmd_nas_dsm_error_one($api, $method, $data, $err = '') {
    if ($err !== '') return $api . '.' . $method . ' : ' . $err;
    $error = is_array($data) ? ($data['error'] ?? null) : null;
    if (is_array($error)) {
        $code = (string)($error['code'] ?? '');
        $extra = $error;
        unset($extra['code']);
        $msg = $api . '.' . $method;
        if ($code !== '') $msg .= ' : code ' . $code . ' (' . dmd_nas_dsm_code_label($code) . ')';
        if (!empty($extra)) $msg .= ' ; retour DSM ' . json_encode($extra, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return $msg;
    }
    return $api . '.' . $method . ' : retour DSM ' . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
function dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries) {
    $errors = [];
    $lastData = null;
    foreach ($tries as $try) {
        [$api, $method, $params] = $try + [null, null, []];
        [$ok, $data, $err] = dmd_nas_dsm_call_api($base, $apiInfo, $api, $method, $params ?: [], $sid);
        if (is_array($data)) $lastData = $data;
        if ($ok && !empty($data['success'])) return [true, $data, $api . '.' . $method];
        $errors[] = dmd_nas_dsm_error_one((string)$api, (string)$method, $data, (string)$err);
    }
    $errors = array_values(array_unique($errors));
    return [false, $lastData, implode(' | ', array_slice($errors, 0, 8))];
}
function dmd_nas_extract_list($payload) {
    if (!is_array($payload)) return [];
    $data = $payload['data'] ?? $payload;
    foreach (['packages','available','servers','items','list','containers','images','result','data'] as $k) {
        if (isset($data[$k]) && is_array($data[$k])) {
            if (dmd_nas_array_is_list_compat($data[$k])) return $data[$k];
        }
    }
    if (isset($data['packages']) && is_array($data['packages'])) return array_values($data['packages']);
    if (dmd_nas_array_is_list_compat($data)) return $data;
    return [];
}
function dmd_nas_dsm_pkg_normalize_meta($value) {
    if (is_string($value)) {
        $trim = trim($value);
        if ($trim !== '' && ($trim[0] === '{' || $trim[0] === '[')) {
            $json = json_decode($trim, true);
            if (is_array($json)) return dmd_nas_dsm_pkg_normalize_meta($json);
        }
        return $value;
    }
    if (is_array($value)) {
        foreach ($value as $k => $v) $value[$k] = dmd_nas_dsm_pkg_normalize_meta($v);
    }
    return $value;
}
function dmd_nas_dsm_pkg_path($pkg, $path) {
    $cur = dmd_nas_dsm_pkg_normalize_meta($pkg);
    foreach (explode('.', (string)$path) as $part) {
        if (!is_array($cur) || !array_key_exists($part, $cur)) return null;
        $cur = dmd_nas_dsm_pkg_normalize_meta($cur[$part]);
    }
    return $cur;
}
function dmd_nas_dsm_pkg_classify_status($raw, $source = '') {
    if ($raw === true || $raw === 1 || $raw === '1') return ['state'=>'on', 'label'=>'Actif', 'raw'=>(string)$raw, 'source'=>$source];
    if ($raw === false || $raw === 0 || $raw === '0') return ['state'=>'off', 'label'=>'Arrêté', 'raw'=>(string)$raw, 'source'=>$source];
    if (is_array($raw)) return null;
    $t = strtolower(trim((string)$raw));
    if ($t === '') return null;
    if (in_array($t, ['running','run','started','enabled','enable','on','active','true'], true) || strpos($t, 'running') !== false || strpos($t, 'started') !== false || strpos($t, 'enabled') !== false) {
        return ['state'=>'on', 'label'=>'Actif', 'raw'=>(string)$raw, 'source'=>$source];
    }
    if (in_array($t, ['stopped','stop','disabled','disable','off','inactive','false','not running'], true) || strpos($t, 'stopped') !== false || strpos($t, 'disabled') !== false || strpos($t, 'not running') !== false) {
        return ['state'=>'off', 'label'=>'Arrêté', 'raw'=>(string)$raw, 'source'=>$source];
    }
    return null;
}
function dmd_nas_dsm_pkg_op_has($ops, $name) {
    $ops = dmd_nas_dsm_pkg_normalize_meta($ops);
    $name = strtolower((string)$name);
    if (!$ops) return false;
    if (is_string($ops)) return strpos(strtolower($ops), $name) !== false;
    if (!is_array($ops)) return false;
    if (array_key_exists($name, $ops) && $ops[$name]) return true;
    foreach ($ops as $k => $v) {
        if (strtolower((string)$k) === $name && $v) return true;
        if (is_string($v) && strtolower($v) === $name) return true;
        if (is_array($v) && dmd_nas_dsm_pkg_op_has($v, $name)) return true;
    }
    return false;
}
function dmd_nas_dsm_pkg_status($pkg) {
    $pkg = dmd_nas_dsm_pkg_normalize_meta($pkg);
    foreach (['status','state','run','running','is_running','started','enabled','enable','additional.status','additional.status_origin','additional.status_description','additional.state','additional.installed_info.status','installed_info.status'] as $path) {
        $status = dmd_nas_dsm_pkg_classify_status(dmd_nas_dsm_pkg_path($pkg, $path), $path);
        if ($status) return $status;
    }
    foreach (['available_operation','additional.available_operation','installed_info.available_operation'] as $path) {
        $ops = dmd_nas_dsm_pkg_path($pkg, $path);
        if (dmd_nas_dsm_pkg_op_has($ops, 'stop') || dmd_nas_dsm_pkg_op_has($ops, 'restart')) return ['state'=>'on', 'label'=>'Actif', 'raw'=>'stop/restart disponible', 'source'=>$path];
        if (dmd_nas_dsm_pkg_op_has($ops, 'start')) return ['state'=>'off', 'label'=>'Arrêté', 'raw'=>'start disponible', 'source'=>$path];
    }
    foreach (['ctl_stop','additional.ctl_stop','available_operation.stop'] as $path) {
        $v = dmd_nas_dsm_pkg_path($pkg, $path);
        if ($v === true || $v === 1 || $v === '1') return ['state'=>'on', 'label'=>'Actif', 'raw'=>'stop disponible', 'source'=>$path];
    }
    foreach (['ctl_start','additional.ctl_start','available_operation.start'] as $path) {
        $v = dmd_nas_dsm_pkg_path($pkg, $path);
        if ($v === true || $v === 1 || $v === '1') return ['state'=>'off', 'label'=>'Arrêté', 'raw'=>'start disponible', 'source'=>$path];
    }
    return ['state'=>'unknown', 'label'=>'État non renvoyé par DSM', 'raw'=>'', 'source'=>'DSM'];
}
function dmd_nas_dsm_pkg_with_status($pkg) {
    if (!is_array($pkg)) return $pkg;
    $pkg = dmd_nas_dsm_pkg_normalize_meta($pkg);
    $pkg['_dmd_status'] = dmd_nas_dsm_pkg_status($pkg);
    return $pkg;
}
function dmd_nas_dsm_package_merge_meta($base, $apiInfo, $sid, $pkg) {
    if (!is_array($pkg)) return $pkg;
    $id = dmd_nas_dsm_pkg_first($pkg, ['id','package','package_id','package_name','pkgname','name']);
    if ($id === '') return dmd_nas_dsm_pkg_with_status($pkg);

    $fields = ['status','status_code','status_origin','status_description','dsm_apps','startable','available_operation','installed_info'];
    $jsonAdditional = json_encode($fields, JSON_UNESCAPED_SLASHES);
    $csvAdditional = implode(',', $fields);

    $tries = [];
    foreach ([$jsonAdditional, $csvAdditional] as $additional) {
        foreach ([['package_id'=>$id], ['id'=>$id], ['package'=>$id], ['name'=>$id]] as $idParams) {
            $tries[] = ['SYNO.Core.Package', 'get', $idParams + ['additional'=>$additional]];
            $tries[] = ['SYNO.Package', 'get', $idParams + ['additional'=>$additional]];
            $tries[] = ['SYNO.Core.Package.Info', 'get', $idParams + ['additional'=>$additional]];
        }
    }
    /* Certains DSM exposent un endpoint de statut séparé. On le tente aussi. */
    foreach ([['package_id'=>$id], ['id'=>$id], ['package'=>$id], ['name'=>$id]] as $idParams) {
        $tries[] = ['SYNO.Core.Package', 'status', $idParams];
        $tries[] = ['SYNO.Package', 'status', $idParams];
        $tries[] = ['SYNO.Core.Package.Control', 'status', $idParams];
        $tries[] = ['SYNO.Core.Package.Control', 'get', $idParams + ['additional'=>$jsonAdditional]];
        $tries[] = ['SYNO.Core.Package.Info', 'get', $idParams + ['additional'=>$jsonAdditional]];
    }

    [$ok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    if ($ok && is_array($data)) {
        $payload = $data['data'] ?? $data;
        if (isset($payload['package']) && is_array($payload['package'])) $payload = $payload['package'];
        if (isset($payload['packages']) && is_array($payload['packages']) && isset($payload['packages'][0]) && is_array($payload['packages'][0])) $payload = $payload['packages'][0];
        if (is_array($payload)) $pkg = array_replace_recursive($pkg, $payload);
    }
    return dmd_nas_dsm_pkg_with_status($pkg);
}
function dmd_nas_dsm_enrich_installed_packages($base, $apiInfo, $sid, $packages) {
    if (!is_array($packages)) return [];
    $out = [];
    $n = 0;
    foreach ($packages as $pkg) {
        $n++;
        $pkg = ($n <= 80) ? dmd_nas_dsm_package_merge_meta($base, $apiInfo, $sid, $pkg) : $pkg;
        $out[] = dmd_nas_dsm_pkg_with_status($pkg);
    }
    return $out;
}
function dmd_nas_dsm_package_center($item) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    $result = ['refreshed_at'=>date('Y-m-d H:i:s'), 'installed'=>[], 'available'=>[], 'errors'=>[]];

    $installedFields = ['description','description_enu','dependent_packages','beta','distributor','maintainer','dsm_apps','dsm_app_page','startable','installed_info','support_url','is_uninstall_pages','install_type','autoupdate','silent_upgrade','installing_progress','ctl_uninstall','updated_at','status','status_code','status_origin','status_description','url','available_operation'];
    $installedAdditionalJson = json_encode($installedFields, JSON_UNESCAPED_SLASHES);
    $installedAdditionalCsv = implode(',', $installedFields);
    [$ok1, $installed, $msg1] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package','list',['additional'=>$installedAdditionalJson, 'ignore_hidden'=>'false']],
        ['SYNO.Core.Package','list',['additional'=>$installedAdditionalCsv, 'ignore_hidden'=>'false']],
        ['SYNO.Core.Package','list',['additional'=>$installedAdditionalJson]],
        ['SYNO.Core.Package','list',['additional'=>$installedAdditionalCsv]],
        ['SYNO.Package','list',['additional'=>$installedAdditionalJson]],
        ['SYNO.Package','list',['additional'=>$installedAdditionalCsv]],
        ['SYNO.Core.Package','list',[]],
        ['SYNO.Package','list',[]],
    ]);
    if ($ok1) $result['installed'] = dmd_nas_dsm_enrich_installed_packages($base, $apiInfo, $sid, dmd_nas_extract_list($installed)); else $result['errors']['installed'] = $msg1;

    [$ok2, $available, $msg2] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package.Server','list',[]],
        ['SYNO.Core.Package.Server','list_package',[]],
        ['SYNO.Core.Package','list_server',[]],
        ['SYNO.Package','list_server',[]],
    ]);
    if ($ok2) {
        $rawAvailable = dmd_nas_extract_list($available);
        $result['available_total'] = count($rawAvailable);
        $result['available_hidden_installed'] = max(0, count($rawAvailable) - count(dmd_nas_dsm_filter_available_packages($rawAvailable, $result['installed'])));
        $result['available'] = dmd_nas_dsm_filter_available_packages($rawAvailable, $result['installed']);
    } else {
        $result['errors']['available'] = $msg2;
    }

    dmd_nas_dsm_logout($base, $sid);
    return [true, $result, count($result['installed']) . ' paquet(s) installé(s), ' . count($result['available']) . ' paquet(s) catalogue non installé(s).'];
}
function dmd_nas_dsm_pkg_first($pkg, $keys) {
    if (!is_array($pkg)) return '';
    foreach ($keys as $k) {
        if (isset($pkg[$k]) && $pkg[$k] !== '' && !is_array($pkg[$k]) && !is_object($pkg[$k])) return (string)$pkg[$k];
        if (isset($pkg['additional']) && is_array($pkg['additional']) && isset($pkg['additional'][$k]) && $pkg['additional'][$k] !== '' && !is_array($pkg['additional'][$k])) return (string)$pkg['additional'][$k];
    }
    return '';
}

function dmd_nas_dsm_pkg_norm_key($value) {
    $value = strtolower(trim((string)$value));
    if ($value === '') return '';
    if (function_exists('iconv')) {
        $x = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        if (is_string($x) && $x !== '') $value = $x;
    }
    $value = preg_replace('/[^a-z0-9]+/', '', $value);
    $value = str_replace(['httpserver','server','station','package','service'], '', $value);
    return (string)$value;
}
function dmd_nas_dsm_pkg_candidate_keys($pkg) {
    if (!is_array($pkg)) return [];
    $keys = ['id','package','package_id','package_name','pkgname','name','display_name','title','dname'];
    $out = [];
    foreach ($keys as $k) {
        $v = dmd_nas_dsm_pkg_first($pkg, [$k]);
        if ($v !== '') {
            $out[] = strtolower(trim($v));
            $n = dmd_nas_dsm_pkg_norm_key($v);
            if ($n !== '') $out[] = $n;
        }
    }
    $pkgId = dmd_nas_dsm_pkg_first($pkg, ['package','package_id','pkgname','id']);
    $display = dmd_nas_dsm_pkg_first($pkg, ['display_name','name','title']);
    if ($pkgId !== '' && $display !== '') {
        $n = dmd_nas_dsm_pkg_norm_key($pkgId . ' ' . $display);
        if ($n !== '') $out[] = $n;
    }
    return array_values(array_unique(array_filter($out, static fn($v) => $v !== '')));
}
function dmd_nas_dsm_pkg_in_list($pkg, $installed) {
    if (!is_array($installed)) return false;
    $installedKeys = [];
    foreach ($installed as $one) {
        foreach (dmd_nas_dsm_pkg_candidate_keys(is_array($one) ? $one : []) as $k) $installedKeys[$k] = true;
    }
    foreach (dmd_nas_dsm_pkg_candidate_keys(is_array($pkg) ? $pkg : []) as $k) {
        if (isset($installedKeys[$k])) return true;
    }
    return false;
}
function dmd_nas_dsm_filter_available_packages($available, $installed) {
    if (!is_array($available)) return [];
    $out = [];
    foreach ($available as $pkg) {
        if (!is_array($pkg)) continue;
        if (!dmd_nas_dsm_pkg_in_list($pkg, $installed)) $out[] = $pkg;
    }
    return $out;
}
function dmd_nas_dsm_bool($v) {
    return $v ? 'true' : 'false';
}
function dmd_nas_dsm_cached_package($item, $package, $preferAvailable = false) {
    $package = trim((string)$package);
    $sets = [];
    if ($preferAvailable) {
        $sets[] = $item['dsm_packages']['available'] ?? [];
        $sets[] = $item['dsm_packages']['installed'] ?? [];
    } else {
        $sets[] = $item['dsm_packages']['installed'] ?? [];
        $sets[] = $item['dsm_info']['packages'] ?? [];
        $sets[] = $item['dsm_packages']['available'] ?? [];
    }
    foreach ($sets as $list) {
        if (!is_array($list)) continue;
        foreach ($list as $pkg) {
            if (!is_array($pkg)) continue;
            $ids = [
                dmd_nas_dsm_pkg_first($pkg, ['id']),
                dmd_nas_dsm_pkg_first($pkg, ['package']),
                dmd_nas_dsm_pkg_first($pkg, ['package_id']),
                dmd_nas_dsm_pkg_first($pkg, ['package_name']),
                dmd_nas_dsm_pkg_first($pkg, ['pkgname']),
                dmd_nas_dsm_pkg_first($pkg, ['name']),
                dmd_nas_dsm_pkg_first($pkg, ['display_name']),
                dmd_nas_dsm_pkg_first($pkg, ['title']),
            ];
            foreach ($ids as $id) {
                if ($id !== '' && strcasecmp($id, $package) === 0) return $pkg;
            }
        }
    }
    return [];
}
function dmd_nas_dsm_package_id_from_meta($meta, $fallback) {
    $id = dmd_nas_dsm_pkg_first($meta, ['id','package','package_id','package_name','pkgname']);
    return $id !== '' ? $id : trim((string)$fallback);
}
function dmd_nas_dsm_volume_from_payload($payload) {
    if (!is_array($payload)) return '';
    $data = $payload['data'] ?? $payload;
    foreach (['default_vol','volume_path','mount_point'] as $k) {
        if (!empty($data[$k]) && is_string($data[$k])) return $data[$k];
    }
    if (!empty($data['volume_list']) && is_array($data['volume_list'])) {
        foreach ($data['volume_list'] as $vol) {
            if (is_array($vol) && !empty($vol['mount_point'])) return (string)$vol['mount_point'];
        }
    }
    return '';
}
function dmd_nas_dsm_default_volume($base, $apiInfo, $sid, $item) {
    [$ok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package.Setting.Volume', 'get', []],
        ['SYNO.Core.Package.Setting', 'get', []],
    ]);
    if ($ok) {
        $v = dmd_nas_dsm_volume_from_payload($data);
        if ($v !== '') return $v;
    }
    $storage = $item['dsm_info']['storage'] ?? null;
    if (is_array($storage)) {
        $json = json_encode($storage, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (preg_match('#/volume\d+#', (string)$json, $m)) return $m[0];
    }
    return '/volume1';
}
function dmd_nas_dsm_codes_from_msg($msg) {
    preg_match_all('/"code"\s*:\s*(\d+)/', (string)$msg, $m);
    $codes = array_values(array_unique($m[1] ?? []));
    return $codes ? implode(', ', $codes) : '';
}

function dmd_nas_dsm_params_clean($params) {
    $out = [];
    foreach ((array)$params as $k => $v) {
        if ($v === null) continue;
        if (is_string($v) && trim($v) === '') continue;
        if (is_bool($v)) $v = $v ? 'true' : 'false';
        $out[$k] = $v;
    }
    return $out;
}

function dmd_nas_dsm_extra_values_json($raw) {
    if (is_array($raw)) return json_encode((object)$raw, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $raw = trim((string)$raw);
    if ($raw === '') return '';
    $decoded = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) return null;
    return json_encode((object)$decoded, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
function dmd_nas_dsm_contains_extra_values($data, $msg = '') {
    $txt = strtolower((string)$msg . ' ' . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    return strpos($txt, 'extra_values') !== false;
}
function dmd_nas_dsm_collect_extra_fields($value, &$out) {
    if (!is_array($value)) return;
    if (isset($value['extra_values']) && is_array($value['extra_values'])) {
        foreach ($value['extra_values'] as $k => $v) {
            if (is_array($v)) {
                $name = (string)($v['name'] ?? $v['id'] ?? $v['key'] ?? $k);
                if ($name !== '') $out[$name] = ['name'=>$name, 'label'=>(string)($v['label'] ?? $v['title'] ?? $name), 'type'=>(string)($v['type'] ?? 'text'), 'default'=>$v['default'] ?? ''];
            } else {
                $name = is_string($k) ? $k : (string)$v;
                if ($name !== '') $out[$name] = ['name'=>$name, 'label'=>$name, 'type'=>'text', 'default'=>''];
            }
        }
    }
    if (isset($value['name']) && (string)$value['name'] !== '' && (isset($value['type']) || isset($value['label']) || isset($value['title']))) {
        $name = (string)$value['name'];
        if ($name !== 'extra_values') $out[$name] = ['name'=>$name, 'label'=>(string)($value['label'] ?? $value['title'] ?? $name), 'type'=>(string)($value['type'] ?? 'text'), 'default'=>$value['default'] ?? ''];
    }
    foreach ($value as $child) if (is_array($child)) dmd_nas_dsm_collect_extra_fields($child, $out);
}
function dmd_nas_dsm_extra_required_payload($packageId, $meta, $volume, $rawData, $rawMsg) {
    $fields = [];
    dmd_nas_dsm_collect_extra_fields(is_array($rawData) ? $rawData : [], $fields);
    dmd_nas_dsm_collect_extra_fields(is_array($meta) ? $meta : [], $fields);
    return [
        'extra_required' => true,
        'package' => $packageId,
        'package_name' => dmd_nas_dsm_pkg_first(is_array($meta) ? $meta : [], ['display_name','name','title']) ?: $packageId,
        'volume_path' => $volume,
        'fields' => array_values($fields),
        'raw_dsm' => $rawData,
        'raw_message' => mb_substr((string)$rawMsg, 0, 900)
    ];
}

function dmd_nas_dsm_collect_wizard_fields($node, &$out) {
    if (!is_array($node)) return;
    $key = '';
    foreach (['key','name','id','field','var','variable'] as $k) {
        if (isset($node[$k]) && is_scalar($node[$k]) && trim((string)$node[$k]) !== '') { $key = trim((string)$node[$k]); break; }
    }
    $type = strtolower((string)($node['type'] ?? $node['xtype'] ?? $node['input_type'] ?? ''));
    $label = '';
    foreach (['desc','description','label','title','display','text','caption'] as $k) {
        if (isset($node[$k]) && is_scalar($node[$k]) && trim((string)$node[$k]) !== '') { $label = trim((string)$node[$k]); break; }
    }
    $inputTypes = ['textfield','text','password','passwd','textarea','textbox','checkbox','radio','select','combobox','singleselect','multiselect','number','spinner'];
    if ($key !== '' && ($type === '' || in_array($type, $inputTypes, true) || strpos($key, 'wizard_') === 0)) {
        $options = [];
        foreach (['items','options','values','choices','store'] as $okey) {
            if (!empty($node[$okey]) && is_array($node[$okey])) {
                foreach ($node[$okey] as $opt) {
                    if (is_array($opt)) {
                        $val = '';
                        foreach (['value','key','id','name'] as $vk) { if (isset($opt[$vk]) && is_scalar($opt[$vk])) { $val = (string)$opt[$vk]; break; } }
                        $txt = '';
                        foreach (['text','label','display','desc','name'] as $tk) { if (isset($opt[$tk]) && is_scalar($opt[$tk])) { $txt = (string)$opt[$tk]; break; } }
                        if ($val !== '' || $txt !== '') $options[] = ['value'=>$val !== '' ? $val : $txt, 'label'=>$txt !== '' ? $txt : $val];
                    } elseif (is_scalar($opt)) {
                        $options[] = ['value'=>(string)$opt, 'label'=>(string)$opt];
                    }
                }
            }
        }
        $default = $node['default'] ?? $node['defaultValue'] ?? $node['value'] ?? '';
        $out[$key] = [
            'name'=>$key,
            'label'=>$label !== '' ? $label : $key,
            'type'=>$type !== '' ? $type : 'text',
            'default'=>is_scalar($default) ? (string)$default : '',
            'options'=>$options,
            'source'=>'install_uifile'
        ];
    }
    foreach ($node as $child) if (is_array($child)) dmd_nas_dsm_collect_wizard_fields($child, $out);
}

function dmd_nas_dsm_read_spk_entry($filePath, $entry) {
    $filePath = (string)$filePath;
    $entry = (string)$entry;
    if ($filePath === '' || $entry === '' || !is_file($filePath)) return '';
    if (!function_exists('shell_exec')) return '';
    $cmd = 'tar -xOf ' . escapeshellarg($filePath) . ' ' . escapeshellarg($entry) . ' 2>/dev/null';
    $raw = @shell_exec($cmd);
    return is_string($raw) ? $raw : '';
}

function dmd_nas_dsm_download_spk_temp($url) {
    $url = trim((string)$url);
    if ($url === '' || !preg_match('#^https?://#i', $url)) return [false, '', 'URL SPK invalide.'];
    $tmp = @tempnam(sys_get_temp_dir(), 'dmdnas_spk_');
    if (!$tmp) return [false, '', 'Impossible de créer le fichier temporaire SPK.'];
    $ok = false; $msg = '';
    if (function_exists('curl_init')) {
        $fh = @fopen($tmp, 'wb');
        if ($fh) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_FILE => $fh,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 5,
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT => 45,
                CURLOPT_USERAGENT => 'DoMyDesk-DMD-NAS/1.2.0',
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_FAILONERROR => false,
            ]);
            $res = curl_exec($ch);
            $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $err = curl_error($ch);
            curl_close($ch); fclose($fh);
            $ok = ($res !== false && $http >= 200 && $http < 400 && @filesize($tmp) > 0);
            if (!$ok) $msg = $err !== '' ? $err : ('HTTP ' . $http);
        }
    } elseif (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(['http'=>['timeout'=>45,'follow_location'=>1,'user_agent'=>'DoMyDesk-DMD-NAS/1.2.0'], 'ssl'=>['verify_peer'=>false,'verify_peer_name'=>false]]);
        $in = @fopen($url, 'rb', false, $ctx);
        $out = @fopen($tmp, 'wb');
        if ($in && $out) {
            stream_copy_to_stream($in, $out);
            fclose($in); fclose($out);
            $ok = @filesize($tmp) > 0;
        } else {
            if (is_resource($in)) fclose($in);
            if (is_resource($out)) fclose($out);
            $msg = 'Téléchargement HTTP indisponible.';
        }
    } else {
        $msg = 'Aucun client HTTP PHP disponible.';
    }
    if (!$ok) { @unlink($tmp); return [false, '', $msg ?: 'Téléchargement SPK impossible.']; }
    return [true, $tmp, ''];
}

function dmd_nas_dsm_wizard_fields_from_url($url) {
    [$ok, $tmp, $msg] = dmd_nas_dsm_download_spk_temp($url);
    if (!$ok) return [[], ['url'=>(string)$url, 'download_error'=>$msg]];
    [$fields, $debug] = dmd_nas_dsm_wizard_fields_from_spk($tmp);
    @unlink($tmp);
    $debug['url'] = (string)$url;
    $debug['downloaded_by_domydesk'] = true;
    return [$fields, $debug];
}

function dmd_nas_dsm_wizard_fields_from_spk($filePath) {
    $fields = [];
    $debug = ['file'=>(string)$filePath, 'entries'=>[]];
    if (!is_string($filePath) || $filePath === '' || !is_file($filePath) || !function_exists('shell_exec')) return [$fields, $debug];
    $listRaw = @shell_exec('tar -tf ' . escapeshellarg($filePath) . ' 2>/dev/null');
    if (!is_string($listRaw) || trim($listRaw) === '') return [$fields, $debug];
    $entries = preg_split('/
?
/', trim($listRaw));
    $wanted = [];
    foreach ($entries as $e) {
        $e = trim($e);
        if ($e === '') continue;
        $base = basename($e);
        if (preg_match('/^install_uifile($|_)/i', $base) || preg_match('#(^|/)WIZARD_UIFILES/.*/?install_uifile($|_)#i', $e)) {
            $wanted[] = $e;
        }
    }
    usort($wanted, function($a, $b) {
        $score = function($x) {
            $x = strtolower($x);
            if (strpos($x, 'install_uifile_fre') !== false) return 0;
            if (strpos($x, 'install_uifile_enu') !== false) return 1;
            if (preg_match('/install_uifile$/', $x)) return 2;
            return 3;
        };
        return $score($a) <=> $score($b);
    });
    foreach ($wanted as $entry) {
        $debug['entries'][] = $entry;
        $raw = dmd_nas_dsm_read_spk_entry($filePath, $entry);
        if (trim($raw) === '') continue;
        $json = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($json)) continue;
        dmd_nas_dsm_collect_wizard_fields($json, $fields);
        if ($fields) break;
    }
    return [array_values($fields), $debug];
}

function dmd_nas_dsm_extract_volumes_from_check($data) {
    $payload = is_array($data) ? ($data['data'] ?? $data) : [];
    $out = [];
    if (isset($payload['volume_list']) && is_array($payload['volume_list'])) {
        foreach ($payload['volume_list'] as $v) {
            if (!is_array($v)) continue;
            $mount = (string)($v['mount_point'] ?? $v['volume_path'] ?? $v['path'] ?? '');
            if ($mount === '') continue;
            $out[] = [
                'mount_point'=>$mount,
                'display'=>(string)($v['display'] ?? $v['vol_desc'] ?? $mount),
                'size_free'=>(string)($v['size_free'] ?? ''),
                'size_total'=>(string)($v['size_total'] ?? '')
            ];
        }
    }
    return $out;
}

function dmd_nas_dsm_prepare_package_install($item, $package) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    $meta = dmd_nas_dsm_cached_package($item, $package, true);
    $packageId = dmd_nas_dsm_package_id_from_meta($meta, $package);
    if ($packageId === '') { dmd_nas_dsm_logout($base, $sid); return [false, null, 'Identifiant paquet absent.']; }
    $meta = dmd_nas_dsm_get_package_server_detail($base, $apiInfo, $sid, $packageId, $meta);
    $volume = dmd_nas_dsm_default_volume($base, $apiInfo, $sid, $item);
    $replacePkgs = $meta['replace_pkgs'] ?? [];
    if (!is_array($replacePkgs)) $replacePkgs = [];
    $checkParams = dmd_nas_dsm_params_clean([
        'id' => $packageId,
        'install_type' => dmd_nas_dsm_pkg_first($meta, ['install_type']),
        'install_on_cold_storage' => dmd_nas_dsm_bool(in_array(strtolower(dmd_nas_dsm_pkg_first($meta, ['install_on_cold_storage'])), ['true','1','yes'], true)),
        'blCheckDep' => 'false',
        'replacepkgs' => json_encode((object)$replacePkgs, JSON_UNESCAPED_SLASHES),
    ]);
    [$checkOk, $checkData, $checkMsg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package.Installation', 'check', $checkParams],
        ['SYNO.Core.Package.Installation', 'check_installation', $checkParams],
    ]);
    $checked = is_array($checkData) ? ($checkData['data'] ?? $checkData) : [];
    if (is_array($checked) && !empty($checked['volume_path'])) $volume = (string)$checked['volume_path'];
    $fields = [];
    dmd_nas_dsm_collect_extra_fields(is_array($checkData) ? $checkData : [], $fields);
    dmd_nas_dsm_collect_extra_fields(is_array($meta) ? $meta : [], $fields);
    $downloadInfo = null; $wizardDebug = [];
    $url = dmd_nas_dsm_pkg_first($meta, ['link','url','download_url','remote_link']);
    /* Le chemin renvoyé par DSM après un download appartient au NAS, pas au serveur DoMyDesk.
       On inspecte donc d'abord le SPK directement depuis son URL de catalogue côté DoMyDesk. */
    if (!$fields && $url !== '') {
        [$urlWizardFields, $urlWizardDebug] = dmd_nas_dsm_wizard_fields_from_url($url);
        $wizardDebug['catalog_url'] = $urlWizardDebug;
        foreach ($urlWizardFields as $wf) if (!empty($wf['name'])) $fields[$wf['name']] = $wf;
    }
    if (!$fields && $url !== '') {
        $checksum = dmd_nas_dsm_pkg_first($meta, ['md5','checksum','sha256']);
        $filesize = dmd_nas_dsm_pkg_first($meta, ['size','filesize']);
        [$dlOk, $dlData, $dlMsg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
            ['SYNO.Core.Package.Installation', 'download', dmd_nas_dsm_params_clean(['package_id'=>$packageId, 'url'=>$url, 'checksum'=>$checksum, 'filesize'=>$filesize])],
            ['SYNO.Core.Package.Installation', 'download', dmd_nas_dsm_params_clean(['package_id'=>$packageId, 'url'=>$url, 'md5'=>$checksum, 'size'=>$filesize])],
        ]);
        if ($dlOk && is_array($dlData)) {
            $dlPayload = dmd_nas_dsm_deepest_data_payload($dlData);
            $taskId = (string)(dmd_nas_dsm_find_recursive($dlData, ['taskid','task_id','taskId']) ?? '');
            for ($i = 0; $i < 6 && $taskId !== ''; $i++) {
                if ($i > 0) usleep(700000);
                [$diOk, $diData, $diMsg] = dmd_nas_dsm_downloaded_file_info($base, $apiInfo, $sid, $taskId);
                if ($diOk && is_array($diData)) {
                    $downloadInfo = $diData['data'] ?? $diData;
                    dmd_nas_dsm_collect_extra_fields($downloadInfo, $fields);
                    $filePath = (string)($downloadInfo['filename'] ?? $downloadInfo['file_path'] ?? $downloadInfo['path'] ?? '');
                    if ($filePath !== '') {
                        [$wizardFields, $wizardDebug] = dmd_nas_dsm_wizard_fields_from_spk($filePath);
                        foreach ($wizardFields as $wf) if (!empty($wf['name'])) $fields[$wf['name']] = $wf;
                        break;
                    }
                }
            }
        }
    }
    $data = [
        'extra_required'=>true,
        'package'=>$packageId,
        'package_name'=>dmd_nas_dsm_pkg_first(is_array($meta) ? $meta : [], ['display_name','name','title']) ?: $packageId,
        'volume_path'=>$volume,
        'volume_list'=>dmd_nas_dsm_extract_volumes_from_check($checkData),
        'fields'=>array_values($fields),
        'wizard_schema_found'=>count($fields) > 0,
        'raw_message'=>count($fields) ? 'Formulaire d’installation détecté depuis le paquet SPK / DSM.' : 'Aucun champ spécifique détecté. DMD-NAS tentera une installation directe sur le volume sélectionné et ne renverra plus vers Package Center.',
        'raw_dsm'=>['check'=>$checkData, 'download'=>$downloadInfo, 'wizard_debug'=>$wizardDebug]
    ];
    dmd_nas_dsm_logout($base, $sid);
    return [true, $data, count($fields) ? 'Formulaire DSM détecté.' : 'Aucun formulaire spécifique renvoyé par DSM.'];
}

function dmd_nas_dsm_install_error_summary($packageId, $checkOk, $directMsg, $downloadMsg, $easyMsg) {
    $all = trim((string)$easyMsg . ' ' . (string)$directMsg . ' ' . (string)$downloadMsg);
    $codes = dmd_nas_dsm_codes_from_msg($all);
    $codeText = $codes !== '' ? ' Code DSM : ' . $codes . '.' : '';
    if (strpos($all, 'extra_values') !== false || strpos($all, '"name":"extra_values"') !== false) {
        return 'DSM refuse l’installation de "' . $packageId . '" : le paquet réclame des paramètres d’installation supplémentaires (extra_values).' . $codeText;
    }
    if (strpos($all, 'code 107') !== false || strpos($all, '"code":107') !== false) {
        return 'DSM refuse l’installation de "' . $packageId . '" : droits insuffisants pour ce compte API.' . $codeText;
    }
    if (strpos($all, 'code 103') !== false || strpos($all, '"code":103') !== false) {
        return 'DSM refuse l’installation de "' . $packageId . '" via cette API/méthode sur ce DSM.' . $codeText;
    }
    if (!$checkOk) {
        return 'DSM refuse le contrôle préalable d’installation de "' . $packageId . '".' . $codeText;
    }
    return 'DSM refuse l’installation de "' . $packageId . '".' . $codeText;
}
function dmd_nas_dsm_get_package_server_detail($base, $apiInfo, $sid, $packageId, $meta = []) {
    $additional = json_encode(['description','maintainer','distributor','startable','dsm_apps','status','status_code','status_origin','status_description','install_reboot','install_type','install_on_cold_storage','break_pkgs','replace_pkgs'], JSON_UNESCAPED_SLASHES);
    $tries = [
        ['SYNO.Core.Package.Server', 'get', ['id'=>$packageId, 'package_id'=>$packageId, 'additional'=>$additional]],
        ['SYNO.Core.Package.Server', 'get', ['package'=>$packageId, 'additional'=>$additional]],
        ['SYNO.Core.Package.Server', 'info', ['id'=>$packageId, 'package_id'=>$packageId, 'additional'=>$additional]],
        ['SYNO.Core.Package', 'get', ['package_id'=>$packageId, 'additional'=>$additional]],
        ['SYNO.Core.Package', 'get', ['id'=>$packageId, 'additional'=>$additional]],
    ];
    [$ok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    if ($ok && is_array($data)) {
        $payload = $data['data'] ?? $data;
        if (isset($payload['package']) && is_array($payload['package'])) $payload = $payload['package'];
        if (is_array($payload)) return array_replace_recursive(is_array($meta) ? $meta : [], $payload);
    }
    return is_array($meta) ? $meta : [];
}


function dmd_nas_dsm_find_recursive($data, array $keys) {
    if (!is_array($data)) return null;
    foreach ($keys as $k) {
        if (array_key_exists($k, $data) && $data[$k] !== null && $data[$k] !== '') return $data[$k];
    }
    foreach ($data as $v) {
        if (!is_array($v)) continue;
        $found = dmd_nas_dsm_find_recursive($v, $keys);
        if ($found !== null && $found !== '') return $found;
    }
    return null;
}

function dmd_nas_dsm_deepest_data_payload($data) {
    $cur = $data;
    $guard = 0;
    while (is_array($cur) && isset($cur['data']) && is_array($cur['data']) && $guard++ < 8) {
        $next = $cur['data'];
        /* Ne descend que si le niveau courant ne contient pas déjà les champs utiles. */
        $hasUseful = false;
        foreach (['taskid','task_id','filename','file_path','path','tmp_folder','finished','progress','status','installing'] as $k) {
            if (array_key_exists($k, $cur)) { $hasUseful = true; break; }
        }
        if ($hasUseful) break;
        $cur = $next;
    }
    return is_array($cur) ? $cur : [];
}

function dmd_nas_dsm_downloaded_file_info($base, $apiInfo, $sid, $taskId) {
    if ($taskId === '') return [false, null, 'Task DSM vide.'];

    /* Package Center attend la fin REELLE du téléchargement avant Download.check.
       Appeler Download.check pendant que finished=false renvoie notamment 4501 sur
       certains DSM : ce code ne signifie alors PAS que le paquet est indisponible. */
    [$statusOk, $statusData, $statusMsg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package.Installation', 'status', ['taskid'=>$taskId]],
        ['SYNO.Core.Package.Installation', 'status', ['task_id'=>$taskId]],
    ]);

    if ($statusOk && is_array($statusData)) {
        $st = dmd_nas_dsm_deepest_data_payload($statusData);
        if (is_array($st)) {
            $finished = !empty($st['finished']);
            $progress = isset($st['progress']) ? (float)$st['progress'] : 0.0;
            $installing = !empty($st['installing']);
            if (!$finished && !$installing && $progress < 0.999999) {
                return [false, $statusData, 'Téléchargement DSM en cours (' . round(max(0,min(1,$progress))*100, 1) . ' %).'];
            }
        }
    }

    /* Une fois le téléchargement terminé, DSM expose le fichier temporaire ici. */
    [$checkOk, $checkData, $checkMsg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package.Installation.Download', 'check', ['taskid'=>$taskId]],
    ]);
    if ($checkOk) {
        $out = $checkData;
        if (is_array($out)) $out['_download_status'] = $statusData;
        return [true, $out, ''];
    }

    /* Si status indique explicitement que ce n'est pas fini, un 4501 de Download.check
       reste un état transitoire, pas une erreur d'installation. */
    if ($statusOk && is_array($statusData)) {
        $st = dmd_nas_dsm_deepest_data_payload($statusData);
        if (is_array($st) && empty($st['finished'])) {
            $progress = isset($st['progress']) ? (float)$st['progress'] : 0.0;
            return [false, $statusData, 'Téléchargement DSM en cours (' . round(max(0,min(1,$progress))*100, 1) . ' %).'];
        }
    }
    return [false, $checkData ?: $statusData, trim($statusMsg . ' | ' . $checkMsg, ' |')];
}
function dmd_nas_dsm_package_download_then_install($base, $apiInfo, $sid, $packageId, $downloadData, $volume, $extraValues = '') {
    $dlPayload = dmd_nas_dsm_deepest_data_payload($downloadData);
    $taskId = (string)(dmd_nas_dsm_find_recursive($downloadData, ['taskid','task_id','taskId']) ?? '');
    if ($taskId === '') {
        $state = (string)(dmd_nas_dsm_find_recursive($downloadData, ['status']) ?? '');
        return [false, $downloadData, "Téléchargement DSM lancé mais identifiant de tâche introuvable dans la réponse" . ($state !== '' ? ' (état : ' . $state . ')' : '') . '.'];
    }

    @set_time_limit(180);
    $fileInfo = null;
    $lastData = null;
    $lastMsg = '';
    /* Un paquet Synology peut prendre plusieurs dizaines de secondes à être téléchargé.
       L'ancienne version abandonnait après ~3,5 s, donc l'installation n'avait jamais de file_path. */
    $deadline = microtime(true) + 150.0;
    do {
        [$ok, $data, $msg] = dmd_nas_dsm_downloaded_file_info($base, $apiInfo, $sid, $taskId);
        if (is_array($data)) $lastData = $data;
        if ($ok && is_array($data)) {
            $candidate = dmd_nas_dsm_deepest_data_payload($data);
            $filePath = (string)(dmd_nas_dsm_find_recursive($data, ['filename','file_path','path']) ?? '');
            if ($filePath !== '') { $fileInfo = $candidate; break; }
        }
        $lastMsg = $msg;
        usleep(1000000);
    } while (microtime(true) < $deadline);

    if (!is_array($fileInfo)) {
        return [false, ['package'=>$packageId, 'task_id'=>$taskId, 'download'=>$lastData],
            "Le téléchargement DSM n'a pas atteint l'état terminé dans le délai du module." . ($lastMsg ? ' ' . mb_substr($lastMsg, 0, 300) : '')];
    }

    $filePath = (string)(dmd_nas_dsm_find_recursive($fileInfo, ['filename','file_path','path']) ?? '');
    $extraJson = dmd_nas_dsm_extra_values_json($extraValues);
    if ($extraJson === null) return [false, ['extra_invalid'=>true], 'extra_values doit être un objet JSON valide.'];
    if ($extraJson === '' && isset($fileInfo['extra_values']) && is_array($fileInfo['extra_values'])) {
        $extraJson = dmd_nas_dsm_extra_values_json($fileInfo['extra_values']);
    }
    if ($extraJson === '') $extraJson = json_encode((object)[], JSON_UNESCAPED_SLASHES);

    $installType = (string)($fileInfo['install_type'] ?? '');
    $cold = !empty($fileInfo['install_on_cold_storage']);
    $replace = $fileInfo['replace_pkgs'] ?? [];
    $checkParams = [
        'id'=>$packageId,
        'install_type'=>$installType,
        'install_on_cold_storage'=>$cold ? 'true' : 'false',
        'breakpkgs'=>null,
        'blCheckDep'=>'false',
        'replacepkgs'=>is_array($replace) ? json_encode((object)$replace, JSON_UNESCAPED_SLASHES) : (string)$replace,
    ];
    [$checkOk, $checkData, $checkMsg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package.Installation', 'check', dmd_nas_dsm_params_clean($checkParams)],
    ]);
    if ($checkOk && is_array($checkData)) {
        $c = $checkData['data'] ?? $checkData;
        if ($volume === '' && !empty($c['volume_path'])) $volume = (string)$c['volume_path'];
    }
    if ($volume === '') $volume = '/volume1';

    /* IMPORTANT : Package Center exécute le check + install via SYNO.Entry.Request
       dans une requête compound. L'appel direct à Installation.install renvoie
       notamment le code DSM 120 sur DSM 7 pour certains paquets, même si les
       paramètres paraissent corrects. On reproduit donc le contrat du WebUI. */
    $installApi = dmd_nas_dsm_pick_api($apiInfo, 'SYNO.Core.Package.Installation');
    $installVersion = 1;
    if (is_array($installApi)) {
        $installVersion = (int)($installApi['minVersion'] ?? $installApi['min_version'] ?? 1);
        if ($installVersion < 1) $installVersion = 1;
    }
    $extraObj = json_decode($extraJson, true);
    if (!is_array($extraObj)) $extraObj = [];
    $extraPayload = json_encode((object)$extraObj, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $compound = [
        [
            'api'=>'SYNO.Core.Package.Installation',
            'method'=>'check',
            'version'=>$installVersion,
            'id'=>$packageId,
            'install_type'=>$installType,
            'install_on_cold_storage'=>$cold,
            'breakpkgs'=>null,
            'blCheckDep'=>false,
            'replacepkgs'=>null,
        ],
        [
            'api'=>'SYNO.Core.Package.Installation',
            'method'=>'install',
            'version'=>$installVersion,
            'type'=>0,
            'volume_path'=>$volume,
            'path'=>$filePath,
            'check_codesign'=>true,
            'force'=>true,
            'installrunpackage'=>true,
            'extra_values'=>$extraPayload,
        ],
    ];
    [$iok, $idata, $imsg] = dmd_nas_dsm_batch_request($base, $apiInfo, $sid, $compound, 'sequential');
    if ($iok && dmd_nas_dsm_install_payload_has_success($idata)) {
        return [true, $idata, 'Installation lancée par DSM : ' . $packageId . '.'];
    }
    if (dmd_nas_dsm_contains_extra_values($idata, $imsg)) {
        return [false, dmd_nas_dsm_extra_required_payload($packageId, $fileInfo, $volume, $idata, $imsg),
            'DSM demande des paramètres supplémentaires pour installer ' . $packageId . '.'];
    }
    return [false, ['package'=>$packageId,'task_id'=>$taskId,'file_path'=>$filePath,'check'=>$checkData,'install'=>$idata],
        dmd_nas_dsm_install_error_summary($packageId, $checkOk, $imsg ?: $checkMsg, '', '')];
}

function dmd_nas_dsm_live_installed_snapshot($base, $apiInfo, $sid) {
    $fields = ['description','description_enu','dsm_apps','startable','installed_info','install_type','autoupdate','installing_progress','ctl_uninstall','updated_at','status','status_code','status_origin','status_description','url','available_operation'];
    $json = json_encode($fields, JSON_UNESCAPED_SLASHES);
    $csv = implode(',', $fields);
    [$ok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package','list',['additional'=>$json, 'ignore_hidden'=>'false']],
        ['SYNO.Core.Package','list',['additional'=>$csv, 'ignore_hidden'=>'false']],
        ['SYNO.Core.Package','list',['additional'=>$json]],
        ['SYNO.Core.Package','list',['additional'=>$csv]],
        ['SYNO.Package','list',['additional'=>$json]],
        ['SYNO.Package','list',['additional'=>$csv]],
        ['SYNO.Core.Package','list',[]],
        ['SYNO.Package','list',[]],
    ]);
    if (!$ok) return [];
    return dmd_nas_dsm_enrich_installed_packages($base, $apiInfo, $sid, dmd_nas_extract_list($data));
}

function dmd_nas_dsm_install_payload_has_success($data) {
    if (!is_array($data)) return false;
    if (!empty($data['success'])) return true;
    $d = $data['data'] ?? $data;
    if (is_array($d) && array_key_exists('has_fail', $d) && !$d['has_fail']) return true;
    if (!empty($d['result']) && is_array($d['result'])) {
        $hasFail = false; $hasOk = false;
        foreach ($d['result'] as $r) {
            if (!is_array($r)) continue;
            if (array_key_exists('success', $r)) {
                if ($r['success']) $hasOk = true; else $hasFail = true;
            }
        }
        return $hasOk && !$hasFail;
    }
    return false;
}

function dmd_nas_dsm_package_install($item, $package, $extraValues = '', $volumeOverride = '') {
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];

    $meta = dmd_nas_dsm_cached_package($item, $package, true);
    $packageId = dmd_nas_dsm_package_id_from_meta($meta, $package);
    if ($packageId === '') { dmd_nas_dsm_logout($base, $sid); return [false, null, 'Installation impossible : identifiant paquet absent.']; }

    $extraJson = dmd_nas_dsm_extra_values_json($extraValues);
    if ($extraJson === null) { dmd_nas_dsm_logout($base, $sid); return [false, ['extra_invalid'=>true], 'extra_values doit être un objet JSON valide.']; }

    $liveInstalled = dmd_nas_dsm_live_installed_snapshot($base, $apiInfo, $sid);
    if (dmd_nas_dsm_pkg_in_list($meta ?: ['package_id'=>$packageId,'id'=>$packageId,'name'=>$packageId], $liveInstalled)) {
        dmd_nas_dsm_logout($base, $sid);
        return [true, ['already_installed'=>true,'package'=>$packageId], 'Paquet déjà installé : ' . $packageId . '.'];
    }

    $meta = dmd_nas_dsm_get_package_server_detail($base, $apiInfo, $sid, $packageId, $meta);
    $volume = trim((string)$volumeOverride);
    if ($volume === '') $volume = dmd_nas_dsm_default_volume($base, $apiInfo, $sid, $item);

    $url = dmd_nas_dsm_pkg_first($meta, ['link','url','download_url','remote_link']);
    $checksum = dmd_nas_dsm_pkg_first($meta, ['md5','checksum']);
    $filesize = dmd_nas_dsm_pkg_first($meta, ['size','filesize']);

    /* Package Center ne possède PAS de méthode "download" ici.
       Le téléchargement d'un paquet du catalogue démarre avec Installation.install
       + operation=install + type=0 + url/name/checksum/filesize. */
    if ($url === '') {
        [$srvOk, $srvData] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
            ['SYNO.Core.Package.Server', 'list', ['blforcereload'=>'false','blloadothers'=>'false']],
        ]);
        if ($srvOk) {
            $payload = $srvData['data'] ?? $srvData;
            foreach (($payload['packages'] ?? []) as $candidate) {
                if (!is_array($candidate)) continue;
                $cid = dmd_nas_dsm_package_id_from_meta($candidate, '');
                if ($cid !== '' && strcasecmp($cid, $packageId) === 0) {
                    $meta = array_replace_recursive($meta, $candidate);
                    $url = dmd_nas_dsm_pkg_first($meta, ['link','url','download_url','remote_link']);
                    $checksum = dmd_nas_dsm_pkg_first($meta, ['md5','checksum']);
                    $filesize = dmd_nas_dsm_pkg_first($meta, ['size','filesize']);
                    break;
                }
            }
        }
    }
    if ($url === '') {
        dmd_nas_dsm_logout($base, $sid);
        return [false, ['package'=>$packageId], "DSM n'a pas fourni l'URL SPK de " . $packageId . '. Recharge le catalogue puis réessaie.'];
    }

    $downloadParams = dmd_nas_dsm_params_clean([
        'operation'=>'install',
        'type'=>0,
        'blqinst'=>'false',
        'url'=>$url,
        'name'=>$packageId,
        'checksum'=>$checksum,
        'filesize'=>$filesize,
    ]);
    [$dlOk, $dlData, $dlMsg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.Package.Installation', 'install', $downloadParams],
    ]);
    if (!$dlOk || !is_array($dlData)) {
        dmd_nas_dsm_logout($base, $sid);
        return [false, ['package'=>$packageId,'download'=>$dlData],
            'DSM refuse le démarrage du téléchargement de ' . $packageId . '. ' . mb_substr((string)$dlMsg,0,600)];
    }

    [$chainOk, $chainData, $chainMsg] = dmd_nas_dsm_package_download_then_install($base, $apiInfo, $sid, $packageId, $dlData, $volume, $extraJson);
    dmd_nas_dsm_logout($base, $sid);
    return [$chainOk, $chainData, $chainMsg];
}

function dmd_nas_dsm_package_action($item, $package, $op, $extraValues = '', $volume = '') {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $package = trim((string)$package);
    $op = strtolower(trim((string)$op));
    if ($package === '') return [false, null, 'Identifiant paquet manquant.'];

    if ($op === 'install') {
        return dmd_nas_dsm_package_install($item, $package, $extraValues, $volume);
    }

    $methodSets = [
        'start' => ['start'],
        'stop' => ['stop'],
        'uninstall' => ['uninstall', 'remove'],
        'remove' => ['uninstall', 'remove'],
    ];
    if (!isset($methodSets[$op])) return [false, null, 'Action paquet inconnue.'];

    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];

    $meta = dmd_nas_dsm_cached_package($item, $package, false);
    $packageId = dmd_nas_dsm_package_id_from_meta($meta, $package);
    $tries = [];
    if ($op === 'uninstall' || $op === 'remove') {
        foreach ([['package_id'=>$packageId], ['package'=>$packageId], ['id'=>$packageId], ['packages'=>json_encode([$packageId])]] as $params) {
            foreach ($methodSets[$op] as $method) {
                $tries[] = ['SYNO.Core.Package.Uninstallation', $method, $params];
                $tries[] = ['SYNO.Core.Package', $method, $params];
            }
        }
    } else {
        foreach ([['package'=>$packageId], ['id'=>$packageId], ['package_id'=>$packageId], ['packages'=>json_encode([$packageId])]] as $params) {
            foreach ($methodSets[$op] as $method) {
                $tries[] = ['SYNO.Core.Package.Control', $method, $params];
                $tries[] = ['SYNO.Core.Package', $method, $params];
                $tries[] = ['SYNO.Package', $method, $params];
            }
        }
    }

    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    dmd_nas_dsm_logout($base, $sid);
    if (!$aok) {
        return [false, null, 'Action paquet refusée par DSM pour ' . $packageId . '. Codes : ' . (dmd_nas_dsm_codes_from_msg($msg) ?: 'inconnu') . '. Détail court : ' . mb_substr($msg, 0, 350)];
    }
    return [true, $data, 'Action paquet envoyée : ' . $op . ' ' . $packageId];
}
function dmd_nas_dsm_docker_center($item, $query = '') {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    $result = ['refreshed_at'=>date('Y-m-d H:i:s'), 'containers'=>[], 'images'=>[], 'registry'=>[], 'errors'=>[]];
    [$cok, $containers, $cerr] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Docker.Container','list',[]],
        ['SYNO.ContainerManager.Container','list',[]],
    ]);
    if ($cok) $result['containers'] = dmd_nas_extract_list($containers); else $result['errors']['containers'] = $cerr;
    [$iok, $images, $ierr] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Docker.Image','list',[]],
        ['SYNO.ContainerManager.Image','list',[]],
    ]);
    if ($iok) $result['images'] = dmd_nas_extract_list($images); else $result['errors']['images'] = $ierr;
    if (trim((string)$query) !== '') {
        [$rok, $reg, $rerr] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
            ['SYNO.Docker.Registry','search',['keyword'=>$query]],
            ['SYNO.Docker.Registry','search',['query'=>$query]],
            ['SYNO.ContainerManager.Registry','search',['keyword'=>$query]],
        ]);
        if ($rok) $result['registry'] = dmd_nas_extract_list($reg); else $result['errors']['registry'] = $rerr;
    }
    dmd_nas_dsm_logout($base, $sid);
    return [true, $result, count($result['containers']) . ' container(s), ' . count($result['images']) . ' image(s).'];
}
function dmd_nas_dsm_container_action($item, $container, $op) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $container = trim((string)$container); $op = strtolower(trim((string)$op));
    if ($container === '') return [false, null, 'Container manquant.'];
    $map = ['start'=>'start','stop'=>'stop','restart'=>'restart','delete'=>'delete','remove'=>'delete'];
    if (!isset($map[$op])) return [false, null, 'Action container inconnue.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    $method = $map[$op];
    $variants = [['id'=>$container], ['name'=>$container], ['container'=>$container]];
    $tries = [];
    foreach ($variants as $p) $tries[] = ['SYNO.Docker.Container', $method, $p];
    foreach ($variants as $p) $tries[] = ['SYNO.ContainerManager.Container', $method, $p];
    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    dmd_nas_dsm_logout($base, $sid);
    if (!$aok) return [false, null, 'Action container refusée/indisponible : ' . $msg];
    return [true, $data, 'Action container envoyée : ' . $op . ' ' . $container];
}

function dmd_nas_dsm_image_action($item, $image, $op) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $image = trim((string)$image); $op = strtolower(trim((string)$op));
    if ($image === '') return [false, null, 'Image Docker manquante.'];
    $map = ['pull'=>'download','download'=>'download','install'=>'download','delete'=>'delete','remove'=>'delete'];
    if (!isset($map[$op])) return [false, null, 'Action image inconnue.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    $method = $map[$op];
    $variants = [
        ['image'=>$image], ['name'=>$image], ['repo'=>$image], ['repository'=>$image], ['id'=>$image],
        ['image'=>$image, 'tag'=>'latest'], ['repository'=>$image, 'tag'=>'latest']
    ];
    $tries = [];
    foreach ($variants as $v) $tries[] = ['SYNO.Docker.Image', $method, $v];
    foreach ($variants as $v) $tries[] = ['SYNO.ContainerManager.Image', $method, $v];
    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    dmd_nas_dsm_logout($base, $sid);
    if (!$aok) return [false, null, 'Action image refusée/indisponible : ' . $msg];
    return [true, $data, 'Action image envoyée : ' . $op . ' ' . $image];
}

function dmd_nas_dsm_user_exists($base, $apiInfo, $sid, $user) {
    [$ok, $payload, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.User', 'list', []],
        ['SYNO.Core.User', 'enum', []],
    ]);
    if (!$ok) return false;
    $list = dmd_nas_extract_list($payload);
    foreach ($list as $u) {
        if (!is_array($u)) continue;
        $name = (string)($u['name'] ?? $u['username'] ?? $u['user'] ?? $u['uid'] ?? '');
        if ($name !== '' && strcasecmp($name, $user) === 0) return true;
    }
    return false;
}
function dmd_nas_dsm_user_action($item, $user, $op, $password = '') {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $user = trim((string)$user); $op = strtolower(trim((string)$op));
    if ($user === '') return [false, null, 'Utilisateur manquant.'];
    if ($op === 'create' && (string)$password === '') {
        return [false, null, 'Mot de passe utilisateur manquant : création non envoyée à DSM.'];
    }

    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];

    $tries = [];
    if ($op === 'create') {
        if (dmd_nas_dsm_user_exists($base, $apiInfo, $sid, $user)) {
            dmd_nas_dsm_logout($base, $sid);
            return [false, null, 'DSM indique que l’utilisateur existe déjà : ' . $user];
        }
        $params = [
            'name' => $user,
            'password' => (string)$password,
            'description' => 'Créé depuis DoMyDesk',
            'email' => '',
            'expire' => 'never',
            'expired' => 'normal',
            'cannot_chg_passwd' => 'false',
            'passwd_never_expire' => 'true',
            'notify_by_email' => 'false',
            'send_password' => 'false',
            'disallow_chpasswd' => 'false'
        ];
        $tries[] = ['SYNO.Core.User', 'create', $params];
        $tries[] = ['SYNO.Core.User', 'create', $params + ['groups' => json_encode(['users'])]];
        $tries[] = ['SYNO.Core.User', 'add', $params];
    } elseif ($op === 'delete' || $op === 'remove') {
        foreach ([['name'=>$user], ['user'=>$user], ['users'=>json_encode([$user])]] as $p) { $tries[] = ['SYNO.Core.User','delete',$p]; }
    } elseif ($op === 'disable') {
        foreach ([['name'=>$user,'disabled'=>'true'], ['name'=>$user,'enable'=>'false'], ['user'=>$user,'disabled'=>'true'], ['name'=>$user,'expired'=>'now']] as $p) { $tries[] = ['SYNO.Core.User','set',$p]; }
    } elseif ($op === 'enable') {
        foreach ([['name'=>$user,'disabled'=>'false'], ['name'=>$user,'enable'=>'true'], ['user'=>$user,'disabled'=>'false'], ['name'=>$user,'expire'=>'never']] as $p) { $tries[] = ['SYNO.Core.User','set',$p]; }
    } else {
        dmd_nas_dsm_logout($base, $sid); return [false, null, 'Action utilisateur inconnue : ' . $op];
    }

    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    if (!$aok && $op === 'create' && dmd_nas_dsm_user_exists($base, $apiInfo, $sid, $user)) {
        dmd_nas_dsm_logout($base, $sid);
        return [true, ['verified_by_list'=>true], 'Utilisateur créé confirmé par DSM : ' . $user . '. DSM a quand même renvoyé : ' . mb_substr($msg, 0, 550)];
    }
    dmd_nas_dsm_logout($base, $sid);
    if (!$aok) {
        $codes = function_exists('dmd_nas_dsm_codes_from_msg') ? (dmd_nas_dsm_codes_from_msg($msg) ?: 'aucun code') : 'aucun code';
        return [false, null, 'Action utilisateur refusée par DSM pour "' . $user . '". Opération : ' . $op . '. Codes DSM : ' . $codes . '. Réponse DSM : ' . mb_substr($msg, 0, 900)];
    }
    return [true, $data, 'DSM confirme l’action utilisateur : ' . $op . ' ' . $user];
}

function dmd_nas_dsm_share_name($share) {
    $share = trim((string)$share);
    $share = str_replace(['\\','/'], '-', $share);
    $share = preg_replace('/[\x00-\x1F\x7F]+/', '', $share);
    return trim($share);
}
function dmd_nas_dsm_perm_variants($permission) {
    $permission = strtolower(trim((string)$permission));
    if (in_array($permission, ['rw','readwrite','read_write','write','lecture/ecriture','lecture/écriture'], true)) {
        return ['read_write','readwrite','rw','2','3'];
    }
    if (in_array($permission, ['ro','readonly','read_only','read','lecture'], true)) {
        return ['read_only','readonly','ro','1'];
    }
    return ['no_access','noaccess','na','deny','0'];
}
function dmd_nas_dsm_extract_permissions($payload) {
    if (!is_array($payload)) return [];
    $data = $payload['data'] ?? $payload;
    foreach (['permissions','permission','privileges','privilege','acl','items','list','users','groups','shares','data'] as $k) {
        if (isset($data[$k]) && is_array($data[$k])) {
            if (dmd_nas_array_is_list_compat($data[$k])) return $data[$k];
            $flat = [];
            foreach ($data[$k] as $name => $v) {
                if (is_array($v)) { $v['name'] = $v['name'] ?? (string)$name; $flat[] = $v; }
                else $flat[] = ['name'=>(string)$name, 'permission'=>$v];
            }
            if ($flat) return $flat;
        }
    }
    if (dmd_nas_array_is_list_compat($data)) return $data;
    return [];
}

function dmd_nas_dsm_shares_list($item) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    [$ok,$base,$sid,$apiInfo,$err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false,null,$err];
    $tries = [
        ['SYNO.Core.Share','list',['offset'=>0,'limit'=>1000,'sort_by'=>'name','sort_direction'=>'ASC']],
        ['SYNO.Core.Share','list',[]],
        ['SYNO.Share','list',[]],
    ];
    [$aok,$data,$msg] = dmd_nas_dsm_try_methods($base,$apiInfo,$sid,$tries);
    dmd_nas_dsm_logout($base,$sid);
    if (!$aok) return [false,$data,'Lecture des partages DSM refusée : '.mb_substr($msg,0,900)];
    $payload = is_array($data) ? ($data['data'] ?? $data) : [];
    $shares=[];
    foreach (['shares','items','list','data'] as $k) {
        if (isset($payload[$k]) && is_array($payload[$k])) { $shares=$payload[$k]; break; }
    }
    if (!$shares && function_exists('dmd_nas_array_is_list_compat') && dmd_nas_array_is_list_compat($payload)) $shares=$payload;
    return [true,array_values(is_array($shares)?$shares:[]),'Partages DSM chargés.'];
}

function dmd_nas_dsm_share_action($item, $share, $op, $volume = '', $newName = '', $description = '') {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $share = dmd_nas_dsm_share_name($share);
    $op = strtolower(trim((string)$op));
    $newName = dmd_nas_dsm_share_name($newName);
    $volume = trim((string)$volume);
    $description = trim((string)$description);
    if ($share === '') return [false, null, 'Nom du partage manquant.'];
    if (!in_array($op, ['create','modify','edit','set','delete','remove'], true)) return [false, null, 'Action partage inconnue : ' . $op];

    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];

    $tries = [];
    if ($op === 'create') {
        // DSM 7.3.x: create attend un objet shareinfo JSON sur certaines builds.
        $shareinfo = ['name'=>$share, 'desc'=>$description, 'enable_acl'=>false, 'recycle_bin'=>true, 'recycle_bin_admin_only'=>false];
        if ($volume !== '') $shareinfo['vol_path'] = $volume;
        $tries[] = ['SYNO.Core.Share','create',[
            'name'=>json_encode($share, JSON_UNESCAPED_SLASHES),
            'shareinfo'=>json_encode($shareinfo, JSON_UNESCAPED_SLASHES)
        ]];
        $params = ['name'=>$share, 'desc'=>$description, 'description'=>$description, 'enable_acl'=>'false', 'recycle_bin'=>'true', 'recycle_bin_admin_only'=>'false'];
        if ($volume !== '') {
            $params['vol_path'] = $volume;
            $params['volume_path'] = $volume;
            $params['location'] = $volume;
        }
        $variants = [
            $params,
            array_filter(['name'=>$share, 'desc'=>$description, 'vol_path'=>$volume], static fn($v) => $v !== ''),
            array_filter(['name'=>$share, 'description'=>$description, 'volume_path'=>$volume], static fn($v) => $v !== ''),
            array_filter(['share_name'=>$share, 'desc'=>$description, 'vol_path'=>$volume], static fn($v) => $v !== ''),
        ];
        foreach ($variants as $p) {
            $tries[] = ['SYNO.Core.Share','create',$p];
            $tries[] = ['SYNO.Core.Share','add',$p];
            $tries[] = ['SYNO.Share','create',$p];
        }
    } elseif ($op === 'modify' || $op === 'edit' || $op === 'set') {
        $target = $newName !== '' ? $newName : $share;
        $variants = [
            ['name'=>$share, 'new_name'=>$target, 'desc'=>$description, 'description'=>$description],
            ['name'=>$share, 'share_name'=>$target, 'desc'=>$description],
            ['share'=>$share, 'new_name'=>$target, 'description'=>$description],
            ['old_name'=>$share, 'name'=>$target, 'desc'=>$description],
        ];
        foreach ($variants as $p) {
            $p = array_filter($p, static fn($v) => $v !== '');
            $tries[] = ['SYNO.Core.Share','set',$p];
            $tries[] = ['SYNO.Core.Share','edit',$p];
            $tries[] = ['SYNO.Share','set',$p];
        }
    } else {
        foreach ([['name'=>$share], ['share'=>$share], ['share_name'=>$share], ['shares'=>json_encode([$share], JSON_UNESCAPED_SLASHES)]] as $p) {
            $tries[] = ['SYNO.Core.Share','delete',$p];
            $tries[] = ['SYNO.Core.Share','remove',$p];
            $tries[] = ['SYNO.Share','delete',$p];
        }
    }

    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    dmd_nas_dsm_logout($base, $sid);
    if (!$aok) {
        $codes = function_exists('dmd_nas_dsm_codes_from_msg') ? (dmd_nas_dsm_codes_from_msg($msg) ?: 'aucun code') : 'aucun code';
        return [false, null, 'Action partage refusée par DSM pour "' . $share . '". Opération : ' . $op . '. Codes DSM : ' . $codes . '. Réponse DSM : ' . mb_substr($msg, 0, 900)];
    }
    $label = $op === 'create' ? 'créé' : (($op === 'delete' || $op === 'remove') ? 'supprimé' : 'modifié');
    return [true, $data, 'DSM confirme le partage ' . $label . ' : ' . ($newName !== '' ? $newName : $share)];
}
function dmd_nas_dsm_share_acl($item, $share) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $share = dmd_nas_dsm_share_name($share);
    if ($share === '') return [false, null, 'Nom du partage manquant.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    $tries = [
        ['SYNO.Core.Share.Permission','list',['name'=>$share]],
        ['SYNO.Core.Share.Permission','get',['name'=>$share]],
        ['SYNO.Core.Share.Permission','enum',['name'=>$share]],
        ['SYNO.Core.Share.Permission','list',['share'=>$share]],
        ['SYNO.Core.Share','get_permission',['name'=>$share]],
        ['SYNO.Core.Share','get_permission',['share'=>$share]],
    ];
    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    dmd_nas_dsm_logout($base, $sid);
    if (!$aok) return [false, null, 'Lecture des droits refusée par DSM pour "' . $share . '". Réponse DSM : ' . mb_substr($msg, 0, 800)];
    return [true, dmd_nas_dsm_extract_permissions($data), 'Droits chargés pour : ' . $share];
}
function dmd_nas_dsm_share_perm_action($item, $share, $principal, $principalType = 'user', $permission = 'read_only') {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $share = dmd_nas_dsm_share_name($share);
    $principal = trim((string)$principal);
    $principalType = strtolower(trim((string)$principalType)) === 'group' ? 'group' : 'user';
    if ($share === '') return [false, null, 'Nom du partage manquant.'];
    if ($principal === '') return [false, null, 'Utilisateur/groupe manquant pour les droits.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];

    $tries = [];
    foreach (dmd_nas_dsm_perm_variants($permission) as $perm) {
        $entry = ['name'=>$principal, 'type'=>$principalType, 'permission'=>$perm, 'privilege'=>$perm];
        $paramsList = [
            ['name'=>$share, 'user'=>$principal, 'type'=>$principalType, 'permission'=>$perm],
            ['name'=>$share, 'principal'=>$principal, 'principal_type'=>$principalType, 'permission'=>$perm],
            ['name'=>$share, 'target'=>$principal, 'target_type'=>$principalType, 'privilege'=>$perm],
            ['share'=>$share, 'permissions'=>json_encode([$entry], JSON_UNESCAPED_SLASHES)],
            ['name'=>$share, 'permissions'=>json_encode([$entry], JSON_UNESCAPED_SLASHES)],
            ['name'=>$share, $principalType === 'group' ? 'groups' : 'users'=>json_encode([[$principal=>$perm]], JSON_UNESCAPED_SLASHES)],
        ];
        foreach ($paramsList as $p) {
            $tries[] = ['SYNO.Core.Share.Permission','set',$p];
            $tries[] = ['SYNO.Core.Share.Permission','update',$p];
            $tries[] = ['SYNO.Core.Share','set_permission',$p];
        }
    }
    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    dmd_nas_dsm_logout($base, $sid);
    if (!$aok) return [false, null, 'Modification des droits refusée par DSM pour "' . $share . '". Réponse DSM : ' . mb_substr($msg, 0, 900)];
    return [true, $data, 'DSM confirme les droits : ' . $principal . ' sur ' . $share . ' = ' . $permission];
}

function dmd_nas_dsm_group_action($item, $group, $op, $description = '') {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $group = trim((string)$group); $op = strtolower(trim((string)$op));
    if ($group === '') return [false, null, 'Groupe manquant.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    $tries = [];
    if ($op === 'create') {
        $params = ['name'=>$group, 'description'=>(string)$description];
        $tries[] = ['SYNO.Core.Group', 'create', $params];
        $tries[] = ['SYNO.Core.Group', 'add', $params];
    } elseif ($op === 'delete' || $op === 'remove') {
        foreach ([['name'=>$group], ['group'=>$group], ['groups'=>json_encode([$group])]] as $p) { $tries[] = ['SYNO.Core.Group','delete',$p]; }
    } else {
        dmd_nas_dsm_logout($base, $sid); return [false, null, 'Action groupe inconnue.'];
    }
    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    dmd_nas_dsm_logout($base, $sid);
    if (!$aok) return [false, null, 'Action groupe refusée/indisponible : ' . $msg];
    return [true, $data, 'Action groupe envoyée : ' . $op . ' ' . $group];
}


function dmd_nas_dsm_flat_names($value) {
    $out = [];
    if (is_string($value)) {
        $parts = preg_split('/[;,\n]+/', $value);
        foreach ($parts as $p) { $p = trim($p, " \t\r\n\"'"); if ($p !== '') $out[] = $p; }
        return array_values(array_unique($out));
    }
    if (!is_array($value)) return [];
    foreach ($value as $k => $v) {
        if (is_string($v) || is_numeric($v)) {
            $vv = trim((string)$v);
            if ($vv !== '') $out[] = $vv;
        } elseif (is_array($v)) {
            foreach (['name','username','user','uid','group','groupname','gid'] as $field) {
                if (isset($v[$field]) && trim((string)$v[$field]) !== '') { $out[] = trim((string)$v[$field]); break; }
            }
        } elseif (is_string($k)) {
            $kk = trim((string)$k);
            if ($kk !== '') $out[] = $kk;
        }
    }
    return array_values(array_unique($out));
}
function dmd_nas_dsm_record_name($record, $fields) {
    if (!is_array($record)) return '';
    foreach ($fields as $f) if (isset($record[$f]) && trim((string)$record[$f]) !== '') return trim((string)$record[$f]);
    return '';
}
function dmd_nas_dsm_extract_records($payload, $keys) {
    if (!is_array($payload)) return [];
    $data = $payload['data'] ?? $payload;
    foreach ($keys as $k) {
        if (isset($data[$k]) && is_array($data[$k])) {
            return dmd_nas_array_is_list_compat($data[$k]) ? $data[$k] : array_values($data[$k]);
        }
    }
    foreach (['items','list','result','data'] as $k) {
        if (isset($data[$k]) && is_array($data[$k])) {
            return dmd_nas_array_is_list_compat($data[$k]) ? $data[$k] : array_values($data[$k]);
        }
    }
    if (dmd_nas_array_is_list_compat($data)) return $data;
    return is_array($data) ? [$data] : [];
}
function dmd_nas_dsm_extract_members_from_group_record($record) {
    if (!is_array($record)) return [];
    foreach (['members','member','users','user','user_list','member_list','usernames','accounts'] as $k) {
        if (array_key_exists($k, $record)) {
            $names = dmd_nas_dsm_flat_names($record[$k]);
            if ($names) return $names;
        }
    }
    return [];
}

function dmd_nas_dsm_extract_group_names_from_user_record($record) {
    if (!is_array($record)) return [];
    foreach (['groups','group','member_of','memberof','group_list','user_group','user_groups','groupname'] as $k) {
        if (array_key_exists($k, $record)) {
            $names = dmd_nas_dsm_flat_names($record[$k]);
            if ($names) return $names;
        }
    }
    return [];
}
function dmd_nas_dsm_user_groups_session($base, $apiInfo, $sid, $user) {
    $user = trim((string)$user);
    $tries = [
        ['SYNO.Core.User.Group','list',['user'=>$user]],
        ['SYNO.Core.User.Group','list',['name'=>$user]],
        ['SYNO.Core.User.Group','list',['username'=>$user]],
        ['SYNO.Core.User.Group','get',['user'=>$user]],
        ['SYNO.Core.User.Group','get',['name'=>$user]],
        ['SYNO.Core.User.Group','get',['username'=>$user]],
        ['SYNO.Core.User','get',['name'=>$user, 'additional'=>json_encode(['groups','group','member_of','memberof','group_list'], JSON_UNESCAPED_SLASHES)]],
        ['SYNO.Core.User','get',['user'=>$user, 'additional'=>json_encode(['groups','group','member_of','memberof','group_list'], JSON_UNESCAPED_SLASHES)]],
        ['SYNO.Core.User','list',['additional'=>json_encode(['groups','group','member_of','memberof','group_list'], JSON_UNESCAPED_SLASHES)]],
        ['SYNO.Core.User','list',[]],
    ];
    $lastMsg = '';
    foreach ($tries as $try) {
        [$ok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [$try]);
        if (!$ok) { $lastMsg = $msg; continue; }
        $records = dmd_nas_dsm_extract_records($data, ['groups','group','items','list','users','user']);
        $flat = [];
        foreach ($records as $rec) {
            if (is_array($rec)) {
                $uname = dmd_nas_dsm_record_name($rec, ['name','username','user','uid']);
                if ($uname !== '' && strcasecmp($uname, $user) !== 0) continue;
                $names = dmd_nas_dsm_extract_group_names_from_user_record($rec);
                if ($names) $flat = array_merge($flat, $names);
                else {
                    $g = dmd_nas_dsm_record_name($rec, ['group','groupname','name','gid']);
                    if ($g !== '' && strcasecmp($g, $user) !== 0) $flat[] = $g;
                }
            } else {
                $v = trim((string)$rec);
                if ($v !== '') $flat[] = $v;
            }
        }
        $flat = array_values(array_unique(array_filter($flat, static fn($v)=>trim((string)$v) !== '')));
        if ($flat) return [true, $flat, 'Groupes DSM chargés via SYNO.Core.User.Group.'];
        $direct = dmd_nas_dsm_flat_names($data['data']['groups'] ?? ($data['data']['group'] ?? null));
        if ($direct) return [true, $direct, 'Groupes DSM chargés via SYNO.Core.User.Group.'];
    }
    return [false, [], $lastMsg ?: 'DSM ne renvoie pas les groupes de cet utilisateur via WebAPI.'];
}

function dmd_nas_dsm_group_members_session($base, $apiInfo, $sid, $group) {
    $group = trim((string)$group);
    $tries = [
        ['SYNO.Core.Group.Member','list',['group'=>$group]],
        ['SYNO.Core.Group.Member','list',['name'=>$group]],
        ['SYNO.Core.Group.Member','list',['groupname'=>$group]],
        ['SYNO.Core.Group.Member','get',['group'=>$group]],
        ['SYNO.Core.Group.Member','get',['name'=>$group]],
        ['SYNO.Core.Group.Member','get',['groupname'=>$group]],
        ['SYNO.Core.Group','get',['name'=>$group, 'additional'=>json_encode(['members','member','users','user_list','member_list'], JSON_UNESCAPED_SLASHES)]],
        ['SYNO.Core.Group','get',['group'=>$group, 'additional'=>json_encode(['members','member','users','user_list','member_list'], JSON_UNESCAPED_SLASHES)]],
        ['SYNO.Core.Group','list',['additional'=>json_encode(['members','member','users','user_list','member_list'], JSON_UNESCAPED_SLASHES)]],
        ['SYNO.Core.Group','list',[]],
    ];
    $lastMsg = '';
    foreach ($tries as $try) {
        [$ok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [$try]);
        if (!$ok) { $lastMsg = $msg; continue; }
        $records = dmd_nas_dsm_extract_records($data, ['members','member','users','user','items','list','groups','group']);
        $flat = [];
        foreach ($records as $rec) {
            if (is_array($rec)) {
                $recName = dmd_nas_dsm_record_name($rec, ['name','group','groupname','gid']);
                if ($recName !== '' && strcasecmp($recName, $group) === 0) {
                    $names = dmd_nas_dsm_extract_members_from_group_record($rec);
                    if ($names) $flat = array_merge($flat, $names);
                    continue;
                }
                $userName = dmd_nas_dsm_record_name($rec, ['username','user','uid','account']);
                if ($userName !== '') $flat[] = $userName;
                else {
                    foreach (['members','member','users','user_list','member_list','accounts'] as $k) {
                        if (array_key_exists($k, $rec)) $flat = array_merge($flat, dmd_nas_dsm_flat_names($rec[$k]));
                    }
                }
            } else {
                $v = trim((string)$rec);
                if ($v !== '') $flat[] = $v;
            }
        }
        $flat = array_values(array_unique(array_filter($flat, static fn($v)=>trim((string)$v) !== '')));
        if ($flat) return [true, $flat, 'Membres DSM chargés via SYNO.Core.Group.Member.'];
        $direct = dmd_nas_dsm_flat_names($data['data']['members'] ?? ($data['data']['users'] ?? null));
        if ($direct) return [true, $direct, 'Membres DSM chargés via SYNO.Core.Group.Member.'];
    }
    return [false, [], $lastMsg ?: 'DSM ne renvoie pas les membres du groupe via WebAPI.'];
}

function dmd_nas_dsm_group_members($item, $group) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $group = trim((string)$group);
    if ($group === '') return [false, null, 'Groupe manquant.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    [$known, $members, $msg] = dmd_nas_dsm_group_members_session($base, $apiInfo, $sid, $group);
    dmd_nas_dsm_logout($base, $sid);
    return [true, ['group'=>$group, 'members'=>$members, 'known'=>$known], $known ? ('Membres chargés pour le groupe ' . $group . ' : ' . count($members)) : $msg];
}
function dmd_nas_dsm_user_groups($item, $user) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $user = trim((string)$user);
    if ($user === '') return [false, null, 'Utilisateur manquant.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];
    [$known, $groups, $msg] = dmd_nas_dsm_user_groups_session($base, $apiInfo, $sid, $user);
    dmd_nas_dsm_logout($base, $sid);
    return [true, ['user'=>$user, 'groups'=>array_values(array_unique($groups)), 'known'=>$known], $known ? ('Groupes chargés pour ' . $user . ' : ' . count($groups)) : $msg];
}

function dmd_nas_dsm_group_member_action($item, $group, $user, $op) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'API Synology non configurée.'];
    $group = trim((string)$group);
    $user = trim((string)$user);
    $op = strtolower(trim((string)$op));
    if ($group === '') return [false, null, 'Groupe manquant.'];
    if ($user === '') return [false, null, 'Utilisateur manquant.'];
    if (!in_array($op, ['add','remove','delete'], true)) return [false, null, 'Action membre inconnue : ' . $op];
    $remove = in_array($op, ['remove','delete'], true);
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, $err];

    /* Le rapport d'audit du DSM montre que SYNO.Core.Group.Member et SYNO.Core.User.Group
       sont exposées. On tente d'abord leurs actions directes, sans reconstruire une liste
       incomplète qui pourrait écraser les membres/groupes existants. */
    $directTries = [];
    $singleUser = json_encode([$user], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $singleGroup = json_encode([$group], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($remove) {
        foreach ([
            ['group'=>$group, 'user'=>$user], ['name'=>$group, 'user'=>$user], ['groupname'=>$group, 'user'=>$user],
            ['group'=>$group, 'users'=>$singleUser], ['name'=>$group, 'users'=>$singleUser],
            ['user'=>$user, 'group'=>$group], ['name'=>$user, 'group'=>$group], ['user'=>$user, 'groups'=>$singleGroup]
        ] as $p) {
            $directTries[] = ['SYNO.Core.Group.Member','delete',$p];
            $directTries[] = ['SYNO.Core.Group.Member','remove',$p];
            $directTries[] = ['SYNO.Core.User.Group','delete',$p];
            $directTries[] = ['SYNO.Core.User.Group','remove',$p];
        }
    } else {
        foreach ([
            ['group'=>$group, 'user'=>$user], ['name'=>$group, 'user'=>$user], ['groupname'=>$group, 'user'=>$user],
            ['group'=>$group, 'users'=>$singleUser], ['name'=>$group, 'users'=>$singleUser],
            ['user'=>$user, 'group'=>$group], ['name'=>$user, 'group'=>$group], ['user'=>$user, 'groups'=>$singleGroup]
        ] as $p) {
            $directTries[] = ['SYNO.Core.Group.Member','create',$p];
            $directTries[] = ['SYNO.Core.Group.Member','add',$p];
            $directTries[] = ['SYNO.Core.User.Group','create',$p];
            $directTries[] = ['SYNO.Core.User.Group','add',$p];
        }
    }
    [$directOk, $directData, $directMsg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $directTries);
    if ($directOk) {
        [$verifyKnown, $verifyMembers, $verifyMsg] = dmd_nas_dsm_group_members_session($base, $apiInfo, $sid, $group);
        dmd_nas_dsm_logout($base, $sid);
        if ($verifyKnown) {
            $present = false;
            foreach ($verifyMembers as $m) if (strcasecmp($m, $user) === 0) { $present = true; break; }
            if (!$remove && !$present) return [false, ['members'=>$verifyMembers], 'DSM a accepté l’action, mais ne confirme pas encore ' . $user . ' dans ' . $group . '. Relance Actualiser.'];
            if ($remove && $present) return [false, ['members'=>$verifyMembers], 'DSM a accepté l’action, mais indique encore ' . $user . ' dans ' . $group . '. Relance Actualiser.'];
        }
        return [true, ['group'=>$group,'user'=>$user,'op'=>$op,'members'=>$verifyMembers ?? [], 'direct'=>true], ($remove ? 'Utilisateur retiré du groupe : ' : 'Utilisateur ajouté au groupe : ') . $user . ' → ' . $group];
    }

    [$known, $members, $mmsg] = dmd_nas_dsm_group_members_session($base, $apiInfo, $sid, $group);
    $newMembers = $members;
    if ($known) {
        $exists = false;
        foreach ($newMembers as $m) if (strcasecmp($m, $user) === 0) { $exists = true; break; }
        if (!$remove && !$exists) $newMembers[] = $user;
        if ($remove) $newMembers = array_values(array_filter($newMembers, static fn($m) => strcasecmp((string)$m, $user) !== 0));
    } else {
        $newMembers = [$user];
    }

    $encoded = json_encode(array_values($newMembers), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $singleEncoded = json_encode([$user], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $tries = [];
    if ($known) {
        foreach ([
            ['name'=>$group, 'users'=>$encoded],
            ['name'=>$group, 'members'=>$encoded],
            ['name'=>$group, 'member'=>$encoded],
            ['group'=>$group, 'users'=>$encoded],
            ['groupname'=>$group, 'users'=>$encoded],
        ] as $p) {
            $tries[] = ['SYNO.Core.Group','set',$p];
            $tries[] = ['SYNO.Core.Group','edit',$p];
            $tries[] = ['SYNO.Core.Group.Member','set',$p];
        }
    }
    if ($remove) {
        foreach ([
            ['group'=>$group, 'user'=>$user], ['name'=>$group, 'user'=>$user], ['group'=>$group, 'users'=>$singleEncoded], ['name'=>$group, 'users'=>$singleEncoded]
        ] as $p) {
            $tries[] = ['SYNO.Core.Group.Member','delete',$p];
            $tries[] = ['SYNO.Core.Group.Member','remove',$p];
            $tries[] = ['SYNO.Core.Group','delete_member',$p];
            $tries[] = ['SYNO.Core.Group','remove_member',$p];
            $tries[] = ['SYNO.Core.Group','del_member',$p];
        }
    } else {
        foreach ([
            ['group'=>$group, 'user'=>$user], ['name'=>$group, 'user'=>$user], ['group'=>$group, 'users'=>$singleEncoded], ['name'=>$group, 'users'=>$singleEncoded]
        ] as $p) {
            $tries[] = ['SYNO.Core.Group.Member','create',$p];
            $tries[] = ['SYNO.Core.Group.Member','add',$p];
            $tries[] = ['SYNO.Core.Group','add_member',$p];
            $tries[] = ['SYNO.Core.Group','add_user',$p];
        }
    }
    // Fallback côté utilisateur : on essaye aussi de réécrire la liste des groupes de l'utilisateur.
    [$ugOk, $ugData, $_ugMsg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, [
        ['SYNO.Core.User','get',['name'=>$user]],
        ['SYNO.Core.User','get',['user'=>$user]],
    ]);
    $userGroups = [];
    if ($ugOk) {
        foreach (dmd_nas_dsm_extract_records($ugData, ['users','user']) as $u) {
            if (!is_array($u)) continue;
            foreach (['groups','group','member_of','memberof','group_list'] as $k) {
                if (array_key_exists($k, $u)) { $userGroups = dmd_nas_dsm_flat_names($u[$k]); break 2; }
            }
        }
    }
    if ($userGroups) {
        $hasGroup = false;
        foreach ($userGroups as $g) if (strcasecmp($g, $group) === 0) { $hasGroup = true; break; }
        if (!$remove && !$hasGroup) $userGroups[] = $group;
        if ($remove) $userGroups = array_values(array_filter($userGroups, static fn($g) => strcasecmp((string)$g, $group) !== 0));
        $ge = json_encode(array_values($userGroups), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        foreach ([['name'=>$user,'groups'=>$ge], ['name'=>$user,'group'=>$ge], ['user'=>$user,'groups'=>$ge]] as $p) {
            $tries[] = ['SYNO.Core.User','set',$p];
            $tries[] = ['SYNO.Core.User','edit',$p];
        }
    }

    [$aok, $data, $msg] = dmd_nas_dsm_try_methods($base, $apiInfo, $sid, $tries);
    if (!$aok) { dmd_nas_dsm_logout($base, $sid); return [false, null, 'DSM refuse la modification membre/groupe. Actions directes : ' . mb_substr($directMsg ?? '', 0, 450) . ' | Fallback : ' . mb_substr($msg, 0, 450)]; }
    [$verifyKnown, $verifyMembers, $verifyMsg] = dmd_nas_dsm_group_members_session($base, $apiInfo, $sid, $group);
    dmd_nas_dsm_logout($base, $sid);
    if ($verifyKnown) {
        $present = false;
        foreach ($verifyMembers as $m) if (strcasecmp($m, $user) === 0) { $present = true; break; }
        if (!$remove && !$present) return [false, ['members'=>$verifyMembers], 'Action envoyée mais DSM ne confirme pas que ' . $user . ' est dans ' . $group . '.'];
        if ($remove && $present) return [false, ['members'=>$verifyMembers], 'Action envoyée mais DSM indique encore ' . $user . ' dans ' . $group . '.'];
    }
    return [true, ['group'=>$group,'user'=>$user,'op'=>$op,'members'=>$verifyMembers ?? []], ($remove ? 'Utilisateur retiré du groupe : ' : 'Utilisateur ajouté au groupe : ') . $user . ' → ' . $group];
}

/**
 * Audit non destructif de ce que CE DSM expose réellement en WebAPI.
 * Ne crée, ne modifie et ne supprime rien. Le rapport est renvoyé au module
 * et sauvegardé dans modules/dmd_nas/data/debug/.
 */
function dmd_nas_dsm_audit_extract_error_code($data) {
    if (is_array($data) && isset($data['error']) && is_array($data['error']) && isset($data['error']['code'])) {
        return (string)$data['error']['code'];
    }
    return '';
}
function dmd_nas_dsm_audit_shape($data) {
    $out = ['success'=>!empty($data['success']), 'data_keys'=>[], 'list_count'=>null, 'sample_keys'=>[]];
    if (!is_array($data)) return $out;
    $payload = $data['data'] ?? $data;
    if (is_array($payload)) {
        $out['data_keys'] = array_slice(array_keys($payload), 0, 30);
        $list = dmd_nas_extract_list($data);
        if (is_array($list) && count($list)) {
            $out['list_count'] = count($list);
            if (is_array($list[0] ?? null)) $out['sample_keys'] = array_slice(array_keys($list[0]), 0, 40);
        }
    }
    return $out;
}
function dmd_nas_dsm_audit_meta($apiInfo, $apiName) {
    $meta = dmd_nas_dsm_pick_api($apiInfo, $apiName);
    if (!$meta) return null;
    return [
        'path' => (string)($meta['path'] ?? 'entry.cgi'),
        'minVersion' => $meta['minVersion'] ?? $meta['min_version'] ?? null,
        'maxVersion' => $meta['maxVersion'] ?? $meta['max_version'] ?? $meta['version'] ?? null,
        'requestFormat' => $meta['requestFormat'] ?? $meta['request_format'] ?? null
    ];
}
function dmd_nas_dsm_audit_run_call($base, $apiInfo, $sid, $label, $api, $method, $params = []) {
    $meta = dmd_nas_dsm_audit_meta($apiInfo, $api);
    if (!$meta) {
        return ['label'=>$label, 'api'=>$api, 'method'=>$method, 'available'=>false, 'ok'=>false, 'code'=>'API_ABSENTE', 'message'=>'API absente sur ce DSM'];
    }
    [$ok, $data, $err] = dmd_nas_dsm_call_api($base, $apiInfo, $api, $method, $params ?: [], $sid);
    $success = $ok && !empty($data['success']);
    $code = $success ? '' : (dmd_nas_dsm_audit_extract_error_code($data) ?: ($err !== '' ? 'ERREUR' : 'REFUS'));
    return [
        'label'=>$label,
        'api'=>$api,
        'method'=>$method,
        'available'=>true,
        'meta'=>$meta,
        'ok'=>$success,
        'code'=>$code,
        'code_label'=>$code !== '' && ctype_digit((string)$code) ? dmd_nas_dsm_code_label($code) : '',
        'message'=>$success ? 'OK' : ($err ?: 'DSM refuse ou ne renvoie pas success=true'),
        'shape'=>dmd_nas_dsm_audit_shape($data),
        'raw_error'=>(!$success && is_array($data)) ? ($data['error'] ?? null) : null
    ];
}
function dmd_nas_dsm_api_audit($item) {
    if (($item['api_type'] ?? 'none') !== 'synology') return [false, null, 'Audit DSM disponible uniquement pour Synology.'];
    [$ok, $base, $sid, $apiInfo, $err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false, null, 'Audit impossible : ' . $err];

    $apiData = $apiInfo['data'] ?? [];
    $apis = [];
    if (is_array($apiData)) {
        foreach ($apiData as $name => $meta) {
            if (!is_array($meta)) continue;
            $apis[$name] = [
                'path'=>(string)($meta['path'] ?? 'entry.cgi'),
                'minVersion'=>$meta['minVersion'] ?? $meta['min_version'] ?? null,
                'maxVersion'=>$meta['maxVersion'] ?? $meta['max_version'] ?? $meta['version'] ?? null,
                'requestFormat'=>$meta['requestFormat'] ?? $meta['request_format'] ?? null
            ];
        }
        ksort($apis, SORT_NATURAL | SORT_FLAG_CASE);
    }

    $tests = [
        ['system.info','SYNO.Core.System','info',[]],
        ['system.utilization','SYNO.Core.System.Utilization','get',[]],
        ['storage.load_info','SYNO.Storage.CGI.Storage','load_info',[]],
        ['network.get','SYNO.Core.Network','get',[]],
        ['packages.installed','SYNO.Core.Package','list',[]],
        ['packages.catalogue','SYNO.Core.Package.Server','list',[]],
        ['users.list','SYNO.Core.User','list',[]],
        ['groups.list','SYNO.Core.Group','list',[]],
        ['shares.list','SYNO.Core.Share','list',[]],
        ['services.list','SYNO.Core.Service','list',[]],
        ['docker.containers','SYNO.Docker.Container','list',[]],
        ['docker.images','SYNO.Docker.Image','list',[]],
        ['container_manager.containers','SYNO.ContainerManager.Container','list',[]],
        ['container_manager.images','SYNO.ContainerManager.Image','list',[]],
        ['task_scheduler.list','SYNO.Core.TaskScheduler','list',[]],
        ['permission.role.list','SYNO.Core.Permission.Role','list',[]],
        ['share.acl.list','SYNO.Core.Share.ACL','list',[]],
    ];

    $results = [];
    $success = [];
    $failed = [];
    $codes = [];
    foreach ($tests as $t) {
        [$label, $api, $method, $params] = $t;
        $r = dmd_nas_dsm_audit_run_call($base, $apiInfo, $sid, $label, $api, $method, $params);
        $results[$label] = $r;
        if (!empty($r['ok'])) $success[$label] = ['api'=>$api, 'method'=>$method, 'shape'=>$r['shape'] ?? []];
        else {
            $failed[$label] = ['api'=>$api, 'method'=>$method, 'code'=>$r['code'] ?? '', 'message'=>$r['message'] ?? ''];
            $c = (string)($r['code'] ?? '');
            if ($c !== '') $codes[$c] = ($codes[$c] ?? 0) + 1;
        }
    }

    $actionApis = [
        'package_installation' => ['SYNO.Core.Package.Installation','SYNO.Core.Package','SYNO.Package'],
        'package_control' => ['SYNO.Core.Package.Control','SYNO.Core.Package','SYNO.Package'],
        'user_write' => ['SYNO.Core.User'],
        'group_write' => ['SYNO.Core.Group'],
        'share_write' => ['SYNO.Core.Share'],
        'share_acl' => ['SYNO.Core.Share.ACL','SYNO.Core.Permission.Role'],
        'docker_write' => ['SYNO.Docker.Container','SYNO.ContainerManager.Container','SYNO.Docker.Image','SYNO.ContainerManager.Image']
    ];
    $capabilities = [];
    foreach ($actionApis as $cap => $names) {
        $capabilities[$cap] = [];
        foreach ($names as $name) $capabilities[$cap][$name] = dmd_nas_dsm_audit_meta($apiInfo, $name);
    }

    $systemData = $results['system.info']['ok'] ? ($results['system.info']['shape'] ?? []) : [];
    $report = [
        'generated_at'=>date('Y-m-d H:i:s'),
        'nas'=>[
            'name'=>(string)($item['name'] ?? ''),
            'id'=>(string)($item['id'] ?? ''),
            'vendor'=>'synology',
            'model'=>(string)($item['model'] ?? ''),
            'ip'=>(string)($item['ip'] ?? ''),
            'api_base'=>$base
        ],
        'api_count'=>count($apis),
        'apis_disponibles'=>$apis,
        'tests_reussis'=>$success,
        'tests_refuses'=>$failed,
        'codes_erreur'=>$codes,
        'methodes_valides'=>$results,
        'capacites_detectees'=>$capabilities,
        'notes'=>[
            'audit_non_destructif'=>true,
            'actions_create_delete_non_executees'=>true,
            'secret_api_exclu_du_rapport'=>true
        ]
    ];

    $dir = __DIR__ . '/data/debug';
    if (!is_dir($dir)) @mkdir($dir, 0775, true);
    $ht = $dir . '/.htaccess';
    if (!is_file($ht)) @file_put_contents($ht, "Require all denied\nDeny from all\n");
    $slug = function_exists('dmd_nas_slug') ? dmd_nas_slug(($item['name'] ?? $item['id'] ?? 'nas')) : preg_replace('/[^a-z0-9_-]+/i','-', (string)($item['name'] ?? 'nas'));
    $fileName = ($slug ?: 'nas') . '_api_audit_' . date('Ymd_His') . '.json';
    $file = $dir . '/' . $fileName;
    @file_put_contents($file, json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    $report['report_file'] = $file;
    $report['report_file_relative'] = 'modules/dmd_nas/data/debug/' . $fileName;

    dmd_nas_dsm_logout($base, $sid);
    return [true, $report, 'Audit DSM terminé : ' . count($apis) . ' API détectée(s), ' . count($success) . ' test(s) OK, ' . count($failed) . ' refus/absences.'];
}


/* ===== DMD-NAS administration DSM étendue ===== */
function dmd_nas_dsm_admin_probe($base, $apiInfo, $sid, $api, $method, $params = []) {
    if (!isset($apiInfo['data'][$api])) return [false, null, 'API absente : ' . $api];
    [$ok, $data, $err] = dmd_nas_dsm_call_api($base, $apiInfo, $api, $method, $params, $sid);
    if (!$ok || empty($data['success'])) return [false, $data, dmd_nas_dsm_error_one($api, $method, $data, (string)$err)];
    return [true, $data['data'] ?? $data, ''];
}
function dmd_nas_dsm_admin_first($base, $apiInfo, $sid, $tries) {
    $errors=[];
    foreach ($tries as $t) {
        [$api,$method,$params] = $t + [null,null,[]];
        [$ok,$data,$err] = dmd_nas_dsm_admin_probe($base,$apiInfo,$sid,$api,$method,$params ?: []);
        if ($ok) return [true,$data,$api.'.'.$method];
        $errors[]=$err;
    }
    return [false,null,implode(' | ',array_values(array_unique($errors)))];
}
function dmd_nas_dsm_admin_snapshot($item, $scope = 'system') {
    [$ok,$base,$sid,$apiInfo,$err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false,null,$err];
    $sections=[]; $errors=[];
    $probes = [
      'system' => [
        ['SYNO.Core.System','info',[]],
      ],
      'health' => [
        ['SYNO.Core.System.SystemHealth','get',[]],
        ['SYNO.Core.System','info',['type'=>'health']],
      ],
      'utilization' => [
        ['SYNO.Core.System.Utilization','get',[]],
      ],
      'storage' => [
        ['SYNO.Storage.CGI.Storage','load_info',[]],
      ],
      'storage_pools' => [
        ['SYNO.Core.Storage.Pool','list',[]],
      ],
      'storage_volumes' => [
        ['SYNO.Core.Storage.Volume','list',[]],
      ],
      'storage_disks' => [
        ['SYNO.Core.Storage.Disk','list',[]],
      ],
      'storage_smart' => [
        ['SYNO.Storage.CGI.Smart','list',[]],
        ['SYNO.Storage.CGI.Smart','get_health_info',[]],
      ],
      'network' => [
        ['SYNO.Core.System','info',['type'=>'network']],
      ],
      'network_interfaces' => [
        ['SYNO.Core.Network.Interface','get',[]],
        ['SYNO.Core.Network.Interface','list',[]],
      ],
      'network_gateways' => [
        ['SYNO.Core.Network.Router.Gateway.List','list',['ip_type'=>'ipv4','type'=>'wan']],
        ['SYNO.Core.Network.Router.Gateway.List','get',['ip_type'=>'ipv4','type'=>'wan']],
      ],
      'upgrade' => [
        ['SYNO.Core.Upgrade','status',[]],
        ['SYNO.Core.Upgrade.Server','check',[]],
      ],
      'upgrade_settings' => [
        ['SYNO.Core.Upgrade.Setting','get',[]],
      ],
      'certificates' => [
        ['SYNO.Core.Certificate','list',[]],
        ['SYNO.Core.Certificate','get',[]],
      ],
      'terminal' => [
        ['SYNO.Core.Terminal','get',[]],
      ],
      'tasks' => [
        ['SYNO.Core.TaskScheduler','list',['offset'=>0,'limit'=>200,'sort_by'=>'name','sort_direction'=>'ASC']],
      ],
      'notifications' => [
        ['SYNO.Core.DSMNotify','list',[]],
        ['SYNO.Core.DSMNotify','get',[]],
      ],
      'file_handles' => [
        ['SYNO.Core.FileHandle','list',['offset'=>0,'limit'=>100,'sort_by'=>'service','sort_direction'=>'ASC']],
      ],
      'ups' => [
        ['SYNO.Core.ExternalDevice.UPS','get',[]],
      ],
      'autoblock' => [
        ['SYNO.Core.Security.AutoBlock','get',[]],
        ['SYNO.Core.SmartBlock','get',[]],
      ],
      'firewall' => [
        ['SYNO.Core.Security.Firewall','get',[]],
        ['SYNO.Core.Firewall','get',[]],
      ],
    ];
    $scopeMap = [
      'system'=>['system','health','utilization','ups'],
      'storage'=>['storage','storage_pools','storage_volumes','storage_disks','storage_smart'],
      'network'=>['network','network_interfaces','network_gateways'],
      'updates'=>['upgrade','upgrade_settings'],
      'security'=>['terminal','certificates','autoblock','firewall'],
      'tasks'=>['tasks'],
      'activity'=>['notifications','file_handles'],
      'power'=>['system'],
    ];
    $wanted = $scopeMap[$scope] ?? $scopeMap['system'];
    foreach($probes as $key=>$tries){
        if (!in_array($key,$wanted,true)) continue;
        [$pok,$pdata,$pmsg]=dmd_nas_dsm_admin_first($base,$apiInfo,$sid,$tries);
        if($pok) $sections[$key]=$pdata; else $errors[$key]=$pmsg;
    }
    $sections['api_count']=is_array($apiInfo['data']??null)?count($apiInfo['data']):0;
    $sections['available_admin_apis']=array_values(array_filter(array_keys($apiInfo['data']??[]),function($n){
        return preg_match('/(Storage|Network|Upgrade|Certificate|Security|Firewall|Task|Log|Notify|System|Terminal|Backup|HyperBackup|FileHandle)/i',$n);
    }));
    dmd_nas_dsm_logout($base,$sid);
    return [true,['sections'=>$sections,'errors'=>$errors,'refreshed_at'=>date('Y-m-d H:i:s')],'Administration DSM chargée.'];
}
function dmd_nas_dsm_admin_action($item, $op, $args = []) {
    [$ok,$base,$sid,$apiInfo,$err] = dmd_nas_dsm_session($item);
    if (!$ok) return [false,null,$err];
    $tries=[]; $label='Action DSM';
    switch($op){
      case 'reboot':
        $label='Redémarrage';
        $tries=[['SYNO.Core.System','reboot',['local'=>true,'force'=>false]]]; break;
      case 'shutdown':
        $label='Arrêt';
        $tries=[['SYNO.Core.System','shutdown',['local'=>true,'force'=>false]]]; break;
      case 'ssh_enable':
      case 'ssh_disable':
        $label=($op==='ssh_enable'?'Activation':'Désactivation').' SSH';
        $port=max(1,min(65535,(int)($args['port']??22)));
        $tries=[['SYNO.Core.Terminal','set',['enable_ssh'=>$op==='ssh_enable','ssh_port'=>$port,'enable_telnet'=>false,'forbid_console'=>false]]]; break;
      case 'update_check':
        $label='Recherche de mise à jour';
        $tries=[['SYNO.Core.Upgrade.Server','check',[]],['SYNO.Core.Upgrade','status',[]]]; break;
      case 'task_run':
        $label='Exécution de tâche';
        $tid=(int)($args['task_id']??0); $owner=(string)($args['owner']??'root');
        $tasks=json_encode([['id'=>$tid,'real_owner'=>$owner]],JSON_UNESCAPED_SLASHES);
        $tries=[['SYNO.Core.TaskScheduler','run',['tasks'=>$tasks]]]; break;
      case 'task_enable':
      case 'task_disable':
        $label=($op==='task_enable'?'Activation':'Désactivation').' de tâche';
        $tid=(int)($args['task_id']??0); $owner=(string)($args['owner']??'root');
        $status=json_encode([['id'=>$tid,'real_owner'=>$owner,'enable'=>$op==='task_enable']],JSON_UNESCAPED_SLASHES);
        $tries=[['SYNO.Core.TaskScheduler','set_enable',['status'=>$status]]]; break;
      case 'storage_pool_desc':
        $label='Description du pool';
        $tries=[['SYNO.Core.Storage.Pool','set',['pool_id'=>(string)($args['pool_id']??''),'description'=>(string)($args['description']??'')]]]; break;
      case 'storage_volume_desc':
        $label='Description du volume';
        $tries=[['SYNO.Core.Storage.Volume','set',['volume_path'=>(string)($args['volume_path']??''),'description'=>(string)($args['description']??'')]]]; break;
      case 'storage_disk_fw':
        $label='Mise à jour firmware disque';
        $tries=[['SYNO.Core.Storage.Disk.FWUpgrade','start',['disk_id'=>(string)($args['disk_id']??'')]]]; break;
      case 'storage_scrub':
        $label='Nettoyage des données';
        $tries=[['SYNO.Storage.CGI.Check','do_data_scrubbing',[]]]; break;
      case 'storage_scan':
        $label='Analyse des disques';
        $tries=[['SYNO.Storage.CGI.Check','do_disk_scan',[]]]; break;
      case 'update_smart_nano_on':
      case 'update_smart_nano_off':
        $label='Réglage des mises à jour intelligentes';
        $tries=[['SYNO.Core.Upgrade.Setting','set',['enabled'=>$op==='update_smart_nano_on','smart_nano_enabled'=>$op==='update_smart_nano_on']]]; break;
      case 'hibernation_set':
        $label='Réglage hibernation';
        $tries=[['SYNO.Core.Hardware.Hibernation','set',['internal_hd_idletime'=>(int)($args['internal_hd_idletime']??0),'usb_idletime'=>(int)($args['usb_idletime']??0)]]]; break;
      case 'task_delete':
        $label='Suppression de tâche';
        $tid=(int)($args['task_id']??0); $owner=(string)($args['owner']??'root');
        $tasks=json_encode([['id'=>$tid,'real_owner'=>$owner]],JSON_UNESCAPED_SLASHES);
        $tries=[['SYNO.Core.TaskScheduler','delete',['tasks'=>$tasks]]]; break;
      case 'task_create':
        $label='Création de tâche';
        $name=trim((string)($args['name']??'')); $owner=trim((string)($args['owner']??'root')); $script=(string)($args['script']??'');
        if($name==='' || trim($script)===''){ dmd_nas_dsm_logout($base,$sid); return [false,null,'Nom et script obligatoires.']; }
        $time=(string)($args['time']??'03:00'); $tp=explode(':',$time,2); $hh=max(0,min(23,(int)($tp[0]??3))); $mm=max(0,min(59,(int)($tp[1]??0)));
        $schedule=['run_frequently'=>true,'run_days'=>'0,1,2,3,4,5,6','run_date'=>'','repeat'=>'daily','monthly_week'=>[],'start_time_h'=>$hh,'start_time_m'=>$mm,'same_day_repeat_h'=>0,'same_day_repeat_m'=>0,'same_day_repeat_until'=>-1];
        $extra=['notify_enable'=>false,'notify_mail'=>'','notify_if_error'=>false,'script'=>$script];
        $params=['name'=>$name,'real_owner'=>$owner,'owner'=>$owner,'enable'=>true,'schedule'=>json_encode($schedule,JSON_UNESCAPED_SLASHES),'extra'=>json_encode($extra,JSON_UNESCAPED_SLASHES),'type'=>'script'];
        $tries=[['SYNO.Core.TaskScheduler','create',$params]];
        if($owner==='root') $tries[]=['SYNO.Core.TaskScheduler.Root','create',$params];
        break;
      case 'network_general_set':
        $label='Configuration réseau générale';
        $hostname=trim((string)($args['hostname']??'')); $workgroup=trim((string)($args['workgroup']??''));
        $dns=array_values(array_filter(array_map('trim',explode(',',(string)($args['dns']??'')))));
        $params=[]; if($hostname!=='') $params['hostname']=$hostname; if($workgroup!=='') $params['workgroup']=$workgroup; if($dns) $params['dns']=json_encode($dns,JSON_UNESCAPED_SLASHES);
        $tries=[['SYNO.Core.Network','set',$params],['SYNO.Core.System','set',$params]]; break;
      case 'network_interface_set':
        $label='Configuration interface réseau';
        $ifid=trim((string)($args['interface']??''));
        if($ifid===''){ dmd_nas_dsm_logout($base,$sid); return [false,null,'Interface réseau manquante.']; }
        $dhcp=!empty($args['dhcp']); $mtu=max(0,(int)($args['mtu']??0));
        $params=['id'=>$ifid,'ifname'=>$ifid,'interface'=>$ifid,'use_dhcp'=>$dhcp,'dhcp'=>$dhcp];
        if(!$dhcp){ foreach(['address'=>'address','netmask'=>'netmask','gateway'=>'gateway'] as $ak=>$pk){ $v=trim((string)($args[$ak]??'')); if($v!=='')$params[$pk]=$v; } }
        if($mtu>0)$params['mtu']=$mtu;
        $tries=[['SYNO.Core.Network.Interface','set',$params],['SYNO.Core.Network.Interface','update',$params],['SYNO.Core.Network.Interface','edit',$params]]; break;
      case 'storage_pool_create':
        $label='Création pool de stockage';
        $raid=trim((string)($args['raid_type']??'shr')); $disks=array_values(array_filter(array_map('trim',explode(',',(string)($args['disks']??'')))));
        if(!$disks){ dmd_nas_dsm_logout($base,$sid); return [false,null,'Indique au moins un disque pour créer le pool.']; }
        $params=['raid_type'=>$raid,'type'=>$raid,'disks'=>json_encode($disks,JSON_UNESCAPED_SLASHES),'disk_ids'=>json_encode($disks,JSON_UNESCAPED_SLASHES)];
        $tries=[['SYNO.Core.Storage.Pool','create',$params],['SYNO.Storage.CGI.Storage','create_pool',$params]]; break;
      case 'storage_pool_delete':
        $label='Suppression pool de stockage';
        $pid=trim((string)($args['pool_id']??'')); if($pid===''){ dmd_nas_dsm_logout($base,$sid); return [false,null,'Pool manquant.']; }
        $tries=[['SYNO.Core.Storage.Pool','delete',['pool_id'=>$pid]],['SYNO.Core.Storage.Pool','remove',['pool_id'=>$pid]],['SYNO.Storage.CGI.Storage','delete_pool',['pool_id'=>$pid]]]; break;
      case 'storage_volume_create':
        $label='Création volume';
        $pid=trim((string)($args['pool_id']??'')); $fs=trim((string)($args['fs_type']??'btrfs')); $size=trim((string)($args['size']??''));
        if($pid===''){ dmd_nas_dsm_logout($base,$sid); return [false,null,'Pool de destination manquant.']; }
        $params=['pool_id'=>$pid,'fs_type'=>$fs,'filesystem'=>$fs]; if($size!==''){$params['size']=$size;$params['volume_size']=$size;}
        $tries=[['SYNO.Core.Storage.Volume','create',$params],['SYNO.Storage.CGI.Storage','create_volume',$params]]; break;
      case 'storage_volume_delete':
        $label='Suppression volume';
        $vp=trim((string)($args['volume_path']??'')); if($vp===''){ dmd_nas_dsm_logout($base,$sid); return [false,null,'Volume manquant.']; }
        $tries=[['SYNO.Core.Storage.Volume','delete',['volume_path'=>$vp]],['SYNO.Core.Storage.Volume','remove',['volume_path'=>$vp]],['SYNO.Storage.CGI.Storage','delete_volume',['volume_path'=>$vp]]]; break;
      case 'task_edit':
        $label='Modification de tâche';
        $tid=(int)($args['task_id']??0); $owner=trim((string)($args['owner']??'root')); $name=trim((string)($args['name']??'')); $script=(string)($args['script']??'');
        $time=(string)($args['time']??'03:00'); $tp=explode(':',$time,2); $hh=max(0,min(23,(int)($tp[0]??3))); $mm=max(0,min(59,(int)($tp[1]??0)));
        $schedule=['run_frequently'=>true,'run_days'=>'0,1,2,3,4,5,6','repeat'=>'daily','start_time_h'=>$hh,'start_time_m'=>$mm,'same_day_repeat_h'=>0,'same_day_repeat_m'=>0,'same_day_repeat_until'=>-1];
        $extra=['notify_enable'=>false,'notify_mail'=>'','notify_if_error'=>false,'script'=>$script];
        $params=['id'=>$tid,'task_id'=>$tid,'real_owner'=>$owner,'owner'=>$owner,'name'=>$name,'schedule'=>json_encode($schedule,JSON_UNESCAPED_SLASHES),'extra'=>json_encode($extra,JSON_UNESCAPED_SLASHES),'type'=>'script'];
        $tries=[['SYNO.Core.TaskScheduler','set',$params],['SYNO.Core.TaskScheduler','edit',$params],['SYNO.Core.TaskScheduler','update',$params]]; break;
      default:
        dmd_nas_dsm_logout($base,$sid); return [false,null,'Action DSM avancée inconnue : '.$op];
    }
    [$aok,$data,$amsg]=dmd_nas_dsm_admin_first($base,$apiInfo,$sid,$tries);
    dmd_nas_dsm_logout($base,$sid);
    if(!$aok) return [false,$data,$label.' refusé : '.$amsg];
    return [true,$data,$label.' envoyé à DSM.'];
}
