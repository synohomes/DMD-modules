<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/dmd_nas_lib.php';
dmd_nas_boot_core();
dmd_nas_boot_storage();
dmd_nas_require('module.view');
$csrf = dmd_nas_csrf_token();
$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/dmd-nas';
if ($documentRoot !== '' && strpos($moduleRealDir, $documentRoot) === 0) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot))), '/');
}
$apiUrl = rtrim($moduleWebPath, '/') . '/dmd_nas_api.php';
$fullUrl = rtrim($moduleWebPath, '/') . '/dmd_nas.php';
$uid = 'dmdNasMyDesk_' . substr(md5(__DIR__ . microtime(true)), 0, 8);
?>
<div class="dmdnas-mydesk" id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>" data-api="<?= htmlspecialchars($apiUrl, ENT_QUOTES, 'UTF-8') ?>" data-full="<?= htmlspecialchars($fullUrl, ENT_QUOTES, 'UTF-8') ?>" data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
  <header class="dmdnas-mydesk-head">
    <div class="dmdnas-mydesk-title"><img src="<?= htmlspecialchars(rtrim($moduleWebPath,'/') . '/icon.png', ENT_QUOTES, 'UTF-8') ?>" alt=""><div><strong>NAS</strong><small>Mes équipements</small></div></div>
    <button type="button" data-reload title="Actualiser">↻</button>
  </header>
  <div class="dmdnas-mydesk-status" data-status>Chargement…</div>
  <main class="dmdnas-mydesk-list" data-list></main>
  <footer class="dmdnas-mydesk-foot"><button type="button" data-open-full>Ouvrir la version complète</button></footer>
</div>
<script>
(function(){
  const root=document.getElementById(<?= json_encode($uid) ?>); if(!root||root.dataset.ready==='1')return; root.dataset.ready='1';
  const api=root.dataset.api, list=root.querySelector('[data-list]'), status=root.querySelector('[data-status]');
  const esc=v=>String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
  function msg(t,ok){status.textContent=t||''; status.dataset.ok=ok?'1':'0';}
  async function call(action,item){
    const b=new URLSearchParams(); b.set('action',action); b.set('csrf',root.dataset.csrf||'');
    if(item){b.set('id',item.id||''); b.set('vendor',item.vendor||'other'); b.set('storage_mode','private');}
    const r=await fetch(api,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:b});
    const txt=await r.text(); let j; try{j=JSON.parse(txt)}catch(e){throw new Error(txt.slice(0,180)||'Réponse API invalide');} if(!j.ok)throw new Error(j.message||'Erreur API'); return j;
  }
  function render(items){
    if(!items.length){list.innerHTML='<div class="dmdnas-mydesk-empty">Aucun NAS enregistré.</div>';return;}
    list.innerHTML=items.map(i=>`<article class="dmdnas-mydesk-card" data-id="${esc(i.id)}" data-vendor="${esc(i.vendor)}">
      <div class="dmdnas-mydesk-cardtop"><div><strong>${esc(i.name||'NAS')}</strong><small>${esc(i.vendor_label||i.vendor||'NAS')} · ${esc(i.ip||i.hostname||'-')}</small></div><span class="dmdnas-state ${i.last_status==='online'?'on':i.last_status==='offline'?'off':'unknown'}">${i.last_status==='online'?'En ligne':i.last_status==='offline'?'Hors ligne':'Non testé'}</span></div>
      <div class="dmdnas-mydesk-actions">
        <button data-action="test">Tester</button><button data-action="scan">Scanner</button><button data-action="dsm_refresh">Actualiser</button>${i.admin_url?'<button data-action="admin">Admin</button>':''}
      </div>
    </article>`).join('');
  }
  async function load(){try{msg('Chargement…',true);const r=await fetch(api+'?action=list',{credentials:'same-origin'});const txt=await r.text();let j;try{j=JSON.parse(txt)}catch(e){throw new Error(txt.slice(0,180)||'Réponse API invalide')}if(!j.ok)throw new Error(j.message||'Erreur');render(Array.isArray(j.items)?j.items:[]);msg('Prêt',true);}catch(e){msg(e.message,false);list.innerHTML='';}}
  root.addEventListener('click',async e=>{
    const b=e.target.closest('button'); if(!b)return;
    if(b.matches('[data-reload]')){load();return;}
    if(b.matches('[data-open-full]')){window.open(root.dataset.full,'_blank','noopener');return;}
    const card=b.closest('.dmdnas-mydesk-card'); if(!card)return;
    const id=card.dataset.id,vendor=card.dataset.vendor; const r=await fetch(api+'?action=list',{credentials:'same-origin'}); const j=await r.json(); const item=(j.items||[]).find(x=>x.id===id&&x.vendor===vendor); if(!item)return;
    let act=b.dataset.action;
    if(act==='dsm_refresh' && item.vendor==='qnap') act='qnap_refresh';
    if(act==='admin'){if(item.admin_url)window.open(item.admin_url,'_blank','noopener');return;}
    try{b.disabled=true;msg('Action en cours…',true);const out=await call(act,item);msg(out.message||'OK',true);await load();}catch(err){msg(err.message,false)}finally{b.disabled=false;}
  });
  load();
})();
</script>
