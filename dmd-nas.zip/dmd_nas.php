<?php
/**
 * DoMyDesk - dmd_nas.php
 * Interface dashboard NAS.
 * UX demandée : vignettes constructeur -> liste NAS -> fiche NAS en popup indépendante. V50 : erreurs DSM nettoyées, détails humains.
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/dmd_nas_lib.php';
dmd_nas_boot_core();
dmd_nas_boot_storage();
dmd_nas_require('module.view');
$csrf = dmd_nas_csrf_token();
$dmdNasPermissions = dmd_nas_permissions_snapshot();

$vendors = [
    'synology' => 'Synology',
    'qnap' => 'QNAP',
    'asustor' => 'ASUSTOR',
    'truenas' => 'TrueNAS',
    'omv' => 'OpenMediaVault',
    'other' => 'Autre'
];

function dmd_nas_ui_email(): string {
    return trim((string)($_SESSION['email'] ?? $_SESSION['user_email'] ?? ($_SESSION['user']['email'] ?? '')));
}
function dmd_nas_ui_is_admin(): bool {
    $rs = strtolower((string)($_SESSION['role_system'] ?? ($_SESSION['user']['role_system'] ?? '')));
    $r = strtolower((string)($_SESSION['role'] ?? ($_SESSION['user']['role'] ?? '')));
    return in_array($rs, ['admin','administrator','superadmin'], true) || in_array($r, ['admin','administrator','superadmin'], true);
}
function dmd_nas_ui_slug($v): string {
    $v = trim((string)$v);
    $v = str_replace(['\\','/','..'], '-', $v);
    $v = preg_replace('/[^a-zA-Z0-9_\-.]+/', '-', $v);
    return strtolower(trim((string)$v, '-_.'));
}
function dmd_nas_ui_vendor($v, array $vendors): string {
    $v = strtolower(trim((string)$v));
    return isset($vendors[$v]) ? $v : 'other';
}
function dmd_nas_ui_root(): string {
    $root = realpath(__DIR__ . '/../..');
    return $root ?: dirname(__DIR__, 2);
}
function dmd_nas_ui_storage_root(string $storage, ?string $email = null): ?string {
    $email = $email ?: dmd_nas_ui_email();
    return $email !== '' ? dmd_nas_ui_root() . '/users/profiles/' . $email . '/dmd_nas' : null;
}
function dmd_nas_ui_read_file(string $file, string $storage, string $vendor, array $vendors): ?array {
    $json = json_decode((string)@file_get_contents($file), true);
    if (!is_array($json)) return null;
    $json['id'] = dmd_nas_ui_slug($json['id'] ?? pathinfo($file, PATHINFO_FILENAME));
    if ($json['id'] === '') return null;
    $json['vendor'] = dmd_nas_ui_vendor($json['vendor'] ?? $vendor, $vendors);
    $json['vendor_label'] = $vendors[$json['vendor']] ?? 'Autre';
    $json['storage_mode'] = 'private';
    $json['enabled'] = array_key_exists('enabled', $json) ? (bool)$json['enabled'] : true;
    $json['api_password_saved'] = !empty($json['api_pass_enc']) || !empty($json['api_pass']);
    unset($json['api_pass'], $json['api_pass_enc']);
    return $json;
}
function dmd_nas_ui_collect_items(array $vendors): array {
    $items = [];
    $seen = [];
    $roots = [];
    $private = dmd_nas_ui_storage_root('private');
    if ($private) $roots[] = ['private', $private];
    foreach ($roots as [$storage, $root]) {
        if (!$root || !is_dir($root)) continue;
        foreach ($vendors as $vendor => $_label) {
            $dir = $root . '/' . $vendor;
            if (!is_dir($dir)) continue;
            foreach (glob($dir . '/*.json') ?: [] as $file) {
                $key = realpath($file) ?: $file;
                if (isset($seen[$key])) continue;
                $seen[$key] = true;
                $item = dmd_nas_ui_read_file($file, $storage, $vendor, $vendors);
                if ($item) $items[] = $item;
            }
        }
    }
    usort($items, static fn($a, $b) => strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? '')));
    return $items;
}

$items = dmd_nas_ui_collect_items($vendors);
$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$moduleRealDir = realpath(__DIR__) ?: __DIR__;
$moduleWebPath = '/modules/dmd-nas';
if ($documentRoot !== '' && strpos($moduleRealDir, $documentRoot) === 0) {
    $moduleWebPath = '/' . ltrim(str_replace('\\', '/', substr($moduleRealDir, strlen($documentRoot))), '/');
}
$apiUrl = rtrim($moduleWebPath, '/') . '/dmd_nas_api.php';
$uid = 'dmdNasCtl_' . substr(md5(__DIR__ . microtime(true)), 0, 8);
?>
<div class="dmdnasctl" id="<?= htmlspecialchars($uid, ENT_QUOTES, 'UTF-8') ?>" data-api="<?= htmlspecialchars($apiUrl, ENT_QUOTES, 'UTF-8') ?>" data-csrf="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
    <div class="dmdnasctl-head">
        <div>
            <h3>NAS</h3>
            <p>Constructeurs, NAS enregistrés et gestion depuis le dashboard.</p>
        </div>
        <button type="button" class="dmdnasctl-icon" data-refresh-list title="Rafraîchir">↻</button>
    </div>
    <div class="dmdnasctl-vendors" data-vendors></div>
    <p class="dmdnasctl-msg" data-main-msg></p>
</div>

<script>
(function(){
    const root = document.getElementById(<?= json_encode($uid) ?>);
    if (!root || root.dataset.ready === '1') return;
    root.dataset.ready = '1';

    const apiUrl = root.dataset.api || '';
    const csrf = root.dataset.csrf || '';
    const permissions = <?= json_encode($dmdNasPermissions, JSON_UNESCAPED_UNICODE) ?>;
    const vendors = <?= json_encode($vendors, JSON_UNESCAPED_UNICODE) ?>;
    let items = <?= json_encode($items, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    let openVendor = null;
    let zIndex = 9000;

    const vendorsBox = root.querySelector('[data-vendors]');
    const mainMsg = root.querySelector('[data-main-msg]');

    const css = document.createElement('style');
    css.textContent = `
#${root.id}.dmdnasctl{box-sizing:border-box;padding:10px;min-width:220px;width:100%;height:100%;max-height:100%;color:var(--text-color,inherit);background:transparent;overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable}
#${root.id} *{box-sizing:border-box}
#${root.id} h3,#${root.id} p{margin:0}
#${root.id} h3{font-size:1.18em;font-weight:900;letter-spacing:.02em;color:var(--title-color,var(--primary-color,inherit))}
#${root.id} p{color:var(--muted-color,inherit);opacity:1;margin-top:3px;font-size:.92em}
#${root.id} button,#${root.id} input,#${root.id} select{font:inherit;color:var(--text-color,inherit)}
#${root.id} .dmdnasctl-head{position:sticky;top:0;z-index:3;display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:8px;padding-bottom:6px;background:var(--section-bg,var(--background-color,transparent))}
#${root.id} .dmdnasctl-icon{width:36px;height:36px;border:1px solid var(--border-color,currentColor);border-radius:999px;background:var(--button-bg,var(--panel-bg,transparent));cursor:pointer;font-weight:900}
#${root.id} .dmdnasctl-icon:hover{background:var(--button-hover,var(--primary-soft,var(--card-bg,transparent)))}
#${root.id} .dmdnasctl-vendors{display:grid;gap:9px}
#${root.id} .dmdnasctl-brand{border:1px solid var(--border-color,currentColor);border-radius:var(--radius,12px);background:var(--card-bg,var(--section-bg,transparent));overflow:hidden}
#${root.id} .dmdnasctl-brandBtn{width:100%;border:0;background:transparent;color:var(--text-color,inherit);padding:11px 12px;display:grid;grid-template-columns:1fr auto;gap:8px;align-items:center;text-align:left;cursor:pointer}
#${root.id} .dmdnasctl-brandBtn:hover{background:var(--primary-soft,var(--panel-bg,transparent))}
#${root.id} .dmdnasctl-brandName{font-weight:900;display:flex;align-items:center;gap:8px;color:var(--title-color,var(--text-color,inherit))}
#${root.id} .dmdnasctl-brandSub{color:var(--muted-color,inherit);opacity:1;font-size:.84em;margin-top:3px}
#${root.id} .dmdnasctl-count{min-width:34px;height:30px;border:1px solid var(--border-color,currentColor);border-radius:999px;display:inline-flex;align-items:center;justify-content:center;font-weight:900;background:var(--panel-bg,transparent)}
#${root.id} .dmdnasctl-list{display:none;border-top:1px solid var(--border-color,currentColor);padding:9px;gap:7px;background:var(--section-bg,transparent)}
#${root.id} .dmdnasctl-brand.is-open .dmdnasctl-list{display:grid}
#${root.id} .dmdnasctl-nasRow{width:100%;border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);background:var(--panel-bg,var(--card-bg,transparent));padding:9px 10px;display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;text-align:left;cursor:pointer;color:var(--text-color,inherit)}
#${root.id} .dmdnasctl-nasRow:hover{background:var(--primary-soft,var(--card-bg,transparent))}
#${root.id} .dmdnasctl-nasTitle{font-weight:850;line-height:1.15;word-break:break-word}
#${root.id} .dmdnasctl-nasMeta{color:var(--muted-color,inherit);opacity:1;font-size:.82em;margin-top:2px;word-break:break-word}
#${root.id} .dmdnasctl-pill{border:1px solid var(--border-color,currentColor);border-radius:999px;padding:4px 8px;font-size:.78em;white-space:nowrap;display:inline-flex;align-items:center;gap:6px;background:var(--card-bg,transparent)}
#${root.id} .dmdnasctl-pill::before{content:'';width:7px;height:7px;border-radius:99px;background:currentColor;opacity:.35}
#${root.id} .dmdnasctl-pill.online{color:var(--success-color,inherit);border-color:var(--success-color,var(--border-color,currentColor))}
#${root.id} .dmdnasctl-pill.online::before{opacity:1}
#${root.id} .dmdnasctl-empty{color:var(--muted-color,inherit);opacity:1;padding:9px 3px;font-size:.9em}
#${root.id} .dmdnasctl-msg{min-height:20px;margin-top:10px;font-weight:700;font-size:.88em;color:var(--muted-color,inherit)}
.dmdnas-win{position:absolute;z-index:9000;width:min(760px,calc(100vw - 28px));min-width:300px;min-height:240px;max-height:min(760px,calc(100vh - 26px));resize:both;overflow:auto;overscroll-behavior:contain;border:1px solid var(--border-color,currentColor);border-radius:var(--radius,12px);box-shadow:0 16px 48px var(--shadow-color,rgba(0,0,0,.24));color:var(--text-color,inherit);background:var(--section-bg,var(--background-color,Canvas))}
.dmdnas-win *{box-sizing:border-box}.dmdnas-win button,.dmdnas-win input,.dmdnas-win select,.dmdnas-win textarea{font:inherit;color:var(--text-color,inherit)}.dmdnas-win-head{position:sticky;top:0;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 12px;border-bottom:1px solid var(--border-color,currentColor);background:var(--section-bg,var(--background-color,Canvas));cursor:move;user-select:none}.dmdnas-win-title{font-weight:950;line-height:1.15;color:var(--title-color,var(--text-color,inherit))}.dmdnas-win-sub{color:var(--muted-color,inherit);opacity:1;font-size:.82em;margin-top:2px}.dmdnas-win-actions{display:flex;gap:7px;align-items:center}.dmdnas-round{border:1px solid var(--border-color,currentColor);border-radius:999px;background:var(--button-bg,var(--panel-bg,transparent));height:32px;min-width:32px;padding:0 10px;cursor:pointer;font-weight:850}.dmdnas-round:hover,.dmdnas-btn:hover{background:var(--button-hover,var(--primary-soft,var(--card-bg,transparent)))}.dmdnas-win-body{padding:12px;display:grid;gap:10px}.dmdnas-panel{border:1px solid var(--border-color,currentColor);border-radius:var(--radius,12px);background:var(--panel-bg,var(--card-bg,transparent));padding:11px}.dmdnas-panel h4{margin:0 0 9px;font-size:.95em;color:var(--title-color,var(--text-color,inherit))}.dmdnas-facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px}.dmdnas-fact{border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);padding:8px;background:var(--card-bg,var(--panel-bg,transparent));min-width:0}.dmdnas-fact span{display:block;text-transform:uppercase;font-size:.66em;letter-spacing:.05em;color:var(--muted-color,inherit);opacity:1;margin-bottom:3px}.dmdnas-fact strong{display:block;word-break:break-word}.dmdnas-buttons{display:flex;gap:7px;flex-wrap:wrap}.dmdnas-btn{border:1px solid var(--border-color,currentColor);border-radius:999px;background:var(--button-bg,var(--panel-bg,transparent));color:var(--text-color,inherit);text-decoration:none;padding:7px 10px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:6px}.dmdnas-btn[disabled]{opacity:.48;cursor:wait}.dmdnas-msg{overflow-wrap:anywhere;min-height:20px;font-size:.88em;font-weight:800;border:1px solid var(--border-color,currentColor);border-left:4px solid var(--primary-color,currentColor);border-radius:var(--radius-sm,8px);padding:7px 9px;background:var(--card-bg,var(--panel-bg,transparent));line-height:1.25}.dmdnas-chips{display:flex;flex-wrap:wrap;gap:6px}.dmdnas-chip{border:1px solid var(--border-color,currentColor);border-radius:999px;padding:5px 8px;text-decoration:none;color:var(--text-color,inherit);font-size:.84em;display:inline-flex;gap:5px;align-items:center;background:var(--card-bg,transparent)}.dmdnas-state{border:1px solid var(--border-color,currentColor);border-radius:999px;padding:4px 9px;font-size:.78em;font-weight:950;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;background:var(--card-bg,transparent)}.dmdnas-state::before{content:'';width:8px;height:8px;border-radius:99px;background:currentColor}.dmdnas-state.on{color:var(--success-color,inherit);border-color:var(--success-color,var(--border-color,currentColor));background:var(--card-bg,transparent)}.dmdnas-state.off{color:var(--danger-color,inherit);border-color:var(--danger-color,var(--border-color,currentColor));background:var(--card-bg,transparent)}.dmdnas-state.unknown{color:var(--muted-color,inherit)}.dmdnas-tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px}.dmdnas-tile{border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);background:var(--card-bg,var(--panel-bg,transparent));color:var(--text-color,inherit);min-height:74px;padding:10px;display:grid;grid-template-columns:1fr auto;gap:4px 8px;text-align:left;cursor:pointer}.dmdnas-tile:hover{background:var(--primary-soft,var(--panel-bg,transparent))}.dmdnas-tile strong{line-height:1.12}.dmdnas-tile small{color:var(--muted-color,inherit);opacity:1;line-height:1.2}.dmdnas-badge{grid-row:1/3;grid-column:2;border:1px solid var(--border-color,currentColor);border-radius:999px;min-width:30px;height:30px;display:flex;align-items:center;justify-content:center;font-weight:900;background:var(--panel-bg,transparent)}.dmdnas-tools{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.dmdnas-tools input{flex:1;min-width:190px;border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);background:var(--input-bg,var(--panel-bg,transparent));padding:8px 10px}.dmdnas-rows{display:grid;gap:7px}.dmdnas-row{display:grid;grid-template-columns:minmax(150px,1fr) minmax(180px,1.3fr) auto;gap:8px;align-items:center;border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);padding:7px 9px;background:var(--card-bg,var(--panel-bg,transparent))}.dmdnas-row-title{font-weight:900;word-break:break-word}.dmdnas-row-sub{color:var(--muted-color,inherit);opacity:1;font-size:.82em;margin-top:2px;word-break:break-word}.dmdnas-row-text{color:var(--text-color,inherit);opacity:.88;font-size:.84em;line-height:1.24;word-break:break-word}.dmdnas-row-actions{display:flex;gap:5px;flex-wrap:wrap;justify-content:flex-end}.dmdnas-mini{padding:5px 8px;font-size:.82em}.dmdnas-formline{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr) auto;gap:8px;margin-bottom:8px}.dmdnas-formline input,.dmdnas-formline select,.dmdnas-formline textarea{border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);background:var(--input-bg,var(--panel-bg,transparent));padding:8px 10px}.dmdnas-formline-share{grid-template-columns:150px minmax(0,.8fr) minmax(0,1.2fr) auto}.dmdnas-share-box{border:1px solid var(--border-color,currentColor);border-radius:var(--radius,12px);background:var(--card-bg,var(--panel-bg,transparent));padding:10px;margin-bottom:9px}.dmdnas-share-box h4{margin:0 0 8px;font-size:.94em;color:var(--title-color,var(--text-color,inherit))}.dmdnas-share-note{color:var(--muted-color,inherit);opacity:1;font-size:.84em;margin-top:6px}.dmdnas-formline-perm{grid-template-columns:minmax(0,1fr) 120px 140px auto}.dmdnas-formline-members{grid-template-columns:minmax(0,1fr) auto}.dmdnas-install-grid{display:grid;gap:9px}.dmdnas-install-grid label{display:grid;gap:4px;font-weight:800}.dmdnas-install-grid textarea{min-height:120px;width:100%;border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);background:var(--input-bg,var(--panel-bg,transparent));padding:9px 10px;resize:vertical}.dmdnas-install-hint{color:var(--muted-color,inherit);opacity:1;font-size:.84em;line-height:1.25}.dmdnas-native{border:1px solid var(--border-color,currentColor);border-radius:var(--radius,12px);background:var(--card-bg,var(--panel-bg,transparent));padding:10px;display:grid;gap:8px}.dmdnas-native strong{display:block}.dmdnas-native small{color:var(--muted-color,inherit);opacity:1;line-height:1.25}.dmdnas-dsm-frame{width:100%;height:640px;border:1px solid var(--border-color,currentColor);border-radius:var(--radius,12px);background:var(--section-bg,transparent)}
.dmdnas-win{width:min(900px,calc(100vw - 24px));max-height:calc(100vh - 20px);min-height:260px}
.dmdnas-win-body{overflow:auto;align-content:start;padding:10px;gap:8px}
.dmdnas-win h4{margin:4px 0 2px;font-size:.9em}
.dmdnas-admin-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(245px,1fr));gap:7px}
.dmdnas-admin-card{border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);background:var(--card-bg,var(--panel-bg,transparent));padding:9px;min-width:0}
.dmdnas-admin-card-head{display:flex;justify-content:space-between;gap:8px;align-items:flex-start;margin-bottom:6px}.dmdnas-admin-card-head strong{font-size:.94em}.dmdnas-admin-card-head small{display:block;color:var(--muted-color,inherit);font-size:.76em;margin-top:2px}
.dmdnas-admin-card-body{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:5px}.dmdnas-admin-card-actions{display:flex;flex-wrap:wrap;gap:5px;margin-top:7px;padding-top:7px;border-top:1px solid var(--border-color,currentColor)}
.dmdnas-admin-metric{min-width:0}.dmdnas-admin-metric span{display:block;color:var(--muted-color,inherit);font-size:.68em;text-transform:uppercase;letter-spacing:.03em}.dmdnas-admin-metric strong{display:block;overflow-wrap:anywhere;font-size:.86em}
.dmdnas-admin-toolbar,.dmdnas-admin-summary{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.dmdnas-admin-summary>.dmdnas-admin-metric{border:1px solid var(--border-color,currentColor);border-radius:7px;padding:6px 8px;min-width:105px;background:var(--card-bg,var(--panel-bg,transparent))}
.dmdnas-editor{border:1px solid var(--border-color,currentColor);border-radius:var(--radius-sm,8px);padding:9px;background:var(--panel-bg,var(--card-bg,transparent));display:grid;gap:7px}.dmdnas-editor-title{font-weight:900;font-size:.9em}.dmdnas-editor-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:7px}.dmdnas-editor input,.dmdnas-editor select,.dmdnas-editor textarea{width:100%;border:1px solid var(--border-color,currentColor);border-radius:7px;background:var(--input-bg,var(--card-bg,transparent));padding:7px 8px}.dmdnas-editor textarea{min-height:70px;resize:vertical}
.dmdnas-danger{border-color:var(--danger-color,var(--border-color,currentColor));color:var(--danger-color,var(--text-color,inherit))}
.dmdnas-note{font-size:.78em;color:var(--muted-color,inherit);line-height:1.25}
@media(max-width:620px){.dmdnas-admin-grid{grid-template-columns:1fr}.dmdnas-admin-card-body{grid-template-columns:1fr}.dmdnas-win{width:calc(100vw - 12px);left:6px!important;min-width:0}.dmdnas-editor-grid{grid-template-columns:1fr}}
.dmdnas-hidden{display:none!important}
/* V60 - dashboard compact et fenêtres pro */
#${root.id}.dmdnasctl{padding:7px;overflow:auto}
#${root.id} .dmdnasctl-head{align-items:center;margin-bottom:6px;padding:0 0 6px}
#${root.id} .dmdnasctl-head p{display:none}
#${root.id} .dmdnasctl-vendors{display:grid;grid-template-columns:repeat(auto-fit,minmax(165px,180px));gap:8px;align-items:start}
#${root.id} .dmdnas-nas-card{min-width:0;min-height:92px;border:1px solid var(--border-color,currentColor);border-radius:10px;background:var(--card-bg,var(--panel-bg,transparent));padding:10px 12px;display:flex;flex-direction:column;justify-content:flex-start;align-items:flex-start;gap:8px;text-align:left;cursor:pointer;overflow:hidden}
#${root.id} .dmdnas-nas-card:hover{background:var(--primary-soft,var(--panel-bg,transparent))}
#${root.id} .dmdnas-nas-main{display:grid;min-width:0;width:100%;gap:6px}
#${root.id} .dmdnas-nas-titleline{display:flex;align-items:center;gap:8px;min-width:0;width:100%}
#${root.id} .dmdnas-nas-main strong{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:.98em;line-height:1.15;color:var(--title-color,var(--text-color,inherit));max-width:100%}
#${root.id} .dmdnas-nas-meta{font-size:.84em;line-height:1.25;color:var(--muted-color,inherit);word-break:break-word}
#${root.id} .dmdnas-status-dot{width:10px;height:10px;border-radius:999px;display:inline-block;flex:0 0 10px;background:var(--danger-color,#bf4d4d)}
#${root.id} .dmdnas-status-dot.online{background:var(--success-color,#37b36b)}
.dmdnas-empty-state{border:1px dashed var(--border-color,currentColor);border-radius:9px;padding:14px;display:grid;gap:3px;text-align:center}.dmdnas-empty-state span{font-size:.82em;color:var(--muted-color,inherit)}
.dmdnas-win{position:fixed!important;width:min(860px,calc(100vw - 20px));height:min(680px,calc(100vh - 20px));max-height:calc(100vh - 20px);min-height:300px;overflow:hidden;display:grid;grid-template-rows:auto minmax(0,1fr);resize:both}
.dmdnas-win-head{padding:8px 10px!important;cursor:move}.dmdnas-win-body{min-height:0;overflow:auto;padding:8px!important;gap:7px!important;align-content:start}.dmdnas-win-title{font-size:.98em!important}.dmdnas-win-sub{font-size:.74em!important}.dmdnas-round{height:30px!important;padding:0 9px!important}
.dmdnas-sheet-top{display:flex;justify-content:space-between;gap:10px;align-items:center;border:1px solid var(--border-color,currentColor);border-radius:9px;padding:8px 10px;background:var(--card-bg,var(--panel-bg,transparent))}.dmdnas-sheet-top>div{display:grid}.dmdnas-sheet-top small{font-size:.78em;color:var(--muted-color,inherit)}
.dmdnas-quickbar,.dmdnas-action-strip{display:flex;flex-wrap:wrap;gap:5px}.dmdnas-btn{border-radius:7px!important;padding:6px 9px!important;min-height:30px}.dmdnas-btn.primary{background:var(--primary-color,var(--button-bg,transparent));color:var(--primary-text,#fff);border-color:var(--primary-color,currentColor)}.dmdnas-msg.compact{min-height:0;padding:5px 8px;font-size:.78em}
.dmdnas-tiles{grid-template-columns:repeat(auto-fit,minmax(165px,1fr));gap:6px!important}.dmdnas-tile{min-height:58px!important;padding:7px 8px!important;grid-template-columns:30px minmax(0,1fr) auto!important;grid-template-rows:auto!important;align-items:center}.dmdnas-tile-icon{width:28px;height:28px;border:1px solid var(--border-color,currentColor);border-radius:7px;display:grid;place-items:center;font-weight:900}.dmdnas-tile-copy{display:grid;min-width:0}.dmdnas-tile-copy strong{font-size:.86em}.dmdnas-tile-copy small{font-size:.72em}.dmdnas-badge{grid-row:auto!important;grid-column:auto!important;width:28px;min-width:28px;height:28px;font-size:.78em}
.dmdnas-admin-grid{grid-template-columns:repeat(auto-fit,minmax(210px,1fr))!important;gap:6px!important}.dmdnas-admin-card{padding:7px!important}.dmdnas-admin-card-body{gap:4px!important}.dmdnas-admin-card-actions{margin-top:5px!important;padding-top:5px!important}.dmdnas-admin-metric span{font-size:.62em!important}.dmdnas-admin-metric strong{font-size:.82em!important}.dmdnas-admin-summary{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:5px!important}.dmdnas-admin-summary>.dmdnas-admin-metric{min-width:0!important;padding:6px!important}
.dmdnas-editor{padding:7px!important;gap:5px!important}.dmdnas-editor-grid{grid-template-columns:repeat(auto-fit,minmax(135px,1fr))!important;gap:5px!important}.dmdnas-editor input,.dmdnas-editor select,.dmdnas-editor textarea,.dmdnas-formline input,.dmdnas-formline select,.dmdnas-formline textarea{padding:6px 8px!important;min-height:30px}.dmdnas-inline-form{display:grid;grid-template-columns:100px auto auto;gap:5px}.dmdnas-section{border:1px solid var(--border-color,currentColor);border-radius:9px;padding:7px;background:var(--panel-bg,var(--card-bg,transparent))}.dmdnas-section h4{margin:0 0 6px!important}.dmdnas-tech{margin-top:6px;border-top:1px solid var(--border-color,currentColor);padding-top:5px}.dmdnas-tech summary{cursor:pointer;font-size:.76em;color:var(--muted-color,inherit)}.dmdnas-tech pre{max-height:240px;overflow:auto;font-size:.72em;white-space:pre-wrap}.dmdnas-empty-inline{font-size:.8em;color:var(--muted-color,inherit);padding:6px}
.dmdnas-row{grid-template-columns:minmax(130px,.9fr) minmax(160px,1.2fr) auto!important;padding:6px 7px!important;gap:6px!important}.dmdnas-row-title{font-size:.86em}.dmdnas-row-sub,.dmdnas-row-text{font-size:.74em!important}.dmdnas-row-actions{gap:4px!important}.dmdnas-mini{padding:4px 7px!important;min-height:27px!important}.dmdnas-formline,.dmdnas-formline-share{gap:5px!important;margin-bottom:6px!important}.dmdnas-share-box{padding:7px!important;margin-bottom:6px!important}
@media(max-width:720px){#${root.id} .dmdnasctl-vendors{grid-template-columns:repeat(auto-fit,minmax(145px,1fr))}#${root.id} .dmdnas-nas-card{min-height:86px;padding:9px 10px}.dmdnas-win{left:5px!important;top:5px!important;width:calc(100vw - 10px)!important;height:calc(100vh - 10px)!important;min-width:0;resize:none}.dmdnas-row,.dmdnas-formline,.dmdnas-formline-share,.dmdnas-formline-perm,.dmdnas-inline-form{grid-template-columns:1fr}.dmdnas-row-actions{justify-content:flex-start}.dmdnas-tiles{grid-template-columns:repeat(2,minmax(0,1fr))!important}}
`;

    document.head.appendChild(css);

    function esc(v){return String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));}
    function norm(v){return String(v ?? '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');}
    function msg(text){mainMsg.textContent = text || '';}
    function keyOf(i){return [i.storage_mode || 'private', i.vendor || 'other', i.id || ''].join('|');}
    function findByKey(k){return items.find(i => keyOf(i) === k) || null;}
    function vendorName(v){return vendors[v] || 'Autre';}
    function addr(i){return i.ip || i.hostname || '-';}
    function online(i){return String(i.last_status || '').toLowerCase() === 'online';}
    function status(i){return i.last_status || 'non testé';}
    function last(i){return i.dsm_last_refresh || i.qnap_last_refresh || i.last_check || '-';}
    function packs(i){
        if (i.api_type === 'qnap') {
            const info = i.qnap_info || i.qnap_refresh || {};
            const p = i.qnap_packages || {};
            const installed = Array.isArray(p.installed) && p.installed.length ? p.installed : (Array.isArray(info.packages) ? info.packages : []);
            return {installed, available: []};
        }
        const info = i.dsm_info || {};
        const p = i.dsm_packages || {};
        const installed = Array.isArray(p.installed) && p.installed.length ? p.installed : (Array.isArray(info.packages) ? info.packages : []);
        const availableRaw = Array.isArray(p.available) ? p.available : [];
        return {installed, available: filterAvailablePackages(availableRaw, installed)};
    }
    function dsm(i){
        const d = i.api_type === 'qnap' ? (i.qnap_info || i.qnap_refresh || {}) : (i.dsm_info || {});
        const p = packs(i);
        const docker = i.api_type === 'qnap' ? (i.qnap_docker || {}) : (i.dsm_docker || {});
        return {
            model: (d.summary && (d.summary.model || d.summary.hostname)) || (d.system && (d.system.model || d.system.support_model || d.system.servername)) || i.model || '-',
            version: (d.summary && d.summary.firmware) || (d.system && (d.system.firmware_ver || d.system.firmware || d.system.version)) || '-',
            serial: (d.summary && d.summary.serial) || (d.system && (d.system.serial || d.system.serial_num)) || '-',
            packages: p.installed,
            available: p.available,
            containers: Array.isArray(docker.containers) && docker.containers.length ? docker.containers : (Array.isArray(d.containers) ? d.containers : []),
            images: Array.isArray(docker.images) && docker.images.length ? docker.images : (Array.isArray(d.images) ? d.images : []),
            registry: Array.isArray(docker.registry) ? docker.registry : [],
            users: Array.isArray(d.users) ? d.users : [],
            groups: Array.isArray(d.groups) ? d.groups : [],
            shares: Array.isArray(d.shares) ? d.shares : [],
            storage: Array.isArray(d.storage) ? d.storage : [],
            network: d.network && typeof d.network === 'object' ? d.network : {},
            system: d.system && typeof d.system === 'object' ? d.system : {},
            errors: Array.isArray(d.errors) ? d.errors : [],
            services: (Array.isArray(d.services) && d.services.length) ? d.services : (Array.isArray(i.detected_services) ? i.detected_services : [])
        };
    }
    function first(o, keys){
        if(!o || typeof o !== 'object') return '';
        for(const k of keys){ if(o[k] !== undefined && o[k] !== null && String(o[k]) !== '' && typeof o[k] !== 'object') return o[k]; }
        if (o.additional && typeof o.additional === 'object') for (const k of keys){ if(o.additional[k] !== undefined && o.additional[k] !== null && String(o.additional[k]) !== '' && typeof o.additional[k] !== 'object') return o.additional[k]; }
        return '';
    }

    function pkgCandidateValues(p){
        if (!p || typeof p !== 'object') return [];
        const keys = ['id','package','package_id','package_name','pkgname','name','display_name','title','dname'];
        const vals = [];
        keys.forEach(k => {
            const v = first(p, [k]);
            if (v !== '') vals.push(String(v));
        });
        const pkg = first(p, ['package']);
        const display = first(p, ['display_name','name','title']);
        if (pkg && display) vals.push(pkg + ' ' + display);
        return vals;
    }
    function pkgNormKey(v){
        let t = norm(v).replace(/[^a-z0-9]+/g, '');
        if (!t) return '';
        t = t.replace(/httpserver/g, '').replace(/server/g, '').replace(/station/g, '').replace(/package/g, '').replace(/service/g, '');
        return t;
    }
    function pkgKeys(p){
        const out = new Set();
        pkgCandidateValues(p).forEach(v => {
            const a = norm(v).trim();
            const b = pkgNormKey(v);
            if (a) out.add(a);
            if (b) out.add(b);
        });
        return Array.from(out);
    }
    function packageIsInstalled(pkg, installed){
        const have = new Set();
        (Array.isArray(installed) ? installed : []).forEach(p => pkgKeys(p).forEach(k => have.add(k)));
        return pkgKeys(pkg).some(k => have.has(k));
    }
    function filterAvailablePackages(available, installed){
        return (Array.isArray(available) ? available : []).filter(p => !packageIsInstalled(p, installed));
    }
    function deepFirst(o, paths){
        if (!o || typeof o !== 'object') return '';
        for (const path of paths) {
            const parts = String(path).split('.');
            let cur = o;
            let ok = true;
            for (const part of parts) {
                if (!cur || typeof cur !== 'object' || cur[part] === undefined || cur[part] === null || typeof cur[part] === 'object') { ok = false; break; }
                cur = cur[part];
            }
            if (ok && String(cur) !== '') return cur;
        }
        return '';
    }
    function packageState(p){
        const server = p && typeof p === 'object' ? (p._dmd_status || p.dmd_status || null) : null;
        if (server && typeof server === 'object' && server.state) {
            const st = String(server.state || '').toLowerCase();
            return {
                state: st === 'on' || st === 'off' ? st : 'unknown',
                label: server.label || (st === 'on' ? 'Actif' : (st === 'off' ? 'Arrêté' : 'Inconnu')),
                raw: server.raw || '',
                source: server.source || 'DSM'
            };
        }
        function parse(v){
            if (typeof v !== 'string') return v;
            const t = v.trim();
            if (!t || !/^[\[{]/.test(t)) return v;
            try { return JSON.parse(t); } catch(_) { return v; }
        }
        function val(obj, path){
            let cur = obj;
            for (const part of String(path).split('.')) {
                cur = parse(cur);
                if (!cur || typeof cur !== 'object' || cur[part] === undefined || cur[part] === null) return '';
                cur = cur[part];
            }
            cur = parse(cur);
            return cur;
        }
        function classify(raw, source){
            if (raw === true || raw === 1 || raw === '1') return {state:'on', label:'Actif', raw:String(raw), source};
            if (raw === false || raw === 0 || raw === '0') return {state:'off', label:'Arrêté', raw:String(raw), source};
            const t = norm(raw);
            if (!t) return null;
            if (['running','run','started','enabled','enable','on','active','true'].includes(t) || t.includes('running') || t.includes('started') || t.includes('enabled')) return {state:'on', label:'Actif', raw:String(raw), source};
            if (['stopped','stop','disabled','disable','off','inactive','false','not running'].includes(t) || t.includes('stopped') || t.includes('disabled') || t.includes('not running')) return {state:'off', label:'Arrêté', raw:String(raw), source};
            return null;
        }
        function opHas(ops, name){
            ops = parse(ops);
            if (!ops) return false;
            if (Array.isArray(ops)) return ops.map(x => norm(x && typeof x === 'object' ? (x.name || x.method || x.action || '') : x)).includes(name);
            if (typeof ops === 'object') {
                if (ops[name] === true || ops[name] === 1 || ops[name] === '1') return true;
                if (ops[name] && typeof ops[name] === 'object') return true;
                return Object.keys(ops).map(norm).includes(name);
            }
            return norm(ops).includes(name);
        }
        for (const path of ['status','state','run','running','is_running','started','enabled','enable','additional.status','additional.status_origin','additional.status_description','additional.state','additional.installed_info.status','installed_info.status']) {
            const c = classify(val(p, path), path);
            if (c) return c;
        }
        for (const path of ['available_operation','additional.available_operation','installed_info.available_operation']) {
            const ops = val(p, path);
            if (opHas(ops, 'stop') || opHas(ops, 'restart')) return {state:'on', label:'Actif', raw:'stop/restart disponible', source:path};
            if (opHas(ops, 'start')) return {state:'off', label:'Arrêté', raw:'start disponible', source:path};
        }
        for (const path of ['ctl_stop','additional.ctl_stop','available_operation.stop']) {
            if (val(p, path) === true || val(p, path) === 1 || val(p, path) === '1') return {state:'on', label:'Actif', raw:'stop disponible', source:path};
        }
        for (const path of ['ctl_start','additional.ctl_start','available_operation.start']) {
            if (val(p, path) === true || val(p, path) === 1 || val(p, path) === '1') return {state:'off', label:'Arrêté', raw:'start disponible', source:path};
        }
        return {state:'unknown', label:'État non renvoyé par DSM', raw:'', source:'DSM'};
    }
    function packageStateBadge(st){
        const state = (st && st.state) ? st.state : 'unknown';
        const label = state === 'on' ? 'Actif' : (state === 'off' ? 'Arrêté' : 'Statut inconnu');
        return `<span class="dmdnas-state ${esc(state)}" title="${esc((st && st.source ? st.source : 'DSM') + (st && st.raw ? ' : ' + st.raw : ''))}">${esc(label)}</span>`;
    }
    function short(v, max=120){ const s=String(v||'').replace(/\s+/g,' ').trim(); return s.length>max?s.slice(0,max-1)+'…':s; }
    function pkgName(p){return first(p, ['display_name','name','title','package','package_name','id']) || 'Paquet';}
    function pkgId(p){return first(p, ['package','id','package_name','pkgname','name','title','display_name']);}
    function collectVolumesFromObject(o, out){
        if (!o || typeof o !== 'object') return;
        if (Array.isArray(o)) { o.forEach(x => collectVolumesFromObject(x, out)); return; }
        Object.keys(o).forEach(k => {
            const v = o[k];
            if (typeof v === 'string') {
                const m = v.match(/(\/volume\d+)(?:\/|$)/i);
                if (m) out.add(m[1]);
            } else if (v && typeof v === 'object') collectVolumesFromObject(v, out);
        });
    }
    function volumeList(i){
        const out = new Set();
        const info = i.dsm_info || {};
        collectVolumesFromObject(info.storage || {}, out);
        collectVolumesFromObject(info.raw && info.raw.storage ? info.raw.storage : {}, out);
        collectVolumesFromObject(info.shares || [], out);
        return Array.from(out).sort((a,b)=>a.localeCompare(b, undefined, {numeric:true}));
    }
    function volumeOptions(i, selected, known){
        let vols = volumeList(i);
        if (known && Array.isArray(known.volume_list) && known.volume_list.length) {
            vols = known.volume_list.map(v => v.mount_point || v.volume_path || v.path || '').filter(Boolean);
        }
        vols = Array.from(new Set(vols));
        const opts = ['<option value="">Volume DSM par défaut</option>'].concat(vols.map(v => `<option value="${esc(v)}"${v===selected?' selected':''}>${esc(v)}</option>`));
        return opts.join('');
    }
    function shareName(x){return first(x, ['name','share_name','id','uuid']) || 'Partage';}
    function shareDesc(x){return first(x, ['description','desc','comment','remark']) || '';}
    function shareStatus(x){return first(x, ['status','state','enable','enabled','available','is_available']) || 'état non renvoyé';}
    function shareRawPath(x){return first(x, ['path','share_path','real_path','mount_point','volume_path','vol_path']);}
    function shareVolume(x){
        const direct = first(x, ['vol_path','volume_path','mount_point','volume','volume_name']);
        if (direct) {
            const m = String(direct).match(/(\/volume\d+)(?:\/|$)/i);
            return m ? m[1] : direct;
        }
        const p = shareRawPath(x);
        const m = String(p).match(/(\/volume\d+)(?:\/|$)/i);
        return m ? m[1] : '';
    }
    function sharePath(x){
        const p = shareRawPath(x);
        if (p) return p;
        const v = shareVolume(x), n = shareName(x);
        return v && n && n !== 'Partage' ? v.replace(/\/$/,'') + '/' + n : '';
    }
    function permName(x){return first(x, ['name','user','group','uid','gid','principal','subject']) || 'entrée';}
    function permType(x){return first(x, ['type','is_group','principal_type','subject_type']) || '';} 
    function permValue(x){return first(x, ['permission','privilege','perm','access','right','acl']) || detailText(x, ['readable','writable','deny','allow']);}

    function safeBg(){
        let e = root;
        while (e && e !== document.documentElement) {
            const val = getComputedStyle(e).backgroundColor;
            if (val && val !== 'rgba(0, 0, 0, 0)' && val !== 'transparent') return val;
            e = e.parentElement;
        }
        const body = getComputedStyle(document.body).backgroundColor;
        return body && body !== 'rgba(0, 0, 0, 0)' ? body : 'Canvas';
    }
    function bring(w){w.style.zIndex = String(++zIndex);}
    function growPage(){ /* fenêtres confinées au viewport : ne jamais agrandir le dashboard */ }
    function makeWin(title, sub, html, key, width){
        let existing = null;
        if (key) document.querySelectorAll('.dmdnas-win[data-key]').forEach(w => { if (w.dataset.key === key) existing = w; });
        if (existing) { bring(existing); return existing; }
        const w = document.createElement('div');
        w.className = 'dmdnas-win';
        if (key) w.dataset.key = key;
        if (width) w.style.width = width;
        w.style.background = safeBg();
        w.style.color = getComputedStyle(root).color;
        w.style.left = Math.max(8, Math.min(window.innerWidth - Math.min(parseInt(width||'900',10), 900) - 16, 70 + Math.random()*28)) + 'px';
        w.style.top = Math.max(8, Math.min(window.innerHeight - 300, 60 + Math.random()*24)) + 'px';
        w.innerHTML = `<div class="dmdnas-win-head"><div><div class="dmdnas-win-title">${esc(title)}</div><div class="dmdnas-win-sub">${esc(sub||'')}</div></div><div class="dmdnas-win-actions"><button type="button" class="dmdnas-round" data-win-refresh>Refresh</button><button type="button" class="dmdnas-round" data-win-close>×</button></div></div><div class="dmdnas-win-body">${html}</div>`;
        document.body.appendChild(w);
        drag(w);
        bring(w);
        growPage();
        w.addEventListener('mousedown', () => bring(w));
        w.querySelector('[data-win-close]').onclick = () => { w.remove(); growPage(); };
        return w;
    }
    function drag(w){
        const h = w.querySelector('.dmdnas-win-head');
        let active=false,sx=0,sy=0,left=0,top=0;
        h.addEventListener('pointerdown', e => {
            if (e.target.closest('button')) return;
            active=true; sx=e.clientX; sy=e.clientY; left=parseFloat(w.style.left)||0; top=parseFloat(w.style.top)||0; bring(w); h.setPointerCapture(e.pointerId);
        });
        h.addEventListener('pointermove', e => { if(!active) return; const maxL=Math.max(0,window.innerWidth-w.offsetWidth); const maxT=Math.max(0,window.innerHeight-Math.min(w.offsetHeight,120)); w.style.left=Math.max(0,Math.min(maxL,left+e.clientX-sx))+'px'; w.style.top=Math.max(0,Math.min(maxT,top+e.clientY-sy))+'px'; });
        h.addEventListener('pointerup', e => { active=false; try{h.releasePointerCapture(e.pointerId)}catch(_){} growPage(); });
    }
    function ensureMsg(scope){
        let m = scope.querySelector('[data-msg]');
        if (!m) { m = document.createElement('div'); m.className='dmdnas-msg'; m.dataset.msg='1'; scope.prepend(m); }
        return m;
    }
    function setWinMsg(scope, text){ ensureMsg(scope).textContent = text || ''; }
    function dsmCodes(text){
        const found = [];
        String(text || '').replace(/\"code\"\s*:\s*(\d+)|"code"\s*:\s*(\d+)/g, (_,a,b) => { const c = a || b; if(c && !found.includes(c)) found.push(c); return ''; });
        return found;
    }
    function friendlyError(raw, action, extra){
        const text = String(raw || 'Erreur inconnue').replace(/\s+/g, ' ').trim();
        if (!text) return 'Erreur inconnue';
        const codes = dsmCodes(text);
        const codeText = codes.length ? ' Code DSM : ' + codes.join(', ') + '.' : '';
        if ((action === 'dsm_package_action' || text.includes('installation')) && text.includes('extra_values')) {
            return 'DSM refuse l’installation du paquet : paramètres supplémentaires demandés par DSM (extra_values).' + codeText;
        }
        if ((action === 'dsm_package_action' || text.includes('installation')) && (text.includes('code 103') || text.includes('\"code\":103'))) {
            return 'DSM refuse l’installation via cette méthode API.' + codeText;
        }
        if (text.length <= 260) return text;
        const prefix = codes.length ? 'Codes DSM : ' + codes.join(', ') + '. ' : '';
        return prefix + text.slice(0, 260) + '…';
    }
    function detailText(o, keys){
        if (!o || typeof o !== 'object') return '';
        const out = [];
        keys.forEach(k => { if (o[k] !== undefined && o[k] !== null && String(o[k]) !== '' && typeof o[k] !== 'object') out.push(k + ' : ' + o[k]); });
        return out.join(' · ');
    }
    async function callApi(action, item, extra){
        const body = new URLSearchParams(extra || {});
        body.set('action', action);
        body.set('csrf', csrf);
        if (item) { body.set('id', item.id||''); body.set('vendor', item.vendor||'other'); body.set('storage_mode', item.storage_mode||'private'); }
        const res = await fetch(apiUrl, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body});
        const text = await res.text();
        let json;
        try { json = JSON.parse(text); } catch(e) { throw new Error('API non JSON : ' + text.slice(0, 180)); }
        if (!json.ok) {
            if (json.item) mergeItem(json.item);
            const er = new Error(json.message || 'Erreur API');
            er.payload = json;
            throw er;
        }
        if (json.item) mergeItem(json.item);
        return json;
    }
    function mergeItem(item){ const idx = items.findIndex(x => keyOf(x) === keyOf(item)); if(idx>=0) items[idx]=item; else items.push(item); render(); }
    async function reloadItems(){
        const res = await fetch(apiUrl + '?action=list', {credentials:'same-origin'});
        const text = await res.text();
        let json;
        try { json = JSON.parse(text); } catch(e) { throw new Error('Liste non JSON : ' + text.slice(0, 180)); }
        if (!json.ok) throw new Error(json.message || 'Liste NAS impossible');
        items = Array.isArray(json.items) ? json.items : [];
        render(); return items;
    }

    function countVendor(v){return items.filter(i => i.enabled !== false && i.vendor === v).length;}
    function onlineCount(v){return items.filter(i => i.enabled !== false && i.vendor === v && online(i)).length;}
    function render(){
        const active = items.filter(i => i.enabled !== false);
        if (!active.length) {
            vendorsBox.innerHTML = '<div class="dmdnas-empty-state"><strong>Aucun NAS configuré</strong><span>Ajoute ton NAS depuis la configuration du module.</span></div>';
            return;
        }
        vendorsBox.innerHTML = active.map(i => {
            const isOnline = online(i);
            return `<button type="button" class="dmdnas-nas-card" data-nas-key="${esc(keyOf(i))}" title="${esc(i.name||'NAS')} - ${isOnline?'En ligne':'Hors ligne'} - ${esc(vendorName(i.vendor))}: ${esc(addr(i))}">
                <span class="dmdnas-nas-main">
                    <span class="dmdnas-nas-titleline">
                        <strong>${esc(i.name||'NAS')}</strong>
                        <span class="dmdnas-status-dot ${isOnline?'online':''}" title="${isOnline?'En ligne':'Hors ligne'}"></span>
                    </span>
                    <span class="dmdnas-nas-meta">${esc(vendorName(i.vendor))}: ${esc(addr(i))}</span>
                </span>
            </button>`;
        }).join('');
    }

    function fact(label, value){return `<div class="dmdnas-fact"><span>${esc(label)}</span><strong>${esc(value || '-')}</strong></div>`;}
    function chipList(list){
        list = Array.isArray(list) ? list : [];
        if (!list.length) return '<span class="dmdnas-chip">Aucun service détecté</span>';
        return list.map(s => s.url ? `<a class="dmdnas-chip" target="_blank" rel="noopener" href="${esc(s.url)}">${esc(s.name||'Service')} · ${esc(s.port||'')}</a>` : `<span class="dmdnas-chip">${esc(s.name||'Service')} · ${esc(s.port||'')}</span>`).join('');
    }
    function tile(panel, title, count, sub, icon='•'){return `<button type="button" class="dmdnas-tile" data-panel="${esc(panel)}"><span class="dmdnas-tile-icon">${esc(icon)}</span><span class="dmdnas-tile-copy"><strong>${esc(title)}</strong><small>${esc(sub||'')}</small></span><span class="dmdnas-badge">${esc(count)}</span></button>`;}
    function sheetHtml(i){
        const d = dsm(i), isSyno=i.api_type==='synology', isQnap=i.api_type==='qnap';
        const href=i.admin_url?`<a class="dmdnas-btn primary" target="_blank" rel="noopener" href="${esc(i.admin_url)}">Ouvrir DSM/QTS</a>`:'';
        const apiActions=isSyno?'<button type="button" class="dmdnas-btn" data-act="dsm_refresh">Actualiser DSM</button><button type="button" class="dmdnas-btn" data-act="api_audit">Diagnostic</button>':(isQnap?'<button type="button" class="dmdnas-btn" data-act="qnap_refresh">Actualiser QTS</button><button type="button" class="dmdnas-btn" data-act="qnap_docker">Containers</button>':'');
        const tiles=isSyno?[
            tile('admin_system','Système','›','CPU, RAM, santé','⚙'),
            tile('admin_storage','Stockage','›','pools, volumes, disques','▣'),
            tile('admin_network','Réseau','›','interfaces, IP, DNS','↔'),
            tile('shares','Partages',d.shares.length,'créer, modifier, ACL','▤'),
            tile('users','Utilisateurs',d.users.length,'créer, désactiver, supprimer','♙'),
            tile('groups','Groupes',d.groups.length,'membres et droits','♟'),
            tile('installed','Paquets',d.packages.length,'start, stop, uninstall','◇'),
            tile('available','Catalogue',d.available.length,'installer','＋'),
            tile('docker','Containers',d.containers.length,'start, stop, images','▱'),
            tile('admin_tasks','Tâches','›','créer, éditer, exécuter','✓'),
            tile('admin_updates','Mises à jour','›','rechercher, configurer','↑'),
            tile('admin_security','Sécurité','›','SSH, certificats, firewall','◆'),
            tile('admin_power','Alimentation','›','redémarrer, arrêter','⏻')
        ].join(''):(isQnap?[
            tile('qnap_system','Système','›','QTS / QuTS, CPU, RAM, santé','⚙'),
            tile('qnap_storage','Stockage',Array.isArray(d.storage)?d.storage.length:0,'disques, SMART, pools, volumes','▣'),
            tile('qnap_network','Réseau','›','interfaces, IP, MAC, DNS','↔'),
            tile('qnap_users','Utilisateurs',d.users.length,'comptes locaux détectés','♙'),
            tile('qnap_groups','Groupes',d.groups.length,'groupes locaux détectés','♟'),
            tile('qnap_shares','Partages',d.shares.length,'dossiers partagés et ACL','▤'),
            tile('qnap_packages','Applications',d.packages.length,'App Center / QPKG','◇'),
            tile('qnap_docker','Containers',d.containers.length,'Container Station','▱'),
            tile('services','Services',Array.isArray(i.detected_services)?i.detected_services.length:0,'scan réseau','↗')
        ].join(''):tile('services','Services',Array.isArray(i.detected_services)?i.detected_services.length:0,'scan réseau','↗'));
        return `<div class="dmdnas-sheet-top"><div><strong>${esc(i.name||'NAS')}</strong><small>${esc(vendorName(i.vendor))} · ${esc(d.model||i.model||'—')} · ${esc(addr(i))}</small></div><span class="dmdnasctl-pill ${online(i)?'online':''}">${esc(status(i))}</span></div>
        <div class="dmdnas-quickbar">${href}<button type="button" class="dmdnas-btn" data-act="test">Tester</button><button type="button" class="dmdnas-btn" data-act="scan">Scanner</button>${apiActions}</div><div class="dmdnas-msg compact" data-msg></div>
        <div class="dmdnas-tiles">${tiles}</div>`;
    }

    function openSheet(i){
        const w = makeWin(i.name || 'NAS', `${vendorName(i.vendor)} · ${addr(i)}`, sheetHtml(i), 'nas-' + keyOf(i), '760px');
        w.dataset.itemKey = keyOf(i);
        bindSheet(w);
        const rb = w.querySelector('[data-win-refresh]');
        rb.onclick = async e => { e.preventDefault(); await refreshSheet(w); };
    }
    async function refreshSheet(w){
        let i = findByKey(w.dataset.itemKey);
        if (!i) return;
        const body = w.querySelector('.dmdnas-win-body');
        const rb = w.querySelector('[data-win-refresh]');
        if (rb) rb.disabled = true;
        try {
            const refreshAction = i.api_type === 'synology' ? 'dsm_refresh' : (i.api_type === 'qnap' ? 'qnap_refresh' : 'scan');
            setWinMsg(body, refreshAction === 'dsm_refresh' ? 'Actualisation DSM...' : (refreshAction === 'qnap_refresh' ? 'Actualisation QTS...' : 'Scan en cours...'));
            const j = await callApi(refreshAction, i, {});
            i = j.item || i;
            w.dataset.itemKey = keyOf(i);
            body.dataset.bound = '0';
            body.innerHTML = sheetHtml(i);
            bindSheet(w);
            setWinMsg(body, j.message || 'Actualisé.');
        } catch(err) { setWinMsg(body, friendlyError(err.message || String(err), 'refresh_sheet', {})); }
        finally { if(rb) rb.disabled=false; growPage(); }
    }
    function bindSheet(w){
        const body = w.querySelector('.dmdnas-win-body');
        if (!body || body.dataset.bound === '1') return;
        body.dataset.bound = '1';
        body.addEventListener('click', async e => {
            const panel = e.target.closest('[data-panel]');
            if (panel && body.contains(panel)) {
                const i = findByKey(w.dataset.itemKey);
                if (i) { if ((panel.dataset.panel||'').startsWith('admin_')) openAdminPanel(i, panel.dataset.panel); else openPanel(i, panel.dataset.panel); }
                return;
            }
            const btn = e.target.closest('[data-act]');
            if (!btn || !body.contains(btn)) return;
            e.preventDefault();
            let i = findByKey(w.dataset.itemKey);
            if (!i) return;
            const act = btn.dataset.act;
            if (act === 'api_audit') { openApiAudit(i); return; }
            btn.disabled = true;
            try {
                const j = await callApi(act, i, {});
                i = j.item || i;
                w.dataset.itemKey = keyOf(i);
                body.dataset.bound = '0';
                body.innerHTML = sheetHtml(i);
                bindSheet(w);
                setWinMsg(body, j.message || 'OK');
            } catch(err) { setWinMsg(body, friendlyError(err.message || String(err), act, {})); }
            finally { btn.disabled = false; growPage(); }
        });
    }


    function auditHtml(message, report){
        if (!report) {
            return `<div class="dmdnas-msg" data-msg>${esc(message || 'Clique sur Lancer audit pour générer le rapport DSM.')}</div><div class="dmdnas-buttons"><button type="button" class="dmdnas-btn" data-run-audit>Lancer audit DSM</button></div>`;
        }
        const json = JSON.stringify(report, null, 2);
        const okCount = report.tests_reussis ? Object.keys(report.tests_reussis).length : 0;
        const koCount = report.tests_refuses ? Object.keys(report.tests_refuses).length : 0;
        const apiCount = report.api_count || (report.apis_disponibles ? Object.keys(report.apis_disponibles).length : 0);
        const file = report.report_file_relative || report.report_file || '';
        const rowsOk = report.tests_reussis ? Object.entries(report.tests_reussis).map(([k,v]) => row(k, (v.api||'') + '.' + (v.method||''), 'OK', '<span class="dmdnas-state on">OK</span>', k)).join('') : '';
        const rowsKo = report.tests_refuses ? Object.entries(report.tests_refuses).map(([k,v]) => row(k, (v.api||'') + '.' + (v.method||''), (v.code ? 'Code '+v.code+' · ' : '') + (v.message||''), '<span class="dmdnas-state off">Refusé</span>', k)).join('') : '';
        return `<div class="dmdnas-msg" data-msg>${esc(message || 'Audit terminé.')} ${file ? 'Fichier serveur : ' + esc(file) : ''}</div>
            <section class="dmdnas-panel"><h4>Résumé</h4><div class="dmdnas-facts">${fact('APIs détectées', apiCount)}${fact('Tests OK', okCount)}${fact('Refus / absences', koCount)}${fact('Fichier', file || '-')}</div></section>
            <section class="dmdnas-panel"><h4>Rapport JSON</h4><div class="dmdnas-buttons"><button type="button" class="dmdnas-btn" data-copy-audit>Copier JSON</button><button type="button" class="dmdnas-btn" data-download-audit>Télécharger JSON</button><button type="button" class="dmdnas-btn" data-run-audit>Relancer audit</button></div><textarea data-audit-json style="width:100%;min-height:260px;margin-top:8px;border:1px solid currentColor;border-radius:12px;background:transparent;color:inherit;padding:10px;resize:vertical">${esc(json)}</textarea></section>
            <section class="dmdnas-panel"><h4>Tests réussis</h4><div class="dmdnas-rows">${rowsOk || noRows()}</div></section>
            <section class="dmdnas-panel"><h4>Tests refusés / absents</h4><div class="dmdnas-rows">${rowsKo || noRows()}</div></section>`;
    }
    function openApiAudit(item){
        const w = makeWin('Diagnostic API DSM', item.name || 'NAS', auditHtml('Clique sur Lancer audit DSM pour générer le rapport JSON.', null), 'audit-' + keyOf(item), '900px');
        w.dataset.itemKey = keyOf(item);
        bindAuditWindow(w);
    }
    function bindAuditWindow(w){
        const body = w.querySelector('.dmdnas-win-body');
        if (!body || body.dataset.auditBound === '1') return;
        body.dataset.auditBound = '1';
        body.addEventListener('click', async e => {
            const run = e.target.closest('[data-run-audit]');
            const copy = e.target.closest('[data-copy-audit]');
            const dl = e.target.closest('[data-download-audit]');
            if (run) {
                e.preventDefault();
                let i = findByKey(w.dataset.itemKey);
                if (!i) return;
                run.disabled = true;
                body.innerHTML = '<div class="dmdnas-msg" data-msg>Audit DSM en cours...</div>';
                body.dataset.auditBound = '0';
                try {
                    const j = await callApi('dsm_api_audit', i, {});
                    body.innerHTML = auditHtml(j.message || 'Audit terminé.', j.report || null);
                    bindAuditWindow(w);
                } catch(err) {
                    body.innerHTML = auditHtml(friendlyError(err.message || String(err), 'dsm_api_audit', {}), null);
                    bindAuditWindow(w);
                } finally { growPage(); }
                return;
            }
            if (copy) {
                e.preventDefault();
                const ta = body.querySelector('[data-audit-json]');
                if (!ta) return;
                try { await navigator.clipboard.writeText(ta.value); setWinMsg(body, 'Rapport JSON copié.'); }
                catch(_) { ta.focus(); ta.select(); document.execCommand('copy'); setWinMsg(body, 'Rapport JSON copié.'); }
                return;
            }
            if (dl) {
                e.preventDefault();
                const ta = body.querySelector('[data-audit-json]');
                if (!ta) return;
                const blob = new Blob([ta.value], {type:'application/json;charset=utf-8'});
                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'dmd_nas_dsm_api_audit.json';
                document.body.appendChild(a); a.click(); a.remove();
                setTimeout(()=>URL.revokeObjectURL(a.href), 2000);
                return;
            }
        });
    }

    function panelTitle(panel){return ({installed:'Paquets installés',available:'Catalogue paquets',docker:'Docker / Container Manager',users:'Utilisateurs DSM',groups:'Groupes DSM',shares:'Partages — créer / modifier / droits / supprimer',services:'Services détectés',qnap_system:'QNAP — système',qnap_storage:'QNAP — stockage',qnap_network:'QNAP — réseau',qnap_users:'QNAP — utilisateurs',qnap_groups:'QNAP — groupes',qnap_shares:'QNAP — partages',qnap_packages:'QNAP — applications',qnap_docker:'QNAP — Container Station',admin_system:'Système / Santé',admin_storage:'Stockage',admin_network:'Réseau',admin_updates:'Mises à jour DSM',admin_security:'Sécurité',admin_tasks:'Tâches planifiées',admin_activity:'Activité',admin_power:'Alimentation'})[panel] || 'Gestion';}
    function row(name, sub, text, actions, filterText){return `<div class="dmdnas-row" data-filter="${esc(norm(filterText || [name,sub,text].join(' ')))}"><div><div class="dmdnas-row-title">${esc(name)}</div><div class="dmdnas-row-sub">${esc(sub||'')}</div></div><div class="dmdnas-row-text">${esc(text||'')}</div><div class="dmdnas-row-actions">${actions||''}</div></div>`;}
    function noRows(){return row('Aucun élément','','','');}
    function searchTools(){return '<div class="dmdnas-tools"><input type="search" data-filter-input placeholder="Rechercher..."><button type="button" class="dmdnas-btn" data-panel-refresh>Actualiser</button></div>';}
    function panelHtml(i, panel){
        const d = dsm(i);
        if (panel === 'qnap_system') {
            const sys = d.system || {};
            const labels={hostname:'Nom du NAS',model:'Modèle',platform:'Plateforme',firmware_version:'Version QTS / QuTS',firmware_build:'Build',firmware_number:'Firmware',cpu_model:'Processeur',cpu_usage:'CPU utilisé',memory_total:'Mémoire totale',memory_free:'Mémoire libre',memory_usage:'Mémoire utilisée',system_temp:'Température système',cpu_temp:'Température CPU',uptime:'Uptime',health:'Santé',is_zfs:'QuTS hero / ZFS'};
            const order=['hostname','model','platform','firmware_version','firmware_build','firmware_number','cpu_model','cpu_usage','memory_total','memory_free','memory_usage','system_temp','cpu_temp','uptime','health','is_zfs'];
            const mainRows = order.filter(k => sys[k] !== undefined && sys[k] !== null && String(sys[k]) !== '').map(k => row(labels[k]||k,'QNAP',k==='is_zfs'?(String(sys[k])==='1'?'Oui':'Non'):String(sys[k]),'')).join('');
            const extraRows = Object.entries(sys).filter(([k,v]) => !order.includes(k) && v !== undefined && v !== null && typeof v !== 'object' && String(v) !== '').slice(0,80).map(([k,v]) => row(k.replaceAll('_',' '),'QNAP',String(v),'')).join('');
            const rows = mainRows + extraRows;
            const err = d.errors && d.errors.length ? `<div class="dmdnas-msg">${esc(d.errors.join(' · '))}</div>` : '';
            return `<div class="dmdnas-msg" data-msg></div>${err}${searchTools()}<div class="dmdnas-rows">${rows || row('Aucune donnée QTS reçue','QNAP','Clique sur Actualiser.','')}</div>`;
        }
        if (panel === 'qnap_storage') {
            const volumes = (d.storage || []).filter(v => String(v.type||'').toLowerCase() !== 'disk');
            const disks = (d.storage || []).filter(v => String(v.type||'').toLowerCase() === 'disk');
            const diskRows = disks.map(v => {
                const slot=first(v,['slot','disk_no','disk_number','id']); const model=first(v,['model','model_number','name'])||'Disque';
                const serial=first(v,['serial','serial_number']); const cap=first(v,['capacity','size','total_size']); const health=first(v,['health','status','smart_status']); const temp=first(v,['temperature','temp']); const smart=first(v,['smart','smart_status','selftest']);
                return row((slot!==''?'Disque '+slot+' — ':'')+model,'Disque physique',[serial!==''?'S/N : '+serial:'',cap!==''?'Capacité : '+cap:'',health!==''?'Santé : '+health:'',temp!==''?'Temp. : '+temp:'',smart!==''?'SMART : '+smart:''].filter(Boolean).join(' · '),'');
            }).join('');
            const volumeRows = volumes.map(v => {
                const name = first(v,['volume_name','name','text','volume_id','id']) || 'Volume QNAP';
                const unit=first(v,['volume_unit','unit'])||''; const fmt=x=>x!==''?(String(x)+(unit?' '+unit:'')):'';
                const cap = first(v,['capacity','total_size','size']); const free=first(v,['free_size','free','available']); const used=first(v,['used_size','used']);
                const state=first(v,['status','volume_status','state']); const pool=first(v,['pool_name','pool_id']); const raid=first(v,['raid_level']);
                return row(name,'Volume / pool',[cap!==''?'Capacité : '+fmt(cap):'',used!==''?'Utilisé : '+fmt(used):'',free!==''?'Libre : '+fmt(free):'',pool!==''?'Pool : '+pool:'',raid!==''?'RAID : '+raid:'',state!==''?'État : '+state:''].filter(Boolean).join(' · '),'');
            }).join('');
            const err = d.errors && d.errors.length ? `<div class="dmdnas-msg">${esc(d.errors.join(' · '))}</div>` : '';
            return `<div class="dmdnas-msg" data-msg></div>${err}${searchTools()}<h4>Disques physiques / SMART</h4><div class="dmdnas-rows">${diskRows || noRows()}</div><h4 style="margin-top:10px">Pools / volumes</h4><div class="dmdnas-rows">${volumeRows || noRows()}</div>`;
        }
        if (panel === 'qnap_network') {
            const net = d.network && typeof d.network === 'object' ? d.network : {};
            const ifaces = Array.isArray(net.interfaces) ? net.interfaces : [];
            const ifaceRows = ifaces.map(v => {
                const name=first(v,['display_name','name','id'])||'Interface'; const st=String(first(v,['status','link_status'])||'').toLowerCase();
                const ip=first(v,['ip','address']); const mask=first(v,['mask','netmask']); const mac=first(v,['mac']); const speed=first(v,['max_speed','speed']); const usage=first(v,['usage']); const rx=first(v,['rx']); const tx=first(v,['tx']);
                const meta=[st!==''?'État : '+(st==='up'?'connectée':(st==='down'?'déconnectée':st)):'',ip!==''?'IP : '+ip:'',mask!==''?'Masque : '+mask:'',mac!==''?'MAC : '+mac:'',speed!==''?'Vitesse max : '+speed+' Mb/s':'',usage!==''?'Utilisation : '+usage:'',rx!==''?'RX : '+rx:'',tx!==''?'TX : '+tx:''].filter(Boolean).join(' · ');
                return row(name,'Interface réseau QNAP',meta,'');
            }).join('');
            const general=[];
            if(net.default_gateway) general.push(row('Passerelle par défaut','Réseau QNAP',String(net.default_gateway),''));
            if(Array.isArray(net.dns) && net.dns.length) general.push(row('DNS','Réseau QNAP',net.dns.join(' · '),''));
            if(net.local_ip) general.push(row('IP locale','Réseau QNAP',String(net.local_ip),''));
            if(net.external_ip) general.push(row('IP externe','Réseau QNAP',String(net.external_ip),''));
            return `<div class="dmdnas-msg" data-msg></div>${searchTools()}<h4>Interfaces</h4><div class="dmdnas-rows">${ifaceRows || noRows()}</div>${general.length?`<h4 style="margin-top:10px">Paramètres réseau</h4><div class="dmdnas-rows">${general.join('')}</div>`:''}`;
        }
        if (panel === 'qnap_users') {
            const rows = d.users.map(v => { const name=first(v,['name','username','user','id'])||String(v||'Utilisateur'); return row(name,'Utilisateur QNAP','',''); }).join('');
            return `<div class="dmdnas-msg" data-msg></div>${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'qnap_groups') {
            const rows = d.groups.map(v => { const name=first(v,['name','groupname','group','id'])||String(v||'Groupe'); return row(name,'Groupe QNAP','',''); }).join('');
            return `<div class="dmdnas-msg" data-msg></div>${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'qnap_shares') {
            const rows = d.shares.map(v => { const name=first(v,['text','name','share_name','id'])||'Partage'; const path=first(v,['path','id']); const perm=first(v,['privilege','acl','cls']); const owner=first(v,['owner']); return row(name,'Partage QNAP',[path!==''?'Chemin : '+path:'',owner!==''?'Propriétaire : '+owner:'',perm!==''?'Accès : '+perm:''].filter(Boolean).join(' · '),''); }).join('');
            return `<div class="dmdnas-msg" data-msg></div>${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'qnap_packages') {
            const rows = d.packages.map(v => { const id=first(v,['name','Name','QPKG_NAME','id']); const name=first(v,['display_name','Display_Name','title'])||id||'Application'; const ver=first(v,['version','Version']); const st=first(v,['status','enabled','enable','Enable']); const act=id?`<button type="button" class="dmdnas-btn dmdnas-mini" data-qnap-package-act="enable" data-qnap-package="${esc(id)}">Activer / démarrer</button>`:''; return row(name,'App Center QNAP',[ver!==''?'Version : '+ver:'',st!==''?'État : '+st:''].filter(Boolean).join(' · '),act); }).join('');
            return `<div class="dmdnas-msg" data-msg></div>${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'qnap_docker') {
            const rows = [...d.containers.map(c => { const id=first(c,['id','container_id','name','container_name']); const type=first(c,['type','runtime'])||'docker'; const name=first(c,['name','container_name','id'])||'Container'; const state=first(c,['status','state']); const image=first(c,['image','image_name']); const key=id?(String(type)+':'+String(id)):''; const acts=key?`<button type="button" class="dmdnas-btn dmdnas-mini" data-qnap-container-act="start" data-qnap-container="${esc(key)}">Start</button><button type="button" class="dmdnas-btn dmdnas-mini" data-qnap-container-act="stop" data-qnap-container="${esc(key)}">Stop</button><button type="button" class="dmdnas-btn dmdnas-mini" data-qnap-container-act="restart" data-qnap-container="${esc(key)}">Restart</button><button type="button" class="dmdnas-btn dmdnas-mini dmdnas-danger" data-qnap-container-act="delete" data-qnap-container="${esc(key)}">Supprimer</button>`:''; return row(name,'Container Station',[image!==''?'Image : '+image:'',state!==''?'État : '+state:''].filter(Boolean).join(' · '),acts); }), ...d.images.map(x => row(first(x,['name','repository','id'])||'Image','Image QNAP',first(x,['tag','size','version'])||'',''))].join('');
            return `<div class="dmdnas-msg" data-msg></div>${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'installed' || panel === 'available') {
            const installed = panel === 'installed';
            const list = installed ? d.packages : d.available;
            const rows = list.map(p => {
                const id = pkgId(p);
                const name = pkgName(p);
                const st = packageState(p);
                const version = first(p, ['version','new_version','latest_version','id','package']);
                const sub = installed ? `${version || id || ''}` : (version || id || '');
                const desc = short(first(p, ['description','description_enu','desc','summary','maintainer']), 150);
                const statusTxt = installed
                    ? (st.state === 'on' ? 'Paquet actif' : (st.state === 'off' ? 'Paquet arrêté / désactivé' : 'DSM ne donne pas l’état via l’API Package'))
                    : desc;
                let actions = '<span class="dmdnas-chip">ID absent</span>';
                if (id) {
                    if (installed) {
                        let startBtn = '';
                        let stopBtn = '';
                        if (st.state === 'on') {
                            stopBtn = `<button type="button" class="dmdnas-btn dmdnas-mini" data-package-act="stop" data-package="${esc(id)}">Stop</button>`;
                        } else if (st.state === 'off') {
                            startBtn = `<button type="button" class="dmdnas-btn dmdnas-mini" data-package-act="start" data-package="${esc(id)}">Start</button>`;
                        } else {
                            startBtn = `<button type="button" class="dmdnas-btn dmdnas-mini" data-package-act="start" data-package="${esc(id)}">Start</button>`;
                            stopBtn = `<button type="button" class="dmdnas-btn dmdnas-mini" data-package-act="stop" data-package="${esc(id)}">Stop</button>`;
                        }
                        actions = `${packageStateBadge(st)}${startBtn}${stopBtn}<button type="button" class="dmdnas-btn dmdnas-mini" data-package-act="uninstall" data-package="${esc(id)}">Désinstaller</button>`;
                    } else {
                        const already = packageIsInstalled(p, d.packages);
                        actions = already ? '<span class="dmdnas-state on">Déjà installé</span>' : `<button type="button" class="dmdnas-btn dmdnas-mini" data-package-install data-package="${esc(id)}" data-package-name="${esc(name)}">Installer</button>`;
                    }
                }
                return row(name, sub, installed ? statusTxt : desc, actions, [name, sub, desc, st.label].join(' '));
            }).join('');
            return `<div class="dmdnas-msg" data-msg></div>${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'docker') {
            const rows = [
                ...d.containers.map(c => { const name = first(c, ['name','id','container','container_name']) || 'container'; const text = first(c, ['image','image_name','repo','repository','status','state']); return row(name, 'Container', text, `<button type="button" class="dmdnas-btn dmdnas-mini" data-container-act="start" data-container="${esc(name)}">Start</button><button type="button" class="dmdnas-btn dmdnas-mini" data-container-act="stop" data-container="${esc(name)}">Stop</button><button type="button" class="dmdnas-btn dmdnas-mini" data-container-act="restart" data-container="${esc(name)}">Restart</button>`); }),
                ...d.images.map(img => { const name = first(img, ['name','id','repo','repository']) || 'image'; return row(name, 'Image installée', first(img, ['tag','version','size','status']), ''); }),
                ...d.registry.map(img => { const name = first(img, ['name','title','id','repo','repository']) || 'image'; return row(name, 'Recherche Docker', short(first(img, ['description','desc']), 150), `<button type="button" class="dmdnas-btn dmdnas-mini" data-image-act="pull" data-image="${esc(name)}">Télécharger</button>`); })
            ].join('');
            const hint = rows ? '' : '<div class="dmdnas-msg">Docker est installé, mais l’audit DSM indique que SYNO.Docker.* répond code 114 avec ce compte/API. Le module n’invente pas de containers.</div>';
            return `<div class="dmdnas-msg" data-msg></div>${hint}<div class="dmdnas-tools"><input type="search" data-docker-query placeholder="Rechercher une image Docker"><button type="button" class="dmdnas-btn" data-docker-search>Rechercher / actualiser</button></div><div class="dmdnas-tools"><input type="search" data-filter-input placeholder="Filtrer l'affichage..."></div><div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'users') {
            const form = '<div class="dmdnas-formline"><input data-user-name placeholder="Nouvel utilisateur"><input data-user-pass type="password" placeholder="Mot de passe"><button type="button" class="dmdnas-btn" data-user-create>Créer</button></div>';
            const rows = d.users.map(u => {
                const name = userName(u);
                return row(name, 'Utilisateur DSM', detailText(u, ['email','description','expired','disabled','enable','type']) || 'Utilisateur DSM', `<button type="button" class="dmdnas-btn dmdnas-mini" data-user-groups data-user="${esc(name)}">Groupes</button><button type="button" class="dmdnas-btn dmdnas-mini" data-user-act="disable" data-user="${esc(name)}">Désactiver</button><button type="button" class="dmdnas-btn dmdnas-mini" data-user-act="delete" data-user="${esc(name)}">Supprimer</button>`);
            }).join('');
            return `<div class="dmdnas-msg" data-msg></div>${form}${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'groups') {
            const form = '<div class="dmdnas-formline"><input data-group-name placeholder="Nouveau groupe"><input data-group-desc placeholder="Description"><button type="button" class="dmdnas-btn" data-group-create>Créer</button></div>';
            const rows = d.groups.map(g => {
                const name = groupName(g);
                return row(name, 'Groupe DSM', detailText(g, ['description','members','member_count','gid']) || 'Groupe DSM', `<button type="button" class="dmdnas-btn dmdnas-mini" data-group-members data-group="${esc(name)}">Membres</button><button type="button" class="dmdnas-btn dmdnas-mini" data-group-act="delete" data-group="${esc(name)}">Supprimer</button>`);
            }).join('');
            return `<div class="dmdnas-msg" data-msg></div>${form}${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'shares') {
            const volumes = getVolumes(i);
            const volumeHelp = volumes.length ? 'Volumes détectés depuis DSM.' : 'Aucun volume détaillé renvoyé par DSM : le module tentera quand même la création avec le volume choisi si disponible.';
            const createBox = `<div class="dmdnas-share-box"><h4>Créer un partage DSM</h4><div class="dmdnas-formline dmdnas-formline-share"><select data-share-volume>${volumeOptions(i, '')}</select><input data-share-name placeholder="Nom du partage DSM"><input data-share-desc placeholder="Description"><button type="button" class="dmdnas-btn" data-share-create>Créer le partage</button></div><div class="dmdnas-share-note">${esc(volumeHelp)} Les partages existants restent modifiables, supprimables, et les droits s’ouvrent avec le bouton Droits.</div></div>`;
            const rows = d.shares.map(x => {
                const name = shareName(x);
                const volume = shareVolume(x) || 'volume non renvoyé';
                const path = sharePath(x) || 'chemin non renvoyé';
                const desc = shareDesc(x) || 'description non renvoyée';
                const st = shareStatus(x);
                const text = `Volume : ${volume} | Chemin : ${path} | État : ${st} | ${desc}`;
                const actions = `<button type="button" class="dmdnas-btn dmdnas-mini" data-share-edit data-share="${esc(name)}">Modifier</button><button type="button" class="dmdnas-btn dmdnas-mini" data-share-perms data-share="${esc(name)}">Droits</button><button type="button" class="dmdnas-btn dmdnas-mini" data-share-act="delete" data-share="${esc(name)}">Supprimer</button>`;
                return row(name, 'Dossier partagé DSM', text, actions, [name, volume, path, st, desc].join(' '));
            }).join('');
            return `<div class="dmdnas-msg" data-msg></div>${createBox}${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        if (panel === 'services') {
            const rows = d.services.map(x => {
                const name = first(x, ['name','share_name','service_name','id']) || 'Élément';
                const port = first(x, ['port']);
                const url = first(x, ['url']);
                const text = first(x, ['path','status','enable','enabled','description','desc']) || detailText(x, ['uuid','size','type']) || (port ? 'Port ' + port : '');
                const act = url ? `<a class="dmdnas-btn dmdnas-mini" href="${esc(url)}" target="_blank" rel="noopener">Ouvrir</a>` : '';
                return row(name, port ? 'Service détecté · port ' + port : 'Service détecté', text, act);
            }).join('');
            return `<div class="dmdnas-msg" data-msg>Lecture basée sur le scan réseau quand SYNO.Core.Service.list est refusé par DSM.</div>${searchTools()}<div class="dmdnas-rows">${rows || noRows()}</div>`;
        }
        return '<div class="dmdnas-msg" data-msg>Indisponible.</div>';
    }

    function userName(u){return first(u, ['name','username','user','uid']) || 'user';}
    function groupName(g){return first(g, ['name','groupname','group','gid']) || 'group';}
    function namesSet(list){const set = new Set(); (Array.isArray(list) ? list : []).forEach(v => set.add(norm(typeof v === 'string' ? v : first(v, ['name','username','user','uid','group','groupname'])))); return set;}
    function membershipRows(item, mode, target, knownNames, known){
        const d = dsm(item);
        const source = mode === 'group' ? d.users.map(userName) : d.groups.map(groupName);
        const set = namesSet(knownNames || []);
        const rows = source.map(name => {
            const inIt = known ? set.has(norm(name)) : false;
            const text = known ? (inIt ? (mode === 'group' ? 'Membre de ce groupe' : 'Utilisateur dans ce groupe') : 'Non membre') : 'DSM ne renvoie pas la liste complète : action possible quand même';
            const add = `<button type="button" class="dmdnas-btn dmdnas-mini" data-member-op="add" data-member-name="${esc(name)}">Ajouter</button>`;
            const remove = `<button type="button" class="dmdnas-btn dmdnas-mini" data-member-op="remove" data-member-name="${esc(name)}">Retirer</button>`;
            const actions = known ? (inIt ? remove : add) : (add + remove);
            return row(name, mode === 'group' ? 'Utilisateur DSM' : 'Groupe DSM', text, actions, [name, text].join(' '));
        }).join('');
        return `<div class="dmdnas-tools"><input type="search" data-filter-input placeholder="Rechercher..."><button type="button" class="dmdnas-btn" data-members-refresh>Actualiser</button></div><div class="dmdnas-rows" data-members-list>${rows || noRows()}</div>`;
    }
    function openGroupMembers(item, group){
        const html = `<div class="dmdnas-msg" data-msg>Chargement des membres...</div>${membershipRows(item, 'group', group, [], false)}`;
        const w = makeWin('Membres du groupe', `${item.name || 'NAS'} · ${group}`, html, `group-members-${keyOf(item)}-${group}`, '760px');
        w.dataset.itemKey = keyOf(item); w.dataset.mode = 'group'; w.dataset.group = group;
        bindMembership(w); refreshMembership(w);
    }
    function openUserGroups(item, user){
        const html = `<div class="dmdnas-msg" data-msg>Chargement des groupes...</div>${membershipRows(item, 'user', user, [], false)}`;
        const w = makeWin('Groupes de l’utilisateur', `${item.name || 'NAS'} · ${user}`, html, `user-groups-${keyOf(item)}-${user}`, '760px');
        w.dataset.itemKey = keyOf(item); w.dataset.mode = 'user'; w.dataset.user = user;
        bindMembership(w); refreshMembership(w);
    }
    async function refreshMembership(w){
        let i = findByKey(w.dataset.itemKey); if (!i) return;
        const body = w.querySelector('.dmdnas-win-body');
        const mode = w.dataset.mode;
        const target = mode === 'group' ? w.dataset.group : w.dataset.user;
        const action = mode === 'group' ? 'dsm_group_members' : 'dsm_user_groups';
        const extra = mode === 'group' ? {group:target} : {user:target};
        try {
            setWinMsg(body, 'Lecture DSM...');
            const j = await callApi(action, i, extra);
            const known = j.known !== false;
            const names = mode === 'group' ? (j.members || []) : (j.groups || []);
            const updated = findByKey(w.dataset.itemKey) || i;
            body.dataset.bound = '0';
            body.innerHTML = `<div class="dmdnas-msg" data-msg></div>${membershipRows(updated, mode, target, names, known)}`;
            bindMembership(w);
            setWinMsg(body, j.message || 'Liste chargée.');
        } catch(err) { setWinMsg(body, friendlyError(err.message || String(err), action, extra)); }
    }
    function bindMembership(w){
        const body = w.querySelector('.dmdnas-win-body');
        if (!body || body.dataset.bound === '1') return;
        body.dataset.bound = '1';
        body.addEventListener('input', e => {
            const input = e.target.closest('[data-filter-input]');
            if (!input) return;
            const q = norm(input.value);
            body.querySelectorAll('[data-filter]').forEach(r => r.classList.toggle('dmdnas-hidden', q && !r.dataset.filter.includes(q)));
        });
        body.addEventListener('click', async e => {
            const refresh = e.target.closest('[data-members-refresh]');
            if (refresh) { e.preventDefault(); await refreshMembership(w); return; }
            const btn = e.target.closest('[data-member-op]');
            if (!btn || !body.contains(btn)) return;
            e.preventDefault();
            let i = findByKey(w.dataset.itemKey); if (!i) return;
            const mode = w.dataset.mode;
            const name = btn.dataset.memberName || '';
            const op = btn.dataset.memberOp || '';
            const group = mode === 'group' ? (w.dataset.group || '') : name;
            const user = mode === 'group' ? name : (w.dataset.user || '');
            btn.disabled = true;
            try {
                setWinMsg(body, (op === 'add' ? 'Ajout' : 'Retrait') + ' en cours...');
                const j = await callApi('dsm_group_member_action', i, {op, group, user});
                if (j.item) { i = j.item; w.dataset.itemKey = keyOf(i); }
                setWinMsg(body, j.message || 'Action envoyée.');
                await refreshMembership(w);
            } catch(err) { setWinMsg(body, friendlyError(err.message || String(err), 'dsm_group_member_action', {op, group, user})); }
            finally { btn.disabled = false; growPage(); }
        });
        const rb = w.querySelector('[data-win-refresh]');
        if (rb && !rb.dataset.membersBound) { rb.dataset.membersBound='1'; rb.onclick = async e => { e.preventDefault(); await refreshMembership(w); }; }
    }

    function openShareEdit(item, share){
        const current = (dsm(item).shares || []).find(x => shareName(x).toLowerCase() === String(share).toLowerCase()) || {};
        const html = `<div class="dmdnas-msg" data-msg></div><div class="dmdnas-formline dmdnas-formline-share"><input data-edit-current value="${esc(share)}" readonly><input data-edit-name value="${esc(shareName(current) === 'Partage' ? share : shareName(current))}" placeholder="Nouveau nom"><input data-edit-desc value="${esc(shareDesc(current))}" placeholder="Description"><button type="button" class="dmdnas-btn" data-share-save>Enregistrer</button></div>`;
        const w = makeWin('Modifier partage — nom / description', `${item.name || 'NAS'} · ${share}`, html, `share-edit-${keyOf(item)}-${share}`, '680px');
        w.dataset.itemKey = keyOf(item);
        w.dataset.share = share;
        const body = w.querySelector('.dmdnas-win-body');
        if (body.dataset.bound === '1') return;
        body.dataset.bound = '1';
        body.addEventListener('click', async e => {
            const btn = e.target.closest('[data-share-save]');
            if (!btn) return;
            e.preventDefault();
            let i = findByKey(w.dataset.itemKey);
            if (!i) return;
            btn.disabled = true;
            try {
                setWinMsg(body, 'Modification du partage...');
                let j = await callApi('dsm_share_action', i, {op:'modify', share:w.dataset.share || '', new_name:(body.querySelector('[data-edit-name]')||{}).value||'', description:(body.querySelector('[data-edit-desc]')||{}).value||''});
                i = j.item || i;
                w.dataset.itemKey = keyOf(i);
                setWinMsg(body, j.message || 'Partage modifié.');
            } catch(err) { setWinMsg(body, friendlyError(err.message || String(err), 'dsm_share_action', {op:'modify'})); }
            finally { btn.disabled = false; }
        });
    }
    function renderPermRows(list){
        const rows = (Array.isArray(list) ? list : []).map(p => row(permName(p), permType(p) || 'Permission', permValue(p) || detailText(p, Object.keys(p || {})), '')).join('');
        return `<div class="dmdnas-rows">${rows || noRows()}</div>`;
    }
    function openSharePerms(item, share){
        const html = `<div class="dmdnas-msg" data-msg>Chargement des droits...</div><div class="dmdnas-formline dmdnas-formline-perm"><input data-perm-principal placeholder="Utilisateur ou groupe"><select data-perm-type><option value="user">Utilisateur</option><option value="group">Groupe</option></select><select data-perm-value><option value="read_write">Lecture/écriture</option><option value="read_only">Lecture seule</option><option value="no_access">Aucun accès</option></select><button type="button" class="dmdnas-btn" data-perm-set>Appliquer</button></div><div data-perm-list></div>`;
        const w = makeWin('Droits du partage — lecture / écriture / aucun accès', `${item.name || 'NAS'} · ${share}`, html, `share-perms-${keyOf(item)}-${share}`, '760px');
        w.dataset.itemKey = keyOf(item);
        w.dataset.share = share;
        const body = w.querySelector('.dmdnas-win-body');
        async function loadPerms(){
            let i = findByKey(w.dataset.itemKey);
            if (!i) return;
            try {
                const j = await callApi('dsm_share_acl', i, {share:w.dataset.share || ''});
                setWinMsg(body, j.message || 'Droits chargés.');
                const list = body.querySelector('[data-perm-list]');
                if (list) list.innerHTML = renderPermRows(j.permissions || j.raw || []);
            } catch(err) { setWinMsg(body, friendlyError(err.message || String(err), 'dsm_share_acl', {})); }
        }
        if (body.dataset.bound !== '1') {
            body.dataset.bound = '1';
            body.addEventListener('click', async e => {
                const btn = e.target.closest('[data-perm-set]');
                if (!btn) return;
                e.preventDefault();
                let i = findByKey(w.dataset.itemKey);
                if (!i) return;
                btn.disabled = true;
                try {
                    setWinMsg(body, 'Application des droits...');
                    const j = await callApi('dsm_share_perm_action', i, {share:w.dataset.share || '', principal:(body.querySelector('[data-perm-principal]')||{}).value||'', principal_type:(body.querySelector('[data-perm-type]')||{}).value||'user', permission:(body.querySelector('[data-perm-value]')||{}).value||'read_only'});
                    setWinMsg(body, j.message || 'Droits envoyés.');
                    await loadPerms();
                } catch(err) { setWinMsg(body, friendlyError(err.message || String(err), 'dsm_share_perm_action', {})); }
                finally { btn.disabled = false; }
            });
        }
        loadPerms();
    }

    function extraFieldsHtml(fields){
        fields = Array.isArray(fields) ? fields : [];
        if (!fields.length) return '';
        return '<div class="dmdnas-panel"><h4>Champs demandés par ce paquet</h4>' + fields.map(f => {
            const name = esc(f.name || '');
            const label = esc(f.label || f.name || 'Champ');
            const type = String(f.type || 'text').toLowerCase();
            const def = esc(f.default || '');
            const opts = Array.isArray(f.options) ? f.options : [];
            if (opts.length) {
                return `<label>${label}<select data-extra-field="${name}" data-extra-type="select">${opts.map(o => `<option value="${esc(o.value ?? o.label ?? '')}"${String(o.value ?? '')===String(f.default ?? '')?' selected':''}>${esc(o.label ?? o.value ?? '')}</option>`).join('')}</select></label>`;
            }
            if (['checkbox','bool','boolean'].includes(type)) {
                const checked = ['1','true','yes','on'].includes(String(f.default || '').toLowerCase()) ? ' checked' : '';
                return `<label>${label}<input type="checkbox" data-extra-field="${name}" data-extra-type="checkbox"${checked}></label>`;
            }
            if (['password','passwd'].includes(type)) {
                return `<label>${label}<input type="password" data-extra-field="${name}" data-extra-type="password" value="${def}"></label>`;
            }
            if (['textarea','textbox'].includes(type)) {
                return `<label>${label}<textarea data-extra-field="${name}" data-extra-type="textarea">${def}</textarea></label>`;
            }
            return `<label>${label}<input data-extra-field="${name}" data-extra-type="text" placeholder="${esc(type || 'valeur')}" value="${def}"></label>`;
        }).join('') + '</div>';
    }
    function dsmAdminUrl(item){
        let u = String((item && (item.admin_url || item.api_url)) || '').trim();
        if (!u && item && item.ip) u = (item.protocol || 'http') + '://' + item.ip + (item.admin_port ? ':' + item.admin_port : '');
        if (!u) return '';
        return u.replace(/\/webapi\/.*$/i, '').replace(/\/+$/,'');
    }
    function dsmPackageCenterUrl(item){
        const base = dsmAdminUrl(item);
        if (!base) return '';
        return base + '/?launchApp=SYNO.SDS.PkgManApp.Instance';
    }
    function openNativeDsmInstaller(item, packageId, packageName){
        const url = dsmPackageCenterUrl(item);
        const label = packageName || packageId || 'paquet';
        if (!url) {
            makeWin('Assistant DSM natif', label, '<div class="dmdnas-msg">URL DSM absente dans la configuration du NAS.</div>', `dsm-native-${keyOf(item)}-${packageId}`, '620px');
            return;
        }
        const html = `<div class="dmdnas-msg">Assistant DSM natif pour installer ${esc(label)}. Utilise Package Center DSM : c’est lui qui affiche les vrais champs spécifiques du paquet.</div><iframe class="dmdnas-dsm-frame" src="${esc(url)}"></iframe><div class="dmdnas-install-hint">Si DSM bloque l’affichage intégré, clique le bouton ci-dessous.</div><div class="dmdnas-buttons"><a class="dmdnas-btn" href="${esc(url)}" target="_blank" rel="noopener">Ouvrir DSM</a></div>`;
        makeWin('Package Center DSM', `${item.name || 'NAS'} · ${label}`, html, `dsm-native-${keyOf(item)}-${packageId}`, '860px');
    }
    function readExtraJson(body){
        const fields = {};
        body.querySelectorAll('[data-extra-field]').forEach(inp => {
            const k = inp.dataset.extraField;
            if (!k) return;
            if (inp.dataset.extraType === 'checkbox') fields[k] = !!inp.checked;
            else fields[k] = inp.value;
        });
        let raw = (body.querySelector('[data-install-extra]') || {}).value || '';
        raw = raw.trim();
        let fromText = {};
        if (raw && raw !== '{}') {
            try { fromText = JSON.parse(raw); } catch(e) { throw new Error('Le champ extra_values doit être un JSON valide.'); }
            if (!fromText || typeof fromText !== 'object' || Array.isArray(fromText)) throw new Error('extra_values doit être un objet JSON, pas une liste.');
        }
        return JSON.stringify(Object.assign({}, fromText, fields));
    }
    function renderInstallBody(item, known, loading){
        known = known || {};
        const fields = Array.isArray(known.fields) ? known.fields : [];
        const volume = known.volume_path || '';
        const hasFields = fields.length > 0;
        const title = hasFields ? 'DSM demande des paramètres supplémentaires.' : 'Installation directe depuis DMD-NAS';
        const rawHint = known.raw_message ? `<div class="dmdnas-install-hint">${esc(known.raw_message)}</div>` : '';
        const jsonBox = hasFields
            ? `<details><summary>Paramètres avancés (extra_values)</summary><label>JSON extra_values<textarea data-install-extra placeholder='{"cle":"valeur"}'>${esc(known.example || '{}')}</textarea></label></details>`
            : '<textarea data-install-extra hidden>{}</textarea>';
        return `<div class="dmdnas-msg" data-msg>${esc(title)}</div><div class="dmdnas-install-grid"><label>Volume DSM<select data-install-volume>${volumeOptions(item, volume, known)}</select></label>${extraFieldsHtml(fields)}${jsonBox}${rawHint}<div class="dmdnas-buttons"><button type="button" class="dmdnas-btn" data-install-send${loading?' disabled':''}>${loading?'Installation en cours...':'Installer'}</button></div></div>`;
    }
    function bindInstallWindow(w, parentWin){
        const body = w.querySelector('.dmdnas-win-body');
        if (!body || body.dataset.installBound === '1') return;
        body.dataset.installBound = '1';
        body.addEventListener('click', async e => {
            const sendBtn = e.target.closest('[data-install-send]');
            if (!sendBtn) return;
            e.preventDefault();
            let i = findByKey(w.dataset.itemKey);
            if (!i) return;
            sendBtn.disabled = true;
            sendBtn.textContent = 'Installation en cours...';
            try {
                const extraValues = readExtraJson(body);
                setWinMsg(body, 'DSM télécharge le paquet puis lance son installation...');
                let j = await callApi('dsm_package_action', i, {
                    op:'install',
                    package:w.dataset.package || '',
                    volume:(body.querySelector('[data-install-volume]')||{}).value||'',
                    extra_values:extraValues
                });
                i = j.item || i;
                setWinMsg(body, j.message || 'Installation lancée.');
                await callApi('dsm_packages', i, {});
                if (parentWin) await refreshPanel(parentWin);
            } catch(err) {
                const raw = err && err.payload && err.payload.raw ? err.payload.raw : null;
                if (raw && raw.extra_required) {
                    body.dataset.installBound = '0';
                    body.innerHTML = renderInstallBody(i, raw, false);
                    bindInstallWindow(w, parentWin);
                } else {
                    setWinMsg(body, friendlyError(err.message || String(err), 'dsm_package_action', {op:'install'}));
                    if (raw) {
                        const detail = document.createElement('details');
                        detail.innerHTML = `<summary>Détails DSM</summary><pre>${esc(JSON.stringify(raw,null,2))}</pre>`;
                        body.appendChild(detail);
                    }
                }
            } finally {
                const currentBtn = body.querySelector('[data-install-send]');
                if (currentBtn) { currentBtn.disabled = false; currentBtn.textContent = 'Installer'; }
                growPage();
            }
        });
    }
    function openPackageInstall(item, packageId, packageName, parentWin, known){
        known = known || {};
        const html = renderInstallBody(item, known, false);
        const w = makeWin('Installer un paquet DSM', `${item.name || 'NAS'} · ${packageName || packageId}`, html, `install-${keyOf(item)}-${packageId}`, '620px');
        w.dataset.itemKey = keyOf(item);
        w.dataset.package = packageId;
        w.dataset.parentPanelKey = parentWin ? (parentWin.dataset.key || '') : '';
        bindInstallWindow(w, parentWin);
    }


    function arrOf(v, keys=[]){
        if(Array.isArray(v)) return v;
        if(v && typeof v==='object') for(const k of keys){ if(Array.isArray(v[k])) return v[k]; }
        return [];
    }
    function humanBytes(v){ let n=Number(v); if(!isFinite(n)||n<=0)return String(v??''); const units=['o','Ko','Mo','Go','To','Po']; let i=0; while(n>=1024&&i<units.length-1){n/=1024;i++;} return (i? n.toFixed(n>=10?1:2):Math.round(n))+' '+units[i]; }
    function statusBadge(v){ const s=String(v??'inconnu'); return `<span class="dmdnas-badge">${esc(s)}</span>`; }
    function metric(label,val){ return `<div class="dmdnas-admin-metric"><span>${esc(label)}</span><strong>${esc(String(val??'—'))}</strong></div>`; }
    function card(title,meta,body,actions=''){ return `<article class="dmdnas-admin-card"><div class="dmdnas-admin-card-head"><div><strong>${esc(title)}</strong>${meta?`<small>${esc(meta)}</small>`:''}</div></div><div class="dmdnas-admin-card-body">${body}</div>${actions?`<div class="dmdnas-admin-card-actions">${actions}</div>`:''}</article>`; }
    function storageHtml(data){
        const s=data.sections||{}, legacy=s.storage||{};
        const pools=arrOf(s.storage_pools,['pools','items','storagePools']).length?arrOf(s.storage_pools,['pools','items','storagePools']):arrOf(legacy,['storagePools','pools']);
        const vols=arrOf(s.storage_volumes,['volumes','items']).length?arrOf(s.storage_volumes,['volumes','items']):arrOf(legacy,['volumes']);
        const disks=arrOf(s.storage_disks,['disks','items']).length?arrOf(s.storage_disks,['disks','items']):arrOf(legacy,['disks']);
        const diskIds=disks.map((x,i)=>first(x,['id','disk_id','device','dev'])||String(i+1)).join(',');
        let html=`<div class="dmdnas-msg" data-msg></div>
        <div class="dmdnas-editor"><div class="dmdnas-editor-title">Créer un pool</div><div class="dmdnas-editor-grid"><select data-new-pool-raid><option value="shr">SHR</option><option value="raid1">RAID 1</option><option value="raid5">RAID 5</option><option value="raid6">RAID 6</option><option value="raid10">RAID 10</option><option value="basic">Basic</option><option value="jbod">JBOD</option></select><input data-new-pool-disks value="${esc(diskIds)}" placeholder="Disques, séparés par des virgules"></div><div class="dmdnas-buttons"><button class="dmdnas-btn" data-pool-create>Créer le pool</button></div><div class="dmdnas-note">Action destructive potentielle : vérifie la sélection des disques avant validation.</div></div>`;
        html+=`<h4>Pools</h4><div class="dmdnas-admin-grid">`+(pools.length?pools.map((x,i)=>{const id=first(x,['id','pool_id','poolId','space_id'])||String(i+1);const st=first(x,['status','state','raid_status'])||'—';const raid=first(x,['raid_type','raidType','type'])||'—';const total=first(x,['total_size','size_total','size']);const used=first(x,['used_size','size_used']);return card('Pool '+id,raid,metric('État',st)+metric('Taille',humanBytes(total))+metric('Utilisé',humanBytes(used)),`<button class="dmdnas-btn dmdnas-mini" data-pool-volume-create="${esc(id)}">Créer un volume</button><button class="dmdnas-btn dmdnas-mini dmdnas-danger" data-pool-delete="${esc(id)}">Supprimer le pool</button>`)}).join(''):'<div class="dmdnas-msg">Aucun pool détecté.</div>')+'</div>';
        html+=`<h4>Volumes</h4><div class="dmdnas-admin-grid">`+(vols.length?vols.map((x,i)=>{const path=first(x,['volume_path','vol_path','path','id'])||('/volume'+(i+1));const st=first(x,['status','state'])||'—';const fs=first(x,['fs_type','filesystem','type'])||'—';const total=first(x,['total_size','size_total','size']);const free=first(x,['free_size','size_free','avail']);return card(path,fs,metric('État',st)+metric('Taille',humanBytes(total))+metric('Libre',humanBytes(free)),`<button class="dmdnas-btn dmdnas-mini dmdnas-danger" data-volume-delete="${esc(path)}">Supprimer le volume</button>`)}).join(''):'<div class="dmdnas-msg">Aucun volume détecté.</div>')+'</div>';
        html+=`<h4>Disques</h4><div class="dmdnas-admin-grid">`+(disks.length?disks.map((x,i)=>{const id=first(x,['id','disk_id','device','dev'])||String(i+1);const model=first(x,['model','model_name'])||'Disque';const st=first(x,['status','health','state'])||'—';const temp=first(x,['temp','temperature']);const size=first(x,['size','total_size']);return card(model,id,metric('Santé',st)+metric('Temp.',temp?temp+' °C':'—')+metric('Taille',humanBytes(size)),`<button class="dmdnas-btn dmdnas-mini" data-disk-fw="${esc(id)}">Firmware</button>`)}).join(''):'<div class="dmdnas-msg">Aucun disque détecté.</div>')+'</div>';
        html+=`<div class="dmdnas-admin-toolbar"><button class="dmdnas-btn" data-storage-op="storage_scrub">Nettoyage des données</button><button class="dmdnas-btn" data-storage-op="storage_scan">Analyse disques</button></div>`;
        return html;
    }
    function networkHtml(data){
        const s=data.sections||{}, net=s.network||{}; const ifs=arrOf(s.network_interfaces,['interfaces','nif','items']).length?arrOf(s.network_interfaces,['interfaces','nif','items']):arrOf(net,['nif','interfaces']);
        let html=`<div class="dmdnas-msg" data-msg></div><div class="dmdnas-editor"><div class="dmdnas-editor-title">Paramètres généraux</div><div class="dmdnas-editor-grid"><input data-net-hostname value="${esc(first(net,['hostname'])||'')}" placeholder="Hostname"><input data-net-dns value="${esc(Array.isArray(net.dns)?net.dns.join(','):(net.dns||''))}" placeholder="DNS (séparés par virgules)"><input data-net-workgroup value="${esc(first(net,['workgroup'])||'')}" placeholder="Workgroup"></div><div class="dmdnas-buttons"><button class="dmdnas-btn" data-net-save>Appliquer</button></div></div>`;
        html+=`<h4>Interfaces réseau</h4><div class="dmdnas-admin-grid">`+(ifs.length?ifs.map((x,i)=>{const id=first(x,['id','name','ifname','dev'])||('eth'+i);const ip=first(x,['addr','ip','ipv4','address'])||'';const mask=first(x,['netmask','mask'])||'';const gw=first(x,['gateway'])||'';const mac=first(x,['mac','mac_address'])||'';const mtu=first(x,['mtu'])||1500;const dhcp=!!(x.use_dhcp||x.dhcp||x.useDhcp);return card(id,mac,metric('IP',ip)+metric('Masque',mask)+metric('Passerelle',gw)+metric('MTU',mtu),`<button class="dmdnas-btn dmdnas-mini" data-net-edit="${esc(id)}" data-net-ip="${esc(ip)}" data-net-mask="${esc(mask)}" data-net-gw="${esc(gw)}" data-net-mtu="${esc(mtu)}" data-net-dhcp="${dhcp?'1':'0'}">Configurer</button>`)}).join(''):'<div class="dmdnas-msg">Aucune interface détectée.</div>')+'</div>';
        return html;
    }
    function simpleObjectCards(v,title='Informations'){
        if(v===null||v===undefined)return '<div class="dmdnas-empty-inline">Information non renvoyée par DSM.</div>';
        if(Array.isArray(v)){
            if(!v.length)return '<div class="dmdnas-empty-inline">Aucun élément.</div>';
            return `<div class="dmdnas-admin-grid">${v.slice(0,30).map((x,i)=>{ if(typeof x!=='object') return card(String(x),'','',''); const name=first(x,['name','title','id','hostname','service_name'])||('Élément '+(i+1)); const scal=Object.entries(x).filter(([k,val])=>val===null||['string','number','boolean'].includes(typeof val)).slice(0,6); return card(name,'',scal.map(([k,val])=>metric(k,val)).join(''));}).join('')}</div>`;
        }
        if(typeof v!=='object') return `<div class="dmdnas-admin-summary">${metric(title,v)}</div>`;
        const scal=Object.entries(v).filter(([k,val])=>val===null||['string','number','boolean'].includes(typeof val)).slice(0,18);
        const summary=scal.length?`<div class="dmdnas-admin-summary">${scal.map(([k,val])=>metric(k,val)).join('')}</div>`:'<div class="dmdnas-empty-inline">Aucune valeur synthétique.</div>';
        return summary+`<details class="dmdnas-tech"><summary>Détails techniques</summary><pre>${esc(JSON.stringify(v,null,2))}</pre></details>`;
    }

    function adminPanelHtml(panel,data,item){
        const s=data.sections||{}, e=data.errors||{};
        if(panel==='admin_storage') return storageHtml(data);
        if(panel==='admin_network') return networkHtml(data);
        if(panel==='admin_system') {
            const sys=s.system||{}, h=s.health||{}, u=s.utilization||{};
            const cpu=u.cpu||u.cpu_usage||{}, mem=u.memory||u.mem||{};
            const cpuPct=first(cpu,['user_load','system_load','other_load','load','usage'])||first(u,['cpu_usage','cpu_load']);
            const memPct=first(mem,['real_usage','usage','percent'])||first(u,['memory_usage']);
            const summary=`<div class="dmdnas-admin-summary">${metric('Modèle',first(sys,['model','support_model'])||'—')}${metric('DSM',first(sys,['firmware_ver','firmware','version'])||'—')}${metric('Nom',first(sys,['servername','hostname'])||'—')}${metric('N° série',first(sys,['serial','serial_num'])||'—')}${metric('CPU',first(sys,['cpu_series','cpu_family','cpu_vendor'])||'—')}${metric('Cœurs',first(sys,['cpu_cores'])||'—')}${metric('CPU utilisé',cpuPct!==''?cpuPct:'—')}${metric('RAM utilisée',memPct!==''?memPct:'—')}${metric('Uptime',first(sys,['up_time','uptime'])||'—')}${metric('Santé',first(h,['status','health','overall_status'])||'—')}</div>`;
            return `<div class="dmdnas-msg" data-msg></div>${summary}<section class="dmdnas-panel"><h4>Hibernation</h4><div class="dmdnas-formline"><input type="number" min="0" data-hib-int placeholder="Disques internes (minutes)"><input type="number" min="0" data-hib-usb placeholder="USB (minutes)"><button class="dmdnas-btn" data-hib-save>Appliquer</button></div></section>`;
        }
        if(panel==='admin_updates') return `<div class="dmdnas-msg compact" data-msg></div><div class="dmdnas-action-strip"><button type="button" class="dmdnas-btn primary" data-admin-update-check>Rechercher une mise à jour</button><button class="dmdnas-btn" data-smart-nano="1">Auto : ON</button><button class="dmdnas-btn" data-smart-nano="0">Auto : OFF</button></div><section class="dmdnas-section"><h4>État DSM</h4>${simpleObjectCards(s.upgrade)}</section><section class="dmdnas-section"><h4>Configuration</h4>${simpleObjectCards(s.upgrade_settings)}</section>`;
        if(panel==='admin_security') return `<div class="dmdnas-msg compact" data-msg></div><div class="dmdnas-editor compact-editor"><div class="dmdnas-editor-title">SSH</div><div class="dmdnas-inline-form"><input type="number" min="1" max="65535" value="22" data-ssh-port><button class="dmdnas-btn primary" data-ssh="1">Activer</button><button class="dmdnas-btn" data-ssh="0">Désactiver</button></div></div><section class="dmdnas-section"><h4>Certificats</h4>${simpleObjectCards(s.certificates)}</section><section class="dmdnas-section"><h4>AutoBlock</h4>${simpleObjectCards(s.autoblock)}</section><section class="dmdnas-section"><h4>Pare-feu</h4>${simpleObjectCards(s.firewall)}</section>`;
        if(panel==='admin_tasks') {
            const tasks=arrOf(s.tasks,['tasks','items','list']);
            const create=`<div class="dmdnas-editor"><div class="dmdnas-editor-title">Créer une tâche script quotidienne</div><div class="dmdnas-editor-grid"><input data-task-name placeholder="Nom"><input data-task-owner value="root" placeholder="Propriétaire"><input type="time" data-task-time value="03:00"></div><textarea data-task-script placeholder="Commande / script"></textarea><div class="dmdnas-buttons"><button class="dmdnas-btn" data-task-create>Créer</button></div></div>`;
            const rows=tasks.map((t,i)=>{const id=first(t,['id','task_id'])||String(i+1);const name=first(t,['name','task_name'])||('Tâche '+id);const owner=first(t,['real_owner','owner'])||'root';const enabled=String(first(t,['enable','enabled'])).toLowerCase()!=='false';const extra=(t.extra&&typeof t.extra==='object')?t.extra:{};const script=first(extra,['script','command'])||first(t,['script','command'])||'';return card(name,'#'+id,metric('Propriétaire',owner)+metric('État',enabled?'Activée':'Désactivée')+metric('Prochaine exécution',first(t,['next_trigger_time','next_run'])||'—'),`<button class="dmdnas-btn dmdnas-mini" data-task-edit="${esc(id)}" data-owner="${esc(owner)}" data-task-name0="${esc(name)}" data-task-script0="${esc(script)}">Modifier</button><button class="dmdnas-btn dmdnas-mini" data-task-op="task_run" data-task-id="${esc(id)}" data-owner="${esc(owner)}">Exécuter</button><button class="dmdnas-btn dmdnas-mini" data-task-op="${enabled?'task_disable':'task_enable'}" data-task-id="${esc(id)}" data-owner="${esc(owner)}">${enabled?'Désactiver':'Activer'}</button><button class="dmdnas-btn dmdnas-mini dmdnas-danger" data-task-op="task_delete" data-task-id="${esc(id)}" data-owner="${esc(owner)}">Supprimer</button>`)}).join('');
            return `<div class="dmdnas-msg" data-msg></div>${create}<h4>Tâches</h4><div class="dmdnas-admin-grid">${rows||'<div class="dmdnas-msg">Aucune tâche.</div>'}</div>`;
        }
        if(panel==='admin_activity') return `<section class="dmdnas-section"><h4>Notifications DSM</h4>${simpleObjectCards(s.notifications)}</section><section class="dmdnas-section"><h4>Sessions / fichiers ouverts</h4>${simpleObjectCards(s.file_handles)}</section>`;
        if(panel==='admin_power') return `<div class="dmdnas-msg" data-msg>Actions immédiates sur ${esc(item.name||'le NAS')}.</div><div class="dmdnas-buttons"><button class="dmdnas-btn" data-power="reboot">Redémarrer le NAS</button><button class="dmdnas-btn" data-power="shutdown">Arrêter le NAS</button></div>`;
        return '<div class="dmdnas-msg">Section indisponible.</div>';
    }
    async function openAdminPanel(item,panel){
        const w=makeWin(panelTitle(panel),item.name||'NAS','<div class="dmdnas-msg" data-msg>Lecture DSM en cours...</div>',panel+'-'+keyOf(item),'900px');
        w.dataset.itemKey=keyOf(item); w.dataset.panel=panel;
        await refreshAdminPanel(w);
        const rb=w.querySelector('[data-win-refresh]'); if(rb) rb.onclick=async e=>{e.preventDefault(); await refreshAdminPanel(w);};
    }
    async function refreshAdminPanel(w){
        let item=findByKey(w.dataset.itemKey); if(!item)return; const body=w.querySelector('.dmdnas-win-body');
        try{ body.innerHTML='<div class="dmdnas-msg" data-msg>Lecture DSM en cours...</div>'; const scope=(w.dataset.panel||'admin_system').replace('admin_',''); const j=await callApi('dsm_admin_snapshot',item,{scope}); w.__adminData=j.admin||{}; body.innerHTML=adminPanelHtml(w.dataset.panel,w.__adminData,item); bindAdminPanel(w); }
        catch(err){ body.innerHTML=`<div class="dmdnas-msg" data-msg>${esc(friendlyError(err.message||String(err),'dsm_admin_snapshot',{}))}</div>`; }
        growPage();
    }
    function bindAdminPanel(w){
        const body=w.querySelector('.dmdnas-win-body'); if(!body||body.dataset.adminBound==='1')return; body.dataset.adminBound='1';
        body.addEventListener('click',async e=>{
            let item=findByKey(w.dataset.itemKey); if(!item)return; let action='',extra={}; const btn=e.target.closest('button'); if(!btn)return;
            if(btn.dataset.power){ if(!confirm((btn.dataset.power==='shutdown'?'Arrêter':'Redémarrer')+' '+(item.name||'le NAS')+' ?'))return; action='dsm_admin_power'; extra={op:btn.dataset.power}; }
            else if(btn.dataset.ssh!==undefined){ action='dsm_admin_ssh'; extra={enabled:btn.dataset.ssh,port:(body.querySelector('[data-ssh-port]')||{}).value||22}; }
            else if(btn.hasAttribute('data-admin-update-check')){ action='dsm_admin_update'; }
            else if(btn.dataset.smartNano!==undefined){ action='dsm_admin_updates_manage'; extra={enabled:btn.dataset.smartNano}; }
            else if(btn.hasAttribute('data-hib-save')){ action='dsm_admin_system_manage'; extra={internal_hd_idletime:(body.querySelector('[data-hib-int]')||{}).value||0,usb_idletime:(body.querySelector('[data-hib-usb]')||{}).value||0}; }
            else if(btn.dataset.storageOp){ if(!confirm('Lancer cette opération de stockage ?'))return; action='dsm_admin_storage'; extra={op:btn.dataset.storageOp}; }
            else if(btn.dataset.poolSave){ action='dsm_admin_storage'; extra={op:'storage_pool_desc',pool_id:btn.dataset.poolSave,description:(body.querySelector('[data-pool-desc="'+CSS.escape(btn.dataset.poolSave)+'"]')||{}).value||''}; }
            else if(btn.dataset.volumeSave){ action='dsm_admin_storage'; extra={op:'storage_volume_desc',volume_path:btn.dataset.volumeSave,description:(body.querySelector('[data-volume-desc="'+CSS.escape(btn.dataset.volumeSave)+'"]')||{}).value||''}; }
            else if(btn.dataset.diskFw){ if(!confirm('Lancer la mise à jour firmware du disque '+btn.dataset.diskFw+' ?'))return; action='dsm_admin_storage'; extra={op:'storage_disk_fw',disk_id:btn.dataset.diskFw}; }
            else if(btn.hasAttribute('data-pool-create')){ if(!confirm('Créer ce pool avec les disques indiqués ? Cette opération peut effacer les disques sélectionnés.'))return; action='dsm_admin_storage'; extra={op:'storage_pool_create',raid_type:(body.querySelector('[data-new-pool-raid]')||{}).value||'shr',disks:(body.querySelector('[data-new-pool-disks]')||{}).value||''}; }
            else if(btn.dataset.poolDelete){ if(!confirm('SUPPRIMER le pool '+btn.dataset.poolDelete+' ? Les données peuvent être perdues.'))return; action='dsm_admin_storage'; extra={op:'storage_pool_delete',pool_id:btn.dataset.poolDelete}; }
            else if(btn.dataset.poolVolumeCreate){ const fs=prompt('Système de fichiers du volume (btrfs ou ext4)','btrfs'); if(!fs)return; const size=prompt('Taille (laisser vide pour tout l’espace disponible)',''); action='dsm_admin_storage'; extra={op:'storage_volume_create',pool_id:btn.dataset.poolVolumeCreate,fs_type:fs,size:size||''}; }
            else if(btn.dataset.volumeDelete){ if(!confirm('SUPPRIMER le volume '+btn.dataset.volumeDelete+' ? Toutes les données du volume seront perdues.'))return; action='dsm_admin_storage'; extra={op:'storage_volume_delete',volume_path:btn.dataset.volumeDelete}; }
            else if(btn.dataset.netEdit){ const dhcp=confirm('Utiliser DHCP pour '+btn.dataset.netEdit+' ?\nOK = DHCP / Annuler = IP statique'); let address='',netmask='',gateway=''; if(!dhcp){address=prompt('Adresse IPv4',btn.dataset.netIp||'')||'';netmask=prompt('Masque',btn.dataset.netMask||'255.255.255.0')||'';gateway=prompt('Passerelle',btn.dataset.netGw||'')||'';} const mtu=prompt('MTU',btn.dataset.netMtu||'1500')||'1500'; action='dsm_admin_network'; extra={op:'network_interface_set',interface:btn.dataset.netEdit,dhcp:dhcp?'1':'0',address,netmask,gateway,mtu}; }
            else if(btn.dataset.copyNet){ const sec=(w.__adminData||{}).sections||{}; navigator.clipboard?.writeText(JSON.stringify(sec.network_interfaces||sec.network||{},null,2)); setWinMsg(body,'Détails réseau copiés.'); return; }
            else if(btn.hasAttribute('data-task-create')){ action='dsm_admin_task'; const time=(body.querySelector('[data-task-time]')||{}).value||'03:00'; extra={op:'task_create',name:(body.querySelector('[data-task-name]')||{}).value||'',owner:(body.querySelector('[data-task-owner]')||{}).value||'root',script:(body.querySelector('[data-task-script]')||{}).value||'',time}; }
            else if(btn.dataset.taskEdit){ const name=prompt('Nom de la tâche',btn.dataset.taskName0||'')||''; if(!name)return; const script=prompt('Commande / script',btn.dataset.taskScript0||'')||''; if(!script)return; const time=prompt('Heure quotidienne (HH:MM)','03:00')||'03:00'; action='dsm_admin_task'; extra={op:'task_edit',task_id:btn.dataset.taskEdit,owner:btn.dataset.owner||'root',name,script,time}; }
            else if(btn.dataset.taskOp){ if(btn.dataset.taskOp==='task_delete'&&!confirm('Supprimer cette tâche planifiée ?'))return; action='dsm_admin_task'; extra={op:btn.dataset.taskOp,task_id:btn.dataset.taskId||'',owner:btn.dataset.owner||'root'}; }
            else if(btn.hasAttribute('data-net-save')){ action='dsm_admin_network'; extra={hostname:(body.querySelector('[data-net-hostname]')||{}).value||'',dns:(body.querySelector('[data-net-dns]')||{}).value||'',workgroup:(body.querySelector('[data-net-workgroup]')||{}).value||''}; }
            else return;
            e.preventDefault(); btn.disabled=true; setWinMsg(body,'Action DSM en cours...');
            try{const j=await callApi(action,item,extra); await refreshAdminPanel(w); setWinMsg(w.querySelector('.dmdnas-win-body'),j.message||'Action envoyée.');}
            catch(err){setWinMsg(body,friendlyError(err.message||String(err),action,extra));}
            finally{btn.disabled=false;growPage();}
        });
    }

    function openPanel(i, panel){
        const w = makeWin(panelTitle(panel), i.name || 'NAS', '<div class="dmdnas-msg" data-msg>Chargement...</div>', `panel-${panel}-${keyOf(i)}`, '780px');
        w.dataset.itemKey = keyOf(i);
        w.dataset.panel = panel;
        const rb = w.querySelector('[data-win-refresh]');
        rb.onclick = async e => { e.preventDefault(); await refreshPanel(w); };
        // Les panneaux issus du dernier refresh DSM restent immédiatement utilisables.
        // Le réseau/API ne doit jamais remplacer toute la fenêtre par "Actualisation...".
        if (['users','groups','shares','services'].includes(panel)) {
            const body = w.querySelector('.dmdnas-win-body');
            body.innerHTML = panelHtml(i, panel);
            bindPanel(w);
            setWinMsg(body, 'Données du dernier rafraîchissement DSM. Utilise Refresh pour relire le NAS.');
        } else {
            bindPanel(w);
            refreshPanel(w);
        }
    }
    async function refreshPanel(w){
        const body = w.querySelector('.dmdnas-win-body');
        let i = findByKey(w.dataset.itemKey);
        const panel = w.dataset.panel;
        if (!i) return;
        const rb = w.querySelector('[data-win-refresh]'); if(rb) rb.disabled=true;
        try {
            body.innerHTML = '<div class="dmdnas-msg" data-msg>Actualisation...</div>';
            let j = null;
            if (panel === 'installed' || panel === 'available') j = await callApi('dsm_packages', i, {});
            else if (panel === 'docker') j = await callApi('dsm_docker', i, {});
            else if (panel === 'shares') j = await callApi('dsm_shares_list', i, {});
            else if (['users','groups','services'].includes(panel)) j = await callApi('dsm_refresh', i, {});
            else if (['qnap_system','qnap_storage','qnap_network','qnap_users','qnap_groups','qnap_shares','qnap_packages'].includes(panel)) j = await callApi('qnap_refresh', i, {});
            else if (panel === 'qnap_docker') j = await callApi('qnap_docker', i, {});
            if (j && j.item) i = j.item;
            w.dataset.itemKey = keyOf(i);
            body.dataset.bound = '0';
            body.innerHTML = panelHtml(i, panel);
            bindPanel(w);
            setWinMsg(body, (j && j.message) ? j.message : 'Actualisé.');
        } catch(err) { body.innerHTML = '<div class="dmdnas-msg" data-msg>'+esc(friendlyError(err.message || String(err), 'refresh_panel', {}))+'</div>' + panelHtml(i, panel); bindPanel(w); }
        finally { if(rb) rb.disabled=false; growPage(); }
    }
    function bindPanel(w){
        const body = w.querySelector('.dmdnas-win-body');
        if (!body || body.dataset.bound === '1') return;
        body.dataset.bound = '1';
        body.addEventListener('input', e => {
            const input = e.target.closest('[data-filter-input]');
            if (!input) return;
            const q = norm(input.value);
            body.querySelectorAll('[data-filter]').forEach(r => r.classList.toggle('dmdnas-hidden', q && !r.dataset.filter.includes(q)));
        });
        body.addEventListener('click', async e => {
            let i = findByKey(w.dataset.itemKey);
            if (!i) return;
            const btn = e.target.closest('button');
            if (!btn || !body.contains(btn)) return;
            let action = null, extra = {}, refreshAfter = null;
            if (btn.hasAttribute('data-panel-refresh')) { await refreshPanel(w); return; }
            if (btn.hasAttribute('data-docker-search')) { action='dsm_docker'; extra={query:(body.querySelector('[data-docker-query]')||{}).value||''}; refreshAfter='docker'; }
            if (btn.hasAttribute('data-package-install')) { openPackageInstall(i, btn.dataset.package || '', btn.dataset.packageName || btn.dataset.package || '', w); return; }
            if (btn.hasAttribute('data-package-act')) { action='dsm_package_action'; extra={op:btn.dataset.packageAct||'', package:btn.dataset.package||''}; refreshAfter='packages'; }
            if (btn.hasAttribute('data-container-act')) { action='dsm_container_action'; extra={op:btn.dataset.containerAct||'', container:btn.dataset.container||''}; refreshAfter='docker'; }
            if (btn.hasAttribute('data-image-act')) { action='dsm_image_action'; extra={op:btn.dataset.imageAct||'pull', image:btn.dataset.image||''}; refreshAfter='docker'; }
            if (btn.hasAttribute('data-user-create')) { action='dsm_user_action'; extra={op:'create', user:(body.querySelector('[data-user-name]')||{}).value||'', password:(body.querySelector('[data-user-pass]')||{}).value||''}; refreshAfter='refresh'; }
            if (btn.hasAttribute('data-user-act')) { action='dsm_user_action'; extra={op:btn.dataset.userAct||'', user:btn.dataset.user||''}; refreshAfter='refresh'; }
            if (btn.hasAttribute('data-group-create')) { action='dsm_group_action'; extra={op:'create', group:(body.querySelector('[data-group-name]')||{}).value||'', description:(body.querySelector('[data-group-desc]')||{}).value||''}; refreshAfter='refresh'; }
            if (btn.hasAttribute('data-group-act')) { action='dsm_group_action'; extra={op:btn.dataset.groupAct||'', group:btn.dataset.group||''}; refreshAfter='refresh'; }
            if (btn.hasAttribute('data-user-groups')) { openUserGroups(i, btn.dataset.user || ''); return; }
            if (btn.hasAttribute('data-group-members')) { openGroupMembers(i, btn.dataset.group || ''); return; }
            if (btn.hasAttribute('data-share-create')) { action='dsm_share_action'; extra={op:'create', share:(body.querySelector('[data-share-name]')||{}).value||'', volume:(body.querySelector('[data-share-volume]')||{}).value||'', description:(body.querySelector('[data-share-desc]')||{}).value||''}; refreshAfter='refresh'; }
            if (btn.hasAttribute('data-share-act')) { const op=btn.dataset.shareAct||''; const share=btn.dataset.share||''; if((op==='delete'||op==='remove') && !confirm('Supprimer le partage '+share+' ?')) return; action='dsm_share_action'; extra={op, share}; refreshAfter='refresh'; }
            if (btn.hasAttribute('data-share-edit')) { openShareEdit(i, btn.dataset.share || ''); return; }
            if (btn.hasAttribute('data-share-perms')) { openSharePerms(i, btn.dataset.share || ''); return; }
            if (btn.hasAttribute('data-qnap-package-act')) { action='qnap_package_action'; extra={op:btn.dataset.qnapPackageAct||'enable', package:btn.dataset.qnapPackage||''}; refreshAfter='qnap_refresh'; }
            if (btn.hasAttribute('data-qnap-container-act')) { const op=btn.dataset.qnapContainerAct||''; if(op==='delete'&&!confirm('Supprimer ce conteneur QNAP ?')) return; action='qnap_container_action'; extra={op, container:btn.dataset.qnapContainer||''}; refreshAfter='qnap_docker'; }
            if (!action) return;
            e.preventDefault(); btn.disabled=true;
            try {
                setWinMsg(body, 'Action en cours...');
                let j = await callApi(action, i, extra);
                i = j.item || i;
                if (refreshAfter === 'packages') j = await callApi('dsm_packages', i, {});
                if (refreshAfter === 'docker') j = await callApi('dsm_docker', i, {});
                if (refreshAfter === 'refresh') j = (w.dataset.panel === 'shares') ? await callApi('dsm_shares_list', i, {}) : await callApi('dsm_refresh', i, {});
                if (refreshAfter === 'qnap_refresh') j = await callApi('qnap_refresh', i, {});
                if (refreshAfter === 'qnap_docker') j = await callApi('qnap_docker', i, {});
                i = j.item || i;
                w.dataset.itemKey = keyOf(i);
                body.dataset.bound = '0';
                body.innerHTML = panelHtml(i, w.dataset.panel);
                bindPanel(w);
                setWinMsg(body, j.message || 'Action terminée.');
            } catch(err) { setWinMsg(body, friendlyError(err.message || String(err), action, extra)); }
            finally { btn.disabled=false; growPage(); }
        });
    }

    root.addEventListener('click', async e => {
        const toggler = e.target.closest('[data-toggle-vendor]');
        if (toggler) { openVendor = openVendor === toggler.dataset.toggleVendor ? null : toggler.dataset.toggleVendor; render(); return; }
        const row = e.target.closest('[data-nas-key]');
        if (row) { const i = findByKey(row.dataset.nasKey); if (i) openSheet(i); return; }
        const refresh = e.target.closest('[data-refresh-list]');
        if (refresh) { refresh.disabled=true; try{ msg('Rafraîchissement...'); await reloadItems(); msg(''); } catch(err){ msg(friendlyError(err.message || String(err), 'list', {})); } finally{ refresh.disabled=false; } }
    });
    render();
})();
</script>
