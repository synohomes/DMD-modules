<?php
/**
 * DoMyDesk - dmd_nas_api.php
 * API stable du module dmd_nas.
 */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
require_once __DIR__ . '/dmd_nas_lib.php';
dmd_nas_boot_core();
dmd_nas_boot_storage();

header('Content-Type: application/json; charset=utf-8');

$vendors = [
    'synology' => 'Synology',
    'qnap' => 'QNAP',
    'asustor' => 'ASUSTOR',
    'truenas' => 'TrueNAS',
    'omv' => 'OpenMediaVault',
    'other' => 'Autre'
];

function dmd_nas_json($ok, $message = '', $extra = []) {
    echo json_encode(array_merge(['ok' => (bool)$ok, 'message' => $message], $extra), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function dmd_nas_email() {
    return trim((string)($_SESSION['email'] ?? $_SESSION['user_email'] ?? ($_SESSION['user']['email'] ?? '')));
}
function dmd_nas_is_admin() {
    $rs = strtolower((string)($_SESSION['role_system'] ?? ($_SESSION['user']['role_system'] ?? '')));
    $r = strtolower((string)($_SESSION['role'] ?? ($_SESSION['user']['role'] ?? '')));
    return in_array($rs, ['admin','administrator','superadmin'], true) || in_array($r, ['admin','administrator','superadmin'], true);
}
function dmd_nas_slug($v) {
    $v = trim((string)$v);
    $v = str_replace(['\\','/','..'], '-', $v);
    $v = preg_replace('/[^a-zA-Z0-9_\-.]+/', '-', $v);
    $v = trim($v, '-_.');
    return $v !== '' ? strtolower($v) : '';
}
function dmd_nas_vendor($v, $vendors) {
    $v = strtolower(trim((string)$v));
    return isset($vendors[$v]) ? $v : 'other';
}
function dmd_nas_root() {
    $root = realpath(__DIR__ . '/../..');
    return $root ?: dirname(__DIR__, 2);
}
function dmd_nas_storage_root($storage = 'private', $email = null) {
    $email = $email ?: dmd_nas_email();
    if ($email === '') return null;
    return dmd_nas_root() . '/users/profiles/' . $email . '/dmd_nas';
}
function dmd_nas_file_path($id, $vendor, $storage, $vendors) {
    $id = dmd_nas_slug($id);
    $vendor = dmd_nas_vendor($vendor, $vendors);
    $root = dmd_nas_storage_root($storage);
    if (!$root || $id === '') return null;
    return $root . '/' . $vendor . '/' . $id . '.json';
}
function dmd_nas_read_file($file, $storage, $vendor, $vendors) {
    if (!is_file($file)) return null;
    $j = json_decode((string)file_get_contents($file), true);
    if (!is_array($j)) return null;
    $j['id'] = dmd_nas_slug($j['id'] ?? pathinfo($file, PATHINFO_FILENAME));
    $j['vendor'] = dmd_nas_vendor($j['vendor'] ?? $vendor, $vendors);
    $j['vendor_label'] = $vendors[$j['vendor']] ?? 'Autre';
    $j['storage_mode'] = $storage;
    $j['enabled'] = array_key_exists('enabled', $j) ? (bool)$j['enabled'] : true;
    return $j;
}
function dmd_nas_public_item($item) {
    $saved = !empty($item['api_pass_enc']) || !empty($item['api_pass']);
    unset($item['api_pass'], $item['api_pass_enc']);
    $item['api_password_saved'] = $saved;
    $item['resource'] = array('type'=>'nas','id'=>'dmd-nas:nas:'.($item['id'] ?? ''),'label'=>$item['name'] ?? ($item['id'] ?? ''),'source'=>DMD_NAS_MODULE_ID,'tags'=>array_filter(array('nas',$item['vendor'] ?? '',$item['api_type'] ?? '')));
    return $item;
}
function dmd_nas_collect_items_from_root($root, $storage, $vendors, &$seen) {
    $out = [];
    if (!$root || !is_dir($root)) return $out;
    foreach ($vendors as $vk => $vl) {
        $dir = $root . '/' . $vk;
        if (!is_dir($dir)) continue;
        foreach (glob($dir . '/*.json') ?: [] as $file) {
            $key = realpath($file) ?: $file;
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $item = dmd_nas_read_file($file, $storage, $vk, $vendors);
            if ($item) $out[] = dmd_nas_public_item($item);
        }
    }
    return $out;
}
function dmd_nas_list_items($vendors) {
    $items = [];
    $seen = [];
    $items = array_merge($items, dmd_nas_collect_items_from_root(dmd_nas_storage_root('private'), 'private', $vendors, $seen));
    usort($items, fn($a,$b) => strcasecmp((string)($a['name'] ?? ''), (string)($b['name'] ?? '')));
    return $items;
}
function dmd_nas_log($action, $item = [], $extra = []) {
    $dir = dmd_nas_storage_root('private') . '/logs';
    if (!is_dir($dir)) @mkdir($dir, 0770, true);
    $line = ['date'=>date('Y-m-d H:i:s'),'user'=>dmd_nas_email(),'action'=>$action,'nas'=>$item['name'] ?? ($item['id'] ?? ''),'storage'=>'private','extra'=>$extra];
    @file_put_contents($dir . '/dmd_nas.log', json_encode($line, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL, FILE_APPEND|LOCK_EX);
}
function dmd_nas_crypto_key() {
    $dir = dmd_nas_storage_root('private') . '/secure';
    if (!is_dir($dir)) @mkdir($dir, 0770, true);
    $ht=$dir.'/.htaccess'; if (!is_file($ht)) @file_put_contents($ht,"Require all denied
Deny from all
");
    $file=$dir.'/dmd_nas.key';
    if (!is_file($file)) { @file_put_contents($file,base64_encode(random_bytes(32)),LOCK_EX); @chmod($file,0600); }
    $raw=trim((string)@file_get_contents($file)); $bin=base64_decode($raw,true);
    return ($bin!==false && strlen($bin)===32) ? $bin : hash('sha256',$raw,true);
}
function dmd_nas_encrypt_secret($plain) {
    $plain = (string)$plain;
    if ($plain === '') return '';
    if (!function_exists('openssl_encrypt')) return 'plain:' . base64_encode($plain);
    $key = dmd_nas_crypto_key();
    $iv = random_bytes(16);
    $cipher = openssl_encrypt($plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    if ($cipher === false) return '';
    $mac = hash_hmac('sha256', $iv . $cipher, $key);
    return 'enc:v1:' . base64_encode($iv) . ':' . base64_encode($cipher) . ':' . $mac;
}
function dmd_nas_decrypt_secret($enc) {
    $enc = (string)$enc;
    if ($enc === '') return '';
    if (substr($enc, 0, 6) === 'plain:') return (string)base64_decode(substr($enc, 6));
    if (substr($enc, 0, 7) !== 'enc:v1:') return $enc; // compat anciens JSON si besoin
    $parts = explode(':', $enc, 5);
    if (count($parts) !== 5) return '';
    [, , $iv64, $cipher64, $mac] = $parts;
    $iv = base64_decode($iv64, true);
    $cipher = base64_decode($cipher64, true);
    if (!is_string($iv) || !is_string($cipher)) return '';
    $key = dmd_nas_crypto_key();
    $calc = hash_hmac('sha256', $iv . $cipher, $key);
    if (!hash_equals($calc, $mac)) return '';
    $plain = openssl_decrypt($cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
    return $plain === false ? '' : $plain;
}
function dmd_nas_get_api_pass($item) {
    if (!empty($item['api_pass_enc'])) return dmd_nas_decrypt_secret((string)$item['api_pass_enc']);
    // compat uniquement pour les vieux JSON. Dès sauvegarde, on ne réécrit plus ce champ en clair.
    return (string)($item['api_pass'] ?? '');
}
function dmd_nas_save_item($item, $vendors) {
    $item['vendor'] = dmd_nas_vendor($item['vendor'] ?? 'other', $vendors);
    $item['vendor_label'] = $vendors[$item['vendor']] ?? 'Autre';
    $item['storage_mode'] = 'private';
    
    $id = dmd_nas_slug($item['id'] ?? '');
    if ($id === '') $id = 'nas-' . date('YmdHis');
    $item['id'] = $id;
    $file = dmd_nas_file_path($item['id'], $item['vendor'], $item['storage_mode'], $vendors);
    if (!$file) dmd_nas_json(false, 'Chemin JSON impossible.');
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0775, true)) dmd_nas_json(false, 'Impossible de créer le dossier : ' . $dir);
    if (!is_writable($dir)) dmd_nas_json(false, 'Dossier non inscriptible : ' . $dir);
    $old = is_file($file) ? json_decode((string)file_get_contents($file), true) : [];
    if (!is_array($old)) $old = [];
    $now = date('Y-m-d H:i:s');
    $item = array_merge($old, $item);
    unset($item['api_pass']);
    $item['created_at'] = $old['created_at'] ?? $now;
    $item['updated_at'] = $now;
    if (@file_put_contents($file, json_encode($item, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) === false) {
        dmd_nas_json(false, 'Écriture JSON impossible : ' . $file);
    }
    dmd_nas_log('save', $item, ['file' => $file]);
    dmd_nas_core_event('nas.saved', array('type'=>'nas','id'=>'dmd-nas:nas:'.$item['id'],'label'=>$item['name'],'source'=>DMD_NAS_MODULE_ID), array('vendor'=>$item['vendor'],'storage'=>$item['storage_mode']));
    return $item;
}
function dmd_nas_find_item($id, $vendor, $storage, $vendors, &$file = null) {
    $file = dmd_nas_file_path($id, $vendor, $storage, $vendors);
    if (!$file || !is_file($file)) return null;
    return dmd_nas_read_file($file, $storage === 'public' ? 'public' : 'private', $vendor, $vendors);
}
function dmd_nas_tcp_check($host, $port, $timeout = 1.3) {
    $host = trim((string)$host);
    $port = (int)$port;
    if ($host === '' || $port < 1) return false;
    $errno = 0; $errstr = '';
    $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
    if ($fp) { fclose($fp); return true; }
    return false;
}
function dmd_nas_known_ports($vendor) {
    $base = [
        22 => ['SSH', null, 'Administration distante'],
        80 => ['HTTP', 'http', 'Web HTTP'],
        443 => ['HTTPS', 'https', 'Web HTTPS'],
        139 => ['NetBIOS', null, 'Partage Windows ancien'],
        445 => ['SMB', null, 'Partage fichiers Windows'],
        8080 => ['HTTP alt', 'http', 'Interface web alternative'],
        8443 => ['HTTPS alt', 'https', 'Interface web alternative sécurisée'],
    ];
    if ($vendor === 'synology') {
        $base += [
            5000 => ['Synology DSM HTTP', 'http', 'Interface DSM'],
            5001 => ['Synology DSM HTTPS', 'https', 'Interface DSM sécurisée'],
            5005 => ['WebDAV HTTP', 'http', 'WebDAV'],
            5006 => ['WebDAV HTTPS', 'https', 'WebDAV sécurisé'],
            6690 => ['Synology Drive', null, 'Synology Drive'],
            32400 => ['Plex', 'http', 'Plex Media Server'],
            8096 => ['Jellyfin', 'http', 'Jellyfin'],
            9000 => ['Portainer', 'http', 'Portainer'],
        ];
    }
    if ($vendor === 'qnap') {
        $base += [
            8080 => ['QNAP HTTP', 'http', 'Interface QTS'],
            443 => ['QNAP HTTPS', 'https', 'Interface QTS sécurisée'],
            8081 => ['QNAP HTTPS alt', 'https', 'Interface QTS sécurisée'],
            32400 => ['Plex', 'http', 'Plex Media Server'],
            8096 => ['Jellyfin', 'http', 'Jellyfin'],
        ];
    }
    ksort($base);
    return $base;
}
function dmd_nas_http_get_json($url, $timeout = 8) {
    $ctx = stream_context_create([
        'http' => ['timeout' => $timeout, 'ignore_errors' => true],
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
    ]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) return [false, null, 'HTTP impossible : ' . $url];
    $j = json_decode($raw, true);
    if (!is_array($j)) return [false, null, 'Réponse non JSON : ' . substr($raw, 0, 180)];
    return [true, $j, ''];
}


/* Chargement des connecteurs constructeurs.
   Pour ajouter un constructeur plus tard : créer simplement qnap.php, asustor.php, truenas.php...
   Convention : dmd_nas_{constructeur}_refresh(), dmd_nas_{constructeur}_packages(), etc. */
foreach (['synology','qnap','asustor','truenas','omv','other'] as $dmdNasVendorConnector) {
    $dmdNasVendorFile = __DIR__ . '/' . $dmdNasVendorConnector . '.php';
    if (is_file($dmdNasVendorFile)) {
        require_once $dmdNasVendorFile;
    }
}

$action = strtolower((string)($_POST['action'] ?? $_GET['action'] ?? ''));
$permissionMap = array(
    'ping'=>'module.view','list'=>'nas.list','probe_config'=>'nas.test','save'=>'nas.edit','delete'=>'nas.delete','test'=>'nas.test','check'=>'nas.test','scan'=>'nas.scan','scanner'=>'nas.scan',
    'add_application'=>'nas.edit','add_app'=>'nas.edit','add_docker'=>'nas.edit','add_share'=>'nas.shares.manage',
    'dsm_refresh'=>'nas.refresh','qnap_refresh'=>'nas.refresh','dsm_packages'=>'nas.apps.view','qnap_packages'=>'nas.apps.view','dsm_package_prepare_install'=>'nas.apps.manage','dsm_package_action'=>'nas.apps.manage',
    'dsm_docker'=>'nas.containers.view','qnap_docker'=>'nas.containers.view','dsm_container_action'=>'nas.containers.manage','qnap_container_action'=>'nas.containers.manage','qnap_package_action'=>'nas.apps.manage','qnap_user_action'=>'nas.users.manage','qnap_group_action'=>'nas.groups.manage','qnap_share_action'=>'nas.shares.manage','qnap_share_acl_action'=>'nas.shares.permissions','dsm_image_action'=>'nas.containers.manage',
    'dsm_user_action'=>'nas.users.manage','dsm_group_action'=>'nas.groups.manage','dsm_group_members'=>'nas.groups.view','dsm_user_groups'=>'nas.users.view','dsm_group_member_action'=>'nas.groups.manage',
    'dsm_api_audit'=>'nas.audit','dsm_admin_snapshot'=>'nas.system.view','dsm_admin_power'=>'nas.power.manage','dsm_admin_ssh'=>'nas.security.manage','dsm_admin_update'=>'nas.updates.view','dsm_admin_task'=>'nas.tasks.manage','dsm_admin_storage'=>'nas.storage.manage','dsm_admin_updates_manage'=>'nas.updates.manage','dsm_admin_system_manage'=>'nas.system.manage','dsm_admin_network'=>'nas.network.manage','dsm_shares_list'=>'nas.shares.view','dsm_share_action'=>'nas.shares.manage','dsm_share_acl'=>'nas.shares.view','dsm_share_perm_action'=>'nas.shares.permissions'
);
if ($action === 'save') {
    $originalId = dmd_nas_slug($_POST['original_id'] ?? '');
    dmd_nas_require($originalId === '' ? 'nas.create' : 'nas.edit', true);
} else {
    dmd_nas_require($permissionMap[$action] ?? 'module.view', true);
}
if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) === 'POST') dmd_nas_require_csrf(true);
if ($action === 'ping') {
    dmd_nas_json(true, 'API dmd_nas OK', ['debug' => ['session_email'=>dmd_nas_email(),'api_file'=>__FILE__,'module_dir'=>__DIR__,'domydesk_root'=>dmd_nas_root(),'method'=>$_SERVER['REQUEST_METHOD'] ?? '']]);
}
if ($action === '') dmd_nas_json(false, 'Action manquante');

if ($action === 'list') dmd_nas_json(true, 'OK', ['items' => dmd_nas_list_items($vendors)]);

if ($action === 'probe_config') {
    $vendor = dmd_nas_vendor($_POST['vendor'] ?? 'other', $vendors);
    $protocol = strtolower((string)($_POST['protocol'] ?? 'http')) === 'https' ? 'https' : 'http';
    $ip = trim((string)($_POST['ip'] ?? ''));
    $host = trim((string)($_POST['hostname'] ?? ''));
    $target = $ip !== '' ? $ip : $host;
    $port = trim((string)($_POST['admin_port'] ?? ''));
    if ($port === '') $port = $vendor === 'qnap' ? ($protocol === 'https' ? '443' : '8080') : ($protocol === 'https' ? '5001' : '5000');
    $base = trim((string)($_POST['api_url'] ?? ''));
    if ($base === '' && $target !== '') $base = $protocol.'://'.$target.($port !== '' ? ':'.$port : '');
    $probe = [
        'vendor'=>$vendor, 'api_type'=>$vendor === 'qnap' ? 'qnap' : ($vendor === 'synology' ? 'synology' : strtolower((string)($_POST['api_type'] ?? 'none'))),
        'api_url'=>$base, 'api_user'=>trim((string)($_POST['api_user'] ?? '')),
        'protocol'=>$protocol, 'ip'=>$ip, 'hostname'=>$host, 'admin_port'=>$port
    ];
    $pass = (string)($_POST['api_pass'] ?? '');
    if ($pass !== '') $probe['api_pass_enc'] = dmd_nas_encrypt_secret($pass);
    if ($target === '') dmd_nas_json(false, 'IP ou hostname obligatoire pour tester le NAS.');
    if ($vendor === 'qnap') {
        if ($probe['api_user'] === '' || $pass === '') dmd_nas_json(false, 'Utilisateur et mot de passe QNAP obligatoires pour le premier test.');
        list($ok,$data,$msg) = dmd_nas_qnap_refresh($probe);
        dmd_nas_json($ok, $msg ?: ($ok ? 'Connexion QNAP réussie.' : 'Connexion QNAP impossible.'), ['data'=>$data]);
    }
    if ($vendor === 'synology') {
        if ($probe['api_user'] === '' || $pass === '') dmd_nas_json(false, 'Utilisateur et mot de passe Synology obligatoires pour le premier test.');
        list($ok,$data,$msg) = dmd_nas_synology_refresh($probe);
        dmd_nas_json($ok, $msg ?: ($ok ? 'Connexion Synology réussie.' : 'Connexion Synology impossible.'), ['data'=>$data]);
    }
    dmd_nas_json(false, 'Test API non disponible pour ce constructeur.');
}

if ($action === 'save') {
    $id = dmd_nas_slug($_POST['id'] ?? '');
    $item = [
        'id' => $id,
        'name' => trim((string)($_POST['name'] ?? '')),
        'vendor' => $_POST['vendor'] ?? 'other',
        'model' => trim((string)($_POST['model'] ?? '')),
        'ip' => trim((string)($_POST['ip'] ?? '')),
        'hostname' => trim((string)($_POST['hostname'] ?? '')),
        'protocol' => strtolower((string)($_POST['protocol'] ?? 'http')) === 'https' ? 'https' : 'http',
        'admin_port' => trim((string)($_POST['admin_port'] ?? '')),
        'admin_url' => trim((string)($_POST['admin_url'] ?? '')),
        'backup_path' => trim((string)($_POST['backup_path'] ?? '')),
        'storage_mode' => 'private',
        'enabled' => (string)($_POST['enabled'] ?? '1') === '1',
        'notes' => trim((string)($_POST['notes'] ?? '')),
        'api_type' => strtolower((string)($_POST['api_type'] ?? 'none')),
        'api_url' => trim((string)($_POST['api_url'] ?? '')),
        'api_user' => trim((string)($_POST['api_user'] ?? '')),
    ];
    $item['vendor'] = dmd_nas_vendor($item['vendor'], $vendors);
    if ($item['vendor'] === 'qnap') {
        $item['api_type'] = 'qnap';
        if ($item['admin_port'] === '') $item['admin_port'] = $item['protocol'] === 'https' ? '443' : '8080';
    } elseif ($item['vendor'] === 'synology') {
        $item['api_type'] = 'synology';
        if ($item['admin_port'] === '') $item['admin_port'] = $item['protocol'] === 'https' ? '5001' : '5000';
    }
    $target = $item['ip'] !== '' ? $item['ip'] : $item['hostname'];
    if ($item['admin_url'] === '' && $target !== '') $item['admin_url'] = $item['protocol'].'://'.$target.($item['admin_port'] !== '' ? ':'.$item['admin_port'] : '');
    if ($item['api_url'] === '' && in_array($item['vendor'], ['qnap','synology'], true)) $item['api_url'] = $item['admin_url'];
    $originalId = dmd_nas_slug($_POST['original_id'] ?? '');
    $originalVendor = dmd_nas_vendor($_POST['original_vendor'] ?? ($item['vendor'] ?? 'other'), $vendors);
    $originalStorage = 'private';
    $originalFile = $originalId !== '' ? dmd_nas_file_path($originalId, $originalVendor, $originalStorage, $vendors) : null;
    $originalItem = ($originalFile && is_file($originalFile)) ? (json_decode((string)file_get_contents($originalFile), true) ?: []) : [];
    if (!is_array($originalItem)) $originalItem = [];

    $postedApiPass = (string)($_POST['api_pass'] ?? '');
    if ($postedApiPass !== '') {
        $item['api_pass_enc'] = dmd_nas_encrypt_secret($postedApiPass);
    } elseif (!empty($originalItem['api_pass_enc'])) {
        $item['api_pass_enc'] = $originalItem['api_pass_enc'];
    } elseif (!empty($originalItem['api_pass'])) {
        $item['api_pass_enc'] = dmd_nas_encrypt_secret((string)$originalItem['api_pass']);
    }
    if ($item['name'] === '') dmd_nas_json(false, 'Nom du NAS obligatoire.');
    if ($item['admin_url'] === '' && $item['ip'] !== '') $item['admin_url'] = $item['protocol'] . '://' . $item['ip'] . ($item['admin_port'] ? ':' . $item['admin_port'] : '');
    foreach (['modules_json'=>'modules','dockers_json'=>'dockers','applications_json'=>'applications','shares_json'=>'shares'] as $postKey=>$jsonKey) {
        if (isset($_POST[$postKey])) {
            $v = json_decode((string)$_POST[$postKey], true);
            if (is_array($v)) $item[$jsonKey] = $v;
        }
    }
    $saved = dmd_nas_save_item($item, $vendors);
    $newFile = dmd_nas_file_path($saved['id'], $saved['vendor'], $saved['storage_mode'], $vendors);
    if (!empty($originalFile) && is_file($originalFile) && $newFile && (realpath($originalFile) ?: $originalFile) !== (realpath($newFile) ?: $newFile)) {
        @unlink($originalFile);
    }
    dmd_nas_json(true, 'NAS enregistré.', ['item'=>dmd_nas_public_item($saved)]);
}

if ($action === 'delete') {
    $storage = 'private';
    
    $file = dmd_nas_file_path($_POST['id'] ?? $_GET['id'] ?? '', $_POST['vendor'] ?? $_GET['vendor'] ?? 'other', $storage, $vendors);
    if (!$file || !is_file($file)) dmd_nas_json(false, 'NAS introuvable.');
    $old = json_decode((string)file_get_contents($file), true) ?: [];
    @unlink($file);
    dmd_nas_log('delete', $old, ['file'=>$file]);
    dmd_nas_core_event('nas.deleted', array('type'=>'nas','id'=>'dmd-nas:nas:'.($old['id'] ?? ''),'label'=>$old['name'] ?? '', 'source'=>DMD_NAS_MODULE_ID));
    dmd_nas_json(true, 'NAS supprimé.');
}

$needsItem = ['test','check','scan','scanner','add_application','add_app','add_docker','add_share','dsm_refresh','dsm_packages','dsm_package_action','dsm_docker','dsm_container_action','dsm_image_action','dsm_user_action','dsm_group_action','dsm_group_members','dsm_user_groups','dsm_group_member_action','dsm_api_audit','dsm_shares_list','dsm_share_action','dsm_share_acl','dsm_share_perm_action','dsm_package_prepare_install','dsm_admin_snapshot','dsm_admin_power','dsm_admin_ssh','dsm_admin_update','dsm_admin_task','dsm_admin_storage','dsm_admin_updates_manage','dsm_admin_system_manage','qnap_refresh','qnap_packages','qnap_docker','qnap_container_action','qnap_package_action','qnap_user_action','qnap_group_action','qnap_share_action','qnap_share_acl_action'];
if (in_array($action, $needsItem, true)) {
    $storage = 'private';
    $vendor = $_POST['vendor'] ?? $_GET['vendor'] ?? 'other';
    $id = $_POST['id'] ?? $_GET['id'] ?? '';
    $file = null;
    $item = dmd_nas_find_item($id, $vendor, $storage, $vendors, $file);
    if (!$item) dmd_nas_json(false, 'NAS introuvable', ['debug'=>['id'=>$id,'vendor'=>$vendor,'storage'=>$storage,'file'=>$file]]);

    /* Routes génériques constructeur : ajout futur sans toucher l'API.
       Exemple futur : action=qnap_refresh appellera dmd_nas_qnap_refresh($item).
       Les anciennes routes dsm_* restent compatibles pour Synology. */
    if (preg_match('/^([a-z0-9_]+)_(refresh|packages|docker)$/', $action, $m)) {
        $connector = $m[1];
        $verb = $m[2];
        if ($connector !== ($item['api_type'] ?? 'none') && !($connector === 'dsm' && ($item['api_type'] ?? '') === 'synology')) {
            dmd_nas_json(false, 'API ' . strtoupper($connector) . ' non configurée sur ce NAS.');
        }
        $prefix = ($connector === 'dsm') ? 'synology' : $connector;
        $fn = 'dmd_nas_' . $prefix . '_' . $verb;
        if (function_exists($fn)) {
            $query = (string)($_POST['query'] ?? $_GET['query'] ?? '');
            $args = $verb === 'docker' ? [$item, $query] : [$item];
            [$ok, $data, $msg] = $fn(...$args);
            if (!$ok) dmd_nas_json(false, $msg);
            $key = $prefix . '_' . $verb;
            $item[$key] = $data;
            $item[$key . '_last_refresh'] = date('Y-m-d H:i:s');
            if ($verb === 'refresh') {
                $item[$prefix . '_info'] = $data;
                $item[$prefix . '_last_refresh'] = date('Y-m-d H:i:s');
            }
            dmd_nas_save_item($item, $vendors);
            dmd_nas_json(true, $msg, [$verb => $data, 'item'=>dmd_nas_public_item($item)]);
        }
    }

    if ($action === 'qnap_container_action') {
        $container = trim((string)($_POST['container'] ?? $_GET['container'] ?? ''));
        $op = strtolower(trim((string)($_POST['op'] ?? $_GET['op'] ?? '')));
        if ($container === '' || $op === '') dmd_nas_json(false, 'Conteneur ou action manquant.');
        list($ok, $data, $msg) = dmd_nas_qnap_container_action($item, $container, $op);
        if (!$ok) dmd_nas_json(false, $msg);
        dmd_nas_log('qnap_container_action', $item, array('container'=>$container,'op'=>$op));
        dmd_nas_json(true, $msg, array('result'=>$data));
    }

    if ($action === 'qnap_package_action') {
        $package = trim((string)($_POST['package'] ?? $_GET['package'] ?? ''));
        $op = strtolower(trim((string)($_POST['op'] ?? $_GET['op'] ?? '')));
        if ($package === '' || $op === '') dmd_nas_json(false, 'Application ou action manquante.');
        list($ok, $data, $msg) = dmd_nas_qnap_package_action($item, $package, $op);
        if (!$ok) dmd_nas_json(false, $msg);
        dmd_nas_log('qnap_package_action', $item, array('package'=>$package,'op'=>$op));
        dmd_nas_json(true, $msg, array('result'=>$data));
    }

    if ($action === 'qnap_user_action') {
        $op=strtolower(trim((string)($_POST['op']??''))); $user=trim((string)($_POST['user']??''));
        list($ok,$data,$msg)=dmd_nas_qnap_user_action($item,$op,$user,(string)($_POST['password']??''),trim((string)($_POST['new_name']??'')));
        if(!$ok)dmd_nas_json(false,$msg?:'Action utilisateur QNAP refusée.');
        dmd_nas_log('qnap_user_action',$item,array('op'=>$op,'user'=>$user));
        dmd_nas_json(true,$msg?:'Utilisateur QNAP mis à jour.',array('result'=>$data));
    }
    if ($action === 'qnap_group_action') {
        $op=strtolower(trim((string)($_POST['op']??''))); $group=trim((string)($_POST['group']??''));
        list($ok,$data,$msg)=dmd_nas_qnap_group_action($item,$op,$group,trim((string)($_POST['new_name']??'')));
        if(!$ok)dmd_nas_json(false,$msg?:'Action groupe QNAP refusée.');
        dmd_nas_log('qnap_group_action',$item,array('op'=>$op,'group'=>$group));
        dmd_nas_json(true,$msg?:'Groupe QNAP mis à jour.',array('result'=>$data));
    }
    if ($action === 'qnap_share_action') {
        $op=strtolower(trim((string)($_POST['op']??''))); $share=trim((string)($_POST['share']??''));
        list($ok,$data,$msg)=dmd_nas_qnap_share_action($item,$op,$share,trim((string)($_POST['new_name']??'')),trim((string)($_POST['volume']??'1')),trim((string)($_POST['comment']??'')));
        if(!$ok)dmd_nas_json(false,$msg?:'Action partage QNAP refusée.');
        dmd_nas_log('qnap_share_action',$item,array('op'=>$op,'share'=>$share));
        dmd_nas_json(true,$msg?:'Partage QNAP mis à jour.',array('result'=>$data));
    }
    if ($action === 'qnap_share_acl_action') {
        $share=trim((string)($_POST['share']??''));
        $users=json_decode((string)($_POST['users_rw']??'[]'),true); if(!is_array($users))$users=array();
        $groups=json_decode((string)($_POST['groups_rw']??'[]'),true); if(!is_array($groups))$groups=array();
        list($ok,$data,$msg)=dmd_nas_qnap_share_acl_action($item,$share,$users,$groups,trim((string)($_POST['guest']??'I')));
        if(!$ok)dmd_nas_json(false,$msg?:'Modification ACL QNAP refusée.');
        dmd_nas_log('qnap_share_acl_action',$item,array('share'=>$share));
        dmd_nas_json(true,$msg?:'ACL QNAP enregistrée.',array('result'=>$data));
    }

    if ($action === 'test' || $action === 'check') {
        $host = $item['ip'] ?: $item['hostname'];
        $port = (int)($item['admin_port'] ?: 80);
        $online = dmd_nas_tcp_check($host, $port);
        $item['last_status'] = $online ? 'online' : 'offline';
        $item['last_check'] = date('Y-m-d H:i:s');
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, $online ? 'NAS en ligne.' : 'NAS hors ligne.', ['online'=>$online,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'scan' || $action === 'scanner') {
        $host = $item['ip'] ?: $item['hostname'];
        $found = [];
        foreach (dmd_nas_known_ports($item['vendor'] ?? 'other') as $port => $meta) {
            if (dmd_nas_tcp_check($host, (int)$port, 0.7)) {
                [$name, $scheme, $desc] = $meta;
                $found[] = ['name'=>$name,'port'=>(int)$port,'url'=>$scheme ? ($scheme . '://' . $host . ':' . $port) : null,'description'=>$desc];
            }
        }
        $item['detected_services'] = $found;
        $item['last_scan'] = date('Y-m-d H:i:s');
        $item['last_status'] = count($found) ? 'online' : 'offline';
        $item['last_check'] = $item['last_scan'];
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, count($found) . ' service(s) détecté(s).', ['services'=>$found,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'add_application' || $action === 'add_app') {
        $name = trim((string)($_POST['name'] ?? ''));
        $url = trim((string)($_POST['url'] ?? ''));
        if ($name === '') dmd_nas_json(false, 'Nom application obligatoire.');
        $item['applications'] = array_values(array_filter($item['applications'] ?? [], 'is_array'));
        $item['applications'][] = ['name'=>$name,'url'=>$url,'created_at'=>date('Y-m-d H:i:s')];
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, 'Application ajoutée.', ['item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'add_docker') {
        $name = trim((string)($_POST['name'] ?? ''));
        $url = trim((string)($_POST['url'] ?? ''));
        $port = trim((string)($_POST['port'] ?? ''));
        if ($name === '') dmd_nas_json(false, 'Nom Docker obligatoire.');
        $item['dockers'] = array_values(array_filter($item['dockers'] ?? [], 'is_array'));
        $item['dockers'][] = ['name'=>$name,'url'=>$url,'port'=>$port,'created_at'=>date('Y-m-d H:i:s')];
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, 'Docker ajouté.', ['item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'add_share') {
        $name = trim((string)($_POST['name'] ?? ''));
        $path = trim((string)($_POST['path'] ?? ''));
        if ($name === '' && $path === '') dmd_nas_json(false, 'Nom ou chemin obligatoire.');
        $item['shares'] = array_values(array_filter($item['shares'] ?? [], 'is_array'));
        $item['shares'][] = ['name'=>$name ?: $path,'path'=>$path,'created_at'=>date('Y-m-d H:i:s')];
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, 'Partage ajouté.', ['item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_refresh') {
        if (($item['api_type'] ?? 'none') !== 'synology') dmd_nas_json(false, 'API Synology non configurée sur ce NAS.');
        [$ok, $data, $msg] = dmd_nas_dsm_refresh($item);
        if (!$ok) dmd_nas_json(false, $msg);
        $item['dsm_info'] = $data;
        $item['dsm_last_refresh'] = date('Y-m-d H:i:s');
        if (function_exists('dmd_nas_dsm_package_center')) {
            [$pok, $pdata, $pmsg] = dmd_nas_dsm_package_center($item);
            if ($pok) {
                $item['dsm_packages'] = $pdata;
                $item['dsm_packages_last_refresh'] = date('Y-m-d H:i:s');
                $msg .= ' Catalogue chargé : ' . count($pdata['available'] ?? []) . ' paquet(s).';
            } else {
                $item['dsm_package_last_error'] = $pmsg;
            }
        }
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, $msg, ['dsm'=>$data,'item'=>dmd_nas_public_item($item)]);
    }


    if ($action === 'dsm_packages') {
        [$ok, $data, $msg] = dmd_nas_dsm_package_center($item);
        if (!$ok) dmd_nas_json(false, $msg);
        $item['dsm_packages'] = $data;
        $item['dsm_packages_last_refresh'] = date('Y-m-d H:i:s');
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, $msg, ['packages'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_package_prepare_install') {
        $package = (string)($_POST['package'] ?? $_GET['package'] ?? '');
        if (!function_exists('dmd_nas_dsm_prepare_package_install')) dmd_nas_json(false, 'Préparation installation DSM indisponible.');
        [$ok, $data, $msg] = dmd_nas_dsm_prepare_package_install($item, $package);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_json(true, $msg, ['raw'=>$data, 'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_package_action') {
        $package = (string)($_POST['package'] ?? $_GET['package'] ?? '');
        $op = (string)($_POST['op'] ?? $_GET['op'] ?? '');
        $extraValues = (string)($_POST['extra_values'] ?? $_GET['extra_values'] ?? '');
        $volume = (string)($_POST['volume'] ?? $_GET['volume'] ?? '');
        [$ok, $data, $msg] = dmd_nas_dsm_package_action($item, $package, $op, $extraValues, $volume);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_log('dsm_package_action', $item, ['package'=>$package,'op'=>$op]);
        if (function_exists('dmd_nas_dsm_package_center')) {
            [$pok, $pdata, $pmsg] = dmd_nas_dsm_package_center($item);
            if ($pok) {
                $item['dsm_packages'] = $pdata;
                $item['dsm_packages_last_refresh'] = date('Y-m-d H:i:s');
                $msg .= ' ' . $pmsg;
            } else {
                $item['dsm_package_last_error'] = $pmsg;
            }
        }
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, $msg, ['raw'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_docker') {
        $query = (string)($_POST['query'] ?? $_GET['query'] ?? '');
        [$ok, $data, $msg] = dmd_nas_dsm_docker_center($item, $query);
        if (!$ok) dmd_nas_json(false, $msg);
        $item['dsm_docker'] = $data;
        $item['dsm_docker_last_refresh'] = date('Y-m-d H:i:s');
        dmd_nas_save_item($item, $vendors);
        dmd_nas_json(true, $msg, ['docker'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_container_action') {
        $container = (string)($_POST['container'] ?? $_GET['container'] ?? '');
        $op = (string)($_POST['op'] ?? $_GET['op'] ?? '');
        [$ok, $data, $msg] = dmd_nas_dsm_container_action($item, $container, $op);
        if (!$ok) dmd_nas_json(false, $msg);
        dmd_nas_log('dsm_container_action', $item, ['container'=>$container,'op'=>$op]);
        dmd_nas_json(true, $msg, ['raw'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_image_action') {
        $image = (string)($_POST['image'] ?? $_GET['image'] ?? '');
        $op = (string)($_POST['op'] ?? $_GET['op'] ?? 'pull');
        [$ok, $data, $msg] = dmd_nas_dsm_image_action($item, $image, $op);
        if (!$ok) dmd_nas_json(false, $msg);
        dmd_nas_log('dsm_image_action', $item, ['image'=>$image,'op'=>$op]);
        dmd_nas_json(true, $msg, ['raw'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_user_action') {
        $user = (string)($_POST['user'] ?? $_GET['user'] ?? '');
        $op = (string)($_POST['op'] ?? $_GET['op'] ?? '');
        $password = (string)($_POST['password'] ?? $_GET['password'] ?? '');
        [$ok, $data, $msg] = dmd_nas_dsm_user_action($item, $user, $op, $password);
        if (!$ok) dmd_nas_json(false, $msg);
        dmd_nas_log('dsm_user_action', $item, ['user'=>$user,'op'=>$op]);
        dmd_nas_json(true, $msg, ['raw'=>$data,'item'=>dmd_nas_public_item($item)]);
    }


    if ($action === 'dsm_group_members') {
        $group = (string)($_POST['group'] ?? $_GET['group'] ?? '');
        if (!function_exists('dmd_nas_dsm_group_members')) dmd_nas_json(false, 'Gestion des membres de groupe indisponible.');
        [$ok, $data, $msg] = dmd_nas_dsm_group_members($item, $group);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_json(true, $msg, ['members'=>$data['members'] ?? [], 'known'=>$data['known'] ?? true, 'raw'=>$data, 'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_user_groups') {
        $user = (string)($_POST['user'] ?? $_GET['user'] ?? '');
        if (!function_exists('dmd_nas_dsm_user_groups')) dmd_nas_json(false, 'Gestion des groupes utilisateur indisponible.');
        [$ok, $data, $msg] = dmd_nas_dsm_user_groups($item, $user);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_json(true, $msg, ['groups'=>$data['groups'] ?? [], 'known'=>$data['known'] ?? true, 'raw'=>$data, 'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_group_member_action') {
        $group = (string)($_POST['group'] ?? $_GET['group'] ?? '');
        $user = (string)($_POST['user'] ?? $_GET['user'] ?? '');
        $op = (string)($_POST['op'] ?? $_GET['op'] ?? '');
        if (!function_exists('dmd_nas_dsm_group_member_action')) dmd_nas_json(false, 'Action membre/groupe indisponible.');
        [$ok, $data, $msg] = dmd_nas_dsm_group_member_action($item, $group, $user, $op);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_log('dsm_group_member_action', $item, ['group'=>$group,'user'=>$user,'op'=>$op]);
        if (function_exists('dmd_nas_dsm_refresh')) {
            [$rok, $rdata, $rmsg] = dmd_nas_dsm_refresh($item);
            if ($rok) {
                $item['dsm_info'] = $rdata;
                $item['dsm_last_refresh'] = date('Y-m-d H:i:s');
                dmd_nas_save_item($item, $vendors);
            }
        }
        dmd_nas_json(true, $msg, ['raw'=>$data, 'item'=>dmd_nas_public_item($item)]);
    }




    if ($action === 'dsm_admin_snapshot') {
        if (($item['api_type'] ?? '') !== 'synology') dmd_nas_json(false, 'Administration étendue disponible pour Synology DSM.');
        $scope = strtolower((string)($_POST['scope'] ?? $_GET['scope'] ?? 'system'));
        $scopePerm = ['system'=>'nas.system.view','storage'=>'nas.storage.view','network'=>'nas.network.view','updates'=>'nas.updates.view','security'=>'nas.security.view','tasks'=>'nas.tasks.view','activity'=>'nas.activity.view','power'=>'nas.system.view'];
        dmd_nas_require($scopePerm[$scope] ?? 'nas.system.view', true);
        [$ok,$data,$msg] = dmd_nas_dsm_admin_snapshot($item, $scope);
        if (!$ok) dmd_nas_json(false,$msg,['raw'=>$data]);
        dmd_nas_json(true,$msg,['admin'=>$data,'item'=>dmd_nas_public_item($item)]);
    }
    if (in_array($action, ['dsm_admin_power','dsm_admin_ssh','dsm_admin_update','dsm_admin_task','dsm_admin_storage','dsm_admin_updates_manage','dsm_admin_system_manage','dsm_admin_network'], true)) {
        $op='';
        if($action==='dsm_admin_power') $op=(string)($_POST['op']??'');
        if($action==='dsm_admin_ssh') $op=((string)($_POST['enabled']??'0')==='1')?'ssh_enable':'ssh_disable';
        if($action==='dsm_admin_update') $op='update_check';
        if($action==='dsm_admin_task') $op=(string)($_POST['op']??'');
        if($action==='dsm_admin_storage') $op=(string)($_POST['op']??'');
        if($action==='dsm_admin_updates_manage') $op=((string)($_POST['enabled']??'0')==='1')?'update_smart_nano_on':'update_smart_nano_off';
        if($action==='dsm_admin_system_manage') $op='hibernation_set';
        if($action==='dsm_admin_network') $op=(string)($_POST['op']??'network_general_set');
        $args=[
          'port'=>(int)($_POST['port']??22),'task_id'=>(int)($_POST['task_id']??0),'owner'=>(string)($_POST['owner']??'root'),
          'pool_id'=>(string)($_POST['pool_id']??''),'volume_path'=>(string)($_POST['volume_path']??''),'disk_id'=>(string)($_POST['disk_id']??''),'description'=>(string)($_POST['description']??''),
          'internal_hd_idletime'=>(int)($_POST['internal_hd_idletime']??0),'usb_idletime'=>(int)($_POST['usb_idletime']??0),
          'name'=>(string)($_POST['name']??''),'script'=>(string)($_POST['script']??''),'time'=>(string)($_POST['time']??'03:00'),
          'hostname'=>(string)($_POST['hostname']??''),'dns'=>(string)($_POST['dns']??''),'workgroup'=>(string)($_POST['workgroup']??''),
          'interface'=>(string)($_POST['interface']??''),'dhcp'=>(string)($_POST['dhcp']??'0')==='1','address'=>(string)($_POST['address']??''),'netmask'=>(string)($_POST['netmask']??''),'gateway'=>(string)($_POST['gateway']??''),'mtu'=>(int)($_POST['mtu']??0),
          'raid_type'=>(string)($_POST['raid_type']??'shr'),'disks'=>(string)($_POST['disks']??''),'fs_type'=>(string)($_POST['fs_type']??'btrfs'),'size'=>(string)($_POST['size']??'')
        ];
        [$ok,$data,$msg]=dmd_nas_dsm_admin_action($item,$op,$args);
        if(!$ok) dmd_nas_json(false,$msg,['raw'=>$data]);
        dmd_nas_log($action,$item,['op'=>$op,'args'=>$args]);
        dmd_nas_json(true,$msg,['raw'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_api_audit') {
        if (($item['api_type'] ?? 'none') !== 'synology') dmd_nas_json(false, 'Audit DSM disponible uniquement pour Synology.');
        if (!function_exists('dmd_nas_dsm_api_audit')) dmd_nas_json(false, 'Audit API DSM indisponible dans synology.php.');
        [$ok, $data, $msg] = dmd_nas_dsm_api_audit($item);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_log('dsm_api_audit', $item, ['file'=>$data['report_file'] ?? '']);
        dmd_nas_json(true, $msg, ['report'=>$data, 'item'=>dmd_nas_public_item($item)]);
    }


    if ($action === 'dsm_shares_list') {
        if (!function_exists('dmd_nas_dsm_shares_list')) dmd_nas_json(false, 'Lecture des partages DSM indisponible.');
        [$ok,$data,$msg] = dmd_nas_dsm_shares_list($item);
        if (!$ok) dmd_nas_json(false,$msg,['raw'=>$data,'item'=>dmd_nas_public_item($item)]);
        $item['dsm_info'] = is_array($item['dsm_info'] ?? null) ? $item['dsm_info'] : [];
        $item['dsm_info']['shares'] = $data;
        dmd_nas_save_item($item,$vendors);
        dmd_nas_json(true,$msg,['shares'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_share_action') {
        $share = (string)($_POST['share'] ?? $_GET['share'] ?? '');
        $op = (string)($_POST['op'] ?? $_GET['op'] ?? '');
        $volume = (string)($_POST['volume'] ?? $_GET['volume'] ?? '');
        $newName = (string)($_POST['new_name'] ?? $_GET['new_name'] ?? '');
        $description = (string)($_POST['description'] ?? $_GET['description'] ?? '');
        if (!function_exists('dmd_nas_dsm_share_action')) dmd_nas_json(false, 'Gestion des partages DSM indisponible.');
        [$ok, $data, $msg] = dmd_nas_dsm_share_action($item, $share, $op, $volume, $newName, $description);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_log('dsm_share_action', $item, ['share'=>$share,'op'=>$op]);
        if (function_exists('dmd_nas_dsm_shares_list')) {
            [$rok,$rshares,$rmsg] = dmd_nas_dsm_shares_list($item);
            if ($rok) { $item['dsm_info'] = is_array($item['dsm_info'] ?? null) ? $item['dsm_info'] : []; $item['dsm_info']['shares']=$rshares; dmd_nas_save_item($item,$vendors); }
        }
        dmd_nas_json(true, $msg, ['raw'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_share_acl') {
        $share = (string)($_POST['share'] ?? $_GET['share'] ?? '');
        if (!function_exists('dmd_nas_dsm_share_acl')) dmd_nas_json(false, 'Lecture droits DSM indisponible.');
        [$ok, $data, $msg] = dmd_nas_dsm_share_acl($item, $share);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_json(true, $msg, ['permissions'=>$data, 'raw'=>$data, 'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_share_perm_action') {
        $share = (string)($_POST['share'] ?? $_GET['share'] ?? '');
        $principal = (string)($_POST['principal'] ?? $_GET['principal'] ?? '');
        $principalType = (string)($_POST['principal_type'] ?? $_GET['principal_type'] ?? 'user');
        $permission = (string)($_POST['permission'] ?? $_GET['permission'] ?? 'read_only');
        if (!function_exists('dmd_nas_dsm_share_perm_action')) dmd_nas_json(false, 'Modification droits DSM indisponible.');
        [$ok, $data, $msg] = dmd_nas_dsm_share_perm_action($item, $share, $principal, $principalType, $permission);
        if (!$ok) dmd_nas_json(false, $msg, ['raw'=>$data ?? null, 'item'=>dmd_nas_public_item($item)]);
        dmd_nas_log('dsm_share_perm_action', $item, ['share'=>$share,'principal'=>$principal,'type'=>$principalType,'permission'=>$permission]);
        dmd_nas_json(true, $msg, ['raw'=>$data, 'item'=>dmd_nas_public_item($item)]);
    }

    if ($action === 'dsm_group_action') {
        $group = (string)($_POST['group'] ?? $_GET['group'] ?? '');
        $op = (string)($_POST['op'] ?? $_GET['op'] ?? '');
        $description = (string)($_POST['description'] ?? $_GET['description'] ?? '');
        [$ok, $data, $msg] = dmd_nas_dsm_group_action($item, $group, $op, $description);
        if (!$ok) dmd_nas_json(false, $msg);
        dmd_nas_log('dsm_group_action', $item, ['group'=>$group,'op'=>$op]);
        dmd_nas_json(true, $msg, ['raw'=>$data,'item'=>dmd_nas_public_item($item)]);
    }

}

dmd_nas_json(false, 'Action inconnue : ' . $action);
